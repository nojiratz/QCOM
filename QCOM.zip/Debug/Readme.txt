==============================================================================
QCOM Transducer Communications Software (C) 2010
Quartzdyne, Inc. (a Dover Company)
==============================================================================
The latest version of the QCOM software can be downloaded from
http://www.quartzdyne.com/software.htm
------------------------------------------------------------------------------
Run the executable file (QCOM-Setup-X.Y.Z.exe, where X is the major version,
Y is the minor version, and Z is the build or micro version).

Select the Typical installation, and an icon for QCOM will be installed on
your desktop.
------------------------------------------------------------------------------
To uninstall QCOM, run Control Panel, and click Programs and Features (Add or
Remove Programs prior to Windows 7), highlight QCOM, and click Uninstall
------------------------------------------------------------------------------
Report problems or questions regarding QCOM to support@quartzdyne.com
==============================================================================
