<?php
//============================================================================
// //qdlamp/var/www/qd.quartzdyne.com/QCOM/CoefficientFilesDownload.php
//
// Transducer coefficient data file background retrieval script
//
// Copyright (C) 2012 - 2015 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// Updated 12-04-2015
//============================================================================
    //------------------------------------------------------------------------
    // According to http://support.microsoft.com/kb/234067 the next three
    // lines effectively prevent caching the page in IE
    //------------------------------------------------------------------------
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: -1');
    header('Pragma: no-cache');
    //------------------------------------------------------------------------
    // File date and version
    //------------------------------------------------------------------------
    define('displayVersion', '1.0.2');
    define('sourceVersion', displayVersion . '.2015-08-04');
    //------------------------------------------------------------------------
    // Quartzdyne-specific websites
    //------------------------------------------------------------------------
    define('QD_HomeDir', 'http://www.quartzdyne.com/');
    define('QD_HostDir', 'http://qd.quartzdyne.com/');
    define('QD_PublicDir', QD_HostDir);
    define('QD_DataDir', QD_PublicDir . 'cdata/');
    if (!file_exists('/mnt/QD/Ops/Cal_Data/47xx/4707/192134.hex'))
    {
        echo('You need to mount //qdcluster/public first<br />');
    }
    //------------------------------------------------------------------------
    // Program constant definitions
    //------------------------------------------------------------------------
    define('webDataDirectory' , '/var/www/qd.quartzdyne.com/cdata/');
    //------------------------------------------------------------------------
    // Open the database
    //------------------------------------------------------------------------
    $mysql = @mysql_connect('localhost', 'qdweb', '4internal');
    @mysql_select_db('CalSum2', $mysql);
    //------------------------------------------------------------------------
    // Retrieve the serial number and begin parsing
    //------------------------------------------------------------------------
    $serialNumberString = $_REQUEST['sn'];
    //------------------------------------------------------------------------
    // Invalid serial number entered
    //------------------------------------------------------------------------
    if (strlen($serialNumberString) != 6)
    {
        exit;
    }
    //------------------------------------------------------------------------
    // Query for the coefficient paths
    //------------------------------------------------------------------------
    $serialNumberQuery =
        "SELECT dir, sernum
            FROM Path
            WHERE sernum in ($serialNumberString)
                AND dir = (
                    SELECT Path2.dir
                    FROM Path AS Path2
                    WHERE Path2.sernum = Path.sernum
                    ORDER BY Path2.date DESC
                LIMIT 1
                )
            ORDER BY sernum
        LIMIT 1";
    $result = @mysql_query($serialNumberQuery, $mysql);
    //------------------------------------------------------------------------
    // Coefficient files found, so ZIP them up and initiate the download
    //------------------------------------------------------------------------
    if(@mysql_num_rows($result))
    {
        echo('DB results found<br />');
        //--------------------------------------------------------------------
        // Clean up the data directory by deleting all the .ZIP files
        //--------------------------------------------------------------------
        if (($dirHandle = opendir(webDataDirectory)) !== false)
        {
            while (($dirEntry = readdir($dirHandle)) !== false)
            {
                $entryPath = webDataDirectory . $dirEntry;
                if (stristr($entryPath, '.zip'))
                {
                    unlink($entryPath);
                }
            }
        }
        //--------------------------------------------------------------------
        // Create a filename from the serial number
        //--------------------------------------------------------------------
        $zipfile = $serialNumberString . '.zip';
        $zipWebName = webDataDirectory . $zipfile;
        //--------------------------------------------------------------------
        // Open a ZIP archive session
        //--------------------------------------------------------------------
        $zip = new ZipArchive();
        $zipStatus = $zip->open($zipWebName, (ZIPARCHIVE::CREATE | ZIPARCHIVE::OVERWRITE));
        if ($zipStatus == true)
        {
            while($row = @mysql_fetch_row($result))
            {
                $fullPath = $row[0] . '/';
                if (($dirHandle = opendir($fullPath)) !== false)
                {
                    while (($dirEntry = readdir($dirHandle)) !== false)
                    {
                        if (stristr($dirEntry, '.hex') ||
                            stristr($dirEntry, '.crf') ||
                            stristr($dirEntry, '.crt') ||
                            stristr($dirEntry, '.cff') ||
                            stristr($dirEntry, '.cft'))
                        {
                            $entryPath = $fullPath . $dirEntry;
                            if (stristr($entryPath, $row[1]))
                            {
                                if (is_file($entryPath))
                                {
                                    $zip->addFile($entryPath, $dirEntry);
                                }
                            }
                        }
                    }
                }
            }
            //----------------------------------------------------------------
            // Close the ZIP archive session
            //----------------------------------------------------------------
            $zip->close();
        }
        //--------------------------------------------------------------------
        // Call the new .ZIP file and exit
        //--------------------------------------------------------------------
        header('Location: ' . QD_DataDir . $zipfile);
    }                                   // end of if(@mysql_num_rows($result))
    exit;
//============================================================================
// CoefficientFilesDownload.php Revision History (defined as sourceVersion
// in this source)
//
//  14 Dec 2012     1.0.0       1.  Initial public release, first used by
//                                  the QCOM software for downloading
//                                  coefficient data files
//
//  29 May 2015     1.0.1       1.  Updated for the new directory structure
//
//  04 Aug 2015     1.0.2       1.  Updated for the new qdlamp
//
// End of CoefficientFilesDownload.php
//============================================================================
?>
