<?php
//============================================================================
// //qdlamp/var/www/qd.quartzdyne.com/QCOM/QCOM-Archive.php
//
// Download page for QCOM archived software
//
// Copyright (C) 2011 - 2015 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software.  Also,
// a detailed revision history of this file is included at the bottom of this
// source.
//============================================================================
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: -1');
    header('Pragma: no-cache');
    define('displayVersion', '1.1.1');
    define('updatedDate', '2015-09-10');
    define('sourceVersion', displayVersion . '.' . updatedDate);
    include('/var/www/qd.quartzdyne.com/script/server/MainDefs.php');
    //------------------------------------------------------------------------
    // QCOM-specific websites
    //------------------------------------------------------------------------
    define('QCOM_PublicDir', QD_PublicDir . 'QCOM/');
    define('QCOM_PkgDir', QCOM_PublicDir . 'pkg/');
    define('QCOM_HelpSite', QCOM_PublicDir . 'QCOM-Help.php');
    define('QCOM_DownloadSite', QCOM_PublicDir . 'QCOM-Download.php');
    //------------------------------------------------------------------------
    // Packages
    //------------------------------------------------------------------------
    define('QCOM_SW_Version_1_0_7', '1.0.7');
    define('QCOM_SW_1_0_7', 'QCOM-Setup-' . QCOM_SW_Version_1_0_7 . '.exe');
    define('QCOM_SW_Date_1_0_7', '06-13-2014');
    //------------------------------------------------------------------------
    define('QCOM_SW_Version_1_0_6', '1.0.6');
    define('QCOM_SW_1_0_6', 'QCOM-Setup-' . QCOM_SW_Version_1_0_6 . '.exe');
    define('QCOM_SW_Date_1_0_6', '12-07-2012');
    //------------------------------------------------------------------------
    define('QCOM_SW_Version_1_0_5', '1.0.5');
    define('QCOM_SW_1_0_5', 'QCOM-Setup-' . QCOM_SW_Version_1_0_5 . '.exe');
    define('QCOM_SW_Date_1_0_5', '03-22-2012');
    //------------------------------------------------------------------------
    define('QCOM_SW_Version_1_0_4', '1.0.4');
    define('QCOM_SW_1_0_4', 'QCOM-Setup-' . QCOM_SW_Version_1_0_4 . '.exe');
    define('QCOM_SW_Date_1_0_4', '07-07-2011');
    //------------------------------------------------------------------------
    define('QCOM_SW_Version_1_0_3', '1.0.3');
    define('QCOM_SW_1_0_3', 'QCOM-Setup-' . QCOM_SW_Version_1_0_3 . '.exe');
    define('QCOM_SW_Date_1_0_3', '06-22-2011');
    //------------------------------------------------------------------------
    define('QCOM_SW_Version_1_0_2', '1.0.2');
    define('QCOM_SW_1_0_2', 'QCOM-Setup-' . QCOM_SW_Version_1_0_2 . '.exe');
    define('QCOM_SW_Date_1_0_2', '06-03-2011');
    //------------------------------------------------------------------------
    define('QCOM_SW_Version_1_0_1', '1.0.1');
    define('QCOM_SW_1_0_1', 'QCOM-Setup-' . QCOM_SW_Version_1_0_1 . '.exe');
    define('QCOM_SW_Date_1_0_1', '05-17-2011');
    //------------------------------------------------------------------------
    define('QCOM_SW_Version_1_0_0', '1.0.0');
    define('QCOM_SW_1_0_0', 'QCOM-Setup-' . QCOM_SW_Version_1_0_0 . '.exe');
    define('QCOM_SW_Date_1_0_0', '04-11-2011');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Version_1_0_8', '1.0.8');
    define('QCOM_DLL_1_0_8', 'QCOM-DLL-' . QCOM_DLL_Version_1_0_8 . '.zip');
    define('QCOM_DLL_Date_1_0_8', '05-22-2013');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Version_1_0_7', '1.0.7');
    define('QCOM_DLL_1_0_7', 'QCOM-DLL-' . QCOM_DLL_Version_1_0_7 . '.zip');
    define('QCOM_DLL_Date_1_0_7', '12-07-2012');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Version_1_0_6', '1.0.6');
    define('QCOM_DLL_1_0_6', 'QCOM-DLL-' . QCOM_DLL_Version_1_0_6 . '.zip');
    define('QCOM_DLL_Date_1_0_6', '10-03-2012');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Version_1_0_5', '1.0.5');
    define('QCOM_DLL_1_0_5', 'QCOM-DLL-' . QCOM_DLL_Version_1_0_5 . '.zip');
    define('QCOM_DLL_Date_1_0_5', '01-17-2012');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Version_1_0_4', '1.0.4');
    define('QCOM_DLL_1_0_4', 'QCOM-DLL-' . QCOM_DLL_Version_1_0_4 . '.zip');
    define('QCOM_DLL_Date_1_0_4', '08-19-2011');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Version_1_0_3', '1.0.3');
    define('QCOM_DLL_1_0_3', 'QCOM-DLL-' . QCOM_DLL_Version_1_0_3 . '.zip');
    define('QCOM_DLL_Date_1_0_3', '07-07-2011');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Version_1_0_2', '1.0.2');
    define('QCOM_DLL_1_0_2', 'QCOM-DLL-' . QCOM_DLL_Version_1_0_2 . '.zip');
    define('QCOM_DLL_Date_1_0_2', '06-17-2011');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Version_1_0_1', '1.0.1');
    define('QCOM_DLL_1_0_1', 'QCOM-DLL-' . QCOM_DLL_Version_1_0_1 . '.zip');
    define('QCOM_DLL_Date_1_0_1', '05-17-2011');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Version_1_0_0', '1.0.0');
    define('QCOM_DLL_1_0_0', 'QCOM-DLL-' . QCOM_DLL_Version_1_0_0 . '.zip');
    define('QCOM_DLL_Date_1_0_0', '04-11-2011');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Spec_Version_B3', 'B3');
    define('QCOM_DLL_Spec_B3', 'QCOM-DLL-Spec-' . QCOM_DLL_Spec_Version_B3 . '.pdf');
    define('QCOM_DLL_Spec_Date_B3', '01-17-2012');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Spec_Version_B2', 'B2');
    define('QCOM_DLL_Spec_B2', 'QCOM-DLL-Spec-' . QCOM_DLL_Spec_Version_B2 . '.pdf');
    define('QCOM_DLL_Spec_Date_B2', '07-18-2011');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Spec_Version_B1', 'B1');
    define('QCOM_DLL_Spec_B1', 'QCOM-DLL-Spec-' . QCOM_DLL_Spec_Version_B1 . '.pdf');
    define('QCOM_DLL_Spec_Date_B1', '05-06-2011');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Spec_Version_B0', 'B0');
    define('QCOM_DLL_Spec_B0', 'QCOM-DLL-Spec-' . QCOM_DLL_Spec_Version_B0 . '.pdf');
    define('QCOM_DLL_Spec_Date_B0', '04-06-2011');
    //------------------------------------------------------------------------
    define('QCOM_Firmware_Version_1_1', '1.1');
    define('QCOM_Firmware_1_1', 'QCOM-Firmware-' . QCOM_Firmware_Version_1_1 . '.zip');
    //------------------------------------------------------------------------
    define('QCOM_Firmware_Version_1_0', '1.0');
    define('QCOM_Firmware_1_0', 'QCOM-Firmware-' . QCOM_Firmware_Version_1_0 . '.zip');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Spec_Date_B1', '05-06-2011');
    //------------------------------------------------------------------------
    define('QCOM_VB_Demo_Version_1_0_2', '1.0.2');
    define('QCOM_VB_Demo_1_0_2', 'QCOM-VB-Demo-' . QCOM_VB_Demo_Version_1_0_2 . '.zip');
    define('QCOM_VB_Demo_Date_1_0_2', '06-17-2011');
    //------------------------------------------------------------------------
    define('QCOM_VB_Demo_Version_1_0_1', '1.0.1');
    define('QCOM_VB_Demo_1_0_1', 'QCOM-VB-Demo-' . QCOM_VB_Demo_Version_1_0_1 . '.zip');
    define('QCOM_VB_Demo_Date_1_0_1', '05-19-2011');
    //------------------------------------------------------------------------
    define('QCOM_VB_Demo_Version_1_0_0', '1.0.0');
    define('QCOM_VB_Demo_1_0_0', 'QCOM-VB-Demo-' . QCOM_VB_Demo_Version_1_0_0 . '.zip');
    define('QCOM_VB_Demo_Date_1_0_0', '04-21-2011');
    //------------------------------------------------------------------------
    define('QCOM_LV_Demo_Version_1_0_2', '1.0.2');
    define('QCOM_LV_Demo_1_0_2', 'QCOM-LV-Demo-' . QCOM_LV_Demo_Version_1_0_2 . '.zip');
    define('QCOM_LV_Demo_Date_1_0_2', '06-17-2011');
    //------------------------------------------------------------------------
    define('QCOM_LV_Demo_Version_1_0_1', '1.0.1');
    define('QCOM_LV_Demo_1_0_1', 'QCOM-LV-Demo-' . QCOM_LV_Demo_Version_1_0_1 . '.zip');
    define('QCOM_LV_Demo_Date_1_0_1', '05-18-2011');
    //------------------------------------------------------------------------
    define('QCOM_LV_Demo_Version_1_0_0', '1.0.0');
    define('QCOM_LV_Demo_1_0_0', 'QCOM-LV-Demo-' . QCOM_LV_Demo_Version_1_0_0 . '.zip');
    define('QCOM_LV_Demo_Date_1_0_0', '04-11-2011');
    //------------------------------------------------------------------------
    define('QCOM_VC_Demo_Version_1_0_0', '1.0.0');
    define('QCOM_VC_Demo_1_0_0', 'QCOM-VC-Demo-' . QCOM_VC_Demo_Version_1_0_0 . '.zip');
    define('QCOM_VC_Demo_Date_1_0_0', '05-23-2011');
    //------------------------------------------------------------------------
    // Support
    //------------------------------------------------------------------------
    define('emailSubject' , 'QCOM Archives (Version ' . sourceVersion . ')');
    define('reportIssues',
        'Please communicate problems and suggestions to <a href="' . mailSite . '?emailSubject=' .
        emailSubject . '&dest=support" target="_blank">Quartzdyne Support</a>');
    //------------------------------------------------------------------------
    include('/script/server/compresshtml.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
    <head>
        <title>QCOM Archives</title>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <meta name="description" content="This page displays the QCOM software archives site" />
        <meta name="keywords" content="quartzdyne, quartz, downhole, pressure, temperature, sensor, transducer, archive, QCOM" />
        <meta name="distribution" content="global" />
        <meta name="author" content="Noji Ratzlaff" />
        <link href="/image/quartzdyne.ico" rel="shortcut icon" type="image/x-icon" />
        <link href="/style/qdprogstd.css" rel="stylesheet" type="text/css" />
        <link href="/style/reset1.css" rel="stylesheet" type="text/css" />
        <link href="/style/table1.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
            body
            {
                background-image: url('/image/white_sand.jpg');
                font: 100% verdana,sans-serif;
                margin-left: 16px;
                margin-right: 16px;
                margin-top: 8px;
            }
            @media print
            {
                table
                {
                    font-size: 140%;
                }
            }
        </style>
        <?  //----------------------------------------------------------------
            // Invoke the javascript page header functions
            //----------------------------------------------------------------
        ?>
        <script src="<?=clientScriptDir ?>PageHeader.js" language="javascript" type="text/javascript"></script>
        <script src="<?=clientScriptDir ?>ExpandCollapse.js" language="javascript" type="text/javascript"></script>
        <?  //----------------------------------------------------------------
            // Define local javascript functions
            //----------------------------------------------------------------
        ?>
        <script type="text/javascript">
<!--
//-->
        </script>
    </head>
    <body onselectstart="event.returnValue=false;">
        <div id="qd_div" lang="QD"></div>
        <?  //----------------------------------------------------------------
            // Display the company logo and a button to print the page
            //----------------------------------------------------------------
        ?>
        <div style="margin:auto; text-align:center; width:1000px;" id="MainHeader">
            <a href="http://www.quartzdyne.com" target="_blank" name="doc_top">
                <img src="/image/QDDoverLogo.png" style="float:left; width:150px; margin-bottom:10px;" alt="Quartzdyne" />
            </a>
            <div style="margin-left:20px; margin-bottom:10px; text-align:center; float:left;">
                <div style="color:black; font-weight:bold; font-size:160%;">
                    <span style="color:red; font-style:italic; font-weight:extra-bold; font-family:Arial,sans;">
                        <acronym title="Quartzdyne Communication Module">
                            QCOM
                        </acronym>
                    </span>
                    Software Archives
                </div>
                <span style="font-size:120%; margin-top:5px;">
                    <?=date('D d M Y h:i:s a'); ?>
                </span>
                <span>
                    <form style="margin-top:10px;">
                        <input
                            type="button"
                            onClick="window.print()"
                            value=" Print This Page "
                            style="color:blue;" />
                    </form>
                </span>
            </div>
        </div>                          <? // end of MainHeader ?>
        <div style="clear:both;" id="MainBody">
            <a href="<?=QCOM_DownloadSite ?>">Return</a> to the QCOM Download Center
            <br /><br />
            <a href="<?=QCOM_HelpSite ?>">Return</a> to the QCOM Help Center
            <br /><br />
            <?=reportIssues ?>
            <hr class="redLine" />
            <div class="archive_category" id="ProductionSW"
                onclick="expand_collapse('ProductionSW_Body')"
                ondblclick="expand_collapse('ProductionSW_Body')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                <img src="/image/Purple-Dot.gif" class="centerDot" />
                QCOM Production Software
            </div>
            <div class="archive_invisible" id="ProductionSW_Body" lang="QD">
                <div class="archive_topic"
                    onclick="expand_collapse('SW107ChangeHistory')"
                    ondblclick="expand_collapse('SW107ChangeHistory')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    Version 1.0.7
                </div>
                <div class="archive_subtopic" id="SW107ChangeHistory" lang="QD">
                    <div>
                        <b>
                            1.0.7.4 (06-13-2014) <a href="archive/QCOM-1.0.7.4.zip">ZIP</a> file and
                            <a href="archive/QCOM-Setup-1.0.7.exe">Setup</a> file
                        </b>
                    </div>
                    <br />
                    <div>
                        <b>
                            1.0.7.3 (08-01-2013) <a href="archive/QCOM-1.0.7.3.zip">ZIP</a> file
                        </b>
                    </div>
                    <br />
                    <div>
                        <b>
                            1.0.7.2 (07-12-2013) <a href="archive/QCOM-1.0.7.2.zip">ZIP</a> file
                        </b>
                    </div>
                    <br />
                    <div>
                        <b>
                            1.0.7.1 (06-21-2013) <a href="archive/QCOM-1.0.7.1.zip">ZIP</a> file
                        </b>
                    </div>
                    <br />
                    <div>
                        <b>
                            1.0.7.0 (06-04-2013) <a href="archive/QCOM-1.0.7.0.zip">ZIP</a> file
                        </b>
                    </div>
                </div>                  <? // end of SW107ChangeHistory subtopic ?>
                Version <a href="archive/<?=QCOM_SW_1_0_6 ?>"><?=QCOM_SW_Version_1_0_6 ?></a> (<?=QCOM_SW_Date_1_0_6 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_SW_1_0_5 ?>"><?=QCOM_SW_Version_1_0_5 ?></a> (<?=QCOM_SW_Date_1_0_5 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_SW_1_0_4 ?>"><?=QCOM_SW_Version_1_0_4 ?></a> (<?=QCOM_SW_Date_1_0_4 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_SW_1_0_3 ?>"><?=QCOM_SW_Version_1_0_3 ?></a> (<?=QCOM_SW_Date_1_0_3 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_SW_1_0_2 ?>"><?=QCOM_SW_Version_1_0_2 ?></a> (<?=QCOM_SW_Date_1_0_2 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_SW_1_0_1 ?>"><?=QCOM_SW_Version_1_0_1 ?></a> (<?=QCOM_SW_Date_1_0_1 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_SW_1_0_0 ?>"><?=QCOM_SW_Version_1_0_0 ?></a> (<?=QCOM_SW_Date_1_0_0 ?>)
            </div>
            <div class="archive_category" id="ProductionDLL"
                onclick="expand_collapse('ProductionDLL_Body')"
                ondblclick="expand_collapse('ProductionDLL_Body')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                <img src="/image/Purple-Dot.gif" class="centerDot" />
                QCOM DLL
            </div>
            <div class="archive_invisible" id="ProductionDLL_Body" lang="QD">
                Version <a href="archive/<?=QCOM_DLL_1_0_8 ?>"><?=QCOM_DLL_Version_1_0_8 ?></a> (<?=QCOM_DLL_Date_1_0_8 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_DLL_1_0_7 ?>"><?=QCOM_DLL_Version_1_0_7 ?></a> (<?=QCOM_DLL_Date_1_0_7 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_DLL_1_0_6 ?>"><?=QCOM_DLL_Version_1_0_6 ?></a> (<?=QCOM_DLL_Date_1_0_6 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_DLL_1_0_5 ?>"><?=QCOM_DLL_Version_1_0_5 ?></a> (<?=QCOM_DLL_Date_1_0_5 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_DLL_1_0_4 ?>"><?=QCOM_DLL_Version_1_0_4 ?></a> (<?=QCOM_DLL_Date_1_0_4 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_DLL_1_0_3 ?>"><?=QCOM_DLL_Version_1_0_3 ?></a> (<?=QCOM_DLL_Date_1_0_3 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_DLL_1_0_2 ?>"><?=QCOM_DLL_Version_1_0_2 ?></a> (<?=QCOM_DLL_Date_1_0_2 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_DLL_1_0_1 ?>"><?=QCOM_DLL_Version_1_0_1 ?></a> (<?=QCOM_DLL_Date_1_0_1 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_DLL_1_0_0 ?>"><?=QCOM_DLL_Version_1_0_0 ?></a> (<?=QCOM_DLL_Date_1_0_0 ?>)
            </div>
            <div class="archive_category" id="DLLSpec"
                onclick="expand_collapse('DLLSpec_Body')"
                ondblclick="expand_collapse('DLLSpec_Body')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                <img src="/image/Purple-Dot.gif" class="centerDot" />
                QCOM DLL Specification
            </div>
            <div class="archive_invisible" id="DLLSpec_Body" lang="QD">
                Version <a href="archive/<?=QCOM_DLL_Spec_B3 ?>" target="_blank"><?=QCOM_DLL_Spec_Version_B3 ?></a> (<?=QCOM_DLL_Spec_Date_B3 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_DLL_Spec_B2 ?>" target="_blank"><?=QCOM_DLL_Spec_Version_B2 ?></a> (<?=QCOM_DLL_Spec_Date_B2 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_DLL_Spec_B1 ?>" target="_blank"><?=QCOM_DLL_Spec_Version_B1 ?></a> (<?=QCOM_DLL_Spec_Date_B1 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_DLL_Spec_B0 ?>" target="_blank"><?=QCOM_DLL_Spec_Version_B0 ?></a> (<?=QCOM_DLL_Spec_Date_B0 ?>)
            </div>
            <div class="archive_category" id="ProductionFW"
                onclick="expand_collapse('ProductionFW_Body')"
                ondblclick="expand_collapse('ProductionFW_Body')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                <img src="/image/Purple-Dot.gif" class="centerDot" />
                QCOM Firmware
            </div>
            <div class="archive_invisible" id="ProductionFW_Body" lang="QD">
                Version <a href="archive/<?=QCOM_Firmware_1_1 ?>" target="_blank"><?=QCOM_Firmware_Version_1_1 ?></a>
                <br /><br />
                Version <a href="archive/<?=QCOM_Firmware_1_0 ?>" target="_blank"><?=QCOM_Firmware_Version_1_0 ?></a>
            </div>
            <div class="archive_category" id="VBDemo"
                onclick="expand_collapse('VBDemo_Body')"
                ondblclick="expand_collapse('VBDemo_Body')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                <img src="/image/Purple-Dot.gif" class="centerDot" />
                QCOM VB Demo
            </div>
            <div class="archive_invisible" id="VBDemo_Body" lang="QD">
                Version <a href="archive/<?=QCOM_VB_Demo_1_0_2 ?>"><?=QCOM_VB_Demo_Version_1_0_2 ?></a> (<?=QCOM_VB_Demo_Date_1_0_2 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_VB_Demo_1_0_1 ?>"><?=QCOM_VB_Demo_Version_1_0_1 ?></a> (<?=QCOM_VB_Demo_Date_1_0_1 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_VB_Demo_1_0_0 ?>"><?=QCOM_VB_Demo_Version_1_0_0 ?></a> (<?=QCOM_VB_Demo_Date_1_0_0 ?>)
            </div>
            <div class="archive_category" id="LVDemo"
                onclick="expand_collapse('LVDemo_Body')"
                ondblclick="expand_collapse('LVDemo_Body')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                <img src="/image/Purple-Dot.gif" class="centerDot" />
                QCOM LabVIEW Demo
            </div>
            <div class="archive_invisible" id="LVDemo_Body" lang="QD">
                Version <a href="archive/<?=QCOM_LV_Demo_1_0_2 ?>"><?=QCOM_LV_Demo_Version_1_0_2 ?></a> (<?=QCOM_LV_Demo_Date_1_0_2 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_LV_Demo_1_0_1 ?>"><?=QCOM_LV_Demo_Version_1_0_1 ?></a> (<?=QCOM_LV_Demo_Date_1_0_1 ?>)
                <br /><br />
                Version <a href="archive/<?=QCOM_LV_Demo_1_0_0 ?>"><?=QCOM_LV_Demo_Version_1_0_0 ?></a> (<?=QCOM_LV_Demo_Date_1_0_0 ?>)
            </div>
        </div>                          <? // end of MainBody ?>
        <hr class="redLine" />
        <div class="page_bottom" id="MainFooter">
            <i class="flush_left">Copyright &copy; <?=date('Y'); ?> <a href="<?=QD_HomeDir ?>" target="_blank">Quartzdyne, Inc.</a>, a <a href="<?=DoverDir ?>" target="_blank">Dover</a><sup>&reg;</sup> company</i>
            <span class="flush_right" style="font-size:80%;">(Version <?=sourceVersion ?> [<script type="text/javascript">document.write(browserFlag);</script>])</span>
        </div>                          <? // end of MainFooter ?>
    </body>
</html>
<?php
//============================================================================
// QCOM-Archive.php Revision History (defined as sourceVersion in this source)
//
//  04 May 2011     1.0.0       1.  Initial public release
//
//  20 May 2011     1.0.1       1.  Reformatted with standardized macros for
//                                  support
//
//  19 Aug 2011     1.0.2       1.  Added support for Chrome, Safari, and Opera
//
//  21 Sep 2012     1.0.3       1.  Added qdUSB.dll 1.0.5
//
//  21 Nov 2012     1.0.4       1.  Added LabVIEW demo 1.0.2
//
//  28 Nov 2012     1.0.5       1.  Added qdUSB.dll 1.0.6
//                              2.  Changed the character set to UTF-8
//                              3.  Removed the no-cache pragma meta
//                              4.  Added the global distribution meta
//
//  07 Mar 2013     1.0.6       1.  Made the categories collapsible
//                              2.  Made redundant tags reference classes
//                              3.  Began using qdprogstd.css
//
//  05 Jun 2013     1.0.7       1.  Added qdUSB.dll 1.0.7
//                              2.  Added QCOM software 1.0.6
//
//  01 Aug 2013     1.0.8       1.  Added QCOM software 1.0.7 and sub-sections
//
//  06 Dec 2013     1.0.9       1.  Began using MainDefs.php
//                              2.  Moved the browser detection scripts to
//                                  PageHeader.js
//  13 Jun 2014     1.1.0       1.  Added QCOM software 1.0.7.4
//                              2.  Reformatted the presentation of the minor
//                                  software builds
//
//  04 Aug 2015     1.1.1       1.  Updated for the new qdlamp
//
// End of QCOM-Archive.php
//============================================================================
?>
