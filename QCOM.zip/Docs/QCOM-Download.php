<?php
//============================================================================
// //qdlamp/var/www/qd.quartzdyne.com/QCOM/QCOM-Download.php
//
// Download page for QCOM and associated entities
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software.  Also,
// a detailed revision history of this file is included at the bottom of this
// source.
//============================================================================
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: -1');
    header('Pragma: no-cache');
    define('displayVersion', '1.1.8');
    define('updatedDate', '2015-09-10');
    define('sourceVersion', displayVersion . '.' . updatedDate);
    include('/var/www/qd.quartzdyne.com/script/server/MainDefs.php');
    //------------------------------------------------------------------------
    // QCOM-specific websites
    //------------------------------------------------------------------------
    define('MS_dot_NET_4', QD_PkgDir . 'dotNetFx40_Full_setup.exe');
    define('QCOM_PublicDir', QD_PublicDir . 'QCOM/');
    define('QCOM_PkgDir', QCOM_PublicDir . 'pkg/');
    define('QCOM_ArchiveDir', QCOM_PublicDir . 'archive/');
    define('QCOM_HelpSite', QCOM_PublicDir . 'QCOM-Help.php');
    define('QCOM_ArchiveSite', QCOM_PublicDir . 'QCOM-Archive.php');
    define('matlabSite', QCOM_PublicDir . 'QCOM-MATLAB.php');
    //------------------------------------------------------------------------
    // Packages
    //------------------------------------------------------------------------
    define('releaseVersion', '1.0.7');
    define('releaseDate', '06-13-2014');
    define('QCOM_Release', QCOM_PkgDir . 'QCOM-Setup-' . releaseVersion . '.exe');
    //------------------------------------------------------------------------
    define('betaVersion', '1.1.0');
    define('betaDate', '06-05-2013');
    define('QCOM_Beta', QCOM_PkgDir . 'QCOM-Beta-' . betaVersion . '.zip');
    //------------------------------------------------------------------------
    define('DLLVersion', '1.1.0');
    define('DLLDate', '02-25-2014');
    define('QCOM_DLL', QCOM_PkgDir . 'QCOM-DLL-' . DLLVersion . '.zip');
    //------------------------------------------------------------------------
    define('QCOM_DLL_Source', QCOM_PkgDir . 'QCOM-DLL-Source-' . DLLVersion . '.zip');
    //------------------------------------------------------------------------
    define('DLLSpecVersion', 'B4');
    define('DLLSpecDate', '10-03-2012');
    define('QCOM_DLL_Spec', QCOM_PkgDir . 'QCOM-DLL-Spec-' . DLLSpecVersion . '.pdf');
    //------------------------------------------------------------------------
    define('driverVersion', '3.3');
    define('QCOM_Drivers', QCOM_PkgDir . 'QCOM-Drivers-' . driverVersion . '.zip');
    //------------------------------------------------------------------------
    define('firmwareVersion', '1.2');
    define('QCOM_Firmware', QCOM_PkgDir . 'QCOM-Firmware-' . firmwareVersion . '.zip');
    //------------------------------------------------------------------------
    define('CLDemoVersion', '1.0.0');
    define('CLDemoDate', '02-15-2013');
    define('QCOM_CL', QCOM_PkgDir . 'QCOM-CL-Demo-' . CLDemoVersion . '.zip');
    //------------------------------------------------------------------------
    define('VCDemoVersion', '1.0.0');
    define('VCDemoDate', '06-17-2011');
    define('QCOM_VC', QCOM_PkgDir . 'QCOM-VC-Demo-' . VCDemoVersion . '.zip');
    //------------------------------------------------------------------------
    define('VBDemoVersion', '2.0.0');
    define('VBDemoDate', '04-24-2013');
    define('QCOM_VB', QCOM_PkgDir . 'QCOM-VB-Demo-' . VBDemoVersion . '.zip');
    //------------------------------------------------------------------------
    define('LVDemoVersion', '1.0.3');
    define('LVDemoDate', '11-21-2012');
    define('QCOM_LV', QCOM_PkgDir . 'QCOM-LV-Demo-' . LVDemoVersion . '.zip');
    //------------------------------------------------------------------------
    define('QCOM_Lite', QCOM_PkgDir . 'QCOM-Lite.zip');
    define('QCOM_Util', QCOM_PkgDir . 'QCOMUtil.zip');
    define('QCOM_MATLAB', QCOM_PkgDir . 'QCOM-MATLAB.zip');
    //------------------------------------------------------------------------
    // Support
    //------------------------------------------------------------------------
    define('emailSubject' , 'QCOM Download (Version ' . sourceVersion . ')');
    define('reportIssues',
        'Please communicate problems and suggestions to <a href="' . mailSite . '?emailSubject=' .
        emailSubject . '&dest=support" target="_blank">Quartzdyne Support</a>');
    //------------------------------------------------------------------------
    include('/script/server/compresshtml.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
    <head>
        <title>QCOM Download</title>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <meta name="description" content="This page displays the QCOM download site" />
        <meta name="keywords" content="quartzdyne, quartz, downhole, pressure, temperature, sensor, transducer, download, QCOM" />
        <meta name="distribution" content="global" />
        <meta name="author" content="Noji Ratzlaff" />
        <link href="/image/quartzdyne.ico" rel="shortcut icon" type="image/x-icon" />
        <link href="/style/qdprogstd.css" rel="stylesheet" type="text/css" />
        <link href="/style/reset1.css" rel="stylesheet" type="text/css" />
        <link href="/style/table1.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
            body
            {
                background-image: url('/image/white_sand.jpg');
                font: 100% verdana,sans-serif;
                margin-left: 16px;
                margin-right: 16px;
                margin-top: 8px;
            }
            @media print
            {
                table
                {
                    font-size: 140%;
                }
            }
        </style>
        <?  //----------------------------------------------------------------
            // Invoke the javascript page header functions
            //----------------------------------------------------------------
        ?>
        <script src="<?=clientScriptDir ?>PageHeader.js" language="javascript" type="text/javascript"></script>
        <script src="<?=clientScriptDir ?>ExpandCollapse.js" language="javascript" type="text/javascript"></script>
        <?  //----------------------------------------------------------------
            // Define local javascript functions
            //----------------------------------------------------------------
        ?>
        <script type="text/javascript">
<!--
//-->
        </script>
    </head>
    <body onselectstart="event.returnValue=false;">
        <div id="qd_div" lang="QD"></div>
        <?  //----------------------------------------------------------------
            // Display the company logo and a button to print the page
            //----------------------------------------------------------------
        ?>
        <div style="margin:auto; text-align:center; width:1000px;" id="MainHeader">
            <a href="<?=QD_HomeDir ?>" target="_blank" name="doc_top">
                <img src="/image/QDDoverLogo.png" style="float:left; width:150px; margin-bottom:10px;" alt="Quartzdyne" />
            </a>
            <div style="margin-left:20px; margin-bottom:10px; text-align:center; float:left;">
                <div style="color:black; font-weight:bold; font-size:160%;">
                    <span style="color:red; font-style:italic; font-weight:extra-bold; font-family:Arial,sans;">
                        <acronym title="Quartzdyne Communication Module">
                            QCOM
                        </acronym>
                    </span>
                    Download Center
                </div>
                <span style="font-size:120%; margin-top:5px;">
                    <?=date('D d M Y h:i:s a'); ?>
                </span>
                <span>
                    <form style="margin-top:10px;">
                        <input
                            type="button"
                            onClick="window.print()"
                            value=" Print This Page "
                            style="color:blue;" />
                    </form>
                </span>
            </div>
        </div>                          <? // end of MainHeader ?>
        <div style="clear:both;" id="MainBody">
            <a href="<?=QCOM_HelpSite ?>">Return</a> to the QCOM Help Center<br />
            <br />
            <?=reportIssues ?>
            <hr class="redLine" />
            <a href="<?=QCOM_Release ?>">
                <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
            </a> and install the <b>released</b>
            <a href="<?=QCOM_Release ?>">
                <img src="image/QCOM-Logo.png" style="height:40px; width:60px; vertical-align:middle;" alt="QCOM" />
            </a> software (version <?=releaseVersion?> on <?=releaseDate ?>)
            <div class="download_category" id="SWChangeHistory"
                onclick="expand_collapse('SWChangeHistoryBody')"
                ondblclick="expand_collapse('SWChangeHistoryBody')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                History of Changes Made to the released QCOM Software
            </div>
            <div class="invisible" id="SWChangeHistoryBody" lang="QD">
                <div class="download_topic"
                    onclick="expand_collapse('SW107ChangeHistory')"
                    ondblclick="expand_collapse('SW107ChangeHistory')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    Version 1.0.7
                </div>
                <div class="download_subtopic" id="SW107ChangeHistory" lang="QD">
                    <div>
                        <b>
                            <a href="archive/QCOM-1.0.7.4.zip">1.0.7.4</a> (06-13-2014) :
                        </b><br /><br />
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Fixed the problem with reporting the amperage
                            of many newer, low-current transducers, in
                            which the software would report 0.0 mA if the
                            actual value dropped below 2.0 mA. This fix
                            requires the cooperation of qdUSB.dll 1.1.0,
                            released on 02-25-2014.
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Changed the full-path server access from
                            \\qdfile1\share1 to Q:\
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Raised the maximum number of QCOM units
                            supported to 20.
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Added the Manage Multiple Coefficient Storage
                            interface to the Expert tab.
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Fixed the problem updating transducer
                            coefficients, which disabled the ability to
                            read the transducer following the update.
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Fixed the problem in which the sampling and
                            logging stopped upon encountering an error,
                            even if the Halt operations when errors occur
                            checkbox isn't checked.
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Added the transducer part number to the
                            graphing window.
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Changed the font style of the toolstrip words
                            to bold type.
                        </li>
                    </div>
                    <br />
                    <div>
                        <b>
                            <a href="archive/QCOM-1.0.7.3.zip">1.0.7.3</a> (09-03-2013) :
                        </b><br /><br />
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Added the graphing feature, available from a button in the
                            unit section of the Readout tab.
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Added the Download the Latest button to the main menu bar, to
                            download the absolute latest version of the QCOM software
                            without actually installing it.
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Fixed a problem in which starting and stopping sampling and
                            logging became confused, depending on the starting and stopping
                            order.
                        </li>
                    </div>
                    <br />
                    <div>
                        <b>
                            <a href="archive/QCOM-1.0.7.2.zip">1.0.7.2</a> (07-12-2013) :
                        </b><br /><br />
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Fixed a problem that prevents some models of transducers from
                            being recognized
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Added Get Number of Modules and Get DLL Version to the
                            Miscellaneous window
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Modified the serial number search to prefer coefficient data
                            file names that consist only of the serial number and extension
                        </li>
                    </div>
                    <br />
                    <div>
                        <b>
                            <a href="archive/QCOM-1.0.7.1.zip">1.0.7.1</a> (06-21-2013) :
                        </b><br /><br />
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Added the Sending status LED to the front panel, that displays
                            in Expert Mode
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Added the Start Logging All Events drop-down button
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Modified the installation package to include the signed version
                            of the driver
                        </li>
                    </div>
                    <br />
                    <div>
                        <b>
                            <a href="archive/QCOM-1.0.7.0.zip">1.0.7.0</a> (06-04-2013) :
                        </b><br /><br />
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Changed the unit section of each home tab to a set of tabs for all the units
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Changed the Program Info window to display a tab for each unit
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Added the Download Coefficient Files button to the Utilities tab
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Implemented a Halt Operations on Errors check box in the Expert tab
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Implemented a Save Logged Data Immediately check box in the Data Logging
                            windows
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Provided a way to delete log files that reside in the QLog folder
                        </li>
                        <li style="margin-left:40px; list-style-type:decimal;">
                            Changes the transducer output reference signal from 7.2 MHz to 1 kHz upon
                            startup
                        </li>
                    </div>
                </div>                  <? // end of SW107ChangeHistory subtopic ?>
                <div class="download_topic"
                    onclick="expand_collapse('SW106ChangeHistory')"
                    ondblclick="expand_collapse('SW106ChangeHistory')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    Version 1.0.6
                </div>
                <div class="download_subtopic" id="SW106ChangeHistory" lang="QD">
                    <li style="list-style-type:decimal;">
                        Implemented complete hot-plug addition / removal of QCOM modules
                        and transducers
                    </li>
                    <li style="list-style-type:decimal;">
                        Updated to work with Windows 8 and Windows Server 2012
                    </li>
                    <li style="list-style-type:decimal;">
                        Added buttons to the Readout tab, Test tab, and data logging windows
                        to pause the sampling, logging, and testing. The pause operation will
                        also occur when a modal message is displayed, preventing logging and
                        testing time from elapsing.
                    </li>
                    <li style="list-style-type:decimal;">
                        Displays hand pointers for all active check boxes, radio buttons, and
                        regular buttons
                    </li>
                    <li style="list-style-type:decimal;">
                        Added buttons in the Miscellaneous window to copy the raw contents
                        of the module to the transducer and the transducer to the module
                    </li>
                    <li style="list-style-type:decimal;">
                        The test fixture (Testing tab) now displays its results in color
                    </li>
                    <li style="list-style-type:decimal;">
                        Prompts to delete the log data if the amount of remaining disk space
                        on the target drive drops below 10 MB
                    </li>
                    <li style="list-style-type:decimal;">
                        Added an expert feature to direct the software to send periodic transducer
                        readings to a designated email address and/or text number
                    </li>
                    <li style="list-style-type:decimal;">
                        Added an entry under the Advanced menu item to display the last event
                        log, if one exists
                    </li>
                    <li style="list-style-type:decimal;">
                        Modified the appearance of the Display Coefficient Parameters function
                        to allow for the display of the parameters in all known coefficient files
                    </li>
                    <li style="list-style-type:decimal;">
                        Added the Transducer Chip ID box to the Miscellaneous tabs
                    </li>
                    <li style="list-style-type:decimal;">
                        Added code that attempts to determine whether a transducer communication
                        error is due to a possible missing ground connection between the QCOM module
                        and the transducer cable
                    </li>
                    <li style="list-style-type:decimal;">
                        The test fixture now tests up to the first 64 pages of both module and
                        digital transducer memory, instead of only the first four
                    </li>
                    <li style="list-style-type:decimal;">
                        The software will now load coefficient file data from module memory
                        if an attached transducer has no memory or if its memory contains no
                        coefficient data
                    </li>
                    <li style="list-style-type:decimal;">
                        The Verify Hex File Data function will offer the option to display the
                        converted hex file data if it determines that the information is
                        coefficient file data
                    </li>
                    <li style="list-style-type:decimal;">
                        Now prevents use of the text number or email address unless one of the
                        To: fields is populated
                    </li>
                </div>                  <? // end of SW106ChangeHistory subtopic ?>
                <div class="download_topic"
                    onclick="expand_collapse('SW105ChangeHistory')"
                    ondblclick="expand_collapse('SW105ChangeHistory')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    Version 1.0.5
                </div>
                <div class="download_subtopic" id="SW105ChangeHistory" lang="QD">
                    <li style="list-style-type:decimal;">
                        Moved the test fixture to its own tab, and adjusted the window and
                        group box sizes accordingly. Also highlights the test suite currently
                        running.
                    </li>
                    <li style="list-style-type:decimal;">
                        Added a button on the General Utilities tab to test a hex file for
                        validity. If the selected hex file has one or more invalid checksums,
                        the test can also correct them and save the corrected file with the
                        same or different name. Supports record types 0x00, 0x01, 0x02, 0x04,
                        and 0x05.
                    </li>
                    <li style="list-style-type:decimal;">
                        On startup, the software determines whether an update to the software,
                        DLL, or firmware is available online, and prompts for its download
                        and subsequent installation.
                    </li>
                    <li style="list-style-type:decimal;">
                        Added an event log, to record basic, verbose, or detailed actions
                        the tester uses to control the software.
                    </li>
                    <li style="list-style-type:decimal;">
                        Corrected a problem in which, if the software was started for the
                        first time without any Quartzdyne hardware attached, the software
                        incorrectly reported the driver missing.
                    </li>
                    <li style="list-style-type:decimal;">
                        If the data log contains any data, selecting or changing the name
                        of the data log file will save the data to the new file as well.
                        The same applies to the test log.
                    </li>
                    <li style="list-style-type:decimal;">
                        Added support for floating-point coefficients that are stored in hex
                        files that use the little-endian format.
                    </li>
                    <li style="list-style-type:decimal;">
                        Added support for hex coefficient files of version 1.00.
                    </li>
                    <li style="list-style-type:decimal;">
                        Adjusted GUI_DisplayTCCheck to display the transducer readings for
                        the coefficient data stored in the QCOM module if the attached
                        transducer has no memory.
                    </li>
                    <li style="list-style-type:decimal;">
                        Added a Reset Transducer button to the Unit Utilities tab.
                    </li>
                    <li style="list-style-type:decimal;">
                        Now accepts a variety of command-line parameters, to enable event
                        logging from the very start, for example. Enter QCOM.exe /? in the
                        command prompt to display a list of acceptable command-line parameters.
                    </li>
                    <li style="list-style-type:decimal;">
                        Can now save the data log in Microsoft Excel CSV (comma-separated
                        values) format.
                    </li>
                    <li style="list-style-type:decimal;">
                        Added a button on the General Utilities tab to convert a QCOM format
                        log data file into a .csv file. Added another to convert a .csv file
                        into a QCOM log data file.
                    </li>
                    <li style="list-style-type:decimal;">
                        Added a pulldown button in the toolstrip File menu to prevent saving
                        the config file upon program exit.
                    </li>
                    <li style="list-style-type:decimal;">
                        Added buttons in the Miscellaneous window to display the raw contents
                        of all four pages of the QCOM module memory and the attached transducer
                        memory.
                    </li>
                    <li style="list-style-type:decimal;">
                        Added the Program Info and Miscellaneous Controls buttons to the
                        Advanced tab.
                    </li>
                    <li style="list-style-type:decimal;">
                        Now offers the ability to display (and record) pressure and temperature
                        values in a variety of units.
                    </li>
                    <li style="list-style-type:decimal;">
                        Now able to specify the time between samples in seconds, minutes, and
                        hours, as well as milliseconds.
                    </li>
                    <li style="list-style-type:decimal;">
                        Now displays the Run for minutes control on the Log All data logging
                        window, as well as the Readout tab
                    </li>
                    <li style="list-style-type:decimal;">
                        Added a checkbox (in the Expert tab) to enable the display of stack
                        traces when the software encounters an error.
                    </li>
                    <li style="list-style-type:decimal;">
                        Added the ability (on the Expert tab) to send text messages when the
                        software encounters errors. Also added the ability to send email
                        messages when errors occur.
                    </li>
                </div>                  <? // end of SW105ChangeHistory subtopic ?>
            </div>                      <? // end of SWChangeHistoryBody ?>
<!--
            <a href="<?=QCOM_Beta ?>">
                <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
            </a> and install the latest <b>trial</b> (unreleased)
            <a href="<?=QCOM_Beta ?>">
                <img src="image/QCOM-Logo.png" style="height:40px; width:60px; vertical-align:middle;" alt="QCOM Beta" />
            </a> software
            (version <?=betaVersion?> on <?=betaDate ?>)
            <div class="download_category" id="BetaInstructions"
                onclick="expand_collapse('BetaInstructionsBody')"
                ondblclick="expand_collapse('BetaInstructionsBody')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                Trial version download and installation instructions
            </div>
            <div class="invisible" id="BetaInstructionsBody" lang="QD">
                <div style="font-weight:bold; font-size:80%; margin-left:60px;">
                    Note: These instructions assume that the released version of the QCOM software has
                    already been installed on the target computer. If it has not, please install the
                    <a href="<?=QCOM_Release ?>">released version</a> of the software first.
                </div>
                <div class="topictext" lang="QD">
                    <li style="list-style-type:decimal;">
                        Exit the QCOM software if it is currently running
                    </li>
                    <li style="list-style-type:decimal;">
                        <a href="<?=QCOM_Beta ?>">Download</a> the .ZIP file, and extract the contents
                        (four files) to the executable folder (<code>C:\Program Files\Quartzdyne\QCOM</code>
                        for 32-bit environments or <code>C:\Program Files (x86)\Quartzdyne\QCOM</code>
                        for 64-bit environments)
                    </li>
                    <li style="list-style-type:decimal;">
                        Delete all <code>(executable folder)\QLog\*.config</code> files if any
                    </li>
                    <li style="list-style-type:decimal;">
                        Proceed to run the QCOM software like usual
                    </li>
                </div>
            </div>                      <? // end of BetaInstructionsBody ?>
            <div class="download_category" id="BetaChangeHistory"
                onclick="expand_collapse('BetaChangeHistoryBody')"
                ondblclick="expand_collapse('BetaChangeHistoryBody')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                History of Changes Made to the Trial Software
            </div>
            <div class="invisible" id="BetaChangeHistoryBody" lang="QD">
                <div class="topictext" lang="QD">
                    <li style="list-style-type:decimal;">
                        Implements a button to allow the download of coefficient data files from
                        the web, if connected to the internet
                    </li>
                    <li style="list-style-type:decimal;">
                        Implements a check box on the Expert tab to halt all sampling, logging,
                        and testing operations if errors are encountered
                    </li>
                    <li style="list-style-type:decimal;">
                        Implements a check box on the Data Logging windows to save logged data
                        immediately instead of waiting until the buffer is full
                    </li>
                </div>
            </div>                      <? // end of BetaChangeHistoryBody ?>
-->
            <div class="download_category" id="FutureChangeHistory"
                onclick="expand_collapse('FutureChangeHistoryBody')"
                ondblclick="expand_collapse('FutureChangeHistoryBody')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                Proposed Changes to the released QCOM Software
            </div>
            <div class="invisible" id="FutureChangeHistoryBody" lang="QD">
                <div class="download_topic"
                    onclick="expand_collapse('FutureVersionChangeHistory')"
                    ondblclick="expand_collapse('FutureVersionChangeHistory')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    Version 1.1.0
                </div>
                <div class="download_subtopic" id="FutureVersionChangeHistory" lang="QD">
                    <li style="list-style-type:decimal;">
                        Version 1.0.7 has been published as a prototype of version 1.1.0
                    </li>
                    <li style="list-style-type:decimal;">
                        Problems associated with (primarily firmware) testing multiple transducers
                        will be solved
                    </li>
                    <li style="list-style-type:decimal;">
                        The software will prevent its client from going into hibernation
                    </li>
                </div>
            </div>                      <? // end of FutureChangeHistoryBody ?>
            <a href="<?=QCOM_Lite ?>">
                <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
            </a> the released version of <b>QCOM Lite</b>, the reduced-overhead version of
            <a href="<?=QCOM_Lite ?>">
                <img src="image/QCOM-Logo.png" style="height:40px; width:60px; vertical-align:middle;" alt="QCOM" />
            </a> software.
            <div class="download_category" id="QCOMLiteInstructions"
                onclick="expand_collapse('QCOMLiteInstructionsBody')"
                ondblclick="expand_collapse('QCOMLiteInstructionsBody')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                QCOM Lite download and installation instructions
            </div>
            <div class="invisible" id="QCOMLiteInstructionsBody" lang="QD">
                <div style="font-weight:bold; font-size:80%; margin-left:60px;">
                    <i>QCOM Lite is a reduced-overhead (and therefore reduced-functionality) version of the
                    QCOM software. It will sample the transducers at a rate of your choice and display
                    their readings, but will not log those readings or save them to a file.</i>
                </div>
                <br />
                <div style="font-weight:bold; font-size:80%; margin-left:60px;">
                    Note: If the released version of the QCOM software has not yet been installed
                    on the target computer, please <a href="<?=QCOM_Release ?>">install</a> it first.
                </div>
                <div class="topictext" lang="QD">
                    <li style="list-style-type:decimal;">
                        Exit the QCOM software if it is currently running. QCOM Lite and the QCOM software
                        cannot run simultaneously on the same computer.
                    </li>
                    <li style="list-style-type:decimal;">
                        <a href="<?=QCOM_Util ?>">Download</a> the package and extract the contents to
                        a folder of your choice.
                    </li>
                    <li style="list-style-type:decimal;">
                        Right-click the executable file and drag it to your desktop, then save it
                        as a shortcut by selecting Create shortcuts here.
                    </li>
                    <li style="list-style-type:decimal;">
                        Install a QCOM module and Quartzdyne transducer on the computer.
                    </li>
                    <li style="list-style-type:decimal;">
                        Double-click the shortcut icon as usual to run the program.
                    </li>
                </div>
            </div>                      <? // end of QCOMLiteInstructionsBody ?>
            <a href="<?=QCOM_Util ?>">
                <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
            </a> the released version of <b>QCOMUtil</b>, the command-line (Command Prompt) version of
            <a href="<?=QCOM_Util ?>">
                <img src="image/QCOM-Logo.png" style="height:40px; width:60px; vertical-align:middle;" alt="QCOM" />
            </a> software
            <div class="download_category" id="QCOMUtilInstructions"
                onclick="expand_collapse('QCOMUtilInstructionsBody')"
                ondblclick="expand_collapse('QCOMUtilInstructionsBody')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                QCOMUtil download and installation instructions
            </div>
            <div class="invisible" id="QCOMUtilInstructionsBody" lang="QD">
                <div style="font-weight:bold; font-size:80%; margin-left:60px;">
                    Note: If the released version of the QCOM software has not yet been installed
                    on the target computer, please <a href="<?=QCOM_Release ?>">install</a> it first.
                </div>
                <div class="topictext" lang="QD">
                    <li style="list-style-type:decimal;">
                        Exit the QCOM software if it is currently running. QCOMUtil and the QCOM software
                        cannot run simultaneously on the same computer.
                    </li>
                    <li style="list-style-type:decimal;">
                        <a href="<?=QCOM_Util ?>">Download</a> the package and extract the appropriate
                        three files (32-bit or 64-bit) to the <code>C:\Windows\System32</code> folder.
                    </li>
                    <li style="list-style-type:decimal;">
                        Install a QCOM module and Quartzdyne transducer on the computer.
                    </li>
                    <li style="list-style-type:decimal;">
                        Open a Windows Command Prompt
                    </li>
                    <li style="list-style-type:decimal;">
                        Enter <code>qcomutil ?</code> at the command prompt to display the program syntax.
                    </li>
                </div>
            </div>                      <? // end of QCOMUtilInstructionsBody ?>
            <a href="<?=QCOM_MATLAB ?>">
                <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
            </a> the
            <a href="<?=QCOM_MATLAB ?>">
                <img src="image/QCOM-Logo.png" style="height:40px; width:60px; vertical-align:middle;" alt="QCOM" />
            </a> Package for MathWorks<sup>&reg;</sup> MATLAB<sup>&trade;</sup>
            <div class="download_category" id="QCOM_MATLABInstructions"
                onclick="expand_collapse('QCOM_MATLABInstructionsBody')"
                ondblclick="expand_collapse('QCOM_MATLABInstructionsBody')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                QCOM Package for MATLAB download and installation instructions
            </div>
            <div class="invisible" id="QCOM_MATLABInstructionsBody" lang="QD">
                <div style="font-weight:bold; font-size:80%; margin-left:60px;">
                    Note: If the released version of the QCOM software has not yet been installed
                    on the target computer, please <a href="<?=QCOM_Release ?>">install</a> it first.
                </div>
                <div class="topictext" lang="QD">
                    <li style="list-style-type:decimal;">
                        Exit the QCOM software if it is currently running. <i>The QCOM Package for
                        MATLAB and the QCOM software cannot run simultaneously on the same computer.</i>
                    </li>
                    <li style="list-style-type:decimal;">
                        <a href="<?=QCOM_MATLAB ?>">Download</a> the package and extract the contents
                        (nine files) to a working directory where you can access these files from MATLAB.
                    </li>
                    <li style="list-style-type:decimal;">
                        Install a QCOM module and Quartzdyne transducer on the computer (instructions
                        can be found on the <a href="<?=QCOM_HelpSite ?>" target="_blank">help</a> page).
                    </li>
                    <li style="list-style-type:decimal;">
                        Start MATLAB.
                    </li>
                    <li style="list-style-type:decimal;">
                        Follow the instructions on the <a href="<?=matlabSite ?>" target="_blank">QCOM
                        Package for MATLAB</a> web page to call DLL functions from within MATLAB.
                    </li>
                </div>
            </div>                      <? // end of QCOM_MATLABInstructionsBody ?>
            <a href="<?=QCOM_DLL ?>">
                <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
            </a> and install the released
            <a href="<?=QCOM_DLL ?>">
                <img src="image/QCOM-Logo.png" style="height:40px; width:60px; vertical-align:middle;" alt="QCOM" />
            </a> DLL package
            (version <?=DLLVersion?> on <?=DLLDate ?>)
            <div class="download_category" id="DLLChangeHistory"
                onclick="expand_collapse('DLLChangeHistoryBody')"
                ondblclick="expand_collapse('DLLChangeHistoryBody')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                History of Changes Made to the QCOM DLL
            </div>
            <div class="invisible" id="DLLChangeHistoryBody" lang="QD">
                <div class="download_topic"
                    onclick="expand_collapse('DLL110ChangeHistoryBody')"
                    ondblclick="expand_collapse('DLL110ChangeHistoryBody')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    Version 1.1.0
                </div>
                <div class="download_subtopic" id="DLL110ChangeHistoryBody" lang="QD">
                    <li style="list-style-type:decimal;">
                        Changed the minimum acceptable transducer current draw from
                        2.5 mA to 0.5 mA, to accommodate newer, low-current
                        transducers.
                    </li>
                    <li style="list-style-type:decimal;">
                        QD_GetTransducerCurrent and QD_GetTransducerVoltage now
                        return the resulting current and voltage values,
                        respectively, even if the values are outside the minimum
                        or maximum set for them, but will return appropriate
                        error and locus codes.
                    </li>
                    <li style="list-style-type:decimal;">
                        Changed the length of time for all functions that call
                        Sleep(100) after encountering an error status, except
                        QD_Open, from 100 ms to 10 ms.
                    </li>
                    <a href="<?=QCOM_DLL_Source ?>" style="font-size:60%;">Source Code for DLL version <?=DLLVersion ?></a>
                </div>                  <? // end of DLL108ChangeHistoryBody subtopic ?>
                <div class="download_topic"
                    onclick="expand_collapse('DLL108ChangeHistoryBody')"
                    ondblclick="expand_collapse('DLL108ChangeHistoryBody')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    Version 1.0.8
                </div>
                <div class="download_subtopic" id="DLL108ChangeHistoryBody" lang="QD">
                    <li style="list-style-type:decimal;">
                        Forced the functions that require byte-value inputs to check
                        the values to ensure they are within specified limits
                    </li>
                    <li style="list-style-type:decimal;">
                        Corrected a bug in QD_WriteCoefficientDataToHexFile, in which
                        the function would fail if the target file did not already
                        exist.
                    </li>
                    <li style="list-style-type:decimal;">
                        Changed the input buffer of QD_ReadCoefficientDataFromSourcePage
                        from being dynamically allocated to a stack, automatic array, to
                        improve the read speed.
                    </li>
                    <li style="list-style-type:decimal;">
                        QD_ReadCoefficientDataFromSourcePage no longer clears the input
                        coefficient data buffer upon encountering an error.
                    </li>
                    <a href="<?=QCOM_ArchiveDir ?>QCOM-DLL-Source-1.0.8.zip" style="font-size:60%;">Source Code for DLL version 1.0.8</a>
                    <br />
                    <a href="<?=QCOM_PkgDir ?>qdUSB-64-1.0.8.zip" style="font-size:60%;">64-bit version of DLL version 1.0.8</a>
                </div>                  <? // end of DLL108ChangeHistoryBody subtopic ?>
                <div class="download_topic"
                    onclick="expand_collapse('DLL107ChangeHistoryBody')"
                    ondblclick="expand_collapse('DLL107ChangeHistoryBody')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    Version 1.0.7
                </div>
                <div class="download_subtopic" id="DLL107ChangeHistoryBody" lang="QD">
                    <li style="list-style-type:decimal;">
                        Added a test in QD_ReadCoefficientDataFromHexFile for the correct
                        hex file size
                    </li>
                    <li style="list-style-type:decimal;">
                        Added a test for coefficient data validity in
                        QD_ReadCoefficientDataFromSourcePage
                    </li>
                    <li style="list-style-type:decimal;">
                        Added a test for coefficient data validity in
                        QD_CoefficientHexFileDataIsValid, which eliminates a locus in
                        QD_ReadCoefficientDataFromHexFile
                    </li>
                    <li style="list-style-type:decimal;">
                        Corrected the status value in QD_CalculatePressureOrTemperature for
                        invalid coefficient data from 0x2B to 0x40
                    </li>
                    <li style="list-style-type:decimal;">
                        Determines whether the coefficient data passed to
                        QD_CalculatePressureOrTemperature is valid by verifying that
                        the first byte is the Quartzdyne ID
                    </li>
                    <li style="list-style-type:decimal;">
                        Changed the maximum number of memory pages to 64, and set the maximum
                        number of lower memory pages to 4
                    </li>
                </div>                  <? // end of DLL107ChangeHistoryBody subtopic ?>
                <div class="download_topic"
                    onclick="expand_collapse('DLL106ChangeHistoryBody')"
                    ondblclick="expand_collapse('DLL106ChangeHistoryBody')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    Version 1.0.6
                </div>
                <div class="download_subtopic" id="DLL106ChangeHistoryBody" lang="QD">
                    <li style="list-style-type:decimal;">
                        The Firmware functions are no longer declared with the <code>HANDLE &unitHandle</code>
                        syntax, fostering greater compatibility with older compilers
                    </li>
                    <li style="list-style-type:decimal;">
                        Added more loci to some of the functions
                    </li>
                    <li style="list-style-type:decimal;">
                        Changed bool QD_DLLErrorEncountered to DWORD QD_DLLStatus
                    </li>
                    <li style="list-style-type:decimal;">
                        Changed the following functions, to more accurately reflect the
                        fact that they address operations with only the module rather than
                        the entire unit:
                        <table>
                            <th>
                                Old Function
                            </th>
                            <th>
                                New Function
                            </th>
                            <tr>
                                <td>QD_GetNumberOfUnits</td><td>QD_GetNumberOfModules</td>
                            </tr>
                            <tr>
                                <td>QD_GetUnitControlRegister</td><td>QD_GetModuleControlRegister</td>
                            </tr>
                            <tr>
                                <td>QD_GetUnitSerialNumber</td><td>QD_GetModuleSerialNumber</td>
                            </tr>
                            <tr>
                                <td>QD_GetUnitFirmwareID</td><td>QD_GetModuleFirmwareID</td>
                            </tr>
                            <tr>
                                <td>QD_GetUnitStatusRegister</td><td>QD_GetModuleStatusRegister</td>
                            </tr>
                            <tr>
                                <td>QD_GetUnitModeSwitchSetting</td><td>QD_GetModuleModeSwitchSetting</td>
                            </tr>
                            <tr>
                                <td>QD_ReadCoefficientDataFromUnitPage</td><td>QD_ReadCoefficientDataFromModulePage</td>
                            </tr>
                            <tr>
                                <td>QD_ResetUnit</td><td>QD_ResetModule</td>
                            </tr>
                            <tr>
                                <td>QD_SetUnitControlRegister</td><td>QD_SetModuleControlRegister</td>
                            </tr>
                            <tr>
                                <td>QD_WriteCoefficientDataToUnitPage</td><td>QD_WriteCoefficientDataToModulePage</td>
                            </tr>
                        </table>
                        Deprecated the old functions to provide an interface for those
                        programs that depend on them, and reflected the names of the new
                        functions in D11813 B4 (the DLL Specification version B4)
                    </li>
                    <li style="list-style-type:decimal;">
                        Changed the third byte (0x00FF0000) of the status DWORD returned by<br />
                        <p style="margin-left:20px;">
                            QD_ReadCoefficientDataFromDevice<br />
                            QD_ReadCoefficientDataFromModulePage<br />
                            QD_ReadCoefficientDataFromSourcePage<br />
                            QD_WriteCoefficientDataToDevice<br />
                            QD_WriteCoefficientDataToModulePage<br />
                            QD_WriteCoefficientDataToTargetPage<br />
                        </p>
                        to reflect a bitmap of the target device and the page number when an
                        error is encountered. The upper two bits (0xC0) represent the device
                        (00b = transducer, 01b = module) and the lower six bits (0x3F) represent
                        the page number.
                    </li>
                    <li style="list-style-type:decimal;">
                        QD_WriteCoefficientDataToHexFile no longer clears the coefficient
                        data buffer upon encountering an error
                    </li>
                </div>                  <? // end of DLL106ChangeHistoryBody subtopic ?>
            </div>                      <? // end of DLLChangeHistoryBody ?>
            <a href="<?=QCOM_DLL_Spec ?>" target="_blank">
                <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
            </a> the latest <b>QCOM DLL</b> specification (version <?=DLLSpecVersion?> on <?=DLLSpecDate ?>)
            <br />
            <a href="<?=QCOM_Drivers ?>">
                <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
            </a> the latest <b>QCOM Drivers</b> (version <?=driverVersion ?>)
            <br />
            <a href="<?=QCOM_Firmware ?>">
                <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
            </a> the latest <b>QCOM Firmware</b> (version <?=firmwareVersion ?>)
            <br />
            <a href="<?=MS_dot_NET_4 ?>">
                <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
            </a> and install the Microsoft<sup>&reg;</sup> .NET Framework<sup>&copy;</sup> 4
            package
            <br />
            <hr style="height:10px;" />
            <b>The following packages are reduced-functionality versions of the QCOM software
            that demonstrate how to use the QCOM DLL, and include the full source code for each:</b>
            <br />
            <div class="download_category" id="QCOM_CL_Demo"
                onclick="expand_collapse('QCOM_CL_Topics')"
                ondblclick="expand_collapse('QCOM_CL_Topics')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                C Language Demo (version <?=CLDemoVersion?> on <?=CLDemoDate ?>)
            </div>
            <div class="invisible" id="QCOM_CL_Topics" lang="QD">
                <div class="download_topic"
                    onclick="expand_collapse('QCOM_CL_Download')"
                    ondblclick="expand_collapse('QCOM_CL_Download')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    <a href="<?=QCOM_CL ?>">
                        <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
                    </a> the C Language demo
                </div>
                <div class="download_subtopic" id="QCOM_CL_Download" lang="QD">
                    <li>
                        Text on how to download the C Language demo
                    </li>
                </div>
                <div class="download_topic"
                    onclick="expand_collapse('QCOM_CL_Usage')"
                    ondblclick="expand_collapse('QCOM_CL_Usage')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    How to use the C Language demo
                </div>
                <div class="download_subtopic" id="QCOM_CL_Usage" lang="QD">
                    <li>
                        Text on how to use the C Language demo
                    </li>
                </div>
            </div>                      <? // end of QCOM_CL_Topics ?>
            <div class="download_category" id="QCOM_VC_Demo"
                onclick="expand_collapse('QCOM_VC_Topics')"
                ondblclick="expand_collapse('QCOM_VC_Topics')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                Visual C++ (.NET) Demo (version <?=VCDemoVersion?> on <?=VCDemoDate ?>)
            </div>
            <div class="invisible" id="QCOM_VC_Topics" lang="QD">
                <div class="download_topic"
                    onclick="expand_collapse('QCOM_VC_Download')"
                    ondblclick="expand_collapse('QCOM_VC_Download')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    <a href="<?=QCOM_VC ?>">
                        <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
                    </a> the Visual C++ (.NET) demo
                </div>
                <div class="download_subtopic" id="QCOM_VC_Download" lang="QD">
                    <li style="list-style-type:decimal;">
                        Save the <code>.zip</code> file to a folder of your choosing
                    </li>
                    <li style="list-style-type:decimal;">
                        Unzip the file to extract the contents to a folder of your choosing
                    </li>
                </div>
                <div class="download_topic"
                    onclick="expand_collapse('QCOM_VC_Usage')"
                    ondblclick="expand_collapse('QCOM_VC_Usage')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    How to use the Visual C++ demo
                </div>
                <div class="download_subtopic" id="QCOM_VC_Usage" lang="QD">
                    <b style="margin-left:-20px;">Running the stand-alone application</b>
                    <br /><br />
                    <li style="list-style-type:decimal;">
                        The demo <code>.zip</code> file includes the executable (<code>QCOM.exe</code>)
                        file, the two DLL files (<code>qdUSB.dll</code> and <code>SiUSBXp.dll</code>),
                        and the support files you need to run the application stand-alone.
                    </li>
                    <li style="list-style-type:decimal;">
                        Copy the contents of the <code>Debug</code> folder to a folder of your choice.
                    </li>
                    <li style="list-style-type:decimal;">
                        Right-click the executable file and drag it to your desktop, then save it
                        as a shortcut by selecting Create shortcuts here.
                    </li>
                    <li style="list-style-type:decimal;">
                        Install a QCOM module and Quartzdyne transducer on the computer.
                    </li>
                    <li style="list-style-type:decimal;">
                        Double-click the shortcut icon as usual to run the program.
                    </li>
                    <br />
                    <b style="margin-left:-20px;">Loading the project and building the source</b>
                    <br /><br />
                    <b style="margin-left:-20px;">
                        <i>
                            Note: It is assumed that you already have Microsoft Visual C++ installed
                            on your client to build this demo source code.
                        </i>
                    </b>
                    <br /><br />
                    <span style="margin-left:-20px;">Note: The original source code was developed with Visual C++ 2010 Express.</span>
                    <br /><br />
                    <li style="list-style-type:disk;">
                        Double-click on <code>QCOM.sln</code> to invoke the Microsoft Visual C++ 2010
                        Express IDE, assuming you have a licensed version of Visual C++ 2010 Express or
                        later installed on your workstation.
                    </li>
                    <li style="list-style-type:disk;">
                        Select Build > Build QCOM to create the executable application in the Debug
                        folder.
                    </li>
                </div>
            </div>                      <? // end of QCOM_VC_Topics ?>
            <div class="download_category" id="QCOM_VB_Demo"
                onclick="expand_collapse('QCOM_VB_Topics')"
                ondblclick="expand_collapse('QCOM_VB_Topics')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                Visual Basic Demo (version <?=VBDemoVersion?> on <?=VBDemoDate ?>)
            </div>
            <div class="invisible" id="QCOM_VB_Topics" lang="QD">
                <div class="download_topic"
                    onclick="expand_collapse('QCOM_VB_Download')"
                    ondblclick="expand_collapse('QCOM_VB_Download')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    <a href="<?=QCOM_VB ?>">
                        <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
                    </a> the Visual Basic demo
                </div>
                <div class="download_subtopic" id="QCOM_VB_Download" lang="QD">
                    <li style="list-style-type:decimal;">
                        Save the <code>.zip</code> file to a folder of your choosing
                    </li>
                    <li style="list-style-type:decimal;">
                        Unzip the file to extract the contents to a folder of your choosing
                    </li>
                </div>
                <div class="download_topic"
                    onclick="expand_collapse('QCOM_VB_Usage')"
                    ondblclick="expand_collapse('QCOM_VB_Usage')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    How to use the Visual Basic demo
                </div>
                <div class="download_subtopic" id="QCOM_VB_Usage" lang="QD">
                    <b style="margin-left:-20px;">Running the stand-alone application</b>
                    <br /><br />
                    <li style="list-style-type:decimal;">
                        The demo <code>.zip</code> file includes the executable (<code>QCOM.exe</code>)
                        file, the two DLL files (<code>qdUSB.dll</code> and <code>SiUSBXp.dll</code>),
                        and the support files you need to run the application stand-alone.
                    </li>
                    <li style="list-style-type:decimal;">
                        Copy the contents of the <code>Debug</code> folder to a folder of your choice.
                    </li>
                    <li style="list-style-type:decimal;">
                        Right-click the executable file and drag it to your desktop, then save it
                        as a shortcut by selecting Create shortcuts here.
                    </li>
                    <li style="list-style-type:decimal;">
                        Install a QCOM module and Quartzdyne transducer on the computer.
                    </li>
                    <li style="list-style-type:decimal;">
                        Double-click the shortcut icon as usual to run the program.
                    </li>
                    <br />
                    <b style="margin-left:-20px;">Loading the project and building the source</b>
                    <br /><br />
                    <b style="margin-left:-20px;">
                        <i>
                            Note: It is assumed that you already have Microsoft Visual Basic installed
                            on your client to build this demo source code.
                        </i>
                    </b>
                    <br /><br />
                    <span style="margin-left:-20px;">Note: The original source code was developed with Visual Basic 2010 Express.</span>
                    <br /><br />
                    <li style="list-style-type:disc;">
                        Double-click on <code>QCOM.sln</code> to invoke the Microsoft Visual Basic 2010
                        Express IDE, assuming you have a licensed version of Visual Basic 2010 Express or
                        later installed on your workstation.
                    </li>
                    <li style="list-style-type:disc;">
                        Select Build > Build QCOM to create the executable application in the Debug
                        folder.
                    </li>
                </div>
            </div>                      <? // end of QCOM_VB_Topics ?>
            <div class="download_category" id="QCOM_LV_Demo"
                onclick="expand_collapse('QCOM_LV_Topics')"
                ondblclick="expand_collapse('QCOM_LV_Topics')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                LabVIEW Demo (version <?=LVDemoVersion?> on <?=LVDemoDate ?>)
            </div>
            <div class="invisible" id="QCOM_LV_Topics" lang="QD">
                <div class="download_topic"
                    onclick="expand_collapse('QCOM_LV_Download')"
                    ondblclick="expand_collapse('QCOM_LV_Download')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    <a href="<?=QCOM_LV ?>">
                        <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
                    </a> the LabVIEW demo
                </div>
                <div class="download_subtopic" id="QCOM_LV_Download" lang="QD">
                    <li>
                        Save the <code>.zip</code> file to a folder of your choosing.
                    </li>
                    <li>
                        Unzip the file to extract the contents to a folder of your choosing.
                    </li>
                </div>
                <div class="download_topic"
                    onclick="expand_collapse('QCOM_LV_Usage')"
                    ondblclick="expand_collapse('QCOM_LV_Usage')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    How to use the LabVIEW demo
                </div>
                <div class="download_subtopic" id="QCOM_LV_Usage" lang="QD">
                    <b style="margin-left:-20px;">Running the stand-alone application</b>
                    <br /><br />
                    <b style="margin-left:-20px;">
                        <i>
                            Note: If you do not have the National Instruments<sup>&reg;</sup> Measurement & Automation
                            Explorer&trade; or LabVIEW development environment already installed on your workstation,
                            you might need to download and install the
                            <a href="http://ftp.ni.com/support/softlib/labview/labview_runtime/2011/Windows/LVRTE2011f3std.exe">LabVIEW Run Time Engine</a> to
                            run this demo.
                        </i>
                    </b>
                    <br /><br />
                    <li style="list-style-type:decimal;">
                        The demo <code>.zip</code> file includes the executable (<code>QCOM.exe</code>) and the
                        two DLL files (<code>qdUSB.dll</code> and <code>SiUSBXp.dll</code>) you need
                        to run the application stand-alone.
                    </li>
                    <li style="list-style-type:decimal;">
                        Copy the two DLL files to the same folder on your workstation. Create a
                        sub-folder of that folder and copy the executable file to the newly
                        created sub-folder.
                    </li>
                    <li style="list-style-type:decimal;">
                        Right-click the executable file and drag it to your desktop, then save it
                        as a shortcut by selecting Create shortcuts here.
                    </li>
                    <li style="list-style-type:decimal;">
                        Install a QCOM module and Quartzdyne transducer on the computer.
                    </li>
                    <li style="list-style-type:decimal;">
                        Double-click the shortcut icon as usual to run the program.
                    </li>
                    <br />
                    <b style="margin-left:-20px;">Loading the project and building the source</b>
                    <br /><br />
                    <span style="margin-left:-20px;">Note: The original source code was developed with LabVIEW 2011</span>
                    <br /><br />
                    <li style="list-style-type:disc;">
                        Double-click on <code>QCOM Demo.lvproj</code> to invoke the LabVIEW
                        Explorer, assuming you have a licensed version of LabVIEW 2011 installed on
                        your workstation.
                    </li>
                    <li style="list-style-type:disc;">
                        In the Items view click the plus (+) sign before Build Specifications,
                        right-click QCOM, and click Build to build a stand-alone executable
                        file called <code>QCOM.exe</code> in the <code>Using qdUSB_dll</code>
                        folder.
                    </li>
                </div>                  <? // end of QCOM_LV_Usage subtopic ?>
            </div>                      <? // end of QCOM_LV_Topics ?>
            <b>Visit the <a href="<?=QCOM_ArchiveSite ?>">archives</a> to download older versions of QCOM-related software</b>
            <br />
        </div>                          <? // end of MainBody ?>
        <hr class="redLine" />
        <div class="page_bottom" id="MainFooter">
            <i class="flush_left">Copyright &copy; <?=date('Y'); ?> <a href="<?=QD_HomeDir ?>" target="_blank">Quartzdyne, Inc.</a>, a <a href="<?=DoverDir ?>" target="_blank">Dover</a><sup>&reg;</sup> company</i>
            <span class="flush_right" style="font-size:80%;">(Version <?=sourceVersion ?> [<script type="text/javascript">document.write(browserFlag);</script>])</span>
        </div>                          <? // end of MainFooter ?>
    </body>
</html>
<?php
//============================================================================
// QCOM-Download.php Revision History (defined as sourceVersion in this source)
//
//  18 Apr 2011     1.0.0       1.  Initial public release
//
//  29 Apr 2011     1.0.1       1.  Posted revised DLL and apps to accommodate
//                                  digital transducers that contain no memory
//                              2.  Added a link for archived versions of the
//                                  software
//
//  20 May 2011     1.0.2       1.  Added a link for QCOM archives
//                              2.  Added a History of Changes Made list for
//                                  each version of each downloadable item
//
//  19 Aug 2011     1.0.3       1.  Added support for Chrome, Safari, and Opera
//
//  28 Nov 2011     1.0.4       1.  Added Microsoft .NET Framework 4.0 to the
//                                  list of packages to download
//
//  20 Mar 2012     1.0.5       1.  Updated QCOM package 1.0.5 with numerous
//                                  enhancements and bug fixes
//
//  17 Aug 2012     1.0.6       1.  Updated QCOM package 1.0.6 with numerous
//                                  enhancements and bug fixes
//
//  03 Oct 2012     1.0.7       1.  Updated qdUSB.dll to 1.0.6 and its spec
//                                  D11813 to B4.
//                              2.  Updated QCOM package 1.0.6 to accommodate
//                                  the DLL changes
//
//  07 Dec 2012     1.0.8       1.  Updated the LabVIEW Demo link to 1.0.3
//                              2.  Added LabVIEW 2011 Run Time Engine to the
//                                  list of packages to download
//                              3.  Updated QCOM package 1.0.6 with numerous
//                                  enhancements and fixes
//                              4.  Updated qdUSB.dll to 1.0.7
//
//  18 Mar 2013     1.0.9       1.  Added QCOMUtil to the download list
//                              2.  Added the MATLAB package for QCOM
//                              3.  Added a download graphic for each download
//                                  link
//                              4.  Changed the character set to UTF-8
//                              5.  Removed the no-cache pragma meta
//                              6.  Added the global distribution meta
//                              7.  Made redundant tags reference classes
//                              8.  Began using qdprogstd.css
//                              9.  Posted QCOM software Beta 1.0.7
//
//  24 Apr 2013     1.1.0       1.  Posted QCOM demo in VB 2.0.0
//                              2.  Posted QCOM Lite for the first time
//
//  05 Jun 2013     1.1.1       1.  Updated qdUSB.dll to 1.0.8
//                              2.  Updated the QCOM software to 1.0.7
//
//  28 Jun 2013     1.1.2       1.  Added a tiny link to download the
//                                  qdUSB.dll source code
//                              2.  Created separate sections for links and
//                                  change histories of the QCOM software
//                              3.  Added the 64-bit version of QCOMUtil
//
//  12 Jul 2013     1.1.3       1.  Added QCOM software 1.0.7.2
//
//  03 Sep 2013     1.1.4       1.  Added QCOM software 1.0.7.3
//
//  06 Dec 2013     1.1.5       1.  Began using MainDefs.php
//                              2.  Moved the browser detection scripts to
//                                  PageHeader.js
//
//  13 Jun 2014     1.1.6       1.  Added QCOM software 1.0.7.4
//
//  25 Jun 2014     1.1.7       1.  Added the 64-bit version of qdUSB.dll
//                                  version 1.0.8
//
//  04 Aug 2015     1.1.8       1.  Updated for the new qdlamp
//
// End of QCOM-Download.php
//============================================================================
?>
