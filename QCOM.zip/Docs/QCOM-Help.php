<?php
//============================================================================
// //qdlamp/var/www/qd.quartzdyne.com/QCOM/QCOM-Help.php
//
// General online help for QCOM
//
// Copyright (C) 2011 - 2015 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software.  Also,
// a detailed revision history of this file is included at the bottom of this
// source.
//============================================================================
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: -1');
    header('Pragma: no-cache');
    define('displayVersion', '1.0.9');
    define('updatedDate', '2015-09-10');
    define('sourceVersion', displayVersion . '.' . updatedDate);
    include('/var/www/qd.quartzdyne.com/script/server/MainDefs.php');
    //------------------------------------------------------------------------
    // QCOM-specific websites
    //------------------------------------------------------------------------
    define('MS_dot_NET_4', QD_PkgDir . 'dotNetFx40_Full_setup.exe');
    define('QCOM_PublicDir', QD_PublicDir . 'QCOM/');
    define('QCOM_PkgDir', QCOM_PublicDir . 'pkg/');
    define('QCOM_HelpSite', QCOM_PublicDir . 'QCOM-Help.php');
    define('QCOM_ArchiveSite', QCOM_PublicDir . 'QCOM-Archive.php');
    define('QCOM_DownloadSite', QCOM_PublicDir . 'QCOM-Download.php');
    define('matlabSite', QCOM_PublicDir . 'QCOM-MATLAB.php');
    //------------------------------------------------------------------------
    // Packages
    //------------------------------------------------------------------------
    define('driverVersion', '3.3');
    define('QCOM_Drivers', QCOM_PkgDir . 'QCOM-Drivers-' . driverVersion . '.zip');
    define('releaseVersion', '1.0.7');
    define('QCOM_Software', QCOM_PkgDir . 'QCOM-Setup-' . releaseVersion . '.exe');
    //------------------------------------------------------------------------
    // Support
    //------------------------------------------------------------------------
    define('mailSite', QD_PublicDir . 'Mail-Handler.php');
    define('emailSubject' , 'QCOM Help (Version ' . sourceVersion . ')');
    define('reportIssues',
        'Please communicate problems and suggestions to <a href="' . mailSite . '?emailSubject=' .
        emailSubject . '&dest=support" target="_blank">Quartzdyne Support</a>');
    //------------------------------------------------------------------------
    include('/script/server/compresshtml.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
    <head>
        <title>QCOM Help</title>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <meta name="description" content="This page displays the QCOM help" />
        <meta name="keywords" content="quartzdyne, quartz, downhole, pressure, temperature, sensor, transducer, help, QCOM" />
        <meta name="distribution" content="global" />
        <meta name="author" content="Noji Ratzlaff" />
        <link href="/image/quartzdyne.ico" rel="shortcut icon" type="image/x-icon" />
        <link href="/style/qdprogstd.css" rel="stylesheet" type="text/css" />
        <link href="/style/reset1.css" rel="stylesheet" type="text/css" />
        <link href="/style/table1.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
            body
            {
                background-image: url('/image/white_sand.jpg');
                font: 12px verdana,sans-serif;
                margin-left: 16px;
                margin-right: 16px;
                margin-top: 8px;
            }
            div.center_window
            {
                text-align: center;
                margin-top: 10px;
                margin-bottom: 10px;
            }
            div.footer
            {
                color: black;
                font-size: 85%;
                font-weight: normal;
                margin-top: 10px;
                margin-bottom: 10px;
            }
        </style>
        <?  //----------------------------------------------------------------
            // Invoke the javascript page header functions
            //----------------------------------------------------------------
        ?>
        <script src="<?=clientScriptDir ?>PageHeader.js" language="javascript" type="text/javascript"></script>
        <script src="<?=clientScriptDir ?>ExpandCollapse.js" language="javascript" type="text/javascript"></script>
        <?  //----------------------------------------------------------------
            // Define local javascript functions
            //----------------------------------------------------------------
        ?>
        <script type="text/javascript">
<!--
            //----------------------------------------------------------------
            // center_pic
            //
            // Displays and centers the specified picture, depending on
            // picture type, Windows version, and size
            //----------------------------------------------------------------
            function center_pic(pic, picType, os, size)
            {
                document.write('<div class="center_window">');
                display_pic(pic, picType, os, size);
                document.write('</div>');
            }                           // end of center_pic()
            //----------------------------------------------------------------
            // display_pic
            //
            // Displays the specified picture, depending on picture type,
            // Windows version, and size
            //----------------------------------------------------------------
            function display_pic(pic, picType, os, size)
            {
                var     fileType;
                var     fullPic;
                //------------------------------------------------------------
                switch (os)
                {
                    case 'W7' :
                    case 'W8' :
                    case '08R2' :
                        fileType = 'png';
                        break;
                    case 'Vista' :
                        fileType = 'jpg';
                        break;
                    default :
                        fileType = 'bmp';
                        break;
                }
                switch (picType)
                {
                    case 'Window' :
                        fullPic = os + '/' + pic + '-' + os + '.' + fileType;
                        if (size == null)
                            size = '500';
                        document.write(
                             '<img src="image/' + fullPic + '" style="text-align:center; width:' + size + 'px;" />');
                        break;
                    case 'Hardware' :
                    case 'Manual' :
                        fullPic = picType + '/' + pic + '.' + fileType;
                        if (size == null)
                            size = '500';
                        document.write(
                             '<img src="image/' + fullPic + '" style="text-align:center; width:' + size + 'px;" />');
                        break;
                    default :
                        var     sizeSpec = '';
                        fullPic = os + '/' + pic + '-' + picType + '-' + os + '.' + fileType;
                        if (size != null)
                        {
                            switch (size)
                            {
                                case '1' :
                                    sizeSpec = ' width:72px; height:22px;';
                                    break;
                                case '2' :
                                    sizeSpec = ' width:86px; height:20px;';
                                    break;
                                default:
                                    sizeSpec = ' width:' + size + 'px;';
                                    break;
                            }
                        }
                        document.write(
                             '<img src="image/' + fullPic + '" style="vertical-align:middle;' + sizeSpec + '" />');
                        break;
                }
            }                           // end of display_pic()
            //----------------------------------------------------------------
            // display_ie_pic
            //
            // Displays the specified picture, depending on picture type,
            // browser version, and Windows version; meant specifically for
            // images that have browser-dependent appearances
            //----------------------------------------------------------------
            function display_ie_pic(pic, picType, size)
            {
                //------------------------------------------------------------
                switch (picType)
                {
                    case 'Button' :
                    case 'Label' :
                    case 'Pulldown' :
                        if (browserFlag == 'IE 9')
                            pic = 'Vista/' + pic + '-' + picType + '-IE9-Vista.jpg';
                        else
                            pic = 'XP/' + pic + '-' + picType + '-XP.bmp';
                        document.write(
                             '<img src="image/' + pic + '" style="vertical-align:middle;" />');
                        break;
                    case 'Window' :
                    default :
                        if (browserFlag == 'IE 9')
                            pic = 'Vista/' + pic + '-IE9-Vista.jpg';
                        else
                            pic = 'XP/' + pic + '-XP.bmp';
                        if (size == null)
                            size = '500';
                        document.write(
                             '<img src="image/' + pic + '" style="text-align:center; width:' + size + 'px;" />');
                        break;
                }
            }                           // end of display_ie_pic()
            //----------------------------------------------------------------
            // jump_within_doc
            //
            // Expands the text of the specified category and topic, then
            // jumps to the specified tag whose text is displayed as a link
            //----------------------------------------------------------------
            function jump_within_doc(text, linkTag, topic, category)
            {
                //------------------------------------------------------------
                if (category == null)
                    category = 'Software_Man';
                document.write(
                    '<a href="#' + linkTag + '" onclick="expand_sub(\'' + category +
                    '\');expand_sub(\'' + topic + '\')"><b>' + text + '</b></a>');
            }                           // end of jump_within_doc()
            //----------------------------------------------------------------
            // display_footer
            //
            // Displays a footer
            //----------------------------------------------------------------
            function display_footer()
            {
                //------------------------------------------------------------
                document.write(
                    '<div class="footer" id="footer"><?=reportIssues ?><br /><br />' +
                    '<a href="#doc_top">Return to the top of the page</a></div>');
            }                           // end of display_footer()
//-->
        </script>
    </head>
    <body onselectstart="event.returnValue=false;">
        <div id="qd_div" lang="QD"></div>
        <div style="margin:auto; text-align:center; width:1000px;" id="MainHeader">
            <?  //------------------------------------------------------------
                // Display the company logo and a button to print the page
                //------------------------------------------------------------
            ?>
            <a href="<?=QD_HomeDir ?>" target="_blank" name="doc_top">
                <img src="/image/QDDoverLogo.png" style="float:left; width:150px; margin-bottom:10px;" alt="Quartzdyne" />
            </a>
            <div style="margin-left:20px; margin-bottom:10px; text-align:center; float:left;">
                <div style="color:black; font-weight:bold; font-size:200%;">
                    <span style="color:red; font-style:italic; font-weight:extra-bold; font-family:Arial,sans;">
                        <acronym title="Quartzdyne Transducer Communication Module">
                            QCOM
                        </acronym>
                    </span>
                    Help Center
                </div>
                <span style="font-size:120%; margin-top:5px;">
                    <?=date('D d M Y h:i:s a'); ?>
                </span>
                <span>
                    <form style="margin-top:10px;">
                        <input
                            type="button"
                            onClick="window.print()"
                            value=" Print This Help Page "
                            style="color:blue;" />
                    </form>
                </span>
            </div>
        </div>                          <? // end of MainHeader ?>
        <div style="clear:both;" id="MainBody">
            <?  //------------------------------------------------------------
                // Display the header of the help text
                //------------------------------------------------------------
            ?>
            <div style="margin-top:5px; margin-bottom:10px;">
                <a href="<?=QCOM_DownloadSite ?>" target="_blank">Download</a> and install
                <a href="<?=QCOM_DownloadSite ?>" target="_blank">
                    <img src="image/QCOM-Logo.png" style="height:40px; width:60px; vertical-align:middle;" alt="QCOM" />
                </a>
                software and related tools
                <br />
                <div style="color:blue; margin-bottom:10px; cursor:pointer;" id="ExpandAll"
                    onclick="expand_collapse_all()"
                    ondblclick="expand_collapse_all()"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/Red-Dot.gif" class="centerDot" />
                    Expand the entire text
                </div>
                <?=reportIssues ?>
            </div>
            <?  //------------------------------------------------------------
                // Display the actual help text
                //------------------------------------------------------------
            ?>
            <hr class="redLine" />
            <div style="margin-top:10px" id="Help_Section">
                <div style="font-size:180%; color:blue; font-weight:bold; cursor:default;">QCOM Help</div>
                <?  //--------------------------------------------------------
                    // Overview
                    //--------------------------------------------------------
                ?>
                <div class="category" id="Overview"
                    onclick="expand_collapse('Overview_Topics')"
                    ondblclick="expand_collapse('Overview_Topics')"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/SpinStar.gif" class="spinStar" />
                    Overview
                </div>
                <div class="invisible" id="Overview_Topics" lang="QD">
                    <div class="topic"
                        onclick="expand_collapse('Overview_What')"
                        ondblclick="expand_collapse('Overview_What')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        What Is QCOM?<a name="About_QCOM"></a>
                    </div>
                    <div class="subtopic" id="Overview_What" lang="QD">
                        QCOM&trade;, or the Quartzdyne<sup>&reg;</sup> Transducer Communication module
                        is a hardware unit designed to allow client measuring and testing of Quartzdyne
                        <a href="<?=QD_PDFDir ?>FreqManual.pdf" target="_blank">frequency</a> ("analog")
                        and <a href="<?=QD_PDFDir ?>DigitalTransProg.pdf" target="_blank">digital</a> quartz
                        downhole pressure and temperature transducers at ambient conditions.
                        <div class="center_window">
                            <img src="image/Hardware/QCOM-Module.gif" style="width:200px;" />
                        </div>
                        Previously, testers used <a href="<?=QD_PDFDir ?>QLinkManual.pdf" target="_blank">Q-Link</a> modules
                        to interface digital transducers and <a href="<?=QD_PDFDir ?>SIManual.pdf" target="_blank">Series-I</a> modules
                        to interface frequency transducers. Eventually, the components of these earlier modules
                        became obsolete, rendering their upgrade or repair very difficult, if not
                        impossible. As more Q-Link and Series-I modules become inoperable, we expect
                        most testers will move to the QCOM module. Furthermore, in spite of being able to
                        interface only one transducer at any time, the fact that the QCOM module can
                        address both frequency- and digital-type transducers will probably promote
                        it as the transducer interface option of choice.
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Overview_What ?>
                    <div class="topic"
                        onclick="expand_collapse('Overview_Transducer')"
                        ondblclick="expand_collapse('Overview_Transducer')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        What is a transducer?<a name="About_Transducers"></a>
                    </div>
                    <div class="subtopic" id="Overview_Transducer" lang="QD">
                        By definition, a <a href="<?=Wiki_Dir ?>Transducer" title="Transducer" target="_blank">transducer</a> is
                        a device that transforms energy from one form into another. A Quartzdyne transducer
                        transforms the pressure and temperature applied to an internal <a href="<?=Wiki_Dir ?>Quartz" title="Quartz" target="_blank">quartz</a> crystal
                        into an electrical current by taking advantage of the <a href="<?=Wiki_Dir ?>Piezoelectric_effect" title="Piezoelectricity" target="_blank">piezoelectric effect</a>.
                        Basically, a set of internal quartz crystals change frequency in response to
                        changes in pressure and temperature, and an internal circuit reports the measured changes
                        in the form of digital electrical signals.
                        <div class="center_window">
                            <img src="image/Hardware/Transducers.gif" style="width:270px;" />
                        </div>
                        A frequency, or analog, transducer is so-called because the output of this
                        transducer is the raw frequency measurements of the crystals, although these measurements
                        are presented in a digital waveform. A digital transducer outputs the digital representation,
                        or counts, of these frequencies by means of a frequency counter through an
                        <a href="<?=Wiki_Dir ?>I%C2%B2C" target="_blank">I<sup>2</sup>C</a> interface.
                        <br /><br />
                        Because small variations in chemical and other physical properties exist between
                        one real-world quartz crystal and another, even those manufactured under the strictest
                        conditions, precise measurements based on these crystals require the hardware and
                        circuitry that interface with them be calibrated to produce accurate and consistent
                        results. Calibration is achieved by capturing the output of a transducer over a
                        permutation of pressures and temperatures, then
                        <a href="<?=Wiki_Dir ?>Curve_fitting" title="Curve-fitting" target="_blank">curve-fitting</a> these
                        values in multiple-order polynomials.  The resulting <a href="<?=Wiki_Dir ?>Coefficient" title="Coefficient" target="_blank">coefficients</a>
                        of the calibration are then collected and associated with their respective
                        transducers in a local database.
                        <br /><br />
                        Quartzdyne stores a repository of transducer coefficients, and makes them available
                        <a href="<?=coeffSite ?>" target="_blank">online</a> by transducer serial number.
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Overview_Transducer ?>
                </div>                  <? // end of Overview_Topics ?>
                <?  //--------------------------------------------------------
                    // Requirements
                    //--------------------------------------------------------
                ?>
                <div class="category" id="Requirements"
                    onclick="expand_collapse('Requirements_Topics')"
                    ondblclick="expand_collapse('Requirements_Topics')"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/SpinStar.gif" class="spinStar" />
                    Requirements
                </div>
                <div class="invisible" id="Requirements_Topics" lang="QD">
                    <div class="topic"
                        onclick="expand_collapse('Requirements_Hardware')"
                        ondblclick="expand_collapse('Requirements_Hardware')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Hardware<a name="Hardware_Requirements"></a>
                    </div>
                    <div class="subtopic" id="Requirements_Hardware" lang="QD">
                        <div class="center_window">
                            <img src="image/Hardware/Computer.gif" style="width:200px;" />
                        </div>
                        You will need a Windows-compatible computer that has at least one USB
                        2.0 port available.  It can be a desktop, laptop, server, or any other
                        kind of computer that contains a USB port and is capable of supporting
                        the Microsoft<sup>&reg;</sup> Windows<sup>&trade;</sup> operating system.
                        The computer must also meet the following minimum requirements:
                        <li style="margin-left:40px;">
                            32-bit or 64-bit processor, at least 1.2 GHz
                        </li>
                        <li style="margin-left:40px;">
                            2.0 GB memory
                        </li>
                        <li style="margin-left:40px;">
                            94 MB free disk space
                        </li>
                        <li style="margin-left:40px;">
                            Connection to the internet is optional but highly recommended
                        </li>
                        <li style="margin-left:40px;">
                            Standard mouse and keyboard
                        </li>
                        <div class="center_window">
                            <img src="image/Hardware/USB-Type-A-Type-B.gif" style="width:200px;" />
                        </div>
                        A standard 6-foot USB 2.0 (Type A male to Type B male) cable like this
                        one is needed to connect the QCOM module to your computer or a USB hub,
                        one cable for each module.
                        <div class="center_window">
                            <img src="image/Hardware/DE-9-Connector.jpg" style="width:200px;" />
                        </div>
                        You will also need the cable that connects your transducer to the QCOM
                        module. The end that attaches to your transducer is specific to your
                        transducer type; the other end is a Type DE-9 (often mistakenly
                        referred to as DB-9) male connector, which will attach to the QCOM module.
                        <div class="center_window">
                            <img src="image/Hardware/QCOM-Module-USB.jpg" style="width:200px;" />
                        </div>
                        This is the top and USB end of the QCOM module. Plug the USB type B male
                        end of the cable into this port, and attach the DE-9 connector of the transducer
                        cable to the opposite end of the QCOM module.
                        <div class="center_window">
                            <img src="image/Hardware/QCOM-Plug-USB.jpg" style="width:300px;" />
                        </div>
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Requirements_Hardware ?>
                    <div class="topic"
                        onclick="expand_collapse('Requirements_Software')"
                        ondblclick="expand_collapse('Requirements_Software')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Software<a name="Software_Requirements"></a>
                    </div>
                    <div class="subtopic" id="Requirements_Software" lang="QD">
                        <ul style="list-style-type:decimal;">
                            <li>
                                The Quartzdyne QCOM software is designed to run on any of the following Microsoft<sup>&reg;</sup>
                                Windows<sup>&trade;</sup> operating environments:
                                <br /><br />
                                <ol>
                                    <li style="list-style-type:disc;">
                                        Windows 10&trade; (tested on 64-bit <i>Enterprise</i>)
                                    </li>
                                    <li style="list-style-type:disc;">
                                        Windows 8&trade; (tested on 64-bit <i>Pro</i>)
                                    </li>
                                    <li style="list-style-type:disc;">
                                        Windows Server 2012&trade; (tested on Windows Server 8 <i>Beta Datacenter</i>)
                                    </li>
                                    <li style="list-style-type:disc;">
                                        Windows 7&trade; (tested on 32-bit <i>Professional</i>, 32-bit <i>Professional</i> SP1,
                                        32-bit <i>Ultimate</i>, 64-bit <i>Enterprise</i>, and 64-bit <i>Enterprise</i> SP1)
                                    </li>
                                    <li style="list-style-type:disc;">
                                        Windows Vista&trade; SP2 (tested on 64-bit <i>Ultimate</i>)
                                    </li>
                                    <li style="list-style-type:disc;">
                                        Windows Server 2008&trade; R2 (tested on <i>Enterprise</i>)
                                    </li>
                                    <li style="list-style-type:disc;">
                                        Windows Server 2003&trade; R2 (tested on 64-bit <i>Standard</i>)
                                    </li>
                                    <li style="list-style-type:disc;">
                                        Windows XP&trade; SP3 (tested on 32-bit <i>Professional</i>, 64-bit <i>Professional</i>)
                                    </li>
                                    <br />
                                    <li style="list-style-type:none; margin-left:-20px;">
                                        Note: The QCOM software will <b>NOT</b> run on Windows 2000&trade; or
                                        earlier
                                    </li>
                                    <br />
                                    <li style="list-style-type:none; margin-left:-20px;">
                                        Note: The QCOM software must only be run using Windows
                                        <b><i><span style="color:brown;" title="Control Panel > All Control Panel Items > Display">small</span> font size</i></b>
                                    </li>
                                    <br />
                                </ol>
                            </li>
                            <li>
                                You must have Administrator privileges to install the QCOM software and drivers
                            </li>
                            <br />
                            <li>
                                An internet browser, such as
                                Microsoft<sup>&reg;</sup> <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home" target="_blank">Internet Explorer</a>&trade; or
                                Microsoft<sup>&reg;</sup> <a href="https://www.microsoft.com/en-us/windows/microsoft-edge" target="_blank">Edge</a>&trade; or
                                Mozilla<sup>&reg;</sup> <a href="http://www.mozilla.com/en-US/firefox/new/" target="_blank">Firefox</a>&trade; or
                                Google<sup>&reg;</sup> <a href="http://www.google.com/chrome/" target="_blank">Chrome</a>&trade; should
                                be available to you during installation.
                            </li>
                        </ul>
                        When you have all of the above items in place, <a href="<?=QCOM_DownloadSite ?>" target="_blank">download</a>
                        and install the QCOM software.
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Requirements_Software ?>
                    <div class="topic"
                        onclick="expand_collapse('Requirements_Skill')"
                        ondblclick="expand_collapse('Requirements_Skill')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Skill Level and Knowledge<a name="Skill_Requirements"></a>
                    </div>
                    <div class="subtopic" id="Requirements_Skill" lang="QD">
                        No particular education or certification is required to operate the QCOM
                        hardware or software, but a basic knowledge of the Microsoft<sup>&reg;</sup> Windows<sup>&trade;</sup>
                        operating environments will be helpful in navigating the QCOM software.
                        <br /><br />
                        All the steps needed to install and run the QCOM software are detailed in this
                        comprehensive Help. You need administrator privileges to install the QCOM software
                        and driver, however.
                        <br /><br />
                        Furthermore, no particular knowledge of Quartzdyne products are required to
                        operate the QCOM hardware or software, but an understanding of applicable
                        products might help QCOM settings, controls, and responses become more meaningful
                        to you.
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>
                </div>                  <? // end of Requirements_Topics ?>
                <?  //--------------------------------------------------------
                    // Installation
                    //--------------------------------------------------------
                ?>
                <div class="category" id="Installation" name="install_top"
                    onclick="expand_collapse('Installation_Topics')"
                    ondblclick="expand_collapse('Installation_Topics')"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/SpinStar.gif" style="height:16px; width:16px; margin-bottom:2px; vertical-align:middle;" />
                    Installation
                </div>
                <div class="invisible" id="Installation_Topics" lang="QD">
                    <div class="topic"
                        onclick="expand_collapse('Install_Software')"
                        ondblclick="expand_collapse('Install_Software')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Software Download and Installation<a name="Software_Installation"></a>
                    </div>
                    <div class="subtopic" id="Install_Software" lang="QD">
                        <div style="margin-top:10px; margin-bottom:10px;" lang="QD">
                            Follow these instructions to install the software on your computer. <b>You need
                            administrator privileges to install the software.</b>
                        </div>
                        If there are any QCOM modules attached to your computer, remove them before
                        proceeding.
                        <br /><br />
                        <a href="<?=QCOM_Software ?>" target="_blank">Download</a> the software directly from the <a href="<?=QCOM_DownloadSite ?>" target="_blank">QCOM Download Center</a>.
                        <div class="center_window">
                            <img src="image/XP/QCOM-Download.bmp" style="width:600px;" />
                        </div>
                        Click <a href="<?=QCOM_Software ?>" target="_blank"><img src="/image/Download-Button.gif" style="vertical-align:middle; width:80px; margin-bottom:5px;" /></a>
                        for the <b>released</b> software.
                        <br /><br />
                        <script type="text/javascript">display_pic('Run-Or-Save', 'Window', 'XP', '400');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_ie_pic('Run', 'Button');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('Run-Software', 'Window', 'XP', '400');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_ie_pic('Run', 'Button');</script> at the
                        <b>Do you want to run this software?</b> window
                        <br /><br />
                        The following window should appear if Microsoft<sup>&reg;</sup> .NET Framework<sup>&copy;</sup> 4 or
                        later was not previously installed on your computer:
                        <br /><br />
                        <script type="text/javascript">display_ie_pic('MS.NET-4-Install', 'Window');</script>
                        <br /><br />
                        If the window <b>does</b> appear, click <script type="text/javascript">display_pic('Install', 'Button', 'XP');</script> to proceed with
                        the installation, which will take several minutes.
                        <br /><br />
                        <b>Note: During the .NET Framework installation, your malware (anti-virus)
                        protection program might determine that the .NET Framework package cannot be installed
                        because the package installation is called from within the original QCOM installation package.
                        If this is the case, <a href="<?=MS_dot_NET_4 ?>">download the .NET Framework 4 package from this link</a> and
                        click <script type="text/javascript">display_ie_pic('Run', 'Button');</script> to begin and
                        complete its installation, then proceed with the QCOM installation.
                        <br /><br />
                        <script type="text/javascript">display_pic('QCOM-Installation', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', 'XP');</script> at the <b>Welcome
                        to QCOM installation</b> window.
                        <br /><br />
                        <script type="text/javascript">display_pic('Customer-Information', 'Window', 'XP');</script>
                        <br /><br />
                        Fill in the <b>Customer Information</b> fields, then
                        click <script type="text/javascript">display_pic('Next', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('Destination-Folder', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', 'XP');</script> to accept the
                        <b>Destination Folder</b> as shown.
                        <br /><br />
                        <script type="text/javascript">display_pic('Typical-Or-Custom', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', 'XP');</script> at the <b>Setup Type</b>
                        window for a Typical setup.
                        <br /><br />
                        <script type="text/javascript">display_pic('Ready-To-Install', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Install', 'Button', 'XP');</script> at the <b>Ready
                        to Install the Program</b> window.
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallingSoftware', 'Window', 'XP');</script>
                        <br /><br />
                        Do not click anything while the software is being installed.
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallationCompleted', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Finish', 'Button', 'XP');</script> at the <b>QCOM
                        installation completed</b> window.
                        <br /><br />
                        At this point, the QCOM software installation is complete, including the driver
                        and all support files. The installation should have placed the <img src="image/QCOM-Logo.png" style="height:40px; width:60px; vertical-align:middle;" alt="QCOM" />
                        icon shortcut on your desktop to provide access to the QCOM software.
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Install_Software ?>
                    <div class="topic"
                        onclick="expand_collapse('Install_Hardware')"
                        ondblclick="expand_collapse('Install_Hardware')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Hardware Installation
                    </div>
                    <div class="subtopic" id="Install_Hardware" lang="QD">
                        <div style="margin-top:10px; margin-bottom:10px;" lang="QD">
                            The only hardware installation involved with operating the QCOM hardware and
                            software includes the Quartzdyne transducer, QCOM module, associated cabling,
                            and the computer on which to run the QCOM software. To properly install the
                            hardware, however, you must first deactivate the User Account Control (only
                            if you are running Windows 7&trade;, Windows Vista&trade;, Windows 8&trade;,
                            or Windows Server 2012&trade;) and complete the driver <i>configuration</i> as
                            outlined here, assuming the QCOM software and driver have already been installed
                            on your computer.
                        </div>
                        <script type="text/javascript">center_pic('QCOM-Plug-USB', 'Hardware', 'Vista', '500');</script>
                        To deactivate User Account Control on Windows 7, Windows Vista, Windows 8, or
                        Windows Server 2012, open <b>Control Panel</b>, select View by: Small icons, and
                        click <b>User Accounts</b>. Click <b>Change User Account Control settings</b> and
                        drag the vertical slide bar to the very bottom setting, labeled <b>Never notify</b>.
                        Click <b>OK</b>, then exit <b>User Accounts</b> and <b>Control Panel</b>. Restart
                        your computer, even if Windows does not ask you to do so.
                        <br /> <br />
                        Perform the following six steps for each QCOM module with a different serial
                        number that you want to connect to your computer:
                        <ol style="list-style-type:decimal;">
                            <li>
                                Connect a QCOM module to an available USB port on your computer, but <b><i>do not</i></b>
                                attach a Quartzdyne transducer to the QCOM module just yet.
                            </li>
                            <li>
                                <b>Important!</b> If this is the first time you have attached a QCOM
                                module with this particular serial number to your computer, Windows
                                will display the <b>Installing device driver software</b> or <b>Found New
                                Hardware</b> message near the bottom of your screen. Wait 30 to 60 seconds
                                for Windows to configure the QCOM driver. Eventually Windows will display
                                the <b>Device driver software installed successfully</b> or <b>Your new
                                hardware is installed and ready to use</b> message.
                            </li>
                            <li>
                                Double-click the <img src="image/QCOM-Logo.png" style="height:40px; width:60px; vertical-align:middle;" alt="QCOM" />
                                icon shortcut on your desktop to start the QCOM software.
                            </li>
                            <li>
                                <b>Important!</b> If this is the first time you have attached a QCOM
                                module with this particular serial number to your computer, Windows
                                will display the <b>Installing device driver software</b> or <b>Found New
                                Hardware</b> message near the bottom of your screen a <i>second</i> time. Wait
                                another 30 to 60 seconds for Windows to complete the QCOM driver configuration before
                                you do anything else with the QCOM software. Eventually Windows will
                                display the <b>Device driver software installed successfully</b> or <b>Your
                                new hardware is installed and ready to use</b> message.
                            </li>
                            <li>
                                Exit the QCOM software.
                            </li>
                            <li>
                                Remove the QCOM module from your computer.
                            </li>
                        </ol>
                        Connect a Quartzdyne transducer to the QCOM module.
                        <br /><br />
                        Re-connect the QCOM module to your computer.
                        <br />
                        Double-click the <img src="image/QCOM-Logo.png" style="height:40px; width:60px; vertical-align:middle;" alt="QCOM" />
                        icon shortcut on your desktop to start the QCOM software.
                        <br />
                        Proceed to operate the QCOM software normally.
                        <br /><br />
                        See <script type="text/javascript">jump_within_doc('Hardware Requirements', 'Hardware_Requirements', 'Requirements_Hardware', 'Requirements_Topics');</script> for
                        more information on the computer and cabling required to run and support the
                        QCOM software.
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Install_Hardware ?>
                    <div class="topic"
                        onclick="expand_collapse('Install_Driver_Win7')"
                        ondblclick="expand_collapse('Install_Driver_Win7')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Driver Installation - Windows 7&trade; and Windows Vista&trade;
                    </div>
                    <div class="subtopic" id="Install_Driver_Win7" lang="QD">
                        <div style="margin-top:10px; margin-bottom:10px;" lang="QD">
                            Follow these steps to install the QCOM driver on your Windows 7 or Windows
                            Vista computer. Normally, the driver will be applied automatically during
                            software installation, so these instructions are provided if you need to
                            install the driver without the software, to provide support for the QCOM DLL
                            used in custom software, for example. <b>You need administrator privileges
                            to install the driver.</b>
                        </div>
                        <a href="<?=QCOM_Drivers ?>" target="_blank">Download</a> the latest QCOM drivers to your local
                        computer and un-ZIP the files to a folder of your choice.
                        <br /><br />
                        <script type="text/javascript">display_pic('QCOM-Plug-USB', 'Hardware', 'Vista', '500');</script>
                        <br /><br />
                        Connect a QCOM module to an available USB port on your computer.
                        <br /><br />
                        <script type="text/javascript">display_pic('Start', 'Button', 'W7');</script>
                        <br /><br />
                        Click the Start button at the lower left of your Windows toolbar.
                        <br /><br />
                        <script type="text/javascript">display_pic('Computer-Manage', 'Window', 'W7');</script>
                        <br /><br />
                        In the Start menu <i>right-click</i> <script type="text/javascript">display_pic('Computer', 'Button', 'W7');</script> then
                        click <script type="text/javascript">display_pic('Manage', 'Button', 'W7');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('Device-Manager', 'Window', 'W7');</script>
                        <br /><br />
                        In the left pane of <b>Computer Management</b> click <script type="text/javascript">display_pic('DM', 'Button', 'W7');</script> and
                        then in the middle pane <i>right-click</i> <script type="text/javascript">display_pic('DM', 'QCOM', 'W7');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('DM-QCOM-Pulldown', 'Window', 'W7');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('DM-UDS', 'Button', 'W7');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('Search-Browse', 'Window', 'W7');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('BrowseMyComputer', 'Label', 'W7');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('LetMePick', 'Window', 'W7');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('LetMePick', 'Label', 'W7');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('SelectDeviceType', 'Window', 'W7');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', 'W7');</script> This
                        could take a few minutes.
                        <br /><br />
                        <script type="text/javascript">display_pic('SelectDeviceDriver-HaveDisk', 'Window', 'W7');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('HaveDisk', 'Button', 'W7', '2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallFromDisk-Browse', 'Window', 'W7');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Browse', 'Button', 'W7');</script> and
                        navigate to the folder where you un-ZIPped the QCOM driver.
                        <br /><br />
                        <script type="text/javascript">display_pic('LocateFile', 'Window', 'W7');</script>
                        <br /><br />
                        Highlight (single-click) <script type="text/javascript">display_pic('QCOM', 'INF', 'W7');</script> and
                        click <script type="text/javascript">display_pic('Open', 'Button', 'W7');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallFromDisk-OK', 'Window', 'W7');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('OK', 'Button', 'W7');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('SelectDeviceDriver-Next', 'Window', 'W7');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', 'W7');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallingDriver', 'Window', 'W7');</script>
                        <br /><br />
                        Do not click anything while the driver is being installed.
                        <br /><br />
                        <script type="text/javascript">display_pic('SuccessfullyUpdated', 'Window', 'W7');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Close', 'Button', 'W7');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('DM-QCOM-Confirmation', 'Window', 'W7');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Red-X', 'Button', 'W7');</script> to close
                        the Device Manager (<b>Computer Management</b>) window. The QCOM driver is now
                        installed and ready to use.
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Install_Driver_Win7 ?>
                    <div class="topic"
                        onclick="expand_collapse('Install_Driver_Win8')"
                        ondblclick="expand_collapse('Install_Driver_Win8')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Driver Installation - Windows 8&trade; and Windows Server 2012&trade;
                    </div>
                    <div class="subtopic" id="Install_Driver_Win8" lang="QD">
                        <div style="margin-top:10px; margin-bottom:10px;" lang="QD">
                            Follow these steps to install the QCOM driver on your Windows 8 or Windows Server
                            2012 computer. Normally, the driver will be applied automatically during
                            software installation, so these instructions are provided if you need to
                            install the driver without the software, to provide support for the QCOM DLL
                            used in custom software, for example. <b>You need administrator privileges
                            to install the driver.</b>
                        </div>
                        <a href="<?=QCOM_Drivers ?>" target="_blank">Download</a> the latest QCOM drivers to your local
                        computer and un-ZIP the files to a folder of your choice.
                        <br /><br />
                        <script type="text/javascript">display_pic('QCOM-Plug-USB', 'Hardware', 'Vista', '500');</script>
                        <br /><br />
                        Connect a QCOM module to an available USB port on your computer.
                        <br /><br />
                        Press &lt;Windows-x&gt;, then click Device Manager.
                        <br /><br />
                        <script type="text/javascript">display_pic('Device-Manager', 'Window', 'W8');</script>
                        <br /><br />
                        In <b>Device Manager</b> <i>right-click</i> <script type="text/javascript">display_pic('DM', 'QCOM', 'W8');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('DM-QCOM-Pulldown', 'Window', 'W8');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('DM-UDS', 'Button', 'W7');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('Search-Browse', 'Window', 'W8');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('BrowseMyComputer', 'Label', 'W7');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('LetMePick', 'Window', 'W8');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('LetMePick', 'Label', 'W7');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('SelectDeviceType', 'Window', 'W8');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', 'W8');</script> This
                        could take a few minutes.
                        <br /><br />
                        <script type="text/javascript">display_pic('SelectDeviceDriver-HaveDisk', 'Window', 'W8');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('HaveDisk', 'Button', 'W8');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallFromDisk-Browse', 'Window', 'W8');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Browse', 'Button', 'W8');</script> and
                        navigate to the folder where you un-ZIPped the QCOM driver.
                        <br /><br />
                        <script type="text/javascript">display_pic('LocateFile', 'Window', 'W8');</script>
                        <br /><br />
                        Highlight (single-click) <script type="text/javascript">display_pic('QCOM', 'INF', 'W7');</script> and
                        click <script type="text/javascript">display_pic('Open', 'Button', 'W8');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallFromDisk-OK', 'Window', 'W8');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('OK', 'Button', 'W8');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('SelectDeviceDriver-Next', 'Window', 'W8');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', 'W8');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallingDriver', 'Window', 'W8');</script>
                        <br /><br />
                        Do not click anything while the driver is being installed.
                        <br /><br />
                        <script type="text/javascript">display_pic('SuccessfullyUpdated', 'Window', 'W8');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Close', 'Button', 'W8');</script>
                        <br /><br />
                        <img src="image/W8/DM-QCOM-Confirmation-W8.png" style="text-align:center; width:500px;" />
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Red-X', 'Button', 'W8');</script> to close
                        the Device Manager window. The QCOM driver is now installed and ready to use.
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Install_Driver_Win8 ?>
                    <div class="topic"
                        onclick="expand_collapse('Install_Driver_WinXP_Prompt')"
                        ondblclick="expand_collapse('Install_Driver_WinXP_Prompt')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Driver Installation - Windows XP&trade; (you have been prompted by the Hardware Wizard)
                    </div>
                    <div class="subtopic" id="Install_Driver_WinXP_Prompt" lang="QD">
                        <div style="margin-top:10px; margin-bottom:10px;" lang="QD">
                            Follow these steps to install the QCOM driver on your Windows XP computer if
                            the Hardware Wizard appears and announces that new hardware has been found.
                            Normally, the driver will be applied automatically during software installation,
                            so these instructions are provided if you need to install the driver without
                            the software, to provide support for the QCOM DLL used in custom software,
                            for example. <b>You need administrator privileges to install the driver.</b>
                        </div>
                        <a href="<?=QCOM_Drivers ?>" target="_blank">Download</a> the latest QCOM drivers to your local
                        computer and un-ZIP the files to a folder of your choice.
                        <br /><br />
                        <script type="text/javascript">display_pic('QCOM-Plug-USB', 'Hardware', 'Vista', '500');</script>
                        <br /><br />
                        Connect a QCOM module to an available USB port on your computer.
                        <br /><br />
                        Plug a QCOM module into an available USB port or USB hub attached to your Windows&trade;
                        computer. A Quartzdyne transducer is not required for driver installation. Once
                        the operating system detects your QCOM module, the following window should appear if
                        the QCOM driver has never previously been installed on your computer:
                        <br /><br />
                        <script type="text/javascript">display_pic('Hardware-Wizard', 'Window', 'XP');</script>
                        <br /><br />
                        Select <script type="text/javascript">display_pic('NotThisTime', 'Radio', 'XP');</script> and
                        click <script type="text/javascript">display_pic('Next', 'Button', 'XP', '1');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HW-InstallList', 'Window', 'XP');</script>
                        <br /><br />
                        Select <script type="text/javascript">display_pic('InstallFromAList', 'Radio', 'XP');</script> and
                        click <script type="text/javascript">display_pic('Next', 'Button', 'XP', '1');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HW-DontSearch', 'Window', 'XP');</script>
                        <br /><br />
                        Select <script type="text/javascript">display_pic('DontSearch', 'Radio', 'XP');</script> and
                        click <script type="text/javascript">display_pic('Next', 'Button', 'XP', '1');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HW-HardwareType', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', 'XP', '1');</script> This
                        could take a few minutes.
                        <br /><br />
                        <script type="text/javascript">display_pic('HW-SelectDeviceDriver-HaveDisk', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('HaveDisk', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallFromDisk-Browse', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Browse', 'Button', 'XP');</script> and
                        navigate to the folder where you un-ZIPped the QCOM driver.
                        <br /><br />
                        <script type="text/javascript">display_pic('LocateFile', 'Window', 'XP');</script>
                        <br /><br />
                        Highlight (single-click) <script type="text/javascript">display_pic('QCOM', 'INF', 'XP');</script> and
                        click <script type="text/javascript">display_pic('Open', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallFromDisk-OK', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('OK', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HW-SelectDeviceDriver-Next', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', 'XP', '1');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HW-FinishedInstalling', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Finish', 'Button', 'XP');</script> to close
                        the Hardware Wizard. The QCOM driver is now installed and ready to use.
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Install_Driver_WinXP_Prompt ?>
                    <div class="topic"
                        onclick="expand_collapse('Install_Driver_WinXP_No_Prompt')"
                        ondblclick="expand_collapse('Install_Driver_WinXP_No_Prompt')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Driver Installation - Windows XP&trade; (you have NOT been prompted to install the driver)
                    </div>
                    <div class="subtopic" id="Install_Driver_WinXP_No_Prompt" lang="QD">
                        <div style="margin-top:10px; margin-bottom:10px;" lang="QD">
                            Follow these steps to install the QCOM driver on your Windows XP computer.
                            Normally, the driver will be applied automatically during software installation,
                            so these instructions are provided if you need to install the driver without
                            the software, to provide support for the QCOM DLL used in custom software,
                            for example. <b>You need administrator privileges to install the driver.</b>
                        </div>
                        <a href="<?=QCOM_Drivers ?>" target="_blank">Download</a> the latest QCOM drivers to your local
                        computer and un-ZIP the files to a folder of your choice.
                        <br /><br />
                        <script type="text/javascript">display_pic('QCOM-Plug-USB', 'Hardware', 'Vista', '500');</script>
                        <br /><br />
                        Connect a QCOM module to an available USB port on your computer.
                        <br /><br />
                        <script type="text/javascript">display_pic('Start', 'Button', 'XP');</script>
                        <br /><br />
                        Click the Start button in the lower left of your Windows toolbar.
                        <br /><br />
                        <script type="text/javascript">display_pic('Computer-Manage', 'Window', 'XP');</script>
                        <br /><br />
                        In the Start menu <i>right-click</i> <script type="text/javascript">display_pic('Computer', 'Button', 'XP');</script> then
                        click <script type="text/javascript">display_pic('Manage', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('Device-Manager', 'Window', 'XP');</script>
                        <br /><br />
                        In the left pane of <b>Computer Management</b> click <script type="text/javascript">display_pic('DM', 'Button', 'XP');</script> and
                        then in the right pane <i>right-click</i> <script type="text/javascript">display_pic('DM', 'QCOM', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('DM-QCOM-Pulldown', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('DM-UD', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('Hardware-Update', 'Window', 'XP');</script>
                        <br /><br />
                        Select <script type="text/javascript">display_pic('NotThisTime', 'Radio', 'XP');</script> and
                        click <script type="text/javascript">display_pic('Next', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HU-InstallList', 'Window', 'XP');</script>
                        <br /><br />
                        Select <script type="text/javascript">display_pic('InstallFromAList', 'Radio', 'XP');</script> and
                        click <script type="text/javascript">display_pic('Next', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HU-DontSearch', 'Window', 'XP');</script>
                        <br /><br />
                        Select <script type="text/javascript">display_pic('DontSearch', 'Radio', 'XP');</script> and
                        click <script type="text/javascript">display_pic('Next', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HU-HardwareType', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', 'XP');</script> This
                        could take a few minutes.
                        <br /><br />
                        <script type="text/javascript">display_pic('HU-SelectDeviceDriver-HaveDisk', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('HaveDisk', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallFromDisk-Browse', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Browse', 'Button', 'XP');</script> and
                        navigate to the folder where you un-ZIPped the QCOM driver.
                        <br /><br />
                        <script type="text/javascript">display_pic('LocateFile', 'Window', 'XP');</script>
                        <br /><br />
                        Highlight (single-click) <script type="text/javascript">display_pic('QCOM', 'INF', 'XP');</script> and
                        click <script type="text/javascript">display_pic('Open', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallFromDisk-OK', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('OK', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HU-SelectDeviceDriver-Next', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HU-FinishedInstalling', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Finish', 'Button', 'XP');</script> to close
                        the Hardware Update Wizard.
                        <br /><br />
                        <script type="text/javascript">display_pic('DM-QCOM-Confirmation', 'Window', 'XP');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Red-X', 'Button', 'XP');</script> to close
                        the Device Manager (<b>Computer Management</b>) window. The QCOM driver is now
                        installed and ready to use.
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Install_Driver_WinXP_No_Prompt ?>
                    <div class="topic"
                        onclick="expand_collapse('Install_Driver_08R2')"
                        ondblclick="expand_collapse('Install_Driver_08R2')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Driver Installation - Windows Server 2008&trade; R2
                    </div>
                    <div class="subtopic" id="Install_Driver_08R2" lang="QD">
                        <div style="margin-top:10px; margin-bottom:10px;" lang="QD">
                            Follow these steps to install the QCOM driver on your Windows Server 2008
                            R2 computer. Normally, the driver will be applied automatically
                            during software installation, so these instructions are provided if you need to
                            install the driver without the software, to provide support for the QCOM DLL
                            used in custom software, for example. <b>You need administrator privileges
                            to install the driver.</b>
                        </div>
                        <a href="<?=QCOM_Drivers ?>" target="_blank">Download</a> the latest QCOM drivers to your local
                        computer and un-ZIP the files to a folder of your choice.
                        <br /><br />
                        <script type="text/javascript">display_pic('QCOM-Plug-USB', 'Hardware', 'Vista', '500');</script>
                        <br /><br />
                        Connect a QCOM module to an available USB port on your computer.
                        <br /><br />
                        <script type="text/javascript">display_pic('Start', 'Button', '08R2');</script>
                        <br /><br />
                        Click the Start button at the lower left of your Windows toolbar.
                        <br /><br />
                        <script type="text/javascript">display_pic('Computer-Manage', 'Window', '08R2');</script>
                        <br /><br />
                        In the Start menu <i>right-click</i> <script type="text/javascript">display_pic('Computer', 'Button', '08R2');</script> then
                        click <script type="text/javascript">display_pic('Manage', 'Button', '08R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('Server-Manager', 'Window', '08R2');</script>
                        <br /><br />
                        In the left pane of <b>Server Manager</b> click the <script type="text/javascript">display_pic('Plus', 'Sign', '08R2');</script> in front
                        of <script type="text/javascript">display_pic('Diagnostics', 'Button', '08R2');</script> then
                        click <script type="text/javascript">display_pic('DM', 'Button', '08R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('Device-Manager', 'Window', '08R2');</script>
                        <br /><br />
                        In the middle pane of <b>Server Manager</b> <i>right-click</i> <script type="text/javascript">display_pic('DM', 'QCOM', 'W7');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('DM-QCOM', 'Pulldown', '08R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('DM-UDS', 'Button', '08R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('Search-Browse', 'Window', '08R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('BrowseMyComputer', 'Label', '08R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('LetMePick', 'Window', '08R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('LetMePick', 'Label', '08R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('SelectDeviceType', 'Window', '08R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', '08R2');</script> This
                        could take a few minutes.
                        <br /><br />
                        <script type="text/javascript">display_pic('SelectDeviceDriver-HaveDisk', 'Window', '08R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('HaveDisk', 'Button', '08R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallFromDisk-Browse', 'Window', '08R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Browse', 'Button', '08R2');</script> and
                        navigate to the folder where you un-ZIPped the QCOM driver.
                        <br /><br />
                        <script type="text/javascript">display_pic('LocateFile', 'Window', '08R2');</script>
                        <br /><br />
                        Highlight (single-click) <script type="text/javascript">display_pic('QCOM', 'INF', '08R2');</script> and
                        click <script type="text/javascript">display_pic('Open', 'Button', '08R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallFromDisk-OK', 'Window', '08R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('OK', 'Button', '08R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('SelectDeviceDriver-Next', 'Window', '08R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', '08R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallingDriver', 'Window', '08R2');</script>
                        <br /><br />
                        Do not click anything while the driver is being installed.
                        <br /><br />
                        <script type="text/javascript">display_pic('SuccessfullyUpdated', 'Window', '08R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Close', 'Button', '08R2');</script>
                        <br /><br />
                        <img src="image/08R2/DM-QCOM-Confirmation-08R2.png" style="text-align:center; width:500px;" />
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Black-X', 'Button', '08R2');</script> to close
                        the Device Manager (<b>Server Manager</b>) window. The QCOM driver is now
                        installed and ready to use.
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Install_Driver_08R2 ?>
                    <div class="topic"
                        onclick="expand_collapse('Install_Driver_03R2')"
                        ondblclick="expand_collapse('Install_Driver_03R2')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Driver Installation - Windows Server 2003&trade; R2
                    </div>
                    <div class="subtopic" id="Install_Driver_03R2" lang="QD">
                        <div style="margin-top:10px; margin-bottom:10px;" lang="QD">
                            Follow these steps to install the QCOM driver on your Windows Server 2003
                            computer. Normally, the driver will be applied automatically during
                            software installation, so these instructions are provided if you need to
                            install the driver without the software, to provide support for the QCOM DLL
                            used in custom software, for example. <b>You need administrator privileges
                            to install the driver.</b>
                        </div>
                        <a href="<?=QCOM_Drivers ?>" target="_blank">Download</a> the latest QCOM drivers to your local
                        computer and un-ZIP the files to a folder of your choice.
                        <br /><br />
                        <script type="text/javascript">display_pic('QCOM-Plug-USB', 'Hardware', 'Vista', '500');</script>
                        <br /><br />
                        Connect a QCOM module to an available USB port on your computer.
                        <br /><br />
                        <script type="text/javascript">display_pic('Start', 'Button', '03R2');</script>
                        <br /><br />
                        Click the Start button at the lower left of your Windows toolbar.
                        <br /><br />
                        <script type="text/javascript">display_pic('Computer-Manage', 'Window', '03R2');</script>
                        <br /><br />
                        In the Start menu <i>right-click</i> <script type="text/javascript">display_pic('Computer', 'Button', '03R2');</script> then
                        click <script type="text/javascript">display_pic('Manage', 'Button', '03R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('Device-Manager', 'Window', '03R2');</script>
                        <br /><br />
                        In the left pane of <b>Computer Management</b> click <script type="text/javascript">display_pic('DM', 'Button', 'XP');</script> and
                        then in the right pane <i>right-click</i> <script type="text/javascript">display_pic('DM', 'QCOM', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('DM-QCOM-Pulldown', 'Window', '03R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('DM-UD', 'Button', 'XP');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('Hardware-Update', 'Window', '03R2');</script>
                        <br /><br />
                        Select <script type="text/javascript">display_pic('NotThisTime', 'Radio', '03R2');</script> and
                        click <script type="text/javascript">display_pic('Next', 'Button', '03R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HU-InstallList', 'Window', '03R2');</script>
                        <br /><br />
                        Select <script type="text/javascript">display_pic('InstallFromAList', 'Radio', '03R2');</script> and
                        click <script type="text/javascript">display_pic('Next', 'Button', '03R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HU-DontSearch', 'Window', '03R2');</script>
                        <br /><br />
                        Select <script type="text/javascript">display_pic('DontSearch', 'Radio', '03R2');</script> and
                        click <script type="text/javascript">display_pic('Next', 'Button', '03R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HU-HardwareType', 'Window', '03R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', '03R2');</script> This
                        could take a few minutes.
                        <br /><br />
                        <script type="text/javascript">display_pic('HU-SelectDeviceDriver-HaveDisk', 'Window', '03R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('HaveDisk', 'Button', '03R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallFromDisk-Browse', 'Window', '03R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Browse', 'Button', '03R2');</script> and
                        navigate to the folder where you un-ZIPped the QCOM driver.
                        <br /><br />
                        <script type="text/javascript">display_pic('LocateFile', 'Window', '03R2');</script>
                        <br /><br />
                        Highlight (single-click) <script type="text/javascript">display_pic('QCOM', 'INF', 'XP');</script> and
                        click <script type="text/javascript">display_pic('Open', 'Button', '03R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('InstallFromDisk-OK', 'Window', '03R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('OK', 'Button', '03R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HU-SelectDeviceDriver-Next', 'Window', '03R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Next', 'Button', '03R2');</script>
                        <br /><br />
                        <script type="text/javascript">display_pic('HU-FinishedInstalling', 'Window', '03R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Finish', 'Button', '03R2');</script> to close
                        the Hardware Update Wizard.
                        <br /><br />
                        <script type="text/javascript">display_pic('DM-QCOM-Confirmation', 'Window', '03R2');</script>
                        <br /><br />
                        Click <script type="text/javascript">display_pic('Black-X', 'Button', '03R2');</script> to close
                        the Device Manager (<b>Computer Management</b>) window. The QCOM driver is now
                        installed and ready to use.
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Install_Driver_03R2 ?>
                </div>                  <? // end of Installation_Topics ?>
                <?  //--------------------------------------------------------
                    // Software Manual / User Guide
                    //--------------------------------------------------------
                ?>
                <div class="category" id="Software_Manual"
                    onclick="expand_collapse('Software_Man')"
                    ondblclick="expand_collapse('Software_Man')"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/SpinStar.gif" class="spinStar" />
                    Software User Guide
                </div>
                <div class="invisible" id="Software_Man" lang="QD">
                    <div style="text-align:center; margin-top:10px; margin-bottom:10px;">
                        <script type="text/javascript">display_pic('Home-Readout-Tab', 'Manual', 'W7', '800');</script>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_Overview')"
                        ondblclick="expand_collapse('Software_Overview')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Software Overview
                    </div>              <? // end of Software Overview ?>
                    <div class="subtopic" id="Software_Overview" lang="QD">
                        The Quartzdyne<sup>&reg;</sup> QCOM&trade; software is a program that allows testers to monitor, control,
                        track, and record information about Quartzdyne transducers. The software is designed
                        to run on most modern Microsoft<sup>&reg;</sup> Windows<sup>&trade;</sup> operating environments,
                        using a compatible and familiar graphical user interface. The tester controls the
                        operations of the QCOM software by mouse and keyboard. The primary
                        operations of the software can be categorized into <b>Sampling</b>, <b>Logging</b>,
                        <b>Testing</b>, <b>Utilities</b>, <b>Expert</b>, and <b>Help</b>, although there
                        is some overlap in function between various operations.
                        <br /><br />
                        The major functions of the software are grouped by similar tasks into the
                        <script type="text/javascript">jump_within_doc('Readout', 'Readout_Tab', 'Software_Readout');</script>,
                        <script type="text/javascript">jump_within_doc('Utilities', 'Utilities_Tab', 'Software_Utilities');</script>, and
                        <script type="text/javascript">jump_within_doc('Testing', 'Testing_Tab', 'Software_Testing');</script> tab
                        pages. Each tab page displays a header that presents general controls and information, plus
                        one group panel below the header for tabs to all the units detected by the software.
                        <br /><br />
                        If you move your mouse pointer over any active controls (buttons, labels, boxes, etc.) on
                        any of the tab pages, the software will display a short description of the control.
                        <br /><br />
                        <script type="text/javascript">jump_within_doc('Sampling', 'Data_Sampling', 'Software_Readout');</script> is
                        the acquisition of transducer data,
                        and can include pressure, temperature, voltage, and current readings. The software
                        can display the pressure and temperature data by frequency, frequency counts,
                        standard units, and alternate units, then capture (log) this data, as needed.
                        <br /><br />
                        <script type="text/javascript">jump_within_doc('Logging', 'Data_Logging', 'Software_Logging');</script> is
                        the capture and storage of the sampled
                        data. At present, data logging is limited to acquired transducer readings, but
                        can change to include other measurements in future versions of the software.
                        <br /><br />
                        The <script type="text/javascript">jump_within_doc('Utilities', 'Utilities_Tab', 'Software_Utilities');</script> section
                        provides the interface for logging, plus a few tools for downloading, importing, and saving
                        coefficient files, testing hex files, and others.
                        <br /><br />
                        <script type="text/javascript">jump_within_doc('Testing', 'Testing_Tab', 'Software_Testing');</script> is
                        available in a software test fixture, for either QCOM modules, Quartzdyne transducers, or both.
                        <br /><br />
                        An <script type="text/javascript">jump_within_doc('Expert (Advanced) Mode', 'Expert_Tab', 'Software_Expert');</script> provides
                        additional utilities, controls, and information about the hardware or software,
                        but is primarily for testers who are familiar with the technical details
                        involved with associated Quartzdyne products and the QCOM software itself.
                        <br /><br />
                        Help for the QCOM software and other Quartzdyne products is available by several
                        means. A small popup About window lists the program build and copyright. The Online Help
                        takes the tester to this page. You can also generate a Support Log with the software, to capture
                        detailed and technical information about your hardware and software configuration, for you
                        to send to Quartzdyne's <a href="<?=mailSite ?>?emailSubject=<?=emailSubject ?>&dest=support" target="_blank">Support Team</a>.
                        To check whether an update to the software is available online, you can click Check for Update.
                        Finally, you can record mouse clicks and resulting errors in an
                        <script type="text/javascript">jump_within_doc('event log', 'Event_Log', 'Software_Troubleshooting');</script>
                        (in Expert Mode) that you can examine or submit to our support team for review.
                        <br /><br />
                        In the software, this user guide, and related QCOM documentation the terms <i>unit</i> and <i>module</i> are
                        often used interchangeably, although the term <i>module</i> can refer more specifically
                        to the QCOM hardware box alone, and <i>unit</i> to the combination transducer / module
                        (and possibly cabling and firmware) assembly, depending on context.
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Software_Overview ?>
                    <div class="topic"
                        onclick="expand_collapse('Software_Startup')"
                        ondblclick="expand_collapse('Software_Startup')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        At Startup<a name="At_Startup"></a>
                    </div>              <? // end of At Startup ?>
                    <div class="subtopic" id="Software_Startup" lang="QD">
                        When you start the software running, it performs a number of startup tasks, in
                        the following order (not an exhaustive list):
                        <ol>
                            <li style="list-style-type:disc;">
                                Checks to make sure the QCOM software is not already running
                            </li>
                            <li style="list-style-type:disc;">
                                Processes any specified command-line parameters
                            </li>
                            <li style="list-style-type:disc;">
                                Allocates and initializes internal structures and other data elements
                            </li>
                            <li style="list-style-type:disc;">
                                Creates the error log, and the
                                <script type="text/javascript">jump_within_doc('event log', 'Event_Log', 'Software_Troubleshooting');</script>
                                if you have selected to do so
                            </li>
                            <li style="list-style-type:disc;">
                                Determines the Windows version of your computer
                            </li>
                            <li style="list-style-type:disc;">
                                Ensures the QCOM driver and DLL are in place
                            </li>
                            <li style="list-style-type:disc;">
                                Scans your computer for all attached QCOM modules and transducers, during
                                which the software performs the following for each module or unit (module / transducer pair):
                                <ol>
                                    <li style="list-style-type:circle;">
                                        Determines whether a QCOM module is attached, and retrieves its
                                        serial number if one is found
                                    </li>
                                    <li style="list-style-type:circle;">
                                        Determines whether the module is currently in Boot Loader Mode,
                                        and if it is, resets it to Application Mode
                                    </li>
                                    <li style="list-style-type:circle;">
                                        Opens a handle to the module for subsequent access
                                    </li>
                                    <li style="list-style-type:circle;">
                                        Checks the <a href="<?=Wiki_Dir ?>Windows_Registry" title="Windows Registry" target="_blank">Windows System Registry</a> for
                                        the presence of the key corresponding to the module serial number, and
                                        if the key is absent, enters Boot Loader Mode and then Application Mode,
                                        thereby forcing the system to record the module, preventing
                                        unnecessary user intervention later
                                    </li>
                                    <li style="list-style-type:circle;">
                                        Retrieves the module firmware ID
                                    </li>
                                    <li style="list-style-type:circle;">
                                        Sets the unit <a href="<?=Wiki_Dir ?>I%C2%B2C" target="_blank">I<sup>2</sup>C</a> data
                                        rate to the maximum (100 kHz)
                                    </li>
                                    <li style="list-style-type:circle;">
                                        Determines whether a Quartzdyne transducer is connected to the attached
                                        module, and if one is, retrieves its type (frequency, digital, with / without
                                        memory, early / advanced, etc.), chip ID (ASIC / FPGA, version, etc.), and
                                        basic communication ability
                                    </li>
                                    <li style="list-style-type:circle;">
                                        Retrieves the coefficient data currently stored in the transducer if
                                        a digital transducer with memory is attached, or the coefficient data
                                        currently stored in the module if one is not, then verifies the integrity
                                        of the data, interprets the data
                                    </li>
                                    <li style="list-style-type:circle;">
                                        Constructs the transducer description from the unit number, module serial
                                        number, transducer serial number, and chip ID
                                    </li>
                                    <li style="list-style-type:circle;">
                                        Changes the transducer reference signal from 7.2 MHz to 1 kHz
                                    </li>
                                    <li style="list-style-type:circle;">
                                        Takes one transducer reading sample for a quick sanity check and
                                        initial display purposes
                                    </li>
                                </ol>
                            </li>
                            <li style="list-style-type:disc;">
                                Retrieves the config data saved from the previous run of the software
                            </li>
                            <li style="list-style-type:disc;">
                                Determines the presence of past data log, test results, event log, error log,
                                and other data files
                            </li>
                            <li style="list-style-type:disc;">
                                Sets the foundation for the GUI by installing icons, images, and sounds, then
                                initializes the program GUI components and the infrastructure for the
                                windows and their contents
                            </li>
                            <li style="list-style-type:disc;">
                                Constructs the Opening ('Home') Window, its tool strip, and status strip
                            </li>
                            <li style="list-style-type:disc;">
                                Determines whether the software has access to the internet, then checks
                                whether the installed versions of the DLL, software, and firmware match
                                those recorded on Quartzdyne's website, and prompts for download and installation
                                of these items if they don't
                            </li>
                            <li style="list-style-type:disc;">
                                Checks whether the attached module is attached to a transducer, and displays
                                a warning if one is not found, or is found but has failed the sanity check
                            </li>
                            <li style="list-style-type:disc;">
                                Determines whether the attached transducer contains no memory, and if that
                                is the case, will prompt you with
                                <br /><br />
                                <script type="text/javascript">display_pic('Analog-XD-Present', 'Manual', 'W7', '300');</script>
                                <br /><br />
                                to ensure that the coefficient data residing in module memory matches the data
                                that should correspond to the attached transducer. Click <b>Yes</b> to accept
                                the transducer coefficient data as it exists in the module, or click <b>No</b> to
                                have the software prompt you for a coefficient data file of a different transducer.
                            </li>
                            <li style="list-style-type:disc;">
                                Constructs the tabbed pages, sets up their group boxes and contents, sets
                                their sizes, populates the components with appropriate values, initializes
                                the interface, then finally displays the Opening Window
                            </li>
                        </ol>
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Software_Startup ?>
                    <div class="topic"
                        onclick="expand_collapse('Software_Home')"
                        ondblclick="expand_collapse('Software_Home')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Opening Window<a name="Opening_Window"></a>
                    </div>              <? // end of Opening Window ?>
                    <div class="subtopic" id="Software_Home" lang="QD">
                        When the software first appears, it presents you with the program name, software
                        version, the tool strip, the <b>hardware summary line</b>, the tab pages, an exit button,
                        one or three LED buttons, the status bar, the main progress bar, and the current
                        date-and-time.
                        <br /><br />
                        The <b>hardware summary line</b> displays in green text the number of QCOM modules and
                        Quartzdyne transducers the software discovered the last time it attempted to scan
                        for hardware changes, the first of which is at program startup. The frequency at
                        which the software will scan for these changes is set by the Poller, a feature controlled in
                        <script type="text/javascript">jump_within_doc('Expert Mode', 'Expert_Tab', 'Software_Expert');</script>,
                        and should not be changed in most normal operations.
                        <br /><br />
                        The three LEDs on the right side of the window indicate whether the software
                        is sampling, logging, or testing at the moment. All three LEDs are also active
                        buttons that can be used to start or stop these respective functions. If the software
                        is run in Expert Mode, a fourth LED is displayed, to indicate whether the Send
                        Transducer Readings function is running.
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Software_Home ?>
                    <div class="topic"
                        onclick="expand_collapse('Software_Readout')"
                        ondblclick="expand_collapse('Software_Readout')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';"
                        name="Sampling">
                        Readout Operations<a name="Readout_Tab"></a>
                    </div>              <? // end of Readout Operations ?>
                    <div class="subtopic" id="Software_Readout" lang="QD">
                        The operations presented by the Readout tab page, which is the tab page first
                        presented on the opening window, include transducer readings and basic hardware
                        configuration.
                        <a name="Data_Sampling"></a>Click <b><i>Start Sampling</i></b> to begin sampling all
                        attached transducers that are included in sampling. This button will not
                        cause the data to be logged unless Logging has already been started.
                        <br /><br />
                        Click <b><i>Start All Logging</i></b> to begin logging the data that is being
                        sampled. If Sampling has not yet been started, this action will also
                        start the Sampling for all transducers that are
                        <script type="text/javascript">jump_within_doc('Included in Sampling', 'Included_In_Sampling', 'Software_Readout');</script>.
                        <br /><br />
                        The <a name="Sampling_Interval"></a>Sampling <b><i>Interval</i></b> (<b>Time Between Samples</b>) is
                        the minimum amount of time between moments when transducer measurements are acquired
                        during Sampling, and can bet set between 20 ms and 500 hours (just under 21 days),
                        inclusive.
                        <br /><br />
                        <a name="Sampling_Time_Limit"></a>If <b>Run for a specified time</b> is checked,
                        you can have the software stop sampling after the number of minutes you specify;
                        otherwise, Sampling will continue until you stop it, or it encounters a DLL error.
                        <br /><br />
                        <a name="Display_Frequencies"></a>Besides displaying the actual pressure and temperature
                        values, you can also display the corresponding frequencies as they are presented by
                        the transducer if you check <b>Display frequencies for this transducer</b> for the
                        unit whose measurements you want to display. You can do the same for all attached
                        units if you check <b>Display frequencies for all transducers</b>.
                        <br /><br />
                        <script type="text/javascript">display_pic('Sampling-With-Frequencies', 'Manual', 'W7', '600');</script>
                        <br /><br />
                        <a name="Included_In_Sampling"></a>By default, the software includes all
                        attached modules and transducers (units) in the sampling when Sampling is
                        started. To keep any of them from being sampled, un-check the <b>Include this
                        unit in sampling</b> box for each unit that you don't want sampled. You can also
                        check or un-check <b>Include all units in sampling</b> to include or exclude all
                        attached units, respectively. Note that the <b>Include this unit in sampling</b> and
                        <b>Include all units in sampling</b> boxes are only present if more than one
                        transducer is attached.
                        <br /><br />
                        You can select the default pressure units (psi) and temperature units (Celsius), or any
                        of several alternate units of each. This selection is reflected in the Data Logging
                        section of the software.
                        <br /><br />
                        You can direct the software to display the actual pressure and temperature in your
                        selected units or in frequency counts, represented in either decimal or hexadecimal.
                        Select the actual pressure and temperature to display from 0 to 7 decimal points
                        of accuracy.
                        <br /><br />
                        Along with pressure and temperature controls, the software will also display
                        some useful hardware and firmware information. These include the module serial
                        number, the transducer type (digital, analog/frequency, memory/no-memory) and serial number
                        (if available), and the firmware version.
                        <br /><br />
                        <a name="Graphing"></a>The software can also display a real-time graph of the pressure,
                        temperature, and current draw (of the transducer) if you click the <b><i>Display Graph</i></b>
                        button.
                        <br /><br />
                        <script type="text/javascript">display_pic('Graphing-Unit', 'Manual', 'W7', '600');</script>
                        <br /><br />
                        While the software is sampling one or more transducers, it will display the elapsed time
                        it has been sampling since you started it, in one-second increments.
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Software_Readout ?>
                    <div class="topic"
                        onclick="expand_collapse('Software_Logging')"
                        ondblclick="expand_collapse('Software_Logging')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';"
                        name="Logging">
                        Data Logging<a name="Data_Logging"></a>
                    </div>              <? // end of Data Logging ?>
                    <div class="subtopic" id="Software_Logging" lang="QD">
                        Data logging is the capture of acquired data. The data logging capability in
                        the QCOM software is currently set to capture only data that is being sampled
                        from the transducer, but can easily be expanded to include data from other sources
                        in the future. Testing, on the other hand, uses a separate data capturing
                        mechanism within the software instead of the data logging interface discussed here.
                        <br /><br />
                        The <i>data log</i> is specifically the box (lavender when idle, green when logging)
                        that displays the lines of entry numbers, dates and/or times, plus the data points (pressure,
                        temperature, voltage, etc., values) you have selected to be displayed. All the contents
                        of the data log are stored in a 4 MB section of memory. When the logged data approaches
                        the memory limit, it are moved to a file, at which point the data log and its associated
                        memory are cleared. The data log is captioned with abbreviations that represent the data
                        points currently being logged.
                        <br /><br />
                        <script type="text/javascript">display_pic('Data-Log-All', 'Manual', 'W7', '600');</script>
                        <br /><br />
                        From the <script type="text/javascript">jump_within_doc('Utilities', 'Utilities_Tab', 'Software_Utilities');</script> tab,
                        you can invoke the data logging controls and displays by selecting either the
                        <b><i>Display All Data Logging Controls</i></b> button in the General Utilities header box,
                        or the <b><i>Display Unit Data Logging Controls</i></b> button in the unit
                        group panel below the header. The first button will display the controls, current status,
                        and logged data for all detected transducers. The second button will display the
                        same for only the selected transducer, but will allow you more explicit control
                        of the data being logged and/or displayed.
                        <br /><br />
                        When you start data logging, the software will display the logging start date and
                        time, along with the logging interval, module serial number, and transducer serial
                        number if they are available. When you stop data logging, the software will likewise
                        display the stop date and time, along with the same serial numbers that are available.
                        Note that the data points to be logged can only be specified in the unit logging
                        windows, accessed by the <b><i>Display Unit Data Logging Controls</i></b> buttons.
                        <br /><br />
                        <script type="text/javascript">display_pic('Data-Logging-All', 'Manual', 'W7', '600');</script>
                        <br /><br />
                        Click <b><i>Save Data Log</i></b> or <b><i>Save All Logs</i></b> to store the
                        data you have already logged ni a file of your choice. Click <b><i>Clear Data
                        Log</i></b> or <b><i>Clear All Data Logs</i></b> to erase the data you have logged
                        in memory so far. Click <b><i>Change Data Log File</i></b> to select a different
                        filename to store your logged data. If you do not select a filename to store your
                        logged data, the software will select one for you, constructed from the module
                        serial number, transducer serial number, and the creation date. <b>Note:
                        In <script type="text/javascript">jump_within_doc('Expert Mode', 'Expert_Tab', 'Software_Expert');</script>,
                        you will not be prompted to confirm your attempt to clear the data log.</b>
                        <br /><br />
                        Similar to the <script type="text/javascript">jump_within_doc('Sampling Interval', 'Sampling_Interval', 'Software_Readout');</script>,
                        the Logging <b><i>Interval</b></i> is the minimum amount of time between moments
                        when transducer measurements are acquired during Sampling, and can be set between
                        20 ms and 500 days (just under 21 days), inclusive.
                        <br /><br />
                        Select the actual pressure and temperature to display and record from 0 to 7 decimal points
                        of accuracy. Check <b><i>Wrap text in display box</i></b> to see logged text that might
                        have scrolled off the right of the box. Check <b><i>Display caption in log</i></b> to
                        display the caption for the data points in the data log box. Check <b><i>Embed caption
                        in file</i></b> to display the caption for the data points in the file, should the
                        data log get saved to a file.
                        <br /><br />
                        When you or the software stop the data logging, you can also display a summary
                        of the displayed data if you check <b><i>Display summary when stopped</i></b> or <b><i>Display
                        all summaries</i></b>. The summary is headed by a line that displays the elapsed logging
                        time, along with the number of logged samples. The summary header is followed by lines that
                        display the lowest value, highest value, and average value of all the data points just
                        logged.
                        <br /><br />
                        <script type="text/javascript">display_pic('Data-Log-Summary', 'Manual', 'W7', '600');</script>
                        <br /><br />
                        By default, the software will automatically save your logged data to the data log
                        file listed on the window, and the <b><i>Auto-save the data log</i></b> button will be
                        selected. If you want the software to prompt you before saving the data (because
                        the 4 MB data log in memory is full, or you have chosen to quit the software, for
                        example), select <b><i>Prompt to save the data log</i></b> instead. By default, the software
                        will append your logged data to the data log file listed on the window, and
                        the <b><i>Append the data log</i></b> button will be selected. If you want to over-write
                        each file write by the software to the file, select <b><i>Over-write the data log</i></b> instead.
                        <br /><br />
                        If you need to insert a text comment into the data log, you can do so in the
                        box after <b><i>Add a comment to the log:</i></b> or <b><i>Add a comment to all the logs</i></b>.
                        Note that these comments entry boxes are independent, so that each data log has its
                        own comment box that will display a comment only in its data log. Also, you can
                        also display a particular comment in all the data logs.
                        <br /><br />
                        When <script type="text/javascript">jump_within_doc('Expert Mode', 'Expert_Tab', 'Software_Expert');</script> is
                        enabled, the software will display a progress bar for each data log, indicating
                        how much of its 4 MB data log buffer is filled.
                        <br /><br />
                        <script type="text/javascript">display_pic('Data-Logging-Expert', 'Manual', 'W7', '600');</script>
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Software_Logging ?>
                    <div class="topic"
                        onclick="expand_collapse('Software_Testing')"
                        ondblclick="expand_collapse('Software_Testing')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Testing<a name="Testing_Tab"></a>
                    </div>              <? // end of Testing ?>
                    <div class="subtopic" id="Software_Testing" lang="QD">
                        <script type="text/javascript">display_pic('Testing-Tab', 'Manual', 'W7', '800');</script>
                        <br /><br />
                        The Testing tab presents the <b>QCOM Software Test Fixture</b>,
                        which is the software platform for testing QCOM modules, Quartzdyne transducers,
                        and the QCOM software itself. The <a href="<?=QCOM_PkgDir ?>QCOM-Test-Procedure.pdf" target="_blank">Official QCOM Testing Procedure</a> makes
                        use of the software test fixture to qualify QCOM modules for customer use.
                        <br /><br />
                        Each of the tests presented are known as the <b>major</b> tests, which are no more
                        than collections of more granular, or <b>minor</b> tests themselves. Minor tests often
                        rely on smaller, localized <b>micro</b> tests to provide the results of testing the
                        most detailed features of the module, transducer, or software.
                        <br /><br />
                        The test results log is a text box (lavender when idle, green when testing) that
                        displays the tests that have completed, the tests currently running, and their
                        results, if so selected. You can elect to display the summary test results (not
                        detailed), complete test results (detailed), or no test results at all. The software
                        displays a progress bar of the current loop for each unit being tested just under
                        the test results log, indicating what percent of the selected tests have completed.
                        <br /><br />
                        <script type="text/javascript">display_pic('Testing', 'Manual', 'W7', '600');</script>
                        <br /><br />
                        Once you have checked the tests you want to run, click <b><i>Run Selected Tests</i></b> to
                        start the tests running on the particular unit you select, or <b><i>Test All Units</i></b> to
                        start the tests running on all attached units.
                        <br /><br />
                        Click <b><i>Reset All Tests</i></b> to un-check all selected tests for all units.
                        Click <b><i>Save Test Results</i></b> or <b><i>Save All Results</i></b> to store
                        the test results in a file of your choice. Click <b><i>Clear Test Results</i></b> or
                        <b><i>Clear All Results</i></b> to clear (erase) the test results log.
                        <br /><br />
                        Check <b><i>Run the tests in a loop</i></b> to repeat the selected tests as many times
                        as you select, or indefinitely. Note that if you check <b><i>Loop forever</i></b> to run
                        the tests indefinitely, the events that can stop the testing include a deliberate click to stop
                        the tests, any kind of error if <b><i>Stop on errors</i></b> is checked, or no more
                        memory is available to hold the test results if <b><i>Append new results to current results</i></b> is
                        checked.
                        <br /><br />
                        When you run the tests in a loop, a small loop counter just above the test results
                        log will display the current loop number. The results will reflect the loop
                        whose results are being displayed, plus the amount time the loop has taken
                        to complete, along with the total test time completed up to that point. You can
                        elect to run the tests in a loop from 1 through 9999 times, inclusive, if you
                        do not check <b><i>Loop forever</i></b>.
                        <br /><br />
                        If you check <b><i>Stop on errors</i></b> the software will immediately terminate the
                        testing on any unit that encounters any error of any kind. The remaining units
                        that are running tests will continue to run if they do not also encounter errors.
                        <br /><br />
                        By default, the software will display the summary test results; that is, it will
                        only display the names of the major tests (the names of the ones you selected) that
                        were run and their results (Pass or Fail). If you check <b><i>Detailed results</i></b> or
                        <b><i>Detailed test results</i></b>, the software will display the names (and some
                        descriptions) of all the (major, minor, and micro) tests and their results,
                        along with the dot-leader progress of some tests that take a long time to run.
                        <br /><br />
                        Check <b><i>Auto-save the test results to file</i></b> if you want the software to save
                        the test results to the Test Results File without prompting you to do so. This will
                        also cause the test fixture to save all test results automatically when you exit the
                        software.
                        <br /><br />
                        The major tests included in the software test fixture are grouped into <b>Unit Tests</b> and
                        <b>Transducer Tests</b>. By default, the software displays only the Unit Tests, which
                        are used to test the QCOM module and (indirectly) the software. You can display the
                        Transducer Tests if you check <b><i>Display transducer tests</i></b>, which apply only
                        to transducer health and verification.
                        <br /><br />
                        <b>Unit Tests</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                The Unit <b>Memory Test</b> saves the original contents of the QCOM module
                                memory, writes a variety of patterns (including a zero pattern) to the
                                memory, reads them back to verify the patterns, then restores the original
                                memory contents. One of the memory test patterns is defined by the
                                <b>Test Data File</b>, which you specify, and is a hex file that contains
                                artificial coefficient data specially formulated for testing. This is
                                then repeated for all four memory pages. The software performs all operations
                                using the firmware interface.
                            </div><br />
                            <div style="margin-left:40px;">
                                The <b>I<sup>2</sup>C Test</b> verifies the QCOM module's ability to communicate
                                via I<sup>2</sup>C by sending the module a series of predetermined I<sup>2</sup>C commands
                                over its bus and verifying their results with expected results. These
                                commands include reading pressure and temperature, checking for command
                                acknowledge (ACK), retrieving status and ID, and reading and writing to
                                the onboard ASIC / EEPROM. The commands are sent in a particular sequence, then
                                in a random order, for each possible setting of the I<sup>2</sup>C baud
                                rate, from 33.3 kHz to 100.0 kHz, inclusive, in 0.1 kHz increments.
                            </div><br />
                            <div style="margin-left:40px;">
                                The <b>Readings Test</b> takes a variety of readings from the attached transducer
                                and compares them with expected values, and so requires that an actual Quartzdyne
                                transducer be attached to the QCOM module. This test also requires manual
                                intervention by the tester to remove and re-attach the physical transducer
                                to the module, and so cannot be run in a loop unattended. Among the readings
                                verified are voltage and current readings and over-current handling. The
                                two (503 &Omega; and 150 &Omega;) QCOM test resistors are required for
                                the Readings Test, so that you can swap them with the transducer as
                                directed by the test prompts.
                            </div><br />
                            <div style="margin-left:40px;">
                                The <b>Firmware Test</b> verifies the ability of the QCOM module to change to
                                Boot Loader Mode, read the firmware Device Information, set the firmware page,
                                write and read and verify firmware page information, set the firmware key
                                codes, then return to Application Mode. Some of the required page information
                                originates from a <b>Test Firmware File</b>, which the software will prompt
                                you for if it cannot locate the test file, and is a hex file that contains
                                artificial firmware data specially formulated for testing.
                            </div><br />
                            <div style="margin-left:40px;">
                                The <b>X2</b>, <b>X3</b>, and <b>X4 Test</b>s are place-holders for future tests,
                                and always post successful results, but are mandatory to pass the QCOM unit
                                tests.
                            </div><br />
                        <b>Transducer Tests</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                The <b>Communication Test</b> ensures that communication between the QCOM
                                module and the transducer can occur at all acceptable rates (33.3 kHz to 100.0 kHz,
                                inclusive, in 0.1 kHz increments) by sending and requesting numerous commands in
                                random order, and verifying the contents of each I<sup>2</sup>C packet it
                                transmits and receives.
                            </div><br />
                            <div style="margin-left:40px;">
                                If the software detects the presence of a frequency (analog) transducer, it
                                will present the <b>Analog Integrity Test</b>; otherwise, it will present the
                                <b>Digital Integrity Test</b>. Each test verifies the transducer's ability
                                to output digital frequency (for frequency transducers) or frequency counts
                                (for digital transducers) within given parameters, within a certain
                                period of time, held to a specific level of accuracy.
                            </div><br />
                            <div style="margin-left:40px;">
                                If the software detects the presence of a digital transducer with an ASIC, it
                                will present the <b>ASIC Memory Test</b>; otherwise, it will present the
                                <b>FPGA Memory Test</b>. If the software detects the presence of a frequency
                                (analog) transducer, it will disable the text of the test name. The ASIC / FPGA
                                Memory Test performs the same tasks as those in the Unit Memory Test, except
                                that the software performs all operations using the I<sup>2</sup>C interface.
                            </div><br />
                        <b>QCOM Test States</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                The software will display the <b style="color:green">Untested</b> state if
                                no tests have been run on the unit.
                            </div><br />
                            <div style="margin-left:40px;">
                                The <b style="color:purple">Running</b> state indicates that the unit is currently running
                                tests, and is accompanied by the display of the testing time elapsed for
                                the unit.
                            </div><br />
                            <div style="margin-left:40px;">
                                <b style="color:blue">Passed</b> indicates that all required major, minor,
                                and micro tests have both run and completed without any errors detected
                                by the software during the testing.
                            </div><br />
                            <div style="margin-left:40px;">
                                <b style="color:red">Failed</b> indicates that at least one error was
                                detected by the software during the testing in the major, minor, and
                                micro tests.
                            </div><br />
                            <div style="margin-left:40px;">
                                The software will display <b style="color:olivedrab">Incomplete</b> if
                                all selected tests have completed successfully, but not all tests that
                                are required for QCOM module qualification have run.
                            </div><br />
                            <div style="margin-left:40px;">
                                <b style="color:olivedrab">Stopped</b> indicates that the tests have been
                                terminated by manual intervention or another control outside the software
                                test fixture.
                            </div><br />
                            <div style="margin-left:40px;">
                                The displayed names of the major tests next to the check boxes themselves also
                                give test state indicators to a lesser extent. If the test name appears
                                in <b>black</b>, the particular major test has not yet been run since the
                                program started or since the last time the test results were cleared. If
                                it appears in <b style="color:blue">blue</b>, the test has been run, and
                                has completed successfully (passed). If it appears in <b style="color:red">red</b>, the
                                test has been run, but at least one major, minor, or micro test has failed.
                            </div><br />
                        Check <b><i>Append new test results to current results</i></b> to keep the results of the
                        previous test run from being erased when you re-run the tests or run another test.
                        Uncheck it to over-write the existing test results with the results of the currently
                        running tests. Note that appending the test results will eventually fill the software's
                        1 MB test results buffer, forcing the software to pause the testing and prompt you to
                        save the results in a file, if <b><i>Auto-save the test results to file</i></b> is not checked.
                        <br /><br />
                        At times, the software will display results lines that are longer than the width of
                        the test results log box, resulting in the text scrolling off the right side of the
                        box. Check <b><i>Wrap text in all test results display boxes</i></b> to display all the text
                        of the results by wrapping each excessively long.
                        <br /><br />
                        Check <b><i>Time stamp lines</i></b> if you want the software to date-and-time stamp every
                        line it displays in the test results log.
                        <br /><br />
                        If you want to add one or more comments to the test results log, simply type the
                        text in the <b><i>Add a comment to all the results:</i></b> display box and click <b><i>Add</i></b>. To
                        include the date-and-time stamp at the beginning of your text line, check <b><i>Time stamp
                        comments</i></b> before you add the text. Click <b><i>Clear</i></b> to clear (erase) the comment
                        text from the comment display box. Note that the text you insert will be copied to
                        the test results logs of all units.
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Software_Testing ?>
                    <div class="topic"
                        onclick="expand_collapse('Software_Utilities')"
                        ondblclick="expand_collapse('Software_Utilities')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Utilities<a name="Utilities_Tab"></a>
                    </div>              <? // end of Utilities_Tab ?>
                    <div class="subtopic" id="Software_Utilities" lang="QD">
                        <script type="text/javascript">display_pic('Utilities-Tab', 'Manual', 'W7', '800');</script>
                        <br /><br />
                        The Utilities tab presents you with a variety of tools to help you with transducer,
                        coefficient, or QCOM tasks. These include data logging, analog coefficient conversion,
                        coefficient check reporting, QCOM reset, and hex file verification.
                        <br /><br />
                        <b>Data Logging Controls</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                The <script type="text/javascript">jump_within_doc('data logging controls', 'Data_Logging', 'Software_Logging');</script>, invoked
                                by <b><i>Display All Data Logging Controls</i></b> and <b><i>Display Unit Data Logging Controls</i></b>,
                                give you complete control over the display and capture of <script type="text/javascript">jump_within_doc('data sampling', 'Data_Sampling', 'Software_Readout');</script> in
                                an all-inclusive or individual windows, respectively. You can then save the resulting
                                captured data to files of your choice, or to files pre-selected by the software.
                            </div><br />
                        <b>Module Reset</b><a name="Reset_Module"></a>
                        <br /><br />
                            <div style="margin-left:40px;">
                                Click <b><i>Reset All Units</i></b> or <b><i>Reset Module</i></b> to
                                reset the attached QCOM modules and associated software. As a result, the
                                software will reset its settings to default, except for file paths, such as
                                those for the test data file, the firmware file, and coefficient data files.
                                The software will also re-draw its screens to reflect the resulting changes,
                                if any. The module will be reset to its starting state and re-enumerated for
                                system device scanning. Coefficient data residing in transducer and module
                                memory will be unaffected.
                                <br /><br />
                                <script type="text/javascript">display_pic('Reset-All', 'Manual', 'W7', '240');</script>&nbsp;&nbsp;
                                <script type="text/javascript">display_pic('Reset-Module', 'Manual', 'W7', '190');</script>
                            </div><br />
                        <b>Transducer Reset</b><a name="Reset_Transducer"></a>
                        <br /><br />
                            <div style="margin-left:40px;">
                                Click <b><i>Reset Transducer</i></b> to reset the transducer circuitry state
                                for the unit. Memory contents of transducers containing memory will be
                                unaffected.
                            </div><br />
                        <b>Importing and Exporting Coefficient Data</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                Click <b><i>Import Coefficient Data File</i></b> to prompt you for a coefficient
                                data file to read into the QCOM module, replacing the coefficient data currently
                                residing in its memory. If the software detects the presence of the Calibration
                                database, it will also ask whether you want to search the database for the
                                coefficient file, or whether you would like to browse your computer for it.
                                If the module is attached to a digital transducer with memory, the software
                                will also copy the coefficient data to all four of its memory pages. The software
                                expects the coefficient data file in either the
                                Intel<sup>&reg;</sup> <a href="<?=Wiki_Dir ?>Intel_HEX" title="Intel Hex File Format" target="_blank">Hex File Format</a>
                                or the proprietary Quartzdyne <a href="<?=QD_PDFDir ?>FreqManual.pdf" title="Explanation of the Quartzdyne proprietary coefficient format" target="_blank">analog coefficient data format</a>.
                            </div><br />
                            <div style="margin-left:40px;">
                                Click <b><i>Export Coefficient Data File</i></b> to copy the coefficient data
                                currently occupying QCOM module memory to a file of your choice. The software
                                will only save this data in the Intel<sup>&reg;</sup> <a href="<?=Wiki_Dir ?>Intel_HEX" title="Intel Hex File Format" target="_blank">Hex File Format</a>,
                                and prompt you for a filename to save the file. Note that the Export function
                                will always save the coefficient data in a Hex File Format, even if the imported
                                data originated in another format.
                            </div><br />
                        <b>Downloading Coefficient Files</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                If you don't already have a copy of the coefficient data files that correspond
                                to your particular transducer, you can <a href="<?=coeffSite ?>" title="Coefficient Download Page" target="_blank">download</a>
                                them from our webite or click the <b><i>Download Coefficient Files</i></b> button if
                                the software is running on a computer that has web access.
                            </div><br />
                        <b>Coefficient File Parameter Display</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                To display a coefficient data file by its parameters, along with the parameter
                                names, click <b><i>Display Coefficient File Parameters</i></b>. This shows the
                                contents of the selected coefficient data file, and can be performed on
                                <code>.crf</code>, <code>.crt</code>, <code>.cff</code>, <code>.cft</code>,
                                and <code>.hex</code> files that conform to the Quartzdyne
                                <a href="<?=QD_PDFDir ?>FreqManual.pdf" target="_blank">analog coefficient data format</a>.
                                Like usual, if the software detects the presence of the Calibration database,
                                it will prompt you whether to search the database for the coefficient data file.
                                <br /><br />
                                <script type="text/javascript">display_pic('Coeff-Param-XD-SN-Prompt', 'Manual', 'W7', '300');</script>&nbsp;&nbsp;
                                <script type="text/javascript">display_pic('Coeff-Param-DB-Search', 'Manual', 'W7', '260');</script>
                                <br /><br />
                                The display for a typical <code>.hex</code> file looks like this:
                                <br /><br />
                                <script type="text/javascript">display_pic('Coeff-Param-HEX-Display', 'Manual', 'W7', '600');</script>
                                <br /><br />
                                Click <b><i>Display Native Ref Files</i></b> to display the parameters of the
                                corresponding <code>.crf</code> and <code>.crt</code> files or <b><i>Display Native
                                Non-ref Files</i></b> to display the parameters of the corresponding <code>.cff</code>
                                and <code>.cft</code> files. The display for a typical <code>.crx</code> file pair
                                appears as follows:
                                <br /><br />
                                <script type="text/javascript">display_pic('Coeff-Param-CRF-Display', 'Manual', 'W7', '600');</script>
                            </div><br />
                        <b>Native Coefficient File Conversion</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                To convert a set of native coefficient data files into a single hex file,
                                you can always <b>Import</b> the files, then <b>Export</b> the resulting hex
                                format file. The drawback of that method is that the imported coefficient data
                                replaces that of the attached digital transducer (if the transducer contains
                                memory) and of the QCOM module. On occasion it might be necessary to perform
                                such a data set conversion without disturbing the contents of the transducer
                                or module memory.
                            </div><br />
                            <div style="margin-left:40px;">
                                Click <b><i>Convert a Native File Set</i></b> to have the
                                software prompt you for a set of native (<code>.crf</code> and <code>.crt</code> only)
                                coefficient data files to convert into a <code>.hex</code> file. Note that
                                while <code>.cff</code> and <code>.cft</code> files are also filename extensions
                                of valid native coefficient data files, to perform the conversion using these files,
                                the software would require the true reference frequency (used at the time
                                of transducer calibration), which is unavailable to the QCOM module. On the
                                other hand, the <code>.crf</code> and <code>.crt</code> files require a relative
                                reference frequency, whose value the QCOM software <i>is</i> able to supply
                                for the conversion, resulting in very little loss of accuracy.
                                <br /><br />
                                <script type="text/javascript">display_pic('Coeff-Convert-XD-SN-Prompt', 'Manual', 'W7', '300');</script>
                            </div><br />
                        <b>Hex File Verification</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                The software provides a way to test a text file to determine whether it
                                meets the criteria for a properly formatted
                                <!--
                                Intel<sup>&reg;</sup> <a href="<?=Wiki_Dir ?>Intel_HEX" title="Intel Hex File Format" target="_blank">Hex File Format</a>.
                                -->
                                When you click <b><i>Verify Hex File</i></b>, the software will prompt you
                                for a file on which to perform the hex file test. If the software determines
                                further that the specified hex file contains coefficient file data, it
                                will also check to ensure that it contains the correct coefficient file
                                data checksum. Following the test, the software will fill a section of memory
                                with the specified data, and offer you an opportunity to save the formatted memory
                                data as a <a href="<?=Wiki_Dir ?>Binary_file_format" title="Binary File Format" target="_blank">binary</a> file
                                if no errors were detected, or if it is a coefficient data file, to display it.
                            </div><br />
                            <div style="margin-left:40px;">
                                The <b>Verify Hex File</b> function checks the file for valid record types
                                (types 0, 1, 2, 4, and 5 are recognized) and lengths, checksums, and proper line
                                starts and terminations. If the software detects one or more incorrect checksums,
                                it will attempt to correct the checksums, alert you to the errors, then offer
                                to save the corrected hex file, but not the converted binary equivalent.
                                This way, if you need to modify the contents of a hex file, you can use
                                the <b>Verify Hex File</b> function to adjust the file's checksum and then
                                save the corrected file.
                            </div><br />
                        <b>Firmware Updating</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                Upon startup, if the software detects that the firmware version of its attached QCOM
                                module does not match that which it determines as the current version, it will prompt
                                you whether you would like to upgrade its firmware before the
                                <script type="text/javascript">jump_within_doc('Opening Window', 'Opening_Window', 'Software_Home');</script> appears.
                                If you choose to install or update the module firmware manually at a later time, you can
                                do so if you click <b><i>Update Firmware</i></b> for the module you want to update. The
                                software will prompt you for the firmware hex file.
                                <br /><br />
                                <script type="text/javascript">display_pic('Update-FW-File-Prompt', 'Manual', 'W7', '400');</script>
                            </div><br />
                            <div style="margin-left:40px;">
                                Once the software reads, parses, and verifies the firmware file, the <b>Firmware Update</b> function
                                will then display the firmware version currently installed, along with the version of the
                                firmware contained in the hex file, and ask whether you would like to upgrade (or downgrade, as the
                                case might be).
                                <br /><br />
                                <script type="text/javascript">display_pic('Update-FW-Upgrade', 'Manual', 'W7', '260');</script>
                            </div><br />
                            <div style="margin-left:40px;">
                                If the firmware update completed successfully, the software will display the popup
                                indicating success, and update firmware version displays throughout the software
                                accordingly.
                                <br /><br />
                                <script type="text/javascript">display_pic('Update-FW-Success', 'Manual', 'W7', '300');</script>
                            </div><br />
                        <b>Download Coefficient Files</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                If you are connected to the internet, this button will prompt you for the serial
                                number of one Quartzdyne transducer, then search its repository for the appropriate
                                coefficient data files, collect all the files in a ZIP format, then present the
                                compressed file to you for download. Only <code>.hex</code>, <code>.crf</code>, <code>.crt</code>,
                                <code>.cff</code>, and <code>.cft</code> files will be collected, compressed,
                                and presented for download.
                                <br /><br />
                                <script type="text/javascript">display_pic('XD-SN-Search-Prompt', 'Manual', 'W7', '300');</script>
                            </div><br />
                        <b>Coefficient Checking</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                The <b><i>Coefficient Check</i></b> is a cursory test function whose results
                                are displayed on a web page, and is used primarily by those who are interested
                                in performing a quick compatibility check of the transducer-coefficient data
                                pair, compared with the results rendered by coefficient data from an external
                                file. If the software determines that the Calbration database is available,
                                it attempts to search the database for the appropriate coefficient data
                                files; otherwise, it will prompt you for the file you want to test with.
                            </div><br />
                            <div style="margin-left:40px;">
                                The software compares the transducer readings it obtains from this coefficient
                                data file with that of the coefficient data already residing in the transducer
                                for digital transducers that contain memory, or in the QCOM module memory
                                for other transducers. It then displays the comparison of the transducer readings,
                                along with the coefficient data file location and transducer memory type,
                                on the <i>Quartzdyne Transducer Coefficient Check</i> web page, like the
                                following:
                                <br /><br />
                                <script type="text/javascript">display_pic('Check-XD-Result', 'Manual', 'W7', '600');</script>
                            </div><br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Software_Utilities ?>
                    <div class="topic"
                        onclick="expand_collapse('Software_Reset')"
                        ondblclick="expand_collapse('Software_Reset')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Reset and Rescan<a name="Reset_Rescan"></a>
                    </div>              <? // end of Reset_Rescan ?>
                    <div class="subtopic" id="Software_Reset" lang="QD">
                        Description of Reset and Rescan<br />
                        <br /><br />
                        Reset<br />
                            <div style="margin-left:40px;">QCOM modules</div><br />
                            <div style="margin-left:40px;">Quartzdyne transducers</div><br />
                            <div style="margin-left:40px;">QCOM software</div><br />
                            <div style="margin-left:40px;">All</div><br />
                        <br /><br />
                        Rescan<br />
                        <br /><br />
                        <script type="text/javascript">display_footer();</script>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_Hidden')"
                        ondblclick="expand_collapse('Software_Hidden')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Behind-the-Scenes<a name="Behind_Scenes"></a>
                    </div>              <? // end of Behind_Scenes ?>
                    <div class="subtopic" id="Software_Hidden" lang="QD">
                        Description of Behind-the-Scenes<br />
                        <div style="margin-left:40px;">
                            Config file<br />
                        </div>
                        <div style="margin-left:40px;">
                            Error log<br />
                        </div>
                        <div style="margin-left:40px;">
                            Prompts to ensure coefficients for frequency (analog) transducers are correct<br />
                        </div>
                        <div style="margin-left:40px;">
                            Prompts when outdated firmware is detected<br />
                        </div>
                        <div style="margin-left:40px;">
                            Detects hardware changes<br />
                        </div>
                        <script type="text/javascript">display_footer();</script>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_Expert')"
                        ondblclick="expand_collapse('Software_Expert')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Expert Mode<a name="Expert_Tab"></a>
                    </div>              <? // end of Expert_Tab ?>
                    <div class="subtopic" id="Software_Expert" lang="QD">
                        <script type="text/javascript">display_pic('Expert-Tab', 'Manual', 'W7', '800');</script>
                        <br /><br />
                        An <b>Expert Mode</b> (advanced) interface is provided for testers who are acquainted
                        enough with Quartzdyne's transducer technology and the QCOM software to understand details
                        beyond that of a regular tester. On the main menu bar, mouse over <b><i>Functions</i></b> and
                        select <b><i>Enable Expert Mode</i></b> to enable <b>Expert Mode</b> and display the
                        <b><i>Advanced</i></b> menu item.
                        <br /><br />
                        <b>Effects of Expert Mode on the rest of the software</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                The <b style="color:red;">Sending</b> and <b style="color:olivedrab;">Not Sending</b>
                                LEDs are displayed on the front panel.
                            </div><br />
                            <div style="margin-left:40px;">
                                Progress bars on the data log windows are presented.
                            </div><br />
                            <div style="margin-left:40px;">
                                Some prompts to save or delete files will no longer appear.
                            </div><br />
                            <div style="margin-left:40px;">
                                An Advanced menu item is presented.
                            </div><br />
                        <b>Modal Message Controls</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                A variety of modal-type (those that prompt you for a mouse click) messages are
                                available for displaying when certain kinds of events occur. Some events, such
                                as critical errors, might be displayed beyond your control, but the displaying
                                of most of them can be controlled by the following checkboxes:
                                <br /><br />
                                <div style="margin-left:40px;">
                                    Basic modal messages : A high-level non-error event has occurred
                                </div><br />
                                <div style="margin-left:40px;">
                                    Verbose modal messages : A normal-level non-error event has occurred
                                </div><br />
                                <div style="margin-left:40px;">
                                    Detailed modal messages : Any kind of non-error event has occurred
                                </div><br />
                                <div style="margin-left:40px;">
                                    Error modal messages : An error event has occurred
                                </div><br />
                                <div style="margin-left:40px;">
                                    Experimental modal messages : An experimetal event (specified by experiment number) has occurred
                                </div><br />
                                <div style="margin-left:40px;">
                                    DLL modal messages : An event resulting from a DLL error has occurred
                                </div><br />
                                Click <b><i>Reset All Modal Messages</i></b> to prevent all the user-controlled
                                modal messages from displaying.
                            </div><br />
                        The <b>Poller</b> is an internal timer process that detects changes in hardware,
                        providing hot-plug support. Specifically, the poller attempts to propogate changes in
                        the numbers of modules and transducers attached to the client, to the rest of the
                        software. You can set the interval between the times when the software can detect
                        hardware changes from 0.5 seconds to ten minutes, inclusive.  The program poller
                        is enabled by default; un-check <b><i>Enable the program poller</i></b> to disable
                        the software's ability to detect changes in the numbers of attached modules and
                        transducers.
                        <br /><br />
                        <b>Error Controls</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                Aside from displaying modal messages when an error occurs, you also have some
                                control over the effects of some errors on the software by the following
                                checkboxes:
                                <br /><br />
                                <div style="margin-left:40px;">
                                    Display stack traces : When the software displays an error modal message, it also
                                    displays the stack trace at the error point in the program
                                </div><br />
                                <div style="margin-left:40px;">
                                    Send text messages : If the <b>To:</b> field of the <b>text messages</b>
                                    box contains a valid text number, the software will text the error message to
                                    this number and the number in the <b>CC:</b> field.
                                </div><br />
                                <div style="margin-left:40px;">
                                    Send emails : If the <b>To:</b> field of the <b>email messages</b> box
                                    contains a valid email address, the software will email the error message to
                                    this address and the address in the <b>CC:</b> field.
                                </div><br />
                                <div style="margin-left:40px;">
                                    Halt operations : When the software detects an error, it will stop all major
                                    program operations (sampling, logging, testing, etc.) until you answer its
                                    prompt
                                </div><br />
                            </div>
                        <b>Experiments</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                You can perform a variety of pre-determined experimental tasks, identified
                                by experiment number, which you can make available if you click the
                                <b><i>Enable experiments</i></b> checkbox. After entering an acceptable
                                experiment number, click <b><i>Run Experiments</i></b> to perform the
                                pre-determined set of experiments associated with the entered experiment
                                number. <b>Note: With software version 1.0.7, all pre-determined experiments and
                                their associated numbers are known only to the software developer, with
                                many planned to be published in a later version.</b>
                            </div><br />
                        <b>Email and Text Messages</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                You can direct the software to send text and/or email messages for some
                                applicable events, such as sending samples or reporting errors. The software
                                will not send any text messages unless the <b>To:</b> field for text messages
                                is filled. Likewise, the software will not send any email messages unless the
                                <b>To:</b> field for email messages is filled. The <b>CC:</b> fields are
                                provided to optionally allow these messages to be sent to other destinations.
                            </div><br />
                            <script type="text/javascript">center_pic('Send-Readings', 'Manual', 'W7', '700');</script><br />
                            <div style="margin-left:40px;">
                                <b>Note: Some corporate settings might prohibit receiving emails from QCOM
                                test environments, and might need to be adjusted to accommodate this software
                                feature.</b>
                            </div><br />
                            <div style="margin-left:40px;">
                                If you check <b><i>Send text messages when errors occur</i></b> or
                                <b><i>Send emails when errors occur</i></b>, the software will send error
                                messages to the appropriate destination(s) when they occur.
                            </div><br />
                            <div style="margin-left:40px;">
                                If you check <b><i>Send transducer reading samples</i></b> for a particular
                                unit, the software will send transducer pressure and temperature readings,
                                along with the module serial number, transducer serial number, and current
                                error status, of that unit to the text number(s) <i>and</i> email address(es)
                                you specify. While checked, the software will change the
                                <b style="color:olivedrab;">Not Sending</b> LED to read
                                <b style="color:red;">Sending</b> and light the LED. This check will
                                also display the entry that allows you to specify the interval in minutes
                                (between ten minutes and two weeks, inclusive) between sent transducer
                                samples. The software will update the text in this area, to inform you of
                                the number of minutes remaining until the software sends the next set of
                                transducer readings. The software will send the readings in the units you
                                specify on the <script type="text/javascript">jump_within_doc('Readout', 'Readout_Tab', 'Software_Readout');</script>
                                tab page.
                            </div><br />
                        Click <b>Erase Coefficient Data</b> to erase the coefficient data from module's memory.
                        <br /><br />
                        Click <b>Disable Transducer Power</b> to disable or enable electrical power provided by
                        the QCOM module to the transducer.
                        <br /><br />
                        Click <b>Display Coefficient Data</b> to display the software's interpretation of
                        the coefficient data currently in client memory for the transducer.
                        <br /><br />
                        <script type="text/javascript">center_pic('Coefficient-Data', 'Manual', 'W7');</script>
                        <br /><br />
                        Click <b><i>Program Info</i></b> to display a snapshot of much of what the software
                        tracks on the state of the hardware and software at the moment you clicked the
                        button, for both general and per-unit states.
                        <script type="text/javascript">center_pic('Program-Information', 'Manual', 'W7');</script>
                        <br /><br />
                        Click <b><i>Misc Controls</i></b> to display the <b>Miscellaneous Controls</b> window,
                        which presents a number of minor utilities that allow the advanced tester a level
                        of access and control unavailable to the regular QCOM tester.
                        <br /><br />
                        <script type="text/javascript">center_pic('Miscellaneous', 'Manual', 'W7');</script>
                        <br /><br />
                            General<br />
                                <div style="margin-left:40px;">Number of Modules</div><br />
                                <div style="margin-left:40px;">DLL Version</div><br />
                                <div style="margin-left:40px;">Program Timeouts</div><br />
                                <div style="margin-left:40px;">Program Sounds</div><br />
                                <div style="margin-left:40px;">Config File Control</div><br />
                                <div style="margin-left:40px;">Modify Persistent Flags</div><br />
                            Unit<br />
                                <div style="margin-left:40px;">Module Serial Number</div><br />
                                <div style="margin-left:40px;">I2C Data Rate</div><br />
                                <div style="margin-left:40px;">Memory Type</div><br />
                                <div style="margin-left:40px;">Status Register</div><br />
                                <div style="margin-left:40px;">Control Register</div><br />
                                <div style="margin-left:40px;">Transducer Type</div><br />
                                <div style="margin-left:40px;">Internal Error Code</div><br />
                                <div style="margin-left:40px;">Cadence Timer</div><br />
                                <div style="margin-left:40px;">Module Firmware ID</div><br />
                                <div style="margin-left:40px;">Transducer Chip ID</div><br />
                                <div style="margin-left:40px;">Send I2C Command</div><br />
                                <div style="margin-left:40px;">
                                Click <b><i>Copy Transducer Memory To Module</i></b> to copy the contents of the
                                first four 256-byte pages of digital transducer memory to the QCOM module.
                                </div>
                                <br /><br />
                                <div style="margin-left:40px;">
                                Click <b><i>Copy Module Memory To Transducer</i></b> to copy the contents of the
                                first four 256-byte pages of QCOM module memory to the digital transducer.
                                </div>
                                <br /><br />
                                <div style="margin-left:40px;">
                                Click <b><i>Display Transducer Raw Coefficient Data</i></b> to display the hexadecimal
                                values of all four 256-byte pages of digital transducer memory. A note at the bottom
                                of the display window describes whether the contents of the four memory pages are
                                identical to each other.
                                </div>
                                <br /><br />
                                <div style="margin-left:40px;">
                                Click <b><i>Display Module Raw Coefficient Data</i></b> to display the hexadecimal
                                values of all four 256-byte pages of QCOM module memory. A note at the bottom
                                of the display window describes whether the contents of the four memory pages are
                                identical to each other.
                                </div>
                                <br /><br />
                                <div style="margin-left:40px;">
                                Click <b><i>Display DLL Functions</i></b> to display the names and results
                                of all applicable functions originating from <code>qdUSB.dll</code>.
                                </div>
                                <script type="text/javascript">center_pic('Display-DLL-Functions', 'Manual', 'W7');</script>
                                <div style="margin-left:40px;">
                                Click <b><i>Enter Boot Loader Mode</i></b> to place the module in Boot
                                Loader Mode, which is used primarily for updating its firmware.
                                </div>
                            <br /><br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Software_Expert ?>
                    <div class="topic"
                        onclick="expand_collapse('Software_HotPlug')"
                        ondblclick="expand_collapse('Software_HotPlug')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Hot Plug<a name="Hot_Plug"></a>
                    </div>              <? // end of Hot_Plug ?>
                    <div class="subtopic" id="Software_HotPlug" lang="QD">
                        Description of Hot Plug<br />
                        Do not attempt to attach or detach a module or transducer during sampling,
                        testing, or firmware updating.<br />
                        <div style="margin-left:40px;">
                            Hot-plugging the QCOM module
                        </div><br />
                        <div style="margin-left:40px;">
                            Hot-plugging a Quartzdyne transducer
                        </div><br />
                        <br />
                        <script type="text/javascript">display_footer();</script>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_CommandLine')"
                        ondblclick="expand_collapse('Software_CommandLine')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Command Line<a name="Command_Line"></a>
                    </div>              <? // end of Command_Line ?>
                    <div class="subtopic" id="Software_CommandLine" lang="QD">
                        QCOM has an optional command-line interface available for those who want to
                        start the software in the Command Prompt window. An advantage to starting the
                        software this way is that you have the ability to specify a limited set of
                        command-line parameters to the program, which can affect or control software
                        operations before the GUI begins running, or without displaying the GUI at all,
                        depending on the parameters.
                        <br /><br />
                        <div style="margin-left:40px;">
                            Accepted command-line parameters (switches prefixed by '/' can also be prefixed
                            by '-' instead)
                            <br /><br />
                            <div style="margin-left:40px;">/mb : Enables 'basic' modal messages (/mb- disables)</div><br />
                            <div style="margin-left:40px;">/me : Enables 'error' modal messages (/me- disables)</div><br />
                            <div style="margin-left:40px;">/mv : Enables 'verbose' modal messages (/mv- disables)</div><br />
                            <div style="margin-left:40px;">/md : Enables 'detailed' modal messages (/md- disables)</div><br />
                            <div style="margin-left:40px;">/ml : Enables DLL modal messages (/ml- disables)</div><br />
                            <div style="margin-left:40px;">/mx : Enables 'experimental' modal messages (/mx- disables)</div><br />
                            <div style="margin-left:40px;">/ms : Enables stack traces on errors (/ms- disables)</div><br />
                            <div style="margin-left:40px;">/m0 : Disables all modal messages</div><br />
                            <div style="margin-left:40px;">/evta : Starts logging all non-test events to the <script type="text/javascript">jump_within_doc('event log', 'Event_Log', 'Software_Troubleshooting');</script></div><br />
                            <div style="margin-left:40px;">/evtb : Starts logging basic events (same as /evt)</div><br />
                            <div style="margin-left:40px;">/evtv : Starts logging verbose events</div><br />
                            <div style="margin-left:40px;">/evtd : Starts logging detailed all non-test events (same as /evta)</div><br />
                            <div style="margin-left:40px;">/cfg : Load config information on startup (/cfg- prevents)</div><br />
                            <div style="margin-left:40px;">/gui : Display the graphical user interface (/gui- for command-line only)</div><br />
                            <div style="margin-left:40px;">
                                /x : Starts the software in <script type="text/javascript">jump_within_doc('Expert Mode', 'Expert_Tab', 'Software_Expert');</script>
                                (/x- disables)
                            </div><br />
                            <div style="margin-left:40px;">/h : Displays the command-line usage and the online help</div><br />
                            <div style="margin-left:40px;">/? : Displays the usage window only</div><br />
                        </div>
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Software_CommandLine ?>
                    <div class="topic"
                        onclick="expand_collapse('Software_Errors')"
                        ondblclick="expand_collapse('Software_Errors')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Errors<a name="Errors"></a>
                    </div>              <? // end of Errors ?>
                    <div class="subtopic" id="Software_Errors" lang="QD">
                        As you operate the QCOM software you might encounter an error code, error condition, or
                        other unsatisfactory or unexpected result. While some can be solved or even mitigated
                        by simple tasks, others could be more obscure, requiring more detailed information before
                        the source of the problem could be revealed. In many cases error codes are provided to
                        possibly expose some details of the errors to the tester or the QCOM software developer.
                        This section lists and explains some of the most likely or frequently encountered errors,
                        and their possible causes or solutions.
                        <br /><br />
                        <b>Software Errors</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                Most error messages that appear in popup and other modal windows are self-explanatory,
                                but some are rather cryptic, because they might convey technical information
                                as well as alert the tester to a possible problem.
                                <br /><br />
                                <div style="margin-left:40px;">
                                </div>
                            </div><br />
                        <b>DLL Errors</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                The DLL (<code>qdUSB.dll</code>) does not contain functions that display any error
                                codes or conditions, but many return the result of each function operation to the
                                calling software. They also set a global status value (<code>QD_DLLStatus</code>),
                                which is available to the calling software, and represents the last nonzero return
                                code set by a DLL function, or zero if a nonzero return code was never set since
                                the software started.
                                <br /><br />
                                The DLL function return code value is an unsigned 32-bit integer that is mapped as detailed
                                in <a href="<?=QCOM_PkgDir ?>/QCOM-DLL-Spec-B4.pdf" target="_blank">the DLL specification</a>,
                                section 4, as follows:
                                <br /><br />
                                <div style="margin-left:40px;">
                                    <code>0xNNLLSSSS</code><br /><br />
                                    <code>NN</code>
                                        <span style="margin-left:40px;">The function number</span>
                                    <br />
                                    <code>LL</code>
                                        <span style="margin-left:40px;">The locus (relative location with the function),
                                        which can differ from one function to the next</span>
                                    <br />
                                    <code>SSSS</code>
                                        <span style="margin-left:23px;">The 16-bit status value, as follows:</span>
                                    <br /><br />
                                    <div style="margin-left:40px;">
                                        <code>0000</code> : No error (successful)<br />
                                        <code>0001</code> : Invalid module handle<br />
                                            <div style="margin-left:40px;">
                                                The module handle passed to the function is either zero or
                                                INVALID_HANDLE_VALUE (-1). This condition can occur if the
                                                software attempts to perform a function on a module that
                                                has been closed with QD_Close.
                                            </div>
                                        <code>0002</code> : Read error<br />
                                        <code>0003</code> : Device queue not ready<br />
                                        <code>0004</code> : Write error<br />
                                        <code>0005</code> : Reset error<br />
                                        <code>0006</code> : Invalid parameter<br />
                                            <div style="margin-left:40px;">
                                                This parameter is not recognized or is deemed invalid
                                                for some reason
                                            </div>
                                        <code>0007</code> : Invalid request length<br />
                                        <code>0008</code> : Device I/O failed<br />
                                            <div style="margin-left:40px;">
                                                The QCOM firmware attempted to read from, or write to, the module,
                                                but the attempt failed for some reason
                                            </div>
                                        <code>0009</code> : Invalid data rate<br />
                                        <code>000A</code> : Function not supported<br />
                                            <div style="margin-left:40px;">
                                                The software is attempting to perform an invalid operation,
                                                or make an invalid selection
                                            </div>
                                        <code>000B</code> : Global data error<br />
                                        <code>000C</code> : System error<br />
                                            <div style="margin-left:40px;">
                                                For whatever reason, the operating system, the USB chipset, the
                                                module firmware, or the software is unable to complete the
                                                requested operation. Essentially, the internal state machine has
                                                reached an undetermined state, and might require a reset, which
                                                a software reset will not accomplish. If this error appears
                                                repeatedly, you must exit the QCOM software, unplug the USB cable
                                                from the QCOM module, re-attach the USB cable, then restart the
                                                software before you can resume proper operation.
                                            </div>
                                        <code>000D</code> : Read timed out<br />
                                        <code>000E</code> : Write timed out<br />
                                        <code>000F</code> : I/O pending<br />
                                        <code>0010</code> : Checksum error<br />
                                        <code>0011</code> : Transducer pressure count zero<br />
                                            <div style="margin-left:40px;">
                                                The returned pressure count reports a zero value, but the
                                                temperature count is nonzero
                                            </div>
                                        <code>0012</code> : Transducer temperature count zero<br />
                                            <div style="margin-left:40px;">
                                                The returned temperature count reports a zero value, but the
                                                pressure count is nonzero
                                            </div>
                                        <code>0013</code> : Transducer both counts zero<br />
                                            <div style="margin-left:40px;">
                                                The returned pressure count and temperature count report
                                                zero values. This often indicates that the coefficient data
                                                is missing or invalid. This error can also occur if the
                                                transducer has lost power or has reached an overcurrent condition.
                                            </div>
                                        <code>0014</code> : Memory allocation failed<br />
                                            <div style="margin-left:40px;">
                                            </div>
                                        <code>0015</code> : File failed to open<br />
                                            <div style="margin-left:40px;">
                                                The specified file exists, but cannot be opened. This usually
                                                occurs if the file is already open or has become corrupted.
                                            </div>
                                        <code>0016</code> : ADC count zero<br />
                                        <code>0017</code> : File size mismatch<br />
                                            <div style="margin-left:40px;">
                                                The size of the specified file reported by the file system does
                                                not equal the number of bytes that are read from or written to
                                                the file
                                            </div>
                                        <code>0018</code> : Invalid hex file data<br />
                                            <div style="margin-left:40px;">
                                                The contents of the specified file does not meet the expected
                                                criteria for an Intel Hex File format
                                            </div>
                                        <code>0019</code> : Incorrect data size<br />
                                        <code>001A</code> : Invalid firmware page<br />
                                        <code>001B</code> : Unit not ready<br />
                                        <code>001C</code> : Cadence timer zero<br />
                                        <code>001D</code> : Data rate zero<br />
                                        <code>001E</code> : Invalid I<sup>2</sup>C reply<br />
                                        <code>001F</code> : Firmware ID zero<br />
                                        <code>0020</code> : Data transfer failure<br />
                                        <code>0021</code> : Device timed out<br />
                                        <code>0022</code> : Receive queue overrun<br />
                                        <code>0023</code> : Firmware signature not erased<br />
                                        <code>0024</code> : Transducer voltage too high<br />
                                        <code>0025</code> : Transducer voltage too low<br />
                                        <code>0026</code> : Transducer current too high<br />
                                        <code>0027</code> : Transducer current too low<br />
                                        <code>0028</code> : Write acknowledge (ACK) failed<br />
                                            <div style="margin-left:40px;">
                                                The USB chipset failed to respond to the request as expected.
                                                This is possible if a software thread inadvertently completes
                                                a request that it did not initiate, prompting the initiating
                                                thread to time out, since no acknowledge was received.
                                            </div>
                                        <code>0029</code> : Unreachable condition<br />
                                            <div style="margin-left:40px;">
                                                It is not theoretically possible to reach this particular
                                                condition, and possibly reflects a corrupted environment or
                                                other systemic problem
                                            </div>
                                        <code>002A</code> : Null-pointer parameter<br />
                                            <div style="margin-left:40px;">
                                                The parameter is a null pointer, but should not be
                                            </div>
                                        <code>002B</code> : Zero-length string parameter<br />
                                            <div style="margin-left:40px;">
                                                The string parameter is zero-length, but should not be
                                            </div>
                                        <code>0040</code> : Invalid coefficient data<br />
                                            <div style="margin-left:40px;">
                                                The specified data does not reflect a valid coefficient data format
                                            </div>
                                        <code>0070</code> : File not found<br />
                                            <div style="margin-left:40px;">
                                                The specified file could not be located
                                            </div>
                                        <code>0071</code> : Invalid filename<br />
                                            <div style="margin-left:40px;">
                                                The specified filename string does not have a valid format
                                            </div>
                                        <code>0072</code> : Invalid file found<br />
                                            <div style="margin-left:40px;">
                                                The specified filename was found, but its contents
                                                do not reflect a valid data pattern
                                            </div>
                                        <code>00FF</code> : Device not found<br />
                                            <div style="margin-left:40px;">
                                                A unit number was supplied to the function that requires one,
                                                and no registered QCOM module is registered for that number
                                            </div>
                                    </div>
                                </div>
                            </div><br />
                        <b>The Error Log</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                The software will create an error log file as soon as it starts, to store
                                detectable errors it encounters. These errors include, but are not limited to,
                                DLL errors (nonzero status values reported by DLL functions), operating environment
                                errors (drive full, out of memory, corrupted environment, loss of connection, etc.),
                                operator-induced errors (illegal file names, conflicting settings, invalid email
                                addresses, etc.), and software errors (invalid pointers, local exception, invalid
                                parameters, etc.)
                            </div><br />
                            <div style="margin-left:40px;">
                                The resulting error log file is named <code>QCOM-ErrorLog-YYMMDD-NNN.log</code>, in
                                which <code>YYMMDD</code> represents the creation date and <code>NNN</code> represents
                                the one-relative log number (<code>001</code>, <code>002</code>, <code>003</code>, etc.)
                                for this unit on that day. The error log file is stored by default in the <code>QLog</code>
                                folder under the executable directory, as in <code>C:\Program Files\Quartzdyne\QCOM\QLog</code>
                                or similar. The size of the error log is limited by your operating system and drive
                                space remaining. You can create up to 999 error log files per day for a particular unit
                                (module and transducer combination), but the software will overwrite and re-use the
                                latest existing existing error log file if it contains no error messages.
                            </div><br />
                        <b>Error Codes</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                Cryptic error codes
                            </div><br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Software_Errors ?>
                    <div class="topic"
                        onclick="expand_collapse('Software_Troubleshooting')"
                        ondblclick="expand_collapse('Software_Troubleshooting')"
                        onmouseover="this.style.color = 'darkgoldenrod';"
                        onmouseout="this.style.color = 'purple';">
                        Troubleshooting<a name="Troubleshooting"></a>
                    </div>              <? // end of Troubleshooting ?>
                    <div class="subtopic" id="Software_Troubleshooting" lang="QD">
                        If the QCOM software presents error messages or does not perform as expected,
                        there are a number of steps that you can take to possibly correct the problem or
                        improve the results.
                        <br /><br />
                        <b>After installing the software, you double-click the QCOM icon on your desktop,
                        only to see a message window pop up with 'QCOM Transducer Communication Software
                        has stopped working'</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                The QCOM software requires Administrator privileges to modify the
                                <code>C:\Program Files\Quartzdyne\QCOM</code> folder on the client where you are
                                atempting to run the software. But you can run the software without
                                Administrator privileges if you modify the folder's permissions as
                                Administrator.
                                <br /><br />
                                Once you invoke Administrator privileges, use Windows Explorer to navigate
                                to the <code>C:\Program Files\Quartzdyne</code> folder. Right-click on <code>QCOM</code>
                                and click <code>Properties</code>. Select the <code>Security</code> tab and click
                                the <code>Edit</code> button. Highlight <code>Users</code>, then under
                                the <code>Allow</code> column check the box on the <code>Full control</code> line.
                                Click <code>Apply</code>, <code>OK</code>, and <code>OK</code>. A restart
                                should not be necessary.
                            </div><br />
                            <b style="margin-left:40px;">and if that doesn't fix it...</b><br /><br />
                            <div style="margin-left:40px;">
                                Your User Account Control setting might be set too high for the QCOM software,
                                and because the software is signed but not Microsoft Certified, and because you're
                                probably not running as Administrator, Windows might have restricted your ability
                                to run the QCOM software.
                                <br /><br />
                                In Control Panel, change the <b>View by:</b> to <code>Small icons</code>, click
                                <code>User Accounts</code>, then click <code>Change User Account Control settings</code>.
                                Move the vertical slide bar all the way to the bottom (<code>Never notify</code>) setting.
                                Click <code>OK</code>, then restart your computer for the setting to take effect.
                            </div><br />
                        <b>You are trying to test a transducer with the metal cap detached from the housing tube
                        (which is normally how some models are shipped), and the software presents invalid
                        readings</b>
                        <br /><br />
                            <div style="margin-left:40px;">
                                Some transducer models, such as the digital DXB, normally ships from Quartzdyne's
                                facility with its electrical cap detached from the transducer chassis (the cylindrical
                                metal housing.) Using the longer (7-foot) cable can force the transducer to exceed
                                the amount of current required for its operation from the USB port, which can shut
                                shut down the transducer to prevent overcurrent damage.
                                <br /><br />
                                To get around this problem, either attach the electrical cap to the
                                transducer chassis or use a short (8-inch) cable. To attach the cap onto
                                the chassis, either use short alligator clips between the two, or screw the
                                cap onto the chassis after feeding the wires through the circuit board
                                mounting window.
                            </div><br />
                            <b style="margin-left:40px;">and if that doesn't fix it...</b><br /><br />
                            <div style="margin-left:40px;">
                                It's possible that the reference wire is producing crosstalk on the SCL and/or
                                SDA wires.
                                <br /><br />
                                If your application does not require the use of the reference wire (the QCOM, for
                                example, does not use the reference wire), simply remove the reference (white)
                                wire from the transducer or cut it as closely to the transducer circuitry as you
                                can.
                            </div><br />
                        <b>The Event Log</b><a name="Event_Log"></a>
                        <br /><br />
                            <div style="margin-left:40px;">
                                If all else fails, you can record many, most, or all of your mouse clicks, keystrokes,
                                and resulting software actions by using the built-in <b>Event Log</b>, which is a
                                text file that lists every event you select to record. Because of the detail entered
                                in the Event Log, the file contents might appear rather cryptic, but it was created
                                primarily to aid the software developer in helping the tester expose error sources,
                                as much as possible.
                                <br /><br />
                                To use the Event Log, enable <script type="text/javascript">jump_within_doc('Expert Mode', 'Expert_Tab', 'Software_Expert');</script>
                                and mouse over <b><i>Advanced</i></b> in the main menu bar, then mouse over
                                <b><i>Event Log Recording</i></b>. Recording of mouse clicks and keystrokes
                                begins as soon as you select one of the event recording types.
                                <br /><br />
                                <b><i>Basic Events</i></b> are the most general actions, such as a click of a button or
                                the entry of a prompt field, or the selection of a check box. <b><i>Verbose Events</i></b> include
                                all Basic Events, plus the results of all functions called by mouse clicks and keystrokes.
                                <b><i>Detailed Events</i></b> include all the actions performed by the software, even some
                                background processes. <b><i>Test Events</i></b> are verbose actions that occur only during
                                testing, as a result of running tests.
                                <br /><br />
                                The resulting event log file is named <code>QCOM-EventLog-YYMMDD-NNN.log</code>, in which
                                <code>YYMMDD</code> represents the log file creation date and <code>NNN</code> represents
                                the one-relative log number (<code>001</code>, <code>002</code>, <code>003</code>, etc.)
                                for that day. The event log file is stored by default in the <code>QLog</code> folder
                                under the executable directory, as in <code>C:\Program Files\Quartzdyne\QCOM\QLog</code> or
                                similar. The size of the event log file is limited by your operating system and drive space
                                remaining. You can create up to 999 event log files per day.
                                <br /><br />
                                To examine the contents of the event log, you can either navigate to the folder in
                                which the file is located and display it with your favorite editor, or you can
                                display it with the viewer built into the software when in
                                <script type="text/javascript">jump_within_doc('Expert Mode', 'Expert_Tab', 'Software_Expert');</script>.
                                To display the latest version of event log using the built-in viewer, mouse over
                                the <b><i>Advanced</i></b> menu item, then click <b><i>Display Last Event Log</i></b>.
                            </div><br />
                        <script type="text/javascript">display_footer();</script>
                    </div>              <? // end of Software_Troubleshooting ?>
                </div>                  <? // end of Software_Man ?>
            </div>                      <? // end of Help_Section ?>
        </div>                          <? // end of MainBody ?>
        <hr class="redLine" />
        <div class="page_bottom" id="MainFooter">
            <i class="flush_left">Copyright &copy; <?=date('Y'); ?> <a href="<?=QD_HomeDir ?>" target="_blank">Quartzdyne, Inc.</a>, a <a href="<?=DoverDir ?>" target="_blank">Dover</a><sup>&reg;</sup> company</i>
            <span class="flush_right" style="font-size:80%;">(Version <?=sourceVersion ?> [<script type="text/javascript">document.write(browserFlag);</script>])</span>
        </div>                          <? // end of MainFooter ?>
    </body>
</html>
<?php
//============================================================================
// QCOM-Help.php Revision History (defined as sourceVersion in this source)
//
//  11 Apr 2011     1.0.0       1.  Initial public release
//
//  23 May 2011     1.0.1       1.  Moved the download links to their own page
//
//  25 Aug 2011     1.0.2       1.  Displays the software user guide
//
//  20 Jun 2012     1.0.3       1.  Added Google Analytics
//
//  21 Aug 2012     1.0.4       1.  Updated for software v1.0.6
//                              2.  Added a reference to the Test Procedure
//
//  20 Dec 2012     1.0.5       1.  Updated for Windows 8 and Windows Server
//                                  2012
//                              2.  Fixed a problem that prevented sections
//                                  from expanding
//                              3.  Added help for the Event Log as a trouble-
//                                  shooting tool
//                              4.  Added help for the Error Log
//                              5.  Completed the help for Display Coefficient
//                                  File Parameters
//                              6.  Liberally populated the text with internal
//                                  hyper-links
//                              7.  Updated several outdated images
//                              8.  Added DLL error codes
//
//  30 May 2013     1.0.6       1.  Corrected the mouse pointer appearance
//                                  when hovering over expandable text.
//                              2.  Corrected a problem with links when clicked
//                                  within a subtopic <div>
//                              3.  Updated the expand_collapse_all() function
//                                  to work with Internet Explorer 8 and later
//                              4.  Added troubleshooting notes concerning
//                                  Administrator privileges for the QCOM
//                                  folder of the C:\Program Files\Quartzdyne
//                                  directory
//                              5.  Changed the character set to UTF-8
//                              6.  Removed the no-cache pragma meta
//                              7.  Added the global distribution meta
//                              8.  Began using qdprogstd.css
//
//  05 Sep 2013     1.0.7       1.  Updated for software v1.0.7, including the
//                                  Display Graph function, Download
//                                  Coefficient Files button help and some of
//                                  the startup tasks
//
//  06 Dec 2013     1.0.8       1.  Began using MainDefs.php
//                              2.  Moved the browser detection scripts to
//                                  PageHeader.js
//
//  10 Sep 2015     1.0.9       1.  Updated for the new qdlamp
//                              2.  Updated for Windows 10 and Windows Edge
//
// End of QCOM-Help.php
//============================================================================
?>
