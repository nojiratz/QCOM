<?php
//============================================================================
// //qdlamp/var/www/qd.quartzdyne.com/QCOM/QCOM-MATLAB.php
//
// Online documentation for the QCOM Package for MATLAB
//
// Copyright (C) 2013 - 20145 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software.  Also,
// a detailed revision history of this file is included at the bottom of this
// source.
//
// Updated 09-10-2015
//============================================================================
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: -1');
    header('Pragma: no-cache');
    define('displayVersion', '1.0.3');
    define('updatedDate', '2015-09-10');
    define('sourceVersion', displayVersion . '.' . updatedDate);
    include '/var/www/qd.quartzdyne.com/script/server/MainDefs.php';
    //------------------------------------------------------------------------
    // Quartzdyne/QCOM-specific websites
    //------------------------------------------------------------------------
    define('QD_HomeDir', 'http://www.quartzdyne.com/');
    define('QD_HostDir', 'http://qd.quartzdyne.com/');
    define('QD_InternalDir', QD_HostDir . 'internal/');
    define('QD_PublicDir', QD_HostDir);
    define('QD_PkgDir', QD_PublicDir . 'pkg/');
    define('MS_dot_NET_4', QD_PkgDir . 'dotNetFx40_Full_setup.exe');
    define('QCOM_PublicDir', QD_PublicDir . 'QCOM/');
    define('QCOM_PkgDir', QCOM_PublicDir . 'pkg/');
    define('helpSite', QCOM_PublicDir . 'QCOM-Help.php');
    define('downloadSite', QCOM_PublicDir . 'QCOM-Download.php');
    //------------------------------------------------------------------------
    // Packages
    //------------------------------------------------------------------------
    define('releaseVersion', '1.0.7');
    define('releaseDate', '09-03-2013');
    define('QCOM_Release', QCOM_PkgDir . 'QCOM-Setup-' . releaseVersion . '.exe');
    //------------------------------------------------------------------------
    define('DLLSpecVersion', 'B4');
    define('DLLSpecDate', '10-03-2012');
    define('QCOM_DLL_Spec', QCOM_PkgDir . 'QCOM-DLL-Spec-' . DLLSpecVersion . '.pdf');
    //------------------------------------------------------------------------
    define('driverVersion', '3.3');
    define('QCOM_Drivers', QCOM_PkgDir . 'QCOM-Drivers-' . driverVersion . '.zip');
    //------------------------------------------------------------------------
    define('firmwareVersion', '1.2');
    define('QCOM_Firmware', QCOM_PkgDir . 'QCOM-Firmware-' . firmwareVersion . '.zip');
    //------------------------------------------------------------------------
    define('QCOM_MATLAB', QCOM_PkgDir . 'QCOM-MATLAB.zip');
    //------------------------------------------------------------------------
    // Non-Quartzdyne websites
    //------------------------------------------------------------------------
    define('DoverDir', 'http://www.dovercorporation.com/');
    //------------------------------------------------------------------------
    // Support
    //------------------------------------------------------------------------
    define('emailSubject' , 'QCOM-MATLAB (Version ' . sourceVersion . ')');
    define('reportIssues',
        'Please communicate problems and suggestions to <a href="' . mailSite . '?emailSubject=' .
        emailSubject . '&dest=support" target="_blank">Quartzdyne Support</a>');
    //------------------------------------------------------------------------
    include('/script/server/compresshtml.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
    <head>
        <title>QCOM Package for MATLAB</title>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <meta name="description" content="The online documentation for the QCOM Package for MATLAB" />
        <meta name="keywords" content="quartzdyne, quartz, downhole, pressure, temperature, sensor, transducer, QCOM, MATLAN" />
        <meta name="distribution" content="global" />
        <meta name="author" content="Noji Ratzlaff" />
        <link href="/image/quartzdyne.ico" rel="shortcut icon" type="image/x-icon" />
        <link href="/style/qdprogstd.css" rel="stylesheet" type="text/css" />
        <link href="/style/reset1.css" rel="stylesheet" type="text/css" />
        <link href="/style/table1.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
            body
            {
                background-image: url('/image/white_sand.jpg');
                font: 100% verdana,sans-serif;
                margin-left: 16px;
                margin-top: 8px;
            }
            @media print
            {
                table
                {
                    font-size: 140%;
                }
            }
        </style>
        <?  //----------------------------------------------------------------
            // Invoke the javascript page header functions
            //----------------------------------------------------------------
        ?>
        <script src="<?=clientScriptDir ?>PageHeader.js" language="javascript" type="text/javascript"></script>
        <script src="<?=clientScriptDir ?>ExpandCollapse.js" language="javascript" type="text/javascript"></script>
        <?  //----------------------------------------------------------------
            // Define local javascript functions
            //----------------------------------------------------------------
        ?>
        <script type="text/javascript">
<!--
            //----------------------------------------------------------------
            // jump_within_doc
            //
            // Expands the text of the specified topic, then jumps to the
            // specified tag whose text is displayed as a link
            //----------------------------------------------------------------
            function jump_within_doc(linkTag)
            {
                //------------------------------------------------------------
                document.write(
                    '<a href="#QD_' + linkTag + '" onclick="' +
                    'expand_sub(\'DLLFunctions_' + linkTag + '\')"><b><code>QD_' + linkTag + '</code></b></a>');
            }                           // end of jump_within_doc()
//-->
        </script>
    </head>
    <body onselectstart="event.returnValue=false;">
        <div id="qd_div" lang="QD"></div>
        <?  //----------------------------------------------------------------
            // Display the company logo and a button to print the page
            //----------------------------------------------------------------
        ?>
        <div style="margin:auto; text-align:center; width:1000px;" id="MainHeader">
            <a href="<?=QD_HomeDir ?>" target="_blank" name="doc_top">
                <img src="/image/QDDoverLogo.png" style="float:left; width:150px; margin-bottom:10px;" alt="Quartzdyne" />
            </a>
            <div style="margin-left:20px; margin-bottom:10px; text-align:center; float:left;">
                <div style="color:black; font-weight:bold; font-size:160%;">
                    QCOM Package for MATLAB
                </div>
                <span style="font-size:120%; margin-top:5px;">
                    <?=date('D d M Y h:i:s a'); ?>
                </span>
                <span>
                    <form style="margin-top:10px;">
                        <input
                            type="button"
                            onClick="window.print()"
                            value=" Print This Page "
                            style="color:blue;" />
                    </form>
                </span>
            </div>
        </div>                          <? // end of MainHeader ?>
        <div style="clear:both;" id="MainBody">
            <a href="<?=downloadSite ?>">Return</a> to the QCOM Download Center
            <br /><br />
            <a href="<?=helpSite ?>">Return</a> to the QCOM Help Center<br />
            <br />
            <div style="color:blue; margin-bottom:10px; cursor:pointer;" id="ExpandAll"
                onclick="expand_collapse_all()"
                ondblclick="expand_collapse_all()"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                <img src="/image/Red-Dot.gif" class="centerDot" />
                Expand the entire document
            </div>
            <?=reportIssues ?>
            <hr class="redLine" />
            <div style="font-size:16px; font-weight:bold;">
                The <i>QCOM Package for MATLAB</i> is a set of files that enable programmers
                to call a subset of the QCOM DLL functions directly from within the MATLAB
                environment.
            </div>
            <?  //------------------------------------------------------------
                // Download and Installation
                //------------------------------------------------------------
            ?>
            <div class="category" id="Download" style="margin-top:5px;"
                onclick="expand_collapse('Download_Topics')"
                ondblclick="expand_collapse('Download_Topics')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                Download and Installation
            </div>
            <div class="invisible" id="Download_Topics" lang="QD">
                <div style="font-size:80%; margin-left:20px;">
                    Assuming MATLAB (tested with R2008b and R2012b) has already been completely
                    installed on the target computer, you should be able to call QCOM DLL
                    functions from within MATLAB. Follow these instructions to get started.
                    <br /><br />
                    <b>
                        Note: If the released version of the QCOM software has not yet been installed
                        on the target computer, please <a href="<?=QCOM_Release ?>">install</a> it first.
                    </b>
                </div>
                <br />
                <div style="font-size:80%; margin-left:40px;">
                    <li style="list-style-type:decimal;">
                        Exit the QCOM software if it is currently running. <i>The QCOM Package for
                        MATLAB and the QCOM software cannot run simultaneously on the same computer.</i>
                    </li>
                    <li style="list-style-type:decimal;">
                        <a href="<?=QCOM_MATLAB ?>">Download</a> the package and extract the contents
                        (nine files) to a working directory where you can access these files from MATLAB
                    </li>
                    <li style="list-style-type:decimal;">
                        Install a QCOM module and Quartzdyne transducer on the computer (instructions
                        can be found on the <a href="<?=helpSite ?>" target="_blank">help</a> page)
                    </li>
                    <li style="list-style-type:decimal;">
                        Start MATLAB
                    </li>
                </div>
                <div style="font-size:80%; margin-left:20px;">
                    Compatibility
                    <br /><br />
                    The QCOM Package for MATLAB has been successfully tested on the following
                    configurations:
                    <ul>
                        <li style="list-style-type:disc;">
                            MATLAB R2012b (8.0.0) on Windows 8 64-bit using Microsoft Visual C++
                            2010 Express
                        </li>
                        <li style="list-style-type:disc;">
                            MATLAB R2012b (8.0.0) on Windows 7 32-bit using Microsoft Visual C++
                            2010 Express
                        </li>
                        <li style="list-style-type:disc;">
                            MATLAB R2008b (7.7.0) on Windows Server 2003 R2 SP2 64-bit using
                            Microsoft Visual C++ 2008 Express
                        </li>
                    </ul>
                </div>
            </div>                      <? // end of Download_Topics ?>
            <?  //------------------------------------------------------------
                // MATLAB Setup
                //------------------------------------------------------------
            ?>
            <div class="category" id="Setup" style="margin-top:5px;"
                onclick="expand_collapse('Setup_Topics')"
                ondblclick="expand_collapse('Setup_Topics')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                Setup
            </div>
            <div class="invisible" id="Setup_Topics" lang="QD">
                <div style="font-size:80%; margin-left:20px;">
                    MATLAB will recognize the functions exported in a properly compiled DLL if
                    you import its header file and link the DLL and all dependent libraries to
                    your MATLAB environment. In the instructions below, the string following the
                    <code>&gt;&gt;</code> symbol indicates the text to enter at the MATLAB Command Window prompt.
                </div>
                <br />
                <div style="font-size:80%; margin-left:40px;">
                    <li style="list-style-type:decimal;">
                        For MATLAB R2012b :
                        <ul>
                            <li style="list-style-type:disc;">
                                Make sure you have installed the Microsoft Visual C++ 2010 Express
                                software on the same (target) computer as the one you intend to run
                                MATLAB. You can find complete instructions at
                                <a href="http://www.mathworks.com/support/solutions/en/data/1-ECUGQX/" target="_blank">http://www.mathworks.com/support/solutions/en/data/1-ECUGQX/</a>
                            </li>
                        </ul>
                        For MATLAB R2008b :
                        <ul>
                            <li style="list-style-type:disc;">
                                Make sure you have installed the Microsoft Visual C++ 2008 Express
                                software on the same (target) computer as the one you intend to run
                                MATLAB. You can find complete instructions at
                                <a href="http://www.mathworks.com/support/solutions/en/data/1-6IJJ3L/" target="_blank">http://www.mathworks.com/support/solutions/en/data/1-6IJJ3L/</a>
                            </li>
                        </ul>
                    </li>
                    <li style="list-style-type:decimal;">
                        Install the SDK patch, which is described on the same web page.
                        <ul>
                            <li style="list-style-type:disc;">
                                For MATLAB R2008b, after installing the patch, set the following
                                environment variables:
                                <ul>
                                    <code>
                                        VS80COMNTOOLS = C:\Program Files (x86)\Microsoft Visual Studio 9.0\Common7\Tools
                                        <br />
                                        MSSdk = C:\Program Files\Microsoft SDKs\Windows\v6.1
                                    </code>
                                </ul>
                            </li>
                        </ul>
                        <ul>
                            <li style="list-style-type:disc;">
                                For MATLAB R2008b, after installing the patch, copy the file
                                <ul>
                                    <code>
                                        C:\Program Files (x86)\Microsoft Visual Studio 9.0\VC\bin\vcvars64.bat
                                    </code>
                                </ul>
                                to
                                <ul>
                                    <code>
                                        C:\Program Files (x86)\Microsoft Visual Studio 9.0\VC\bin\amd64\
                                    </code>
                                </ul>
                                and rename the file to <code>vcvarsamd64.bat</code>
                            </li>
                        </ul>
                    </li>
                    <li style="list-style-type:decimal;">
                        Instruct MATLAB to recognize your compiler by mimicking the following
                        dialogue in the MATLAB Command Window (your entries in bold) for your
                        particular version of MATLAB:
                        <br /><br />
                        <code>
                            &gt;&gt; <b>mex -setup</b><br />
                            <br />
                            Welcome to mex -setup.  This utility will help you set up<br />
                            a default compiler.  For a list of supported compilers, see<br />
                            http://www.mathworks.com/support/compilers/R2012b/win32.html<br />
                            <br />
                            Please choose your compiler for building MEX-files:<br />
                            <br />
                            Would you like mex to locate installed compilers [y]/n? <b>y</b><br />
                            <br />
                            Select a compiler:<br />
                            [1] Lcc-win32 C 2.4.1 in C:\PROGRA~1\MatLab\R2012b\sys\lcc<br />
                            [2] Microsoft Software Development Kit (SDK) 7.1 in c:\Program Files\Microsoft Visual Studio 10.0<br />
                            <br />
                            [0] None<br />
                            <br />
                            Compiler: <b>2</b><br />
                            <br />
                            Please verify your choices:<br />
                            <br />
                            Compiler: Microsoft Software Development Kit (SDK) 7.1<br />
                            Location: c:\Program Files\Microsoft Visual Studio 10.0<br />
                            <br />
                            Are these correct [y]/n? <b>y</b><br />
                            <br />
                            ***************************************************************************<br />
                            .<br />
                            .<br />
                            .<br />
                            ***************************************************************************<br />
                        </code>
                        <br />
                    </li>
                    <li style="list-style-type:decimal;">
                        Change directory to your working directory, where you saved the header and
                        DLL files
                        <br /><br />
                        <code>
                            &gt;&gt; <b>cd c:\MyDir\MATLAB</b><br />
                        </code>
                        <br />
                    </li>
                    <li style="list-style-type:decimal;">
                        Load the libraries. These will import the header files and link the
                        program with the required DLLs. The DLL filenames are case-sensitive; the
                        header filenames are not.
                        <br /><br />
                        <code>
                            &gt;&gt; <b>loadlibrary('SiUSBXp.dll','SiUSBXp.h');</b><br />
                            &gt;&gt; <b>loadlibrary('qdUSB.dll','qdUSB.h');</b><br />
                        </code>
                        <br />
                    </li>
                </div>
            </div>                      <? // end of Setup_Topics ?>
            <?  //------------------------------------------------------------
                // The DLL Functions
                //------------------------------------------------------------
            ?>
            <div class="category" id="DLLFunctions" style="margin-top:5px;"
                onclick="expand_collapse('DLLFunctions_Topics')"
                ondblclick="expand_collapse('DLLFunctions_Topics')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                The DLL Functions
            </div>
            <div class="invisible" id="DLLFunctions_Topics" lang="QD">
                <div style="font-size:80%; font-weight:normal; margin-left:20px;">
                    Assuming the QCOM hardware has been installed on the target computer, proceed
                    to call the DLL commands from the MATLAB Command Window as shown.
                    <ul style="list-style-type:disc;">
                        <li>
                            Comments are preceded by a percent (<code>%</code>) symbol
                        </li>
                        <li>
                            It is important in most instances to include or omit the terminating
                            semicolon in the commands exactly as shown
                        </li>
                        <li>
                            Many of the commands are case-sensitive
                        </li>
                        <li>
                            A single text file containing appropriate DLL function examples is
                            included in the download package
                        </li>
                        <li>
                            The firmware update functions have been omitted
                        </li>
                    </ul>
                </div>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_CompleteExample')"
                    ondblclick="expand_collapse('DLLFunctions_CompleteExample')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    Complete Pressure and Temperature Example<a name="DLL_CompleteExample"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_CompleteExample" lang="QD">
                    The following demonstrates a complete example of how to obtain a single
                    transducer reading for actual pressure and temperature of a transducer
                    attached to QCOM module unit 0.
                    <br /><br />
                    Create a pointer of type <code>voidPtrPtr</code> for the returned handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; unitHandlePtr = libpointer('voidPtrPtr');
                        </code>
                    </ul>
                    Call <code>QD_Open</code> with a hard-coded unit number of <code>0</code> and
                    the handle pointer, then store the returned handle in <code>unitHandle</code>
                    and the return code in <code>rCode</code>
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; unitNumber = uint32(0);
                            <br />
                            &gt;&gt; [rCode, unitHandle] = calllib('qdUSB', 'QD_Open', unitNumber, unitHandlePtr);
                        </code>
                    </ul>
                    Set up and call <code>QD_ReadCoefficientDataFromDevice</code>
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; coefficientDataPtr = libpointer('uint8Ptr', uint8(1:256));
                            <br />
                            &gt;&gt; [rCode, unused, coefficientData] = calllib('qdUSB', 'QD_ReadCoefficientDataFromDevice', unitHandle, coefficientDataPtr);
                        </code>
                    </ul>
                    Create pointers to the pressure and temperature values, respectively
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; presPtr = libpointer('doublePtr', 0.0);
                            <br />
                            &gt;&gt; tempPtr = libpointer('doublePtr', 0.0);
                        </code>
                    </ul>
                    Call <code>QD_GetPressureAndTemperature</code> with the unit handle and
                    a populated <code>coefficientData</code> buffer, then store the returned
                    pressure and temperature values and return code, allowing for an unused
                    return value of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, coefficientData, pressure, temperature] = calllib('qdUSB', 'QD_GetPressureAndTemperature', unitHandle, coefficientData, presPtr, tempPtr);
                        </code>
                    </ul>
                    Display the return code, pressure, and temperature
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), pressure, temperature
                        </code>
                    </ul>
                    Call <code>QD_Close</code>, to close the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode] = calllib('qdUSB', 'QD_Close', unitHandle);
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_CompleteExample ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_CalculatePressureAndTemperature')"
                    ondblclick="expand_collapse('DLLFunctions_CalculatePressureAndTemperature')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_CalculatePressureAndTemperature<a name="QD_CalculatePressureAndTemperature"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_CalculatePressureAndTemperature" lang="QD">
                    <i>Note: It is assumed that <code>coefficientData</code> is a pointer
                    to a buffer containing valid coefficient data</i> (see
                    <script type="text/javascript">jump_within_doc('ReadCoefficientDataFromHexFile');</script>)
                    <br /><br />
                    <i>Note: It is assumed that presCount and tempCount are valid pressure and
                    temperature count values, respectively</i> (see
                    <script type="text/javascript">jump_within_doc('GetTransducerCounts');</script>)
                    <br /><br />
                    Create pointers to the pressure and temperature values, respectively
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; presPtr = libpointer('doublePtr', 0.0);
                            <br />
                            &gt;&gt; tempPtr = libpointer('doublePtr', 0.0);
                        </code>
                    </ul>
                    Call <code>QD_CalculatePressureAndTemperature</code> with the populated
                    <code>coefficientData</code> buffer, then store the returned
                    pressure and temperature values and return code, allowing for an unused
                    return value of the coefficient data pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, pressure, temperature] = calllib('qdUSB', 'QD_CalculatePressureAndTemperature', coefficientData, presCount, tempCount, presPtr, tempPtr);
                        </code>
                    </ul>
                    Display the return code, pressure, and temperature
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), pressure, temperature
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_CalculatePressureAndTemperature ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_CalculatePressureOrTemperature')"
                    ondblclick="expand_collapse('DLLFunctions_CalculatePressureOrTemperature')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_CalculatePressureOrTemperature<a name="QD_CalculatePressureOrTemperature"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_CalculatePressureOrTemperature" lang="QD">
                    <i>Note: It is assumed that <code>coefficientData</code> is a pointer
                    to a buffer containing valid coefficient data</i> (see
                    <script type="text/javascript">jump_within_doc('ReadCoefficientDataFromHexFile');</script>)
                    <br /><br />
                    <i>Note: It is assumed that presCount and tempCount are valid pressure and
                    temperature count values, respectively</i> (see
                    <script type="text/javascript">jump_within_doc('GetTransducerCounts');</script>)
                    <br /><br />
                    Define the result as the temperature value (1) and create a pointer to the
                    resulting calculation
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; PorT = uint8(1);
                            <br />
                            &gt;&gt; resultPtr = libpointer('doublePtr', 0.0);
                        </code>
                    </ul>
                    Call <code>QD_CalculatePressureOrTemperature</code> with the populated
                    <code>coefficientData</code> buffer, pressure count, and temperature count,
                    then store the returned calculation in result and return code in <code>rCode</code>,
                    allowing for an unused return value of the coefficient data pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, result] = calllib('qdUSB', 'QD_CalculatePressureOrTemperature', PorT, coefficientData, presCount, tempCount, resultPtr);
                        </code>
                    </ul>
                    Display the return code and the calculated result
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), result
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_CalculatePressureOrTemperature ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_Close')"
                    ondblclick="expand_collapse('DLLFunctions_Close')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_Close<a name="QD_Close"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_Close" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode] = calllib('qdUSB', 'QD_Close', unitHandle);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_Close ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_CoefficientDataIsValid')"
                    ondblclick="expand_collapse('DLLFunctions_CoefficientDataIsValid')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_CoefficientDataIsValid<a name="QD_CoefficientDataIsValid"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_CoefficientDataIsValid" lang="QD">
                    <i>Note: It is assumed that <code>coefficientData</code> is a pointer
                    to a buffer containing valid coefficient data</i> (see
                    <script type="text/javascript">jump_within_doc('ReadCoefficientDataFromHexFile');</script>)
                    <br /><br />
                    Call <code>QD_CoefficientDataIsValid</code> with a pointer to the hex file
                    data, then store the return boolean value, allowing for the unused return
                    value of the coefficient data pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [yesNo, unused] = calllib('qdUSB', 'QD_CoefficientDataIsValid', coefficientData);
                        </code>
                    </ul>
                    Display the boolean result
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; yesNo
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_CoefficientDataIsValid ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_CoefficientHexFileDataIsValid')"
                    ondblclick="expand_collapse('DLLFunctions_CoefficientHexFileDataIsValid')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_CoefficientHexFileDataIsValid<a name="QD_CoefficientHexFileDataIsValid"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_CoefficientHexFileDataIsValid" lang="QD">
                    Read in the hex file data and create a pointer to the data
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; hexFileData = fileread('C:\MyDir\207917.hex');
                            <br />
                            &gt;&gt; hexFileDataPtr = libpointer('uint8Ptr', uint8(hexFileData));
                        </code>
                    </ul>
                    Call <code>QD_CoefficientHexFileDataIsValid</code> with a pointer to the hex file
                    data, then store the return boolean value, allowing for the unused return
                    value of the hex file data pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [yesNo, unused] = calllib('qdUSB', 'QD_CoefficientHexFileDataIsValid', hexFileDataPtr);
                        </code>
                    </ul>
                    Display the boolean result
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; yesNo
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_CoefficientHexFileDataIsValid ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_DataIsInHexFileFormat')"
                    ondblclick="expand_collapse('DLLFunctions_DataIsInHexFileFormat')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_DataIsInHexFileFormat<a name="QD_DataIsInHexFileFormat"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_DataIsInHexFileFormat" lang="QD">
                    Read in the hex file data and create a pointer to the data
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; hexFileData = fileread('C:\MyDir\207917.hex');
                            <br />
                            &gt;&gt; hexFileDataPtr = libpointer('uint8Ptr', uint8(hexFileData));
                        </code>
                    </ul>
                    Call <code>QD_DataIsInHexFileFormat</code> with a pointer to the hex file
                    data, then store the return boolean value, allowing for the unused return
                    value of the hex file data pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [yesNo, unused] = calllib('qdUSB', 'QD_DataIsInHexFileFormat', hexFileDataPtr);
                        </code>
                    </ul>
                    Display the boolean result
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; yesNo
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_DataIsInHexFileFormat ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_ExecuteI2CCommand')"
                    ondblclick="expand_collapse('DLLFunctions_ExecuteI2CCommand')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_ExecuteI2CCommand<a name="QD_ExecuteI2CCommand"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_ExecuteI2CCommand" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Create a command string and reply buffer, then pointers to them
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; command = uint8('S9BFFFFFFFFP');&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;% Get analog temperature
                            <br />
                            &gt;&gt; commandPtr = libpointer('uint8Ptr', command);
                            <br />
                            &gt;&gt; replyPtr = libpointer('uint8Ptr', uint8(1:256));
                        </code>
                    </ul>
                    Call <code>QD_ExecuteI2CCommand</code> with the command string and reply
                    string pointers, allowing for unused return values of the unit handle and
                    command string
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, unused, replyString] = calllib('qdUSB', 'QD_ExecuteI2CCommand', unitHandle, commandPtr, replyPtr);
                        </code>
                    </ul>
                    Display the return code and the reply string
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; replyString = char(replyString(1:strfind(replyString, 0)));
                            <br />
                            &gt;&gt; dec2hex(rCode), replyString
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_ExecuteI2CCommand ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_FormatCoefficientHexFileData')"
                    ondblclick="expand_collapse('DLLFunctions_FormatCoefficientHexFileData')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_FormatCoefficientHexFileData<a name="QD_FormatCoefficientHexFileData"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_FormatCoefficientHexFileData" lang="QD">
                    <i>Note: It is assumed that <code>coefficientData</code> is a pointer
                    to a buffer containing valid coefficient data</i> (see
                    <script type="text/javascript">jump_within_doc('ReadCoefficientDataFromDevice');</script>)
                    <br /><br />
                    Create a pointer to a 734-byte array of unsigned, 8-bit integers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; hexFileDataPtr = libpointer('uint8Ptr', uint8(1:734));
                        </code>
                    </ul>
                    Call <code>QD_FormatCoefficientHexFileData</code> with a pointer to the
                    coefficient data and a pointer to the empty hex file data, then store the
                    returned number of formatted bytes and the formatted hex file data,
                    allowing for an unused return value of the coefficient data pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [numberOfBytes, unused, hexFileData] = calllib('qdUSB', 'QD_FormatCoefficientHexFileData', coefficientData, hexFileDataPtr);
                        </code>
                    </ul>
                    Display the resulting number of bytes
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; numberOfBytes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;% Should always be 733
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_FormatCoefficientHexFileData ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetCadenceTimer')"
                    ondblclick="expand_collapse('DLLFunctions_GetCadenceTimer')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetCadenceTimer<a name="QD_GetCadenceTimer"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetCadenceTimer" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Define a pointer to the returned timer value
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; timerValuePtr = libpointer('uint32Ptr', uint32(0));
                        </code>
                    </ul>
                    Call <code>QD_GetCadenceTimer</code> with the timer value pointer, allowing
                    for an unused return value of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, timerValue] = calllib('qdUSB', 'QD_GetCadenceTimer', unitHandle, timerValuePtr);
                        </code>
                    </ul>
                    Display the return code and cadence timer value
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), timerValue
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetCadenceTimer ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetI2CDataRate')"
                    ondblclick="expand_collapse('DLLFunctions_GetI2CDataRate')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetI2CDataRate<a name="QD_GetI2CDataRate"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetI2CDataRate" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Define a pointer to the returned data rate
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dataRatePtr = libpointer('doublePtr', 0.0);
                        </code>
                    </ul>
                    Call <code>QD_GetI2CDataRate</code> with the pointer to the data rate,
                    allowing for an unused return value of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, dataRate] = calllib('qdUSB', 'QD_GetI2CDataRate', unitHandle, dataRatePtr);
                        </code>
                    </ul>
                    Display the return code and module-transducer I2C data rate
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), dataRate
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetI2CDataRate ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetMemoryType')"
                    ondblclick="expand_collapse('DLLFunctions_GetMemoryType')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetMemoryType<a name="QD_GetMemoryType"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetMemoryType" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Define a target device of 1 (QCOM module) and a pointer to the returned memory type
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; targetDevice = uint8(1);
                            <br />
                            &gt;&gt; memTypePtr = libpointer('uint8Ptr', uint8(0));
                        </code>
                    </ul>
                    Call <code>QD_GetMemoryType</code> with the target device and memory type
                    pointer, allowing for an unused return value of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, memoryType] = calllib('qdUSB', 'QD_GetMemoryType', unitHandle, targetDevice, memTypePtr);
                        </code>
                    </ul>
                    Display the return code and memory type (of the module in this case)
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), dec2hex(memoryType)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetMemoryType ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetModuleControlRegister')"
                    ondblclick="expand_collapse('DLLFunctions_GetModuleControlRegister')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetModuleControlRegister<a name="QD_GetModuleControlRegister"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetModuleControlRegister" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Create the 1-byte control register buffer and its corresponding pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; controlRegPtr = libpointer('uint8Ptr', uint8(0));
                        </code>
                    </ul>
                    Call <code>QD_GetModuleControlRegister</code>, allowing for an unused return value
                    of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, controlRegValue] = calllib('qdUSB', 'QD_GetModuleControlRegister', unitHandle, controlRegPtr);
                        </code>
                    </ul>
                    Display the return code and the contents of the Control Register in hex
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), dec2hex(controlRegValue)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetModuleControlRegister ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetModuleFirmwareID')"
                    ondblclick="expand_collapse('DLLFunctions_GetModuleFirmwareID')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetModuleFirmwareID<a name="QD_GetModuleFirmwareID"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetModuleFirmwareID" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Create a pointer to the 4-byte firmware ID buffer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; firmwareIDPtr = libpointer('uint8Ptr', uint8(1:4));
                        </code>
                    </ul>
                    Call <code>QD_GetModuleFirmwareID</code>, allowing for an unused return value
                    of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, firmwareID] = calllib('qdUSB', 'QD_GetModuleFirmwareID', unitHandle, firmwareIDPtr);
                        </code>
                    </ul>
                    Display the return code and the contents of the firmware ID array in hex
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), dec2hex(firmwareID)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetModuleFirmwareID ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetModuleSerialNumber')"
                    ondblclick="expand_collapse('DLLFunctions_GetModuleSerialNumber')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetModuleSerialNumber<a name="QD_GetModuleSerialNumber"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetModuleSerialNumber" lang="QD">
                    Create a 256-byte array of unsigned, 8-bit integers and its corresponding pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; stringPtr = libpointer('uint8Ptr', uint8(1:256));
                        </code>
                    </ul>
                    Call <code>QD_GetModuleSerialNumber</code> with a hard-coded unit number of
                    <code>0</code> and an empty string, then store the returned characters in
                    <code>moduleSNString</code> and the return code in <code>rCode</code>
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; unitNumber = uint32(0);
                            <br />
                            &gt;&gt; [rCode, moduleSNString] = calllib('qdUSB', 'QD_GetModuleSerialNumber', unitNumber, stringPtr);
                        </code>
                    </ul>
                    Display the return code and the array contents (the module serial number string)
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; moduleSNString = char(moduleSNString(1:strfind(moduleSNString, 0)));
                            <br />
                            &gt;&gt; dec2hex(rCode), moduleSNString
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetModuleSerialNumber ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetModuleStatusRegister')"
                    ondblclick="expand_collapse('DLLFunctions_GetModuleStatusRegister')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetModuleStatusRegister<a name="QD_GetModuleStatusRegister"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetModuleStatusRegister" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Create the 1-byte status register buffer and its corresponding pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; statusRegPtr = libpointer('uint8Ptr', uint8(0));
                        </code>
                    </ul>
                    Call <code>QD_GetModuleStatusRegister</code>, allowing for an unused return value
                    of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, statusRegValue] = calllib('qdUSB', 'QD_GetModuleStatusRegister', unitHandle, statusRegPtr);
                        </code>
                    </ul>
                    Display the return code and the contents of the Status Register in hex
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), dec2hex(statusRegValue)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetModuleStatusRegister ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetNumberOfModules')"
                    ondblclick="expand_collapse('DLLFunctions_GetNumberOfModules')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetNumberOfModules<a name="QD_GetNumberOfModules"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetNumberOfModules" lang="QD">
                    Call <code>QD_GetNumberOfModules</code> with no parameters, then store the
                    returned value (number of attached QCOM modules) in <code>numberOfModules</code>
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [numberOfModules] = calllib('qdUSB', 'QD_GetNumberOfModules');
                        </code>
                    </ul>
                    Display the number of modules
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; numberOfModules
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetNumberOfModules ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetPressureAndTemperature')"
                    ondblclick="expand_collapse('DLLFunctions_GetPressureAndTemperature')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetPressureAndTemperature<a name="QD_GetPressureAndTemperature"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetPressureAndTemperature" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Set up and call <code>QD_ReadCoefficientDataFromDevice</code>
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; coefficientDataPtr = libpointer('uint8Ptr', uint8(1:256));
                            <br />
                            &gt;&gt; [rCode, unused, coefficientData] = calllib('qdUSB', 'QD_ReadCoefficientDataFromDevice', unitHandle, coefficientDataPtr);
                        </code>
                    </ul>
                    Create pointers to the pressure and temperature values, respectively
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; presPtr = libpointer('doublePtr', 0.0);
                            <br />
                            &gt;&gt; tempPtr = libpointer('doublePtr', 0.0);
                        </code>
                    </ul>
                    Call <code>QD_GetPressureAndTemperature</code> with the unit handle
                    and a populated <code>coefficientData</code> buffer, then store the returned
                    pressure and temperature values and return code, allowing for unused return
                    values of the unit handle and coefficient data pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, unused, pressure, temperature] = calllib('qdUSB', 'QD_GetPressureAndTemperature', unitHandle, coefficientData, presPtr, tempPtr);
                        </code>
                    </ul>
                    Display the return code, pressure, and temperature
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), pressure, temperature
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetPressureAndTemperature ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetProductInfo')"
                    ondblclick="expand_collapse('DLLFunctions_GetProductInfo')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetProductInfo<a name="QD_GetProductInfo"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetProductInfo" lang="QD">
                    Create a pointer to a 256-byte array of unsigned, 8-bit integers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; stringPtr = libpointer('uint8Ptr', uint8(1:256));
                        </code>
                    </ul>
                    Call <code>QD_GetProductInfo</code> with a hard-coded unit number of
                    <code>0</code>, an item number of <code>1</code> (Product Description),
                    and an empty string, then store the returned characters in
                    <code>productInfoString</code> and the return code in <code>rCode</code>
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; unitNumber = uint32(0);
                            <br />
                            &gt;&gt; itemNumber = uint32(1);
                            <br />
                            &gt;&gt; [rCode, productInfoString] = calllib('qdUSB', 'QD_GetProductInfo', unitNumber, stringPtr, itemNumber);
                        </code>
                    </ul>
                    Display the return code and the array contents (the product description string)
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; productInfoString = char(productInfoString(1:strfind(productInfoString, 0)));
                            <br />
                            &gt;&gt; dec2hex(rCode), productInfoString
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetProductInfo ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetQDDLLVersion')"
                    ondblclick="expand_collapse('DLLFunctions_GetQDDLLVersion')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetQDDLLVersion<a name="QD_GetQDDLLVersion"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetQDDLLVersion" lang="QD">
                    Create pointers for three 8-bit unsigned integers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; majorPtr = libpointer('uint8Ptr', uint8(0));
                            <br />
                            &gt;&gt; minorPtr = libpointer('uint8Ptr', uint8(0));
                            <br />
                            &gt;&gt; buildPtr = libpointer('uint8Ptr', uint8(0));
                        </code>
                    </ul>
                    Call <code>QD_GetQDDLLVersion</code> with the three pointers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, majorVer, minorVer, buildVer] = calllib('qdUSB', 'QD_GetQDDLLVersion', majorPtr, minorPtr, buildPtr);
                        </code>
                    </ul>
                    Display the return code and final constructed version value
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; version = strcat(int2str(majorVer), '.', int2str(minorVer), '.', int2str(buildVer));
                            <br />
                            &gt;&gt; dec2hex(rCode), version
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetQDDLLVersion ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetTimeouts')"
                    ondblclick="expand_collapse('DLLFunctions_GetTimeouts')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetTimeouts<a name="QD_GetTimeouts"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetTimeouts" lang="QD">
                    Create pointers for two 32-bit unsigned integers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; readTimeoutPtr = libpointer('uint32Ptr', uint32(0));
                            <br />
                            &gt;&gt; writeTimeoutPtr = libpointer('uint32Ptr', uint32(0));
                        </code>
                    </ul>
                    Call <code>QD_GetTimeouts</code> with the two pointers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, readTimeout, writeTimeout] = calllib('qdUSB', 'QD_GetTimeouts', readTimeoutPtr, writeTimeoutPtr);
                        </code>
                    </ul>
                    Display the return code and the two timeout values
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), readTimeout, writeTimeout
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetTimeouts ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetTransducerCounts')"
                    ondblclick="expand_collapse('DLLFunctions_GetTransducerCounts')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetTransducerCounts<a name="QD_GetTransducerCounts"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetTransducerCounts" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Create pointers to the pressure and temperature values, respectively
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; presPtr = libpointer('uint32Ptr', uint32(0));
                            <br />
                            &gt;&gt; tempPtr = libpointer('uint32Ptr', uint32(0));
                        </code>
                    </ul>
                    Call <code>QD_GetTransducerCounts</code>, allowing for an unused return value
                    of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, presCount, tempCount] = calllib('qdUSB', 'QD_GetTransducerCounts', unitHandle, presPtr, tempPtr);
                        </code>
                    </ul>
                    Display the return code, the pressure count, and the temperature count
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), presCount, tempCount
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetTransducerCounts ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetTransducerCurrent')"
                    ondblclick="expand_collapse('DLLFunctions_GetTransducerCurrent')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetTransducerCurrent<a name="QD_GetTransducerCurrent"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetTransducerCurrent" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Create the current value buffer and its corresponding pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; currentPtr = libpointer('doublePtr', 0.0);
                        </code>
                    </ul>
                    Call <code>QD_GetTransducerCurrent</code>, allowing for an unused return value
                    of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, currentValue] = calllib('qdUSB', 'QD_GetTransducerCurrent', unitHandle, currentPtr);
                        </code>
                    </ul>
                    Display the return code and the current value
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), currentValue
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetTransducerCurrent ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetTransducerType')"
                    ondblclick="expand_collapse('DLLFunctions_GetTransducerType')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetTransducerType<a name="QD_GetTransducerType"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetTransducerType" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Define a pointer to the returned transducer type
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; transducerTypePtr = libpointer('uint8Ptr', uint8(0));
                        </code>
                    </ul>
                    Call <code>QD_GetTransducerType</code> with the transducer type pointer,
                    allowing for an unused return value of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, transducerType] = calllib('qdUSB', 'QD_GetTransducerType', unitHandle, transducerTypePtr);
                        </code>
                    </ul>
                    Display the return code and transducer type
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), dec2hex(transducerType)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetTransducerType ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetTransducerVoltage')"
                    ondblclick="expand_collapse('DLLFunctions_GetTransducerVoltage')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetTransducerVoltage<a name="QD_GetTransducerVoltage"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetTransducerVoltage" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Create the voltage value buffer and its corresponding pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; voltagePtr = libpointer('doublePtr', 0.0);
                        </code>
                    </ul>
                    Call <code>QD_GetTransducerVoltage</code>, allowing for an unused return value
                    of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, voltageValue] = calllib('qdUSB', 'QD_GetTransducerVoltage', unitHandle, voltagePtr);
                        </code>
                    </ul>
                    Display the return code and the voltage value
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode), voltageValue
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetTransducerVoltage ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetUSBDLLVersion')"
                    ondblclick="expand_collapse('DLLFunctions_GetUSBDLLVersion')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetUSBDLLVersion<a name="QD_GetUSBDLLVersion"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetUSBDLLVersion" lang="QD">
                    Create pointers for two 32-bit unsigned integers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; upperPtr = libpointer('uint32Ptr', uint32(0));
                            <br />
                            &gt;&gt; lowerPtr = libpointer('uint32Ptr', uint32(0));
                        </code>
                    </ul>
                    Call <code>QD_GetUSBDLLVersion</code> with the two pointers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, upperVersion, lowerVersion] = calllib('qdUSB', 'QD_GetUSBDLLVersion', upperPtr, lowerPtr);
                        </code>
                    </ul>
                    Display the return code and final constructed version value
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; majorVersion = bitshift(upperVersion, -16);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;% shift right
                            <br />
                            &gt;&gt; minorVersion = bitand(upperVersion, hex2dec('FFFF'));&nbsp;&nbsp;% mask off the upper word
                            <br />
                            &gt;&gt; buildVersion = bitshift(lowerVersion, -16);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;% shift right
                            <br />
                            &gt;&gt; revision = bitand(lowerVersion, hex2dec('FFFF'));&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;% mask off the upper word
                            <br />
                            &gt;&gt; version = strcat(dec2hex(majorVersion), '.', dec2hex(minorVersion), '.', dec2hex(buildVersion), '.', dec2hex(revision));
                            <br />
                            &gt;&gt; dec2hex(rCode), version
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetUSBDLLVersion ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_GetUSBDriverVersion')"
                    ondblclick="expand_collapse('DLLFunctions_GetUSBDriverVersion')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_GetUSBDriverVersion<a name="QD_GetUSBDriverVersion"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_GetUSBDriverVersion" lang="QD">
                    Create pointers for two 32-bit unsigned integers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; upperPtr = libpointer('uint32Ptr', uint32(0));
                            <br />
                            &gt;&gt; lowerPtr = libpointer('uint32Ptr', uint32(0));
                        </code>
                    </ul>
                    Call <code>QD_GetUSBDriverVersion</code> with the two pointers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, upperVersion, lowerVersion] = calllib('qdUSB', 'QD_GetUSBDriverVersion', upperPtr, lowerPtr);
                        </code>
                    </ul>
                    Display the return code and final constructed version value
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; majorVersion = bitshift(upperVersion, -16);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;% shift right
                            <br />
                            &gt;&gt; minorVersion = bitand(upperVersion, hex2dec('FFFF'));&nbsp;&nbsp;% mask off the upper word
                            <br />
                            &gt;&gt; buildVersion = bitshift(lowerVersion, -16);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;% shift right
                            <br />
                            &gt;&gt; revision = bitand(lowerVersion, hex2dec('FFFF'));&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;% mask off the upper word
                            <br />
                            &gt;&gt; version = strcat(dec2hex(majorVersion), '.', dec2hex(minorVersion), '.', dec2hex(buildVersion), '.', dec2hex(revision));
                            <br />
                            &gt;&gt; dec2hex(rCode), version
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_GetUSBDriverVersion ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_HexFileFormatIsValid')"
                    ondblclick="expand_collapse('DLLFunctions_HexFileFormatIsValid')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_HexFileFormatIsValid<a name="QD_HexFileFormatIsValid"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_HexFileFormatIsValid" lang="QD">
                    Read in the hex file data and create a pointer to the data
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; hexFileData = fileread('C:\MyDir\207917.hex');
                            <br />
                            &gt;&gt; hexFileDataPtr = libpointer('uint8Ptr', uint8(hexFileData));
                        </code>
                    </ul>
                    Call <code>QD_HexFileFormatIsValid</code> with a pointer to the hex file
                    data, then store the return boolean value, allowing for the unused return
                    value of the hex file data pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [yesNo, unused] = calllib('qdUSB', 'QD_HexFileFormatIsValid', hexFileDataPtr);
                        </code>
                    </ul>
                    Display the boolean result
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; yesNo
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_HexFileFormatIsValid ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_Open')"
                    ondblclick="expand_collapse('DLLFunctions_Open')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_Open<a name="QD_Open"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_Open" lang="QD">
                    Create a pointer of type <code>voidPtrPtr</code> for the returned handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; unitHandlePtr = libpointer('voidPtrPtr');
                        </code>
                    </ul>
                    Call <code>QD_Open</code> with a hard-coded unit number of <code>0</code> and
                    the handle pointer, then store the returned handle in <code>unitHandle</code>
                    and the return code in <code>rCode</code>
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; unitNumber = uint32(0);
                            <br />
                            &gt;&gt; [rCode, unitHandle] = calllib('qdUSB', 'QD_Open', unitNumber, unitHandlePtr);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_Open ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_ReadCoefficientDataFromDevice')"
                    ondblclick="expand_collapse('DLLFunctions_ReadCoefficientDataFromDevice')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_ReadCoefficientDataFromDevice<a name="QD_ReadCoefficientDataFromDevice"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_ReadCoefficientDataFromDevice" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Create a pointer to a 256-byte array of unsigned, 8-bit integers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; coefficientDataPtr = libpointer('uint8Ptr', uint8(1:256));
                        </code>
                    </ul>
                    Call <code>QD_ReadCoefficientDataFromDevice</code> with the unit handle
                    and an empty <code>coefficientDataPtr</code> buffer, then store the returned
                    characters in <code>coefficientData</code> and the return code in
                    <code>rCode</code>, allowing for an unused return value of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, coefficientData] = calllib('qdUSB', 'QD_ReadCoefficientDataFromDevice', unitHandle, coefficientDataPtr);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_ReadCoefficientDataFromDevice ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_ReadCoefficientDataFromHexFile')"
                    ondblclick="expand_collapse('DLLFunctions_ReadCoefficientDataFromHexFile')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_ReadCoefficientDataFromHexFile<a name="QD_ReadCoefficientDataFromHexFile"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_ReadCoefficientDataFromHexFile" lang="QD">
                    <i>Note: The path name is case-sensitive</i>
                    <br /><br />
                    Create a 256-byte array of unsigned, 8-bit integers for the coefficient
                    data, a static string for the file path, and their corresponding pointers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; coefficientDataPtr = libpointer('uint8Ptr', uint8(1:256));
                            <br />
                            &gt;&gt; pathArray = uint8('C:\MyDir\207917.hex');
                            <br />
                            &gt;&gt; pathPtr = libpointer('uint8Ptr', pathArray);
                        </code>
                    </ul>
                    By the way, to determine whether the file exists, you can enter
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; isempty(dir('C:\MyDir\207917.hex'))
                        </code>
                    </ul>
                    Call <code>QD_ReadCoefficientDataFromHexFile</code> with the path string
                    filled and an empty coefficient data buffer, then store the returned
                    characters in <code>coefficientData</code> and the return code in
                    <code>rCode</code>, along with the unused path name string
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, coefficientData] = calllib('qdUSB', 'QD_ReadCoefficientDataFromHexFile', pathPtr, coefficientDataPtr);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_ReadCoefficientDataFromHexFile ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_ReadCoefficientDataFromModulePage')"
                    ondblclick="expand_collapse('DLLFunctions_ReadCoefficientDataFromModulePage')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_ReadCoefficientDataFromModulePage<a name="QD_ReadCoefficientDataFromModulePage"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_ReadCoefficientDataFromModulePage" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Define a page number of 2, a 256-byte array of unsigned, 8-bit integers for
                    the coefficient data, and their corresponding pointers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; pageNumber = uint8(2);
                            <br />
                            &gt;&gt; coefficientDataPtr = libpointer('uint8Ptr', uint8(1:256));
                        </code>
                    </ul>
                    Call <code>QD_ReadCoefficientDataFromModulePage</code> with the unit handle,
                    page number, and an empty coefficient data buffer, then store the returned
                    characters in <code>coefficientData</code> and the return code in
                    <code>rCode</code>, allowing for an unused return value of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, coefficientData] = calllib('qdUSB', 'QD_ReadCoefficientDataFromModulePage', unitHandle, pageNumber, coefficientDataPtr);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_ReadCoefficientDataFromModulePage ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_ReadCoefficientDataFromSourcePage')"
                    ondblclick="expand_collapse('DLLFunctions_ReadCoefficientDataFromSourcePage')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_ReadCoefficientDataFromSourcePage<a name="QD_ReadCoefficientDataFromSourcePage"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_ReadCoefficientDataFromSourcePage" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Define a target device of 1 (QCOM module), a page number of 2, a 256-byte array of
                    unsigned, 8-bit integers for the coefficient data, and their corresponding
                    pointers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; targetDevice = uint8(1);
                            <br />
                            &gt;&gt; pageNumber = uint8(2);
                            <br />
                            &gt;&gt; coefficientDataPtr = libpointer('uint8Ptr', uint8(1:256));
                        </code>
                    </ul>
                    Call <code>QD_ReadCoefficientDataFromSourcePage</code> with the unit handle,
                    target device, page number, and an empty coefficient data buffer, then
                    store the returned characters in <code>coefficientData</code> and the
                    return code in <code>rCode</code>, allowing for an unused return value of
                    the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, coefficientData] = calllib('qdUSB', 'QD_ReadCoefficientDataFromSourcePage', unitHandle, targetDevice, pageNumber, coefficientDataPtr);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_ReadCoefficientDataFromSourcePage ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_ResetModule')"
                    ondblclick="expand_collapse('DLLFunctions_ResetModule')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_ResetModule<a name="QD_ResetModule"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_ResetModule" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Call <code>QD_ResetModule</code>, allowing for an unused return value of the
                    unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused] = calllib('qdUSB', 'QD_ResetModule', unitHandle);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_ResetModule ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_SetCadenceTimer')"
                    ondblclick="expand_collapse('DLLFunctions_SetCadenceTimer')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_SetCadenceTimer<a name="QD_SetCadenceTimer"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_SetCadenceTimer" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Call <code>QD_SetCadenceTimer</code> with the timer value, allowing for an
                    unused return value of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; timerValue = uint32(1721);
                            <br />
                            &gt;&gt; [rCode, unused] = calllib('qdUSB', 'QD_SetCadenceTimer', unitHandle, timerValue);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_SetCadenceTimer ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_SetFirmwareMode')"
                    ondblclick="expand_collapse('DLLFunctions_SetFirmwareMode')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_SetFirmwareMode<a name="QD_SetFirmwareMode"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_SetFirmwareMode" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    <b><i>Important: Exercise great caution when using this function...use only if necessary</i></b>
                    <br />
                    Its primary purpose is for QCOM module firmware updating, which you will only
                    be able to do from the QCOM software. As a MATLAB user, your sole purpose for
                    using this function should be to return the module to Application Mode, in
                    case the module was left in Boot Loader Mode by mistake.
                    <br /><br />
                    Call <code>QD_SetFirmwareMode</code> with <code>mode</code> to set (Application
                    Mode, in this case), allowing for an unused return value of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; mode = uint8(0);
                            </br />
                            &gt;&gt; [rCode, unused] = calllib('qdUSB', 'QD_SetFirmwareMode', unitHandle, mode);
                        </code>
                    </ul>
                    Important: The call to <code>QD_SetFirmwareMode</code> must be followed by a
                    minimum 1500 ms delay, then a call to <code>QD_Close</code> and then
                    <code>QD_Open</code>, if you plan to continue communicating with the QCOM
                    module afterwards
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; pause(1.5)
                            <br />
                            &gt;&gt; [rCode] = calllib('qdUSB', 'QD_Close', unitHandle);
                            <br />
                            &gt;&gt; unitNumber = uint32(0);
                            <br />
                            &gt;&gt; unitHandlePtr = libpointer('voidPtrPtr');
                            <br />
                            &gt;&gt; [rCode, unitHandle] = calllib('qdUSB', 'QD_Open', unitNumber, unitHandlePtr);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_SetFirmwareMode ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_SetI2CDataRate')"
                    ondblclick="expand_collapse('DLLFunctions_SetI2CDataRate')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_SetI2CDataRate<a name="QD_SetI2CDataRate"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_SetI2CDataRate" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Call <code>QD_SetI2CDataRate</code> with the data rate, allowing for an
                    unused return value of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dataRate = 100.0;
                            <br />
                            &gt;&gt; [rCode, unused] = calllib('qdUSB', 'QD_SetI2CDataRate', unitHandle, dataRate);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_SetI2CDataRate ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_SetModuleControlRegister')"
                    ondblclick="expand_collapse('DLLFunctions_SetModuleControlRegister')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_SetModuleControlRegister<a name="QD_SetModuleControlRegister"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_SetModuleControlRegister" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Call <code>QD_SetModuleControlRegister</code> with the Control Register value,
                    allowing for an unused return value of the unit handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; controlRegValue = uint8(hex2dec('02'));
                            <br />
                            &gt;&gt; [rCode, unused] = calllib('qdUSB', 'QD_SetModuleControlRegister', unitHandle, controlRegValue);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_SetModuleControlRegister ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_SetTimeouts')"
                    ondblclick="expand_collapse('DLLFunctions_SetTimeouts')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_SetTimeouts<a name="QD_SetTimeouts"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_SetTimeouts" lang="QD">
                    Call <code>QD_SetTimeouts</code> with the two values
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; readTimeout = uint32(5000);
                            <br />
                            &gt;&gt; writeTimeout = uint32(10000);
                            <br />
                            &gt;&gt; [rCode] = calllib('qdUSB', 'QD_SetTimeouts', readTimeout, writeTimeout);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_SetTimeouts ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_SetTransducerPowerState')"
                    ondblclick="expand_collapse('DLLFunctions_SetTransducerPowerState')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_SetTransducerPowerState<a name="QD_SetTransducerPowerState"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_SetTransducerPowerState" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script></i>
                    <br /><br />
                    Call <code>QD_SetTransducerPowerState</code> with the power state to set
                    (Enable Power, in this case), allowing for an unused return value of the unit
                    handle
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; powerState = uint8(1);
                            <br />
                            &gt;&gt; [rCode, unused] = calllib('qdUSB', 'QD_SetTransducerPowerState', unitHandle, powerState);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_SetTransducerPowerState ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_WriteCoefficientDataToDevice')"
                    ondblclick="expand_collapse('DLLFunctions_WriteCoefficientDataToDevice')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_WriteCoefficientDataToDevice<a name="QD_WriteCoefficientDataToDevice"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_WriteCoefficientDataToDevice" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script>,
                    and that <code>coefficientData</code> is a pointer to a buffer containing
                    valid coefficient data</i> (see
                    <script type="text/javascript">jump_within_doc('ReadCoefficientDataFromDevice');</script>)
                    <br /><br />
                    Call <code>QD_WriteCoefficientDataToDevice</code> with the unit handle and
                    a pointer to the coefficient data buffer, then store the return code in
                    <code>rCode</code>, allowing for unused return values of the unit handle
                    and coefficient data buffer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, unused] = calllib('qdUSB', 'QD_WriteCoefficientDataToDevice', unitHandle, coefficientData);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_WriteCoefficientDataToDevice ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_WriteCoefficientDataToHexFile')"
                    ondblclick="expand_collapse('DLLFunctions_WriteCoefficientDataToHexFile')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_WriteCoefficientDataToHexFile<a name="QD_WriteCoefficientDataToHexFile"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_WriteCoefficientDataToHexFile" lang="QD">
                    <i>Note: It is assumed that <code>coefficientData</code> is a pointer
                    to a buffer containing valid coefficient data</i> (see
                    <script type="text/javascript">jump_within_doc('ReadCoefficientDataFromHexFile');</script>)
                    <br /><br />
                    <i>Note: A known bug in QD_WriteCoefficientDataToHexFile can prevent the
                    successful writing of the coefficient data to the specified file if the
                    file does not already exist. To work around this bug, create a dummy file
                    by the same name before calling this function.</i>
                    <br /><br />
                    Create a pointer to a static string for the file path
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; pathArray = uint8('C:\MyDir\New_207917.hex');
                            <br />
                            &gt;&gt; pathPtr = libpointer('uint8Ptr', pathArray);
                        </code>
                    </ul>
                    Call <code>QD_WriteCoefficientDataToHexFile</code> with the pointer to
                    the coefficient data buffer and a pointer to the file path string, then
                    store the return code in <code>rCode</code>, allowing for unused return
                    values of the coefficient data buffer and file path string
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, unused] = calllib('qdUSB', 'QD_WriteCoefficientDataToHexFile', coefficientData, pathPtr);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_WriteCoefficientDataToHexFile ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_WriteCoefficientDataToModulePage')"
                    ondblclick="expand_collapse('DLLFunctions_WriteCoefficientDataToModulePage')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_WriteCoefficientDataToModulePage<a name="QD_WriteCoefficientDataToModulePage"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_WriteCoefficientDataToModulePage" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script>,
                    and that <code>coefficientData</code> is a pointer to a buffer containing
                    valid coefficient data</i> (see
                    <script type="text/javascript">jump_within_doc('ReadCoefficientDataFromModulePage');</script>)
                    <br /><br />
                    Define a page number of 0 and its corresponding pointer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; pageNumber = uint8(2);
                        </code>
                    </ul>
                    Call <code>QD_WriteCoefficientDataToModulePage</code> with the unit handle,
                    page number, and a pointer to the coefficient data buffer, then store the
                    return code in <code>rCode</code>, allowing for unused return values of
                    the unit handle and coefficient data buffer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, unused] = calllib('qdUSB', 'QD_WriteCoefficientDataToModulePage', unitHandle, pageNumber, coefficientData);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_WriteCoefficientDataToModulePage ?>
                <div class="topic" style="margin-left:20px;"
                    onclick="expand_collapse('DLLFunctions_WriteCoefficientDataToTargetPage')"
                    ondblclick="expand_collapse('DLLFunctions_WriteCoefficientDataToTargetPage')"
                    onmouseover="this.style.color = 'darkgoldenrod';"
                    onmouseout="this.style.color = 'purple';">
                    QD_WriteCoefficientDataToTargetPage<a name="QD_WriteCoefficientDataToTargetPage"></a>
                </div>
                <div class="subtopic" style="margin-left:40px; font-size:80%;" id="DLLFunctions_WriteCoefficientDataToTargetPage" lang="QD">
                    <i>Note: It is assumed that <code>unitHandle</code> is a valid unit handle
                    returned by <script type="text/javascript">jump_within_doc('Open');</script>,
                    and that <code>coefficientData</code> is a pointer to a buffer containing
                    valid coefficient data</i> (see
                    <script type="text/javascript">jump_within_doc('ReadCoefficientDataFromSourcePage');</script>)
                    <br /><br />
                    Define a target device of 1 (QCOM module), a page number of 2, and their
                    corresponding pointers
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; targetDevice = uint8(1);
                            <br />
                            &gt;&gt; pageNumber = uint8(2);
                        </code>
                    </ul>
                    Call <code>QD_WriteCoefficientDataToTargetPage</code> with the unit handle,
                    target device, page number, and a pointer to the coefficient data buffer,
                    then store the return code in <code>rCode</code>, allowing for unused
                    return values of the unit handle and coefficient data buffer
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; [rCode, unused, unused] = calllib('qdUSB', 'QD_WriteCoefficientDataToTargetPage', unitHandle, targetDevice, pageNumber, coefficientData);
                        </code>
                    </ul>
                    Display the return code
                    <br />
                    <ul>
                        <code>
                            &gt;&gt; dec2hex(rCode)
                        </code>
                    </ul>
                </div>                  <? // end of DLLFunctions_WriteCoefficientDataToTargetPage ?>
            </div>                      <? // end of DLLFunctions_Topics ?>
            <?  //------------------------------------------------------------
                // Other Applicable QCOM Resources
                //------------------------------------------------------------
            ?>
            <div class="category" id="Other" style="margin-top:5px;"
                onclick="expand_collapse('Other_Topics')"
                ondblclick="expand_collapse('Other_Topics')"
                onmouseover="this.style.color = 'green';"
                onmouseout="this.style.color = 'blue';">
                Other Applicable QCOM Resources
            </div>
            <div class="invisible" id="Other_Topics" style="margin-left:20px;" lang="QD">
                <a href="<?=QCOM_DLL_Spec ?>" target="_blank">
                    <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
                </a> the latest QCOM DLL specification (version <?=DLLSpecVersion?> on <?=DLLSpecDate ?>)
                <br />
                <a href="<?=QCOM_Drivers ?>">
                    <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
                </a> the latest QCOM Drivers (version <?=driverVersion ?>)
                <br />
                <a href="<?=QCOM_Firmware ?>">
                    <img src="/image/Download-Button.gif" style="width:110px; vertical-align:middle; margin-bottom:8px;" alt="Download" />
                </a> the latest QCOM Firmware (version <?=firmwareVersion ?>)
            </div>                      <? // end of Other_Topics ?>
        </div>                          <? // end of MainBody ?>
        <hr class="redLine" />
        <div class="page_bottom" id="MainFooter">
            <i class="flush_left">Copyright &copy; <?=date('Y'); ?> <a href="<?=QD_HomeDir ?>" target="_blank">Quartzdyne, Inc.</a>, a <a href="<?=DoverDir ?>" target="_blank">Dover</a><sup>&reg;</sup> company</i>
            <span class="flush_right" style="font-size:80%;">(Version <?=sourceVersion ?> [<script type="text/javascript">document.write(browserFlag);</script>])</span>
        </div>                          <? // end of MainFooter ?>
    </body>
</html>
<?php
//============================================================================
// QCOM-MATLAB.php Revision History (defined as sourceVersion in this source)
//
//  22 Mar 2013     1.0.0       1.  Initial public release
//
//  26 Mar 2013     1.0.1       1.  Updated for Windows Server 2003 R2 SP2
//                                  64-bit and Microsoft Visual C++ 2008
//                                  Express
//
//  18 Mar 2014     1.0.2       1.  Began using MainDefs.php
//                              2.  Moved the browser detection scripts to
//                                  PageHeader.js
//
//  10 Sep 2015     1.0.3       1.  Updated for the new qdlamp
//                              2.  Updated for Windows 10 and Windows Edge
//
// End of QCOM-MATLAB.php
//============================================================================
?>
