<?php
//============================================================================
// //qdlamp/var/www/qd.quartzdyne.com/QCOM/QCOM-TC-Check.php
//
// Quartzdyne Transducer Coefficient Check
//
// Copyright (C) 2011 - 2015 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software.  Also,
// a detailed revision history of this file is included at the bottom of this
// source.
//
// Updated 08-04-2015
//============================================================================
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: -1');
    header('Pragma: no-cache');
    define('displayVersion', '1.0.10');
    define('updatedDate', '2015-09-10');
    define('sourceVersion', displayVersion . '.' . updatedDate);
    include('/var/www/qd.quartzdyne.com/script/server/MainDefs.php');
    //------------------------------------------------------------------------
    // Support
    //------------------------------------------------------------------------
    define('emailSubject' , 'QCOM TC Check (Version ' . sourceVersion . ')');
    define('reportIssues',
        'Please communicate problems and suggestions to <a href="' . mailSite . '?emailSubject=' .
        emailSubject . '&dest=support" target="_blank">Quartzdyne Support</a>');
    //------------------------------------------------------------------------
    // Program parameters
    //------------------------------------------------------------------------
    $serialNumber = ($_REQUEST['serialNumber']);
    $partNumber = ($_REQUEST['partNumber']);
    $calDir = ($_REQUEST['calDir']);
    $digital = ($_REQUEST['digital']);
    $fPressureValue = ($_REQUEST['fpValue']);
    $fTemperatureValue = ($_REQUEST['ftValue']);
    $fPressureFrequency = ($_REQUEST['fpFreq']);
    $fTemperatureFrequency = ($_REQUEST['ftFreq']);
    $dPressureValue = ($_REQUEST['dpValue']);
    $dTemperatureValue = ($_REQUEST['dtValue']);
    $dPressureFrequency = ($_REQUEST['dpFreq']);
    $dTemperatureFrequency = ($_REQUEST['dtFreq']);
    $memoryType = ($_REQUEST['memoryType']);
    $blankLines = 39;
    //------------------------------------------------------------------------
    include('/script/server/compresshtml.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="eng">
    <head>
        <title>Quartzdyne Transducer Coefficient Check</title>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <meta name="description" content="This page displays the Quartzdyne Transducer Coefficient Check" />
        <meta name="keywords" content="quartzdyne, pressure, temperature, transducer, coefficient, check" />
        <meta name="distribution" content="global" />
        <meta name="author" content="Noji Ratzlaff" />
        <link href="/image/quartzdyne.ico" rel="shortcut icon" type="image/x-icon" />
        <link href="/style/qdprogstd.css" rel="stylesheet" type="text/css" />
        <link href="/style/reset1.css" rel="stylesheet" type="text/css" />
        <link href="/style/table1.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
            body
            {
                background-image: url('/image/white_sand.jpg');
                font: 100% verdana,sans-serif;
                margin-left: 16px;
                margin-right: 16px;
                margin-top: 8px;
            }
            table, tr, th, td
            {
                padding: 15px !important;
            }
            @media print
            {
                table
                {
                    font-size: 140%;
                }
            }
        </style>
        <?  //----------------------------------------------------------------
            // Invoke the javascript page header functions
            //----------------------------------------------------------------
        ?>
        <script src="<?=clientScriptDir ?>PageHeader.js" language="javascript" type="text/javascript"></script>
        <?  //----------------------------------------------------------------
            // Define javascript functions
            //----------------------------------------------------------------
        ?>
        <script type="text/javascript">
<!--
            //----------------------------------------------------------------
            // display_footer
            //
            // Displays a footer
            //----------------------------------------------------------------
            function display_footer()
            {
                //------------------------------------------------------------
                document.write(
                    '<div style="font-size:72%; color:black; font-weight:normal; margin-top:10px; margin-bottom:10px;">' +
                    '<span class="flush_left"><?=reportIssues ?></span></div>');
            }                           // end of display_footer()
//-->
        </script>
    </head>
    <body onselectstart="event.returnValue=false;">
        <div id="qd_div" lang="QD"></div>
        <?  //----------------------------------------------------------------
            // Display the company logo and prompt the user to print the page
            //----------------------------------------------------------------
        ?>
        <div style="margin:auto; text-align:center; width:1000px;" id="MainHeader">
            <a href="<?=QD_HomeDir ?>" target="_blank" name="help_top">
                <img src="/image/QDDoverLogo.png" style="float:left; width:150px; margin-bottom:10px;" alt="Quartzdyne" />
            </a>
            <div style="margin-left:20px; margin-bottom:10px; text-align:center; float:left;">
                <div style="color:black; font-weight:bold; font-size:200%;">
                    <span style="font-style:italic; font-weight:extra-bold; font-family:Arial,sans;">
                        Quartzdyne Transducer Coefficient Check
                    </span>
                </div>
                <span style="font-size:120%; margin-top:5px;">
                    <?=date('D d M Y h:i:s a'); ?>
                </span>
                <span>
                    <form style="margin-top:10px;">
                        <input
                            type="button"
                            onClick="window.print()"
                            value=" Print This Report "
                            style="color:blue;" />
                    </form>
                </span>
            </div>
        </div>                          <? // end of MainHeader ?>
        <div style="clear:both;" id="MainBody">
            <?  //------------------------------------------------------------
                // Display the header of the help text
                //------------------------------------------------------------
            ?>
            <div style="text-align:center; margin-top:5px; margin-bottom:10px;">
                Serial Number:&nbsp;&nbsp;<b><?=$serialNumber?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Part Number:&nbsp;&nbsp;<b><?=$partNumber?></b>
            </div>
            <?  //------------------------------------------------------------
                // Display the coefficient verification results
                //------------------------------------------------------------
            ?>
            <hr class="redLine" />
            <center>
                <div style="font-weight:bold; font-size:120%; margin-top:10px; margin-bottom:10px;">
                    From Coefficients Stored in Calibration Files
                </div>
                <table rules=none style="text-align:center; font-size:140%; frame:box;">
                    <tr>
                        <th>
                            Pressure (PSI)
                        </th>
                        <th>
                            Temperature (&deg;C)
                        </th>
                        <th>
                            Pressure Freq (Hz)
                        </th>
                        <th>
                            Temperature Freq (Hz)
                        </th>
                    </tr>
                    <tr>
                        <td>
                            <?=$fPressureValue ?>
                        </td>
                        <td>
                            <?=$fTemperatureValue ?>
                        </td>
                        <td>
                            <?=$fPressureFrequency ?>
                        </td>
                        <td>
                            <?=$fTemperatureFrequency ?>
                        </td>
                    </tr>
                </table>
                <br />
                <div style="font-weight:bold; font-size:120%; margin-top:10px; margin-bottom:10px;">
                    From Coefficients Stored in the <? if ($digital == 'yes') : ?>Digital Transducer<? else : ?>QCOM Module Memory<? endif; ?>
                </div>
                <table rules=none style="text-align:center; font-size:140%; frame:box">
                    <tr>
                        <th>
                            Pressure (PSI)
                        </th>
                        <th>
                            Temperature (&deg;C)
                        </th>
                        <th>
                            Pressure Freq (Hz)
                        </th>
                        <th>
                            Temperature Freq (Hz)
                        </th>
                    </tr>
                    <tr>
                        <td>
                            <?=$dPressureValue ?>
                        </td>
                        <td>
                            <?=$dTemperatureValue ?>
                        </td>
                        <td>
                            <?=$dPressureFrequency ?>
                        </td>
                        <td>
                            <?=$dTemperatureFrequency ?>
                        </td>
                    </tr>
                </table>
                <? $blankLines -= 9; ?>
            </center>
            <? if (isset($calDir) && ($calDir != 'Unknown')) : ?>
                <? for ($lines = 0; $lines < 3; $lines++) : ?>
                    <br />
                    <? $blankLines--; ?>
                <? endfor; ?>
                Calibration File Path:&nbsp;&nbsp;<?=str_replace('\\\\', '\\', $calDir) ?>
            <? endif; ?>
            <? if ($memoryType != 'N/A') : ?>
                <? if (isset($memoryType) && ($memoryType != 'Unknown')) : ?>
                    <br />
                    <? $blankLines--; ?>
                    <? for ($lines = 0; $lines < 3; $lines++) : ?>
                        <br />
                        <? $blankLines--; ?>
                    <? endfor; ?>
                    Memory Type:&nbsp;&nbsp;<?=$memoryType ?>
                <? endif; ?>
            <? endif; ?>
            <? for ($lines = 0; $lines < $blankLines; $lines++) : ?>
                <br />
            <? endfor; ?>
            Verified by ______________________________________________&nbsp;&nbsp;Date: ___________________<br />
        </div>                          <? // end of MainBody ?>
        <hr class="redLine" />
        <div class="page_bottom" id="MainFooter">
            <i class="flush_left">Copyright &copy; <?=date('Y'); ?> <a href="<?=QD_HomeDir ?>" target="_blank">Quartzdyne, Inc.</a>, a <a href="<?=DoverDir ?>" target="_blank">Dover</a><sup>&reg;</sup> company</i>
            <span class="flush_right" style="font-size:80%;">(Report Version <?=sourceVersion ?> [<script type="text/javascript">document.write(browserFlag);</script>])</span>
        </div>                          <? // end of MainFooter ?>
        <br />
        <script type="text/javascript">display_footer();</script>
    </body>
</html>
<?php
//============================================================================
// QCOM-TC-Check.php Revision History (defined as sourceVersion in this source)
//
//  11 Apr 2011     1.0.0       1.  Initial public release
//
//  29 Apr 2011     1.0.1       1.  Created the mailSite shotrcut
//
//  20 May 2011     1.0.2       1.  Now displays the Report Version flushed-
//                                  right
//
//  23 Jun 2011     1.0.4       1.  Added the display of the memory type, to
//                                  accommodate QCOM software version 1.0.4
//                              2.  Bumped the version to line up with that of
//                                  the QCOM software, since this page is
//                                  displayed and populated by the software
//
//  14 Dec 2011     1.0.5       1.  Added support for Chrome, Safari, and Opera
//                              2.  Now displays the coefficient check results
//                                  for the data residing in the QCOM module
//                                  memory if the attached transducer has no
//                                  memory of its own
//
//  27 Feb 2012     1.0.6       1.  Applied Google Analytics to the page
//
//  27 Nov 2012     1.0.7       1.  Removed Google Analytics
//                              2.  Added a background to the body class
//                              3.  Changed the character set to UTF-8
//                              4.  Removed the no-cache pragma meta
//                              5.  Added the global distribution meta
//
//  07 Mar 2013     1.0.8       1.  Began using qdprogstd.css
//
//  28 May 2014     1.0.9       1.  Began using MainDefs.php
//                              2.  Moved the browser detection scripts to
//                                  PageHeader.js
//
//  04 Aug 2015     1.0.10      1.  Updated for the new qdlamp
//
// End of QCOM-TC-Check.php
//============================================================================
?>
