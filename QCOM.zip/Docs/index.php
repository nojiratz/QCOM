<?php
//============================================================================
// //qdlamp/var/www/trunk/public/QCOM/index.php
//
// Default page for QCOM
//
// Copyright (C) 2011 - 2011 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// A detailed revision history of this file is included at the bottom of this
// source.
//
// Updated 06-24-2011
//============================================================================
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: -1');
    header('Pragma: no-cache');
    header('Location: http://qd.quartzdyne.com/public/QCOM/QCOM-Help.php');
    define('displayVersion', '0.0.1');
    define('sourceVersion', displayVersion . '.2011-06-24');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="eng">
    <head>
        <title>Quartzdyne QCOM</title>
        <meta name="keywords" content="quartzdyne,QCOM,quartz,pressure,temperature,sensor,transducer">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta http-equiv="Pragma" content="no-cache">
        <link href="/image/quartzdyne.ico" rel="shortcut icon" type="image/x-icon" />
    </head>
    <body>
    </body>
</html>
<?php
//============================================================================
// index.php Revision History (defined as sourceVersion in this source)
//
//  24 Jun 2011     0.0.1       1.  Written as the default QCOM page, to
//                                  direct the end user to
//                                  http://qd.quartzdyne.com/public/QCOM/QCOM-Help.php
//
// End of index.php
//============================================================================
?>
