<?php
//============================================================================
// //qdlamp/var/www/trunk/public/QCOM/QCOM-Help.php
//
// General online help for QCOM
//
// Copyright (C) 2011 - 2011 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every precaution has been taken in the
// preparation of this source code, Quartzdyne, Inc., assumes no responsibility
// for errors, omissions, or damages from the use of the source code contained
// herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 03-24-2011
//============================================================================
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: -1');
    header('Pragma: no-cache');
    define('sourceVersion', '0.1.2.2011-03-24');
    define('lastUpdated', '03-24-2011');
    define('QCOM_File', 'QCOM-Setup-0.1.2.exe');
    $emailSubject =
        sprintf(
            "QCOM Help (Version %s)",
            sourceVersion);
    include('/script/server/compresshtml.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="eng">
    <head>
        <title>QCOM</title>
        <meta name="description" content="This page displays the QCOM help.">
        <meta name="keywords" content="quartzdyne,quartz,pressure,temperature,sensor,transducer">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta http-equiv="Pragma" content="no-cache">
        <link rel="shortcut icon" href="/image/quartzdyne.ico" type="image/x-icon" />
        <link rel="stylesheet" href="/style/reset1.css" type="text/css" />
        <link rel="stylesheet" href="/style/table1.css" type="text/css" />
        <style type="text/css">
            div.category
            {
                color: blue;
                font-size: 140%;
                font-weight: bold;
            }
            div.invisible
            {
                display: none;
                margin-top: 10px;
                margin-bottom: 10px;
            }
            div.topic
            {
                color: blue;
                font-size: 100%;
                font-weight: bold;
                margin-top: 10px;
                margin-bottom: 10px;
            }
            div.subtopic
            {
                display: none;
                color: black;
                font-weight: normal;
                margin-top: 10px;
                margin-bottom: 10px;
            }
            @media print
            {
                form
                {
                    display: none;
                }
                table
                {
                    font-size: 140%;
                }
            }
        </style>
        <?  //----------------------------------------------------------------
            // Define javascript functions
            //----------------------------------------------------------------
        ?>
        <script type="text/javascript">
<!--
            //----------------------------------------------------------------
            // Global variables
            //----------------------------------------------------------------
            var browserFlag = 'unknown';
            var ie = (/MSIE (\d+\.\d+);/.test(navigator.userAgent)) ? true : false;
            var ieversion = new Number(RegExp.$1);
            var ff = (/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent)) ? true : false;
            var ffversion = new Number(RegExp.$1);
            //----------------------------------------------------------------
            // Determine the browser type and version
            //----------------------------------------------------------------
            if (ff)
            {
                browserFlag = 'FF ' + ffversion;
            }
            else if (ie)
            {
                browserFlag = 'IE ' + ieversion;
            }
            //----------------------------------------------------------------
            // expand_collapse
            //
            // Expands or collapses a document section
            //----------------------------------------------------------------
            function expand_collapse(id)
            {
                var section;
                if (document.getElementById)
                {
                    section = document.getElementById(id);
                    if (section)
                    {
                        if (section.style.display == 'block')
                            section.style.display = 'none';
                        else
                            section.style.display = 'block';
                    }
                }
                else
                {
                    if (document.layers)
                    {
                        if (document.id.display == 'block')
                            document.id.display = 'none';
                        else
                            document.id.display = 'block';
                    }
                    else
                    {
                        if (document.all.id.style.visibility == 'block')
                            document.all.id.style.display = 'none';
                        else
                            document.all.id.style.display = 'block';
                    }
                }
            }                           // end of expand_collapse()
            //----------------------------------------------------------------
            // expand_collapse_all
            //
            // Expands or collapses all 'div' sections whose name is 'QD'
            //
            // Note:  There is a known bug in IE 8, in which getElementsByName
            //      will not work correctly when the specified name is
            //      implemented in any of several tags, of which the <div> tag
            //      is one
            //----------------------------------------------------------------
            function expand_collapse_all()
            {
                var displaying = document.getElementById('qd_div').style.display;
                var expand_collapse = (displaying == 'block') ? 'Expand' : 'Collapse';
                var ie = (/MSIE (\d+\.\d+);/.test(navigator.userAgent)) ? true : false;
                var divel;
                if (ie)
                    divel = document.getElementsByTagName('div');
                else
                    divel = document.getElementsByName('QD');
                for (var el = 0; el < divel.length; el++)
                {
                    //--------------------------------------------------------
                    // Only expand those div tags whose name is 'QD',
                    // including 'qd_div'
                    //--------------------------------------------------------
                    if (!ie || (divel[el].name == 'QD'))
                    {
                        //----------------------------------------------------
                        // If tag 'qd_div' shows 'block' then collapse them all
                        //----------------------------------------------------
                        if (displaying == 'block')
                            divel[el].style.display = 'none';
                        else
                            divel[el].style.display = 'block';
                    }
                }                       // end of for (var el = 0; ...)
                document.getElementById('ExpandAll').innerHTML =
                    '<img src="/image/red_dot.gif" /> ' + expand_collapse +
                    ' the entire help text';
            }                           // end of expand_collapse_all()
            //----------------------------------------------------------------
            // display_footer
            //
            // Displays a footer
            //----------------------------------------------------------------
            function display_footer()
            {
                document.write(
                    '<div style="font-size:72%; color:black; font-weight:normal; margin-top:10px; margin-bottom:10px;">' +
                    'Please communicate problems and suggestions to <a href="http://qd.quartzdyne.com/public/' +
                    'Mail-Handler.php?emailSubject=<?=$emailSubject ?>&dest=support">Quartzdyne Support</a>' +
                    '<br /><br /><a href="#help_top">Return to the top of the help document</a></div>');
            }                           // end of display_footer()
//-->
        </script>
    </head>
    <body
        style="font-family:Verdana,sans-serif; margin-left:16px; margin-top:8px; font-size:100%;"
        background="/image/white_sand.jpg"
        onselectstart="event.returnValue=false;">
        <div id="qd_div" name="QD"></div>
        <?  //----------------------------------------------------------------
            // Display the company logo and prompt the user to print the page
            //----------------------------------------------------------------
        ?>
        <div style="margin:auto; text-align:center; width:1000px;" id="DisplayHeader">
            <a href="http://www.quartzdyne.com" target="_blank" name="help_top">
                <img src="/image/quartzdyne_logo.png" style="float:left;" alt="Quartzdyne" />
            </a>
            <div style="margin-left:20px; margin-bottom:10px; text-align:center; float:left;">
                <div style="color:black; font-weight:bold; font-size:200%;">
                    <span style="color:red; font-style:italic; font-weight:extra-bold; font-family:Arial,sans;"><acronym title="Quartzdyne Communication Module">QCOM</acronym></span> Help Center
                </div>
                <p style="font-size:120%; margin-top:5px;"><?=date('D d M Y h:i:s a'); ?></p>
                <p style="margin-top:10px;">
                    <form>
                        <input
                            type="button"
                            onClick="window.print()"
                            value=" Print This Help Page "
                            style="color:blue;" />
                    </form>
                </p>
            </div>
        </div>
        <div style="clear:both;" id="MainBody">
            <?  //------------------------------------------------------------
                // Display the header of the help text
                //------------------------------------------------------------
            ?>
            <div style="margin-top:5px; margin-bottom:10px;">
                <a href="<?=QCOM_File ?>">Download</a> and install the latest (<?=lastUpdated ?>)
                <a href="<?=QCOM_File ?>"><img src="/image/QCOM.png" style="height:40px; width:60px; vertical-align:middle" alt="QCOM" /></a> software
                <br />
                <div style="color:blue; margin-bottom:10px;" id="ExpandAll"
                    onclick="expand_collapse_all()"
                    ondblclick="expand_collapse_all()"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/red_dot.gif" /> Expand the entire help text
                </div>
                Please communicate problems and suggestions to <a href="http://qd.quartzdyne.com/public/Mail-Handler.php?emailSubject=<?=$emailSubject ?>&dest=support">Quartzdyne Support</a>
            </div>
            <?  //------------------------------------------------------------
                // Display the actual help text
                //------------------------------------------------------------
            ?>
            <hr style="height:2px; border:1px solid; color:#C00; background-color:#C00; margin-top:10px;" />
            <div style="margin-top:10px" id="HelpSection">
                <div style="font-size:180%; color:blue; font-weight:bold;">QCOM Help</div>
                <div class="category" id="Overview"
                    onclick="expand_collapse('Overview_Topics')"
                    ondblclick="expand_collapse('Overview_Topics')"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/SpinStar.gif" style="height:25px; width:25px; vertical-align:middle" /> Overview
                </div>
                <div class="invisible" id="Overview_Topics" name="QD">
                    <div class="topic"
                        onclick="expand_collapse('Overview_Topic_1')"
                        ondblclick="expand_collapse('Overview_Topic_1')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        What Is QCOM?
                        <div class="subtopic" id="Overview_Topic_1" name="QD">
                            QCOM, or the Quartzdyne&copy; Transducer Communication module is a piece of hardware
                            designed to allow client monitoring and control of Quartzdyne analog and digital
                            quartz downhole pressure and temperature transducers.
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Overview_Topic_2')"
                        ondblclick="expand_collapse('Overview_Topic_2')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Overview Topic 2
                        <div class="subtopic" id="Overview_Topic_2" name="QD">
                            Text that appears in Overview Topic 2
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Overview_Topic_3')"
                        ondblclick="expand_collapse('Overview_Topic_3')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Overview Topic 3
                        <div class="subtopic" id="Overview_Topic_3" name="QD">
                            Text that appears in Overview Topic 3
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Overview_Topic_4')"
                        ondblclick="expand_collapse('Overview_Topic_4')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Overview Topic 4
                        <div class="subtopic" id="Overview_Topic_4" name="QD">
                            Text that appears in Overview Topic 4
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                </div>                  <? // end of Overview_Topics ?>
                <div class="category" id="Hardware_Requirements"
                    onclick="expand_collapse('Hardware_Topics')"
                    ondblclick="expand_collapse('Hardware_Topics')"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/SpinStar.gif" style="height:25px; width:25px; vertical-align:middle" /> Hardware Requirements
                </div>
                <div class="invisible" id="Hardware_Topics" name="QD">
                    <div class="topic"
                        onclick="expand_collapse('Hardware_1')"
                        ondblclick="expand_collapse('Hardware_1')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Hardware Requirements 1
                        <div class="subtopic" id="Hardware_1" name="QD">
                            Text that appears in Hardware Requirements 1
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Hardware_2')"
                        ondblclick="expand_collapse('Hardware_2')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Hardware Requirements 2
                        <div class="subtopic" id="Hardware_2" name="QD">
                            Text that appears in Hardware Requirements 2
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Hardware_3')"
                        ondblclick="expand_collapse('Hardware_3')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Hardware Requirements 3
                        <div class="subtopic" id="Hardware_3" name="QD">
                            Text that appears in Hardware Requirements 3
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Hardware_4')"
                        ondblclick="expand_collapse('Hardware_4')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Hardware Requirements 4
                        <div class="subtopic" id="Hardware_4" name="QD">
                            Text that appears in Hardware Requirements 4
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                </div>                  <? // end of Hardware_Topics ?>
                <div class="category" id="Software_Requirements"
                    onclick="expand_collapse('Software_Topics')"
                    ondblclick="expand_collapse('Software_Topics')"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/SpinStar.gif" style="height:25px; width:25px; vertical-align:middle" /> Software Requirements
                </div>
                <div class="invisible" id="Software_Topics" name="QD">
                    <div class="topic"
                        onclick="expand_collapse('Software_1')"
                        ondblclick="expand_collapse('Software_1')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Software Requirements 1
                        <div class="subtopic" id="Software_1" name="QD">
                            Text that appears in Software Requirements 1
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_2')"
                        ondblclick="expand_collapse('Software_2')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Software Requirements 2
                        <div class="subtopic" id="Software_2" name="QD">
                            Text that appears in Software Requirements 2
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_3')"
                        ondblclick="expand_collapse('Software_3')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Software Requirements 3
                        <div class="subtopic" id="Software_3" name="QD">
                            Text that appears in Software Requirements 3
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_4')"
                        ondblclick="expand_collapse('Software_4')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Software Requirements 4
                        <div class="subtopic" id="Software_4" name="QD">
                            Text that appears in Software Requirements 4
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                </div>                  <? // end of Software_Topics ?>
                <div class="category" id="Installation"
                    onclick="expand_collapse('Installation_Topics')"
                    ondblclick="expand_collapse('Installation_Topics')"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/SpinStar.gif" style="height:25px; width:25px; vertical-align:middle" /> Building and Installation
                </div>
                <div class="invisible" id="Installation_Topics" name="QD">
                    <div class="topic"
                        onclick="expand_collapse('Installation_1')"
                        ondblclick="expand_collapse('Installation_1')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Software Download and Installation
                        <div class="subtopic" id="Installation_1" name="QD">
                            Browse to the <a href="http://qd.quartzdyne.com/public/QCOM/QCOM-Help.php">QCOM Help</a> page or
                            download the software directly from the <a href="<?=QCOM_File ?>">QCOM Download</a> site.  Click Run
                            to start the installation.
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Installation_2')"
                        ondblclick="expand_collapse('Installation_2')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Install the QCOM Driver
                        <div class="subtopic" id="Installation_2" name="QD">
                            <ol>
                                <li>If the Hardware Update Wizard prompts you to search for current
                                and updated software, jump to step 4; otherwise, continue.</li>
                                <li>Invoke the Device Manager, which you can access from the Control Panel.</li>
                                <li>Under either Universal Serial Bus controllers or Other devices right-click on
                                <code>QCOM</code>
                                and click <code>Update Driver...</code></li>
                                <li>Click <code>No, not this time</code>, then <code>Next</code>.</li>
                                <li>Click <code>Install from a list</code>, then <code>Next</code>.</li>
                                <li>Click <code>Don't search</code>, then <code>Next</code>.</li>
                                <li>If the Hardware Type window appears, select Universal Serial Bus controllers
                                and click <code>Next</code></li>
                                <li>Click <code>Have Disk...</code></li>
                                <li>Click <code>Browse...</code></li>
                                <li>Navigate to the <code>C:\Program Files\Quartzdyne\QCOM\Driver</code> folder</li>
                                <li>Click <code>QCOM.inf</code>, then <code>Open</code>, then <code>OK</code>.</li>
                                <li>If the Hardware Update Wizard complains that the driver is not digitally signed,
                                ignore these warnings, then click <code>Next</code>.</li>
                                <li>Click <code>Continue Anyway</code>.</li>
                                <li>When Hardware Update has completed, click <code>Finish</code>.</li>
                                <li>Install one or more Quartzdyne transducers, QCOM modules, and associated cabling
                                on your computer. If you do not have this hardware available, you can proceed when you
                                install them; otherwise, continue.</li>
                                <li>Invoke the QCOM software.</li>
                                <li>Select the <code>Utilities</code> tab</li>
                                <li>Click the <code>Update Driver</code> button if it is visible; if the
                                button is not visible, this action has probably already been performed, and
                                the driver installation is complete for this particular module.</li>
                                <li>Follow steps 4 through 14 to re-install the driver, then jump to step 20.</li>
                                <li>In the QCOM software click <code>OK</code> in the small <code>Update Driver</code>
                                popup window.</li>
                                <li>If one or more windows pop up indicating that a handle is invalid, click
                                <code>OK</code> on all of them.</li>
                                <li>Exit the QCOM software.</li>
                                <li>The QCOM software is now ready to be re-invoked for normal use.</li>
                            </ol>
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Installation_3')"
                        ondblclick="expand_collapse('Installation_3')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Installation 3
                        <div class="subtopic" id="Installation_3" name="QD">
                            Text that appears in Installation 3
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Installation_4')"
                        ondblclick="expand_collapse('Installation_4')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Installation 4
                        <div class="subtopic" id="Installation_4" name="QD">
                            Text that appears in Installation 4
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                </div>                  <? // end of Installation_Topics ?>
                <div class="category" id="Software_Operations"
                    onclick="expand_collapse('Software_Ops')"
                    ondblclick="expand_collapse('Software_Ops')"
                    onmouseover="this.style.color = 'green';"
                    onmouseout="this.style.color = 'blue';">
                    <img src="/image/SpinStar.gif" style="height:25px; width:25px; vertical-align:middle" /> Software Operations
                </div>
                <div class="invisible" id="Software_Ops" name="QD">
                    <div class="topic"
                        onclick="expand_collapse('Software_Ops_1')"
                        ondblclick="expand_collapse('Software_Ops_1')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Software Operations 1
                        <div class="subtopic" id="Software_Ops_1" name="QD">
                            Text that appears in Software Operations 1
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_Ops_2')"
                        ondblclick="expand_collapse('Software_Ops_2')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Software Operations 2
                        <div class="subtopic" id="Software_Ops_2" name="QD">
                            Text that appears in Software Operations 2
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_Ops_3')"
                        ondblclick="expand_collapse('Software_Ops_3')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Software Operations 3
                        <div class="subtopic" id="Software_Ops_3" name="QD">
                            Text that appears in Software Operations 3
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                    <div class="topic"
                        onclick="expand_collapse('Software_Ops_4')"
                        ondblclick="expand_collapse('Software_Ops_4')"
                        onmouseover="this.style.color = 'brown';"
                        onmouseout="this.style.color = 'blue';">
                        Software Operations 4
                        <div class="subtopic" id="Software_Ops_4" name="QD">
                            Text that appears in Software Operations 4
                            <script type="text/javascript">display_footer();</script>
                        </div>
                    </div>
                </div>                  <? // end of Software_Opts ?>
            </div>                      <? // end of HelpSection ?>
            <hr style="height:2px; border:1px solid; color:#C00; background-color:#C00; margin-top:10px;" />
            <div style="font-size:70%; margin-top:5px;">
                (Document Version <?=sourceVersion ?> [<script type="text/javascript">document.write(browserFlag);</script>])<br /><br />
                <i>Copyright &copy; 2011 Quartzdyne, Inc., a Dover<sup>&reg;</sup> company</i>
            </div>
        </div>                          <? // end of MainBody ?>
    </body>
</html>
<?php
//============================================================================
// End of QCOM-Help.php
//============================================================================
?>
