//============================================================================
// Coefficient.cpp
//
// Routines that manage coefficient data handling
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     COEFFICIENT_CPP
#define     COEFFICIENT_CPP
#include    "Coefficient.h"
//----------------------------------------------------------------------------
// QCOM_ApplyCoefficientDataInfoToProgram
//
// Updates various program entities and displays with the information based on
// the coefficient data currently stored in unit->coefficientData
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ApplyCoefficientDataInfoToProgram(
    UnitInfo        ^unit)
{
    DWORD           status;
    String          ^functionName = _T("QCOM_ApplyCoefficientDataInfoToProgram");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    if (QCOM_UnitValid(unit))
    {
        QCOM_InterpretCoefficientData(unit);
        QCOM_ConstructUnitDescriptionString(unit);
        unit->flags &=
            ~(QCOM_UNIT_INITIAL_READINGS |
            QCOM_UNIT_CAN_COMMUNICATE |
            QCOM_UNIT_OK_TO_SAMPLE);
        if (QCOM_XDPresent(unit))
        {
            status = QCOM_RetrieveTransducerReadings(unit);
            if (status == QCOM_SUCCESS)
            {
                unit->flags |=
                    (QCOM_UNIT_INITIAL_READINGS |
                    QCOM_UNIT_CAN_COMMUNICATE |
                    QCOM_UNIT_OK_TO_SAMPLE);
                QCOM_GeneralInfo->logFlags |=
                    QCOM_GENERAL_LOG_LOGGING_AVAILABLE;
                QCOM_GeneralInfo->testFlags |=
                    QCOM_GENERAL_TEST_TESTING_AVAILABLE;
            }
            else
            {
                if (status != QCOM_ERROR_UNIT_NOT_READY)
                {
                    QCOM_RecordAndModalErrorEvent(
                        "{0} :\nError 0x{1:X8} retrieving initial counts",
                        functionName, status);
                }
            }
        }
        if (!QCOM_UnitReady(unit))
            unit->flags &= ~QCOM_UNIT_INCLUDE_IN_SAMPLING;
    }
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ApplyCoefficientDataInfoToProgram()
//----------------------------------------------------------------------------
// QCOM_CheckAllTransducerCoefficientData
//
// Checks all attached modules for transducer coefficient data that could be
// interpreted
//
// Called by:   QCOM_ReDrawWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_CheckAllTransducerCoefficientData(void)
{
    String          ^functionName = _T("QCOM_CheckAllTransducerCoefficientData");
    //------------------------------------------------------------------------
    for each (UnitInfo ^unit in QCOM_UnitInfoArray)
    {
        if (unit->unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS)
        {
            QCOM_CheckForTransducerCoefficientData(unit);
        }
    }
}                                       // end of QCOM_CheckAllTransducerCoefficientData()
//----------------------------------------------------------------------------
// QCOM_CheckForTransducerCoefficientData
//
// Prompts the user if the specified unit is attached to a transducer that has
// no coefficient data memory, to ensure the loaded coefficient data is the
// correct one for the device
//
// Called by:   QCOM_AffirmStartupConditions
//              QCOM_CheckAllTransducerCoefficientData
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_CheckForTransducerCoefficientData(
    UnitInfo        ^unit)
{
    bool            browseForFiles = GUI_NO;
    bool            fileLocated = GUI_NO;
    bool            inputResponse = GUI_ACCEPT;
    bool            inputValid = GUI_NO;
    bool            proceedToImport = GUI_NO;
    bool            promptForNewData = GUI_NO;
    bool            serialNumberIsCorrect = GUI_YES;
    DWORD           status;
    DWORD           transducerSerialNumber = 0;
    String          ^filePathString;
    String          ^promptString;
    String          ^titleString;
    String          ^transducerSearchString;
    String          ^transducerSerialString;
    String          ^functionName = _T("QCOM_CheckForTransducerCoefficientData");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (QCOM_XDPresent(unit))
        {
            if (QCOM_XDSNValid(unit))
            {
                transducerSerialString = unit->transducerSerialNumber;
                RecordVerboseEvent("    Checking coefficient data for transducer {0}",
                    transducerSerialString);
            }
            else
            {
                transducerSerialString = _T("(Unknown)");
                RecordVerboseEvent("    Attempting to resolve invalid coefficient data for transducer on unit {0:D}",
                    unit->unitNumber);
            }
            if (QCOM_XDIsFrequency(unit) || QCOM_XDIsDigitalNoMem(unit))
            {
                //------------------------------------------------------------
                // A frequency transducer (or a digital transducer with no
                // memory) has been detected at this unit, so prompt for
                // confirmation that the coefficient data currently loaded is
                // targeted for the actual transducer
                //------------------------------------------------------------
                if (QCOM_XDSNValid(unit))
                {
                    bool mustVerifyCoefficientData = GUI_YES;
                    //--------------------------------------------------------
                    // Determine whether this pair was verified previously by
                    // checking the current settings of all other pairs
                    //--------------------------------------------------------
                    ModuleTransducerPair ^unitPair = QCOM_ModuleTransducerPairArray[unit->unitNumber];
                    if (unitPair)
                    {
                        String ^newPair = String::Concat(
                            unitPair->newModuleSerialNumber, unitPair->newTransducerSerialNumber);
                        for (DWORD moduleNumber = 0; moduleNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; moduleNumber++)
                        {
                            ModuleTransducerPair ^modulePair = QCOM_ModuleTransducerPairArray[moduleNumber];
                            if (modulePair && StringICompare(newPair, modulePair->currentUnitPair) == 0)
                            {
                                //--------------------------------------------
                                // The current pair was previously verified,
                                // so no need to verify the pair again
                                //--------------------------------------------
                                mustVerifyCoefficientData = GUI_NO;
                                break;
                            }
                        }
                    }
                    if (mustVerifyCoefficientData)
                    {
                        QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
                        titleString = String::Concat(
                            (QCOM_XDIsDigitalNoMem(unit) ? "Digital (No Memory)" : "Frequency (Analog)"),
                            " Transducer Present");
                        promptString = String::Format(
                            "Module {0} contains coefficients for transducer {1}\n"
                            "Is transducer {1} currently attached to QCOM module {0} ?",
                            unit->moduleSerialNumber,
                            transducerSerialString);
                        serialNumberIsCorrect = QCOM_PromptModal(
                            titleString,
                            promptString);
                        if (!serialNumberIsCorrect)
                        {
                            promptString = String::Format(
                                "Enter the serial number for the transducer attached to\n"
                                "module {0}, or leave it blank to browse for a file.",
                                unit->moduleSerialNumber);
                            promptForNewData = GUI_YES;
                        }
                    }                   // end of if (mustVerifyCoefficientData)
                }                       // end of if (QCOM_XDSNValid(unit))
                else
                {
                    promptString = String::Format(
                        "The QCOM software is unable to determine the serial number\n"
                        "of the transducer attached to module {0}.  Enter the serial\n"
                        "number for this transducer, or leave the entry field blank to\n"
                        "have the software prompt you for a coefficient data file.",
                        unit->moduleSerialNumber);
                    promptForNewData = GUI_YES;
                }
                //------------------------------------------------------------
                // Retrieve a new set of transducer coefficients by first
                // prompting for a new transducer serial number
                //------------------------------------------------------------
                do
                {
                    inputValid = GUI_YES;
                    if (promptForNewData)
                    {
                        titleString = String::Concat(
                            (QCOM_XDIsDigitalNoMem(unit) ?
                                "Digital (No Memory)" : "Frequency (Analog)"),
                            " Transducer Coefficients");
                        StringBuilder ^transducerSearchBuilder = gcnew StringBuilder(
                            transducerSearchString,
                            QCOM_MAXIMUM_SEARCH_STRING_SIZE);
                        inputResponse = QCOM_PromptInputModal(
                            titleString,
                            transducerSerialString,
                            &transducerSerialNumber,
                            transducerSearchBuilder,
                            QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH,
                            promptString);
                        transducerSearchString = transducerSearchBuilder->ToString();
                        delete transducerSearchBuilder;
                        if (inputResponse == GUI_ACCEPT)
                        {
                            if (StringSet(transducerSearchString) && transducerSerialNumber)
                            {
                                if (transducerSerialNumber < 10000)
                                    inputValid = GUI_NO;
                                if (transducerSearchString->Length < (QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH - 1))
                                    inputValid = GUI_NO;
                                if (inputValid)
                                {
                                    QCOM_GeneralInfo->searchString = transducerSearchString;
                                }
                                else
                                {
                                    RecordErrorEvent(
                                        "    '{0}' is not a valid transducer serial number",
                                        transducerSearchString);
                                }
                            }
                            else
                            {
                                browseForFiles = GUI_YES;
                            }
                        }               // end of if (inputResponse == GUI_ACCEPT)
                        else
                        {
                            promptForNewData = GUI_NO;
                        }
                    }                   // end of if (promptForNewData)
                }
                while ((inputResponse == GUI_ACCEPT) && !inputValid);
                if ((inputResponse == GUI_ACCEPT) && inputValid && (promptForNewData == GUI_YES))
                {
                    if (!browseForFiles)
                    {
                        while (transducerSearchString->Length < QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH)
                        {
                            transducerSearchString = String::Concat(
                                "0", transducerSearchString);
                        }
                        //----------------------------------------------------
                        // Begin searching for the coefficient files,
                        // identified by SerialNumber.hex or SerialNumber.crf
                        //----------------------------------------------------
                        QCOM_PleaseWait(
                            GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
                            "Searching for Transducer {0} Coefficient File",
                            transducerSearchString);
                        StringBuilder ^filePathBuilder = gcnew
                            StringBuilder(QCOM_MAXIMUM_FILE_PATH_LENGTH);
                        fileLocated = QCOM_SearchForCoefficientFile(
                            transducerSearchString,
                            filePathBuilder);
                        filePathString = filePathBuilder->ToString();
                        delete filePathBuilder;
                        QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
                        Thread::Sleep(100);
                        if (fileLocated)
                        {
                            proceedToImport = QCOM_ImportCoefficientDataFromFile(
                                unit,
                                filePathString);
                        }
                        else
                        {
                            browseForFiles = GUI_YES;
                        }
                    }                   // end of if (!browseForFiles)
                    if (browseForFiles)
                    {
                        QCOM_PromptForImportCoefficientDataFromFile(unit);
                    }
                    //--------------------------------------------------------
                    // The coefficients have been uploaded to memory, so
                    // prompt to ensure the user wants them installed in the
                    // module memory
                    //--------------------------------------------------------
                    if (proceedToImport)
                    {
                        promptString = String::Format(
                            "Proceed to replace the coefficient data of transducer {0}\n"
                            "on module {1} with that of transducer {2} ?",
                            transducerSerialString,
                            unit->moduleSerialNumber,
                            transducerSearchString);
                        proceedToImport = QCOM_PromptModal(
                            "Update Transducer Coefficients",
                            promptString);
                        if (proceedToImport)
                        {
                            unit->flags &= ~QCOM_UNIT_COEFFICIENTS_VERIFIED;
                            status = QD_WriteCoefficientDataToDevice(
                                unit->unitHandle,
                                (LPBYTE) unit->coefficientData);
                            if (status == QD_SUCCESS)
                            {
                                unit->flags |= QCOM_UNIT_COEFFICIENTS_VERIFIED;
                                if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
                                {
                                    titleString = String::Concat(
                                        (QCOM_XDIsDigitalNoMem(unit) ?
                                            "Digital (No Memory)" : "Frequency (Analog)"),
                                        " Transducer Coefficients");
                                    QCOM_PromptOKModal(
                                        titleString,
                                        "Coefficient data successfully updated for\n"
                                        "transducer {0}",
                                        transducerSearchString);
                                }
                                RecordBasicEvent("    Coefficient data successfully updated for transducer {0}",
                                    transducerSearchString);
                                QCOM_ApplyCoefficientDataInfoToProgram(unit);
                            }
                            else
                            {
                                RecordErrorEvent("    QD_WriteCoefficientDataToDevice returned 0x{0:X8}",
                                    status);
                            }
                        }
                        else
                        {
                            status = QD_ReadCoefficientDataFromDevice(
                                unit->unitHandle,
                                (LPBYTE) unit->coefficientData);
                            if (status == QD_SUCCESS)
                            {
                                QCOM_ApplyCoefficientDataInfoToProgram(unit);
                                RecordBasicEvent("    Coefficient data for {0} verified and applied",
                                    unit->transducerSerialNumber);
                            }
                            else
                            {
                                RecordErrorEvent("    QD_ReadCoefficientDataFromDevice returned 0x{0:X8}",
                                    status);
                            }
                        }
                    }                   // end of if (proceedToImport)
                }                       // end of if ((inputResponse == GUI_ACCEPT) && ...)
            }                           // end of if (QCOM_XDIsFrequency(unit) || QCOM_XDIsDigitalNoMem(unit))
        }                               // end of if (QCOM_XDPresent(unit))
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit) && (unit->unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS))
}                                       // end of QCOM_CheckForTransducerCoefficientData()
//----------------------------------------------------------------------------
// QCOM_ConvertNativeCoefficientFileSet
//
// Converts an Native File set
//
// Called by:   QCOM_UtilConvertNativeCoefficientFileSetButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConvertNativeCoefficientFileSet(void)
{
    bool            browseForFiles = GUI_NO;
    bool            dbFileFound = GUI_NO;
    bool            fileLocated = GUI_NO;
    bool            inputResponse = GUI_ACCEPT;
    bool            inputValid = GUI_NO;
    bool            proceedToConvert = GUI_YES;
    bool            proceedToDisplayCoefficientData = GUI_NO;
    bool            proceedToSaveFile = GUI_NO;
    bool            proceedToSearchDB = GUI_NO;
    char            *hexFilePath;
    DWORD           status = QCOM_SUCCESS;
    DWORD           transducerSerialNumber = 0;
    CoefficientFormatDef
                    *coefficientData;
    UnitInfo        ^unit;
    StringBuilder   ^nativeFilePathBuilder;
    StringBuilder   ^hexFilePathBuilder;
    String          ^nativeFilePathString;
    String          ^dbPathString = QUARTZDYNE_CONFIDENTIAL_ROOT QUARTZDYNE_CALSUM_DB_FILE_PATH;
    String          ^promptString;
    String          ^transducerSearchString;
    String          ^functionName = _T("QCOM_ConvertNativeCoefficientFileSet");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    coefficientData = (CoefficientFormatDef *) malloc(sizeof(CoefficientFormatDef));
    if (coefficientData)
    {
        nativeFilePathBuilder =
            gcnew StringBuilder(QCOM_MAXIMUM_FILE_PATH_LENGTH);
        hexFilePathBuilder =
            gcnew StringBuilder(QCOM_MAXIMUM_FILE_PATH_LENGTH);
        do
        {
            inputValid = GUI_YES;
            if (proceedToConvert)
            {
                StringBuilder ^transducerSearchBuilder =
                    gcnew StringBuilder(QCOM_MAXIMUM_SEARCH_STRING_SIZE);
                inputResponse = QCOM_PromptInputModal(
                    "Transducer Serial Number",
                    QCOM_GeneralInfo->searchString,
                    &transducerSerialNumber,
                    transducerSearchBuilder,
                    QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH,
                    "Enter the transducer serial number of the files to be converted.\n"
                    "Leave it blank to browse for a coefficient file set.");
                transducerSearchString = transducerSearchBuilder->ToString();
                delete transducerSearchBuilder;
                if (inputResponse == GUI_ACCEPT)
                {
                    if (StringSet(transducerSearchString) && transducerSerialNumber)
                    {
                        if (transducerSerialNumber < 10000)
                            inputValid = GUI_NO;
                        if (transducerSearchString->Length < (QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH - 1))
                            inputValid = GUI_NO;
                        if (inputValid)
                        {
                            nativeFilePathString = String::Concat(
                                transducerSearchString, ".crf");
                            GUI_StringToBuilder(
                                nativeFilePathString,
                                nativeFilePathBuilder);
                            QCOM_GeneralInfo->searchString = transducerSearchString;
                            proceedToConvert = GUI_YES;
                        }
                        else
                        {
                            GUI_DisplayMandatoryError(
                                functionName,
                                "'{0}' is not a valid transducer serial number",
                                transducerSearchString);
                        }
                    }
                    else
                    {
                        browseForFiles = GUI_YES;
                    }
                }
                else
                {
                    proceedToConvert = GUI_NO;
                }
            }
        }
        while ((inputResponse == GUI_ACCEPT) && !inputValid);
        if ((inputResponse == GUI_ACCEPT) && inputValid && (proceedToConvert == GUI_YES))
        {
            if (!browseForFiles)
            {
                while (transducerSearchString->Length < QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH)
                {
                    transducerSearchString = String::Concat("0", transducerSearchString);
                }
                //------------------------------------------------------------
                // Search the network, if present, for the CALSUM database file
                //------------------------------------------------------------
                if (File::Exists(dbPathString))
                {
                    dbFileFound = GUI_YES;
                }
                else
                {
                    array <DriveInfo ^> ^driveInfo = DriveInfo::GetDrives();
                    for each (DriveInfo ^oneDrive in driveInfo)
                    {
                        if (oneDrive->DriveType == DriveType::Network)
                        {
                            dbPathString = String::Concat(
                                oneDrive->Name, QUARTZDYNE_CALSUM_DB_FILE_PATH);
                            if (File::Exists(dbPathString))
                            {
                                dbFileFound = GUI_YES;
                            }
                        }
                    }
                }
                if (dbFileFound)
                {
                    proceedToSearchDB = QCOM_PromptYesNoModal(
                        "Search the Database",
                        "Search", "Browse...",
                        "Search the database, or browse for the\n"
                        "coefficient files of transducer {0} ?",
                        transducerSearchString);
                    if (proceedToSearchDB)
                    {
                        QCOM_PleaseWait(
                            GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
                            "Searching for Transducer {0} Coefficient File",
                            transducerSearchString);
                        fileLocated = QCOM_SearchForCoefficientFile(
                            transducerSearchString,
                            nativeFilePathBuilder);
                        nativeFilePathString = nativeFilePathBuilder->ToString();
                        GUI_StringToBuilder(
                            nativeFilePathString,
                            hexFilePathBuilder);
                        hexFilePathBuilder->Replace(
                            Path::GetExtension(nativeFilePathString),
                            ".hex");
                        QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
                        Thread::Sleep(100);
                    }
                    else
                    {
                        browseForFiles = GUI_YES;
                    }
                }
                else
                {
                    browseForFiles = GUI_YES;
                }
            }
            if (browseForFiles)
            {
                fileLocated = QCOM_PromptForReadFile(
                    "Select Coefficient File",
                    nativeFilePathBuilder,
                    nativeFilePathString,
                    GUI_FILE_TYPE_NATIVE_REF);
                nativeFilePathString =
                    nativeFilePathBuilder->ToString();
                if (!StringSet(transducerSearchString))
                {
                    transducerSearchString =
                        Path::GetFileName(nativeFilePathString);
                    if (StringSet(transducerSearchString))
                    {
                        QCOM_GeneralInfo->searchString = transducerSearchString;
                    }
                }
            }
            if (fileLocated)
            {
                nativeFilePathString = nativeFilePathString->Replace(
                    Path::GetExtension(nativeFilePathString),
                    ".crf");
                if (!File::Exists(nativeFilePathString))
                {
                    QCOM_PromptOKModal(
                        "Coefficient File Not Found",
                        "The file\n{0}\ncould not be found\n"
                        "Press OK to exit",
                        nativeFilePathString);
                    proceedToConvert = GUI_NO;
                }
                if (proceedToConvert)
                {
                    ClearBuffer(coefficientData, sizeof(CoefficientFormatDef));
                    status = QCOM_ReadCoefficientDataFromFile(
                        nativeFilePathString,
                        coefficientData);
                    if (status == QCOM_SUCCESS)
                    {
                        promptString = String::Format(
                            "Coefficient data file found at\n{0}\n\n"
                            "Display the converted coefficient data\n"
                            "for transducer {1} ?",
                            nativeFilePathString,
                            transducerSearchString);
                        proceedToDisplayCoefficientData = QCOM_PromptModal(
                            "Conversion Successful",
                            promptString);
                        if (proceedToDisplayCoefficientData)
                        {
                            unit = QCOM_UnitInfoArray[QCOM_MAXIMUM_NUMBER_OF_UNITS];
                            if (unit)
                            {
//                                unit->flags |= QCOM_UNIT_VALID;
                                memcpy(
                                    unit->coefficientData,
                                    coefficientData,
                                    sizeof(CoefficientFormatDef));
                                String ^unitSNString = String::Concat(
                                    "Transducer ", transducerSearchString);
                                unit->moduleSerialNumber = unitSNString;
                                delete unitSNString;
                                QCOM_InterpretCoefficientData(unit);
                                QCOM_ConstructUnitDescriptionString(unit);
                                QCOM_DisplayLoadedCoefficientData(unit);
                            }
                        }
                        String ^hexFilePathString =
                            hexFilePathBuilder->ToString();
                        if (!hexFilePathString->ToLower()->EndsWith(".hex"))
                        {
                            hexFilePathString =
                                nativeFilePathString->Replace(
                                    Path::GetExtension(nativeFilePathString),
                                    ".hex");
                            GUI_StringToBuilder(
                                hexFilePathString,
                                hexFilePathBuilder);
                        }
                        proceedToSaveFile = QCOM_PromptForSaveFile(
                            "Save Coefficient Hex File",
                            hexFilePathBuilder,
                            hexFilePathString,
                            GUI_FILE_TYPE_HEX);
                        hexFilePathString = hexFilePathBuilder->ToString();
                        if (proceedToSaveFile)
                        {
                            hexFilePath = (char *)
                                malloc(QCOM_MAXIMUM_FILE_PATH_LENGTH);
                            if (hexFilePath)
                            {
                                QCOM_ConvertString(
                                    hexFilePathString,
                                    hexFilePath,
                                    QCOM_MAXIMUM_FILE_PATH_LENGTH);
                                QD_WriteCoefficientDataToHexFile(
                                    (LPBYTE) coefficientData,
                                    (LPBYTE) hexFilePath);
                                free((void *) hexFilePath);
                            }
                        }
                        delete hexFilePathString;
                    }
                    else
                    {
                        GUI_DisplayMandatoryError(functionName,
                            "Error 0x{0:X8} while analyzing file\n{1}\n"
                            "Press OK to exit",
                            status,
                            nativeFilePathString);
                    }
                }
            }
        }
        delete hexFilePathBuilder;
        delete nativeFilePathBuilder;
        free((void *) coefficientData);
    }
    else
    {
        QCOM_PromptOKModal(
            "Out Of Memory",
            "Not enough memory to attempt a\n"
            "coefficient file conversion");
    }
    RecordBasicEvent("{0} concluded with status = 0x{1:X8}", functionName, status);
}                                       // end of QCOM_ConvertNativeCoefficientFileSet()
//----------------------------------------------------------------------------
// QCOM_DisplayHexCFParameters
//
// Display the Hex Coefficient File Parameters window
//
// Called by:   QCOM_PromptForRetrieveCoefficientFileParameters
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayHexCFParameters(
    String          ^filePathString,
    bool            primaryDisplay)
{
    bool            littleEndianFloats = GUI_NO;
    DWORD           status = QCOM_SUCCESS;
    StreamReader    ^textReader;
    String          ^fileVersion;
    String          ^lineString;
    String          ^functionName = _T("QCOM_DisplayHexCFParameters");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(filePathString) && File::Exists(filePathString))
    {
        array <String ^> ^hexParameterFieldNameList =
        {
            _T("Transducer serial number"),                     // 0
            _T("Transducer model / part number"),               // 1
            _T("Calibration date"),                             // 2
            _T("Minimum pressure"),                             // 3
            _T("Maximum pressure"),                             // 4
            _T("Minimum temperature"),                          // 5
            _T("Maximum temperature"),                          // 6
            _T("Primary calibration type"),                     // 7
            _T("Pressure prescale type"),                       // 8
            _T("Pressure polynomial order for pressure"),       // 9
            _T("Pressure polynomial order for temperature"),    // 10
            _T("Pressure scale factor (standard units)"),       // 11
            _T("Pressure scale factor (alternate units)"),      // 12
            _T("Pressure alternate units offset"),              // 13
            _T("Pressure Coefficient 0"),                       // 14
            _T("Pressure Coefficient 1"),                       // 15
            _T("Pressure Coefficient 2"),                       // 16
            _T("Pressure Coefficient 3"),                       // 17
            _T("Pressure Coefficient 4"),                       // 18
            _T("Pressure Coefficient 5"),                       // 19
            _T("Pressure Coefficient 6"),                       // 20
            _T("Pressure Coefficient 7"),                       // 21
            _T("Pressure Coefficient 8"),                       // 22
            _T("Pressure Coefficient 9"),                       // 23
            _T("Pressure Coefficient 10"),                      // 24
            _T("Pressure Coefficient 11"),                      // 25
            _T("Pressure Coefficient 12"),                      // 26
            _T("Pressure Coefficient 13"),                      // 27
            _T("Pressure Coefficient 14"),                      // 28
            _T("Pressure Coefficient 15"),                      // 29
            _T("Pressure Coefficient 16"),                      // 30
            _T("Pressure Coefficient 17"),                      // 31
            _T("Pressure Coefficient 18"),                      // 32
            _T("Pressure Coefficient 19"),                      // 33
            _T("Pressure Coefficient 20"),                      // 34
            _T("Pressure Coefficient 21"),                      // 35
            _T("Pressure Coefficient 22"),                      // 36
            _T("Pressure Coefficient 23"),                      // 37
            _T("Pressure Coefficient 24"),                      // 38
            _T("Secondary calibration type"),                   // 39
            _T("Temperature prescale type"),                    // 40
            _T("Temperature polynomial order for pressure"),    // 41
            _T("Temperature polynomial order for temperature"), // 42
            _T("Temperature scale factor (standard units)"),    // 43
            _T("Temperature scale factor (alternate units)"),   // 44
            _T("Temperature alternate units offset"),           // 45
            _T("Temperature Coefficient 0"),                    // 46
            _T("Temperature Coefficient 1"),                    // 47
            _T("Temperature Coefficient 2"),                    // 48
            _T("Temperature Coefficient 3"),                    // 49
            _T("Temperature Coefficient 4"),                    // 50
            _T("Temperature Coefficient 5"),                    // 51
            _T("Temperature Coefficient 6"),                    // 52
            _T("Temperature Coefficient 7"),                    // 53
            _T("Temperature Coefficient 8"),                    // 54
            _T("Temperature Coefficient 9"),                    // 55
            _T("Temperature Coefficient 10"),                   // 56
            _T("Temperature Coefficient 11"),                   // 57
            _T("Temperature Coefficient 12"),                   // 58
            _T("Temperature Coefficient 13"),                   // 59
            _T("Temperature Coefficient 14"),                   // 60
            _T("Temperature Coefficient 15"),                   // 61
            _T("Temperature Coefficient 16"),                   // 62
            _T("Temperature Coefficient 17"),                   // 63
            _T("Temperature Coefficient 18"),                   // 64
            _T("Temperature Coefficient 19"),                   // 65
            _T("Temperature Coefficient 20"),                   // 66
            _T("Temperature Coefficient 21"),                   // 67
            _T("Temperature Coefficient 22"),                   // 68
            _T("Temperature Coefficient 23")                    // 69
        };
        textReader = File::OpenText(filePathString);
        if (textReader)
        {
            lineString = textReader->ReadLine()->Trim();
            if ((((AtoX(lineString[11]) << 12) & 0xF000) |
                ((AtoX(lineString[12]) << 8) & 0x0F00) |
                ((AtoX(lineString[9]) << 4) & 0x00F0) |
                ((AtoX(lineString[10]) & 0x000F))) == QD_QUARTZDYNE_CF_TYPE_LITTLE_ENDIAN)
                littleEndianFloats = GUI_YES;
            fileVersion = String::Format(
                "{0}.{1:D2}",
                ((AtoX(lineString[13]) * 10) + AtoX(lineString[14])),
                ((AtoX(lineString[15]) * 10) + AtoX(lineString[16])));
            textReader->Close();
        }
        //--------------------------------------------------------------------
        // Retrieve all the hex parameter strings based on the file found at
        // the path
        //--------------------------------------------------------------------
        array <String ^> ^hexCFParametersList =
            gcnew array <String ^> (QCOM_MAXIMUM_HEX_COEFFICIENT_FILE_LINES + 1);
        status = QCOM_RetrieveCoefficientFileParameters(
            filePathString,
            hexCFParametersList);
        if (status == QCOM_SUCCESS)
        {
            //----------------------------------------------------------------
            // Create a new window form
            //----------------------------------------------------------------
            displayHexCFParametersWindow = gcnew Form;
            //----------------------------------------------------------------
            // Set its appearance
            //----------------------------------------------------------------
            displayHexCFParametersWindow->MaximizeBox = GUI_NO;
            displayHexCFParametersWindow->HelpButton = GUI_NO;
            displayHexCFParametersWindow->Icon = QCOM_SoftwareIcon;
            displayHexCFParametersWindow->BackgroundImage = whiteSandBackground;
            displayHexCFParametersWindow->Text = String::Concat(
                "Coefficient File Parameters from ",
                filePathString);
            displayHexCFParametersWindow->Size = Drawing::Size(
                Max(QCOM_StringWidth(displayHexCFParametersWindow->Text) + 430, 890),
                ((QCOM_MAXIMUM_HEX_COEFFICIENT_FILE_LINES * 10) + 90));
            displayHexCFParametersWindow->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                10.0F,
                FontStyle::Regular);
            displayHexCFParametersWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
            //----------------------------------------------------------------
            // Populate the two-column window with the strings
            //----------------------------------------------------------------
            for (int lineNumber = 0; lineNumber < QCOM_MAXIMUM_HEX_COEFFICIENT_FILE_LINES; lineNumber++)
            {
                int column = 0;
                Label ^CFLabel = gcnew Label;
                CFLabel->Text = String::Format(
                    "{0} : {1}",
                    hexParameterFieldNameList[lineNumber],
                    hexCFParametersList[lineNumber]);
                if (lineNumber > ((hexParameterFieldNameList->Length / 2) - 1))
                    column = 1;
                CFLabel->Location = Point(
                    (column * 430) + 10,
                    ((lineNumber % (hexParameterFieldNameList->Length / 2)) * 20) + 10);
                CFLabel->Size = Drawing::Size(420, GUI_INFO_LABEL_HEIGHT);
                CFLabel->BackColor = Color::Transparent;
                CFLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
                displayHexCFParametersWindow->Controls->Add(CFLabel);
            }
            //----------------------------------------------------------------
            // Identify the floating-point storage format of this hex file
            //----------------------------------------------------------------
            Label ^fileVersionLabel = gcnew Label;
            fileVersionLabel->Text = String::Concat(
                "File Version: ", fileVersion);
            fileVersionLabel->Location = Point(
                10, displayHexCFParametersWindow->Bottom - 66);
            fileVersionLabel->Size = Drawing::Size(120, GUI_INFO_LABEL_HEIGHT);
            fileVersionLabel->BackColor = Color::Transparent;
            fileVersionLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
            displayHexCFParametersWindow->Controls->Add(fileVersionLabel);
            Label ^endianLabel = gcnew Label;
            endianLabel->Text = String::Concat(
                "Coefficient and floating-point storage orientation: ",
                (littleEndianFloats ? _T("Little-endian") : _T("Big-endian")));
            endianLabel->Location = Point(
                fileVersionLabel->Right + 15,
                fileVersionLabel->Top);
            endianLabel->Size = Drawing::Size(400, GUI_INFO_LABEL_HEIGHT);
            endianLabel->BackColor = Color::Transparent;
            endianLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
            displayHexCFParametersWindow->Controls->Add(endianLabel);
            if (primaryDisplay)
            {
                //------------------------------------------------------------
                // Display native ref files coefficients button
                //------------------------------------------------------------
                String ^presCFRefPathString = String::Concat(
                    Path::GetDirectoryName(filePathString),
                    "\\",
                    Path::GetFileNameWithoutExtension(filePathString),
                    ".crf");
                String ^tempCFRefPathString = String::Concat(
                    Path::GetDirectoryName(filePathString),
                    "\\",
                    Path::GetFileNameWithoutExtension(filePathString),
                    ".crt");
                if (File::Exists(presCFRefPathString) && File::Exists(tempCFRefPathString))
                {
                    Button ^nativeRefFilesButton = gcnew Button;
                    nativeRefFilesButton->Tag = dynamic_cast <Object ^> (presCFRefPathString);
                    nativeRefFilesButton->Text = _T("Display Native\nRef Files");
                    nativeRefFilesButton->Location = Point(
                        displayHexCFParametersWindow->Right - 330,
                        displayHexCFParametersWindow->Bottom - 77);
                    nativeRefFilesButton->Size = Drawing::Size(
                        100,
                        GUI_DOUBLE_BUTTON_HEIGHT);
                    nativeRefFilesButton->Font = gcnew Drawing::Font(
                        FontFamily::GenericSansSerif,
                        8.0F,
                        FontStyle::Regular);
                    GUI_SetButtonInterfaceProperties(nativeRefFilesButton);
                    nativeRefFilesButton->Click +=
                        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DisplayNativeRefCFParametersButtonClicked);
                    displayHexCFParametersWindow->Controls->Add(nativeRefFilesButton);
                }
                delete tempCFRefPathString;
                delete presCFRefPathString;
                //------------------------------------------------------------
                // Display native non-ref files coefficients button
                //------------------------------------------------------------
                String ^presCFNonRefPathString = String::Concat(
                    Path::GetDirectoryName(filePathString),
                    "\\",
                    Path::GetFileNameWithoutExtension(filePathString),
                    ".cff");
                String ^tempCFNonRefPathString = String::Concat(
                    Path::GetDirectoryName(filePathString),
                    "\\",
                    Path::GetFileNameWithoutExtension(filePathString),
                    ".cft");
                if (File::Exists(presCFNonRefPathString) && File::Exists(tempCFNonRefPathString))
                {
                    Button ^nativeNonRefFilesButton = gcnew Button;
                    nativeNonRefFilesButton->Tag = dynamic_cast <Object ^> (presCFNonRefPathString);
                    nativeNonRefFilesButton->Text = _T("Display Native\nNon-ref Files");
                    nativeNonRefFilesButton->Location = Point(
                        displayHexCFParametersWindow->Right - 215,
                        displayHexCFParametersWindow->Bottom - 77);
                    nativeNonRefFilesButton->Size = Drawing::Size(
                        100,
                        GUI_DOUBLE_BUTTON_HEIGHT);
                    nativeNonRefFilesButton->Font = gcnew Drawing::Font(
                        FontFamily::GenericSansSerif,
                        8.0F,
                        FontStyle::Regular);
                    GUI_SetButtonInterfaceProperties(nativeNonRefFilesButton);
                    nativeNonRefFilesButton->Click +=
                        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DisplayNativeNonRefCFParametersButtonClicked);
                    displayHexCFParametersWindow->Controls->Add(nativeNonRefFilesButton);
                }
                delete tempCFNonRefPathString;
                delete presCFNonRefPathString;
            }                           // end of if (primaryDisplay)
            //----------------------------------------------------------------
            // Add a Close button
            //----------------------------------------------------------------
            Button ^closeButton = gcnew Button;
            closeButton->Text = _T("Close");
            closeButton->Location = Point(
                displayHexCFParametersWindow->Right - 100,
                displayHexCFParametersWindow->Bottom - 70);
            closeButton->Size = Drawing::Size(
                GUI_CLOSE_BUTTON_WIDTH,
                GUI_REGULAR_BUTTON_HEIGHT);
            closeButton->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                8.0F,
                FontStyle::Regular);
            closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
            GUI_SetButtonInterfaceProperties(closeButton);
            closeButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DisplayHexCFParametersCloseWindow);
            displayHexCFParametersWindow->Controls->Add(closeButton);
            //----------------------------------------------------------------
            // Set the remaining window properties
            //----------------------------------------------------------------
            displayHexCFParametersWindow->AcceptButton = closeButton;   // button when user presses Enter
            displayHexCFParametersWindow->CancelButton = closeButton;   // button when user presses Esc
            //----------------------------------------------------------------
            // Finally, display the new window
            //----------------------------------------------------------------
            displayHexCFParametersWindow->ShowDialog();
        }                               // end of if (status == QCOM_SUCCESS)
        else
        {
            GUI_DisplayGeneralErrorWithStatus(
                functionName,
                String::Format("QCOM_RetrieveCoefficientFileParameters(hex) for\n{0}",
                    filePathString),
                status);
        }
        delete [] hexCFParametersList;
        delete [] hexParameterFieldNameList;
    }                                   // end of if (StringSet(filePathString) && File::Exists(filePathString))
    else
    {
        if (StringSet(filePathString))
        {
            GUI_DisplaySimpleError(functionName,
                "File '{0}'\ncould not be found",
                filePathString);
        }
        else
        {
            GUI_DisplaySimpleError(functionName,
                "Invalid filename pointer");
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_DisplayHexCFParameters()
//----------------------------------------------------------------------------
// QCOM_DisplayLoadedCoefficientData
//
// Displays the coefficient data for the specified device currently loaded in
// client memory (opposed to either the digital transducer or the module)
//
// Called by:   QCOM_DisplayLoadedCoefficientDataButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayLoadedCoefficientData(
    UnitInfo        ^unit)
{
    bool            littleEndianFloats = GUI_NO;
    char            *digit;
    char            *data;
    int             monthNumber;
    float           floatPres;
    float           floatTemp;
    DWORD           intPres;
    DWORD           intTemp;
    DWORD           unitNumber;
    CoefficientFormatDef
                    *format;
    String          ^labelString;
    String          ^functionName = _T("QCOM_DisplayLoadedCoefficientData");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        format = unit->coefficientData;
        digit = (char *) malloc(200);  // 100 coefficients X 2 digits per value
        if (format && digit)
        {
            unitNumber = unit->unitNumber;
            if (format->fileType == QD_QUARTZDYNE_CF_TYPE_LITTLE_ENDIAN)
                littleEndianFloats = GUI_YES;
            //----------------------------------------------------------------
            // Create a new window form
            //----------------------------------------------------------------
            displayCFDataWindowArray[unitNumber] = gcnew Form;
            //----------------------------------------------------------------
            // Set its appearance
            //----------------------------------------------------------------
            displayCFDataWindowArray[unitNumber]->MaximizeBox = GUI_NO;
            displayCFDataWindowArray[unitNumber]->HelpButton = GUI_NO;
            displayCFDataWindowArray[unitNumber]->TopMost = GUI_YES;
            //----------------------------------------------------------------
            // Set its icon
            //----------------------------------------------------------------
            displayCFDataWindowArray[unitNumber]->Icon = QCOM_SoftwareIcon;
            //----------------------------------------------------------------
            // Set the background image
            //----------------------------------------------------------------
            displayCFDataWindowArray[unitNumber]->BackgroundImage = gcnew
                Bitmap(GUI_BG_WHITE_SAND, GUI_YES);
            //----------------------------------------------------------------
            // Set the title, size, and border style
            //----------------------------------------------------------------
            String ^moduleTitle = unit->moduleSerialNumber;
            String ^snTitle = unit->transducerSerialNumber;
            if (unitNumber == QCOM_MAXIMUM_NUMBER_OF_UNITS)
            {
                if (QCOM_XDSNValid(unit))
                {
                    displayCFDataWindowArray[unitNumber]->Text = String::Concat(
                        "Coefficient Data for Transducer ",
                        snTitle);
                }
                else
                {
                    displayCFDataWindowArray[unitNumber]->Text = String::Concat(
                        "Coefficient Data for ",
                        moduleTitle);
                }
            }
            else
            {
                displayCFDataWindowArray[unitNumber]->Text = String::Concat(
                    "Coefficient Data for ",
                    (QCOM_XDIsFrequency(unit) ?
                        "Frequency (Analog)" : "Digital"),
                    " Transducer ",
                    (QCOM_XDSNValid(unit) ? snTitle : String::Empty));
                if (QCOM_ModuleSNValid(unit))
                {
                    displayCFDataWindowArray[unitNumber]->Text = String::Concat(
                        displayCFDataWindowArray[unitNumber]->Text,
                        " on Module ", moduleTitle);
                }
            }
            delete snTitle;
            delete moduleTitle;
            displayCFDataWindowArray[unitNumber]->Size = Drawing::Size(
                GUI_COEFFICIENT_DATA_WINDOW_WIDTH, 490);
            displayCFDataWindowArray[unitNumber]->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                10.0F,
                FontStyle::Regular);
            displayCFDataWindowArray[unitNumber]->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
//            displayCFDataWindowArray[unitNumber]->StartPosition = FormStartPosition::CenterScreen;
            //----------------------------------------------------------------
            // Add a Close button
            //----------------------------------------------------------------
            Button ^closeButton = gcnew Button;
            closeButton->Text = _T("Close");
            closeButton->Location = Point(
                displayCFDataWindowArray[unitNumber]->Right - 100,
                displayCFDataWindowArray[unitNumber]->Bottom - 70);
            closeButton->Size = Drawing::Size(
                GUI_CLOSE_BUTTON_WIDTH,
                GUI_REGULAR_BUTTON_HEIGHT);
            closeButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
            closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
            GUI_SetUnitObjectInterfaceProperties(
                closeButton,
                unitNumber);
            closeButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_CloseCFWindow);
            displayCFDataWindowArray[unitNumber]->Controls->Add(closeButton);
            //----------------------------------------------------------------
            // Display the serial number bytes
            //----------------------------------------------------------------
            digit[0] = (((format->serialNumber & 0x000000F0) >> 4) & 0x0F);
            digit[1] = (format->serialNumber & 0x0F);
            digit[2] = (((format->serialNumber & 0x0000F000) >> 12) & 0x0F);
            digit[3] = (((format->serialNumber & 0x00000F00) >> 8) & 0x0F);
            digit[4] = (((format->serialNumber & 0x00F00000) >> 20) & 0x0F);
            digit[5] = (((format->serialNumber & 0x000F0000) >> 16) & 0x0F);
            digit[6] = (((format->serialNumber & 0xF0000000) >> 28) & 0x0F);
            digit[7] = (((format->serialNumber & 0x0F000000) >> 24) & 0x0F);
            Label ^serialNumber = gcnew Label;
            serialNumber->Text = String::Format(
                "Transducer Serial Number : {0} < {1:X1}{2:X1} {3:X1}{4:X1} {5:X1}{6:X1} {7:X1}{8:X1} >",
                unit->transducerSerialNumber,
                digit[0], digit[1], digit[2], digit[3],
                digit[4], digit[5], digit[6], digit[7]);
//            serialNumber->Font = gcnew
//                Drawing::Font(
//                    this->Font,
//                    FontStyle::Bold);
            serialNumber->Location = Point(10, 10);
            serialNumber->Size = Drawing::Size(340, GUI_COEFFICIENT_LABEL_HEIGHT);
            serialNumber->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // Display the file information
            //----------------------------------------------------------------
            digit[0] = (((format->fileType & 0x00F0) >> 4) & 0x0F);
            digit[1] = (format->fileType & 0x0F);
            digit[2] = (((format->fileType & 0xF000) >> 12) & 0x0F);
            digit[3] = (((format->fileType & 0x0F00) >> 8) & 0x0F);
            digit[4] = (((format->fileVersion & 0x00F0) >> 4) & 0x0F);
            digit[5] = (format->fileVersion & 0x0F);
            digit[6] = (((format->fileVersion & 0xF000) >> 12) & 0x0F);
            digit[7] = (((format->fileVersion & 0x0F00) >> 8) & 0x0F);
            Label ^fileInfo = gcnew Label;
            fileInfo->Text = String::Format(
                "File Type : {0} < {1:X1}{2:X1} {3:X1}{4:X1} >   File Version : {5:X1}.{6:X1}{7:X1} < {8:X1}{9:X1} {10:X1}{11:X1} >",  // 0x2301
                (((format->fileType & 0xFF) == 0x0D) ? _T("Quartzdyne") : QCOM_STRING_UNKNOWN),
                digit[0], digit[1], digit[2], digit[3],
                digit[5], digit[6], digit[7],
                digit[4], digit[5], digit[6], digit[7]);
            fileInfo->Location = Point(
                serialNumber->Left,
                serialNumber->Bottom + 4);
            fileInfo->Size = Drawing::Size(410, GUI_COEFFICIENT_LABEL_HEIGHT);
            fileInfo->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // Display the part number
            //----------------------------------------------------------------
            data = format->partNumber;
            Label ^partNumber = gcnew Label;
            partNumber->Text = String::Format(
                "Part Number : {0} < {1:X2} {2:X2} {3:X2} {4:X2} {5:X2} {6:X2} {7:X2} {8:X2} >",
                unit->transducerPartNumber,
                (data[0] & 0xFF), (data[1] & 0xFF), (data[2] & 0xFF), (data[3] & 0xFF),
                (data[4] & 0xFF), (data[5] & 0xFF), (data[6] & 0xFF), (data[7] & 0xFF));
            partNumber->Location = Point(
                serialNumber->Left,
                fileInfo->Bottom + 4);
            partNumber->Size = Drawing::Size(420, GUI_COEFFICIENT_LABEL_HEIGHT);
            partNumber->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // Display the calibration date
            //----------------------------------------------------------------
            digit[0] = (((format->calibrationDate & 0xF0) >> 4) & 0x0F);
            digit[1] = (format->calibrationDate & 0x0F);
            digit[2] = (((format->calibrationMonth & 0xF0) >> 4) & 0x0F);
            digit[3] = (format->calibrationMonth & 0x0F);
            digit[4] = (((format->calibrationYear & 0x00F0) >> 4) & 0x0F);
            digit[5] = (format->calibrationYear & 0x0F);
            digit[6] = (((format->calibrationYear & 0xF000) >> 12) & 0x0F);
            digit[7] = (((format->calibrationYear & 0x0F00) >> 8) & 0x0F);
            monthNumber = (int)
                ((format->calibrationMonth > 9) ?
                    (format->calibrationMonth - 6) : format->calibrationMonth);
            Label ^calDate = gcnew Label;
            calDate->Text = String::Format(
                "Calibration Date : {0:X1}{1:X1} {2} {3:X1}{4:X1}{5:X1}{6:X1} < {7:X1}{8:X1} {9:X1}{10:X1} {11:X1}{12:X1} {13:X1}{14:X1} >",
                digit[0], digit[1], QCOM_MonthStringArray[monthNumber],
                digit[4], digit[5], digit[6], digit[7],
                digit[4], digit[5], digit[6], digit[7],
                digit[2], digit[3], digit[0], digit[1]);
            calDate->Location = Point(
                serialNumber->Left,
                partNumber->Bottom + 4);
            calDate->Size = Drawing::Size(320, GUI_COEFFICIENT_LABEL_HEIGHT);
            calDate->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // Display Pmin, Pmax, Tmin, and Tmax
            //----------------------------------------------------------------
            digit[0] = (((format->minimumPressure & 0xF0) >> 4) & 0x0F);
            digit[1] = (format->minimumPressure & 0x0F);
            digit[2] = (((format->maximumPressure & 0xF0) >> 4) & 0x0F);
            digit[3] = (format->maximumPressure & 0x0F);
            digit[4] = (((format->minimumTemperature & 0xF0) >> 4) & 0x0F);
            digit[5] = (format->minimumTemperature & 0x0F);
            digit[6] = (((format->maximumTemperature & 0xF0) >> 4) & 0x0F);
            digit[7] = (format->maximumTemperature & 0x0F);
            Label ^ptLimits = gcnew Label;
            ptLimits->Text = String::Format(
                "Pmin : {0:D} psi < {1:X1}{2:X1} >   Pmax : {3:D} psi < {4:X1}{5:X1} >   "
                "Tmin : {6:D} �C < {7:X1}{8:X1} >   Tmax : {9:D} �C < {10:X1}{11:X1} >",
                (format->minimumPressure * 1000), digit[0], digit[1],
                (format->maximumPressure * 1000), digit[2], digit[3],
                (format->minimumTemperature * 5), digit[4], digit[5],
                (format->maximumTemperature * 5), digit[6], digit[7]);
            ptLimits->Location = Point(
                serialNumber->Left,
                calDate->Bottom + 4);
            ptLimits->Size = Drawing::Size(580, GUI_COEFFICIENT_LABEL_HEIGHT);
            ptLimits->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // Display the standard units
            //----------------------------------------------------------------
            data = (char *) &format->scaleFactor1StdUnits;
            for (int index = 0; index < 8; index++)
            {
                if (index % 2)
                    digit[index] = (data[(index - 1) / 2] & 0x0F);
                else
                    digit[index] = (((data[index / 2] & 0xF0) >> 4) & 0x0F);
            }
            data = (char *) &format->scaleFactor2StdUnits;
            for (int index = 0; index < 8; index++)
            {
                if (index % 2)
                    digit[index + 8] = (data[(index - 1) / 2] & 0x0F);
                else
                    digit[index + 8] = (((data[index / 2] & 0xF0) >> 4) & 0x0F);
            }
            if (littleEndianFloats)
            {
                floatPres = format->scaleFactor1StdUnits;
                floatTemp = format->scaleFactor2StdUnits;
            }
            else
            {
                floatPres = QCOM_ReverseFloatValue(format->scaleFactor1StdUnits);
                floatTemp = QCOM_ReverseFloatValue(format->scaleFactor2StdUnits);
            }
            Label ^stdUnits = gcnew Label;
            stdUnits->Text = String::Format(
                "Std Pressure Units : {0:F1} psi < {1:X1}{2:X1} {3:X1}{4:X1} {5:X1}{6:X1} {7:X1}{8:X1} >   "
                "Std Temperature Units : {9:F1} �C < {10:X1}{11:X1} {12:X1}{13:X1} {14:X1}{15:X1} {16:X1}{17:X1} >",
                (floatPres * QCOM_UNIVERSAL_SCALE_FACTOR),
                digit[0], digit[1], digit[2], digit[3],
                digit[4], digit[5], digit[6], digit[7],
                (floatTemp * QCOM_UNIVERSAL_SCALE_FACTOR),
                digit[8], digit[9], digit[10], digit[11],
                digit[12], digit[13], digit[14], digit[15]);
            stdUnits->Location = Point(
                serialNumber->Left,
                ptLimits->Bottom + 4);
            stdUnits->Size = Drawing::Size(600, GUI_COEFFICIENT_LABEL_HEIGHT);
            stdUnits->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // Display the alternate units
            //----------------------------------------------------------------
            data = (char *) &format->scaleFactor1AltUnits;
            for (int index = 0; index < 8; index++)
            {
                if (index % 2)
                    digit[index] = (data[(index - 1) / 2] & 0x0F);
                else
                    digit[index] = (((data[index / 2] & 0xF0) >> 4) & 0x0F);
            }
            data = (char *) &format->scaleFactor2AltUnits;
            for (int index = 0; index < 8; index++)
            {
                if (index % 2)
                    digit[index + 8] = (data[(index - 1) / 2] & 0x0F);
                else
                    digit[index + 8] = (((data[index / 2] & 0xF0) >> 4) & 0x0F);
            }
            if (littleEndianFloats)
            {
                floatPres = format->scaleFactor1AltUnits;
                floatTemp = format->scaleFactor2AltUnits;
            }
            else
            {
                floatPres = QCOM_ReverseFloatValue(format->scaleFactor1AltUnits);
                floatTemp = QCOM_ReverseFloatValue(format->scaleFactor2AltUnits);
            }
            Label ^altUnits = gcnew Label;
            altUnits->Text = String::Format(
                "Alt Pressure Units : {0:F7} bar < {1:X1}{2:X1} {3:X1}{4:X1} {5:X1}{6:X1} {7:X1}{8:X1} >   "
                "Alt Temperature Units : {9:F1} �F < {10:X1}{11:X1} {12:X1}{13:X1} {14:X1}{15:X1} {16:X1}{17:X1} >",
                (floatPres * QCOM_UNIVERSAL_SCALE_FACTOR),
                digit[0], digit[1], digit[2], digit[3],
                digit[4], digit[5], digit[6], digit[7],
                (floatTemp * QCOM_UNIVERSAL_SCALE_FACTOR),
                digit[8], digit[9], digit[10], digit[11],
                digit[12], digit[13], digit[14], digit[15]);
            altUnits->Location = Point(
                serialNumber->Left,
                stdUnits->Bottom + 4);
            altUnits->Size = Drawing::Size(620, GUI_COEFFICIENT_LABEL_HEIGHT);
            altUnits->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // Display the alternate units offsets
            //----------------------------------------------------------------
            intPres = format->offset1AlternateUnits;
            digit[0] = (((intPres & 0x000000F0) >> 4) & 0x0F);
            digit[1] = (intPres & 0x0F);
            digit[2] = (((intPres & 0x0000F000) >> 12) & 0x0F);
            digit[3] = (((intPres & 0x00000F00) >> 8) & 0x0F);
            digit[4] = (((intPres & 0x00F00000) >> 20) & 0x0F);
            digit[5] = (((intPres & 0x000F0000) >> 16) & 0x0F);
            digit[6] = (((intPres & 0xF0000000) >> 28) & 0x0F);
            digit[7] = (((intPres & 0x0F000000) >> 24) & 0x0F);
            if (littleEndianFloats)
                floatPres = (float) intPres;
            else
                floatPres = (float) QCOM_ReverseIntegerValue(intPres);
            intTemp = format->offset2AlternateUnits;
            digit[8] = (((intTemp & 0x000000F0) >> 4) & 0x0F);
            digit[9] = (intTemp & 0x0F);
            digit[10] = (((intTemp & 0x0000F000) >> 12) & 0x0F);
            digit[11] = (((intTemp & 0x00000F00) >> 8) & 0x0F);
            digit[12] = (((intTemp & 0x00F00000) >> 20) & 0x0F);
            digit[13] = (((intTemp & 0x000F0000) >> 16) & 0x0F);
            digit[14] = (((intTemp & 0xF0000000) >> 28) & 0x0F);
            digit[15] = (((intTemp & 0x0F000000) >> 24) & 0x0F);
            if (littleEndianFloats)
                floatTemp = (float) intTemp;
            else
                floatTemp = (float) QCOM_ReverseIntegerValue(intTemp);
            Label ^offUnits = gcnew Label;
            offUnits->Text = String::Format(
                "Alt Pressure Units Offset : {0:F3} psi < {1:X1}{2:X1} {3:X1}{4:X1} {5:X1}{6:X1} {7:X1}{8:X1} >   "
                "Alt Temperature Units Offset : {9:F3} �C < {10:X1}{11:X1} {12:X1}{13:X1} {14:X1}{15:X1} {16:X1}{17:X1} >",
                (floatPres / QCOM_UNIVERSAL_SCALE_FACTOR),
                digit[0], digit[1], digit[2], digit[3],
                digit[4], digit[5], digit[6], digit[7],
                (floatTemp / QCOM_UNIVERSAL_SCALE_FACTOR),
                digit[8], digit[9], digit[10], digit[11],
                digit[12], digit[13], digit[14], digit[15]);
            offUnits->Location = Point(
                serialNumber->Left,
                altUnits->Bottom + 4);
            offUnits->Size = Drawing::Size(720, GUI_COEFFICIENT_LABEL_HEIGHT);
            offUnits->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // Display the list 1 label
            //----------------------------------------------------------------
            switch (format->calibration1Type)
            {
                case QCOM_CALIBRATION_TYPE_PRESSURE : labelString = _T("Pressure"); break;
                case QCOM_CALIBRATION_TYPE_TEMPERATURE : labelString = _T("Temperature"); break;
                default : labelString = QCOM_STRING_UNKNOWN; break;
            }
            digit[0] = (((format->calibration1Type & 0xF0) >> 4) & 0x0F);
            digit[1] = (format->calibration1Type & 0x0F);
            Label ^list1Label = gcnew Label;
            list1Label->Text = String::Format(
                "{0} Coefficients < {1:X1}{2:X1} > :",
                labelString, digit[0], digit[1]);
            list1Label->Location = Point(
                serialNumber->Left,
                offUnits->Bottom + 8);
            list1Label->Size = Drawing::Size(200, GUI_COEFFICIENT_LABEL_HEIGHT);
            list1Label->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // Display the list 1 prescale type
            //----------------------------------------------------------------
            digit[0] = (((format->prescale1Type & 0xF0) >> 4) & 0x0F);
            digit[1] = (format->prescale1Type & 0x0F);
            digit[2] = (((format->pressure1FitOrder & 0xF0) >> 4) & 0x0F);
            digit[3] = (format->pressure1FitOrder & 0x0F);
            digit[4] = (((format->temperature1FitOrder & 0xF0) >> 4) & 0x0F);
            digit[5] = (format->temperature1FitOrder & 0x0F);
            Label ^list1Prescale = gcnew Label;
            list1Prescale->Text = String::Format(
                "Prescale Type = < {0:X1}{1:X1} >   "
                "N1 = < {2:X1}{3:X1} >   N2 = < {4:X1}{5:X1} >",
                digit[0], digit[1], digit[2],
                digit[3], digit[4], digit[5]);
            list1Prescale->Location = Point(
                displayCFDataWindowArray[unitNumber]->Right - 330,
                list1Label->Top);
            list1Prescale->Size = Drawing::Size(
                314,
                GUI_COEFFICIENT_LABEL_HEIGHT);  // 14 @ 8em, 18 @ 10em
            list1Prescale->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // Display the list 1 coefficients
            //----------------------------------------------------------------
            data = format->coefficients1;
            for (int index = 0; index < 200; index++)
            {
                if (index % 2)
                    digit[index] = (data[(index - 1) / 2] & 0x0F);
                else
                    digit[index] = (((data[index / 2] & 0xF0) >> 4) & 0x0F);
            }
            Label ^list1Coeff1 = gcnew Label;
            list1Coeff1->Text = QCOM_BuildCoefficientDataLine(digit, 0);
            list1Coeff1->Location =
                Point(serialNumber->Left, list1Label->Bottom + 8);
            list1Coeff1->Size =
                Drawing::Size(850, GUI_COEFFICIENT_LABEL_HEIGHT); // GUI_REGULAR_LABEL_HEIGHT);
            list1Coeff1->BackColor = Color::Transparent;
            list1Coeff1->Font = gcnew Drawing::Font(
                FontFamily::GenericMonospace,
                10.0F,
                FontStyle::Bold);
            Label ^list1Coeff2 = gcnew Label;
            list1Coeff2->Text = QCOM_BuildCoefficientDataLine(digit, 1);
            list1Coeff2->Location =
                Point(serialNumber->Left, list1Coeff1->Bottom + 8);
            list1Coeff2->Size = list1Coeff1->Size;
            list1Coeff2->BackColor = Color::Transparent;
            list1Coeff2->Font = gcnew Drawing::Font(
                FontFamily::GenericMonospace,
                10.0F,
                FontStyle::Bold);
            Label ^list1Coeff3 = gcnew Label;
            list1Coeff3->Text = QCOM_BuildCoefficientDataLine(digit, 2);
            list1Coeff3->Location =
                Point(serialNumber->Left, list1Coeff2->Bottom + 8);
            list1Coeff3->Size = list1Coeff1->Size;
            list1Coeff3->BackColor = Color::Transparent;
            list1Coeff3->Font = gcnew Drawing::Font(
                FontFamily::GenericMonospace,
                10.0F,
                FontStyle::Bold);
            Label ^list1Coeff4 = gcnew Label;
            list1Coeff4->Text = String::Format(
                "{0:X1}{1:X1} {2:X1}{3:X1} {4:X1}{5:X1} {6:X1}{7:X1}",
                digit[192], digit[193], digit[194], digit[195],
                digit[196], digit[197], digit[198], digit[199]);
            list1Coeff4->Location = Point(
                serialNumber->Left,
                list1Coeff3->Bottom + 8);
            list1Coeff4->Size = Drawing::Size(100, GUI_REGULAR_LABEL_HEIGHT);
            list1Coeff4->BackColor = Color::Transparent;
            list1Coeff4->Font = gcnew Drawing::Font(
                FontFamily::GenericMonospace,
                10.0F,
                FontStyle::Bold);
            //----------------------------------------------------------------
            // Display the list 2 label
            //----------------------------------------------------------------
            switch (format->calibration2Type)
            {
                case QCOM_CALIBRATION_TYPE_PRESSURE : labelString = _T("Pressure"); break;
                case QCOM_CALIBRATION_TYPE_TEMPERATURE : labelString = _T("Temperature"); break;
                default : labelString = QCOM_STRING_UNKNOWN; break;
            }
            digit[0] = (((format->calibration2Type & 0xF0) >> 4) & 0x0F);
            digit[1] = (format->calibration2Type & 0x0F);
            Label ^list2Label = gcnew Label;
            list2Label->Text = String::Format(
                "{0} Coefficients < {1:X1}{2:X1} > :",
                labelString, digit[0], digit[1]);
            list2Label->Location = Point(
                serialNumber->Left,
                list1Coeff4->Bottom + 8);
            list2Label->Size = Drawing::Size(250, GUI_COEFFICIENT_LABEL_HEIGHT);
            list2Label->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // Display the list 2 prescale type
            //----------------------------------------------------------------
            digit[0] = (((format->prescale2Type & 0xF0) >> 4) & 0x0F);
            digit[1] = (format->prescale2Type & 0x0F);
            digit[2] = (((format->pressure2FitOrder & 0xF0) >> 4) & 0x0F);
            digit[3] = (format->pressure2FitOrder & 0x0F);
            digit[4] = (((format->temperature2FitOrder & 0xF0) >> 4) & 0x0F);
            digit[5] = (format->temperature2FitOrder & 0x0F);
            Label ^list2Prescale = gcnew Label;
            list2Prescale->Text = String::Format(
                "Prescale Type = < {0:X1}{1:X1} >   N1 = < {2:X1}{3:X1} >   N2 = < {4:X1}{5:X1} >",
                digit[0], digit[1], digit[2],
                digit[3], digit[4], digit[5]);
            list2Prescale->Location = Point(
                displayCFDataWindowArray[unitNumber]->Right - 330,
                list2Label->Top);
            list2Prescale->Size = Drawing::Size(314, GUI_COEFFICIENT_LABEL_HEIGHT);
            list2Prescale->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // Display the list 2 coefficients
            //----------------------------------------------------------------
            data = format->coefficients2;
            for (int index = 0; index < 192; index++)
            {
                if (index % 2)
                    digit[index] = (data[(index - 1) / 2] & 0x0F);
                else
                    digit[index] = (((data[index / 2] & 0xF0) >> 4) & 0x0F);
            }
            Label ^list2Coeff1 = gcnew Label;
            list2Coeff1->Text = QCOM_BuildCoefficientDataLine(digit, 0);
            list2Coeff1->Location = Point(
                serialNumber->Left,
                list2Label->Bottom + 8);
            list2Coeff1->Size = Drawing::Size( list1Coeff1->Width, GUI_COEFFICIENT_LABEL_HEIGHT);
            list2Coeff1->BackColor = Color::Transparent;
            list2Coeff1->Font = gcnew Drawing::Font(
                FontFamily::GenericMonospace,
                10.0F,
                FontStyle::Bold);
            Label ^list2Coeff2 = gcnew Label;
            list2Coeff2->Text = QCOM_BuildCoefficientDataLine(digit, 1);
            list2Coeff2->Location = Point(
                serialNumber->Left,
                list2Coeff1->Bottom + 8);
            list2Coeff2->Size =  list2Coeff1->Size;
            list2Coeff2->BackColor = Color::Transparent;
            list2Coeff2->Font = gcnew Drawing::Font(
                FontFamily::GenericMonospace,
                10.0F,
                FontStyle::Bold);
            Label ^list2Coeff3 = gcnew Label;
            list2Coeff3->Text = QCOM_BuildCoefficientDataLine(digit, 2);
            list2Coeff3->Location =
                Point(serialNumber->Left, list2Coeff2->Bottom + 8);
            list2Coeff3->Size = list2Coeff1->Size;
            list2Coeff3->BackColor = Color::Transparent;
            list2Coeff3->Font = gcnew Drawing::Font(
                FontFamily::GenericMonospace,
                10.0F,
                FontStyle::Bold);
            //----------------------------------------------------------------
            // Display the checksum and end-of-file marker
            //----------------------------------------------------------------
            data = (char *) format->endOfFile;
            for (int index = 0; index < 6; index++)
            {
                if (index % 2)
                    digit[index] = (data[(index - 1) / 2] & 0x0F);
                else
                    digit[index] = (((data[index / 2] & 0xF0) >> 4) & 0x0F);
            }
            digit[6] = (((format->checksum & 0xF0) >> 4) & 0x0F);
            digit[7] = (format->checksum & 0x0F);
            Label ^eofChecksum = gcnew Label;
            eofChecksum->Text = String::Format(
                "End-Of-File = < {0:X1}{1:X1} {2:X1}{3:X1} {4:X1}{5:X1} >   Checksum = < {6:X1}{7:X1} >",
                digit[0], digit[1], digit[2], digit[3],
                digit[4], digit[5], digit[6], digit[7]);
            eofChecksum->Location = Point(
                serialNumber->Left,
                list2Coeff3->Bottom + 8);
            eofChecksum->Size = Drawing::Size(320, GUI_COEFFICIENT_LABEL_HEIGHT);
            eofChecksum->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // Add all the string labels to the form control
            //----------------------------------------------------------------
            array <Label ^> ^coefficientLabels =
            {
                serialNumber,       fileInfo,           partNumber,         calDate,
                ptLimits,           stdUnits,           altUnits,           offUnits,
                list1Label,         list1Prescale,      list1Coeff1,        list1Coeff2,
                list1Coeff3,        list1Coeff4,        list2Label,         list2Prescale,
                list2Coeff1,        list2Coeff2,        list2Coeff3,        eofChecksum
            };
            displayCFDataWindowArray[unitNumber]->Controls->AddRange(coefficientLabels);
            //----------------------------------------------------------------
            // Set the remaining window properties
            //----------------------------------------------------------------
            displayCFDataWindowArray[unitNumber]->AcceptButton = closeButton; // button when user presses Enter
            displayCFDataWindowArray[unitNumber]->CancelButton = closeButton; // button when user presses Esc
            //--------------------------------------------------------------------
            // Finally, display the new window
            //--------------------------------------------------------------------
            displayCFDataWindowArray[unitNumber]->ShowDialog();
            free((void *) digit);
        }                               // end of if (format && digit)
        else
        {
            GUI_DisplayMandatoryError(functionName,
                "Unable to allocate the necessary buffers");
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_DisplayLoadedCoefficientData()
//----------------------------------------------------------------------------
// QCOM_DisplayNativeCFParameters
//
// Display the Native Coefficient File Parameters window
//
// Called by:   QCOM_PromptForRetrieveCoefficientFileParameters
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayNativeCFParameters(
    String          ^filePathString,
    bool            primaryDisplay)
{
    int             lineOffset;
    int             numberOfCoefficients = QCOM_MAXIMUM_NUMBER_OF_COEFFICIENTS;
    int             numberOfPresLines;
    int             numberOfTempLines;
    int             pressureOrder;
    int             temperatureOrder;
    DWORD           status = QCOM_SUCCESS;
    StreamReader    ^textReader;
    String          ^lineString;
    String          ^functionName = _T("QCOM_DisplayNativeCFParameters");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(filePathString) && File::Exists(filePathString))
    {
        String ^presCFPathString;
        String ^tempCFPathString;
        array <String ^> ^nativePresParameterFieldNameList;
        array <String ^> ^nativeTempParameterFieldNameList;
        array <String ^> ^nativeParameterFileNameList = gcnew array <String ^> (2);
        array <String ^> ^nativeParameterCompleteFieldNameList =
        {
            _T("Transducer serial number / sensor ID"),         // 0
            _T("Calibration type"),                             // 1
            _T("Calibration units"),                            // 2
            _T("Temperature polynomial order"),                 // 3
            _T("Temperature prescale value"),                   // 4
            _T("Temperature scale factor"),                     // 5
            _T("Temperature offset frequency"),                 // 6
            _T("Pressure polynomial order"),                    // 7
            _T("Pressure prescale value"),                      // 8
            _T("Pressure scale factor"),                        // 9
            _T("Pressure offset frequency"),                    // 10
            _T("Coefficient 0"),                                // 11
            _T("Coefficient 1"),                                // 12
            _T("Coefficient 2"),                                // 13
            _T("Coefficient 3"),                                // 14
            _T("Coefficient 4"),                                // 15
            _T("Coefficient 5"),                                // 16
            _T("Coefficient 6"),                                // 17
            _T("Coefficient 7"),                                // 18
            _T("Coefficient 8"),                                // 19
            _T("Coefficient 9"),                                // 20
            _T("Coefficient 10"),                               // 21
            _T("Coefficient 11"),                               // 22
            _T("Coefficient 12"),                               // 23
            _T("Coefficient 13"),                               // 24
            _T("Coefficient 14"),                               // 25
            _T("Coefficient 15"),                               // 26
            _T("Coefficient 16"),                               // 27
            _T("Coefficient 17"),                               // 28
            _T("Coefficient 18"),                               // 29
            _T("Coefficient 19"),                               // 30
            _T("Coefficient 20"),                               // 31
            _T("Coefficient 21"),                               // 32
            _T("Coefficient 22"),                               // 33
            _T("Coefficient 23"),                               // 34
            _T("Coefficient 24"),                               // 35
            _T("Span"),                                         // 36
            _T("Zero"),                                         // 37
            _T("Minimum temperature"),                          // 38
            _T("Maximum temperature"),                          // 39
            _T("Minimum pressure"),                             // 40
            _T("Maximum pressure"),                             // 41
            _T("Calibration date"),                             // 42
            _T("Transducer model / part number")                // 43
        };
        //--------------------------------------------------------------------
        // Create the path-less filenames to be displayed
        //--------------------------------------------------------------------
        if (filePathString->ToLower()->EndsWith(".crf") ||
            filePathString->ToLower()->EndsWith(".cff"))
        {
            nativeParameterFileNameList[0] =
                Path::GetFileName(filePathString);
            if (filePathString->ToLower()->EndsWith(".crf"))
                nativeParameterFileNameList[1] = String::Concat(
                    Path::GetFileNameWithoutExtension(filePathString),
                    ".crt");
            else
                nativeParameterFileNameList[1] = String::Concat(
                    Path::GetFileNameWithoutExtension(filePathString),
                    ".cft");
        }
        else
        {
            if (filePathString->ToLower()->EndsWith(".crt"))
            {
                nativeParameterFileNameList[0] = String::Concat(
                    Path::GetFileNameWithoutExtension(filePathString),
                    ".crf");
                nativeParameterFileNameList[1] =
                    Path::GetFileName(filePathString);
            }
            else
            {
                nativeParameterFileNameList[0] = String::Concat(
                    Path::GetFileNameWithoutExtension(filePathString),
                    ".cff");
                nativeParameterFileNameList[1] = String::Concat(
                    Path::GetFileNameWithoutExtension(filePathString),
                    ".cft");
            }
        }
        //--------------------------------------------------------------------
        // Parse the pressure coefficient file
        //--------------------------------------------------------------------
        presCFPathString = String::Concat(
            Path::GetDirectoryName(filePathString),
            "\\",
            nativeParameterFileNameList[0]);
        textReader = File::OpenText(presCFPathString);
        if (textReader)
        {
            int lineNumber;
            //----------------------------------------------------------------
            // Skip to line 4 and retrieve the temperature polynomial order
            //----------------------------------------------------------------
            lineNumber = 4;
            while (lineNumber--)
            {
                lineString = textReader->ReadLine();
            }
            temperatureOrder = Convert::ToInt32(lineString->Trim(), 16);
            //----------------------------------------------------------------
            // Skip to line 8 (4 more) and retrieve the pressure polynomial order
            //----------------------------------------------------------------
            lineNumber = 4;
            while (lineNumber--)
            {
                lineString = textReader->ReadLine();
            }
            pressureOrder = Convert::ToInt32(lineString->Trim(), 16);
            numberOfCoefficients = ((temperatureOrder + 1) * (pressureOrder + 1));
            textReader->Close();
        }
        //--------------------------------------------------------------------
        // Create the pressure coefficient field name list
        //--------------------------------------------------------------------
        numberOfPresLines = numberOfCoefficients + 19;
        nativePresParameterFieldNameList = gcnew array <String ^> (numberOfPresLines + 1);
        for (int lineNumber = 0; lineNumber < numberOfPresLines; lineNumber++)
        {
            //----------------------------------------------------------------
            // Adjust the line numbers according to the pressure and
            // temperature polynomial orders
            //----------------------------------------------------------------
            if (lineNumber > (QCOM_NCF_PARAMETER_PRES_OFFSET_FREQ + numberOfCoefficients))
            {
                lineOffset =
                    lineNumber + QCOM_MAXIMUM_NUMBER_OF_COEFFICIENTS - numberOfCoefficients;
            }
            else
            {
                lineOffset = lineNumber;
            }
            nativePresParameterFieldNameList[lineNumber] = nativeParameterCompleteFieldNameList[lineOffset];
        }
        //--------------------------------------------------------------------
        // Parse the temperature coefficient file
        //--------------------------------------------------------------------
        tempCFPathString = String::Concat(
            Path::GetDirectoryName(filePathString),
            "\\",
            nativeParameterFileNameList[1]);
        textReader = File::OpenText(tempCFPathString);
        if (textReader)
        {
            int lineNumber;
            //----------------------------------------------------------------
            // Skip to line 4 and retrieve the temperature polynomial order
            //----------------------------------------------------------------
            lineNumber = 4;
            while (lineNumber--)
            {
                lineString = textReader->ReadLine();
            }
            temperatureOrder = Convert::ToInt32(lineString->Trim(), 16);
            //----------------------------------------------------------------
            // Skip to line 8 (4 more) and retrieve the pressure polynomial order
            //----------------------------------------------------------------
            lineNumber = 4;
            while (lineNumber--)
            {
                lineString = textReader->ReadLine();
            }
            pressureOrder = Convert::ToInt32(lineString->Trim(), 16);
            numberOfCoefficients = ((temperatureOrder + 1) * (pressureOrder + 1));
            textReader->Close();
        }
        //--------------------------------------------------------------------
        // Create the temperature coefficient field name list
        //--------------------------------------------------------------------
        numberOfTempLines = numberOfCoefficients + 19;
        nativeTempParameterFieldNameList = gcnew array <String ^> (numberOfTempLines + 1);
        for (int lineNumber = 0; lineNumber < numberOfTempLines; lineNumber++)
        {
            //----------------------------------------------------------------
            // Adjust the line numbers according to the pressure and
            // temperature polynomial orders
            //----------------------------------------------------------------
            if (lineNumber > (QCOM_NCF_PARAMETER_PRES_OFFSET_FREQ + numberOfCoefficients))
            {
                lineOffset =
                    lineNumber + QCOM_MAXIMUM_NUMBER_OF_COEFFICIENTS - numberOfCoefficients;
            }
            else
            {
                lineOffset = lineNumber;
            }
            nativeTempParameterFieldNameList[lineNumber] = nativeParameterCompleteFieldNameList[lineOffset];
        }
        //--------------------------------------------------------------------
        // Retrieve all the native parameter strings based on the files found
        // at the path
        //--------------------------------------------------------------------
        array <String ^> ^presCFParametersList =
            gcnew array <String ^> (numberOfPresLines + 1);
        status = QCOM_RetrieveCoefficientFileParameters(
            presCFPathString,
            presCFParametersList);
        array <String ^> ^tempCFParametersList =
            gcnew array <String ^> (numberOfTempLines + 1);
        status = QCOM_RetrieveCoefficientFileParameters(
            tempCFPathString,
            tempCFParametersList);
        if (status == QCOM_SUCCESS)
        {
            //----------------------------------------------------------------
            // Create a new window form
            //----------------------------------------------------------------
            displayNativeCFParametersWindow = gcnew Form;
            //----------------------------------------------------------------
            // Set its appearance
            //----------------------------------------------------------------
            displayNativeCFParametersWindow->MaximizeBox = GUI_NO;
            displayNativeCFParametersWindow->HelpButton = GUI_NO;
            displayNativeCFParametersWindow->Icon = QCOM_SoftwareIcon;
            displayNativeCFParametersWindow->BackgroundImage = whiteSandBackground;
            //----------------------------------------------------------------
            // Set the title, size, and border style
            //----------------------------------------------------------------
            displayNativeCFParametersWindow->Text = String::Concat(
                "Coefficient File Parameters from ",
                Path::GetDirectoryName(filePathString));
            displayNativeCFParametersWindow->Size = Drawing::Size(
                Max(QCOM_StringWidth(displayNativeCFParametersWindow->Text) + 440, 770),
                ((Max(numberOfPresLines, numberOfTempLines) * 20) + 70));
            displayNativeCFParametersWindow->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                10.0F,
                FontStyle::Regular);
            displayNativeCFParametersWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
            //----------------------------------------------------------------
            // Populate the two-column window with the strings
            //----------------------------------------------------------------
            for (int column = 0; column < 2; column++)
            {
                Label ^fileNameLabel = gcnew Label;
                fileNameLabel->Text = String::Concat(
                    "File name : ", nativeParameterFileNameList[column]->ToUpper());
                fileNameLabel->Location = Point(
                    (column * 430) + 10,
                    10);
                fileNameLabel->Size = Drawing::Size(420, GUI_INFO_LABEL_HEIGHT);
                fileNameLabel->BackColor = Color::Transparent;
                fileNameLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
                displayNativeCFParametersWindow->Controls->Add(fileNameLabel);
                if (column == 0)
                {
                    for (int lineNumber = 0; lineNumber < numberOfPresLines; lineNumber++)
                    {
                        Label ^CFLabel = gcnew Label;
                        CFLabel->Text = String::Format(
                            "{0} : {1}",
                            nativePresParameterFieldNameList[lineNumber],
                            presCFParametersList[lineNumber]);
                        CFLabel->Location = Point(
                            (column * 430) + 10,
                            (lineNumber * 20) + 14 + GUI_INFO_LABEL_HEIGHT);
                        CFLabel->Size = fileNameLabel->Size;
                        CFLabel->BackColor = Color::Transparent;
                        CFLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
                        displayNativeCFParametersWindow->Controls->Add(CFLabel);
                    }
                }
                else
                {
                    for (int lineNumber = 0; lineNumber < numberOfTempLines; lineNumber++)
                    {
                        Label ^CFLabel = gcnew Label;
                        CFLabel->Text = String::Format(
                            "{0} : {1}",
                            nativeTempParameterFieldNameList[lineNumber],
                            tempCFParametersList[lineNumber]);
                        CFLabel->Location = Point(
                            (column * 430) + 10,
                            (lineNumber * 20) + 14 + GUI_INFO_LABEL_HEIGHT);
                        CFLabel->Size = fileNameLabel->Size;
                        CFLabel->BackColor = Color::Transparent;
                        CFLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
                        displayNativeCFParametersWindow->Controls->Add(CFLabel);
                    }
                }
            }
            if (primaryDisplay)
            {
                //------------------------------------------------------------
                // Display hex file coefficients button
                //------------------------------------------------------------
                String ^hexCFPathString = String::Concat(
                    Path::GetDirectoryName(filePathString),
                    "\\",
                    Path::GetFileNameWithoutExtension(filePathString),
                    ".hex");
                if (File::Exists(hexCFPathString))
                {
                    Button ^hexFilesButton = gcnew Button;
                    hexFilesButton->Tag = dynamic_cast <Object ^> (hexCFPathString);
                    hexFilesButton->Text = _T("Display Hex\nCoefficient File");
                    hexFilesButton->Location = Point(
                        displayNativeCFParametersWindow->Right - 215,
                        displayNativeCFParametersWindow->Bottom - 77);
                    hexFilesButton->Size = Drawing::Size(
                        100,
                        GUI_DOUBLE_BUTTON_HEIGHT);
                    hexFilesButton->Font = gcnew Drawing::Font(
                        FontFamily::GenericSansSerif,
                        8.0F,
                        FontStyle::Regular);
                    GUI_SetButtonInterfaceProperties(hexFilesButton);
                    hexFilesButton->Click +=
                        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DisplayHexCFParametersButtonClicked);
                    displayNativeCFParametersWindow->Controls->Add(hexFilesButton);
                }
                delete hexCFPathString;
            }                           // end of if (primaryDisplay)
            //----------------------------------------------------------------
            // Add a Close button
            //----------------------------------------------------------------
            Button ^closeButton = gcnew Button;
            closeButton->Text = _T("Close");
            closeButton->Location = Point(
                displayNativeCFParametersWindow->Right - 100,
                displayNativeCFParametersWindow->Bottom - 70);
            closeButton->Size = Drawing::Size(
                GUI_CLOSE_BUTTON_WIDTH,
                GUI_REGULAR_BUTTON_HEIGHT);
            closeButton->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                8.0F,
                FontStyle::Regular);
            GUI_SetButtonInterfaceProperties(closeButton);
            closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
            closeButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DisplayNativeCFParametersCloseWindow);
            displayNativeCFParametersWindow->Controls->Add(closeButton);
            //----------------------------------------------------------------
            // Set the remaining window properties
            //----------------------------------------------------------------
            displayNativeCFParametersWindow->AcceptButton = closeButton;    // button when user presses Enter
            displayNativeCFParametersWindow->CancelButton = closeButton;    // button when user presses Esc
            //----------------------------------------------------------------
            // Finally, display the new window
            //----------------------------------------------------------------
            displayNativeCFParametersWindow->ShowDialog();
        }                               // end of if (status == QCOM_SUCCESS)
        else
        {
            GUI_DisplayGeneralErrorWithStatus(
                functionName,
                String::Format("QCOM_RetrieveCoefficientFileParameters(native) for\n{0}",
                    filePathString),
                status);
        }
        delete [] tempCFParametersList;
        delete [] presCFParametersList;
        delete [] nativeParameterCompleteFieldNameList;
        delete [] nativeParameterFileNameList;
        delete [] nativeTempParameterFieldNameList;
        delete [] nativePresParameterFieldNameList;
        delete tempCFPathString;
        delete presCFPathString;
    }                                   // end of if (StringSet(filePathString) && File::Exists(filePathString))
    else
    {
        if (StringSet(filePathString))
        {
            GUI_DisplaySimpleError(functionName,
                "File '{0}'\ncould not be found",
                filePathString);
        }
        else
        {
            GUI_DisplaySimpleError(functionName,
                "Invalid filename pointer");
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_DisplayNativeCFParameters()
//----------------------------------------------------------------------------
// QCOM_DisplayRawCoefficientData
//
// Displays only the coefficient data bytes for the specified location
//
// Called by:   QCOM_MiscDisplayRawModuleCoeffButtonClicked
//              QCOM_MiscDisplayRawXDCoeffButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayRawCoefficientData(
    UnitInfo        ^unit,
    BYTE            device)
{
    bool            allPagesIdentical = GUI_YES;
    bool            allDataValid = GUI_YES;
    char            *digit;
    char            *data;
    char            *dataCompareBuffer;
    DWORD           status;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_DisplayRawCoefficientData");
    //------------------------------------------------------------------------
    if (QCOM_UnitOpen(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        data = (char *) malloc(QD_BYTES_PER_QMEM_PAGE);
        dataCompareBuffer = (char *) malloc(QD_BYTES_PER_QMEM_PAGE);
        digit = (char *) malloc(1000);
        if (data && dataCompareBuffer && digit)
        {
            //----------------------------------------------------------------
            // Create a new window form
            //----------------------------------------------------------------
            displayRawCFDataWindowArray[unitNumber] = gcnew Form;
            //----------------------------------------------------------------
            // Set its appearance
            //----------------------------------------------------------------
            displayRawCFDataWindowArray[unitNumber]->MaximizeBox = GUI_NO;
            displayRawCFDataWindowArray[unitNumber]->HelpButton = GUI_NO;
            displayRawCFDataWindowArray[unitNumber]->TopMost = GUI_NO;
            //----------------------------------------------------------------
            // Set its icon
            //----------------------------------------------------------------
            displayRawCFDataWindowArray[unitNumber]->Icon = QCOM_SoftwareIcon;
            //----------------------------------------------------------------
            // Set the background image
            //----------------------------------------------------------------
            displayRawCFDataWindowArray[unitNumber]->BackgroundImage = gcnew
                Bitmap(GUI_BG_WHITE_SAND, GUI_YES);
            //----------------------------------------------------------------
            // Set the title, size, and border style
            //----------------------------------------------------------------
            String ^moduleTitle = unit->moduleSerialNumber;
            String ^snTitle = unit->transducerSerialNumber;
            String ^titlePrefix = _T("Raw Coefficient Data for ");
            if (unitNumber == QCOM_MAXIMUM_NUMBER_OF_UNITS)
            {
                if (QCOM_XDSNValid(unit))
                {
                    displayCFDataWindowArray[unitNumber]->Text = String::Concat(
                        titlePrefix, "Transducer ", snTitle);
                }
                else
                {
                    displayCFDataWindowArray[unitNumber]->Text = String::Concat(
                        titlePrefix, moduleTitle);
                }
            }
            else
            {
                if (device == QD_DEVICE_TRANSDUCER)
                {
                    displayRawCFDataWindowArray[unitNumber]->Text = String::Concat(
                        titlePrefix,
                        (QCOM_XDIsFrequency(unit) ?
                            "Frequency (Analog)" : "Digital"),
                        " Transducer ",
                        (QCOM_XDSNValid(unit) ? snTitle : String::Empty));
                    if (QCOM_ModuleSNValid(unit))
                    {
                        displayRawCFDataWindowArray[unitNumber]->Text = String::Concat(
                            displayRawCFDataWindowArray[unitNumber]->Text,
                            " attached to Module ", moduleTitle);
                    }
                }
                else
                {
                    displayRawCFDataWindowArray[unitNumber]->Text = String::Concat(
                        titlePrefix,
                        "Module ",
                        (QCOM_ModuleSNValid(unit) ? moduleTitle : String::Empty));
                }
            }
            delete titlePrefix;
            delete snTitle;
            delete moduleTitle;
            displayRawCFDataWindowArray[unitNumber]->Size = Drawing::Size(910, 854);
            displayRawCFDataWindowArray[unitNumber]->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                10.0F,
                FontStyle::Regular);
            displayRawCFDataWindowArray[unitNumber]->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
            //----------------------------------------------------------------
            // Add a Close button
            //----------------------------------------------------------------
            Button ^closeButton = gcnew Button;
            closeButton->Text = _T("Close");
            closeButton->Location = Point(
                displayRawCFDataWindowArray[unitNumber]->Right - 100,
                displayRawCFDataWindowArray[unitNumber]->Bottom - 70);
            closeButton->Size = Drawing::Size(
                GUI_CLOSE_BUTTON_WIDTH,
                GUI_REGULAR_BUTTON_HEIGHT);
            closeButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
            closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
            GUI_SetUnitObjectInterfaceProperties(
                closeButton,
                unitNumber);
            closeButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_CloseRawCFWindow);
            displayRawCFDataWindowArray[unitNumber]->Controls->Add(closeButton);
            //----------------------------------------------------------------
            // Display one set of raw data for each of the lower memory pages
            //----------------------------------------------------------------
            for (BYTE pageNumber = 0; pageNumber < QD_NUMBER_OF_LOWER_QMEM_PAGES; pageNumber++)
            {
                ClearBuffer(data, QD_BYTES_PER_QMEM_PAGE);
                status = QD_ReadCoefficientDataFromSourcePage(
                    unit->unitHandle,
                    device,
                    pageNumber,
                    (LPBYTE) data);
if (!status) ModalX("Disp CFData({0:D}:{1:D}) just read: {2:X2} {3:X2} {4:X2} {5:X2} {6:X2} {7:X2}",
    device, pageNumber, data[0], data[1], data[2], data[3], data[4], data[5]);
                if (status == QD_SUCCESS)
                {
                    if (pageNumber)
                    {
                        if (memcmp((void *) dataCompareBuffer, (void *) data, QD_BYTES_PER_QMEM_PAGE))
                            allPagesIdentical = GUI_NO;
                    }
                    else
                    {
                        memcpy((void *) dataCompareBuffer, (void *) data, QD_BYTES_PER_QMEM_PAGE);
                    }
                }
                else
                {
                    if (device == QD_DEVICE_TRANSDUCER)
                    {
                        GUI_DisplayErrorWithStatus(
                            functionName,
                            String::Concat("Error reading transducer memory page ", pageNumber),
                            unit,
                            status);
                    }
                    else
                    {
                        GUI_DisplayUnitErrorWithStatus(
                            functionName,
                            String::Concat("Error reading module memory page ", pageNumber),
                            unit,
                            status);
                    }
                    allDataValid = GUI_NO;
                }
                //------------------------------------------------------------
                // Prepare the data for display
                //------------------------------------------------------------
                for (int index = 0; index < 512; index++)
                {
                    if (index % 2)
                        digit[index] = (data[(index - 1) / 2] & 0x0F);
                    else
                        digit[index] = (((data[index / 2] & 0xF0) >> 4) & 0x0F);
                }
                //------------------------------------------------------------
                // Line 00
                //------------------------------------------------------------
                Label ^line00 = gcnew Label;
                line00->Text = _T("00  :");
                line00->Location = Point(10, ((pageNumber * 198) + 10));
                line00->Size = Drawing::Size(34, GUI_COEFFICIENT_LABEL_HEIGHT);
                line00->BackColor = Color::Transparent;
                Label ^list00 = gcnew Label;
                list00->Text = QCOM_BuildCoefficientDataLine(digit, 0);
                list00->Location = Point(line00->Right + 2, line00->Top);
                list00->Size = Drawing::Size(840, GUI_COEFFICIENT_LABEL_HEIGHT);
                list00->BackColor = Color::Transparent;
                list00->Font = gcnew Drawing::Font(
                    FontFamily::GenericMonospace,
                    10.0F,
                    FontStyle::Bold);
                //------------------------------------------------------------
                // Line 20
                //------------------------------------------------------------
                Label ^line20 = gcnew Label;
                line20->Text = _T("20  :");
                line20->Location = Point(line00->Left, line00->Bottom + 4);
                line20->Size = line00->Size;
                line20->BackColor = Color::Transparent;
                Label ^list20 = gcnew Label;
                list20->Text = QCOM_BuildCoefficientDataLine(digit, 1);
                list20->Location = Point(line00->Right + 2, line20->Top);
                list20->Size = list00->Size;
                list20->BackColor = Color::Transparent;
                list20->Font = gcnew Drawing::Font(
                    FontFamily::GenericMonospace,
                    10.0F,
                    FontStyle::Bold);
                //------------------------------------------------------------
                // Line 40
                //------------------------------------------------------------
                Label ^line40 = gcnew Label;
                line40->Text = _T("40  :");
                line40->Location = Point(line00->Left, line20->Bottom + 4);
                line40->Size = line00->Size;
                line40->BackColor = Color::Transparent;
                Label ^list40 = gcnew Label;
                list40->Text = QCOM_BuildCoefficientDataLine(digit, 2);
                list40->Location = Point(line00->Right + 2, line40->Top);
                list40->Size = list00->Size;
                list40->BackColor = Color::Transparent;
                list40->Font = gcnew Drawing::Font(
                    FontFamily::GenericMonospace,
                    10.0F,
                    FontStyle::Bold);
                //------------------------------------------------------------
                // Line 60
                //------------------------------------------------------------
                Label ^line60 = gcnew Label;
                line60->Text = _T("60  :");
                line60->Location = Point(line00->Left, line40->Bottom + 4);
                line60->Size = line00->Size;
                line60->BackColor = Color::Transparent;
                Label ^list60 = gcnew Label;
                list60->Text = QCOM_BuildCoefficientDataLine(digit, 3);
                list60->Location = Point(line00->Right + 2, line60->Top);
                list60->Size = list00->Size;
                list60->BackColor = Color::Transparent;
                list60->Font = gcnew Drawing::Font(
                    FontFamily::GenericMonospace,
                    10.0F,
                    FontStyle::Bold);
                //------------------------------------------------------------
                // Line 80
                //------------------------------------------------------------
                Label ^line80 = gcnew Label;
                line80->Text = _T("80  :");
                line80->Location = Point(line00->Left, line60->Bottom + 4);
                line80->Size = line00->Size;
                line80->BackColor = Color::Transparent;
                Label ^list80 = gcnew Label;
                list80->Text = QCOM_BuildCoefficientDataLine(digit, 4);
                list80->Location = Point(line00->Right + 2, line80->Top);
                list80->Size = list00->Size;
                list80->BackColor = Color::Transparent;
                list80->Font = gcnew Drawing::Font(
                    FontFamily::GenericMonospace,
                    10.0F,
                    FontStyle::Bold);
                //------------------------------------------------------------
                // Line A0
                //------------------------------------------------------------
                Label ^lineA0 = gcnew Label;
                lineA0->Text = _T("A0  :");
                lineA0->Location = Point(line00->Left, line80->Bottom + 4);
                lineA0->Size = line00->Size;
                lineA0->BackColor = Color::Transparent;
                Label ^listA0 = gcnew Label;
                listA0->Text = QCOM_BuildCoefficientDataLine(digit, 5);
                listA0->Location = Point(line00->Right + 2, lineA0->Top);
                listA0->Size = list00->Size;
                listA0->BackColor = Color::Transparent;
                listA0->Font = gcnew Drawing::Font(
                    FontFamily::GenericMonospace,
                    10.0F,
                    FontStyle::Bold);
                //------------------------------------------------------------
                // Line C0
                //------------------------------------------------------------
                Label ^lineC0 = gcnew Label;
                lineC0->Text = _T("C0  :");
                lineC0->Location = Point(line00->Left, lineA0->Bottom + 4);
                lineC0->Size = line00->Size;
                lineC0->BackColor = Color::Transparent;
                Label ^listC0 = gcnew Label;
                listC0->Text = QCOM_BuildCoefficientDataLine(digit, 6);
                listC0->Location = Point(line00->Right + 2, lineC0->Top);
                listC0->Size = list00->Size;
                listC0->BackColor = Color::Transparent;
                listC0->Font = gcnew Drawing::Font(
                    FontFamily::GenericMonospace,
                    10.0F,
                    FontStyle::Bold);
                //------------------------------------------------------------
                // Line E0
                //------------------------------------------------------------
                Label ^lineE0 = gcnew Label;
                lineE0->Text = _T("E0  :");
                lineE0->Location = Point(line00->Left, lineC0->Bottom + 4);
                lineE0->Size = line00->Size;
                lineE0->BackColor = Color::Transparent;
                Label ^listE0 = gcnew Label;
                listE0->Text = QCOM_BuildCoefficientDataLine(digit, 7);
                listE0->Location = Point(line00->Right + 2, lineE0->Top);
                listE0->Size = list00->Size;
                listE0->BackColor = Color::Transparent;
                listE0->Font = gcnew Drawing::Font(
                    FontFamily::GenericMonospace,
                    10.0F,
                    FontStyle::Bold);
                //------------------------------------------------------------
                // Add all the string labels to the form control
                //------------------------------------------------------------
                array <Label ^> ^coefficientLabels =
                {
                    line00,     list00,     line20,     list20,
                    line40,     list40,     line60,     list60,
                    line80,     list80,     lineA0,     listA0,
                    lineC0,     listC0,     lineE0,     listE0
                };
                displayRawCFDataWindowArray[unitNumber]->Controls->AddRange(coefficientLabels);
            }                           // end of for (BYTE pageNumber = 0; ...)
            //----------------------------------------------------------------
            // Display whether all the pages are identical
            //----------------------------------------------------------------
            Label ^identicalPagesLabel = gcnew Label;
            String ^memoryResult =
                (allDataValid ?
                    String::Concat((allPagesIdentical ? QCOM_STRING_SPACE : _T(" not ")), _T("identical")) :
                    _T(" invalid"));
            identicalPagesLabel->Text = String::Concat(
                "The four ",
                ((device == QD_DEVICE_TRANSDUCER) ? "transducer" : "module"),
                " memory pages are",
                memoryResult);
            identicalPagesLabel->Location = Point(
                10,
                displayRawCFDataWindowArray[unitNumber]->Bottom - 68);
            identicalPagesLabel->Size = Drawing::Size(400, GUI_COEFFICIENT_LABEL_HEIGHT);
            identicalPagesLabel->BackColor = Color::Transparent;
            identicalPagesLabel->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                10.0F,
                FontStyle::Bold);
            displayRawCFDataWindowArray[unitNumber]->Controls->Add(identicalPagesLabel);
            //----------------------------------------------------------------
            // Set the remaining window properties
            //----------------------------------------------------------------
            displayRawCFDataWindowArray[unitNumber]->AcceptButton = closeButton; // button when user presses Enter
            displayRawCFDataWindowArray[unitNumber]->CancelButton = closeButton; // button when user presses Esc
            //----------------------------------------------------------------
            // Finally, display the new window
            //----------------------------------------------------------------
            displayRawCFDataWindowArray[unitNumber]->ShowDialog();
            free((void *) digit);
            free((void *) dataCompareBuffer);
            free((void *) data);
            RecordBasicEvent("{0} concluded", functionName);
        }                               // end of if (data && dataCompareBuffer && ...)
        else
        {
            GUI_DisplayMandatoryError(functionName,
                "Unable to allocate the necessary buffers");
        }
    }                                   // end of if (QCOM_UnitOpen(unit))
    else
    {
        if (QCOM_UnitValid(unit))
        {
            RecordErrorEvent("{0} called, but unit {1:D} is not open",
                functionName, unit->unitNumber);
        }
        else
        {
            RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
        }
    }
}                                       // end of QCOM_DisplayRawCoefficientData()
//----------------------------------------------------------------------------
// QCOM_DisplayTCCheck
//
// Displays the Transducer Coefficient Check website
//
// Called by:   QCOM_UtilDisplayTCCheckButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayTCCheck(
    UnitInfo        ^unit)
{
    bool            calDirLocated;
    bool            calFileLocated = GUI_NO;
    bool            transducerWithMemory;
    int             lineNumber;
    int             pressureOrder;
    int             temperatureOrder;
    double          digitalPressureFrequency;
    double          digitalPressureValue;
    double          digitalTemperatureFrequency;
    double          digitalTemperatureValue;
    double          filePressureFrequency;
    double          filePressureValue;
    double          fileTemperatureFrequency;
    double          fileTemperatureValue;
    BYTE            memoryType = QD_MEMORY_TYPE_ABSENT;
    String          ^memType = QCOM_STRING_NA;
    String          ^XDwithMemory = _T("yes");
    String          ^functionName = _T("QCOM_DisplayTCCheck");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        if (QCOM_InternetIsAvailable())
        {
            transducerWithMemory =
                (QCOM_XDIsFrequency(unit) || QCOM_XDIsDigitalNoMem(unit)) ?
                    GUI_NO : GUI_YES;
            //----------------------------------------------------------------
            // Retrieve the values based on coefficients already stored in
            // digital transducer memory
            //----------------------------------------------------------------
            if (transducerWithMemory)
            {
                QD_GetMemoryType(
                    unit->unitHandle,
                    QD_DEVICE_TRANSDUCER,
                    (LPBYTE) &memoryType);
                switch (memoryType)
                {
                    case QD_MEMORY_TYPE_ABSENT : memType = QCOM_STRING_NONE;
                        break;
                    case QD_MEMORY_TYPE_FRAM : memType = _T("FRAM");
                        break;
                    case QD_MEMORY_TYPE_EEPROM : memType = _T("EEPROM");
                        break;
                    default : memType = QCOM_STRING_UNKNOWN;
                        break;
                }
            }
            else
            {
                XDwithMemory = _T("no");
                if (QCOM_XDIsDigitalNoMem(unit))
                {
                    memType = QCOM_STRING_NONE;
                }
            }
            QCOM_RetrieveTransducerReadings(unit);
            digitalPressureFrequency =
                ((double) unit->pressureCount) * QCOM_FREQUENCY_MULTIPLIER;
            digitalTemperatureFrequency =
                ((double) unit->temperatureCount) * QCOM_FREQUENCY_MULTIPLIER;
            digitalPressureValue = unit->pressureValuePSI;
            digitalTemperatureValue = unit->temperatureValueCelsius;
                //------------------------------------------------------------
                // Search for the transducer's calibration directory
                //------------------------------------------------------------
            QCOM_PleaseWait(
                GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
                "Searching for Transducer {0} Coefficients",
                unit->transducerSerialNumber);
            String ^calFileString = QCOM_STRING_UNKNOWN;
            StringBuilder ^calFileBuilder =
                gcnew StringBuilder(calFileString, QCOM_MAXIMUM_FILE_PATH_LENGTH);
            calDirLocated = QCOM_SearchForCoefficientFile(
                unit->transducerSerialNumber,
                calFileBuilder);
            calFileString = calFileBuilder->ToString();
            delete calFileBuilder;
            Thread::Sleep(100);
            QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
            Thread::Sleep(100);
            if (calDirLocated)
            {
                //------------------------------------------------------------
                // The appropriate coefficient file has been located in its
                // calibration directory, so import the coefficients
                //------------------------------------------------------------
                QCOM_ImportCoefficientDataFromFile(unit, calFileString);
                //------------------------------------------------------------
                // Locate the full part number by searching the c*f file(s)
                //------------------------------------------------------------
                calFileString = calFileString->Replace(
                    Path::GetExtension(calFileString), ".crf");
                if (File::Exists(calFileString))
                {
                    calFileLocated = GUI_YES;
                }
                else
                {
                    calFileString = calFileString->Replace(
                        Path::GetExtension(calFileString), ".cff");
                    if (File::Exists(calFileString))
                    {
                        calFileLocated = GUI_YES;
                    }
                }
                if (calFileLocated)
                {
                    String ^lineString;
                    StreamReader ^textReader = File::OpenText(calFileString);
                    if (textReader)
                    {
                        //----------------------------------------------------
                        // Skip to line 4 and retrieve the temperature
                        // polynomial order
                        //----------------------------------------------------
                        lineNumber = 4;
                        while (lineNumber--)
                        {
                            lineString = textReader->ReadLine()->Trim();
                        }
                        temperatureOrder = AtoX(lineString[0]);
                        //----------------------------------------------------
                        // Skip to line 8 (4 more) and retrieve the pressure
                        // polynomial order
                        //----------------------------------------------------
                        lineNumber = 4;
                        while (lineNumber--)
                        {
                            lineString = textReader->ReadLine()->Trim();
                        }
                        pressureOrder = AtoX(lineString[0]);
                        //----------------------------------------------------
                        // Skip to line 19 + (NT + 1) * (NP + 1) and retrieve
                        // the part / model number
                        //----------------------------------------------------
                        lineNumber = 11 + ((temperatureOrder + 1) * (pressureOrder + 1));
                        while (lineNumber--)
                        {
                            lineString = textReader->ReadLine()->Trim();
                        }
                        unit->transducerPartNumber = lineString;
                        textReader->Close();
                    }
                }                       // end of if (calFileLocated)
            }                           // end of if (calDirLocated)
            //----------------------------------------------------------------
            // Retrieve the values based on a coefficient file
            //----------------------------------------------------------------
            QCOM_RetrieveTransducerReadings(unit);
            filePressureFrequency =
                ((double) unit->pressureCount) * QCOM_FREQUENCY_MULTIPLIER;
            fileTemperatureFrequency =
                ((double) unit->temperatureCount) * QCOM_FREQUENCY_MULTIPLIER;
            filePressureValue = unit->pressureValuePSI;
            fileTemperatureValue = unit->temperatureValueCelsius;
            //----------------------------------------------------------------
            // Build the URL command line
            //----------------------------------------------------------------
            String ^url = String::Concat(
                QCOM_TC_CHECK_URL,
                _T("?serialNumber="), unit->transducerSerialNumber,
                _T("&partNumber="), unit->transducerPartNumber,
                _T("&calDir="), calFileString,
                _T("&digital="), XDwithMemory,
                String::Format("&fpValue={0:F4}&ftValue={1:F4}&fpFreq={2:F3}&ftFreq={3:F3}",
                    filePressureValue,
                    fileTemperatureValue,
                    filePressureFrequency,
                    fileTemperatureFrequency),
                String::Format("&dpValue={0:F4}&dtValue={1:F4}&dpFreq={2:F3}&dtFreq={3:F3}",
                    digitalPressureValue,
                    digitalTemperatureValue,
                    digitalPressureFrequency,
                    digitalTemperatureFrequency),
                _T("&memoryType="), memType);
            //----------------------------------------------------------------
            // Invoke the browser
            //----------------------------------------------------------------
            System::Diagnostics::Process::Start(url);
            delete url;
            delete calFileString;
        }                               // end of if (QCOM_InternetIsAvailable())
        else
        {
            QCOM_PromptOKModal(functionName,
                "The internet is unavailable at the moment");
        }
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_DisplayTCCheck()
//----------------------------------------------------------------------------
// QCOM_EraseCoefficientDataFromDevice
//
// Zeroes out the entire coefficient data in the device's memory
//
// Called by:   QCOM_ExpertEraseCoefficientDataButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_EraseCoefficientDataFromDevice(
    UnitInfo        ^unit)
{
    bool            currentlySampling;
    bool            currentlyTesting;
    bool            proceedToErase;
    LPBYTE          coefficientData;
    DWORD           status;
    String          ^functionName = _T("QCOM_EraseCoefficientDataFromDevice");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        currentlySampling = QCOM_QueryStopSampling(
            "Coefficient data cannot be modified during transducer sampling.");
        currentlyTesting = QCOM_QueryStopTesting(
            "Coefficient data cannot be modified while tests are running.");
        if (!currentlySampling && !currentlyTesting)
        {
            proceedToErase = QCOM_PromptModal(
                "Erase Coefficient Data",
                "Erase the coefficients from device memory ?");
            if (proceedToErase)
            {
                coefficientData = (LPBYTE) malloc(sizeof(CoefficientFormatDef));
                if (coefficientData)
                {
                    ClearBuffer(coefficientData, sizeof(CoefficientFormatDef));
                    status = QD_WriteCoefficientDataToDevice(
                        unit->unitHandle,
                        coefficientData);
                    if (status == QD_SUCCESS)
                    {
                        QCOM_PromptOKModal(
                            "Erase Coefficient Data",
                            "Coefficient data successfully erased");
                        unit->flags &=
                            ~QCOM_UNIT_COEFFICIENTS_VERIFIED;
                        ClearBuffer(unit->coefficientData, sizeof(CoefficientFormatDef));
                        QCOM_ApplyCoefficientDataInfoToProgram(unit);
                        QCOM_UpdateReadout(unit);
                    }
                    else
                    {
                        GUI_DisplayErrorWithStatus(
                            "Erase Coefficient Data From Device",
                            "QD_WriteCoefficientDataToDevice",
                            unit,
                            status);
                    }
                    free((void *) coefficientData);
                }
            }                           // end of if (proceedToErase)
        }                               // end of if (!currentlySampling)
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unit->unitNumber);
    }
}                                       // end of QCOM_EraseCoefficientDataFromDevice()
//----------------------------------------------------------------------------
// QCOM_ExportCoefficientDataToFile
//
// Saves the coefficient data of the specified unit or transducer to file
//
// Called by:   QCOM_ExportCoefficientDataFileButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExportCoefficientDataToFile(
    UnitInfo        ^unit)
{
    bool            currentlySampling;
    bool            currentlyTesting;
    bool            promptResult = GUI_CANCEL;
    char            *coefficientFilePath;
    DWORD           status;
    String          ^functionName = FunctionName();
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        currentlySampling = QCOM_QueryStopSampling(
            "Coefficient data cannot be exported during transducer sampling.");
        currentlyTesting = QCOM_QueryStopTesting(
            "Coefficient data cannot be exported while tests are running.");
        if (!currentlySampling && !currentlyTesting)
        {
            //----------------------------------------------------------------
            // If the current unit doesn't have a data file path specified,
            // determine whether another unit does, and copy that one, to save
            // the user from having to possibly drill down to the same directory
            //----------------------------------------------------------------
            if (!QCOM_CFKnown(unit))
            {
                for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
                {
                    if (QCOM_UnitNumberValid(unitNumber))
                    {
                        if (QCOM_UnitInfoArray[unitNumber]->flags & QCOM_UNIT_COEFFICIENT_FILE_SPECIFIED)
                        {
                            unit->coefficientFilePath = QCOM_UnitInfoArray[unitNumber]->coefficientFilePath;
                            break;
                        }
                    }
                    else
                    {
                        QCOM_RecordAndModalErrorEvent(
                            "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                            functionName, unitNumber, QCOM_CurrentNumberOfUnits);
                    }
                }
            }
            do
            {
                StringBuilder ^coefficientPathBuilder = gcnew StringBuilder(
                    unit->coefficientFilePath,
                    QCOM_MAXIMUM_FILE_PATH_LENGTH);
                promptResult = QCOM_PromptForSaveFile(
                    String::Format(
                        "Export Coefficient Data File for Transducer {0} Module {1}",
                        (QCOM_XDSNValid(unit) ?
                            unit->transducerSerialNumber : "on"),
                            unit->moduleSerialNumber),
                    coefficientPathBuilder,
                    unit->transducerSerialNumber,
                    GUI_FILE_TYPE_HEX);
                unit->coefficientFilePath = coefficientPathBuilder->ToString();
                delete coefficientPathBuilder;
                if (promptResult)
                {
                    status = QD_ReadCoefficientDataFromDevice(
                        unit->unitHandle,
                        (LPBYTE) unit->coefficientData);
                }
            }
            while ((status != QCOM_SUCCESS) && (promptResult == GUI_ACCEPT));
            if ((promptResult == GUI_ACCEPT) &&
                StringSet(unit->coefficientFilePath) &&
                (status == QCOM_SUCCESS))
            {
                unit->flags |= QCOM_UNIT_COEFFICIENT_FILE_SPECIFIED;
            }
            if (QCOM_CFKnown(unit) && (status == QCOM_SUCCESS))
            {
                coefficientFilePath = (char *) malloc(QCOM_MAXIMUM_FILE_PATH_LENGTH);
                if (coefficientFilePath)
                {
                    QCOM_ConvertString(
                        unit->coefficientFilePath,
                        coefficientFilePath,
                        QCOM_MAXIMUM_FILE_PATH_LENGTH);
                    status = QD_WriteCoefficientDataToHexFile(
                        (LPBYTE) unit->coefficientData,
                        (LPBYTE) coefficientFilePath);
                    if (status == QD_SUCCESS)
                    {
                        ModalB("Coefficient data successfully exported to\n{0}",
                            unit->coefficientFilePath);
                    }
                    else
                    {
                        GUI_DisplayErrorWithStatus(
                            "Export Coefficient Data To File",
                            "QD_WriteCoefficientDataToHexFile",
                            unit,
                            status);
                    }
                    free((void *) coefficientFilePath);
                }
            }
//            else
//            {
//                ModalD("QD_ReadCoefficientDataFromDevice returned status 0x{0:X8}", status);
//            }
        }
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_ExportCoefficientDataToFile()
//----------------------------------------------------------------------------
// QCOM_ImportCoefficientDataFromFile
//
// Retrieves coefficient data from the file specified in filePath and stores
// it in host memory for the specified unit or transducer
//
// Called by:   QCOM_CheckForTransducerCoefficientData
//              QCOM_DisplayTCCheck
//              QCOM_PromptForImportCoefficientDataFromFile
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_ImportCoefficientDataFromFile(
    UnitInfo        ^unit,
    String          ^filePathString)
{
    bool            dataImported = GUI_NO;
    bool            promptResult = GUI_ACCEPT;
    DWORD           status = QCOM_SUCCESS;
    CoefficientFormatDef
                    *coefficientData;
    CoefficientFormatDef
                    *format;
    String          ^functionName = _T("QCOM_ImportCoefficientDataFromFile");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit) && StringSet(filePathString))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (File::Exists(filePathString))
        {
            coefficientData = (CoefficientFormatDef *) malloc(sizeof(CoefficientFormatDef));
            if (coefficientData)
            {
                status = QCOM_ReadCoefficientDataFromFile(
                    filePathString,
                    coefficientData);
                if (status == QCOM_SUCCESS)
                {
                    format = coefficientData;
                    if (memcmp(&format->coefficients1[96], "Test", 4) == 0)
                    {
                        RecordBasicEvent("{0}({1:D}) :\nImport file is a test file\n'{2}'",
                            functionName, unit->unitNumber, filePathString);
                        promptResult = QCOM_PromptModal(
                            "Test Coefficient Data File",
                            "The selected coefficient data file is used only for testing.\n"
                            "Import it anyway ?");
                    }
                    if (promptResult == GUI_ACCEPT)
                    {
                        unit->coefficientFilePath = filePathString;
                        unit->flags |= QCOM_UNIT_COEFFICIENT_FILE_SPECIFIED;
                        memcpy(
                            unit->coefficientData,
                            coefficientData,
                            sizeof(CoefficientFormatDef));
                        QCOM_ApplyCoefficientDataInfoToProgram(unit);
                        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
                        dataImported = GUI_YES;
                    }
                }
                else
                {
                    QCOM_RecordAndModalErrorEvent(
                        "QCOM_ReadCoefficientDataFromFile returned status 0x{0:X8} while analyzing file\n{1}",
                        status,
                        filePathString);
                }
                free((void *) coefficientData);
            }
            else
            {
                QCOM_RecordAndModalErrorEvent(
                    "{0}({1:D}) : Memory allocation attempt failed",
                    functionName, unit->unitNumber);
            }
        }                               // end of if (File::Exists(filePathString))
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0}({1:D}) : File is not found:\n{2}",
                functionName, unit->unitNumber, filePathString);
        }
    }                                   // end of if (QCOM_UnitValid(unit) && ...)
    else
    {
        if (QCOM_UnitValid(unit))
        {
            QCOM_RecordAndModalErrorEvent(
                "{0}({1:D}) : Called with an invalid file path string parameter",
                functionName, unit->unitNumber);
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0} called with an invalid unit pointer", functionName);
        }
    }
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (dataImported ? "Imported" : "Rejected"));
    return dataImported;
}                                       // end of QCOM_ImportCoefficientDataFromFile()
//----------------------------------------------------------------------------
// QCOM_InstallMultipleCoefficientWindows
//
// Installs the graphing windows
//
// Called by:   QCOM_InstallUtilities
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InstallMultipleCoefficientWindows(void)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_InstallMultipleCoefficientWindows");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_SetUpUnitMultipleCoefficientWindow(unit);
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_InstallMultipleCoefficientWindows()
//----------------------------------------------------------------------------
// QCOM_InterpretCoefficientData
//
// Parses select fields of the coefficient data for the specified transducer
// and copies the applicable information to the appropriate transducer fields
//
// Note:    The coefficient data is not checked completely for validity, so it's
//          possible to process an all-zero data set, but the transducer serial
//          number is checked for a nonzero value, in order to set the
//          QCOM_UNIT_TRANSDUCER_SN_VALID flag
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InterpretCoefficientData(
    UnitInfo        ^unit)
{
    CoefficientFormatDef
                    *format;
    String          ^functionName = _T("QCOM_InterpretCoefficientData");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        format = unit->coefficientData;
        char *transducerSerialNumber = (char *) malloc(QCOM_MAXIMUM_SERIAL_NUMBER_SIZE);
        if (transducerSerialNumber)
        {
            int numericValue = QCOM_ExtractSerialNumberFromCoefficientData(
                format,
                transducerSerialNumber);
            unit->transducerSerialNumber = gcnew String(transducerSerialNumber, 0, 6);
            if (unit->flags & QCOM_UNIT_TRANSDUCER_PRESENT)
            {
                ModuleTransducerPair ^unitPair = QCOM_ModuleTransducerPairArray[unit->unitNumber];
                if (unitPair)
                {
                    unitPair->newTransducerSerialNumber = unit->transducerSerialNumber;
                }
            }
            if (numericValue)
            {
                unit->flags |= QCOM_UNIT_TRANSDUCER_SN_VALID;
            }
            //----------------------------------------------------------------
            // Because the maximum temperature value is stored in integer
            // multiples of 5 degrees, the temperature value for transducers
            // whose maximum rated temperature is specifically 177 �C is
            // stored as 35, which corresponds to 175 �C, so set it to exactly
            // 177 when a value of 175 is encountered
            //----------------------------------------------------------------
            DWORD actualTemperature = format->maximumTemperature * 5;
            if (actualTemperature == 175)
                actualTemperature = 177;
            unit->transducerPartNumber = String::Concat(
                gcnew String(format->partNumber, 0, Min(strlen(format->partNumber), 8)),
                _T("-"),
                ((format->maximumPressure < 10) ? String::Concat(_T("0"), format->maximumPressure) : String::Concat(format->maximumPressure)),
                _T("-"),
                ((actualTemperature < 100) ? String::Concat(_T("C"), actualTemperature) : String::Concat(actualTemperature)));
            RecordVerboseEvent(
                "    Coefficient data for module {0} identified by transducer serial number {1}",
                unit->moduleSerialNumber,
                unit->transducerSerialNumber);
            free((void *) transducerSerialNumber);
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_InterpretCoefficientData()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientModuleClearSlot
//
// Handles the click of the unit multiple coefficient storage module
// Clear button
//
// Called by:   QCOM_MultipleCoefficientModuleClearButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientModuleClearSlot(
    UnitInfo        ^unit,
    BYTE            slotNumber)
{
    String          ^functionName = _T("QCOM_MultipleCoefficientModuleClearSlot");
    //------------------------------------------------------------------------
    if (unit)
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D} slot {2:D}) called",
            functionName, unitNumber, slotNumber);
        LPBYTE zeroData = (LPBYTE) malloc(QCOM_COEFFICIENT_DATA_SIZE);
        if (zeroData)
        {
            ClearBuffer(zeroData, QCOM_COEFFICIENT_DATA_SIZE);
            for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot);
                pageNumber < ((slotNumber + 1) * QCOM_CurrentPagesPerMemorySlot);
                pageNumber++)
            {
                DWORD status = QD_WriteCoefficientDataToTargetPage(
                    unit->unitHandle,
                    QD_DEVICE_MODULE,                                           // 1
                    pageNumber,
                    zeroData);
                if (status == QD_SUCCESS)
                {
                }
                else
                {
                    RecordErrorEvent("    {0} : QD_WriteCoefficientDataToTargetPage(module, page {1:D}) returned 0x{2:X8}",
                        functionName, pageNumber, status);
                }
                Thread::Sleep(100);
            }                           // end of for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot); ...)
            QCOM_UpdateMultipleCoefficientWindow(unit);
            free((void *) zeroData);
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_MultipleCoefficientModuleClearSlot()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientModuleCopyToTransducer
//
// Copies the coefficient data from the specified module to its transducer
//
// Called by:   QCOM_MultipleCoefficientModuleCopyButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientModuleCopyToTransducer(
    UnitInfo        ^unit,
    BYTE            slotNumber)
{
    String          ^functionName = _T("QCOM_MultipleCoefficientModuleCopyToTransducer");
    //------------------------------------------------------------------------
    if (unit)
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        if (!QCOM_XDIsFrequency(unit) && !QCOM_XDIsDigitalNoMem(unit))
        {
            LPBYTE coefficientData = (LPBYTE) malloc(QCOM_COEFFICIENT_DATA_SIZE);
            if (coefficientData)
            {
                for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot);
                    pageNumber < ((slotNumber + 1) * QCOM_CurrentPagesPerMemorySlot);
                    pageNumber++)
                {
                    ClearBuffer(coefficientData, QCOM_COEFFICIENT_DATA_SIZE);
                    //--------------------------------------------------------
                    // Retrieve the coefficient data stored in the module
                    //--------------------------------------------------------
                    DWORD status = QD_ReadCoefficientDataFromSourcePage(
                        unit->unitHandle,
                        QD_DEVICE_MODULE,                                       // 1
                        pageNumber,
                        coefficientData);
                    if ((status == QD_SUCCESS) ||
                        ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA)) // 0x00000040
                    {
                        //----------------------------------------------------
                        // Store the coefficient data in the transducer
                        //----------------------------------------------------
                        status = QD_WriteCoefficientDataToTargetPage(
                            unit->unitHandle,
                            QD_DEVICE_TRANSDUCER,                               // 0
                            pageNumber,
                            coefficientData);
                        if (status == QD_SUCCESS)
                        {
                        }
                        else
                        {
                            RecordErrorEvent("    {0} : QD_WriteCoefficientDataToTargetPage(transducer, page {1:D}) returned 0x{2:X8}",
                                functionName, pageNumber, status);
                        }
                    }                   // end of if ((status == QD_SUCCESS) || ...)
                    else
                    {
                        RecordErrorEvent("    {0} : QD_ReadCoefficientDataFromSourcePage(module, page {1:D}) returned 0x{2:X8}",
                            functionName, pageNumber, status);
                    }
                    Thread::Sleep(100);
                }                       // end of for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot); ...)
                QCOM_UpdateMultipleCoefficientWindow(unit);
                free((void *) coefficientData);
            }                           // end of if (coefficientData)
            else
            {
                GUI_DisplayMandatoryError(functionName,
                    "Unable to allocate the necessary buffers");
            }
        }                               // end of if (!QCOM_XDIsFrequency(unit) && !QCOM_XDIsDigitalNoMem(unit))
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_MultipleCoefficientModuleCopyToTransducer()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientModuleLoadSlot
//
// Prompts for a coefficient data file to load in a module slot
//
// Called by:   QCOM_MultipleCoefficientModuleUpdateButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientModuleLoadSlot(
    UnitInfo        ^unit,
    BYTE            slotNumber)
{
    bool            browseForFiles = GUI_NO;
    bool            dbFileFound = GUI_NO;
    bool            fileLocated = GUI_NO;
    String          ^coefficientFilePathString;
    String          ^dbPathString = QUARTZDYNE_CONFIDENTIAL_ROOT QUARTZDYNE_CALSUM_DB_FILE_PATH;
    String          ^transducerSearchString;
    String          ^functionName = _T("QCOM_MultipleCoefficientModuleLoadSlot");
    //------------------------------------------------------------------------
    if (unit)
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D} slot {2:D}) called",
            functionName, unitNumber, slotNumber);
        //--------------------------------------------------------------------
        // Search the network, if present, for the CALSUM database file
        //--------------------------------------------------------------------
        if (File::Exists(dbPathString))
        {
            dbFileFound = GUI_YES;
        }
        else
        {
            array <DriveInfo ^> ^driveInfo = DriveInfo::GetDrives();
            for each (DriveInfo ^oneDrive in driveInfo)
            {
                if (oneDrive->DriveType == DriveType::Network)
                {
                    dbPathString = String::Concat(
                        oneDrive->Name,
                        QUARTZDYNE_CALSUM_DB_FILE_PATH);
                    if (File::Exists(dbPathString))
                    {
                        dbFileFound = GUI_YES;
                    }
                }
            }
        }
        if (dbFileFound)
        {
            bool proceedToSearchDB = QCOM_PromptYesNoModal(
                "Search or Browse",
                "Search", "Browse...",
                "Search the database, or browse for a\n"
                "coefficient data file ?");
            if (QCOM_ModalKeyStroke == GUI_KEY_ESC)
            {
                browseForFiles = GUI_NO;
            }
            else
            {
                if (proceedToSearchDB)
                {
                    bool proceedToImport = GUI_YES;
                    bool inputResponse = GUI_ACCEPT;
                    bool inputValid = GUI_NO;
                    do
                    {
                        inputValid = GUI_YES;
                        if (proceedToImport)
                        {
                            DWORD transducerSerialNumber = 0;
                            StringBuilder ^transducerSearchBuilder =
                                gcnew StringBuilder(QCOM_MAXIMUM_SEARCH_STRING_SIZE);
                            inputResponse = QCOM_PromptInputModal(
                                "Transducer Serial Number",
                                QCOM_GeneralInfo->searchString,
                                &transducerSerialNumber,
                                transducerSearchBuilder,
                                QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH,
                                "Enter the transducer serial number to search for");
                            transducerSearchString = transducerSearchBuilder->ToString();
                            delete transducerSearchBuilder;
                            if (inputResponse == GUI_ACCEPT)
                            {
                                if (StringSet(transducerSearchString) && transducerSerialNumber)
                                {
                                    if (transducerSerialNumber < 10000)
                                        inputValid = GUI_NO;
                                    if (transducerSearchString->Length < (QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH - 1))
                                        inputValid = GUI_NO;
                                    if (inputValid)
                                    {
                                        QCOM_GeneralInfo->searchString = transducerSearchString;
                                    }
                                    else
                                    {
                                        GUI_DisplayMandatoryError(functionName,
                                            "'{0}' is not a valid transducer serial number",
                                            transducerSearchString);
                                    }
                                }
                                else
                                {
                                    browseForFiles = GUI_YES;
                                }
                            }
                        }
                    }
                    while ((inputResponse == GUI_ACCEPT) && (!inputValid));
                    if ((inputResponse == GUI_ACCEPT) && inputValid)
                    {
                        proceedToImport = GUI_YES;
                        browseForFiles = GUI_NO;
                        //----------------------------------------------------
                        // Search the database
                        //----------------------------------------------------
                        QCOM_PleaseWait(
                            GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
                            "Searching for Transducer {0} Coefficient File",
                            transducerSearchString);
                        StringBuilder ^filePathBuilder =
                            gcnew StringBuilder(QCOM_MAXIMUM_FILE_PATH_LENGTH);
                        fileLocated = QCOM_SearchForCoefficientFile(
                            transducerSearchString,
                            filePathBuilder);
                        coefficientFilePathString = filePathBuilder->ToString();
                        delete filePathBuilder;
                        QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
                        Thread::Sleep(100);
                    }
                }
                else
                {
                    browseForFiles = GUI_YES;
                }
            }                           // end of else of if (QCOM_ModalKeyStroke == GUI_KEY_ESC)
        }
        else
        {
            browseForFiles = GUI_YES;
        }
        if (browseForFiles)
        {
            if (QCOM_GeneralInfo->flags & QCOM_GENERAL_USE_PATH_SPECIFIED)
                coefficientFilePathString = QCOM_GeneralInfo->generalUsePath;
            else
                coefficientFilePathString = Environment::GetFolderPath(Environment::SpecialFolder::Recent);
            bool promptResult = GUI_ACCEPT;
            do
            {
                StringBuilder ^coefficientFilePathBuilder = gcnew StringBuilder(
                    coefficientFilePathString,
                    QCOM_MAXIMUM_FILE_PATH_LENGTH);
                promptResult = QCOM_PromptForReadFile(
                    String::Format(
                        "Import Coefficient Data File for Transducer on Module {0}",
                        unit->moduleSerialNumber),
                    coefficientFilePathBuilder,
                    nullptr,
                    GUI_FILE_TYPE_HEX_NATIVE_REF);
                coefficientFilePathString = coefficientFilePathBuilder->ToString();
                delete coefficientFilePathBuilder;
                if (promptResult == GUI_ACCEPT)
                {
                    fileLocated = GUI_YES;
                }
            }
            while (!fileLocated && (promptResult == GUI_ACCEPT));
        }                               // end of if (browseForFiles)
        if (fileLocated)
        {
            LPBYTE coefficientData = (LPBYTE) malloc(QCOM_COEFFICIENT_DATA_SIZE);
            if (coefficientData)
            {
                ClearBuffer(coefficientData, QCOM_COEFFICIENT_DATA_SIZE);
                //--------------------------------------------------------
                // Retrieve the coefficient data from a file
                //--------------------------------------------------------
                DWORD status = QCOM_ReadCoefficientDataFromFile(
                    coefficientFilePathString,
                    (CoefficientFormatDef *) coefficientData);
                if (status == QD_SUCCESS)
                {
                    for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot);
                        pageNumber < ((slotNumber + 1) * QCOM_CurrentPagesPerMemorySlot);
                        pageNumber++)
                    {
                        //----------------------------------------------------
                        // Store the coefficient data in the transducer
                        //----------------------------------------------------
                        status = QD_WriteCoefficientDataToTargetPage(
                            unit->unitHandle,
                            QD_DEVICE_MODULE,                                   // 1
                            pageNumber,
                            coefficientData);
                        if (status == QD_SUCCESS)
                        {
                        }
                        else
                        {
                            RecordErrorEvent("    {0} : QD_WriteCoefficientDataToTargetPage(module, page {1:D}) returned 0x{2:X8}",
                                functionName, pageNumber, status);
                        }
                    }                   // end of for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot); ...)
                }                       // end of if (status == QD_SUCCESS)
                else
                {
                    RecordErrorEvent("    {0} : QCOM_ReadCoefficientDataFromFile returned 0x{1:X8} reading\n{2}",
                        functionName, status, coefficientFilePathString);
                }
                Thread::Sleep(100);
                QCOM_UpdateMultipleCoefficientWindow(unit);
                free((void *) coefficientData);
            }                           // end of if (coefficientData)
            else
            {
                GUI_DisplayMandatoryError(functionName,
                    "Unable to allocate the necessary buffers");
            }
        }                               // end of if (fileLocated)
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_MultipleCoefficientModuleLoadSlot()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientModuleVerifySlot
//
// Verifies the coefficient data of the specified module and slot
//
// Called by:   QCOM_MultipleCoefficientModuleVerifyButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientModuleVerifySlot(
    UnitInfo        ^unit,
    BYTE            slotNumber)
{
    String          ^functionName = _T("QCOM_MultipleCoefficientModuleVerifySlot");
    //------------------------------------------------------------------------
    if (unit)
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        LPBYTE coefficientData = (LPBYTE) malloc(QCOM_COEFFICIENT_DATA_SIZE);
        LPBYTE zeroData = (LPBYTE) malloc(QCOM_COEFFICIENT_DATA_SIZE);
        if (coefficientData && zeroData)
        {
            bool dataVerified = GUI_YES;
            bool memoryCleared = GUI_YES;
            ClearBuffer(zeroData, QCOM_COEFFICIENT_DATA_SIZE);
            for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot);
                pageNumber < ((slotNumber + 1) * QCOM_CurrentPagesPerMemorySlot);
                pageNumber++)
            {
                ClearBuffer(coefficientData, QCOM_COEFFICIENT_DATA_SIZE);
                //------------------------------------------------------------
                // Retrieve the coefficient data stored in the module
                //------------------------------------------------------------
                DWORD status = QD_ReadCoefficientDataFromSourcePage(
                    unit->unitHandle,
                    QD_DEVICE_MODULE,                                           // 1
                    pageNumber,
                    coefficientData);
                if ((status == QD_SUCCESS) ||
                    ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA)) // 0x00000040
                {
                    if (!QD_CoefficientDataIsValid(coefficientData))
                    {
                        dataVerified = GUI_NO;
                        if (memcmp((void *) coefficientData, (void *) zeroData, QCOM_COEFFICIENT_DATA_SIZE))
                        {
                            memoryCleared = GUI_NO;
                        }
                    }
                }                       // end of if ((status == QD_SUCCESS) || ...)
                else
                {
                    dataVerified = GUI_NO;
                    RecordErrorEvent("    {0} : QD_ReadCoefficientDataFromSourcePage(module, page {1:D}) returned 0x{2:X8}",
                        functionName, pageNumber, status);
                }
                Thread::Sleep(100);
            }                           // end of for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot); ...)
            //----------------------------------------------------------------
            // Display the result
            //----------------------------------------------------------------
            if (dataVerified)
            {
                QCOM_PromptOKModal("Coefficient Data Verified",
                    String::Concat(
                        _T("The coefficient data of module "),
                        unit->moduleSerialNumber,
                        _T(" slot "),
                        (slotNumber + 1),
                        _T(" is verified")));
            }
            else
            {
                if (memoryCleared)
                {
                    QCOM_PromptOKModal("Coefficient Data Cleared",
                        String::Concat(
                            _T("Slot "),
                            (slotNumber + 1),
                            _T(" of module "),
                            unit->moduleSerialNumber,
                            _T(" verified clear")));
                }
                else
                {
                    QCOM_PromptOKModal("Coefficient Data Unverified",
                        String::Concat(
                            _T("The coefficient data of module "),
                            unit->moduleSerialNumber,
                            _T(" slot "),
                            (slotNumber + 1),
                            _T(" failed verification")));
                }
            }                           // end of if (dataVerified)
            free((void *) zeroData);
            free((void *) coefficientData);
        }                               // end of if (coefficientData && zeroData)
        else
        {
            GUI_DisplayMandatoryError(functionName,
                "Unable to allocate the necessary buffers");
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_MultipleCoefficientModuleVerifySlot()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientTransducerClearSlot
//
// Handles the click of the unit multiple coefficient storage transducer
// Clear button
//
// Called by:   QCOM_MultipleCoefficientTransducerClearButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientTransducerClearSlot(
    UnitInfo        ^unit,
    BYTE            slotNumber)
{
    String          ^functionName = _T("QCOM_MultipleCoefficientTransducerClearSlot");
    //------------------------------------------------------------------------
    if (unit)
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D} slot {2:D}) called",
            functionName, unitNumber, slotNumber);
        LPBYTE zeroData = (LPBYTE) malloc(QCOM_COEFFICIENT_DATA_SIZE);
        if (zeroData)
        {
            ClearBuffer(zeroData, QCOM_COEFFICIENT_DATA_SIZE);
            for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot);
                pageNumber < ((slotNumber + 1) * QCOM_CurrentPagesPerMemorySlot);
                pageNumber++)
            {
                DWORD status = QD_WriteCoefficientDataToTargetPage(
                    unit->unitHandle,
                    QD_DEVICE_TRANSDUCER,                                       // 0
                    pageNumber,
                    zeroData);
                if (status == QD_SUCCESS)
                {
                }
                else
                {
                    RecordErrorEvent("    {0} : QD_WriteCoefficientDataToTargetPage(transducer, page {1:D}) returned 0x{2:X8}",
                        functionName, pageNumber, status);
                }
                Thread::Sleep(100);
            }                           // end of for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot); ...)
            QCOM_UpdateMultipleCoefficientWindow(unit);
            free((void *) zeroData);
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_MultipleCoefficientTransducerClearSlot()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientTransducerCopyToModule
//
// Copies the coefficient data from the specified transducer to its module
//
// Called by:   QCOM_MultipleCoefficientTransducerCopyButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientTransducerCopyToModule(
    UnitInfo        ^unit,
    BYTE            slotNumber)
{
    String          ^functionName = _T("QCOM_MultipleCoefficientTransducerCopyToModule");
    //------------------------------------------------------------------------
    if (unit)
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        if (!QCOM_XDIsFrequency(unit) && !QCOM_XDIsDigitalNoMem(unit))
        {
            LPBYTE coefficientData = (LPBYTE) malloc(QCOM_COEFFICIENT_DATA_SIZE);
            if (coefficientData)
            {
                for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot);
                    pageNumber < ((slotNumber + 1) * QCOM_CurrentPagesPerMemorySlot);
                    pageNumber++)
                {
                    ClearBuffer(coefficientData, QCOM_COEFFICIENT_DATA_SIZE);
                    //--------------------------------------------------------
                    // Retrieve the coefficient data stored in the module
                    //--------------------------------------------------------
                    DWORD status = QD_ReadCoefficientDataFromSourcePage(
                        unit->unitHandle,
                        QD_DEVICE_TRANSDUCER,                                   // 0
                        pageNumber,
                        coefficientData);
                    if ((status == QD_SUCCESS) ||
                        ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA)) // 0x00000040
                    {
                        //----------------------------------------------------
                        // Store the coefficient data in the transducer
                        //----------------------------------------------------
                        status = QD_WriteCoefficientDataToTargetPage(
                            unit->unitHandle,
                            QD_DEVICE_MODULE,                                   // 1
                            pageNumber,
                            coefficientData);
                        if (status == QD_SUCCESS)
                        {
                        }
                        else
                        {
                            RecordErrorEvent("    {0} : QD_WriteCoefficientDataToTargetPage(module, page {1:D}) returned 0x{2:X8}",
                                functionName, pageNumber, status);
                        }
                    }                   // end of if ((status == QD_SUCCESS) || ...)
                    else
                    {
                        RecordErrorEvent("    {0} : QD_ReadCoefficientDataFromSourcePage(transducer, page {1:D}) returned 0x{2:X8}",
                            functionName, pageNumber, status);
                    }
                    Thread::Sleep(100);
                }                       // end of for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot); ...)
                QCOM_UpdateMultipleCoefficientWindow(unit);
                free((void *) coefficientData);
            }                           // end of if (coefficientData)
            else
            {
                GUI_DisplayMandatoryError(functionName,
                    "Unable to allocate the necessary buffers");
            }
        }                               // end of if (!QCOM_XDIsFrequency(unit) && !QCOM_XDIsDigitalNoMem(unit))
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_MultipleCoefficientTransducerCopyToModule()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientTransducerLoadSlot
//
// Prompts for a coefficient data file to load in a transducer slot
//
// Called by:   QCOM_MultipleCoefficientTransducerUpdateButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientTransducerLoadSlot(
    UnitInfo        ^unit,
    BYTE            slotNumber)
{
    bool            browseForFiles = GUI_NO;
    bool            dbFileFound = GUI_NO;
    bool            fileLocated = GUI_NO;
    String          ^coefficientFilePathString;
    String          ^dbPathString = QUARTZDYNE_CONFIDENTIAL_ROOT QUARTZDYNE_CALSUM_DB_FILE_PATH;
    String          ^transducerSearchString;
    String          ^functionName = _T("QCOM_MultipleCoefficientTransducerLoadSlot");
    //------------------------------------------------------------------------
    if (unit)
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D} slot {2:D}) called",
            functionName, unitNumber, slotNumber);
        //--------------------------------------------------------------------
        // Search the network, if present, for the CALSUM database file
        //--------------------------------------------------------------------
        if (File::Exists(dbPathString))
        {
            dbFileFound = GUI_YES;
        }
        else
        {
            array <DriveInfo ^> ^driveInfo = DriveInfo::GetDrives();
            for each (DriveInfo ^oneDrive in driveInfo)
            {
                if (oneDrive->DriveType == DriveType::Network)
                {
                    dbPathString = String::Concat(
                        oneDrive->Name,
                        QUARTZDYNE_CALSUM_DB_FILE_PATH);
                    if (File::Exists(dbPathString))
                    {
                        dbFileFound = GUI_YES;
                    }
                }
            }
        }
        if (dbFileFound)
        {
            bool proceedToSearchDB = QCOM_PromptYesNoModal(
                "Search or Browse",
                "Search", "Browse...",
                "Search the database, or browse for a\n"
                "coefficient data file ?");
            if (QCOM_ModalKeyStroke == GUI_KEY_ESC)
            {
                browseForFiles = GUI_NO;
            }
            else
            {
                if (proceedToSearchDB)
                {
                    bool proceedToImport = GUI_YES;
                    bool inputResponse = GUI_ACCEPT;
                    bool inputValid = GUI_NO;
                    do
                    {
                        inputValid = GUI_YES;
                        if (proceedToImport)
                        {
                            DWORD transducerSerialNumber = 0;
                            StringBuilder ^transducerSearchBuilder =
                                gcnew StringBuilder(QCOM_MAXIMUM_SEARCH_STRING_SIZE);
                            inputResponse = QCOM_PromptInputModal(
                                "Transducer Serial Number",
                                QCOM_GeneralInfo->searchString,
                                &transducerSerialNumber,
                                transducerSearchBuilder,
                                QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH,
                                "Enter the transducer serial number to search for");
                            transducerSearchString = transducerSearchBuilder->ToString();
                            delete transducerSearchBuilder;
                            if (inputResponse == GUI_ACCEPT)
                            {
                                if (StringSet(transducerSearchString) && transducerSerialNumber)
                                {
                                    if (transducerSerialNumber < 10000)
                                        inputValid = GUI_NO;
                                    if (transducerSearchString->Length < (QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH - 1))
                                        inputValid = GUI_NO;
                                    if (inputValid)
                                    {
                                        QCOM_GeneralInfo->searchString = transducerSearchString;
                                    }
                                    else
                                    {
                                        GUI_DisplayMandatoryError(functionName,
                                            "'{0}' is not a valid transducer serial number",
                                            transducerSearchString);
                                    }
                                }
                                else
                                {
                                    browseForFiles = GUI_YES;
                                }
                            }
                        }
                    }
                    while ((inputResponse == GUI_ACCEPT) && (!inputValid));
                    if ((inputResponse == GUI_ACCEPT) && inputValid)
                    {
                        proceedToImport = GUI_YES;
                        browseForFiles = GUI_NO;
                        //----------------------------------------------------
                        // Search the database
                        //----------------------------------------------------
                        QCOM_PleaseWait(
                            GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
                            "Searching for Transducer {0} Coefficient File",
                            transducerSearchString);
                        StringBuilder ^filePathBuilder =
                            gcnew StringBuilder(QCOM_MAXIMUM_FILE_PATH_LENGTH);
                        fileLocated = QCOM_SearchForCoefficientFile(
                            transducerSearchString,
                            filePathBuilder);
                        coefficientFilePathString = filePathBuilder->ToString();
                        delete filePathBuilder;
                        QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
                        Thread::Sleep(100);
                    }
                }
                else
                {
                    browseForFiles = GUI_YES;
                }
            }                           // end of else of if (QCOM_ModalKeyStroke == GUI_KEY_ESC)
        }
        else
        {
            browseForFiles = GUI_YES;
        }
        if (browseForFiles)
        {
            if (QCOM_GeneralInfo->flags & QCOM_GENERAL_USE_PATH_SPECIFIED)
                coefficientFilePathString = QCOM_GeneralInfo->generalUsePath;
            else
                coefficientFilePathString = Environment::GetFolderPath(Environment::SpecialFolder::Recent);
            bool promptResult = GUI_ACCEPT;
            do
            {
                StringBuilder ^coefficientFilePathBuilder = gcnew StringBuilder(
                    coefficientFilePathString,
                    QCOM_MAXIMUM_FILE_PATH_LENGTH);
                promptResult = QCOM_PromptForReadFile(
                    String::Format(
                        "Import Coefficient Data File for Transducer on Module {0}",
                        unit->moduleSerialNumber),
                    coefficientFilePathBuilder,
                    nullptr,
                    GUI_FILE_TYPE_HEX_NATIVE_REF);
                coefficientFilePathString = coefficientFilePathBuilder->ToString();
                delete coefficientFilePathBuilder;
                if (promptResult == GUI_ACCEPT)
                {
                    fileLocated = GUI_YES;
                }
            }
            while (!fileLocated && (promptResult == GUI_ACCEPT));
        }                               // end of if (browseForFiles)
        if (fileLocated)
        {
            if (!QCOM_XDIsFrequency(unit) && !QCOM_XDIsDigitalNoMem(unit))
            {
                LPBYTE coefficientData = (LPBYTE) malloc(QCOM_COEFFICIENT_DATA_SIZE);
                if (coefficientData)
                {
                    ClearBuffer(coefficientData, QCOM_COEFFICIENT_DATA_SIZE);
                    //--------------------------------------------------------
                    // Retrieve the coefficient data from a file
                    //--------------------------------------------------------
                    DWORD status = QCOM_ReadCoefficientDataFromFile(
                        coefficientFilePathString,
                        (CoefficientFormatDef *) coefficientData);
                    if (status == QD_SUCCESS)
                    {
                        for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot);
                            pageNumber < ((slotNumber + 1) * QCOM_CurrentPagesPerMemorySlot);
                            pageNumber++)
                        {
                            //------------------------------------------------
                            // Store the coefficient data in the transducer
                            //------------------------------------------------
                            status = QD_WriteCoefficientDataToTargetPage(
                                unit->unitHandle,
                                QD_DEVICE_TRANSDUCER,                           // 0
                                pageNumber,
                                coefficientData);
                            if (status == QD_SUCCESS)
                            {
                            }
                            else
                            {
                                RecordErrorEvent("    {0} : QD_WriteCoefficientDataToTargetPage(transducer, page {1:D}) returned 0x{2:X8}",
                                    functionName, pageNumber, status);
                            }
                        }               // end of for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot); ...)
                    }                   // end of if (status == QD_SUCCESS)
                    else
                    {
                        RecordErrorEvent("    {0} : QCOM_ReadCoefficientDataFromFile returned 0x{1:X8} reading\n{2}",
                            functionName, status, coefficientFilePathString);
                    }
                    Thread::Sleep(100);
                    QCOM_UpdateMultipleCoefficientWindow(unit);
                    free((void *) coefficientData);
                }                       // end of if (coefficientData)
                else
                {
                    GUI_DisplayMandatoryError(functionName,
                        "Unable to allocate the necessary buffers");
                }
            }                           // end of if (!QCOM_XDIsFrequency(unit) && !QCOM_XDIsDigitalNoMem(unit))
        }                               // end of if (fileLocated)
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_MultipleCoefficientTransducerLoadSlot()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientTransducerVerifySlot
//
// Verifies the coefficient data of the specified transducer and slot
//
// Called by:   QCOM_MultipleCoefficientTransducerVerifyButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientTransducerVerifySlot(
    UnitInfo        ^unit,
    BYTE            slotNumber)
{
    String          ^functionName = _T("QCOM_MultipleCoefficientTransducerVerifySlot");
    //------------------------------------------------------------------------
    if (unit)
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        if (!QCOM_XDIsFrequency(unit) && !QCOM_XDIsDigitalNoMem(unit))
        {
            LPBYTE coefficientData = (LPBYTE) malloc(QCOM_COEFFICIENT_DATA_SIZE);
            LPBYTE zeroData = (LPBYTE) malloc(QCOM_COEFFICIENT_DATA_SIZE);
            if (coefficientData && zeroData)
            {
                bool dataVerified = GUI_YES;
                bool memoryCleared = GUI_YES;
                ClearBuffer(zeroData, QCOM_COEFFICIENT_DATA_SIZE);
                for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot);
                    pageNumber < ((slotNumber + 1) * QCOM_CurrentPagesPerMemorySlot);
                    pageNumber++)
                {
                    ClearBuffer(coefficientData, QCOM_COEFFICIENT_DATA_SIZE);
                    //--------------------------------------------------------
                    // Retrieve the coefficient data stored in the transducer
                    //--------------------------------------------------------
                    DWORD status = QD_ReadCoefficientDataFromSourcePage(
                        unit->unitHandle,
                        QD_DEVICE_TRANSDUCER,                                   // 0
                        pageNumber,
                        coefficientData);
                    if ((status == QD_SUCCESS) ||
                        ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA)) // 0x00000040
                    {
                        if (!QD_CoefficientDataIsValid(coefficientData))
                        {
                            dataVerified = GUI_NO;
                            if (memcmp((void *) coefficientData, (void *) zeroData, QCOM_COEFFICIENT_DATA_SIZE))
                            {
                                memoryCleared = GUI_NO;
                            }
                        }
                    }                   // end of if ((status == QD_SUCCESS) || ...)
                    else
                    {
                        dataVerified = GUI_NO;
                        RecordErrorEvent("    {0} : QD_ReadCoefficientDataFromSourcePage(transducer, page {1:D}) returned 0x{2:X8}",
                            functionName, pageNumber, status);
                    }
                    Thread::Sleep(100);
                }                       // end of for (BYTE pageNumber = (slotNumber * QCOM_CurrentPagesPerMemorySlot); ...)
                //------------------------------------------------------------
                // Display the result
                //------------------------------------------------------------
                if (dataVerified)
                {
                    QCOM_PromptOKModal("Coefficient Data Verified",
                        String::Concat(
                            _T("The coefficient data of transducer "),
                            unit->transducerSerialNumber,
                            _T(" slot "),
                            (slotNumber + 1),
                            _T(" is verified")));
                }
                else
                {
                    if (memoryCleared)
                    {
                        QCOM_PromptOKModal("Coefficient Data Cleared",
                            String::Concat(
                                _T("Slot "),
                                (slotNumber + 1),
                                _T(" of transducer "),
                                unit->transducerSerialNumber,
                                _T(" verified clear")));
                    }
                    else
                    {
                        QCOM_PromptOKModal("Coefficient Data Unverified",
                            String::Concat(
                                _T("The coefficient data of transducer "),
                                unit->transducerSerialNumber,
                                _T(" slot "),
                                (slotNumber + 1),
                                _T(" failed verification")));
                    }
                }                       // end of if (dataVerified)
                free((void *) zeroData);
                free((void *) coefficientData);
            }                           // end of if (coefficientData && zeroData)
            else
            {
                GUI_DisplayMandatoryError(functionName,
                    "Unable to allocate the necessary buffers");
            }
        }                               // end of if (!QCOM_XDIsFrequency(unit) && !QCOM_XDIsDigitalNoMem(unit))
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_MultipleCoefficientTransducerVerifySlot()
//----------------------------------------------------------------------------
// QCOM_PromptForDownloadCoefficientFiles
//
// Prompts for a transducer serial number and downloads all available
// coefficient files for the specified transducer
//
// Called by:   QCOM_UtilDownloadCoefficientFilesButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PromptForDownloadCoefficientFiles(void)
{
    bool            fileLocated = GUI_NO;
    bool            inputResponse = GUI_ACCEPT;
    bool            inputValid = GUI_NO;
    bool            promptResult = GUI_ACCEPT;
    DWORD           status = QCOM_SUCCESS;
    DWORD           transducerSerialNumber = 0;
    String          ^transducerSearchString;
    String          ^functionName = _T("QCOM_PromptForDownloadCoefficientFiles");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_InternetIsAvailable())
    {
        //--------------------------------------------------------------------
        // The software has access to the web, so check for the presence of
        // the Coefficient Download PHP file
        //--------------------------------------------------------------------
        if (QCOM_URLExists(QCOM_COEFFICIENT_FILE_DOWNLOAD_URL))
        {
            do
            {
                inputValid = GUI_YES;
                StringBuilder ^transducerSearchBuilder =
                    gcnew StringBuilder(QCOM_MAXIMUM_SEARCH_STRING_SIZE);
                inputResponse = QCOM_PromptInputModal(
                    "Transducer Serial Number",
                    QCOM_GeneralInfo->searchString,
                    &transducerSerialNumber,
                    transducerSearchBuilder,
                    QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH,
                    "Enter the transducer serial number to search for");
                transducerSearchString = transducerSearchBuilder->ToString();
                delete transducerSearchBuilder;
                if (inputResponse == GUI_ACCEPT)
                {
                    if (StringSet(transducerSearchString) && transducerSerialNumber)
                    {
                        if (transducerSerialNumber < 10000)
                            inputValid = GUI_NO;
                        if (transducerSearchString->Length < (QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH - 1))
                            inputValid = GUI_NO;
                        if (inputValid)
                        {
                            QCOM_GeneralInfo->searchString = transducerSearchString;
                        }
                        else
                        {
                            GUI_DisplayMandatoryError(functionName,
                                "'{0}' is not a valid transducer serial number",
                                transducerSearchString);
                        }
                    }
                }
            }
            while ((inputResponse == GUI_ACCEPT) && (!inputValid));
            if ((inputResponse == GUI_ACCEPT) && inputValid)
            {
                String ^url = String::Concat(
                    QCOM_COEFFICIENT_FILE_DOWNLOAD_URL,
                    _T("?sn="), transducerSearchString);
                //------------------------------------------------------------
                // Invoke the browser
                //------------------------------------------------------------
                System::Diagnostics::Process::Start(url);
                delete url;
            }
        }                               // end of if (QCOM_URLExists(QCOM_COEFFICIENT_FILE_DOWNLOAD_URL))
        else
        {
            GUI_DisplaySimpleError(
                functionName,
                "The internet file {0} can't be located", QCOM_COEFFICIENT_FILE_DOWNLOAD_URL);
        }
    }                                   // end of if (QCOM_InternetIsAvailable())
    else
    {
        QCOM_RecordAndModalEventByFlags(
            QCOM_EventLogBasicEnabled,
            QCOM_VerboseMessagesEnabled,
            functionName,
            "The internet is unavailable at the moment");
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_PromptForDownloadCoefficientFiles()
//----------------------------------------------------------------------------
// QCOM_PromptForImportCoefficientDataFromFile
//
// Prompts for a file from which to retrieve the coefficient data of the
// specified unit or transducer from file
//
// Called by:   QCOM_UtilImportCoefficientDataFileButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PromptForImportCoefficientDataFromFile(
    UnitInfo        ^unit)
{
    bool            browseForFiles = GUI_NO;
    bool            currentlySampling;
    bool            currentlyTesting;
    bool            dataImported = GUI_NO;
    bool            dbFileFound = GUI_NO;
    bool            fileLocated = GUI_NO;
    bool            inputResponse = GUI_ACCEPT;
    bool            inputValid = GUI_NO;
    bool            proceedToCommit = GUI_NO;
    bool            proceedToImport = GUI_YES;
    bool            proceedToSearchDB = GUI_NO;
    bool            promptResult = GUI_ACCEPT;
    DWORD           interimStatus;
    DWORD           status = QCOM_SUCCESS;
    DWORD           transducerSerialNumber = 0;
    CoefficientFormatDef
                    *coefficientData;
    String          ^coefficientFilePathString;
    String          ^dbPathString = QUARTZDYNE_CONFIDENTIAL_ROOT QUARTZDYNE_CALSUM_DB_FILE_PATH;
    String          ^promptString;
    String          ^transducerSearchString;
    String          ^functionName = _T("QCOM_PromptForImportCoefficientDataFromFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_UnitValid(unit))
    {
        currentlySampling = QCOM_QueryStopSampling(
            "Coefficient data cannot be modified during transducer sampling.");
        currentlyTesting = QCOM_QueryStopTesting(
            "Coefficient data cannot be modified while tests are running.");
        if (!currentlySampling && !currentlyTesting)
        {
            coefficientData = (CoefficientFormatDef *) malloc(sizeof(CoefficientFormatDef));
            if (coefficientData)
            {
                //------------------------------------------------------------
                // Search the network, if present, for the CALSUM database file
                //------------------------------------------------------------
                if (File::Exists(dbPathString))
                {
                    dbFileFound = GUI_YES;
                }
                else
                {
                    array <DriveInfo ^> ^driveInfo = DriveInfo::GetDrives();
                    for each (DriveInfo ^oneDrive in driveInfo)
                    {
                        if (oneDrive->DriveType == DriveType::Network)
                        {
                            dbPathString = String::Concat(
                                oneDrive->Name,
                                QUARTZDYNE_CALSUM_DB_FILE_PATH);
                            if (File::Exists(dbPathString))
                            {
                                dbFileFound = GUI_YES;
                            }
                        }
                    }
                }
                if (dbFileFound)
                {
                    proceedToSearchDB = QCOM_PromptYesNoModal(
                        "Search or Browse",
                        "Search", "Browse...",
                        "Search the database, or browse for a\n"
                        "coefficient data file ?");
                    if (QCOM_ModalKeyStroke == GUI_KEY_ESC)
                    {
                        browseForFiles = GUI_NO;
                    }
                    else
                    {
                        if (proceedToSearchDB)
                        {
                            do
                            {
                                inputValid = GUI_YES;
                                if (proceedToImport)
                                {
                                    StringBuilder ^transducerSearchBuilder =
                                        gcnew StringBuilder(QCOM_MAXIMUM_SEARCH_STRING_SIZE);
                                    inputResponse = QCOM_PromptInputModal(
                                        "Transducer Serial Number",
                                        (QCOM_XDSNValid(unit) ?
                                            unit->transducerSerialNumber :
                                            QCOM_GeneralInfo->searchString),
                                        &transducerSerialNumber,
                                        transducerSearchBuilder,
                                        QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH,
                                        "Enter the transducer serial number to search for");
                                    transducerSearchString = transducerSearchBuilder->ToString();
                                    delete transducerSearchBuilder;
                                    if (inputResponse == GUI_ACCEPT)
                                    {
                                        if (StringSet(transducerSearchString) && transducerSerialNumber)
                                        {
                                            if (transducerSerialNumber < 10000)
                                                inputValid = GUI_NO;
                                            if (transducerSearchString->Length < (QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH - 1))
                                                inputValid = GUI_NO;
                                            if (inputValid)
                                            {
                                                QCOM_GeneralInfo->searchString = transducerSearchString;
                                            }
                                            else
                                            {
                                                GUI_DisplayMandatoryError(functionName,
                                                    "'{0}' is not a valid transducer serial number",
                                                    transducerSearchString);
                                            }
                                        }
                                        else
                                        {
                                            browseForFiles = GUI_YES;
                                        }
                                    }
                                }
                            }
                            while ((inputResponse == GUI_ACCEPT) && (!inputValid));
                            if ((inputResponse == GUI_ACCEPT) && inputValid)
                            {
                                proceedToImport = GUI_YES;
                                browseForFiles = GUI_NO;
                                //--------------------------------------------
                                // Search the database
                                //--------------------------------------------
                                QCOM_PleaseWait(
                                    GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
                                    "Searching for Transducer {0} Coefficient File",
                                    transducerSearchString);
                                StringBuilder ^filePathBuilder =
                                    gcnew StringBuilder(QCOM_MAXIMUM_FILE_PATH_LENGTH);
                                fileLocated = QCOM_SearchForCoefficientFile(
                                    transducerSearchString,
                                    filePathBuilder);
                                coefficientFilePathString = filePathBuilder->ToString();
                                delete filePathBuilder;
                                QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
                                Thread::Sleep(100);
                                if (fileLocated)
                                {
                                    dataImported = QCOM_ImportCoefficientDataFromFile(
                                        unit,
                                        coefficientFilePathString);
                                }
                            }
                        }
                        else
                        {
                            browseForFiles = GUI_YES;
                        }
                    }                   // end of else of if (QCOM_ModalKeyStroke == GUI_KEY_ESC)
                }
                else
                {
                    browseForFiles = GUI_YES;
                }
                if (browseForFiles)
                {
                    //------------------------------------------------------------
                    // If the current unit doesn't have a coefficient file path
                    // specified, determine whether another unit does, and copy
                    // that one, to prevent the user from possibly needing to
                    // drill down to the same directory
                    //------------------------------------------------------------
                    if (!QCOM_CFKnown(unit))
                    {
                        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
                        {   
                            if (QCOM_UnitNumberValid(unitNumber))
                            {
                                if (QCOM_UnitInfoArray[unitNumber]->flags & QCOM_UNIT_COEFFICIENT_FILE_SPECIFIED)
                                {
                                    unit->coefficientFilePath = QCOM_UnitInfoArray[unitNumber]->coefficientFilePath;
                                    break;
                                }
                            }
                            else
                            {
                                QCOM_RecordAndModalErrorEvent(
                                    "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                                    functionName, unitNumber, QCOM_CurrentNumberOfUnits);
                            }
                        }
                    }
                    do
                    {
                        coefficientFilePathString = unit->coefficientFilePath;
                        StringBuilder ^coefficientFilePathBuilder = gcnew StringBuilder(
                            coefficientFilePathString,
                            QCOM_MAXIMUM_FILE_PATH_LENGTH);
                        promptResult = QCOM_PromptForReadFile(
                            String::Format(
                                "Import Coefficient Data File for Transducer on Module {0}",
                                unit->moduleSerialNumber),
                            coefficientFilePathBuilder,
                            (QCOM_XDSNValid(unit) ?
                                unit->transducerSerialNumber : nullptr),
                            GUI_FILE_TYPE_HEX_NATIVE_REF);
                        coefficientFilePathString = coefficientFilePathBuilder->ToString();
                        delete coefficientFilePathBuilder;
                        if (promptResult == GUI_ACCEPT)
                        {
                            dataImported = QCOM_ImportCoefficientDataFromFile(
                                unit,
                                coefficientFilePathString);
                        }
                    }
                    while (!dataImported && (promptResult == GUI_ACCEPT));
                }                       // end of if (browseForFiles)
                if ((promptResult == GUI_ACCEPT) && StringSet(unit->coefficientFilePath) && dataImported)
                {
                    QCOM_RecordAndModalEventByFlags(
                        QCOM_EventLogVerboseEnabled,
                        QCOM_DetailedMessagesEnabled,
                        functionName,
                        "Coefficient data successfully read from\n{0}",
                        coefficientFilePathString);
                    unit->flags |= QCOM_UNIT_COEFFICIENT_FILE_SPECIFIED;
                    //--------------------------------------------------------
                    // The coefficient data file was successfully imported;
                    // next, store the data in all four pages of the module
                    //--------------------------------------------------------
                    unit->flags &= ~QCOM_UNIT_COEFFICIENTS_VERIFIED;
                    status = QCOM_SUCCESS;
                    for (BYTE pageNumber = 0; pageNumber < QD_NUMBER_OF_LOWER_QMEM_PAGES; pageNumber++)
                    {
                        interimStatus = QD_WriteCoefficientDataToModulePage(
                            unit->unitHandle,
                            pageNumber,
                            (LPBYTE) unit->coefficientData);
                        if (interimStatus)
                        {
                            GUI_DisplaySimpleError(functionName,
                                "QD_WriteCoefficientDataToModulePage failed for page {0:D} with status 0x{1:X8}",
                                pageNumber,
                                interimStatus);
                            status = interimStatus;
                        }
                    }
                    if (status == QCOM_SUCCESS)
                    {
                        QCOM_RecordAndModalEventByFlags(
                            QCOM_EventLogVerboseEnabled,
                            QCOM_DetailedMessagesEnabled,
                            functionName,
                            "Coefficient data successfully written to unit {0:D}",
                            unit->unitNumber);
                        //----------------------------------------------------
                        // Verify the integrity of the module's copy of the
                        // coefficient data
                        //----------------------------------------------------
                        status = QCOM_SUCCESS;
                        for (BYTE pageNumber = 0; pageNumber < QD_NUMBER_OF_LOWER_QMEM_PAGES; pageNumber++)
                        {
                            interimStatus = QD_ReadCoefficientDataFromModulePage(
                                unit->unitHandle,
                                pageNumber,
                                (LPBYTE) coefficientData);
                            if (interimStatus)
                            {
                                promptString = String::Format(
                                    "QD_ReadCoefficientDataFromModulePage(page {0:D})",
                                    pageNumber),
                                GUI_DisplayUnitErrorWithStatus(
                                    functionName,
                                    promptString,
                                    unit,
                                    interimStatus);
                                status = interimStatus;
                            }
                        }
                        if (status == QCOM_SUCCESS)
                        {
                            QCOM_RecordAndModalEventByFlags(
                                QCOM_EventLogVerboseEnabled,
                                QCOM_DetailedMessagesEnabled,
                                functionName,
                                "Coefficient data successfully read back from unit {0:D}",
                                unit->unitNumber);
                            if (QD_CoefficientDataIsValid((LPBYTE) coefficientData) &&
                                (memcmp(
                                    coefficientData,
                                    unit->coefficientData,
                                    sizeof(CoefficientFormatDef)) == 0))
                            {
                                QCOM_PromptOKModal(
                                    "Successful Coefficient Data Import",
                                    "Coefficient data successfully imported from\n{0}",
                                    coefficientFilePathString);
                                unit->flags |=
                                    QCOM_UNIT_COEFFICIENTS_VERIFIED;
                                QCOM_ApplyCoefficientDataInfoToProgram(unit);
                                QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
                                //--------------------------------------------
                                // The data is intact, so ask whether the data
                                // should be stored in transducer memory (for
                                // digital transducers only)
                                //--------------------------------------------
                                if (QCOM_XDPresent(unit))
                                {
                                    if (unit->transducerType && !QCOM_XDIsFrequency(unit) && !QCOM_XDIsDigitalNoMem(unit))
                                    {
                                        promptString = String::Format(
                                            "Commit the coefficient data of transducer {0}\n"
                                            "permanently to digital transducer memory ?",
                                            unit->transducerSerialNumber);
                                        proceedToCommit = QCOM_PromptModal(
                                            "Commit Coefficient Data",
                                            promptString);
                                        if (proceedToCommit)
                                        {
                                            for (BYTE pageNumber = 0; pageNumber < QD_NUMBER_OF_LOWER_QMEM_PAGES; pageNumber++)
                                            {
                                                interimStatus = QD_WriteCoefficientDataToTargetPage(
                                                    unit->unitHandle,
                                                    QD_DEVICE_TRANSDUCER,
                                                    pageNumber,
                                                    (LPBYTE) coefficientData);
                                                if (interimStatus)
                                                {
                                                    promptString = String::Format(
                                                        "QD_WriteCoefficientDataToTargetPage(page {0:D})",
                                                        pageNumber);
                                                    GUI_DisplayUnitErrorWithStatus(
                                                        functionName,
                                                        promptString,
                                                        unit,
                                                        interimStatus);
                                                    status = interimStatus;
                                                }
                                            }
                                            if ((status == QCOM_SUCCESS) &&
                                                !(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
                                            {
                                                QCOM_PromptOKModal(
                                                    "Commit Successful",
                                                    "The coefficient data of transducer {0} has been\n"
                                                    "successfully committed to digital transducer memory",
                                                    unit->transducerSerialNumber);
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                GUI_DisplayMandatoryError(
                                    "Coefficient Data Error",
                                    "Invalid coefficient data present in module {0}\n"
                                    "Transducer {1} cannot be sampled",
                                    unit->moduleSerialNumber,
                                    unit->transducerSerialNumber);
                                unit->flags &= ~QCOM_UNIT_OK_TO_SAMPLE;
                            }
                        }
                        else
                        {
                            GUI_DisplayErrorWithStatus(
                                functionName,
                                "QD_ReadCoefficientDataFromModulePage",
                                unit,
                                status);
                        }
                    }
                    else
                    {
                        GUI_DisplayErrorWithStatus(
                            functionName,
                            "QD_WriteCoefficientDataToModulePage",
                            unit,
                            status);
                    }
                }
                free((void *) coefficientData);
            }
            else
            {
                GUI_DisplayUnitError(
                    functionName,
                    "Coefficient data memory allocation failed",
                    unit);
            }
        }                               // end of if (!currentlySampling && !currentlyTesting)
    }                                   // end of if (QCOM_UnitValid(unit))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_PromptForImportCoefficientDataFromFile()
//----------------------------------------------------------------------------
// QCOM_PromptForRetrieveCoefficientFileParameters
//
// Prompts for a transducer serial number and a coefficient file parameter, and
// displays the parameter string
//
// Called by:   QCOM_UtilRetrieveCoefficientFileParametersButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PromptForRetrieveCoefficientFileParameters(void)
{
    bool            browseForFiles = GUI_NO;
    bool            dbFileFound = GUI_NO;
    bool            fileLocated = GUI_NO;
    bool            inputResponse = GUI_ACCEPT;
    bool            inputValid = GUI_NO;
    bool            proceedToRetrieve = GUI_YES;
    bool            proceedToSearchDB = GUI_NO;
    DWORD           status = QCOM_SUCCESS;
    DWORD           transducerSerialNumber = 0;
    StringBuilder   ^filePathBuilder;
    String          ^dbPathString = QUARTZDYNE_CONFIDENTIAL_ROOT QUARTZDYNE_CALSUM_DB_FILE_PATH;
    String          ^fileNameStart;
    String          ^filePathString;
    String          ^transducerSearchString;
    String          ^functionName = _T("QCOM_PromptForRetrieveCoefficientFileParameters");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    filePathBuilder = gcnew StringBuilder(QCOM_MAXIMUM_FILE_PATH_LENGTH);
    do
    {
        inputValid = GUI_YES;
        if (proceedToRetrieve)
        {
            StringBuilder ^transducerSearchBuilder = gcnew StringBuilder(QCOM_MAXIMUM_SEARCH_STRING_SIZE);
            inputResponse = QCOM_PromptInputModal(
                "Transducer Serial Number",
                QCOM_GeneralInfo->searchString,
                &transducerSerialNumber,
                transducerSearchBuilder,
                QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH,
                "Enter the transducer serial number of the coefficient\n"
                "file parameters to retrieve and display.\n"
                "Leave it blank to browse for a coefficient file set.");
            transducerSearchString = transducerSearchBuilder->ToString();
            delete transducerSearchBuilder;
            if (inputResponse == GUI_ACCEPT)
            {
                if (StringSet(transducerSearchString) && transducerSerialNumber)
                {
                    if (transducerSerialNumber < 10000)
                        inputValid = GUI_NO;
                    if (transducerSearchString->Length < (QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH - 1))
                        inputValid = GUI_NO;
                    if (inputValid)
                    {
                        QCOM_GeneralInfo->searchString = transducerSearchString;
                        proceedToRetrieve = GUI_YES;
                    }
                    else
                    {
                        GUI_DisplayMandatoryError(
                            functionName,
                            "'{0}' is not a valid transducer serial number",
                            transducerSearchString);
                    }
                }                       // end of if (StringSet(transducerSearchString) && transducerSerialNumber)
                else
                {
                    browseForFiles = GUI_YES;
                }
            }                           // end of if (inputResponse == GUI_ACCEPT)
            else
            {
                proceedToRetrieve = GUI_NO;
            }
        }                               // end of if (proceedToRetrieve)
    }
    while ((inputResponse == GUI_ACCEPT) && !inputValid);
    if ((inputResponse == GUI_ACCEPT) && inputValid && (proceedToRetrieve == GUI_YES))
    {
        if (!browseForFiles)
        {
            while (transducerSearchString->Length < QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH)
            {
                transducerSearchString = String::Concat("0", transducerSearchString);
            }
            //----------------------------------------------------------------
            // Search the network, if present, for the CALSUM database file
            //----------------------------------------------------------------
            if (File::Exists(dbPathString))
            {
                dbFileFound = GUI_YES;
            }
            else
            {
                array <DriveInfo ^> ^driveInfo = DriveInfo::GetDrives();
                for each (DriveInfo ^oneDrive in driveInfo)
                {
                    if (oneDrive->DriveType == DriveType::Network)
                    {
                        dbPathString = String::Concat(
                            oneDrive->Name,
                            QUARTZDYNE_CALSUM_DB_FILE_PATH);
                        if (File::Exists(dbPathString))
                        {
                            dbFileFound = GUI_YES;
                        }
                    }
                }
            }
            if (dbFileFound)
            {
                proceedToSearchDB = QCOM_PromptYesNoModal(
                    "Search the Database",
                    "Search", "Browse...",
                    "Search the database, or browse for the\n"
                    "coefficient files of transducer {0} ?",
                    transducerSearchString);
                if (proceedToSearchDB)
                {
                    QCOM_PleaseWait(
                        GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
                        "Searching for Transducer {0} Coefficient File",
                        transducerSearchString);
                    fileLocated = QCOM_SearchForCoefficientFile(
                        transducerSearchString,
                        filePathBuilder);
                    filePathString = filePathBuilder->ToString();
                    QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
                    Thread::Sleep(100);
                }
                else
                {
                    browseForFiles = GUI_YES;
                }
            }
            else
            {
                browseForFiles = GUI_YES;
            }
        }                               // end of if (!browseForFiles)
        if (browseForFiles)
        {
            do
            {
                fileLocated = QCOM_PromptForReadFile(
                    "Select Coefficient File",
                    filePathBuilder,
                    transducerSearchString,
                    GUI_FILE_TYPE_HEX_NATIVE_ALL);
                filePathString = filePathBuilder->ToString();
                if (fileLocated)
                {
                    if (filePathString->ToLower()->EndsWith(".crf") ||
                        filePathString->ToLower()->EndsWith(".crt") ||
                        filePathString->ToLower()->EndsWith(".cff") ||
                        filePathString->ToLower()->EndsWith(".cft") ||
                        filePathString->ToLower()->EndsWith(".hex"))
                    {
                        inputValid = GUI_YES;
                        if (!StringSet(transducerSearchString))
                        {
                            fileNameStart = Path::GetFileName(filePathString);
                            if (StringSet(fileNameStart))
                            {
                                transducerSearchString =
                                    Path::GetFileNameWithoutExtension(fileNameStart);
                                if (StringSet(transducerSearchString))
                                {
                                    QCOM_GeneralInfo->searchString = transducerSearchString;
                                }
                            }
                        }
                    }
                    else
                    {
                        inputValid = GUI_NO;
                        GUI_DisplayMandatoryError(
                            functionName,
                            "{0}\n"
                            "is not a valid coefficient file. "
                            "Please select a valid file.",
                            filePathString);
                    }
                }
            }
            while ((fileLocated == GUI_ACCEPT) && !inputValid);
        }                               // end of if (browseForFiles)
        if (fileLocated)
        {
            if (proceedToRetrieve)
            {
                if (filePathString->ToLower()->EndsWith(".crf") ||
                    filePathString->ToLower()->EndsWith(".crt") ||
                    filePathString->ToLower()->EndsWith(".cff") ||
                    filePathString->ToLower()->EndsWith(".cft"))
                {
                    QCOM_DisplayNativeCFParameters(
                        filePathString,
                        GUI_PRIMARY_DISPLAY);
                }                       // end of if (filePathString->ToLower()->EndsWith(".crf") || ...)
                else
                {
                    QCOM_DisplayHexCFParameters(
                        filePathString,
                        GUI_PRIMARY_DISPLAY);
                }                       // end of else of if (filePathString->ToLower()->EndsWith(".crf") || ...)
            }                           // end of if (proceedToRetrieve)
        }                               // end of if (fileLocated)
    }                                   // end of if ((inputResponse == GUI_ACCEPT) && inputValid && ...)
    delete filePathBuilder;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_PromptForRetrieveCoefficientFileParameters()
//----------------------------------------------------------------------------
// QCOM_ReadCoefficientDataFromFile
//
// Retrieves the coefficient data from the specified file path
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    coefficientData must point to at least QCOM_COEFFICIENT_DATA_SIZE
//          (256) bytes of available memory
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_ReadCoefficientDataFromFile(
    String          ^filePathString,
    CoefficientFormatDef
                    *coefficientData)
{
    double          inputDouble;
    char            *filePath;
    BYTE            checksum;
    BYTE            *coefficientBytes = (LPBYTE) coefficientData;
    DWORD           status = QCOM_SUCCESS;
    CoefficientFormatDef
                    *format = coefficientData;
    CoefficientParametersDef
                    parameters;
    StreamReader    ^textReader;
    String          ^crfFilePath;
    String          ^crtFilePath;
    String          ^lineString;
    String          ^functionName = _T("QCOM_ReadCoefficientDataFromFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called for\n{1}", functionName, filePathString);
    if (StringSet(filePathString) && coefficientData)
    {
        if (filePathString->ToLower()->EndsWith(".hex"))
        {
            //----------------------------------------------------------------
            // The source is a hex coefficient data file
            //----------------------------------------------------------------
            filePath = (char *) malloc(QCOM_MAXIMUM_FILE_PATH_LENGTH);
            if (filePath)
            {
                QCOM_ConvertString(
                    filePathString,
                    filePath,
                    QCOM_MAXIMUM_FILE_PATH_LENGTH);
                status = QD_ReadCoefficientDataFromHexFile(
                    (LPBYTE) filePath,
                    (LPBYTE) coefficientBytes);
                if (status == QD_SUCCESS)
                {
                    QCOM_RecordAndModalEventByFlags(
                        QCOM_EventLogBasicEnabled,
                        QCOM_VerboseMessagesEnabled,
                        functionName,
                        "Read in hex coefficient data file\n{0}",
                        filePathString);
                }
                else
                {
                    QCOM_RecordAndModalErrorEvent(
                        "QD_ReadCoefficientDataFromHexFile returned status 0x{0:X8} while analyzing file\n{1}",
                        status,
                        filePathString);
                }
                free((void *) filePath);
            }
            else
            {
                status = QD_ERROR_MEMORY_ALLOCATION_FAILED;                     // 0x00000014
            }
        }                               // end of if (filePathString->ToLower()->EndsWith(".hex"))
        else
        {
            //----------------------------------------------------------------
            // The source is a native coefficient data file
            //----------------------------------------------------------------
            if (!filePathString->ToLower()->EndsWith(".crf") &&
                !filePathString->ToLower()->EndsWith(".crt"))
            {
                QCOM_PromptOKModal(functionName,
                    "The coefficient data file path\n{0}\nis invalid",
                    filePathString);
                return QCOM_ERROR_NATIVE_FILE_PATH_INVALID;
            }
            crfFilePath = filePathString->Replace(Path::GetExtension(filePathString), ".crf");
            crtFilePath = filePathString->Replace(Path::GetExtension(filePathString), ".crt");
            //----------------------------------------------------------------
            // Both reference coefficient files must be present to process
            //----------------------------------------------------------------
            if (File::Exists(crfFilePath) && File::Exists(crtFilePath))
            {
                ClearBuffer(coefficientData, sizeof(CoefficientFormatDef));
                ClearBuffer(&parameters, sizeof(CoefficientParametersDef));
                //------------------------------------------------------------
                // Begin processing the .crf/.crt file (format floats for
                // big-endian storage by default)
                //------------------------------------------------------------
                format->fileType = QD_QUARTZDYNE_CF_TYPE_BIG_ENDIAN;            // 0x010D
                format->fileVersion = QD_QUARTZDYNE_CF_VERSION_123;
                //------------------------------------------------------------
                // Begin processing the .crf file
                //------------------------------------------------------------
                textReader = File::OpenText(crfFilePath);
                if (textReader)
                {
                    //--------------------------------------------------------
                    // Line 1: Transducer Serial Number
                    //--------------------------------------------------------
                    lineString = textReader->ReadLine()->Trim();
                    if ((lineString->Length) > 6 && (lineString[6] == 'R'))
                    {
                        if (filePathString->Contains(lineString->Substring(0, 6)))
                        {
                            int integerValue = 0;
                            for (int index = 4; index >= 0; index -= 2)
                            {
                                if (isdigit((BYTE) lineString[index]) && isdigit((BYTE) lineString[index + 1]))
                                {
                                    integerValue |= ((AtoX(lineString[index]) << 4) | AtoX(lineString[index + 1]));
                                    integerValue <<= 8;
                                }
                            }
                            if (integerValue)
                                format->serialNumber = integerValue | QD_QUARTZDYNE_ID;
                            else
                                status = QCOM_ERROR_NATIVE_SN_INVALID;
                        }
                        else
                            status = QCOM_ERROR_NATIVE_SN_INVALID;
                    }
                    else
                        status = QCOM_ERROR_NATIVE_SN_INVALID;
                    //--------------------------------------------------------
                    // Line 2: Calibration Type
                    //--------------------------------------------------------
                    if (status == QCOM_SUCCESS)
                    {
                        lineString = textReader->ReadLine()->Trim();
                        if (StringICompare(lineString, "Pressure") == 0)
                        {
                            format->calibration1Type = QCOM_CALIBRATION_TYPE_PRESSURE;
                            //------------------------------------------------
                            // line 3: Pressure Calibration Units
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            if (lineString->ToLower()->Contains("psi"))
                            {
                                format->scaleFactor1StdUnits = QCOM_ReverseFloatValue(
                                    (float) (1.0 / QCOM_UNIVERSAL_SCALE_FACTOR));
                                format->scaleFactor1AltUnits = QCOM_ReverseFloatValue(
                                    (float) (QCOM_BAR_PER_PSI / QCOM_UNIVERSAL_SCALE_FACTOR));
                            }
                            else
                            {
                                format->scaleFactor1StdUnits = QCOM_ReverseFloatValue(
                                    (float) (QCOM_BAR_PER_PSI / QCOM_UNIVERSAL_SCALE_FACTOR));
                                format->scaleFactor1AltUnits = QCOM_ReverseFloatValue(
                                    (float) (1.0 / QCOM_UNIVERSAL_SCALE_FACTOR));
                            }
                            format->offset1AlternateUnits = 0L;
                            //------------------------------------------------
                            // line 4: Temperature Polynomial Fit Order
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            format->temperature1FitOrder = AtoX(lineString[0]);
                            //------------------------------------------------
                            // Line 5: Temperature Prescale Algorithm
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            format->prescale2Type = AtoX(lineString[0]);
                            //------------------------------------------------
                            // Line 6: Temperature Scaling Factor
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            inputDouble = Convert::ToDouble(lineString);
                            if (inputDouble)
                                parameters.temperatureScalingFactor = inputDouble;
                            else
                                status = QCOM_ERROR_NATIVE_TSF_INVALID;
                            //------------------------------------------------
                            // Line 7: Temperature Offset Frequency
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            parameters.temperatureOffsetFrequency =
                                Convert::ToInt32(lineString);
                            //------------------------------------------------
                            // Line 8: Pressure Polynomial Fit Order
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            format->pressure1FitOrder = AtoX(lineString[0]);
                            parameters.numberOfPressureCoefficients =
                                (format->pressure1FitOrder + 1) * (format->temperature1FitOrder + 1);
                            //------------------------------------------------
                            // Line 9: Pressure Prescale Algorithm
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            format->prescale1Type = AtoX(lineString[0]);
                            //------------------------------------------------
                            // Line 10: Pressure Scaling Factor
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            inputDouble = Convert::ToDouble(lineString);
                            if (inputDouble)
                                parameters.pressureScalingFactor = inputDouble;
                            else
                                status = QCOM_ERROR_NATIVE_PSF_INVALID;
                            //------------------------------------------------
                            // Line 11: Pressure Offset Frequency
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            parameters.pressureOffsetFrequency =
                                Convert::ToInt32(lineString);
                            //------------------------------------------------
                            // Lines 12-27: Pressure Coefficients
                            //------------------------------------------------
                            for (int index = 0; index < parameters.numberOfPressureCoefficients; index++)
                            {
                                lineString = textReader->ReadLine()->Trim();
                                parameters.pressureInputCoefficients[index] =
                                    Convert::ToDouble(lineString);
                            }
                            //------------------------------------------------
                            // Line 28: Span
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            parameters.pressureSpan = Convert::ToDouble(lineString);
                            //------------------------------------------------
                            // Line 29: Zero
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            parameters.pressureZero = Convert::ToDouble(lineString);
                            //------------------------------------------------
                            // Line 30: Minimum Calibration Temperature
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            format->minimumTemperature = (char) (Convert::ToInt32(lineString) / 5);
                            //------------------------------------------------
                            // Line 31: Maximum Calibration Temperature
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            format->maximumTemperature = (char) (Convert::ToInt32(lineString) / 5);
                            //------------------------------------------------
                            // Line 32: Minimum Calibration Pressure
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            format->minimumPressure = (char) (Convert::ToInt32(lineString) / 1000);
                            //------------------------------------------------
                            // Line 33: Maximum Calibration Pressure
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            format->maximumPressure = (char) (Convert::ToInt32(lineString) / 1000);
                            //------------------------------------------------
                            // Line 34: Calibration Date
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            format->calibrationDate = (AtoX(lineString[0]) << 4) | AtoX(lineString[1]);
                            for (BYTE index = 1; index < 13; index++)
                            {
                                if (StringICompare(lineString->Substring(3, 3), QCOM_MonthStringArray[index]) == 0)
                                {
                                    format->calibrationMonth = ((index > 9) ? (index + 6) : index);
                                    break;
                                }
                            }
                            format->calibrationYear = (WORD)
                                (AtoX(lineString[9]) << 12) |
                                (AtoX(lineString[10]) << 8) |
                                (AtoX(lineString[7]) << 4) |
                                AtoX(lineString[8]);
                            //------------------------------------------------
                            // Line 35: Part Number
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            QCOM_ConvertString(
                                lineString->Substring(0, lineString->IndexOf('-')),
                                format->partNumber,
                                (lineString->IndexOf('-') + 1));
                        }               // end of if (StringICompare(lineString, "Pressure") == 0)
                        else
                        {
                            QCOM_PromptOKModal(functionName,
                                "File does not contain valid pressure coefficient data:\n{0}",
                                crfFilePath);
                            status = QCOM_ERROR_NATIVE_CAL_TYPE_INVALID;
                        }
                    }                   // end of if (status == QCOM_SUCCESS)
                    textReader->Close();
                }                       // end of if (textReader)
                //------------------------------------------------------------
                // Begin processing the .crt file
                //------------------------------------------------------------
                if (status == QCOM_SUCCESS)
                {
                    textReader = File::OpenText(crtFilePath);
                    if (textReader)
                    {
                        //----------------------------------------------------
                        // Line 1: Transducer Serial Number
                        //----------------------------------------------------
                        lineString = textReader->ReadLine()->Trim();
                        if ((lineString->Length) > 6 && (lineString[6] == 'R'))
                        {
                            int integerValue = 0;
                            for (int index = 4; index >= 0; index -= 2)
                            {
                                if (isdigit((BYTE) lineString[index]) && isdigit((BYTE) lineString[index + 1]))
                                {
                                    integerValue |= ((AtoX(lineString[index]) << 4) | AtoX(lineString[index + 1]));
                                    integerValue <<= 8;
                                }
                            }
                            if (integerValue)
                                integerValue |= QD_QUARTZDYNE_ID;
                            else
                                status = QCOM_ERROR_NATIVE_SN_INVALID;
                            if ((status == QCOM_SUCCESS) && (format->serialNumber != integerValue))
                                status = QCOM_ERROR_NATIVE_SN_MISMATCH;
                        }
                        else
                            status = QCOM_ERROR_NATIVE_SN_INVALID;
                        if (status == QCOM_SUCCESS)
                        {
                            //------------------------------------------------
                            // Line 2: Calibration Type
                            //------------------------------------------------
                            lineString = textReader->ReadLine()->Trim();
                            if (StringICompare(lineString, "Temperature") == 0)
                            {
                                format->calibration2Type = QCOM_CALIBRATION_TYPE_TEMPERATURE;
                                //--------------------------------------------
                                // Line 3: Temperature Calibration Units
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                if (lineString->Contains("C"))
                                {
                                    format->scaleFactor2StdUnits = QCOM_ReverseFloatValue(
                                        (float) (1.0 / QCOM_UNIVERSAL_SCALE_FACTOR));
                                    format->scaleFactor2AltUnits = QCOM_ReverseFloatValue(
                                        (float) ((9.0 / 5.0) / QCOM_UNIVERSAL_SCALE_FACTOR));
                                }
                                else
                                {
                                    format->scaleFactor2StdUnits = QCOM_ReverseFloatValue(
                                        (float) ((9.0 / 5.0) / QCOM_UNIVERSAL_SCALE_FACTOR));
                                    format->scaleFactor2AltUnits = QCOM_ReverseFloatValue(
                                        (float) (1.0 / QCOM_UNIVERSAL_SCALE_FACTOR));
                                }
                                format->offset2AlternateUnits = (DWORD)
                                    (float) Math::Round(((32.0 / (9.0 / 5.0)) * QCOM_UNIVERSAL_SCALE_FACTOR), 0);
                                format->offset2AlternateUnits = QCOM_ReverseIntegerValue(
                                    format->offset2AlternateUnits);
                                //--------------------------------------------
                                // Line 4: Temperature Polynomial Fit Order 
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                format->temperature2FitOrder = AtoX(lineString[0]);
                                //--------------------------------------------
                                // Line 5: Temperature Prescale Algorithm
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                if (AtoX(lineString[0]) != format->prescale2Type)
                                    status = QCOM_ERROR_NATIVE_TALG_MISMATCH;
                                //--------------------------------------------
                                // Line 6: Temperature Scaling Factor
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                inputDouble = Convert::ToDouble(lineString);
                                if (inputDouble != parameters.temperatureScalingFactor)
                                    status = QCOM_ERROR_NATIVE_TSF_MISMATCH;
                                //--------------------------------------------
                                // Line 7: Temperature Offset Frequency
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                if (Convert::ToInt32(lineString) != parameters.temperatureOffsetFrequency)
                                    status = QCOM_ERROR_NATIVE_TOF_MISMATCH;
                                //--------------------------------------------
                                // Line 8: Pressure Polynomial Fit Order
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                format->pressure2FitOrder = AtoX(lineString[0]);
                                parameters.numberOfTemperatureCoefficients =
                                    (format->pressure2FitOrder + 1) * (format->temperature2FitOrder + 1);
                                //--------------------------------------------
                                // Line 9: Pressure Prescale Algorithm
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                if (AtoX(lineString[0]) != format->prescale1Type)
                                    status = QCOM_ERROR_NATIVE_PALG_MISMATCH;
                                //--------------------------------------------
                                // Line 10: Pressure Scaling Factor
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                inputDouble = Convert::ToDouble(lineString);
                                if (inputDouble != parameters.pressureScalingFactor)
                                    status = QCOM_ERROR_NATIVE_PSF_MISMATCH;
                                //--------------------------------------------
                                // Line 11: Pressure Offset Frequency
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                if (Convert::ToInt32(lineString) != parameters.pressureOffsetFrequency)
                                    status = QCOM_ERROR_NATIVE_POF_MISMATCH;
                                //--------------------------------------------
                                // Lines 12-15: Temperature Coefficients
                                //--------------------------------------------
                                for (int index = 0; index < parameters.numberOfTemperatureCoefficients; index++)
                                {
                                    lineString = textReader->ReadLine()->Trim();
                                    parameters.temperatureInputCoefficients[index] =
                                        Convert::ToDouble(lineString);
                                }
                                //--------------------------------------------
                                // Line 16: Span
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                parameters.temperatureSpan = Convert::ToDouble(lineString);
                                if (parameters.temperatureSpan != parameters.pressureSpan)
                                    status = QCOM_ERROR_NATIVE_SPAN_MISMATCH;
                                //--------------------------------------------
                                // Line 17: Zero
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                parameters.temperatureZero = Convert::ToDouble(lineString);
                                if (parameters.temperatureZero != parameters.pressureZero)
                                    status = QCOM_ERROR_NATIVE_ZERO_MISMATCH;
                                //--------------------------------------------
                                // Line 18: Minimum Calibration Temperature
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                if (((char) (Convert::ToInt32(lineString) / 5)) != format->minimumTemperature)
                                    status = QCOM_ERROR_NATIVE_MINT_MISMATCH;
                                //--------------------------------------------
                                // Line 19: Maximum Calibration Temperature
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                if (((char) (Convert::ToInt32(lineString) / 5)) != format->maximumTemperature)
                                    status = QCOM_ERROR_NATIVE_MAXT_MISMATCH;
                                //--------------------------------------------
                                // Line 20: Minimum Calibration Pressure
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                if (((char) (Convert::ToInt32(lineString) / 1000)) != format->minimumPressure)
                                    status = QCOM_ERROR_NATIVE_MINP_MISMATCH;
                                //--------------------------------------------
                                // Line 21: Maximum Calibration Pressure
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                if (((char) (Convert::ToInt32(lineString) / 1000)) != format->maximumPressure)
                                    status = QCOM_ERROR_NATIVE_MAXP_MISMATCH;
                                //--------------------------------------------
                                // Line 22: Calibration Date
                                //--------------------------------------------
                                BYTE monthNumber = 0;
                                lineString = textReader->ReadLine()->Trim();
                                if (((AtoX(lineString[0]) << 4) | AtoX(lineString[1])) != format->calibrationDate)
                                    status = QCOM_ERROR_NATIVE_DATE_MISMATCH;
                                for (BYTE index = 1; index < 13; index++)
                                {
                                    if (StringICompare(lineString->Substring(3, 3), QCOM_MonthStringArray[index]) == 0)
                                    {
                                        if (index > 9)
                                            index += 6;
                                        monthNumber = index;
                                        break;
                                    }
                                }
                                if (monthNumber != format->calibrationMonth)
                                    status = QCOM_ERROR_NATIVE_DATE_MISMATCH;
                                if (((WORD) ((AtoX(lineString[9]) << 12) | (AtoX(lineString[10]) << 8) | (AtoX(lineString[7]) << 4) | AtoX(lineString[8]))) !=
                                    format->calibrationYear)
                                    status = QCOM_ERROR_NATIVE_DATE_MISMATCH;
                                //--------------------------------------------
                                // Line 23: Part Number
                                //--------------------------------------------
                                lineString = textReader->ReadLine()->Trim();
                                char partNumber[8];
                                ClearBuffer(partNumber, 8);
                                QCOM_ConvertString(
                                    lineString->Substring(0, lineString->IndexOf('-')),
                                    partNumber,
                                    (lineString->IndexOf('-') + 1));
                                if (memcmp(partNumber, format->partNumber, Min((strlen(partNumber) + 1), 8)))
                                    status = QCOM_ERROR_NATIVE_PN_MISMATCH;
                                //--------------------------------------------
                                // Calculate the actual coefficients
                                //--------------------------------------------
                                if (status == QCOM_SUCCESS)
                                {
                                    status = QCOM_FormulateNativeCoefficients(
                                        format,
                                        &parameters);
                                }
                            }           // end of if (StringICompare(lineString, "Temperature") == 0)
                            else
                            {
                                QCOM_PromptOKModal(functionName,
                                    "File does not contain valid temperature coefficient data:\n{0}",
                                    crtFilePath);
                                status = QCOM_ERROR_NATIVE_CAL_TYPE_INVALID;
                            }
                        }               // end of if (status == QCOM_SUCCESS)
                        else
                        {
                            QCOM_PromptOKModal(functionName,
                                "File does not contain valid temperature coefficient data:\n{0}",
                                crtFilePath);
                        }
                        textReader->Close();
                    }                   // end of if (textReader)
                }                       // end of if (status == QCOM_SUCCESS)
            }                           // end of if (File::Exists(crfFilePath) && File::Exists(crtFilePath))
            else
            {
                if (!File::Exists(crfFilePath))
                {
                    QCOM_PromptOKModal(functionName,
                        "Unable to locate required file\n{0}",
                        crfFilePath);
                }
                if (!File::Exists(crtFilePath))
                {
                    QCOM_PromptOKModal(functionName,
                        "Unable to locate required file\n{0}",
                        crtFilePath);
                }
                status = QCOM_ERROR_NATIVE_FILE_NOT_FOUND;
            }
            if (status == QCOM_SUCCESS)
            {
                //------------------------------------------------------------
                // Apply the end-of-file marker
                //------------------------------------------------------------
                format->endOfFile[0] = 0xFF;
                //------------------------------------------------------------
                // Calculate the checksum
                //------------------------------------------------------------
                for (int index = checksum = 0; index < sizeof(CoefficientFormatDef) - 1; index++)
                {
                    checksum += (BYTE) coefficientBytes[index];
                }
                format->checksum = (~checksum + 1) & 0xFF;
                QCOM_RecordAndModalEventByFlags(
                    QCOM_EventLogBasicEnabled,
                    QCOM_VerboseMessagesEnabled,
                    functionName,
                    "Read in native coefficient data file\n{0}",
                    filePathString);
            }
            else
            {
                ClearBuffer(format, sizeof(CoefficientFormatDef));
            }
        }                               // end of else of if (filePathString->ToLower()->EndsWith(".hex"))
    }                                   // end of if (StringSet(filePathString) && ...)
    else
    {
        if (filePathString && coefficientData)
        {
            status = QD_ERROR_ZERO_LENGTH_STRING_PARAMETER;                     // 0x0000002B
        }
        else
        {
            status = QD_ERROR_NULL_POINTER_PARAMETER;                           // 0x0000002A
        }
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of QCOM_ReadCoefficientDataFromFile()
//----------------------------------------------------------------------------
// QCOM_RetrieveCoefficientData
//
// Retrieves the coefficient data for client storage, to be used for readings
//
// Returns: 0           Success
//          nonzero     Failure
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_RetrieveCoefficientData(
    UnitInfo        ^unit)
{
    bool            tryGettingCFDataFromModule = GUI_NO;
    DWORD           status = QCOM_FAILURE;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_RetrieveCoefficientData");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Test for a digital transducer with memory
        //--------------------------------------------------------------------
        if (unit->transducerType &&
            (unit->transducerType != QD_TRANSDUCER_TYPE_FREQUENCY) &&
            (unit->transducerType != QD_TRANSDUCER_TYPE_DIGITAL_NOMEM))
        {
            //----------------------------------------------------------------
            // Make an attempt to retrieve the coefficient data from the
            // digital transducer
            //----------------------------------------------------------------
            status = QD_ReadCoefficientDataFromDevice(
                unit->unitHandle,
                (LPBYTE) unit->coefficientData);
            if (status == QD_SUCCESS)
            {
                if (QD_CoefficientDataIsValid((LPBYTE) unit->coefficientData))
                {
                    unit->flags |=
                        QCOM_UNIT_COEFFICIENTS_VERIFIED;
                    QCOM_ApplyCoefficientDataInfoToProgram(unit);
                    RecordVerboseEvent(
                        "    Coefficient verification completed successfully for {0}",
                        unit->transducerSerialNumber);
                }
                else
                {
                    //--------------------------------------------------------
                    // The data read from digital transducer memory is invalid,
                    // so attempt retrieving it from the module
                    //--------------------------------------------------------
                    status = QD_ERROR_INVALID_COEFFICIENT_DATA;                 // 0x00000040
                    tryGettingCFDataFromModule = GUI_YES;
                    RecordErrorEvent(
                        "    Invalid coefficient data read from digital transducer");
                }
            }       // end of if (status == QD_SUCCESS)
            else
            {
                //------------------------------------------------------------
                // Received an error when attempting to retrieve coefficient
                // data from the digital transducer, so attempt retrieving it
                // from the module
                //------------------------------------------------------------
                tryGettingCFDataFromModule = GUI_YES;
                RecordErrorEvent(
                    "    Unable to read coefficient data (status 0x{0:X8}) from digital transducer",
                    status);
            }
        }                               // end of if (transducerType && ...)
        else
        {
            //----------------------------------------------------------------
            // This is a frequency transducer or a digital transducer with no
            // memory, so attempt retrieving the coefficient data from the
            // module
            //----------------------------------------------------------------
            tryGettingCFDataFromModule = GUI_YES;
        }
        if (tryGettingCFDataFromModule)
        {
            //----------------------------------------------------------------
            // Make an attempt to retrieve the coefficient data from the first
            // available module memory page that contains valid coefficient
            // data
            //----------------------------------------------------------------
            for (BYTE pageNumber = 0; pageNumber < QD_NUMBER_OF_LOWER_QMEM_PAGES; pageNumber++)
            {
                status = QD_ReadCoefficientDataFromModulePage(
                    unit->unitHandle,
                    pageNumber,
                    (LPBYTE) unit->coefficientData);
                if (status == QD_SUCCESS)
                {
                    if (QD_CoefficientDataIsValid((LPBYTE) unit->coefficientData))
                        break;
                    else
                    {
                        status = QD_ERROR_INVALID_COEFFICIENT_DATA;
                        RecordErrorEvent("    Invalid coefficient data in page {0:D}",
                            pageNumber);
                    }
                }
                else
                {
                    RecordErrorEvent("    QD_ReadCoefficientDataFromModulePage({0:D}) returned 0x{1:X8}",
                        pageNumber, status);
                }
            }
            if (status == QD_SUCCESS)
            {
                unit->flags |=
                    QCOM_UNIT_COEFFICIENTS_VERIFIED;
                QCOM_ApplyCoefficientDataInfoToProgram(unit);
                RecordVerboseEvent(
                    "    Module {0} coefficient data verified",
                    unit->moduleSerialNumber);
            }
            else
            {
                RecordErrorEvent(
                    "    Error 0x{0:X8} retrieving coefficient data from module {1}",
                    status, unit->moduleSerialNumber);
            }
        }       // end of if (tryGettingCFDataFromModule)
        RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return status;
}                                       // end of QCOM_RetrieveCoefficientData()
//----------------------------------------------------------------------------
// QCOM_RetrieveCoefficientFileParameters
//
// Retrieves the coefficient file parameter strings for the specified
// transducer serial number
//
// Called by:   QCOM_PromptForRetrieveCoefficientFileParameters
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_RetrieveCoefficientFileParameters(
    String          ^filePathString,
    array <String ^>
                    ^coefficientParametersList)
{
    bool            fileLocated = GUI_NO;
    bool            littleEndianFloats = GUI_NO;
    bool            proceedToIdentify = GUI_NO;
    int             index;
    int             fileType = QCOM_CF_FILE_TYPE_UNKNOWN;
    int             intValue;
    int             numberOfCoefficients;
    int             numericValue = 0;
    int             pressureOrder;
    int             temperatureOrder;
    float           floatValue;
    DWORD           coefficientOffset;
    DWORD           status = QCOM_SUCCESS;
    BYTE            *coefficientData;
    CoefficientFormatDef
                    *format;
    StreamReader    ^textReader;
    String          ^lineString;
    String          ^parameterString;
    String          ^primaryCalType;
    String          ^secondaryCalType;
    String          ^functionName = _T("QCOM_RetrieveCoefficientFileParameters");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (filePathString && StringSet(coefficientParametersList))
    {
        if (StringSet(filePathString))
        {
            if (File::Exists(filePathString))
            {
                fileLocated = GUI_YES;
                proceedToIdentify = GUI_YES;
            }
            else
            {
                status = QCOM_ERROR_FILE_NOT_FOUND;
            }
        }
        else
        {
            status = QCOM_ERROR_ZERO_LENGTH_STRING_PARAMETER;
        }
        if (proceedToIdentify)
        {
            //----------------------------------------------------------------
            // A file path string is identified, so determine its file type
            //----------------------------------------------------------------
            if (filePathString->ToLower()->EndsWith(".hex"))
                fileType = QCOM_CF_FILE_TYPE_HEX;                               // 1
            if (filePathString->ToLower()->EndsWith(".crf"))
                fileType = QCOM_CF_FILE_TYPE_CRF;                               // 2
            if (filePathString->ToLower()->EndsWith(".crt"))
                fileType = QCOM_CF_FILE_TYPE_CRT;                               // 3
            if (filePathString->ToLower()->EndsWith(".cff"))
                fileType = QCOM_CF_FILE_TYPE_CFF;                               // 4
            if (filePathString->ToLower()->EndsWith(".cft"))
                fileType = QCOM_CF_FILE_TYPE_CFT;                               // 5
            if (filePathString->ToLower()->EndsWith(".cof2"))
                fileType = QCOM_CF_FILE_TYPE_COF2;                              // 6
            if (fileType == QCOM_CF_FILE_TYPE_UNKNOWN)
            {
                status = QCOM_ERROR_INVALID_FILE_NAME;
            }
        }
        if (fileLocated)
        {
            //----------------------------------------------------------------
            // The coefficient file is located, so open it and search it
            //----------------------------------------------------------------
            switch (fileType)
            {
                case QCOM_CF_FILE_TYPE_HEX :
                    //--------------------------------------------------------
                    // If the coefficient file is a hex file, first read it in
                    // and convert it to actual coefficient file data
                    //--------------------------------------------------------
                    coefficientData = (BYTE *) malloc(sizeof(CoefficientFormatDef));
                    if (coefficientData)
                    {
                        ClearBuffer(coefficientData, sizeof(CoefficientFormatDef));
                        format = (CoefficientFormatDef *) coefficientData;
                        status = QCOM_ReadCoefficientDataFromFile(
                            filePathString,
                            format);
                        if (status == QCOM_SUCCESS)
                        {
                            if (format->fileType == QD_QUARTZDYNE_CF_TYPE_LITTLE_ENDIAN)
                                littleEndianFloats = GUI_YES;
                            switch (format->calibration1Type)
                            {
                                case 0x01 : primaryCalType = _T("Pressure"); break;
                                case 0x02 : primaryCalType = _T("Temperature"); break;
                                default : primaryCalType = QCOM_STRING_UNKNOWN; break;
                            }
                            switch (format->calibration2Type)
                            {
                                case 0x01 : secondaryCalType = _T("Pressure"); break;
                                case 0x02 : secondaryCalType = _T("Temperature"); break;
                                default : secondaryCalType = QCOM_STRING_UNKNOWN; break;
                            }
                            for (int lineNumber = 0; lineNumber < (coefficientParametersList->Length - 1); lineNumber++)
                            {
                                switch (lineNumber)
                                {
                                    case QCOM_HCF_PARAMETER_XD_SERIAL_NUMBER :      // 0
                                        //----------------------------------------
                                        // Interpret the bytes from the big-endian
                                        // value into a string 0x5634120D => "123456"
                                        //----------------------------------------
                                        parameterString = String::Format(
                                            "{0:X2}{1:X2}{2:X2}",
                                            coefficientData[5], coefficientData[6], coefficientData[7]);
                                        break;
                                    case QCOM_HCF_PARAMETER_XD_MODEL :              // 1
                                        parameterString = gcnew String(format->partNumber);
                                        break;
                                    case QCOM_HCF_PARAMETER_CAL_DATE :              // 2
                                        index = (int)
                                            ((format->calibrationMonth > 9) ?
                                                (format->calibrationMonth - 6) : format->calibrationMonth);
                                        parameterString = String::Format(
                                            "{0:X2} {1} {2:X2}{3:X2}",
                                            format->calibrationDate,
                                            QCOM_MonthStringArray[index],
                                            coefficientData[16], coefficientData[17]);
                                        break;
                                    case QCOM_HCF_PARAMETER_PRES_MIN :              // 3
                                        parameterString = String::Concat(
                                            (1000 * format->minimumPressure), _T(" psi"));
                                        break;
                                    case QCOM_HCF_PARAMETER_PRES_MAX :              // 4
                                        parameterString = String::Concat(
                                            (1000 * format->maximumPressure), _T(" psi"));
                                        break;
                                    case QCOM_HCF_PARAMETER_TEMP_MIN :              // 5
                                        parameterString = String::Concat(
                                            (5 * format->minimumTemperature), _T(" �C"));
                                        break;
                                    case QCOM_HCF_PARAMETER_TEMP_MAX :              // 6
                                        {
                                            //----------------------------------------------------------------
                                            // Because the maximum temperature value is stored in integer
                                            // multiples of 5 degrees, the temperature value for transducers
                                            // whose maximum rated temperature is specifically 177 �C is
                                            // stored as 35, which corresponds to 175 �C, so set it to exactly
                                            // 177 when a value of 175 is encountered
                                            //----------------------------------------------------------------
                                            DWORD actualTemperature = format->maximumTemperature * 5;
                                            if (actualTemperature == 175)
                                                actualTemperature = 177;
                                            parameterString = String::Concat(
                                                actualTemperature, _T(" �C"));
                                        }
                                        break;
                                    case QCOM_HCF_PARAMETER_PRIMARY_CAL_TYPE :      // 7
                                        parameterString = primaryCalType;
                                        break;
                                    case QCOM_HCF_PARAMETER_PRES_PRESCALE_TYPE :    // 8
                                        parameterString = String::Format(
                                            "{0:D}",
                                            (BYTE) format->prescale1Type);
                                        break;
                                    case QCOM_HCF_PARAMETER_PRES_POLY_ORDER_PRES :  // 9
                                        parameterString = String::Format(
                                            "{0:D}",
                                            (BYTE) format->pressure1FitOrder);
                                        break;
                                    case QCOM_HCF_PARAMETER_PRES_POLY_ORDER_TEMP :  // 10
                                        parameterString = String::Format(
                                            "{0:D}",
                                            (BYTE) format->temperature1FitOrder);
                                        break;
                                    case QCOM_HCF_PARAMETER_PRES_SCALE_FACTOR_STD : // 11
                                        if (littleEndianFloats)
                                            floatValue = format->scaleFactor1StdUnits;
                                        else
                                            floatValue = QCOM_ReverseFloatValue(format->scaleFactor1StdUnits);
                                        parameterString = String::Format(
                                            "{0:F1} psi",
                                            (floatValue * QCOM_UNIVERSAL_SCALE_FACTOR));
                                        break;
                                    case QCOM_HCF_PARAMETER_PRES_SCALE_FACTOR_ALT : // 12
                                        if (littleEndianFloats)
                                            floatValue = format->scaleFactor1AltUnits;
                                        else
                                            floatValue = QCOM_ReverseFloatValue(format->scaleFactor1AltUnits);
                                        parameterString = String::Format(
                                            "{0:F7} bar",
                                            (floatValue * QCOM_UNIVERSAL_SCALE_FACTOR));
                                        break;
                                    case QCOM_HCF_PARAMETER_PRES_ALT_OFFSET :       // 13
                                        intValue = format->offset1AlternateUnits;
                                        if (littleEndianFloats)
                                            floatValue = (float) intValue;
                                        else
                                            floatValue = (float) QCOM_ReverseIntegerValue(intValue);
                                        parameterString = String::Format(
                                            "{0:F3} psi",
                                            (floatValue / QCOM_UNIVERSAL_SCALE_FACTOR));
                                        break;
                                    case QCOM_HCF_PARAMETER_SECONDARY_CAL_TYPE :    // 39
                                        parameterString = secondaryCalType;
                                        break;
                                    case QCOM_HCF_PARAMETER_TEMP_PRESCALE_TYPE :    // 40
                                        parameterString = String::Format(
                                            "{0:D}",
                                            (BYTE) format->prescale2Type);
                                        break;
                                    case QCOM_HCF_PARAMETER_TEMP_POLY_ORDER_PRES :  // 41
                                        parameterString = String::Format(
                                            "{0:D}",
                                            (BYTE) format->pressure2FitOrder);
                                        break;
                                    case QCOM_HCF_PARAMETER_TEMP_POLY_ORDER_TEMP :  // 42
                                        parameterString = String::Format(
                                            "{0:D}",
                                            (BYTE) format->temperature2FitOrder);
                                        break;
                                    case QCOM_HCF_PARAMETER_TEMP_SCALE_FACTOR_STD : // 43
                                        if (littleEndianFloats)
                                            floatValue = format->scaleFactor2StdUnits;
                                        else
                                            floatValue = QCOM_ReverseFloatValue(format->scaleFactor2StdUnits);
                                        parameterString = String::Format(
                                            "{0:F1} �C",
                                            (floatValue * QCOM_UNIVERSAL_SCALE_FACTOR));
                                        break;
                                    case QCOM_HCF_PARAMETER_TEMP_SCALE_FACTOR_ALT : // 44
                                        if (littleEndianFloats)
                                            floatValue = format->scaleFactor2AltUnits;
                                        else
                                            floatValue = QCOM_ReverseFloatValue(format->scaleFactor2AltUnits);
                                        parameterString = String::Format(
                                            "{0:F1} �F",
                                            (floatValue * QCOM_UNIVERSAL_SCALE_FACTOR));
                                        break;
                                    case QCOM_HCF_PARAMETER_TEMP_ALT_OFFSET :       // 45
                                        intValue = format->offset2AlternateUnits;
                                        if (littleEndianFloats)
                                            floatValue = (float) intValue;
                                        else
                                            floatValue = (float) QCOM_ReverseIntegerValue(intValue);
                                        parameterString = String::Format(
                                            "{0:F3} �C",
                                            (floatValue / QCOM_UNIVERSAL_SCALE_FACTOR));
                                        break;
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_0 :          // 14
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_1 :          // 15
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_2 :          // 16
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_3 :          // 17
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_4 :          // 18
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_5 :          // 19
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_6 :          // 20
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_7 :          // 21
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_8 :          // 22
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_9 :          // 23
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_10 :         // 24
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_11 :         // 25
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_12 :         // 26
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_13 :         // 27
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_14 :         // 28
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_15 :         // 29
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_16 :         // 30
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_17 :         // 31
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_18 :         // 32
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_19 :         // 33
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_20 :         // 34
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_21 :         // 35
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_22 :         // 36
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_23 :         // 37
                                    case QCOM_HCF_PARAMETER_PRES_COEFF_24 :         // 38
                                        coefficientOffset =
                                            (lineNumber - QCOM_HCF_PARAMETER_PRES_COEFF_0) * 4;
                                        if (littleEndianFloats)
                                        {
                                            intValue = (int)
                                                (((format->coefficients1[coefficientOffset + 3] << 24) & 0xFF000000) |
                                                 ((format->coefficients1[coefficientOffset + 2] << 16) & 0x00FF0000) |
                                                 ((format->coefficients1[coefficientOffset + 1] << 8) & 0x0000FF00) |
                                                 ((format->coefficients1[coefficientOffset] & 0x000000FF)));
                                            floatValue = (float) intValue;
                                            parameterString = String::Format(
                                                ((floatValue > 10e10) ?
                                                    "{0:X2} {1:X2} {2:X2} {3:X2}  =  {4:E6}" :
                                                    "{0:X2} {1:X2} {2:X2} {3:X2}  =  {4:F0}"),
                                                (BYTE) format->coefficients1[coefficientOffset + 3],
                                                (BYTE) format->coefficients1[coefficientOffset + 2],
                                                (BYTE) format->coefficients1[coefficientOffset + 1],
                                                (BYTE) format->coefficients1[coefficientOffset],
                                                floatValue);
                                        }
                                        else
                                        {
                                            intValue = (int)
                                                (((format->coefficients1[coefficientOffset] << 24) & 0xFF000000) |
                                                 ((format->coefficients1[coefficientOffset + 1] << 16) & 0x00FF0000) |
                                                 ((format->coefficients1[coefficientOffset + 2] << 8) & 0x0000FF00) |
                                                 ((format->coefficients1[coefficientOffset + 3] & 0x000000FF)));
                                            floatValue = (float) intValue;
                                            parameterString = String::Format(
                                                ((floatValue > 10e10) ?
                                                    "{0:X2} {1:X2} {2:X2} {3:X2}  =  {4:E6}" :
                                                    "{0:X2} {1:X2} {2:X2} {3:X2}  =  {4:F0}"),
                                                (BYTE) format->coefficients1[coefficientOffset],
                                                (BYTE) format->coefficients1[coefficientOffset + 1],
                                                (BYTE) format->coefficients1[coefficientOffset + 2],
                                                (BYTE) format->coefficients1[coefficientOffset + 3],
                                                floatValue);
                                        }
                                        break;
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_0 :          // 46
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_1 :          // 47
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_2 :          // 48
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_3 :          // 49
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_4 :          // 50
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_5 :          // 51
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_6 :          // 52
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_7 :          // 53
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_8 :          // 54
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_9 :          // 55
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_10 :         // 56
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_11 :         // 57
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_12 :         // 58
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_13 :         // 59
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_14 :         // 60
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_15 :         // 61
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_16 :         // 62
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_17 :         // 63
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_18 :         // 64
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_19 :         // 65
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_20 :         // 66
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_21 :         // 67
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_22 :         // 68
                                    case QCOM_HCF_PARAMETER_TEMP_COEFF_23 :         // 69
                                        coefficientOffset =
                                            (lineNumber - QCOM_HCF_PARAMETER_TEMP_COEFF_0) * 4;
                                        if (littleEndianFloats)
                                        {
                                            intValue = (int)
                                                (((format->coefficients2[coefficientOffset + 3] << 24) & 0xFF000000) |
                                                 ((format->coefficients2[coefficientOffset + 2] << 16) & 0x00FF0000) |
                                                 ((format->coefficients2[coefficientOffset + 1] << 8) & 0x0000FF00) |
                                                 ((format->coefficients2[coefficientOffset] & 0x000000FF)));
                                            floatValue = (float) intValue;
                                            parameterString = String::Format(
                                                ((floatValue > 10e10) ?
                                                    "{0:X2} {1:X2} {2:X2} {3:X2}  =  {4:E6}" :
                                                    "{0:X2} {1:X2} {2:X2} {3:X2}  =  {4:F0}"),
                                                (BYTE) format->coefficients2[coefficientOffset + 3],
                                                (BYTE) format->coefficients2[coefficientOffset + 2],
                                                (BYTE) format->coefficients2[coefficientOffset + 1],
                                                (BYTE) format->coefficients2[coefficientOffset],
                                                floatValue);
                                        }
                                        else
                                        {
                                            intValue = (int)
                                                (((format->coefficients2[coefficientOffset] << 24) & 0xFF000000) |
                                                 ((format->coefficients2[coefficientOffset + 1] << 16) & 0x00FF0000) |
                                                 ((format->coefficients2[coefficientOffset + 2] << 8) & 0x0000FF00) |
                                                 ((format->coefficients2[coefficientOffset + 3] & 0x000000FF)));
                                            floatValue = (float) intValue;
                                            parameterString = String::Format(
                                                ((floatValue > 10e10) ?
                                                    "{0:X2} {1:X2} {2:X2} {3:X2}  =  {4:E6}" :
                                                    "{0:X2} {1:X2} {2:X2} {3:X2}  =  {4:F0}"),
                                                (BYTE) format->coefficients2[coefficientOffset],
                                                (BYTE) format->coefficients2[coefficientOffset + 1],
                                                (BYTE) format->coefficients2[coefficientOffset + 2],
                                                (BYTE) format->coefficients2[coefficientOffset + 3],
                                                floatValue);
                                        }
                                        break;
                                    default :
                                        status = QCOM_ERROR_INVALID_PARAMETER;      // 0x0006
                                        ModalB("Encountered illegal line {0:D}", lineNumber);
                                        break;
                                }       // end of switch (lineNumber)
                                coefficientParametersList[lineNumber] = parameterString;
                            }           // end of for (int lineNumber = 0; ...)
                        }               // end of if (status == QCOM_SUCCESS)
                        free((void *) coefficientData);
                    }                   // end of if (coefficientData)
                    else
                    {
                        status = QCOM_ERROR_MEMORY_ALLOCATION_FAILED;               // 0x0014
                    }
                    break;
                case QCOM_CF_FILE_TYPE_CRF :
                case QCOM_CF_FILE_TYPE_CRT :
                case QCOM_CF_FILE_TYPE_CFF :
                case QCOM_CF_FILE_TYPE_CFT :
                    //--------------------------------------------------------
                    // This is a native coefficient data file, so determine how
                    // many coefficients are actually listed in the file, check
                    // for errors, then jump down to the requested line and read it
                    //--------------------------------------------------------
                    textReader = File::OpenText(filePathString);
                    if (textReader)
                    {
                        int lineNumber;
                        //----------------------------------------------------
                        // Skip to line 4 and retrieve the temperature
                        // polynomial order
                        //----------------------------------------------------
                        lineNumber = 4;
                        while (lineNumber--)
                        {
                            lineString = textReader->ReadLine();
                        }
                        temperatureOrder = Convert::ToInt32(lineString->Trim(), 16);
                        //----------------------------------------------------
                        // Skip to line 8 (4 more) and retrieve the pressure
                        // polynomial order
                        //----------------------------------------------------
                        lineNumber = 4;
                        while (lineNumber--)
                        {
                            lineString = textReader->ReadLine();
                        }
                        pressureOrder = Convert::ToInt32(lineString->Trim(), 16);
                        numberOfCoefficients = ((temperatureOrder + 1) * (pressureOrder + 1));
                        textReader->Close();
                    }
                    textReader = File::OpenText(filePathString);
                    if (textReader)
                    {
                        if (status == QCOM_SUCCESS)
                        {
                            //------------------------------------------------
                            // Skip to the appropriate line and retrieve its
                            // string
                            //------------------------------------------------
                            for (int lineNumber = 0; lineNumber < (coefficientParametersList->Length - 1); lineNumber++)
                            {
                                lineString = textReader->ReadLine();
                                coefficientOffset =
                                    (lineNumber > (QCOM_NCF_PARAMETER_PRES_OFFSET_FREQ + numberOfCoefficients)) ?
                                        lineNumber + (25 - numberOfCoefficients) :
                                        lineNumber;
                                switch (coefficientOffset)
                                {
                                    case QCOM_NCF_PARAMETER_CAL_UNITS :         // 2
                                        if (lineString->Contains("C"))
                                            parameterString = _T("�C");
                                        else
                                            parameterString = lineString;
                                        break;
                                    case QCOM_NCF_PARAMETER_TEMP_OFFSET_FREQ :  // 6
                                    case QCOM_NCF_PARAMETER_PRES_OFFSET_FREQ :  // 10
                                        parameterString = String::Concat(
                                            lineString, " Hz");
                                        break;
                                    case QCOM_NCF_PARAMETER_TEMP_MIN :          // 38
                                    case QCOM_NCF_PARAMETER_TEMP_MAX :          // 39
                                        parameterString = String::Concat(
                                            lineString, " �C");
                                        break;
                                    case QCOM_NCF_PARAMETER_PRES_MIN :          // 40
                                    case QCOM_NCF_PARAMETER_PRES_MAX :          // 41
                                        parameterString = String::Concat(
                                            lineString, " psi");
                                        break;
                                    default :
                                        if ((coefficientOffset >= QCOM_NCF_PARAMETER_COEFF_0) &&
                                            (coefficientOffset <= QCOM_NCF_PARAMETER_COEFF_24))
                                            parameterString = lineString->ToLower();
                                        else
                                            parameterString = lineString;
                                        break;
                                }       // end of switch (coefficientOffset)
                                coefficientParametersList[lineNumber] = parameterString;
                            }           // end of for (int lineNumber = 0; ...)
                        }               // end of if (status == QCOM_SUCCESS)
                        textReader->Close();
                    }                   // end of if (textReader)
                    else
                    {
                        status = QCOM_ERROR_FILE_OPEN_FAILURE;                  // 0x0015
                    }
                    break;
                case QCOM_CF_FILE_TYPE_COF2 :
                default :
                    QCOM_PromptOKModal(functionName,
                        "Files with the {0} extension are not\ncurrently supported",
                        Path::GetExtension(filePathString->ToUpper()));
                    break;
            }                           // end of switch (fileType)
        }                               // end of if (fileLocated)
    }                                   // end of if (filePathString && StringSet(coefficientParametersList))
    else
    {
        if (filePathString)
            status = QCOM_ERROR_INVALID_PARAMETER;                              // 0x00000006
        else
            status = QCOM_ERROR_NULL_POINTER_PARAMETER;                         // 0x0000002A
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of QCOM_RetrieveCoefficientFileParameters()
//----------------------------------------------------------------------------
// QCOM_SearchForCoefficientFile
//
// Searches the database for the calibration number associated with the
// specified transducer serial number, then searches the file system in the
// resulting calibration directories for the filename derived from the serial
// number, and returns the path of the file with the latest date-and-time
// stamp if more than one is found
//
// Returns: GUI_YES or GUI_NO
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_SearchForCoefficientFile(
    String          ^serialNumberString,
    StringBuilder   ^filePathBuilder)
{
    bool            allowConnection = GUI_NO;
    bool            calDirectoryFound = GUI_NO;
    bool            dbFileFound = GUI_NO;
    bool            fileLocationIdentifiedByDataBase = GUI_NO;
    bool            fileLocated = GUI_NO;
    bool            networkLocated = GUI_NO;
    bool            proceedWithSearch = GUI_NO;
    String          ^calibrationDirectory = QUARTZDYNE_CAL_DATA_FOLDER;
    String          ^connectionString;
    String          ^dbPathString = QUARTZDYNE_CONFIDENTIAL_ROOT QUARTZDYNE_CALSUM_DB_FILE_PATH;
    String          ^fileName;
    String          ^promptString;
    String          ^targetFilePath;
    String          ^functionName = _T("QCOM_SearchForCoefficientFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(serialNumberString) && filePathBuilder)
    {
        RecordVerboseEvent("    Searching for S/N {0}", serialNumberString);
        //--------------------------------------------------------------------
        // Search the network, if present, for the calibration data directory
        // and the CALSUM database file
        //--------------------------------------------------------------------
        if (Directory::Exists(calibrationDirectory))
        {
            calDirectoryFound = GUI_YES;
        }
        if (File::Exists(dbPathString))
        {
            dbFileFound = GUI_YES;
        }
        if (calDirectoryFound && dbFileFound)
        {
            networkLocated = GUI_YES;
        }
        else
        {
            array <DriveInfo ^> ^driveInfo = DriveInfo::GetDrives();
            for each (DriveInfo ^oneDrive in driveInfo)
            {
                if (oneDrive->DriveType == DriveType::Network)
                {
                    networkLocated = GUI_YES;
                    String ^dirStr = String::Concat(oneDrive->Name, calibrationDirectory);
                    if (Directory::Exists(dirStr))
                    {
                        calibrationDirectory = String::Concat(
                            oneDrive->Name, calibrationDirectory);
                        calDirectoryFound = GUI_YES;
                    }
                    dbPathString = String::Concat(
                        oneDrive->Name, QUARTZDYNE_CALSUM_DB_FILE_PATH);
                    if (File::Exists(dbPathString))
                    {
                        dbFileFound = GUI_YES;
                    }
                }
            }
        }                               // end of else of if (calDirectoryFound && dbFileFound)
        if (networkLocated)
        {
            if (dbFileFound)
            {
                allowConnection = GUI_YES;
                //------------------------------------------------------------
                // The following connection string, which uses a drive mapping
                // to the network server and directory that contains the
                // database file, is the preferred method for speed
                //------------------------------------------------------------
                connectionString = String::Concat(
                    "Driver={Microsoft Access Driver (*.mdb)};DBQ=",
                    dbPathString);
            }
            else
            {
                //------------------------------------------------------------
                // The following connection string also works, as long as the
                // client is logged into the server where the database file is
                // located, even if no drive mapped to the server, but using
                // this direct path slows the database search considerably
                //------------------------------------------------------------
                connectionString = String::Concat(
                    "Driver={Microsoft Access Driver (*.mdb)};DBQ=",
                    QUARTZDYNE_CONFIDENTIAL_ROOT,
                    QUARTZDYNE_CALSUM_DB_FILE_PATH);
                //------------------------------------------------------------
                // The above line is no longer used, because OdbcConnection
                // might use it to detect a network without returning an error
                // to indicate that the database cannot be found
                //------------------------------------------------------------
            }
            if (allowConnection)
            {
                OdbcConnection ^connection = gcnew OdbcConnection(connectionString);
//                    if (connection->State == ConnectionState::Connecting)
                {
                    //--------------------------------------------------------
                    // If ExecuteReader fails with "Too few parameters" it is
                    // usually due to the fact that one or more of the columns
                    // in the query string SELECT statement is invalid or does
                    // not exist
                    //--------------------------------------------------------
                    String ^queryString = String::Concat(
                        "SELECT BySerNum.ser_num, BySerNum.cal_num ",
                        "FROM `",
                        dbPathString,
                        "`.ByCal ByCal, `",
                        dbPathString,
                        "`.BySerNum BySerNum ",
                        "WHERE BySerNum.cal_num = ByCal.bc_cal_no AND ((BySerNum.ser_num='",
                        serialNumberString,
                        "'))");
//                    //--------------------------------------------------------
//                    // The previous query string prior to 05-26-2015
//                    //--------------------------------------------------------
//                    String ^queryString = String::Concat(
//                        "SELECT ser_num, cal_num, MaxPres, sens_lot, mux_chan, cal_err, qa_err, sensitivity ",
//                        "FROM BySerNum INNER JOIN ByCal ON BySerNum.cal_num = ByCal.bc_cal_no ",
//                        "WHERE ser_num Like '",
//                        serialNumberString,
//                        "' ORDER BY ByCal.bc_cal_no");
                    OdbcCommand ^command = gcnew OdbcCommand(queryString, connection);
                    command->Connection = connection;
                    connection->Open();
                    OdbcDataReader ^reader = command->ExecuteReader();
                    if (reader->HasRows)
                    {
                        String ^lastCal = String::Empty;
                        String ^thisCal;
                        while (reader->Read())
                        {
                            //------------------------------------------------
                            // Only interested in the cal_num (second)
                            // column data
                            //------------------------------------------------
                            thisCal = reader->GetString(1);
                            if (String::IsNullOrEmpty(lastCal))
                                lastCal = thisCal;
                            //------------------------------------------------
                            // Only interested in the latest Cal
                            //------------------------------------------------
                            if (Convert::ToInt32(thisCal) > Convert::ToInt32(lastCal))
                            {
                                lastCal = thisCal;
                            }
                        }
                        if (!String::IsNullOrEmpty(lastCal))
                        {
                            //------------------------------------------------
                            // Construct the directory name from the Cal Number
                            //------------------------------------------------
                            String ^fullDir = String::Concat(
                                calibrationDirectory,
                                lastCal->Substring(0, lastCal->Length - 2), "xx\\",
                                lastCal, "\\");
                            if (Directory::Exists(fullDir))
                            {
                                //--------------------------------------------
                                // Try and locate the hex file with only the
                                // serial number as its filename
                                //--------------------------------------------
                                targetFilePath = String::Concat(fullDir, serialNumberString, _T(".hex"));
                                if (File::Exists(targetFilePath))
                                {
                                    fileLocationIdentifiedByDataBase = GUI_YES;
                                }
                                else
                                {
                                    //----------------------------------------
                                    // Search for all hex files that contain
                                    // the serial number
                                    //----------------------------------------
                                    array <String ^> ^primaryFiles =
                                        Directory::GetFiles(
                                            fullDir,
                                            "*" + serialNumberString + "*.hex");
                                    if (StringSet(primaryFiles))
                                    {
                                        for each (String ^pf in primaryFiles)
                                        {
                                            fileLocationIdentifiedByDataBase = GUI_YES;
                                            targetFilePath = pf;
                                        }
                                    }
                                    else
                                    {
                                        //------------------------------------
                                        // Try and locate the .crf file with
                                        // only the serial number as its
                                        // filename
                                        //------------------------------------
                                        targetFilePath = String::Concat(fullDir, serialNumberString, _T(".crf"));
                                        if (File::Exists(targetFilePath))
                                        {
                                            fileLocationIdentifiedByDataBase = GUI_YES;
                                        }
                                        else
                                        {
                                            //--------------------------------
                                            // Search for all .crf files that
                                            // contain the serial number
                                            //--------------------------------
                                            array <String ^> ^secondaryFiles =
                                                Directory::GetFiles(
                                                    fullDir,
                                                    "*" + serialNumberString + "*.crf");
                                            if (StringSet(secondaryFiles))
                                            {
                                                for each (String ^sf in secondaryFiles)
                                                {
                                                    fileLocationIdentifiedByDataBase = GUI_YES;
                                                    targetFilePath = sf;
                                                }
                                            }
                                        }
                                    }
                                }       // end of else of if (File::Exists(targetFilePath))
                                if (fileLocationIdentifiedByDataBase)
                                {
                                    GUI_StringToBuilder(
                                        targetFilePath,
                                        filePathBuilder);
                                    fileName = Path::GetFileName(targetFilePath);
                                }
                            }           // end of if (Directory::Exists(fullDir))
                        }               // end of if (!String::IsNullOrEmpty(lastCal))
                    }                   // end of if (reader->HasRows)
                    reader->Close();
                    connection->Close();
                    delete command;
                }                       // end of if (connection->State == ConnectionState::Connecting)
                delete connection;
            }                           // end of if (allowConnection)
            if (fileLocationIdentifiedByDataBase)
            {
                fileLocated = GUI_YES;
            }
            else
            {
                if (calDirectoryFound)
                {
                    //--------------------------------------------------------
                    // The database is unable to provide the calibration
                    // location, so perform a file system search, which can
                    // take several minutes
                    //--------------------------------------------------------
                    if (dbFileFound)
                    {
                        promptString = String::Format(
                            "Coefficient files for transducer {0} could not be located\n"
                            "by searching the database.  A file system search could take\n"
                            "several minutes.  Begin searching the file system anyway?",
                            serialNumberString);
                    }
                    else
                    {
                        promptString = String::Format(
                            "The database that contains coefficient file location\n"
                            "information for transducer {0} could not be found. A file\n"
                            "system search could take several minutes. Begin\n"
                            "searching the file system anyway?",
                            serialNumberString);
                    }
                    proceedWithSearch = QCOM_PromptModal(
                        "No Database Record Found",
                        promptString);
                    if (proceedWithSearch)
                    {
                        QCOM_PromptOKModal(
                            "Warning",
                            "If the file search takes more than a few seconds, the\n"
                            "'Please wait...' window might display a (Not Responding)\n"
                            "message in its title bar, which is normal.  Do not take\n"
                            "any action as a result of the (Not Responding) message.");
                        QCOM_PleaseWait(
                            GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
                            "Extended System Search");
                        fileName = String::Concat(serialNumberString, ".hex");
                        fileLocated = QCOM_GlobalFileSearch(fileName, filePathBuilder);
                        if (!fileLocated)
                        {
                            fileName = String::Concat(serialNumberString, ".crf");
                            fileLocated = QCOM_GlobalFileSearch(fileName, filePathBuilder);
                        }
                        QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
                        RecordVerboseEvent(
                            "Search for coefficient files of {0} {1}",
                            serialNumberString,
                            (fileLocated ? "succeeded" : "failed"));
                        if (!fileLocated)
                        {
                            QCOM_PromptOKModal(
                                "No Coefficient Files Found",
                                "Coefficient files for transducer {0} could not be\n"
                                "located in the database or on the network server",
                                serialNumberString);
                            filePathBuilder->Clear();
                        }
                    }                   // end of if (proceedWithSearch)
                }                       // end of if (calDirectoryFound)
                else
                {
                    //--------------------------------------------------------
                    // Bail
                    //--------------------------------------------------------
                    QCOM_PromptOKModal(
                        "No Coefficient Files Found",
                        "QCOM could not detect a network server connection\n"
                        "or you are not logged in to the server");
                    filePathBuilder->Clear();
                }
            }                           // end of else of if (fileLocationIdentifiedByDataBase)
        }                               // end of if (networkLocated)
    }                                   // end of if (StringSet(serialNumberString) && filePathBuilder)
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (fileLocated ? "Found" : "Not Found"));
    return fileLocated;
}                                       // end of QCOM_SearchForCoefficientFile()
//----------------------------------------------------------------------------
// QCOM_SetUpUnitMultipleCoefficientWindow
//
// Creates the unit multiple coefficient data storage windows
//
// Called by:   QCOM_InstallMultipleCoefficientWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SetUpUnitMultipleCoefficientWindow(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_SetUpUnitMultipleCoefficientWindow");
    //------------------------------------------------------------------------
    if (unit)
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Create a new window form and set its properties and icon
        //--------------------------------------------------------------------
        Form ^multipleCoefficientDataWindow = gcnew Form;
        multipleCoefficientDataWindow->Tag = unitNumber;
        multipleCoefficientDataWindow->MaximizeBox = GUI_NO;
        multipleCoefficientDataWindow->HelpButton = GUI_NO;
        multipleCoefficientDataWindow->Icon = QCOM_SoftwareIcon;
        multipleCoefficientDataWindow->BackgroundImage = whiteSandBackground;
        multipleCoefficientDataWindow->Width = GUI_UNIT_MULTIPLE_CF_WINDOW_WIDTH;
        multipleCoefficientDataWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
        //--------------------------------------------------------------------
        // Multiple coefficient data storage in module memory
        //--------------------------------------------------------------------
        GroupBox ^multipleCFModuleGroupBox = gcnew GroupBox;
        multipleCFModuleGroupBox->Text = String::Concat("Module ", unit->moduleSerialNumber);
        multipleCFModuleGroupBox->Location = Point(10, 10);
        multipleCFModuleGroupBox->Size = Drawing::Size(
            multipleCoefficientDataWindow->Width - 30,
            GUI_UNIT_MULTIPLE_CF_GROUP_BOX_HEIGHT);
        multipleCFModuleGroupBox->BackColor = Color::Transparent;
        multipleCoefficientDataWindow->Controls->Add(multipleCFModuleGroupBox);
        //--------------------------------------------------------------------
        // Slot information and buttons
        //--------------------------------------------------------------------
        for (int slotNumber = 0; slotNumber < QCOM_MAXIMUM_NUMBER_OF_MEMORY_SLOTS; slotNumber++)
        {
            //----------------------------------------------------------------
            // Slot number label
            //----------------------------------------------------------------
            Label ^multipleSlotNumberModuleLabel = gcnew Label;
            multipleSlotNumberModuleLabel->Text = String::Concat("Slot ", slotNumber + 1, " : ");
            multipleSlotNumberModuleLabel->Location = Point(10, (32 * slotNumber) + 20);
            multipleSlotNumberModuleLabel->Size = Drawing::Size(68, 20);
            multipleSlotNumberModuleLabel->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                12.0F,
                FontStyle::Bold);
            multipleSlotNumberModuleLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
            multipleSlotNumberModuleLabel->BackColor = Color::Transparent;
            multipleCFModuleGroupBox->Controls->Add(multipleSlotNumberModuleLabel);
            //----------------------------------------------------------------
            // Transducer serial number label
            //----------------------------------------------------------------
            String ^TSN = unit->transducerSerialNumber;
            Label ^multipleSerialNumberModuleLabel = gcnew Label;
            multipleSerialNumberModuleLabel->Location = Point(
                multipleSlotNumberModuleLabel->Right + 2,
                multipleSlotNumberModuleLabel->Top);
            multipleSerialNumberModuleLabel->Size = Drawing::Size(98, 20);
            multipleSerialNumberModuleLabel->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                12.0F,
                FontStyle::Bold);
            multipleSerialNumberModuleLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
            multipleSerialNumberModuleLabel->BackColor = Color::Transparent;
            multipleCFModuleGroupBox->Controls->Add(multipleSerialNumberModuleLabel);
            multipleSerialNumberModuleLabelArray[unitNumber][slotNumber] = multipleSerialNumberModuleLabel;
            //----------------------------------------------------------------
            // Update button
            //----------------------------------------------------------------
            Button ^multipleModuleUpdateButton = gcnew Button;
            multipleModuleUpdateButton->Tag = ((slotNumber << 8) | unitNumber);
            multipleModuleUpdateButton->Text = _T("Update");
            multipleModuleUpdateButton->Location = Point(
                multipleSerialNumberModuleLabel->Right + 20,
                multipleSerialNumberModuleLabel->Top - 2);
            multipleModuleUpdateButton->Size = Drawing::Size(
                GUI_READOUT_OBJECT_WIDTH,
                GUI_REGULAR_BUTTON_HEIGHT);
            GUI_SetButtonInterfaceProperties(multipleModuleUpdateButton);
            multipleModuleUpdateButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MultipleCoefficientModuleUpdateButtonClicked);
            multipleCFModuleGroupBox->Controls->Add(multipleModuleUpdateButton);
            //--------------------------------------------------------------------
            // Update button tool tip
            //--------------------------------------------------------------------
            ToolTip ^multipleModuleUpdateButtonToolTip = gcnew ToolTip;
            multipleModuleUpdateButtonToolTip->ShowAlways = GUI_YES;
            multipleModuleUpdateButtonToolTip->AutoPopDelay = 10000;
            multipleModuleUpdateButtonToolTip->ToolTipTitle = String::Concat(
                _T("Update Module "),
                unit->moduleSerialNumber,
                _T(" Slot "),
                (slotNumber + 1),
                _T(" Coefficients"));
            String ^multipleModuleUpdateButtonToolTipText = String::Concat(
                "Prompts for a transducer serial number whose", Environment::NewLine,
                "coefficient data will be used to update slot ", slotNumber + 1, Environment::NewLine,
                "of module ", unit->moduleSerialNumber, ".");
            multipleModuleUpdateButtonToolTip->SetToolTip(multipleModuleUpdateButton, multipleModuleUpdateButtonToolTipText);
            delete multipleModuleUpdateButtonToolTipText;
            //----------------------------------------------------------------
            // Verify button
            //----------------------------------------------------------------
            Button ^multipleModuleVerifyButton = gcnew Button;
            multipleModuleVerifyButton->Tag = ((slotNumber << 8) | unitNumber);
            multipleModuleVerifyButton->Text = _T("Verify");
            multipleModuleVerifyButton->Location = Point(
                multipleModuleUpdateButton->Right + 20,
                multipleModuleUpdateButton->Top);
            multipleModuleVerifyButton->Size = multipleModuleUpdateButton->Size;
            GUI_SetButtonInterfaceProperties(multipleModuleVerifyButton);
            multipleModuleVerifyButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MultipleCoefficientModuleVerifyButtonClicked);
            multipleCFModuleGroupBox->Controls->Add(multipleModuleVerifyButton);
            //--------------------------------------------------------------------
            // Verify button tool tip
            //--------------------------------------------------------------------
            ToolTip ^multipleModuleVerifyButtonToolTip = gcnew ToolTip;
            multipleModuleVerifyButtonToolTip->ShowAlways = GUI_YES;
            multipleModuleVerifyButtonToolTip->AutoPopDelay = 10000;
            multipleModuleVerifyButtonToolTip->ToolTipTitle = String::Concat(
                _T("Verify Module "),
                unit->moduleSerialNumber,
                _T(" Coefficient Data Slot "),
                (slotNumber + 1));
            String ^multipleModuleVerifyButtonToolTipText = String::Concat(
                "Verifies the coefficient data integrity", Environment::NewLine,
                "of slot ", slotNumber + 1, " for module ", unit->moduleSerialNumber, ".");
            multipleModuleVerifyButtonToolTip->SetToolTip(multipleModuleVerifyButton, multipleModuleVerifyButtonToolTipText);
            delete multipleModuleVerifyButtonToolTipText;
            //----------------------------------------------------------------
            // Clear button
            //----------------------------------------------------------------
            Button ^multipleModuleClearButton = gcnew Button;
            multipleModuleClearButton->Tag = ((slotNumber << 8) | unitNumber);
            multipleModuleClearButton->Text = _T("Clear");
            multipleModuleClearButton->Location = Point(
                multipleModuleVerifyButton->Right + 20,
                multipleModuleVerifyButton->Top);
            multipleModuleClearButton->Size = multipleModuleVerifyButton->Size;
            GUI_SetButtonInterfaceProperties(multipleModuleClearButton);
            multipleModuleClearButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MultipleCoefficientModuleClearButtonClicked);
            multipleCFModuleGroupBox->Controls->Add(multipleModuleClearButton);
            //--------------------------------------------------------------------
            // Clear button tool tip
            //--------------------------------------------------------------------
            ToolTip ^multipleModuleClearButtonToolTip = gcnew ToolTip;
            multipleModuleClearButtonToolTip->ShowAlways = GUI_YES;
            multipleModuleClearButtonToolTip->AutoPopDelay = 10000;
            multipleModuleClearButtonToolTip->ToolTipTitle = String::Concat(
                _T("Clear Module "),
                unit->moduleSerialNumber,
                _T(" Memory Slot "),
                (slotNumber + 1));
            String ^multipleModuleClearButtonToolTipText = String::Concat(
                "Clears the memory of slot ", slotNumber + 1, Environment::NewLine,
                "for module ", unit->moduleSerialNumber, ".");
            multipleModuleClearButtonToolTip->SetToolTip(multipleModuleClearButton, multipleModuleClearButtonToolTipText);
            delete multipleModuleClearButtonToolTipText;
            //----------------------------------------------------------------
            // Copy button
            //----------------------------------------------------------------
            Button ^multipleModuleCopyButton = gcnew Button;
            multipleModuleCopyButton->Tag = ((slotNumber << 8) | unitNumber);
            multipleModuleCopyButton->Text = _T("Copy to Transducer");
            multipleModuleCopyButton->Location = Point(
                multipleModuleClearButton->Right + 20,
                multipleModuleClearButton->Top);
            multipleModuleCopyButton->Size = Drawing::Size(
                122,
                GUI_REGULAR_BUTTON_HEIGHT);
            GUI_SetButtonInterfaceProperties(multipleModuleCopyButton);
            multipleModuleCopyButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MultipleCoefficientModuleCopyButtonClicked);
            multipleCFModuleGroupBox->Controls->Add(multipleModuleCopyButton);
            multipleModuleCopyButtonArray[unitNumber][slotNumber] = multipleModuleCopyButton;
            //--------------------------------------------------------------------
            // Copy button tool tip
            //--------------------------------------------------------------------
            ToolTip ^multipleModuleCopyButtonToolTip = gcnew ToolTip;
            multipleModuleCopyButtonToolTip->ShowAlways = GUI_YES;
            multipleModuleCopyButtonToolTip->AutoPopDelay = 10000;
            multipleModuleCopyButtonToolTip->ToolTipTitle = String::Concat(
                _T("Copy Module "),
                unit->moduleSerialNumber,
                _T(" Slot "),
                (slotNumber + 1),
                _T(" Coefficient Data"));
            String ^multipleModuleCopyButtonToolTipText = String::Concat(
                "Copies the coefficient data stored in slot ", slotNumber + 1, Environment::NewLine,
                "of module ", unit->moduleSerialNumber, " to the same slot of", Environment::NewLine,
                "transducer ", unit->transducerSerialNumber, ".");
            multipleModuleCopyButtonToolTip->SetToolTip(multipleModuleCopyButton, multipleModuleCopyButtonToolTipText);
            delete multipleModuleCopyButtonToolTipText;
        }                               // end of for (int slotNumber = 0; ...)
        //--------------------------------------------------------------------
        // Multiple coefficient data storage in transducer memory
        //--------------------------------------------------------------------
        GroupBox ^multipleCFXDGroupBox = gcnew GroupBox;
        multipleCFXDGroupBox->Text = String::Concat("Transducer ", unit->transducerSerialNumber);
        multipleCFXDGroupBox->Location = Point(10, multipleCFModuleGroupBox->Bottom + 20);
        multipleCFXDGroupBox->Size = Drawing::Size(
            multipleCoefficientDataWindow->Width - 30,
            GUI_UNIT_MULTIPLE_CF_GROUP_BOX_HEIGHT);
        multipleCFXDGroupBox->BackColor = Color::Transparent;
        multipleCoefficientDataWindow->Controls->Add(multipleCFXDGroupBox);
        //--------------------------------------------------------------------
        // Slot information and buttons
        //--------------------------------------------------------------------
        for (int slotNumber = 0; slotNumber < QCOM_MAXIMUM_NUMBER_OF_MEMORY_SLOTS; slotNumber++)
        {
            //----------------------------------------------------------------
            // Slot number label
            //----------------------------------------------------------------
            Label ^multipleSlotNumberTransducerLabel = gcnew Label;
            multipleSlotNumberTransducerLabel->Text = String::Concat("Slot ", slotNumber + 1, " : ");
            multipleSlotNumberTransducerLabel->Location = Point(10, (32 * slotNumber) + 20);
            multipleSlotNumberTransducerLabel->Size = Drawing::Size(68, 20);
            multipleSlotNumberTransducerLabel->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                12.0F,
                FontStyle::Bold);
            multipleSlotNumberTransducerLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
            multipleSlotNumberTransducerLabel->BackColor = Color::Transparent;
            multipleCFXDGroupBox->Controls->Add(multipleSlotNumberTransducerLabel);
            //----------------------------------------------------------------
            // Transducer serial number label
            //----------------------------------------------------------------
            String ^TSN = unit->transducerSerialNumber;
            Label ^multipleSerialNumberTransducerLabel = gcnew Label;
            multipleSerialNumberTransducerLabel->Location = Point(
                multipleSlotNumberTransducerLabel->Right + 2,
                multipleSlotNumberTransducerLabel->Top);
            multipleSerialNumberTransducerLabel->Size = Drawing::Size(98, 20);
            multipleSerialNumberTransducerLabel->Font = gcnew Drawing::Font(
                FontFamily::GenericSansSerif,
                12.0F,
                FontStyle::Bold);
            multipleSerialNumberTransducerLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
            multipleSerialNumberTransducerLabel->BackColor = Color::Transparent;
            multipleCFXDGroupBox->Controls->Add(multipleSerialNumberTransducerLabel);
            multipleSerialNumberTransducerLabelArray[unitNumber][slotNumber] = multipleSerialNumberTransducerLabel;
            //----------------------------------------------------------------
            // Update button
            //----------------------------------------------------------------
            Button ^multipleTransducerUpdateButton = gcnew Button;
            multipleTransducerUpdateButton->Tag = ((slotNumber << 8) | unitNumber);
            multipleTransducerUpdateButton->Text = _T("Update");
            multipleTransducerUpdateButton->Location = Point(
                multipleSerialNumberTransducerLabel->Right + 20,
                multipleSerialNumberTransducerLabel->Top - 2);
            multipleTransducerUpdateButton->Size = Drawing::Size(
                GUI_READOUT_OBJECT_WIDTH,
                GUI_REGULAR_BUTTON_HEIGHT);
            GUI_SetButtonInterfaceProperties(multipleTransducerUpdateButton);
            multipleTransducerUpdateButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MultipleCoefficientTransducerUpdateButtonClicked);
            multipleCFXDGroupBox->Controls->Add(multipleTransducerUpdateButton);
            //--------------------------------------------------------------------
            // Update button tool tip
            //--------------------------------------------------------------------
            ToolTip ^multipleTransducerUpdateButtonToolTip = gcnew ToolTip;
            multipleTransducerUpdateButtonToolTip->ShowAlways = GUI_YES;
            multipleTransducerUpdateButtonToolTip->AutoPopDelay = 10000;
            multipleTransducerUpdateButtonToolTip->ToolTipTitle = String::Concat(
                _T("Update Transducer "),
                unit->transducerSerialNumber,
                _T(" Slot "),
                (slotNumber + 1),
                _T(" Coefficients"));
            String ^multipleTransducerUpdateButtonToolTipText = String::Concat(
                "Prompts for a transducer serial number whose", Environment::NewLine,
                "coefficient data will be used to update slot ", slotNumber + 1, Environment::NewLine,
                "of transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, ".");
            multipleTransducerUpdateButtonToolTip->SetToolTip(multipleTransducerUpdateButton, multipleTransducerUpdateButtonToolTipText);
            delete multipleTransducerUpdateButtonToolTipText;
            //----------------------------------------------------------------
            // Verify button
            //----------------------------------------------------------------
            Button ^multipleTransducerVerifyButton = gcnew Button;
            multipleTransducerVerifyButton->Tag = ((slotNumber << 8) | unitNumber);
            multipleTransducerVerifyButton->Text = _T("Verify");
            multipleTransducerVerifyButton->Location = Point(
                multipleTransducerUpdateButton->Right + 20,
                multipleTransducerUpdateButton->Top);
            multipleTransducerVerifyButton->Size = multipleTransducerUpdateButton->Size;
            GUI_SetButtonInterfaceProperties(multipleTransducerVerifyButton);
            multipleTransducerVerifyButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MultipleCoefficientTransducerVerifyButtonClicked);
            multipleCFXDGroupBox->Controls->Add(multipleTransducerVerifyButton);
            //--------------------------------------------------------------------
            // Verify button tool tip
            //--------------------------------------------------------------------
            ToolTip ^multipleTransducerVerifyButtonToolTip = gcnew ToolTip;
            multipleTransducerVerifyButtonToolTip->ShowAlways = GUI_YES;
            multipleTransducerVerifyButtonToolTip->AutoPopDelay = 10000;
            multipleTransducerVerifyButtonToolTip->ToolTipTitle = String::Concat(
                _T("Verify Transducer "),
                unit->transducerSerialNumber,
                _T(" Coefficient Data Slot "),
                (slotNumber + 1));
            String ^multipleTransducerVerifyButtonToolTipText = String::Concat(
                "Verifies the coefficient data integrity", Environment::NewLine,
                "of slot ", slotNumber + 1, " for transducer ", unit->transducerSerialNumber, ".");
            multipleTransducerVerifyButtonToolTip->SetToolTip(multipleTransducerVerifyButton, multipleTransducerVerifyButtonToolTipText);
            delete multipleTransducerVerifyButtonToolTipText;
            //----------------------------------------------------------------
            // Clear button
            //----------------------------------------------------------------
            Button ^multipleTransducerClearButton = gcnew Button;
            multipleTransducerClearButton->Tag = ((slotNumber << 8) | unitNumber);
            multipleTransducerClearButton->Text = _T("Clear");
            multipleTransducerClearButton->Location = Point(
                multipleTransducerVerifyButton->Right + 20,
                multipleTransducerVerifyButton->Top);
            multipleTransducerClearButton->Size = multipleTransducerVerifyButton->Size;
            GUI_SetButtonInterfaceProperties(multipleTransducerClearButton);
            multipleTransducerClearButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MultipleCoefficientTransducerClearButtonClicked);
            multipleCFXDGroupBox->Controls->Add(multipleTransducerClearButton);
            //--------------------------------------------------------------------
            // Clear button tool tip
            //--------------------------------------------------------------------
            ToolTip ^multipleTransducerClearButtonToolTip = gcnew ToolTip;
            multipleTransducerClearButtonToolTip->ShowAlways = GUI_YES;
            multipleTransducerClearButtonToolTip->AutoPopDelay = 10000;
            multipleTransducerClearButtonToolTip->ToolTipTitle = String::Concat(
                _T("Clear Transducer "),
                unit->transducerSerialNumber,
                _T(" Memory Slot "),
                (slotNumber + 1));
            String ^multipleTransducerClearButtonToolTipText = String::Concat(
                "Clears the memory of slot ", slotNumber + 1, Environment::NewLine,
                "for transducer ", unit->transducerSerialNumber, ".");
            multipleTransducerClearButtonToolTip->SetToolTip(multipleTransducerClearButton, multipleTransducerClearButtonToolTipText);
            delete multipleTransducerClearButtonToolTipText;
            //----------------------------------------------------------------
            // Copy button
            //----------------------------------------------------------------
            Button ^multipleTransducerCopyButton = gcnew Button;
            multipleTransducerCopyButton->Tag = ((slotNumber << 8) | unitNumber);
            multipleTransducerCopyButton->Text = _T("Copy to Module");
            multipleTransducerCopyButton->Location = Point(
                multipleTransducerClearButton->Right + 20,
                multipleTransducerClearButton->Top);
            multipleTransducerCopyButton->Size = Drawing::Size(
                122,
                GUI_REGULAR_BUTTON_HEIGHT);
            GUI_SetButtonInterfaceProperties(multipleTransducerCopyButton);
            multipleTransducerCopyButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MultipleCoefficientTransducerCopyButtonClicked);
            multipleCFXDGroupBox->Controls->Add(multipleTransducerCopyButton);
            //--------------------------------------------------------------------
            // Copy button tool tip
            //--------------------------------------------------------------------
            ToolTip ^multipleTransducerCopyButtonToolTip = gcnew ToolTip;
            multipleTransducerCopyButtonToolTip->ShowAlways = GUI_YES;
            multipleTransducerCopyButtonToolTip->AutoPopDelay = 10000;
            multipleTransducerCopyButtonToolTip->ToolTipTitle = String::Concat(
                _T("Copy Transducer "),
                unit->transducerSerialNumber,
                _T(" Slot "),
                (slotNumber + 1),
                _T(" Coefficient Data"));
            String ^multipleTransducerCopyButtonToolTipText = String::Concat(
                "Copies the coefficient data stored in slot ", slotNumber + 1, Environment::NewLine,
                "of transducer ", unit->transducerSerialNumber, " to the same slot of", Environment::NewLine,
                "module ", unit->moduleSerialNumber, ".");
            multipleTransducerCopyButtonToolTip->SetToolTip(multipleTransducerCopyButton, multipleTransducerCopyButtonToolTipText);
            delete multipleTransducerCopyButtonToolTipText;
        }                               // end of for (int slotNumber = 0; ...)
        //--------------------------------------------------------------------
        // Close button
        //--------------------------------------------------------------------
        Button ^multipleCFDCloseButton = gcnew Button;
        multipleCFDCloseButton->Text = _T("Close");
        multipleCFDCloseButton->Location = Point(
            multipleCoefficientDataWindow->Right - 100,
            multipleCoefficientDataWindow->Bottom - 70);
        multipleCFDCloseButton->Size = Drawing::Size(
            GUI_CLOSE_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        multipleCFDCloseButton->DialogResult = System::Windows::Forms::DialogResult::OK;
        GUI_SetUnitButtonInterfaceProperties(
            multipleCFDCloseButton,
            unitNumber);
        multipleCFDCloseButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MultipleCoefficientCloseWindow);
        multipleCFDCloseButton->Visible = GUI_NO;
        //--------------------------------------------------------------------
        // Handle the closing of the window by any other way
        //--------------------------------------------------------------------
        multipleCoefficientDataWindow->FormClosing +=
            gcnew FormClosingEventHandler(this, &QCOM_GUIClass::QCOM_MultipleCoefficientClosingWindow);
        multipleCoefficientDataWindow->Controls->Add(multipleCFDCloseButton);
        //--------------------------------------------------------------------
        // Set the remaining window properties
        //--------------------------------------------------------------------
        multipleCoefficientDataWindow->AcceptButton = multipleCFDCloseButton;
        multipleCoefficientDataWindow->CancelButton = multipleCFDCloseButton;
        //--------------------------------------------------------------------
        // Finally, hide the new window
        //--------------------------------------------------------------------
        multipleCoefficientDataWindowArray[unitNumber] = multipleCoefficientDataWindow;
        multipleCoefficientDataWindow->Hide();
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_SetUpUnitMultipleCoefficientWindow()
//----------------------------------------------------------------------------
// QCOM_UpdateMultipleCoefficientWindow
//
// Updates the multiple coefficient management window of the specified unit
// with the most recent slot information
//
// Called by:   QCOM_ExpertManageMultipleCoefficientDataButtonClicked
//              QCOM_MultipleCoefficientModuleCopyButtonClicked
//              QCOM_MultipleCoefficientTransducerCopyButtonClicked
//              QCOM_MultipleCoefficientModuleUpdateButtonClicked
//              QCOM_MultipleCoefficientTransducerUpdateButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateMultipleCoefficientWindow(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_UpdateMultipleCoefficientWindow");
    //------------------------------------------------------------------------
    if (unit)
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Retrieve the coefficient data currently stored
        //--------------------------------------------------------------------
        LPBYTE coefficientData = (LPBYTE) malloc(QCOM_COEFFICIENT_DATA_SIZE);
        char *transducerSerialNumber = (char *) malloc(QCOM_MAXIMUM_SERIAL_NUMBER_SIZE);
        if (coefficientData && transducerSerialNumber)
        {
            for (int slotNumber = 0; slotNumber < QCOM_MAXIMUM_NUMBER_OF_MEMORY_SLOTS; slotNumber++)
            {
                BYTE pageNumber = (BYTE) slotNumber * QCOM_CurrentPagesPerMemorySlot;
                ClearBuffer(coefficientData, QCOM_COEFFICIENT_DATA_SIZE);
                //------------------------------------------------------------
                // Update the module information
                //------------------------------------------------------------
                DWORD status = QD_ReadCoefficientDataFromSourcePage(
                    unit->unitHandle,
                    QD_DEVICE_MODULE,                                           // 1
                    pageNumber,
                    coefficientData);
                if (status == QD_SUCCESS)
                {
                    QCOM_ExtractSerialNumberFromCoefficientData(
                        (CoefficientFormatDef *) coefficientData,
                        transducerSerialNumber);
                    multipleSerialNumberModuleLabelArray[unitNumber][slotNumber]->Text =
                        gcnew String(transducerSerialNumber, 0, 6);
                }
                else
                {
                    if ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA) // 0x00000040
                    {
                        LPBYTE zeroData = (LPBYTE) malloc(QCOM_COEFFICIENT_DATA_SIZE);
                        if (zeroData)
                        {
                            ClearBuffer(zeroData, QCOM_COEFFICIENT_DATA_SIZE);
                            if (memcmp((void *) coefficientData, (void *) zeroData, QCOM_COEFFICIENT_DATA_SIZE))
                                multipleSerialNumberModuleLabelArray[unitNumber][slotNumber]->Text =
                                    QCOM_STRING_INVALID;
                            else
                                multipleSerialNumberModuleLabelArray[unitNumber][slotNumber]->Text =
                                    QCOM_STRING_CLEARED;
                            free((void *) zeroData);
                        }
                        else
                            multipleSerialNumberModuleLabelArray[unitNumber][slotNumber]->Text =
                                QCOM_STRING_ERROR;
                    }
                    else
                    {
                        multipleSerialNumberModuleLabelArray[unitNumber][slotNumber]->Text =
                            QCOM_STRING_ERROR;
                        RecordErrorEvent("    {0} : QD_ReadCoefficientDataFromSourcePage(module) returned 0x{1:X8}",
                            functionName, status);
                    }
                }
                //------------------------------------------------------------
                // Update the transducer information
                //------------------------------------------------------------
                if (!QCOM_XDIsFrequency(unit) && !QCOM_XDIsDigitalNoMem(unit))
                {
                    ClearBuffer(coefficientData, QCOM_COEFFICIENT_DATA_SIZE);
                    status = QD_ReadCoefficientDataFromSourcePage(
                        unit->unitHandle,
                        QD_DEVICE_TRANSDUCER,                                   // 0
                        pageNumber,
                        coefficientData);
                    if (status == QD_SUCCESS)
                    {
                        QCOM_ExtractSerialNumberFromCoefficientData(
                            (CoefficientFormatDef *) coefficientData,
                            transducerSerialNumber);
                        multipleSerialNumberTransducerLabelArray[unitNumber][slotNumber]->Text =
                            gcnew String(transducerSerialNumber, 0, 6);
                    }
                    else
                    {
                        if ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA) // 0x00000040
                        {
                            LPBYTE zeroData = (LPBYTE) malloc(QCOM_COEFFICIENT_DATA_SIZE);
                            if (zeroData)
                            {
                                ClearBuffer(zeroData, QCOM_COEFFICIENT_DATA_SIZE);
                                if (memcmp((void *) coefficientData, (void *) zeroData, QCOM_COEFFICIENT_DATA_SIZE))
                                    multipleSerialNumberTransducerLabelArray[unitNumber][slotNumber]->Text =
                                        QCOM_STRING_INVALID;
                                else
                                    multipleSerialNumberTransducerLabelArray[unitNumber][slotNumber]->Text =
                                        QCOM_STRING_CLEARED;
                                free((void *) zeroData);
                            }
                            else
                                multipleSerialNumberTransducerLabelArray[unitNumber][slotNumber]->Text =
                                    QCOM_STRING_ERROR;
                        }
                        else
                        {
                            multipleSerialNumberTransducerLabelArray[unitNumber][slotNumber]->Text =
                                QCOM_STRING_ERROR;
                            RecordErrorEvent("    {0} : QD_ReadCoefficientDataFromSourcePage(transducer) returned 0x{1:X8}",
                                functionName, status);
                        }
                    }
                }                       // end of if (!QCOM_XDIsFrequency(unit) && !QCOM_XDIsDigitalNoMem(unit))
            }                           // end of for (int slotNumber = 0; ...)
            free((void *) transducerSerialNumber);
            free((void *) coefficientData);
        }                               // end of if (coefficientData && transducerSerialNumber)
        else
        {
            GUI_DisplayMandatoryError(functionName,
                "Unable to allocate the necessary buffers");
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_UpdateMultipleCoefficientWindow()
//----------------------------------------------------------------------------
// QCOM_BuildCoefficientDataLine
//
// Builds a string that represents one 32-byte line of hex data, primarily to
// display coefficient data
//
// Returns the coefficient data line string
//
// Called by:   QCOM_DisplayLoadedCoefficientData
//----------------------------------------------------------------------------
    String ^
QCOM_BuildCoefficientDataLine(
    char            *line,
    int             index)
{
    //------------------------------------------------------------------------
    return
        String::Format(
            "{0:X1}{1:X1} {2:X1}{3:X1} {4:X1}{5:X1} {6:X1}{7:X1}-{8:X1}{9:X1} {10:X1}{11:X1} {12:X1}{13:X1} {14:X1}{15:X1}   "
            "{16:X1}{17:X1} {18:X1}{19:X1} {20:X1}{21:X1} {22:X1}{23:X1}-{24:X1}{25:X1} {26:X1}{27:X1} {28:X1}{29:X1} {30:X1}{31:X1}   "
            "{32:X1}{33:X1} {34:X1}{35:X1} {36:X1}{37:X1} {38:X1}{39:X1}-{40:X1}{41:X1} {42:X1}{43:X1} {44:X1}{45:X1} {46:X1}{47:X1}   "
            "{48:X1}{49:X1} {50:X1}{51:X1} {52:X1}{53:X1} {54:X1}{55:X1}-{56:X1}{57:X1} {58:X1}{59:X1} {60:X1}{61:X1} {62:X1}{63:X1}",
            line[(index * 64) + 0],  line[(index * 64) + 1],  line[(index * 64) + 2],  line[(index * 64) + 3],
            line[(index * 64) + 4],  line[(index * 64) + 5],  line[(index * 64) + 6],  line[(index * 64) + 7],
            line[(index * 64) + 8],  line[(index * 64) + 9],  line[(index * 64) + 10], line[(index * 64) + 11],
            line[(index * 64) + 12], line[(index * 64) + 13], line[(index * 64) + 14], line[(index * 64) + 15],
            line[(index * 64) + 16], line[(index * 64) + 17], line[(index * 64) + 18], line[(index * 64) + 19],
            line[(index * 64) + 20], line[(index * 64) + 21], line[(index * 64) + 22], line[(index * 64) + 23],
            line[(index * 64) + 24], line[(index * 64) + 25], line[(index * 64) + 26], line[(index * 64) + 27],
            line[(index * 64) + 28], line[(index * 64) + 29], line[(index * 64) + 30], line[(index * 64) + 31],
            line[(index * 64) + 32], line[(index * 64) + 33], line[(index * 64) + 34], line[(index * 64) + 35],
            line[(index * 64) + 36], line[(index * 64) + 37], line[(index * 64) + 38], line[(index * 64) + 39],
            line[(index * 64) + 40], line[(index * 64) + 41], line[(index * 64) + 42], line[(index * 64) + 43],
            line[(index * 64) + 44], line[(index * 64) + 45], line[(index * 64) + 46], line[(index * 64) + 47],
            line[(index * 64) + 48], line[(index * 64) + 49], line[(index * 64) + 50], line[(index * 64) + 51],
            line[(index * 64) + 52], line[(index * 64) + 53], line[(index * 64) + 54], line[(index * 64) + 55],
            line[(index * 64) + 56], line[(index * 64) + 57], line[(index * 64) + 58], line[(index * 64) + 59],
            line[(index * 64) + 60], line[(index * 64) + 61], line[(index * 64) + 62], line[(index * 64) + 63]);
}                                       // end of QCOM_BuildCoefficientDataLine()
//----------------------------------------------------------------------------
// QCOM_Calculate2DimensionalPolynomial
//
// Returns the calculated value of the specified coefficients through the
// ordered polynomial vector
//
// Called by:   QCOM_FormulateNativeCoefficients
//----------------------------------------------------------------------------
    double
QCOM_Calculate2DimensionalPolynomial(
    double          **polynomialMatrix,
    double          rowValue,
    double          columnValue,
    int             rowOrder,
    int             columnOrder)
{
    double          result = 0.0;
    double          value;
    //------------------------------------------------------------------------
    if (polynomialMatrix)
    {
        for (int row = 0; row <= rowOrder; row++)
        {
            value = 0.0;
            for (int column = 0; column <= columnOrder; column++)
            {
                value = (value * columnValue) + polynomialMatrix[row][column];
            }
            result = (result * rowValue) + value;
        }
    }
    return result;
}                                       // end of QCOM_Calculate2DimensionalPolynomial()
//----------------------------------------------------------------------------
// QCOM_ExtractSerialNumberFromCoefficientData
//
// Extracts the transducer serial number unmanaged string from the specified
// coefficient data, and returns the same serial number as a signed integer
//
// Called by:   QCOM_InterpretCoefficientData
//              QCOM_UpdateMultipleCoefficientWindow
//              QCOM_UtilConvertReadings
//
// Returns: 0           Failure (the serial number is blank or could not be
//                      determined)
//          nonzero     The signed integer version of the serial number
//
// Note:    format must point to at least QCOM_COEFFICIENT_DATA_SIZE (256)
//          bytes of available memory
//
// Note:    transducerSerialNumber must point to at least
//          QCOM_MAXIMUM_SERIAL_NUMBER_SIZE (256) bytes of available memory
//----------------------------------------------------------------------------
    int
QCOM_ExtractSerialNumberFromCoefficientData(
    CoefficientFormatDef
                    *format,
    char            *transducerSerialNumber)
{
    int             numericValue = 0;
    //------------------------------------------------------------------------
    if (format && transducerSerialNumber)
    {
        ClearBuffer(transducerSerialNumber, QCOM_MAXIMUM_SERIAL_NUMBER_SIZE);
        //--------------------------------------------------------------------
        // Interpret the bytes from the little-endian value into a string
        // 0x5634120D => "123456"
        //
        // For now, hard-code a maximum serial number string length of 6
        //--------------------------------------------------------------------
        for (int index = 0; index < 6; index++)
        {
            int shift = (index % 2) ? ((index - 1) * 4) : ((index + 1) * 4);
            int digit = (int) (((format->serialNumber & (0x00000F00 << shift)) >> (shift + 8)) & 0x0F);
            numericValue = Mult10(numericValue) + digit;
            transducerSerialNumber[index] = XtoA(digit);
        }
    }
    return numericValue;
}                                       // end of QCOM_ExtractSerialNumberFromCoefficientData()
//----------------------------------------------------------------------------
// QCOM_FormulateNativeCoefficients
//
// Creates a complete set of native coefficients
//
// Returns: 0           Success
//          nonzero     Failure
//
// Called by:   QCOM_ReadCoefficientDataFromFile
//----------------------------------------------------------------------------
    DWORD
QCOM_FormulateNativeCoefficients(
    CoefficientFormatDef
                    *format,
    CoefficientParametersDef
                    *parameters)
{
    int             entry;
    int             numberOfDataPoints = QCOM_NUMBER_OF_FREQUENCY_STEPS * QCOM_NUMBER_OF_FREQUENCY_STEPS;
    double          pressureCalculation;
    double          *pressureCoefficients;
    double          *pressureCount;
    double          **pressureInputCoefficientMatrix;
    double          *pressureFrequencies;
    double          *residualVector;
    double          temperatureCalculation;
    double          *temperatureCoefficients;
    double          *temperatureCount;
    double          **temperatureInputCoefficientMatrix;
    double          *temperatureFrequencies;
    double          *truePressure;
    double          *trueTemperature;
    DWORD           status = QCOM_SUCCESS;
    //------------------------------------------------------------------------
    if (format)
    {
        pressureCount = (double *) malloc(numberOfDataPoints * sizeof(double));
        temperatureCount = (double *) malloc(numberOfDataPoints * sizeof(double));
        pressureFrequencies = (double *) malloc(numberOfDataPoints * sizeof(double));
        temperatureFrequencies = (double *) malloc(numberOfDataPoints * sizeof(double));
        truePressure = (double *) malloc(numberOfDataPoints * sizeof(double));
        trueTemperature = (double *) malloc(numberOfDataPoints * sizeof(double));
        residualVector = (double *) malloc(numberOfDataPoints * sizeof(double));
        pressureCoefficients = (double *) malloc(parameters->numberOfPressureCoefficients * sizeof(double));
        temperatureCoefficients = (double *) malloc(parameters->numberOfTemperatureCoefficients * sizeof(double));
        pressureInputCoefficientMatrix = (double **) malloc((format->pressure1FitOrder + 1) * sizeof(double *));
        temperatureInputCoefficientMatrix = (double **) malloc((format->pressure2FitOrder + 1) * sizeof(double *));
        if (pressureCount && temperatureCount && pressureFrequencies && temperatureFrequencies &&
            truePressure && residualVector && pressureInputCoefficientMatrix && temperatureInputCoefficientMatrix)
        {
            for (int index = 0; index <= format->pressure1FitOrder; index++)
            {
                pressureInputCoefficientMatrix[index] = (double *)
                    malloc((format->temperature1FitOrder + 1) * sizeof(double));
                if (pressureInputCoefficientMatrix[index])
                {
                    ClearBuffer(
                        pressureInputCoefficientMatrix[index],
                        ((format->temperature1FitOrder + 1) * sizeof(double)));
                }
                else
                {
                    status = QCOM_ERROR_NATIVE_MEMORY_ALLOC_FAILED;
                    break;
                }
            }
            for (int index = 0; index <= format->pressure2FitOrder; index++)
            {
                temperatureInputCoefficientMatrix[index] = (double *)
                    malloc((format->temperature2FitOrder + 1) * sizeof(double));
                if (temperatureInputCoefficientMatrix[index])
                {
                    ClearBuffer(
                        temperatureInputCoefficientMatrix[index],
                        ((format->temperature2FitOrder + 1) * sizeof(double)));
                }
                else
                {
                    status = QCOM_ERROR_NATIVE_MEMORY_ALLOC_FAILED;
                    break;
                }
            }
            if (status == QCOM_SUCCESS)
            {
                ClearBuffer(temperatureCoefficients, (parameters->numberOfTemperatureCoefficients * sizeof(double)));
                ClearBuffer(pressureCoefficients, (parameters->numberOfPressureCoefficients * sizeof(double)));
                ClearBuffer(residualVector, (numberOfDataPoints * sizeof(double)));
                ClearBuffer(trueTemperature, (numberOfDataPoints * sizeof(double)));
                ClearBuffer(truePressure, (numberOfDataPoints * sizeof(double)));
                ClearBuffer(temperatureCount, (numberOfDataPoints * sizeof(double)));
                ClearBuffer(pressureCount, (numberOfDataPoints * sizeof(double)));
                //------------------------------------------------------------
                // Store the coefficients in reverse order
                //------------------------------------------------------------
                entry = 0;
                for (int row = format->pressure1FitOrder; row >= 0; row--)
                    for (int column = format->temperature1FitOrder; column >= 0; column--)
                        pressureInputCoefficientMatrix[row][column] =
                            parameters->pressureInputCoefficients[entry++];
                entry = 0;
                for (int row = format->pressure2FitOrder; row >= 0; row--)
                    for (int column = format->temperature2FitOrder; column >= 0; column--)
                        temperatureInputCoefficientMatrix[row][column] =
                            parameters->temperatureInputCoefficients[entry++];
                for (int row = 0; row < QCOM_NUMBER_OF_FREQUENCY_STEPS; row++)
                {
                    for (int column = 0; column < QCOM_NUMBER_OF_FREQUENCY_STEPS; column++)
                    {
                        entry = (row * QCOM_NUMBER_OF_FREQUENCY_STEPS) + column;
                        pressureFrequencies[entry] = QCOM_FREQUENCY_STEP * (row + 1);
                        temperatureFrequencies[entry] = QCOM_FREQUENCY_STEP * (column + 1);
                        pressureCalculation = QCOM_PreScaleFrequency(
                            pressureFrequencies[entry],
                            parameters->pressureScalingFactor,
                            parameters->pressureOffsetFrequency,
                            format->prescale1Type);
                        temperatureCalculation = QCOM_PreScaleFrequency(
                            temperatureFrequencies[entry],
                            parameters->temperatureScalingFactor,
                            parameters->temperatureOffsetFrequency,
                            format->prescale2Type);
                        truePressure[entry] = QCOM_Calculate2DimensionalPolynomial(
                            pressureInputCoefficientMatrix,
                            pressureCalculation,
                            temperatureCalculation,
                            format->pressure1FitOrder,
                            format->temperature1FitOrder);
                        truePressure[entry] *= parameters->pressureSpan;
                        trueTemperature[entry] = QCOM_Calculate2DimensionalPolynomial(
                            temperatureInputCoefficientMatrix,
                            pressureCalculation,
                            temperatureCalculation,
                            format->pressure2FitOrder,
                            format->temperature2FitOrder);
                        trueTemperature[entry] *= parameters->temperatureSpan;
                    }
                }
                //------------------------------------------------------------
                // Scale the frequencies into counts
                //------------------------------------------------------------
                for (int index = 0; index < numberOfDataPoints; index++)
                {
                    pressureCount[index] =
                        QCOM_ANALOG_FREQUENCY_MULTIPLIER * pressureFrequencies[index] /
                            QCOM_NOMINAL_REFERENCE_FREQUENCY;
                    temperatureCount[index] =
                        QCOM_ANALOG_FREQUENCY_MULTIPLIER * temperatureFrequencies[index] /
                            QCOM_NOMINAL_REFERENCE_FREQUENCY;
                    truePressure[index] *= QCOM_UNIVERSAL_SCALE_FACTOR;
                    trueTemperature[index] *= QCOM_UNIVERSAL_SCALE_FACTOR;
                }
                status = QCOM_PolynomialFit(
                    pressureCount,
                    temperatureCount,
                    truePressure,
                    residualVector,
                    numberOfDataPoints,
                    format->pressure1FitOrder,
                    format->temperature1FitOrder,
                    pressureCoefficients);
                status |= QCOM_PolynomialFit(
                    pressureCount,
                    temperatureCount,
                    trueTemperature,
                    residualVector,
                    numberOfDataPoints,
                    format->pressure2FitOrder,
                    format->temperature2FitOrder,
                    temperatureCoefficients);
                if (status == QCOM_SUCCESS)
                {
                    for (int index = 0; index < parameters->numberOfPressureCoefficients; index++)
                    {
                        DWORD integerValue = (DWORD) pressureCoefficients[index];
                        (*(DWORD *) &format->coefficients1[index * 4]) =
                            QCOM_ReverseIntegerValue(integerValue);
                    }
                    for (int index = 0; index < parameters->numberOfTemperatureCoefficients; index++)
                    {
                        DWORD integerValue = (DWORD) temperatureCoefficients[index];
                        (*(DWORD *) &format->coefficients2[index * 4]) =
                            QCOM_ReverseIntegerValue(integerValue);
                    }
                }
                //------------------------------------------------------------
                // Release all allocated memory
                //------------------------------------------------------------
                for (int index = 0; index <= format->pressure2FitOrder; index++)
                {
                    if (temperatureInputCoefficientMatrix[index])
                        free((Void *) temperatureInputCoefficientMatrix[index]);
                }
                for (int index = 0; index <= format->pressure1FitOrder; index++)
                {
                    if (pressureInputCoefficientMatrix[index])
                        free((Void *) pressureInputCoefficientMatrix[index]);
                }
            }
            free((void *) temperatureInputCoefficientMatrix);
            free((void *) pressureInputCoefficientMatrix);
            free((void *) temperatureCoefficients);
            free((void *) pressureCoefficients);
            free((void *) residualVector);
            free((void *) trueTemperature);
            free((void *) truePressure);
            free((void *) temperatureFrequencies);
            free((void *) pressureFrequencies);
            free((void *) temperatureCount);
            free((void *) pressureCount);
        }
        else
            status = QCOM_ERROR_NATIVE_MEMORY_ALLOC_FAILED;
    }
    else
        status = QCOM_ERROR_NATIVE_INVALID_PARAMETER;
    return status;
}                                       // end of QCOM_FormulateNativeCoefficients()
//----------------------------------------------------------------------------
// QCOM_MatrixCrossVector
//
// Crosses the specified matrix of doubles with the specified vector (array)
// of doubles, which results in a new vector of doubles
//
//      | a b |    X    | n |    =    | w |
//      | c d |         | m |         | x |
//      | e f |                       | y |
//      | g h |                       | z |
//
// Called by:   QCOM_PolynomialFit
//----------------------------------------------------------------------------
    void
QCOM_MatrixCrossVector(
    double          **matrix,
    double          *vector,
    int             numberOfRows,
    int             numberOfColumns,
    double          *resultingVector)
{
    int             column;
    int             row;
    double          *matrixPtr;
    double          *vectorPtr;
    //------------------------------------------------------------------------
    if (matrix && vector && numberOfRows && numberOfColumns && resultingVector)
    {
        for (row = 0; row < numberOfRows; row++)
        {
            *resultingVector = 0.0;
            matrixPtr = *matrix++;
            vectorPtr = vector;
            for (column = 0; column < numberOfColumns; column++)
            {
                *resultingVector += (*matrixPtr++ * *vectorPtr++);
            }
            resultingVector++;
        }
    }
}                                       // end of QCOM_MatrixCrossVector()
//----------------------------------------------------------------------------
// QCOM_PolynomialFit
//
// Creates a coefficient vector for the values that best fit the polynomial
// representing a specific transducer crystal
//
// Returns: 0           Success
//          nonzero     Failure
//
// Called by:   QCOM_FormulateNativeCoefficients
//----------------------------------------------------------------------------
    DWORD
QCOM_PolynomialFit(
    double          *pressurefrequencyVector,
    double          *temperaturefrequencyVector,
    double          *trueValueVector,
    double          *residualVector,
    int             numberOfElements,
    int             pressurePolynomialOrder,
    int             temperaturePolynomialOrder,
    double          *coefficientVector)
{
    int             numberOfCoefficients;
    double          *LHVector;
    double          **ltMatrix;
    double          **largeMatrix;
    DWORD           status = QCOM_SUCCESS;
    //------------------------------------------------------------------------
    if (pressurefrequencyVector && temperaturefrequencyVector && trueValueVector &&
        residualVector && numberOfElements && coefficientVector)
    {
        if ((pressurePolynomialOrder >= 0) && (temperaturePolynomialOrder >= 0))
        {
            numberOfCoefficients = (pressurePolynomialOrder + 1) * (temperaturePolynomialOrder + 1);
            //----------------------------------------------------------------
            // Allocate matrix and vector memory for calculations
            //----------------------------------------------------------------
            LHVector = (double *) malloc(numberOfCoefficients * sizeof(double));
            ltMatrix = (double **) malloc(numberOfCoefficients * sizeof(double *));
            largeMatrix = (double **) malloc(numberOfElements * sizeof(double *));
            if (LHVector && ltMatrix && largeMatrix)
            {
                ClearBuffer(LHVector, numberOfCoefficients * sizeof(double));
                for (int column = 0; column < numberOfCoefficients; column++)
                {
                    ltMatrix[column] = (double *) malloc(numberOfCoefficients * sizeof(double));
                    if (ltMatrix[column])
                    {
                        ClearBuffer(ltMatrix[column], numberOfCoefficients * sizeof(double));
                    }
                    else
                    {
                        status = QCOM_ERROR_NATIVE_MEMORY_ALLOC_FAILED;
                        break;
                    }
                }
                for (int column = 0; column < numberOfElements; column++)
                {
                    largeMatrix[column] = (double *) malloc(numberOfCoefficients * sizeof(double));
                    if (largeMatrix[column])
                    {
                        ClearBuffer(largeMatrix[column], numberOfCoefficients * sizeof(double));
                    }
                    else
                    {
                        status = QCOM_ERROR_NATIVE_MEMORY_ALLOC_FAILED;
                        break;
                    }
                }
                //------------------------------------------------------------
                // Begin the best-fit calculation
                //------------------------------------------------------------
                if (status == 0)
                {
                    QCOM_VectorCrossVector(
                        pressurefrequencyVector,
                        temperaturefrequencyVector,
                        numberOfElements,
                        pressurePolynomialOrder,
                        temperaturePolynomialOrder,
                        largeMatrix);
                    QCOM_VectorCrossMatrix(
                        trueValueVector,
                        largeMatrix,
                        numberOfElements,
                        numberOfCoefficients,
                        LHVector);
                    QCOM_TransposeCrossMatrix(
                        largeMatrix,
                        numberOfElements,
                        numberOfCoefficients,
                        ltMatrix);
                    status = QCOM_SolveMatrix(
                        ltMatrix,
                        LHVector,
                        numberOfCoefficients,
                        coefficientVector);
                    if (status == 0)
                    {
                        QCOM_MatrixCrossVector(
                            largeMatrix,
                            coefficientVector,
                            numberOfElements,
                            numberOfCoefficients,
                            residualVector);
                        QCOM_VectorMinusVector(
                            residualVector,
                            trueValueVector,
                            numberOfElements,
                            residualVector);
                    }
                }
                //------------------------------------------------------------
                // Release the matrix and vector memory used above
                //------------------------------------------------------------
                for (int column = 0; column < numberOfElements; column++)
                {
                    if (largeMatrix[column])
                    {
                        free((void *) largeMatrix[column]);
                    }
                }
                free((void *) largeMatrix);
                for (int column = 0; column < numberOfCoefficients; column++)
                {
                    if (ltMatrix[column])
                    {
                        free((void *) ltMatrix[column]);
                    }
                }
                free((void *) ltMatrix);
                free((void *) LHVector);
            }
            else
                status = QCOM_ERROR_NATIVE_MEMORY_ALLOC_FAILED;
        }
        else
            status = QCOM_ERROR_NATIVE_INVALID_PARAMETER;
    }
    return status;
}                                       // end of QCOM_PolynomialFit()
//----------------------------------------------------------------------------
// QCOM_PreScaleFrequency
//
// Pre-scales the specified frequency value, according to algorithm type
//
// Called by:   QCOM_FormulateNativeCoefficients
//
// Note:    06-13-2016 : Rick says that type 3 is the only valid scaling
//          algorithm, so the others now use the same algorithm as that
//          used for type 3
//----------------------------------------------------------------------------
    double
QCOM_PreScaleFrequency(
    double          unscaledFrequency,
    double          scalingFactor,
    double          offsetFrequency,
    int             scalingAlgorithm)
{
    double          preScaledFrequency = unscaledFrequency;
    //------------------------------------------------------------------------
    switch (scalingAlgorithm)
    {
        case 1 :
//            preScaledFrequency =
//                scalingFactor * (unscaledFrequency - offsetFrequency);
//            break;
        case 2 :
//            if (unscaledFrequency)
//                preScaledFrequency =
//                    scalingFactor * (1.0 - (offsetFrequency / unscaledFrequency));
//            break;
        case 3 :
            if (unscaledFrequency)
                preScaledFrequency =
                    scalingFactor * (1.0 - ((offsetFrequency * offsetFrequency) / (unscaledFrequency * unscaledFrequency)));
            break;
        default :
            break;
    }
    return preScaledFrequency;
}                                       // end of QCOM_PreScaleFrequency()
//----------------------------------------------------------------------------
// QCOM_SolveMatrix
//
// Solves the specified non-positive definite triangular matrix using
// LDLT-decomposition (LDLt), and returns the resulting solution vector
//
// Returns: 0           Success
//          nonzero     Failure
//
// Called by:   QCOM_PolynomialFit
//----------------------------------------------------------------------------
    DWORD
QCOM_SolveMatrix(
    double          **matrix,
    double          *LHVector,
    int             numberOfRows,
    double          *solutionVector)
{
    double          *eigenPtr;
    double          *eigenVector;
    double          *matrixRowIndex;
    double          *matrixPtr;
    double          *matrixColumnIndex;
    DWORD           status = QCOM_SUCCESS;
    //------------------------------------------------------------------------
    if (matrix && LHVector && solutionVector)
    {
        eigenVector = (double *) malloc(numberOfRows * sizeof(double));
        if (eigenVector)
        {
            ClearBuffer(eigenVector, numberOfRows * sizeof(double));
            matrixPtr = *matrix;
            if (*matrixPtr)
            {
                eigenPtr = eigenVector;
                *eigenPtr = 1.0 / *matrixPtr;
                for (int row = 1; row < numberOfRows; row++)
                {
                    *matrix[row] *= *eigenPtr;
                }
                for (int row = 1; row < numberOfRows; row++)
                {
                    matrixPtr = matrix[row];
                    matrixRowIndex = matrixPtr + row;
                    for (int column = 0; column < row; column++)
                    {
                        *matrixRowIndex -=
                            (matrix[column][column] * matrixPtr[column] * matrixPtr[column]);
                    }
                    if (*matrixRowIndex)
                    {
                        *(++eigenPtr) = 1.0 / *matrixRowIndex;
                        for (int column = row + 1; column < numberOfRows; column++)
                        {
                            matrixColumnIndex = matrix[column];
                            matrixRowIndex = matrixColumnIndex + row;
                            for (int element = 0; element < row; element++)
                            {
                                *matrixRowIndex -=
                                    (matrix[element][element] * matrixPtr[element] * matrixColumnIndex[element]);
                            }
                            *matrixRowIndex *= *eigenPtr;
                        }
                    }
                    else
                        status = QCOM_ERROR_NATIVE_INVALID_MATRIX;
                }
                if (status == 0)
                {
                    //--------------------------------------------------------
                    // Reduce the column vector
                    //--------------------------------------------------------
                    for (int row = 1; row < numberOfRows; row++)
                    {
                        matrixPtr = matrix[row];
                        eigenPtr = LHVector + row;
                        for (int column = 0; column < row; column++)
                        {
                            *eigenPtr -= (matrixPtr[column] * LHVector[column]);
                        }
                    }
                    //--------------------------------------------------------
                    // Use substitution to arrive at a base set of solution
                    // values
                    //--------------------------------------------------------
                    for (int row = 0; row < numberOfRows; row++)
                    {
                        solutionVector[row]=  LHVector[row] * eigenVector[row];
                    }
                    for (int row = numberOfRows - 2; row >= 0; row--)
                    {
                        matrixPtr = solutionVector + row;
                        for (int column = row + 1; column < numberOfRows; column++)
                        {
                            *matrixPtr -= (solutionVector[column] * matrix[column][row]);
                        }
                    }
                }
            }
            else
                status = QCOM_ERROR_NATIVE_INVALID_MATRIX;
            free((void *) eigenVector);
        }
        else
            status = QCOM_ERROR_NATIVE_MEMORY_ALLOC_FAILED;
    }
    else
        status = QCOM_ERROR_NATIVE_INVALID_PARAMETER;
    return status;
}                                       // end of QCOM_SolveMatrix()
//----------------------------------------------------------------------------
// QCOM_TransposeCrossMatrix
//
// Crosses the transpose of the specified matrix of doubles with the matrix
// itself, resulting in a lower triangular matrix of doubles
//
//      | a b c d |    X    | a e j |    =    | p 0 0 |
//      | e f g h |         | b f k |         | q r 0 |
//      | j k m n |         | c g m |         | s t u |
//                          | d h n |
//
// Called by:   QCOM_PolynomialFit
//----------------------------------------------------------------------------
    void
QCOM_TransposeCrossMatrix(
    double          **originalMatrix,
    int             numberOfRows,
    int             numberOfColumns,
    double          **triangularMatrix)
{
    double          *rowPtr;
    //------------------------------------------------------------------------
    if (originalMatrix && numberOfRows && numberOfColumns && triangularMatrix)
    {
        for (int column = 0; column < numberOfColumns; column++, triangularMatrix++)
        {
            rowPtr = *triangularMatrix;
            for (int element = 0; element <= column; element++, rowPtr++)
            {
                *rowPtr = 0.0;
                int row = numberOfRows;
                while (row--)
                {
                    *rowPtr += (originalMatrix[row][column] * originalMatrix[row][element]);
                }
            }
        }
    }
}                                       // end of QCOM_TransposeCrossMatrix()
//----------------------------------------------------------------------------
// QCOM_VectorCrossMatrix
//
// Crosses the specified vector (array) of doubles with the specified matrix
// of doubles, which results in a new vector of doubles
//
//      | w x y z |    X    | a b |    =    | n m |
//                          | c d |
//                          | e f |
//                          | g h |
//
// Called by:   QCOM_PolynomialFit
//----------------------------------------------------------------------------
    void
QCOM_VectorCrossMatrix(
    double          *vector,
    double          **matrix,
    int             numberOfRows,
    int             numberOfColumns,
    double          *resultingVector)
{
    double          *vectorPtr;
    //------------------------------------------------------------------------
    if (vector && matrix && numberOfRows && numberOfColumns && resultingVector)
    {
        for (int column = 0; column < numberOfColumns; column++)
        {
            *resultingVector = 0.0;
            vectorPtr = vector;
            for (int row = 0; row < numberOfRows; row++)
            {
                *resultingVector += (*vectorPtr++ * matrix[row][column]);
            }
            resultingVector++;
        }
    }
}                                       // end of QCOM_VectorCrossMatrix()
//----------------------------------------------------------------------------
// QCOM_VectorCrossVector
//
// Crosses the specified column vector (array) of doubles with a row vector of
// doubles, which results in a symmetric matrix of doubles
//
//      | a |    X    | w x y z |    =    | e f g h |
//      | b |                             | f j k l |
//      | c |                             | g k p q |
//      | d |                             | h l q u |
//
// Called by:   QCOM_PolynomialFit
//----------------------------------------------------------------------------
    void
QCOM_VectorCrossVector(
    double          *rowVector,
    double          *columnVector,
    int             numberOfElements,
    int             rowOrder,
    int             columnOrder,
    double          **resultingMatrix)
{
    int             column;
    int             numberOfCoefficients;
    double          *matrixCurrentPtr;
    double          *matrixNextPtr;
    //------------------------------------------------------------------------
    if (rowVector && columnVector && numberOfElements && resultingMatrix)
    {
        numberOfCoefficients = (rowOrder + 1) * (columnOrder + 1);
        while (numberOfElements--)
        {
            matrixNextPtr = *resultingMatrix;
            *matrixNextPtr = 1.0;
            matrixCurrentPtr = matrixNextPtr + 1;
            for (column = 1; column <= columnOrder; column++)
            {
                *matrixCurrentPtr++ = (*matrixNextPtr++ * *columnVector);
            }
            matrixNextPtr = *resultingMatrix++;
            while (column++ < numberOfCoefficients)
            {
                *matrixCurrentPtr++ = (*matrixNextPtr++ * *rowVector);
            }
            rowVector++;
            columnVector++;
        }
    }
}                                       // end of QCOM_VectorCrossVector()
//----------------------------------------------------------------------------
// QCOM_VectorMinusVector
//
// Subtracts the values of one vector (array) of doubles from that of another,
// which results in a new vector of doubles
//
//      | w x y z |    -    | a b c d |    =    | p q r s |
//
// Called by:   QCOM_PolynomialFit
//----------------------------------------------------------------------------
    void
QCOM_VectorMinusVector(
    double          *minuendVector,
    double          *subtrahendVector,
    int             numberOfElements,
    double          *resultingVector)
{
    //------------------------------------------------------------------------
    if (minuendVector && subtrahendVector && numberOfElements && resultingVector)
    {
        while (numberOfElements--)
        {
            *resultingVector++ = (*minuendVector++ - *subtrahendVector++);
        }
    }
}                                       // end of QCOM_VectorMinusVector()
//----------------------------------------------------------------------------
#endif      // COEFFICIENT_CPP
//============================================================================
// End of Coefficient.cpp
//============================================================================
