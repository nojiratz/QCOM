//============================================================================
// Coefficient.h
//
// Header for Coefficient.cpp
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#pragma once
#ifndef     COEFFICIENT_H
#define     COEFFICIENT_H
//----------------------------------------------------------------------------
// Include appropriate headers
//----------------------------------------------------------------------------
#include    "GUI.h"
//----------------------------------------------------------------------------
// The following lines are only seen by Coefficient.cpp
//----------------------------------------------------------------------------
#ifdef      COEFFICIENT_CPP
//----------------------------------------------------------------------------
// Type definitions
//----------------------------------------------------------------------------
typedef
    struct _CoefficientParameters
        CoefficientParametersDef;
//----------------------------------------------------------------------------
// Numerical definitions
//----------------------------------------------------------------------------
#define     QCOM_MAXIMUM_NUMBER_OF_COEFFICIENTS                 25
#define     QCOM_CALIBRATION_TYPE_PRESSURE                      0x01
#define     QCOM_CALIBRATION_TYPE_TEMPERATURE                   0x02
#define     QCOM_ANALOG_FREQUENCY_MULTIPLIER                    256.0
#define     QCOM_UNIVERSAL_SCALE_FACTOR                         4096.0
#define     QCOM_NOMINAL_REFERENCE_FREQUENCY                    7200000.0
#define     QCOM_FREQUENCY_STEP                                 10000
#define     QCOM_NUMBER_OF_FREQUENCY_STEPS                      10
//----------------------------------------------------------------------------
// File processing error status
//----------------------------------------------------------------------------
#define     QCOM_ERROR_NATIVE_FILE_NOT_FOUND                    0x0080
#define     QCOM_ERROR_NATIVE_FILE_PATH_INVALID                 0x0081
#define     QCOM_ERROR_NATIVE_FILE_DATA_INVALID                 0x0082
#define     QCOM_ERROR_NATIVE_SN_INVALID                        (0x0100 | QCOM_ERROR_NATIVE_FILE_DATA_INVALID)
#define     QCOM_ERROR_NATIVE_CAL_TYPE_INVALID                  (0x0200 | QCOM_ERROR_NATIVE_FILE_DATA_INVALID)
#define     QCOM_ERROR_NATIVE_TSF_INVALID                       (0x1200 | QCOM_ERROR_NATIVE_FILE_DATA_INVALID)
#define     QCOM_ERROR_NATIVE_PSF_INVALID                       (0x2200 | QCOM_ERROR_NATIVE_FILE_DATA_INVALID)
#define     QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH                0x0083
#define     QCOM_ERROR_NATIVE_SN_MISMATCH                       (0x0100 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_CAL_TYPE_MISMATCH                 (0x0200 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_CAL_UNITS_MISMATCH                (0x0300 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_TFO_MISMATCH                      (0x1000 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_TALG_MISMATCH                     (0x1100 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_TSF_MISMATCH                      (0x1200 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_TOF_MISMATCH                      (0x1300 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_PFO_MISMATCH                      (0x2000 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_PALG_MISMATCH                     (0x2100 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_PSF_MISMATCH                      (0x2200 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_POF_MISMATCH                      (0x2300 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_COEFF_MISMATCH                    (0x3000 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_SPAN_MISMATCH                     (0x4000 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_ZERO_MISMATCH                     (0x4100 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_MINT_MISMATCH                     (0x5000 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_MAXT_MISMATCH                     (0x5100 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_MINP_MISMATCH                     (0x5200 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_MAXP_MISMATCH                     (0x5300 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_DATE_MISMATCH                     (0x6000 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_PN_MISMATCH                       (0x7000 | QCOM_ERROR_NATIVE_FILE_DATA_MISMATCH)
#define     QCOM_ERROR_NATIVE_MEMORY_ALLOC_FAILED               0x0084
#define     QCOM_ERROR_NATIVE_INVALID_PARAMETER                 0x0085
#define     QCOM_ERROR_NATIVE_INVALID_MATRIX                    0x0086
//----------------------------------------------------------------------------
// Coefficient file types
//----------------------------------------------------------------------------
#define     QCOM_CF_FILE_TYPE_UNKNOWN                           0
#define     QCOM_CF_FILE_TYPE_HEX                               1
#define     QCOM_CF_FILE_TYPE_CRF                               2
#define     QCOM_CF_FILE_TYPE_CRT                               3
#define     QCOM_CF_FILE_TYPE_CFF                               4
#define     QCOM_CF_FILE_TYPE_CFT                               5
#define     QCOM_CF_FILE_TYPE_COF2                              6
//----------------------------------------------------------------------------
// Native coefficient file parameter identifiers
//----------------------------------------------------------------------------
#define     QCOM_NCF_PARAMETER_SENSOR_ID                        0
#define     QCOM_NCF_PARAMETER_CAL_TYPE                         1
#define     QCOM_NCF_PARAMETER_CAL_UNITS                        2
#define     QCOM_NCF_PARAMETER_TEMP_POLY_ORDER                  3
#define     QCOM_NCF_PARAMETER_TEMP_PRESCALE                    4
#define     QCOM_NCF_PARAMETER_TEMP_SCALE_FACTOR                5
#define     QCOM_NCF_PARAMETER_TEMP_OFFSET_FREQ                 6
#define     QCOM_NCF_PARAMETER_PRES_POLY_ORDER                  7
#define     QCOM_NCF_PARAMETER_PRES_PRESCALE                    8
#define     QCOM_NCF_PARAMETER_PRES_SCALE_FACTOR                9
#define     QCOM_NCF_PARAMETER_PRES_OFFSET_FREQ                 10
#define     QCOM_NCF_PARAMETER_COEFF_0                          11
#define     QCOM_NCF_PARAMETER_COEFF_1                          12
#define     QCOM_NCF_PARAMETER_COEFF_2                          13
#define     QCOM_NCF_PARAMETER_COEFF_3                          14
#define     QCOM_NCF_PARAMETER_COEFF_4                          15
#define     QCOM_NCF_PARAMETER_COEFF_5                          16
#define     QCOM_NCF_PARAMETER_COEFF_6                          17
#define     QCOM_NCF_PARAMETER_COEFF_7                          18
#define     QCOM_NCF_PARAMETER_COEFF_8                          19
#define     QCOM_NCF_PARAMETER_COEFF_9                          20
#define     QCOM_NCF_PARAMETER_COEFF_10                         21
#define     QCOM_NCF_PARAMETER_COEFF_11                         22
#define     QCOM_NCF_PARAMETER_COEFF_12                         23
#define     QCOM_NCF_PARAMETER_COEFF_13                         24
#define     QCOM_NCF_PARAMETER_COEFF_14                         25
#define     QCOM_NCF_PARAMETER_COEFF_15                         26
#define     QCOM_NCF_PARAMETER_COEFF_16                         27
#define     QCOM_NCF_PARAMETER_COEFF_17                         28
#define     QCOM_NCF_PARAMETER_COEFF_18                         29
#define     QCOM_NCF_PARAMETER_COEFF_19                         30
#define     QCOM_NCF_PARAMETER_COEFF_20                         31
#define     QCOM_NCF_PARAMETER_COEFF_21                         32
#define     QCOM_NCF_PARAMETER_COEFF_22                         33
#define     QCOM_NCF_PARAMETER_COEFF_23                         34
#define     QCOM_NCF_PARAMETER_COEFF_24                         35
#define     QCOM_NCF_PARAMETER_SPAN                             36
#define     QCOM_NCF_PARAMETER_ZERO                             37
#define     QCOM_NCF_PARAMETER_TEMP_MIN                         38
#define     QCOM_NCF_PARAMETER_TEMP_MAX                         39
#define     QCOM_NCF_PARAMETER_PRES_MIN                         40
#define     QCOM_NCF_PARAMETER_PRES_MAX                         41
#define     QCOM_NCF_PARAMETER_CAL_DATE                         42
#define     QCOM_NCF_PARAMETER_XD_MODEL                         43
//----------------------------------------------------------------------------
// Hex coefficient file parameter identifiers
//----------------------------------------------------------------------------
#define     QCOM_HCF_PARAMETER_XD_SERIAL_NUMBER                 0
#define     QCOM_HCF_PARAMETER_XD_MODEL                         1
#define     QCOM_HCF_PARAMETER_CAL_DATE                         2
#define     QCOM_HCF_PARAMETER_PRES_MIN                         3
#define     QCOM_HCF_PARAMETER_PRES_MAX                         4
#define     QCOM_HCF_PARAMETER_TEMP_MIN                         5
#define     QCOM_HCF_PARAMETER_TEMP_MAX                         6
#define     QCOM_HCF_PARAMETER_PRIMARY_CAL_TYPE                 7
#define     QCOM_HCF_PARAMETER_PRES_PRESCALE_TYPE               8
#define     QCOM_HCF_PARAMETER_PRES_POLY_ORDER_PRES             9
#define     QCOM_HCF_PARAMETER_PRES_POLY_ORDER_TEMP             10
#define     QCOM_HCF_PARAMETER_PRES_SCALE_FACTOR_STD            11
#define     QCOM_HCF_PARAMETER_PRES_SCALE_FACTOR_ALT            12
#define     QCOM_HCF_PARAMETER_PRES_ALT_OFFSET                  13
#define     QCOM_HCF_PARAMETER_PRES_COEFF_0                     14
#define     QCOM_HCF_PARAMETER_PRES_COEFF_1                     15
#define     QCOM_HCF_PARAMETER_PRES_COEFF_2                     16
#define     QCOM_HCF_PARAMETER_PRES_COEFF_3                     17
#define     QCOM_HCF_PARAMETER_PRES_COEFF_4                     18
#define     QCOM_HCF_PARAMETER_PRES_COEFF_5                     19
#define     QCOM_HCF_PARAMETER_PRES_COEFF_6                     20
#define     QCOM_HCF_PARAMETER_PRES_COEFF_7                     21
#define     QCOM_HCF_PARAMETER_PRES_COEFF_8                     22
#define     QCOM_HCF_PARAMETER_PRES_COEFF_9                     23
#define     QCOM_HCF_PARAMETER_PRES_COEFF_10                    24
#define     QCOM_HCF_PARAMETER_PRES_COEFF_11                    25
#define     QCOM_HCF_PARAMETER_PRES_COEFF_12                    26
#define     QCOM_HCF_PARAMETER_PRES_COEFF_13                    27
#define     QCOM_HCF_PARAMETER_PRES_COEFF_14                    28
#define     QCOM_HCF_PARAMETER_PRES_COEFF_15                    29
#define     QCOM_HCF_PARAMETER_PRES_COEFF_16                    30
#define     QCOM_HCF_PARAMETER_PRES_COEFF_17                    31
#define     QCOM_HCF_PARAMETER_PRES_COEFF_18                    32
#define     QCOM_HCF_PARAMETER_PRES_COEFF_19                    33
#define     QCOM_HCF_PARAMETER_PRES_COEFF_20                    34
#define     QCOM_HCF_PARAMETER_PRES_COEFF_21                    35
#define     QCOM_HCF_PARAMETER_PRES_COEFF_22                    36
#define     QCOM_HCF_PARAMETER_PRES_COEFF_23                    37
#define     QCOM_HCF_PARAMETER_PRES_COEFF_24                    38
#define     QCOM_HCF_PARAMETER_SECONDARY_CAL_TYPE               39
#define     QCOM_HCF_PARAMETER_TEMP_PRESCALE_TYPE               40
#define     QCOM_HCF_PARAMETER_TEMP_POLY_ORDER_PRES             41
#define     QCOM_HCF_PARAMETER_TEMP_POLY_ORDER_TEMP             42
#define     QCOM_HCF_PARAMETER_TEMP_SCALE_FACTOR_STD            43
#define     QCOM_HCF_PARAMETER_TEMP_SCALE_FACTOR_ALT            44
#define     QCOM_HCF_PARAMETER_TEMP_ALT_OFFSET                  45
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_0                     46
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_1                     47
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_2                     48
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_3                     49
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_4                     50
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_5                     51
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_6                     52
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_7                     53
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_8                     54
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_9                     55
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_10                    56
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_11                    57
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_12                    58
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_13                    59
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_14                    60
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_15                    61
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_16                    62
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_17                    63
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_18                    64
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_19                    65
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_20                    66
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_21                    67
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_22                    68
#define     QCOM_HCF_PARAMETER_TEMP_COEFF_23                    69
//----------------------------------------------------------------------------
// Internal function prototypes
//----------------------------------------------------------------------------
String          ^QCOM_BuildCoefficientDataLine(
                    char            *line,
                    int             index);
double          QCOM_Calculate2DimensionalPolynomial(
                    double          **polynomialMatrix,
                    double          rowValue,
                    double          columnValue,
                    int             rowOrder,
                    int             columnOrder);
int             QCOM_ExtractSerialNumberFromCoefficientData(
                    CoefficientFormatDef
                                    *format,
                    char            *transducerSerialNumber);
DWORD           QCOM_FormulateNativeCoefficients(
                    CoefficientFormatDef
                                    *format,
                    CoefficientParametersDef
                                    *parameters);
void            QCOM_MatrixCrossVector(
                    double          **matrix,
                    double          *vector,
                    int             numberOfRows,
                    int             numberOfColumns,
                    double          *resultingVector);
double          QCOM_PreScaleFrequency(
                    double          unscaledFrequency,
                    double          scalingFactor,
                    double          offsetFrequency,
                    int             scalingAlgorithm);
DWORD           QCOM_PolynomialFit(
                    double          *pressurefrequencyVector,
                    double          *temperaturefrequencyVector,
                    double          *trueValueVector,
                    double          *residualVector,
                    int             numberOfElements,
                    int             pressurePolynomialOrder,
                    int             temperaturePolynomialOrder,
                    double          *coefficientVector);
DWORD           QCOM_SolveMatrix(
                    double          **matrix,
                    double          *LHVector,
                    int             numberOfRows,
                    double          *solutionVector);
void            QCOM_TransposeCrossMatrix(
                    double          **originalMatrix,
                    int             numberOfRows,
                    int             numberOfColumns,
                    double          **triangularMatrix);
void            QCOM_VectorCrossMatrix(
                    double          *vector,
                    double          **matrix,
                    int             numberOfRows,
                    int             numberOfColumns,
                    double          *resultingVector);
void            QCOM_VectorCrossVector(
                    double          *rowVector,
                    double          *columnVector,
                    int             numberOfElements,
                    int             rowOrder,
                    int             columnOrder,
                    double          **resultingMatrix);
void            QCOM_VectorMinusVector(
                    double          *minuendVector,
                    double          *subtrahendVector,
                    int             numberOfElements,
                    double          *resultingVector);
//----------------------------------------------------------------------------
// Coefficient parameters structure
//----------------------------------------------------------------------------
struct _CoefficientParameters
{
    int         numberOfPressureCoefficients;
    int         numberOfTemperatureCoefficients;
    double      pressureScalingFactor;
    double      pressureSpan;
    double      pressureZero;
    double      temperatureScalingFactor;
    double      temperatureSpan;
    double      temperatureZero;
    double      pressureInputCoefficients[QCOM_MAXIMUM_NUMBER_OF_COEFFICIENTS];
    double      temperatureInputCoefficients[QCOM_MAXIMUM_NUMBER_OF_COEFFICIENTS];
    DWORD       pressureOffsetFrequency;
    DWORD       temperatureOffsetFrequency;
};                                      // end of struct _CoefficientParameters
//----------------------------------------------------------------------------
// End of the lines that are only seen by Coefficient.cpp
//----------------------------------------------------------------------------
#endif      // COEFFICIENT_CPP
#endif      // COEFFICIENT_H
//============================================================================
// End of Coefficient.h
//============================================================================
