//============================================================================
// CoefficientEvents.cpp
//
// The event methods used by Coefficient.cpp for tasks related to the reading,
// searching, downloading, and displaying of coefficient files and their data
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     COEFFICIENTEVENTS_CPP
#define     COEFFICIENTEVENTS_CPP
#include    "CoefficientEvents.h"
//----------------------------------------------------------------------------
// QCOM_CloseCFWindow
//
// Event that closes the Coefficient Data Display window
//
// Called by:   QCOM_DisplayLoadedCoefficientData
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_CloseCFWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_CloseCFWindow");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Display Coefficient Data window closed for module {0}",
            unit->moduleSerialNumber);
        displayCFDataWindowArray[unitNumber]->Close();
    }
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_CloseCFWindow()
//----------------------------------------------------------------------------
// QCOM_CloseRawCFWindow
//
// Event that closes the raw coefficient data display window
//
// Called by:   QCOM_DisplayRawCoefficientData
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_CloseRawCFWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_CloseRawCFWindow");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Display Raw Coefficient Data window closed for module {0}",
            unit->moduleSerialNumber);
        displayRawCFDataWindowArray[unitNumber]->Close();
    }
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_CloseRawCFWindow()
//----------------------------------------------------------------------------
// QCOM_DisplayHexCFParametersButtonClicked
//
// Handles the click of the Display Hex Coefficient File Parameters button
//
// Called by:   QCOM_PromptForRetrieveCoefficientFileParameters
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayHexCFParametersButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^filePathString = (String ^) (dynamic_cast <Button ^> (sender))->Tag;
    //------------------------------------------------------------------------
    RecordBasicEvent("Display Hex Coefficient File Parameters button clicked");
    QCOM_DisplayHexCFParameters(
        filePathString,
        GUI_SECONDARY_DISPLAY);
}                                       // end of QCOM_DisplayHexCFParametersButtonClicked()
//----------------------------------------------------------------------------
// QCOM_DisplayHexCFParametersCloseWindow
//
// Event that closes the Hex Coefficient File Parameters display window
//
// Called by:   QCOM_PromptForRetrieveCoefficientFileParameters
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayHexCFParametersCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Hex Coefficient File Parameters window closed");
    displayHexCFParametersWindow->Close();
}                                       // end of QCOM_DisplayHexCFParametersCloseWindow()
//----------------------------------------------------------------------------
// QCOM_DisplayLoadedCoefficientDataButtonClicked
//
// Handles the click of the Display Coefficient Data button by displaying a
// new window that is populated with coefficient data information
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//
// Note:    The coefficient data is not checked for validity, so it's possible
//          to display an all-zero data set
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayLoadedCoefficientDataButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DisplayLoadedCoefficientDataButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Display Coefficient Data button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_DisplayLoadedCoefficientData(unit);
    }
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DisplayLoadedCoefficientDataButtonClicked()
//----------------------------------------------------------------------------
// QCOM_DisplayNativeCFParametersCloseWindow
//
// Event that closes the Native Coefficient File Parameters display window
//
// Called by:   QCOM_PromptForRetrieveCoefficientFileParameters
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayNativeCFParametersCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Native Coefficient File Parameters window closed");
    displayNativeCFParametersWindow->Close();
}                                       // end of QCOM_DisplayNativeCFParametersCloseWindow()
//----------------------------------------------------------------------------
// QCOM_DisplayNativeNonRefCFParametersButtonClicked
//
// Handles the click of the Display Native Non-ref Coefficient File Parameters
// button
//
// Called by:   QCOM_PromptForRetrieveCoefficientFileParameters
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayNativeNonRefCFParametersButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^filePathString = (String ^) (dynamic_cast <Button ^> (sender))->Tag;
    //------------------------------------------------------------------------
    RecordBasicEvent("Display Native Non-ref Coefficient File Parameters button clicked");
    QCOM_DisplayNativeCFParameters(
        filePathString,
        GUI_SECONDARY_DISPLAY);
}                                       // end of QCOM_DisplayNativeNonRefCFParametersButtonClicked()
//----------------------------------------------------------------------------
// QCOM_DisplayNativeRefCFParametersButtonClicked
//
// Handles the click of the Display Native Ref Coefficient File Parameters
// button
//
// Called by:   QCOM_PromptForRetrieveCoefficientFileParameters
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayNativeRefCFParametersButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^filePathString = (String ^) (dynamic_cast <Button ^> (sender))->Tag;
    //------------------------------------------------------------------------
    RecordBasicEvent("Display Native Ref Coefficient File Parameters button clicked");
    QCOM_DisplayNativeCFParameters(
        filePathString,
        GUI_SECONDARY_DISPLAY);
}                                       // end of QCOM_DisplayNativeRefCFParametersButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ExpertEraseCoefficientDataButtonClicked
//
// Handles the click of the Erase Coefficient Data button
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertEraseCoefficientDataButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_ExpertEraseCoefficientDataButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Erase Coefficient Data button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_EraseCoefficientDataFromDevice(unit);
    }
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_ExpertEraseCoefficientDataButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ExpertManageMultipleCoefficientDataButtonClicked
//
// Handles the click of the Manage Multiple Coefficient Data Storage button
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertManageMultipleCoefficientDataButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_ExpertManageMultipleCoefficientDataButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Manage Multiple Coefficient Data Storage button clicked for module {0}",
            unit->moduleSerialNumber);
        if (multipleCoefficientDataWindowArray[unitNumber]->WindowState == FormWindowState::Minimized)
            multipleCoefficientDataWindowArray[unitNumber]->WindowState = FormWindowState::Normal;
        else
            multipleCoefficientDataWindowArray[unitNumber]->Show();
        multipleCoefficientDataWindowArray[unitNumber]->BringToFront();
        if (multipleCoefficientDataWindowArray[unitNumber]->CanFocus)
            multipleCoefficientDataWindowArray[unitNumber]->Focus();
        if (multipleCoefficientDataWindowArray[unitNumber]->CanSelect)
            multipleCoefficientDataWindowArray[unitNumber]->Select();
        QCOM_UpdateMultipleCoefficientWindow(unit);
    }
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_ExpertManageMultipleCoefficientDataButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ExportCoefficientDataFileButtonClicked
//
// Handles the click of the Export Coefficient Data File button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExportCoefficientDataFileButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_ExportCoefficientDataFileButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Export Coefficient Data File button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_ExportCoefficientDataToFile(unit);
    }
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_ExportCoefficientDataFileButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientCloseWindow
//
// Event that closes the unit Multiple Coefficient Storage window by hiding it
//
// Called by:   QCOM_SetUpUnitMultipleCoefficientWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_MultipleCoefficientCloseWindow");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Multiple Coefficient Storage Management window closed for module {0}",
            unit->moduleSerialNumber);
        multipleCoefficientDataWindowArray[unitNumber]->Hide();
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MultipleCoefficientCloseWindow()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientClosingWindow
//
// Handles the closing of the unit multiple coefficient storage window by the
// red X or similar method
//
// Called by:   QCOM_SetUpUnitMultipleCoefficientWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Form ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_MultipleCoefficientClosingWindow");
    //------------------------------------------------------------------------
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Multiple Coefficient Storage Management window closing for module {0}",
            unit->moduleSerialNumber);
        multipleCoefficientDataWindowArray[unitNumber]->Hide();
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MultipleCoefficientClosingWindow()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientModuleClearButtonClicked
//
// Handles the click of the unit multiple coefficient storage module
// Clear button
//
// Called by:   QCOM_SetUpUnitMultipleCoefficientWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientModuleClearButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    BYTE            slotNumber = ((unitNumber >> 8) & 0xFF);
    String          ^functionName = _T("QCOM_MultipleCoefficientModuleClearButtonClicked");
    //------------------------------------------------------------------------
    unitNumber &= 0xFF;
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D} slot {2:D}) called",
            functionName, unitNumber, slotNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Multiple Coefficient Storage Management module {0} slot {1:D} Clear clicked",
            unit->moduleSerialNumber, slotNumber);
        QCOM_MultipleCoefficientModuleClearSlot(unit, slotNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MultipleCoefficientModuleClearButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientModuleCopyButtonClicked
//
// Handles the click of the unit multiple coefficient storage module Copy
// button, and copies the coefficient data from the module to the transducer
//
// Called by:   QCOM_SetUpUnitMultipleCoefficientWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientModuleCopyButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    BYTE            slotNumber = ((unitNumber >> 8) & 0xFF);
    String          ^functionName = _T("QCOM_MultipleCoefficientModuleCopyButtonClicked");
    //------------------------------------------------------------------------
    unitNumber &= 0xFF;
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D} slot {2:D}) called",
            functionName, unitNumber, slotNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Multiple Coefficient Storage Management module {0} slot {1:D} Copy clicked",
            unit->moduleSerialNumber, slotNumber);
        QCOM_MultipleCoefficientModuleCopyToTransducer(unit, slotNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MultipleCoefficientModuleCopyButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientModuleUpdateButtonClicked
//
// Handles the click of the unit multiple coefficient storage module Update
// button
//
// Called by:   QCOM_SetUpUnitMultipleCoefficientWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientModuleUpdateButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    BYTE            slotNumber = ((unitNumber >> 8) & 0xFF);
    String          ^functionName = _T("QCOM_MultipleCoefficientModuleUpdateButtonClicked");
    //------------------------------------------------------------------------
    unitNumber &= 0xFF;
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D} slot {2:D}) called",
            functionName, unitNumber, slotNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Multiple Coefficient Storage Management module {0} slot {1:D} Update clicked",
            unit->moduleSerialNumber, slotNumber);
        QCOM_MultipleCoefficientModuleLoadSlot(unit, slotNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MultipleCoefficientModuleUpdateButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientModuleVerifyButtonClicked
//
// Handles the click of the unit multiple coefficient storage module Verify
// button
//
// Called by:   QCOM_SetUpUnitMultipleCoefficientWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientModuleVerifyButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    BYTE            slotNumber = ((unitNumber >> 8) & 0xFF);
    String          ^functionName = _T("QCOM_MultipleCoefficientModuleVerifyButtonClicked");
    //------------------------------------------------------------------------
    unitNumber &= 0xFF;
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D} slot {2:D}) called",
            functionName, unitNumber, slotNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Multiple Coefficient Storage Management module {0} slot {1:D} Verify clicked",
            unit->moduleSerialNumber, slotNumber);
        QCOM_MultipleCoefficientModuleVerifySlot(unit, slotNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MultipleCoefficientModuleVerifyButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientTransducerClearButtonClicked
//
// Handles the click of the unit multiple coefficient storage transducer
// Clear button
//
// Called by:   QCOM_SetUpUnitMultipleCoefficientWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientTransducerClearButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    BYTE            slotNumber = ((unitNumber >> 8) & 0xFF);
    String          ^functionName = _T("QCOM_MultipleCoefficientTransducerClearButtonClicked");
    //------------------------------------------------------------------------
    unitNumber &= 0xFF;
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D} slot {2:D}) called",
            functionName, unitNumber, slotNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Multiple Coefficient Storage Management transducer {0} slot {1:D} Clear clicked",
            unit->transducerSerialNumber, slotNumber);
        QCOM_MultipleCoefficientTransducerClearSlot(unit, slotNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MultipleCoefficientTransducerClearButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientTransducerCopyButtonClicked
//
// Handles the click of the unit multiple coefficient storage transducer Copy
// button, and copies the coefficient data from the transducer to the module
//
// Called by:   QCOM_SetUpUnitMultipleCoefficientWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientTransducerCopyButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    BYTE            slotNumber = ((unitNumber >> 8) & 0xFF);
    String          ^functionName = _T("QCOM_MultipleCoefficientTransducerCopyButtonClicked");
    //------------------------------------------------------------------------
    unitNumber &= 0xFF;
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D} slot {2:D}) called",
            functionName, unitNumber, slotNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Multiple Coefficient Storage Management module {0} transducer {1} slot {2:D} Copy clicked",
            unit->moduleSerialNumber, unit->transducerSerialNumber, slotNumber);
        QCOM_MultipleCoefficientTransducerCopyToModule(unit, slotNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MultipleCoefficientTransducerCopyButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientTransducerUpdateButtonClicked
//
// Handles the click of the unit multiple coefficient storage transducer
// Update button
//
// Called by:   QCOM_SetUpUnitMultipleCoefficientWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientTransducerUpdateButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    BYTE            slotNumber = ((unitNumber >> 8) & 0xFF);
    String          ^functionName = _T("QCOM_MultipleCoefficientTransducerUpdateButtonClicked");
    //------------------------------------------------------------------------
    unitNumber &= 0xFF;
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D} slot {2:D}) called",
            functionName, unitNumber, slotNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Multiple Coefficient Storage Management module {0} transducer {1} slot {2:D} Update clicked",
            unit->moduleSerialNumber, unit->transducerSerialNumber, slotNumber);
        QCOM_MultipleCoefficientTransducerLoadSlot(unit, slotNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MultipleCoefficientTransducerUpdateButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MultipleCoefficientTransducerVerifyButtonClicked
//
// Handles the click of the unit multiple coefficient storage transducer
// Verify button
//
// Called by:   QCOM_SetUpUnitMultipleCoefficientWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MultipleCoefficientTransducerVerifyButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    BYTE            slotNumber = ((unitNumber >> 8) & 0xFF);
    String          ^functionName = _T("QCOM_MultipleCoefficientTransducerVerifyButtonClicked");
    //------------------------------------------------------------------------
    unitNumber &= 0xFF;
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D} slot {2:D}) called",
            functionName, unitNumber, slotNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Multiple Coefficient Storage Management transducer {0} slot {1:D} Verify clicked",
            unit->transducerSerialNumber, slotNumber);
        QCOM_MultipleCoefficientTransducerVerifySlot(unit, slotNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MultipleCoefficientTransducerVerifyButtonClicked()
//----------------------------------------------------------------------------
// QCOM_UtilConvertNativeCoefficientFileSetButtonClicked
//
// Handles the click of the Convert an Native Coefficient File button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertNativeCoefficientFileSetButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Convert Native Coefficient File Set button clicked");
    QCOM_ConvertNativeCoefficientFileSet();
}                                       // end of QCOM_UtilConvertNativeCoefficientFileSetButtonClicked()
//----------------------------------------------------------------------------
// QCOM_UtilDisplayTCCheckButtonClicked
//
// Handles the click of the Coefficient Check button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilDisplayTCCheckButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_UtilDisplayTCCheckButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Coefficient Check button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_DisplayTCCheck(unit);
    }
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_UtilDisplayTCCheckButtonClicked()
//----------------------------------------------------------------------------
// QCOM_UtilDownloadCoefficientFilesButtonClicked
//
// Handles the click of the Download Coefficient Files button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilDownloadCoefficientFilesButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Download Coefficient Files button clicked");
    QCOM_PromptForDownloadCoefficientFiles();
}                                       // end of QCOM_UtilDownloadCoefficientFilesButtonClicked()
//----------------------------------------------------------------------------
// QCOM_UtilImportCoefficientDataFileButtonClicked
//
// Handles the click of the Import Coefficient Data File button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilImportCoefficientDataFileButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_UtilImportCoefficientDataFileButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Import Coefficient Data button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_PromptForImportCoefficientDataFromFile(unit);
    }
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_UtilImportCoefficientDataFileButtonClicked()
//----------------------------------------------------------------------------
// QCOM_UtilRetrieveCoefficientFileParametersButtonClicked
//
// Handles the click of the Retrieve Coefficient File Parameter button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilRetrieveCoefficientFileParametersButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Retrieve Coefficient File Parameters button clicked");
    QCOM_PromptForRetrieveCoefficientFileParameters();
}                                       // end of QCOM_UtilRetrieveCoefficientFileParametersButtonClicked()
//----------------------------------------------------------------------------
#endif      // COEFFICIENTEVENTS_CPP
//============================================================================
// End of CoefficientEvents.cpp
//============================================================================
