﻿//============================================================================
// Device.cpp
//
// The methods used by the QCOM software for device-related tasks
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     DEVICE_CPP
#define     DEVICE_CPP
#include    "Device.h"
//----------------------------------------------------------------------------
// QCOM_CloseUnit
//
// Closes the specified unit for I/O
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_CloseUnit(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_CloseUnit");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordVerboseEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (HandleIsValid(unit->unitHandle))
        {
            QD_Close(unit->unitHandle);
            RecordVerboseEvent("    Unit {0:D} is now closed", unit->unitNumber);
        }
        else
        {
            RecordVerboseEvent("    Unit {0:D} is already closed", unit->unitNumber);
        }
        //--------------------------------------------------------------------
        // Silicon Labs AN169 Rev 1.8 Appendix F indicates that the calling
        // application must set the handle value to INVALID_HANDLE_VALUE
        //--------------------------------------------------------------------
        unit->unitHandle = INVALID_HANDLE_VALUE;
        unit->flags &= ~QCOM_UNIT_OPEN;
        RecordVerboseEvent("{0} concluded", functionName);
    }
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_CloseUnit()
//----------------------------------------------------------------------------
// QCOM_GetModuleInfo
//
// Retrieves the serial number of the specified module, determines whether the
// module is currently in Bootloader mode, and sets the appropriate flags as a
// result
//
// Note:    This function cannot assume that the device is open
//
// Called by:   QCOM_ReScanModules
//              QCOM_ScanForDevices
//              QCOM_SwitchToBootLoaderMode
//              QCOM_SwitchFromBootLoaderMode
//              QCOM_TestSuiteFirmware
//              QCOM_UpdateModuleFirmware
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GetModuleInfo(
    UnitInfo        ^unit)
{
    DWORD           status;
    char            *moduleSerialNumber;
    char            *productInfo;
    String          ^functionName = _T("QCOM_GetModuleInfo");
    //------------------------------------------------------------------------
    if (unit)
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        moduleSerialNumber = (char *) malloc(QCOM_MAXIMUM_SERIAL_NUMBER_SIZE);
        productInfo = (char *) malloc(QD_MAXIMUM_PRODUCT_STRING_SIZE);
        if (moduleSerialNumber && productInfo)
        {
            ClearBuffer(moduleSerialNumber, QCOM_MAXIMUM_SERIAL_NUMBER_SIZE);
            status = QD_GetModuleSerialNumber(
                unit->physicalUnitNumber,
                (LPBYTE) moduleSerialNumber);
            if (status == QD_SUCCESS)
            {
                unit->moduleSerialNumber = gcnew String(moduleSerialNumber);
                ModuleTransducerPair ^unitPair = QCOM_ModuleTransducerPairArray[unit->unitNumber];
                if (unitPair)
                {
                    unitPair->newModuleSerialNumber = unit->moduleSerialNumber;
                }
                unit->flags |= QCOM_UNIT_MODULE_SN_VALID;
                RecordVerboseEvent("    Module serial number {0} found for unit {1:D}",
                    unit->moduleSerialNumber, unit->physicalUnitNumber);
                status = QD_GetProductInfo(
                    unit->physicalUnitNumber,
                    (LPBYTE) productInfo,
                    QD_RETURN_PID);
                if (status == QD_SUCCESS)
                {
                    String ^productInfoString = gcnew String(productInfo);
                    RecordVerboseEvent("    Module {0} has PID {1}",
                        unit->moduleSerialNumber, productInfoString);
                    if (StringICompare(productInfoString, QCOM_PRODUCT_ID_STRING) == 0)
                    {
                        //----------------------------------------------------
                        // Confirmed that this hardware is a QCOM module
                        //----------------------------------------------------
                        unit->flags |= QCOM_UNIT_VALID;
                        QCOM_GeneralInfo->validUnitBitMap |= (0x00000001 << unit->unitNumber);
                        RecordVerboseEvent("    Module {0} is a QCOM device",
                            unit->moduleSerialNumber);
                        if (unit->moduleSerialNumber->EndsWith("~"))
                            unit->flags |= QCOM_UNIT_BOOT_LOADER_MODE;
                        else
                            unit->flags &= ~QCOM_UNIT_BOOT_LOADER_MODE;
                        unit->moduleMemorySize = 8192;          // hard-code for now
                        unit->numberOfModuleMemoryPages =
                            unit->moduleMemorySize / QCOM_COEFFICIENT_DATA_SIZE;
                        RecordVerboseEvent("    Module {0} {1} in Boot Loader Mode",
                            unit->moduleSerialNumber,
                            ((unit->flags & QCOM_UNIT_BOOT_LOADER_MODE) ? "is" : "is not"));
                    }                       // end of if (StringICompare(gcnew String(productInfoString), QCOM_PRODUCT_ID_STRING) == 0)
                    else
                    {
                        if ((StringICompare(productInfoString, CMUX_PRODUCT_ID_STRING) == 0) ||
                            (StringICompare(productInfoString, CMUX_OLD_PRODUCT_ID_STRING) == 0))
                        {
                            //----------------------------------------------------
                            // This device is a Calibration USB mux box
                            //----------------------------------------------------
                            RecordVerboseEvent("    Module {0} is a Calibration Mux Box device",
                                unit->moduleSerialNumber);
                            unit->flags |= QCOM_UNIT_CMUX_BOX;
                        }
                        else
                        {
                            GUI_DisplayMandatoryError(
                                "Unknown Device Found",
                                "A unknown device with VID = {0} and PID = {1} is found for unit {2:D}",
                                QCOM_VENDOR_ID_STRING,
                                productInfoString,
                                unit->physicalUnitNumber);
                        }
                    }
                    delete productInfoString;
                }                       // end of if (status == QD_SUCCESS)
                else
                {
                    unit->flags &= ~QCOM_UNIT_VALID;
                    unit->moduleSerialNumber = String::Empty;
                    unit->unitDescriptionString = String::Empty;
                    if (status == (QD_LOCUS_GET_PRODUCT_INFO | QD_LOCUS_GET_PRODUCT_INFO_3 | QD_ERROR_INVALID_PARAMETER))
                    {
                        RecordBasicEvent("    Unit {0:D} not present",
                            unit->physicalUnitNumber);
                    }
                    else
                    {
                        RecordErrorEvent("    QD_GetProductInfo resulted in status 0x{0:X8}",
                            status);
                    }
                }
            }                           // end of if (status == QD_SUCCESS)
            else
            {
                unit->flags &= ~QCOM_UNIT_VALID;
                unit->moduleSerialNumber = String::Empty;
                unit->unitDescriptionString = String::Empty;
                if (status == (QD_LOCUS_GET_MODULE_SERIAL_NUMBER | QD_LOCUS_GET_PRODUCT_INFO_3 | QD_ERROR_INVALID_PARAMETER))
                {
                    RecordBasicEvent("    Unit {0:D} not present",
                        unit->physicalUnitNumber);
                }
                else
                {
                    RecordErrorEvent("    QD_GetModuleSerialNumber resulted in status 0x{0:X8}",
                        status);
                }
            }
            free((void *) productInfo);
            free((void *) moduleSerialNumber);
        }                               // end of if (moduleSerialNumber && productInfo)
        else
        {
            unit->moduleSerialNumber = String::Empty;
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (unit)
    else
    {
        RecordBasicEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_GetModuleInfo()
//----------------------------------------------------------------------------
// QCOM_GetNumberOfTransducers
//
// Returns the number of physical transducers detected in the system
//
// Called by:   QCOM_ProgramTimerElapsed
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_GetNumberOfTransducers(void)
{
    BYTE            statusRegister = 0;
    DWORD           numberOfTransducers = 0;
    DWORD           status;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_GetNumberOfTransducers");
    //------------------------------------------------------------------------
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            bool spinLockAcquired = GUI_NO;
            try
            {
                QCOM_UnitAccessSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                status = QD_GetModuleStatusRegister(
                    unit->unitHandle,
                    (LPBYTE) &statusRegister);
                if (status == QD_SUCCESS)
                {
                    if (statusRegister & 0x0F)
                    {
                        numberOfTransducers++;
                    }
                }
            }                           // end of try
            finally
            {
                if (spinLockAcquired == GUI_YES)
                    QCOM_UnitAccessSpinLockArray[unitNumber]->Exit();
            }
        }                               // end of if (QCOM_UnitNumberValid(unitNumber))
    }                                   // end of for (DWORD unitNumber = 0; ...)
    return numberOfTransducers;
}                                       // end of QCOM_GetNumberOfTransducers()
//----------------------------------------------------------------------------
// QCOM_GetTransducerInfo
//
// Retrieves various information about the attached transducer, and returns
// the transducer type
//
// Returns the transducer type
//
// Called by:   QCOM_ScanForDevices
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_GetTransducerInfo(
    UnitInfo        ^unit)
{
    bool            transducerChipIDIsValid = GUI_NO;
    char            *commandString;
    char            *replyString;
    BYTE            memoryType = QD_MEMORY_TYPE_ABSENT;                         // 0
    BYTE            statusRegister = 0;
    BYTE            transducerType = QD_TRANSDUCER_TYPE_ABSENT;                 // 0
    DWORD           status;
    String          ^functionName = _T("QCOM_GetTransducerInfo");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        if (QCOM_UnitOpen(unit))
        {
            status = QD_GetModuleStatusRegister(
                unit->unitHandle,
                (LPBYTE) &statusRegister);
            if (status == QD_SUCCESS)
            {
                RecordVerboseEvent("    Status Register = 0x{0:X2}", statusRegister);
                //------------------------------------------------------------
                // The QD_SREG_TRANSDUCER_POWER_STATE bit being set indicates
                // that the module is applying power to the transducer port,
                // regardless whether a transducer is actually present
                //------------------------------------------------------------
                if (statusRegister & QD_SREG_TRANSDUCER_POWER_STATE)            // 0x20
                {
                    unit->flags |= QCOM_UNIT_TRANSDUCER_POWER_ENABLED;
                }
                else
                {
                    //--------------------------------------------------------
                    // The module is not applying power to the transducer
                    // port, so attempt to apply power to it, if power should
                    // be applied to it
                    //--------------------------------------------------------
                    if (QCOM_ModuleShouldApplyTransducerPower[unit->unitNumber])
                    {
                        status = QD_SetTransducerPowerState(
                            unit->unitHandle,
                            QD_ENABLE_TRANSDUCER_POWER);
                        if (status == QD_SUCCESS)
                        {
                            Thread::Sleep(100);
                            QCOM_GetTransducerPowerState(unit);
                        }
                        statusRegister = 0;
                        status = QD_GetModuleStatusRegister(
                            unit->unitHandle,
                            (LPBYTE) &statusRegister);
                        if (status != QCOM_SUCCESS)
                            statusRegister = 0;
                    }
                }                       // end of else of if (statusRegister & QD_SREG_TRANSDUCER_POWER_STATE)
                if (unit->flags & QCOM_UNIT_TRANSDUCER_POWER_ENABLED)
                {
                    if (statusRegister & (QD_SREG_TRANSDUCER_PRESENT | QD_SREG_TRANSDUCER_TYPE_MASK))
                    {
                        //----------------------------------------------------
                        // A transducer is present
                        //----------------------------------------------------
                        QCOM_GeneralInfo->numberOfTransducers++;
                        unit->flags |= QCOM_UNIT_TRANSDUCER_PRESENT;
                        if (statusRegister & QD_SREG_TRANSDUCER_PRESENT)
                        {
                            if (!(statusRegister & QD_SREG_TRANSDUCER_TYPE_MASK))
                            {
                                //--------------------------------------------
                                // A transducer seems to be present, but it
                                // does not report a valid type, so retry
                                // re-reading the status register after a
                                // delay
                                //--------------------------------------------
                                RecordErrorEvent(
                                    "    A transducer is present on {0} but does not report a valid type",
                                    unit->moduleSerialNumber);
                                Thread::Sleep(400);
                                statusRegister = 0;
                                status = QD_GetModuleStatusRegister(
                                    unit->unitHandle,
                                    (LPBYTE) &statusRegister);
                                if (status != QCOM_SUCCESS)
                                    statusRegister = 0;
                            }
                            if (statusRegister & QD_SREG_TRANSDUCER_TYPE_MASK)
                            {
                                //--------------------------------------------
                                // The case in which transducer presence is
                                // detected and its type is nonzero
                                //--------------------------------------------
                                transducerType = statusRegister & QD_SREG_TRANSDUCER_TYPE_MASK;
                                unit->transducerType = (DWORD) transducerType;
                                RecordVerboseEvent(
                                    "    QD_GetModuleStatusRegister successfully returned type {0:D}",
                                    (DWORD) unit->transducerType);
                                //--------------------------------------------
                                // Send an I²C command to retrieve the
                                // transducer chip ID (without the checksum,
                                // because at this point it's unknown whether
                                // the embedded ASIC/FPGA supports the
                                // checksum return)
                                //--------------------------------------------
                                commandString = (char *) malloc(QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE);
                                replyString = (char *) malloc(QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
                                if (commandString && replyString)
                                {
                                    ClearBuffer(replyString, QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
                                    strcpy_s(
                                        commandString,
                                        QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                        (QCOM_XDIsFrequency(unit) ? "S98R99FFFFFFFFP"  : "S9CR9DFFFFFFFFP"));
                                    status = QD_ExecuteI2CCommand(
                                        unit->unitHandle,
                                        (LPBYTE) commandString,
                                        (LPBYTE) replyString);
                                    if (status == QD_SUCCESS)
                                    {
                                        if (strlen(replyString) >= 8)
                                        {
                                            for (int index = 0; index < QD_TRANSDUCER_CHIP_ID_LENGTH; index++)
                                            {
                                                unit->transducerChipID[index] =
                                                    (AtoX(replyString[6 + index * 2]) << 4) | AtoX(replyString[7 + index * 2]);
                                            }
                                            RecordVerboseEvent(
                                                "    QD_ExecuteI2CCommand successfully retrieved transducer chip ID "
                                                "'{0:X2} {1:X2} {2:X2} {3:X2}'",
                                                unit->transducerChipID[0],
                                                unit->transducerChipID[1],
                                                unit->transducerChipID[2],
                                                unit->transducerChipID[3]);
                                            if ((unit->transducerChipID[0] != QD_QUARTZDYNE_ID) ||
                                                (unit->transducerChipID[1] < 0) ||
                                                (unit->transducerChipID[2] < 0) ||
                                                (unit->transducerChipID[3] < 0))
                                            {
                                                for (int index = 0; index < QD_TRANSDUCER_CHIP_ID_LENGTH; index++)
                                                {
                                                    unit->transducerChipID[index] = 0;
                                                }
                                                RecordErrorEvent(
                                                    "    QD_ExecuteI2CCommand returned an invalid transducer chip ID");
                                            }
                                            else
                                            {
                                                transducerChipIDIsValid = GUI_YES;
                                            }
                                        }   // end of if (strlen(replyString) >= 8)
                                        else
                                        {
                                            if ((_strnicmp(replyString, "S9", 2) == 0) &&
                                                (_strnicmp(replyString + 3, "NP", 2) == 0))
                                            {
                                                replyString[5] = QCOM_CHAR_NULL;
                                                RecordErrorEvent(
                                                    "    QD_ExecuteI2CCommand returned error string '{0}'",
                                                    gcnew String(replyString));
                                            }
                                            else
                                            {
                                                RecordErrorEvent(
                                                    "    QD_ExecuteI2CCommand returned invalid reply string '{0}'",
                                                    gcnew String(replyString));
                                            }
                                        }
                                    }       // end of if (status == QD_SUCCESS)
                                    else
                                    {
                                        RecordErrorEvent("    QD_ExecuteI2CCommand returned 0x{0:X8}", status);
                                    }
                                    if (transducerChipIDIsValid)
                                    {
                                        //------------------------------------
                                        // Determine the transducer memory
                                        // capacity
                                        //------------------------------------
                                        QD_GetMemoryType(
                                            unit->unitHandle,
                                            QD_DEVICE_TRANSDUCER,
                                            (LPBYTE) &memoryType);
                                        if (memoryType)
                                        {
/*
                                            for (DWORD memorySize = 0; status == QCOM_SUCCESS; memorySize += 1024)
                                            {
                                                ClearBuffer(replyString, QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
                                                strcpy_s(
                                                    commandString,
                                                    QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                                    "SACXXXXRADFFP");
                                                unit->transducerMemorySize = memorySize + 1024;
                                            }   // end of for (DWORD memorySize = 0; ..)
*/
                                            unit->transducerMemorySize = 8192;  // hard-code for now
                                            unit->numberOfTransducerMemoryPages =
                                                unit->transducerMemorySize / QCOM_COEFFICIENT_DATA_SIZE;
/*
                                            TODO: Consider using QD_ReadCoefficientDataFromSourcePage or
                                            QD_WriteCoefficientDataToTargetPage
*/
                                        }
                                        else
                                        {
                                            if ((transducerType > QD_TRANSDUCER_TYPE_FREQUENCY) &&
                                                (transducerType < QD_TRANSDUCER_TYPE_DIGITAL_NOMEM))
                                                RecordErrorEvent(
                                                    "    Transducer is type {0:D} but has no memory",
                                                    transducerType);
                                        }
                                    }   // end of if (transducerChipIDIsValid)
                                    //----------------------------------------
                                    // Change the reference frequency from 7.2
                                    // MHz to 1 kHz, if the chipset ID reports
                                    // that the chipset can support the change
                                    // (FPGA version 3.03 or later, according
                                    // to the Digital Transducer Manual,
                                    // section 3.3)
                                    //----------------------------------------
                                    if ((unit->transducerChipID[2] > 3) ||
                                        ((unit->transducerChipID[2] == 3) && (unit->transducerChipID[3] > 3)))
                                    {
                                        ClearBuffer(replyString, QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
                                        strcpy_s(
                                            commandString,
                                            QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                            (QCOM_XDIsFrequency(unit) ? "S983FC0P"  : "S9C3FC0P"));
                                        status = QD_ExecuteI2CCommand(
                                            unit->unitHandle,
                                            (LPBYTE) commandString,
                                            (LPBYTE) replyString);
                                        if (status == QD_SUCCESS)
                                        {
                                            if (strncmp(replyString + 3, "3FC0P", 5) == 0)
                                            {
                                                RecordVerboseEvent(
                                                    "    QD_ExecuteI2CCommand successfully changed the reference frequency to 1 kHz");
                                            }   // end of if (strlen(replyString) >= 8)
                                            else
                                            {
                                                if ((_strnicmp(replyString, "S9", 2) == 0) &&
                                                    (_strnicmp(replyString + 3, "NP", 2) == 0))
                                                {
                                                    replyString[5] = QCOM_CHAR_NULL;
                                                    RecordErrorEvent(
                                                        "    QD_ExecuteI2CCommand returned error string '{0}'",
                                                        gcnew String(replyString));
                                                }
                                                else
                                                {
                                                    RecordErrorEvent(
                                                        "    QD_ExecuteI2CCommand returned invalid reply string '{0}'",
                                                        gcnew String(replyString));
                                                }
                                            }
                                        }
                                        else
                                        {
                                            RecordErrorEvent("    QD_ExecuteI2CCommand returned 0x{0:X8}", status);
                                        }
                                    }   // end of if ((unit->transducerChipID[2] > 3) || ...)
                                    free((void *) replyString);
                                    free((void *) commandString);
                                }       // end of if (commandString && replyString)
                            }           // end of if (statusRegister & QD_SREG_TRANSDUCER_TYPE_MASK)
                            else
                            {
                                //--------------------------------------------
                                // Attempt to communicate with the attached
                                // transducer by assuming it is a frequency
                                // type
                                //--------------------------------------------
                                commandString = (char *) malloc(QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE);
                                replyString = (char *) malloc(QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
                                if (commandString && replyString)
                                {
                                    ClearBuffer(replyString, QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
                                    strcpy_s(
                                        commandString,
                                        QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                        "S98R99FFFFFFFFP");
                                    status = QD_ExecuteI2CCommand(
                                        unit->unitHandle,
                                        (LPBYTE) commandString,
                                        (LPBYTE) replyString);
                                    if (status == QD_SUCCESS)
                                    {
                                        if (strlen(replyString) >= 8)
                                        {
                                            for (int index = 0; index < QD_TRANSDUCER_CHIP_ID_LENGTH; index++)
                                            {
                                                unit->transducerChipID[index] =
                                                    (AtoX(replyString[6 + index * 2]) << 4) | AtoX(replyString[7 + index * 2]);
                                            }
                                            RecordVerboseEvent(
                                                "    QD_ExecuteI2CCommand successfully retrieved transducer chip ID "
                                                "'{0:X2} {1:X2} {2:X2} {3:X2}'",
                                                unit->transducerChipID[0],
                                                unit->transducerChipID[1],
                                                unit->transducerChipID[2],
                                                unit->transducerChipID[3]);
                                            if ((unit->transducerChipID[0] != QD_QUARTZDYNE_ID) ||
                                                (unit->transducerChipID[1] < 0) ||
                                                (unit->transducerChipID[2] < 0) ||
                                                (unit->transducerChipID[3] < 0))
                                            {
                                                transducerType = QD_TRANSDUCER_TYPE_ABSENT;
                                                for (int index = 0; index < QD_TRANSDUCER_CHIP_ID_LENGTH; index++)
                                                {
                                                    unit->transducerChipID[index] = 0;
                                                }
                                                RecordErrorEvent(
                                                    "    QD_ExecuteI2CCommand returned an invalid transducer chip ID");
                                            }
                                            else
                                            {
                                                transducerChipIDIsValid = GUI_YES;
//Modal("S98R99 succeeded");
                                                transducerType = QD_TRANSDUCER_TYPE_FREQUENCY;
                                            }
                                        }   // end of if (strlen(replyString) >= 8)
                                        else
                                        {
                                            transducerType = QD_TRANSDUCER_TYPE_ABSENT;
                                            if ((_strnicmp(replyString, "S9", 2) == 0) &&
                                                (_strnicmp(replyString + 3, "NP", 2) == 0))
                                            {
                                                replyString[5] = QCOM_CHAR_NULL;
                                                RecordErrorEvent(
                                                    "    QD_ExecuteI2CCommand returned error string '{0}'",
                                                    gcnew String(replyString));
                                            }
                                            else
                                            {
                                                RecordErrorEvent(
                                                    "    QD_ExecuteI2CCommand returned invalid reply string '{0}'",
                                                    gcnew String(replyString));
                                            }
                                        }
                                    }
                                    else
                                    {
                                        RecordErrorEvent("    QD_ExecuteI2CCommand S98R99 returned 0x{0:X8}", status);
                                    }
//if (!transducerType) Modal("S98R99 failed");
                                    if (!transducerType)
                                    {
                                        //------------------------------------
                                        // Attempt to communicate with the
                                        // attached transducer by assuming it
                                        // is a digital type
                                        //------------------------------------
                                        ClearBuffer(replyString, QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
                                        strcpy_s(
                                            commandString,
                                            QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                            "S9CR9DFFFFFFFFP");
                                        status = QD_ExecuteI2CCommand(
                                            unit->unitHandle,
                                            (LPBYTE) commandString,
                                            (LPBYTE) replyString);
                                        if (status == QD_SUCCESS)
                                        {
                                            if (strlen(replyString) >= 8)
                                            {
                                                for (int index = 0; index < QD_TRANSDUCER_CHIP_ID_LENGTH; index++)
                                                {
                                                    unit->transducerChipID[index] =
                                                        (AtoX(replyString[6 + index * 2]) << 4) | AtoX(replyString[7 + index * 2]);
                                                }
                                                RecordVerboseEvent(
                                                    "    QD_ExecuteI2CCommand successfully retrieved transducer chip ID "
                                                    "'{0:X2} {1:X2} {2:X2} {3:X2}'",
                                                    unit->transducerChipID[0],
                                                    unit->transducerChipID[1],
                                                    unit->transducerChipID[2],
                                                    unit->transducerChipID[3]);
                                                if ((unit->transducerChipID[0] != QD_QUARTZDYNE_ID) ||
                                                    (unit->transducerChipID[1] < 0) ||
                                                    (unit->transducerChipID[2] < 0) ||
                                                    (unit->transducerChipID[3] < 0))
                                                {
                                                    transducerType = QD_TRANSDUCER_TYPE_ABSENT;
                                                    for (int index = 0; index < QD_TRANSDUCER_CHIP_ID_LENGTH; index++)
                                                    {
                                                        unit->transducerChipID[index] = 0;
                                                    }
                                                    RecordErrorEvent(
                                                        "    QD_ExecuteI2CCommand returned an invalid transducer chip ID");
                                                }
                                                else
                                                {
                                                    transducerChipIDIsValid = GUI_YES;
//Modal("S9CR9D succeeded");
                                                    transducerType = 2; // set to Pre-FireFly Digital
                                                }
                                            }   // end of if (strlen(replyString) >= 8)
                                            else
                                            {
                                                transducerType = QD_TRANSDUCER_TYPE_ABSENT;
                                                if ((_strnicmp(replyString, "S9", 2) == 0) &&
                                                    (_strnicmp(replyString + 3, "NP", 2) == 0))
                                                {
                                                    replyString[5] = QCOM_CHAR_NULL;
                                                    RecordErrorEvent(
                                                        "    QD_ExecuteI2CCommand returned error string '{0}'",
                                                        gcnew String(replyString));
                                                }
                                                else
                                                {
                                                    RecordErrorEvent(
                                                        "    QD_ExecuteI2CCommand returned invalid reply string '{0}'",
                                                        gcnew String(replyString));
                                                }
                                            }
                                        }
                                        else
                                        {
                                            RecordErrorEvent("    QD_ExecuteI2CCommand S9CR9D returned 0x{0:X8}", status);
                                        }
                                    }   // end of if (!transducerType)
//if (!transducerType) Modal("S9CR9D failed");
                                    free((void *) replyString);
                                    free((void *) commandString);
                                    if (!transducerType)
                                    {
                                        //------------------------------------
                                        // The type is still not valid, so bail
                                        //------------------------------------
                                        QCOM_PromptOKModal(
                                            "Undetermined Transducer Type",
                                            "QCOM module {0} reports that a transducer is\n"
                                            "attached, but could not determine its type",
                                            unit->moduleSerialNumber);
                                    }
                                }       // end of if (commandString && replyString)
                            }           // end of else of if (statusRegister & QD_SREG_TRANSDUCER_TYPE_MASK)
                            if (transducerType && !transducerChipIDIsValid)
                            {
                                QCOM_PromptOKModal(
                                    "Invalid Transducer Chip ID",
                                    "QCOM module {0} reported an invalid chip ID for its\n"
                                    "attached transducer, indicating possibly poor communication\n"
                                    "between the two.\n\n"
                                    "This is often the result of excessive crosstalk between the\n"
                                    "7.2 MHz reference and other wires. Exit the software,\n"
                                    "disconnect the QCOM module, shorten all the wires between\n"
                                    "the transducer and the connector, then reconnect the module.",
                                    unit->moduleSerialNumber);
                            }
                        }               // end of if (statusRegister & QD_SREG_TRANSDUCER_PRESENT)
                        else
                        {
                            RecordErrorEvent(
                                "    QD_GetModuleStatusRegister returned register value 0x{0:X2}\n"
                                "    No transducer detected attached to module {1},\n"
                                "    but reports a device with a nonzero type",
                                statusRegister,
                                unit->moduleSerialNumber);
                        }               // end of else of if (statusRegister & QD_SREG_TRANSDUCER_PRESENT)
                    }                   // end of if (statusRegister & (QD_SREG_TRANSDUCER_PRESENT | QD_SREG_TRANSDUCER_TYPE_MASK))
                    else
                    {
                        ModuleTransducerPair ^unitPair = QCOM_ModuleTransducerPairArray[unitNumber];
                        if (unitPair)
                        {
                            unitPair->newTransducerSerialNumber = String::Empty;
                        }
                        RecordVerboseEvent("    No transducer detected attached to module {0}",
                            unit->moduleSerialNumber);
                    }
                }                       // end of if (unit->flags & QCOM_UNIT_TRANSDUCER_POWER_ENABLED)
                else
                {
                    RecordErrorEvent("    Module {0} is unable to apply power to the transducer",
                        unit->moduleSerialNumber);
                }
            }                           // end of if (status == QD_SUCCESS)
            else
            {
                RecordErrorEvent("    QD_GetModuleStatusRegister returned 0x{0:X8}", status);
            }
        }                               // end of if (QCOM_UnitOpen(unit))
        else
        {
            RecordErrorEvent("    Unit {0:D} should be open but is not", unitNumber);
        }
        QCOM_OriginalTransducerType[unitNumber] = transducerType;
        RecordBasicEvent("{0} concluded, returning type {1:D}",
            functionName, (DWORD) transducerType);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return (DWORD) transducerType;
}                                       // end of QCOM_GetTransducerInfo()
//----------------------------------------------------------------------------
// QCOM_GetTransducerPowerState
//
// Retrieves the transducer power state from the specified unit and sets the
// appropriate flag
//
// Returns: 0           Success
//          nonzero     Failure
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_GetTransducerPowerState(
    UnitInfo        ^unit)
{
    BYTE            statusRegister;
    DWORD           status = QCOM_FAILURE;
    String          ^functionName = _T("QCOM_GetTransducerPowerState");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        status = QD_GetModuleStatusRegister(
            unit->unitHandle,
            (LPBYTE) &statusRegister);
        if (status == QD_SUCCESS)
        {
            if (statusRegister & QD_SREG_TRANSDUCER_POWER_STATE)                // 0x20
                unit->flags |= QCOM_UNIT_TRANSDUCER_POWER_ENABLED;
            else
                unit->flags &= ~QCOM_UNIT_TRANSDUCER_POWER_ENABLED;
            RecordVerboseEvent("    The transducer power is {0}",
                ((unit->flags & QCOM_UNIT_TRANSDUCER_POWER_ENABLED) ? "enabled" : "disabled"));
        }
        else
        {
            RecordErrorEvent("    QD_GetModuleStatusRegister returned 0x{0:X8}", status);
        }
        RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    }
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return status;
}                                       // end of QCOM_GetTransducerPowerState()
//----------------------------------------------------------------------------
// QCOM_OpenUnit
//
// Opens the specified unit for I/O
//
// Returns: 0           Success
//          nonzero     Failure
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_OpenUnit(
    UnitInfo        ^unit)
{
    int             attempts = QCOM_MAXIMUM_OPEN_ATTEMPTS;                      // 100
    int             closeChecks = 20;
    DWORD           status = QCOM_FAILURE;
//    UnitDef         *module;
    HANDLE          unitHandle;
    String          ^functionName = _T("QCOM_OpenUnit");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordVerboseEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        Thread::Sleep(100);
        ////--------------------------------------------------------------------
        //// Ensure the physical unit number mappings match that of the
        //// corresponding serial numbers
        ////--------------------------------------------------------------------
        //for (DWORD moduleNumber = 0; moduleNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; moduleNumber++)
        //{
        //    if (QCOM_UnitNumberValid(moduleNumber))
        //    {
        //        module = QCOM_UnitInfoArray[moduleNumber];
        //        if (module->flags & QCOM_UNIT_MODULE_SN_VALID)
        //        {
        //            if (_memicmp(module->moduleSerialNumber, unit->moduleSerialNumber, strlen(unit->moduleSerialNumber)) == 0)
        //            {
        //                //----------------------------------------------------
        //                // A serial number match is found, so test the physical
        //                // unit numbers for a match
        //                //----------------------------------------------------
        //                if (module->physicalUnitNumber != unit->physicalUnitNumber)
        //                {
        //                    //------------------------------------------------
        //                    // They don't match, so re-scan the hardware to
        //                    // force a match
        //                    //------------------------------------------------
        //                    QCOM_ReScanModules();
        //                }
        //                break;
        //            }
        //        }
        //    }
        //}
        ////--------------------------------------------------------------------
        //// It is now assumed that the units with matching serial numbers have
        //// correspondingly matching unit numbers
        ////--------------------------------------------------------------------
        //for (DWORD moduleNumber = 0; moduleNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; moduleNumber++)
        //{
        //    if (QCOM_UnitNumberValid(moduleNumber))
        //    {
        //        module = QCOM_UnitInfoArray[moduleNumber];
        //        if (module->flags & QCOM_UNIT_MODULE_SN_VALID)
        //        {
        //            if (_memicmp(module->moduleSerialNumber, unit->moduleSerialNumber, strlen(unit->moduleSerialNumber)) == 0)
        //            {
                    if (HandleIsValid(unit->unitHandle))
                    {
                        while (closeChecks--)
                        {
                            Thread::Sleep(20);
                            if (unit->unitHandle == INVALID_HANDLE_VALUE)
                                closeChecks = 0;
                        }
                    }
                    if (unit->unitHandle == INVALID_HANDLE_VALUE)
                    {
                        while (attempts--)
                        {
                            status = QD_Open(unit->physicalUnitNumber, &unitHandle);
                            if ((status == QCOM_SUCCESS) && HandleIsValid(unitHandle))
                            {
                                unit->unitHandle = unitHandle;
                                unit->flags |= QCOM_UNIT_OPEN;
                                attempts = 0;
                                RecordVerboseEvent("    Unit {0:D} successfully opened using handle 0x{1:X8}",
                                    unit->unitNumber, (DWORD) unitHandle);
                            }
                            else
                            {
                                if (attempts)
                                {
                                    status = QCOM_SUCCESS;
                                    //----------------------------------------
                                    // At this point I wish there was a way to
                                    // reset the module without using a valid
                                    // unit handle
                                    //----------------------------------------
                                    Thread::Sleep(100);
                                }
                                else
                                {
                                    if (status == QCOM_SUCCESS)
                                    {
                                        if (unitHandle == INVALID_HANDLE_VALUE)
                                        {
                                            RecordErrorEvent(
                                                "    QD_Open resulted in an invalid handle for unit {0:D}",
                                                unit->unitNumber);
                                            status = QD_ERROR_INVALID_HANDLE;           // 0x00000001
                                        }
                                        else
                                        {
                                            RecordErrorEvent("    It shouldn't be possible to reach this point");
                                            status = QD_ERROR_UNREACHABLE_CONDITION;    // 0x00000029
                                        }
                                    }
                                    else
                                    {
                                        //------------------------------------
                                        // Don't modal this error, since it is
                                        // already being prompted elsewhere
                                        //------------------------------------
                                        RecordErrorEvent(
                                            "    QD_Open resulted in status 0x{0:X8} for unit {1:D}",
                                            status, unit->unitNumber);
                                    }
                                }
                            }
                        }               // end of while (attempts--)
                    }                   // end of if (unit->unitHandle == INVALID_HANDLE_VALUE)
                    else
                    {
                        RecordErrorEvent(
                            "    QD_Open: Unit {0:D} was never closed",
                            unit->unitNumber);
                    }
        //                break;
        //            }
        //        }
        //    }
        //}
        RecordVerboseEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return status;
}                                       // end of QCOM_OpenUnit()
//----------------------------------------------------------------------------
// QCOM_QueryEnableTransducerPower
//
// If power to the transducer has been disabled, queries the user to have it
//          enabled
//
// Returns: GUI_YES     Power to the transducer is already enabled, or if it is
//                      not, the user has enabled it
//          GUI_NO      Power to the transducer has been disabled, and the user
//                      does not want it enabled
//
// Called by:   QCOM_StartStopSamplingUnit
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_QueryEnableTransducerPower(
    UnitInfo        ^unit)
{
    bool            currentlyPowered = GUI_YES;
    bool            proceedWithPower = GUI_YES;
    DWORD           status;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_QueryEnableTransducerPower");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        if (unit->flags & QCOM_UNIT_TRANSDUCER_POWER_ENABLED)
        {
            RecordBasicEvent("    Power to transducer {0} is already enabled",
                unit->transducerSerialNumber);
        }
        else
        {
            currentlyPowered = GUI_NO;
            proceedWithPower = QCOM_PromptModal(
                "Transducer Power Disabled",
                "Power to transducer {0} has been disabled.  Enable power to it?",
                unit->transducerSerialNumber);
            if (proceedWithPower)
            {
                status = QD_SetTransducerPowerState(
                    unit->unitHandle,
                    QD_ENABLE_TRANSDUCER_POWER);
                if (status == QD_SUCCESS)
                {
                    QCOM_GetTransducerPowerState(unit);
                    if (unit->flags & QCOM_UNIT_TRANSDUCER_POWER_ENABLED)
                    {
                        expertTransducerPowerButtonArray[unitNumber]->Text = _T("Disable Transducer Power");
                        expertTransducerPowerButtonArray[unitNumber]->BackgroundImage = sandBackground;
                        currentlyPowered = GUI_YES;
                        RecordVerboseEvent("    Transducer power for {0} is now enabled",
                            unit->transducerSerialNumber);
                    }
                    else
                    {
                        currentlyPowered = GUI_NO;
                    }
                }
                else
                {
                    RecordErrorEvent(
                        "    QD_SetTransducerPowerState returned 0x{0:X8}",
                        status);
                }
            }                           // end of if (proceedWithPower)
        }
        RecordBasicEvent("{0} concluded, returning {1}",
            functionName, (currentlyPowered ? "Enabled" : "Disabled"));
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return currentlyPowered;
}                                       // end of QCOM_QueryEnableTransducerPower()
//----------------------------------------------------------------------------
// QCOM_ResetAllModules
//
// Resets the states of all the attached QCOM units
//
// Called by:   QCOM_ToolStripResetAllModulesDropDownClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ResetAllModules(void)
{
    bool            currentlySampling;
    bool            proceedWithReset;
    UnitInfo        ^unit;
    //------------------------------------------------------------------------
    currentlySampling =
        QCOM_QueryStopSampling("QCOM cannot be reset during transducer sampling.");
    if (!currentlySampling)
    {
        proceedWithReset = QCOM_PromptModal(
            "Reset Modules",
            "Reset all the QCOM modules ?");
//        Thread::Sleep(100);
        if (proceedWithReset)
        {
            Cursor = Cursors::WaitCursor;
            QCOM_HomeUpdateStatusLine("Resetting the units");
            for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
            {
                if (QCOM_UnitNumberValid(unitNumber))
                {
                    unit = QCOM_UnitInfoArray[unitNumber];
//                    QCOM_ResetSystem();
                }
            }
            for (int percent = 0; percent < 100; percent++)
            {
                QCOM_HomeUpdateProgressBar(percent, 100);
                Thread::Sleep(10);
            }
            QCOM_HomeUpdateProgressBar(0, 0);
            QCOM_HomeUpdateStatusLine("All units reset");
            Cursor = Cursors::Default;
        }                               // end of if (proceedWithReset)
    }                                   // end of if (!currentlySampling)
}                                       // end of QCOM_ResetAllModules()
//----------------------------------------------------------------------------
// QCOM_ResetAllTransducers
//
// Resets the state of the transducer
//
// Called by:   QCOM_ToolStripResetAllTransducersDropDownClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ResetAllTransducers(void)
{
    bool            currentlySampling;
    bool            proceedWithReset = GUI_YES;
    UnitInfo        ^unit;
    //------------------------------------------------------------------------
    currentlySampling =
        QCOM_QueryStopSampling("The transducer cannot be reset while being sampled.");
    if (!currentlySampling)
    {
        proceedWithReset = QCOM_PromptModal(
            "Reset Transducer",
            "Reset all transducers ?");
        if (proceedWithReset)
        {
            Cursor = Cursors::WaitCursor;
            QCOM_HomeUpdateStatusLine("Resetting all the transducers");
            for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
            {
                if (QCOM_UnitNumberValid(unitNumber))
                {
                    unit = QCOM_UnitInfoArray[unitNumber];
                    QCOM_ResetTransducer(unit);
                }
            }
            for (int percent = 0; percent < 100; percent++)
            {
                QCOM_HomeUpdateProgressBar(percent, 100);
                Thread::Sleep(10);
            }
            QCOM_HomeUpdateProgressBar(0, 0);
            QCOM_HomeUpdateStatusLine("All transducers reset");
            Cursor = Cursors::Default;
        }                               // end of if (proceedWithReset)
    }                                   // end of if (!currentlySampling)
}                                       // end of QCOM_ResetAllTransducers()
//----------------------------------------------------------------------------
// QCOM_ResetModule
//
// Resets the onboard frequency counters of the FPGAs of the specified module
//
// Called by:   QCOM_ResetUnit
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ResetModule(
    UnitInfo        ^unit)
{
    DWORD           commandLength = 1;
    DWORD           status;
    String          ^functionName = _T("QCOM_ResetModule");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        status = QD_ResetUnit(unit->unitHandle);
        if (status == QD_SUCCESS)
        {
            QCOM_RecordAndModalEventByFlags(
                QCOM_EventLogVerboseEnabled,
                QCOM_DetailedMessagesEnabled,
                functionName,
                "QCOM module {0} was reset successfully",
                unit->moduleSerialNumber);
            QD_FlushBuffers(unit->unitHandle, 1, 1);
            Thread::Sleep(1000);
//            QCOM_WaitMS(1000);          // now, just wait a second
            QCOM_CloseUnit(unit);
            status = QCOM_OpenUnit(unit);
            if (status == QCOM_SUCCESS)
            {
                if (HandleIsValid(unit->unitHandle))
                {
                    unit->flags |= QCOM_UNIT_OPEN;
/*  TODO: Not sure how far to take this reset thing
                    if (unit->flags & QCOM_UNIT_ALLOCATED)
                    {
                        free((void *) unit->coefficientData);
                    }
*/
                }
                else
                {
                    status = QD_ERROR_INVALID_HANDLE;                           // 0x0001
                }
            }
            else
            {
                unit->unitHandle = INVALID_HANDLE_VALUE;
            }
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0}({1:D}) : Failed to reset",
                functionName, unit->unitNumber);
        }
        if (status == QCOM_SUCCESS)
            RecordVerboseEvent("{0}({1:D}) : Completed successfully",
                functionName, unit->unitNumber);
        else
            QCOM_RecordAndModalErrorEvent(
            "{0}({1:D}) :\nCompleted with status 0x{2:X8}",
                functionName, unit->unitNumber, status);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_ResetModule()
//----------------------------------------------------------------------------
// QCOM_ResetSystem
//
// Resets the firmware and the onboard FPGA frequency counters of all the QCOM
// device units
//
// Called by:   QCOM_ResetAll
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ResetSystem(void)
{
    DWORD           commandLength = 1;
    DWORD           status = QCOM_SUCCESS;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_ResetSystem");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            status |=
                QD_ResetUnit(unit->unitHandle);
            status |=
                QD_SetFirmwareMode(unit->unitHandle, QD_SET_APPLICATION_MODE);
            if (status == QD_SUCCESS)
            {
                QCOM_RecordAndModalEventByFlags(
                    QCOM_EventLogVerboseEnabled,
                    QCOM_DetailedMessagesEnabled,
                    functionName,
                    "QCOM unit {0:D} was reset successfully",
                    unitNumber);
            }
            else
            {
                QCOM_RecordAndModalErrorEvent(
                    "QCOM unit {0:D} failed to reset", unitNumber);
                status = QCOM_SUCCESS;
            }
        }
    }
    //------------------------------------------------------------------------
    // Reset the timeouts to initial values
    //------------------------------------------------------------------------
    QD_SetTimeouts(QCOM_TIMEOUT_500MS, QCOM_TIMEOUT_500MS);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ResetSystem()
//----------------------------------------------------------------------------
// QCOM_ResetTransducer
//
// "Resets" the transducer attached to the specified unit by disabling the
// transducer power provided by the module
//
// Called by:   QCOM_ResetAllTransducers
//              QCOM_UtilUnitResetTransducerButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ResetTransducer(
    UnitInfo        ^unit)
{
    BYTE            statusRegister;
    DWORD           status;
    String          ^functionName = _T("QCOM_ResetTransducer");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        status = QD_SetTransducerPowerState(
            unit->unitHandle,
            QD_DISABLE_TRANSDUCER_POWER);
        if (status == QD_SUCCESS)
        {
            unit->flags &= ~QCOM_UNIT_TRANSDUCER_POWER_ENABLED;
            Thread::Sleep(500);
        }
        else
        {
            GUI_DisplayErrorWithStatus(
                functionName,
                "QD_SetTransducerPowerState(0)",
                unit,
                status);
        }
        status = QD_SetTransducerPowerState(
            unit->unitHandle,
            QD_ENABLE_TRANSDUCER_POWER);
        if (status == QD_SUCCESS)
        {
            status = QD_GetModuleStatusRegister(
                unit->unitHandle,
                (LPBYTE) &statusRegister);
            if (status == QD_SUCCESS)
            {
                if (statusRegister & QD_SREG_TRANSDUCER_POWER_STATE)            // 0x20
                    unit->flags |= QCOM_UNIT_TRANSDUCER_POWER_ENABLED;
                else
                    unit->flags &= ~QCOM_UNIT_TRANSDUCER_POWER_ENABLED;
                QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
            }
            else
            {
                GUI_DisplayErrorWithStatus(
                    functionName,
                    "QD_GetModuleStatusRegister",
                    unit,
                    status);
            }
        }
        else
        {
            GUI_DisplayErrorWithStatus(
                functionName,
                "QD_SetTransducerPowerState(1)",
                unit,
                status);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_ResetTransducer()
//----------------------------------------------------------------------------
// QCOM_ResetUnit
//
// Resets the state of the specified unit
//
// Called by:   QCOM_UtilResetModuleButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ResetUnit(
    UnitInfo        ^unit)
{
    bool            currentlySampling;
    bool            proceedWithReset = GUI_YES;
    String          ^functionName = _T("QCOM_ResetUnit");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        currentlySampling =
            QCOM_QueryStopSampling("QCOM cannot be reset during transducer sampling.");
        if (!currentlySampling)
        {
            proceedWithReset = QCOM_PromptModal(
                "Reset Module",
                String::Format(
                    "Reset QCOM module {0} ?",
                    unit->moduleSerialNumber));
            if (proceedWithReset)
            {
                Cursor = Cursors::WaitCursor;
                QCOM_HomeUpdateStatusLine(
                    String::Format(
                        "Resetting module {0}",
                        unit->moduleSerialNumber));
//                QCOM_ResetModule(unit);
                for (int percent = 0; percent < 100; percent++)
                {
                    QCOM_HomeUpdateProgressBar(percent, 100);
                    Thread::Sleep(10);
                }
                QCOM_HomeUpdateProgressBar(0, 0);
                QCOM_HomeUpdateStatusLine(
                    String::Format(
                        "Module {0} reset",
                        unit->moduleSerialNumber));
                Cursor = Cursors::Default;
            }                           // end of if (proceedWithReset)
        }                               // end of if (!currentlySampling)
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_ResetUnit()
//----------------------------------------------------------------------------
// QCOM_ScanForDevices
//
// Scans the USB interface for all possible QCOM devices
//
// Called by:   QCOM_InitializeQCOM
//              QCOM_ReScanForDevices
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ScanForDevices(void)
{
    DWORD           numberOfUnits;
    DWORD           status;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_ScanForDevices");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Retrieve the number of Silicon Labs modules known to the driver
    //------------------------------------------------------------------------
    numberOfUnits = QD_GetNumberOfModules();
    if (numberOfUnits)
    {
        QCOM_GeneralInfo->numberOfUnits = numberOfUnits;
        RecordBasicEvent("    {0:D} QCOM or CalMux module{1} detected",
            numberOfUnits,
            ((numberOfUnits == 1) ? "" : "s"));
        //--------------------------------------------------------------------
        // Search for all possible QCOM modules, in spite of the actual number
        // of Silicon Labs modules reported
        //--------------------------------------------------------------------
        for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            if (unit && (unit->unitNumber == unitNumber))
            {
                unit->physicalUnitNumber = unitNumber;
                //------------------------------------------------------------
                // Retrieve the serial number and other information about the
                // module of this unit
                //------------------------------------------------------------
                QCOM_GetModuleInfo(unit);
                if (QCOM_UnitValid(unit))
                {
                    //--------------------------------------------------------
                    // This is a QCOM module, so set appropriate flags
                    //--------------------------------------------------------
                    QCOM_SetUnitFlagsToInitialValues(unit);
                    //--------------------------------------------------------
                    // Open a handle to the unit
                    //--------------------------------------------------------
                    QCOM_CloseUnit(unit);
                    status = QCOM_OpenUnit(unit);
                    if (status == QCOM_SUCCESS)
                    {
                        unit->flags |= QCOM_UNIT_OPEN;
                        //----------------------------------------------------
                        // Check for Boot Loader Mode
                        //----------------------------------------------------
                        if (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE)
                        {
                            QCOM_SwitchFromBootLoaderMode(unit);
                        }
                        //----------------------------------------------------
                        // Verify that this module is listed in the Registry
                        //----------------------------------------------------
                        QCOM_CheckModuleRegistryEntry(unit);
                        if (!(unit->flags & QCOM_UNIT_BOOT_LOADER_MODE))
                        {
                            //------------------------------------------------
                            // Retrieve the QCOM unit firmware version and ID
                            //------------------------------------------------
                            QCOM_RetrieveFirmwareInformation(unit);
                            //------------------------------------------------
                            // Set the initial I2C data rate to 100 kHz, the
                            // I2C maximum, whether a transducer is present or
                            // not
                            //------------------------------------------------
                            QCOM_SetTransducerMaximumDataRate(unit);
                            //------------------------------------------------
                            // Determines whether a transducer is present at
                            // the current unit, then retrieves info about the
                            // attached transducer, if one is
                            //------------------------------------------------
                            QCOM_GetTransducerInfo(unit);
                            //------------------------------------------------
                            // Read coefficient data into memory, from the
                            // attached transducer if it is a digital version
                            // that contains valid coefficient data, or from
                            // the module otherwise
                            //------------------------------------------------
                            status = QCOM_RetrieveCoefficientData(unit);
                            //------------------------------------------------
                            // Construct a display string that describes this
                            // unit, including module serial number, transducer
                            // serial number, and transducer type and chip ID
                            //------------------------------------------------
                            QCOM_ConstructUnitDescriptionString(unit);
                            //------------------------------------------------
                            // Update the map of units ready to produce data
                            //------------------------------------------------
                            if (QCOM_UnitReady(unit))
                                QCOM_GeneralInfo->readyUnitBitMap |= (0x00000001 << unitNumber);
                        }               // end of if (!(unit->flags & QCOM_UNIT_BOOT_LOADER_MODE))
                    }                   // end of if (status == QCOM_SUCCESS)
                    else
                    {
                        String ^recommendation;
                        switch (status & QD_ERROR_CODE_MASK)                    // 0x0000FFFF
                        {
                            case QD_ERROR_NO_DEVICE_FOUND :                     // 0x000000FF
                                recommendation =
                                    "Try exiting the software, unplugging the\n"
                                    "USB cable from the QCOM module for a\n"
                                    "few seconds, re-attaching the USB cable,\n"
                                    "then restarting the software";
                                break;
                            default :
                                recommendation = "Say your prayers";
                                break;
                        }               // end of switch (status & QD_ERROR_CODE_MASK)
                        GUI_DisplayMandatoryError(
                            String::Format("{0}({1:D})",
                                functionName, unit->unitNumber),
                                "QCOM_OpenUnit returned 0x{0:X8}\n\n{1}",
                                status, recommendation);
                        delete recommendation;
                        unit->unitHandle = INVALID_HANDLE_VALUE;
                    }                   // end of else of if (status == QCOM_SUCCESS)
                }                       // end of if (QCOM_UnitValid(unit))
                else
                {
                    if (unit->flags & QCOM_UNIT_CMUX_BOX)
                    {
                        QCOM_CheckModuleRegistryEntry(unit);
//                        QCOM_RetrieveFirmwareInformation(unit);
                    }                           // end of if (unit->flags & QCOM_UNIT_CMUX_BOX)
                }
            }
        }                               // end of for (unitNumber = 0; ...)
    }                                   // end of if (numberOfUnits)
    else
    {
        RecordErrorEvent("    {0} : No QCOM or CalMux modules found", functionName);
    }
    QCOM_SetCurrentNumberOfUnits();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ScanForDevices()
//----------------------------------------------------------------------------
// QCOM_SetCurrentNumberOfUnits
//
// Sets the global QCOM_CurrentNumberOfUnits variable to the appropriate value,
// depending on whether the valid unit bit map shows consecutive devices
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SetCurrentNumberOfUnits(void)
{
    bool            consecutive = GUI_YES;  // innocent until proven guilty
    bool            oneRun = GUI_NO;
    bool            zeroRun = GUI_NO;
    DWORD           numberOfValidUnits = 0;
    DWORD           unitBitMap = QCOM_GeneralInfo->validUnitBitMap;
    String          ^functionName = _T("QCOM_SetCurrentNumberOfUnits");
    //------------------------------------------------------------------------
    QCOM_CurrentNumberOfUnits = 0;
    if (unitBitMap)
    {
        for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
        {
            if (zeroRun)
            {
                if (unitBitMap & (0x00000001 << unitNumber))
                {
                    numberOfValidUnits++;
                    consecutive = GUI_NO;
                    break;
                }
            }
            else
            {
                if (unitBitMap & (0x00000001 << unitNumber))
                {
                    numberOfValidUnits++;
                    oneRun = GUI_YES;
                }
                else
                {
                    zeroRun = GUI_YES;
                }
            }
        }
        QCOM_CurrentNumberOfUnits =
            (consecutive ? numberOfValidUnits : QCOM_MAXIMUM_NUMBER_OF_UNITS);
    }
    RecordBasicEvent("{0} : Current number of units set to {1:D}",
        functionName, QCOM_CurrentNumberOfUnits);
}                                       // end of QCOM_SetCurrentNumberOfUnits()
//----------------------------------------------------------------------------
// QCOM_SetTransducerMaximumDataRate
//
// Checks the I²C Data rate set by the module to communicate with the
// transducer, then sets it to the maximum if it isn't already set to that
// value
//
// Called by:   QCOM_ScanForDevices
//----------------------------------------------------------------------------
    double QCOM_GUIClass::
QCOM_SetTransducerMaximumDataRate(
    UnitInfo        ^unit)
{
    double          currentDataRate = 0.0;
    DWORD           status;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_SetTransducerMaximumDataRate");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        status = QD_GetI2CDataRate(
            unit->unitHandle,
            (double *) &currentDataRate);
        if (status == QD_SUCCESS)
        {
            RecordBasicEvent(
                "    QD_GetI2CDataRate successfully returned {0:F}",
                currentDataRate);
            if (currentDataRate < QD_MAXIMUM_I2C_DATA_RATE)
            {
                status = QD_SetI2CDataRate(
                    unit->unitHandle,
                    QD_MAXIMUM_I2C_DATA_RATE);
                if (status == QD_SUCCESS)
                {
                    RecordBasicEvent(
                        "    QD_SetI2CDataRate successfully set to {0:F}",
                        QD_MAXIMUM_I2C_DATA_RATE);
                    status = QD_GetI2CDataRate(
                        unit->unitHandle,
                        (double *) &currentDataRate);
                    if (status == QD_SUCCESS)
                    {
                        RecordBasicEvent(
                            "    QD_GetI2CDataRate successfully returned {0:F} to verify the setting",
                            currentDataRate);
                    }
                    else
                    {
                        RecordErrorEvent("    QD_GetI2CDataRate returned 0x{0:X8}", status);
                        currentDataRate = 0.0;
                    }
                }
                else
                {
                    RecordErrorEvent("    QD_SetI2CDataRate returned 0x{0:X8}", status);
                    currentDataRate = 0.0;
                }
            }
            unit->dataRate = currentDataRate;
        }
        else
        {
            RecordErrorEvent("    QD_GetI2CDataRate returned 0x{0:X8}", status);
            currentDataRate = 0.0;
        }
        RecordBasicEvent("{0} concluded, returning {1:F4}", functionName, currentDataRate);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return currentDataRate;
}                                       // end of QCOM_SetTransducerMaximumDataRate()
//----------------------------------------------------------------------------
// QCOM_ToggleTransducerPowerState
//
// Toggles the power state of the transducer on the specified unit
//
// Called by:   QCOM_ExpertUnitTransducerPowerButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToggleTransducerPowerState(
    UnitInfo        ^unit)
{
    bool            currentlyPowered = GUI_NO;
    bool            currentlySampling;
    bool            proceedWithPower = GUI_YES;
    BYTE            action;
    BYTE            statusRegister;
    DWORD           status;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_ToggleTransducerPowerState");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        currentlySampling = QCOM_QueryStopSampling(
            "Power state cannot be changed during transducer sampling.");
        if (!currentlySampling)
        {
            if (unit->flags & QCOM_UNIT_TRANSDUCER_POWER_ENABLED)
                currentlyPowered = GUI_YES;
            if (QCOM_XDSNValid(unit))
            {
                proceedWithPower = QCOM_PromptModal(
                    "Transducer Power",
                    "{0} power to transducer {1} ?",
                    (currentlyPowered ? "Disable" : "Enable"),
                    unit->transducerSerialNumber);
            }
            else
            {
                proceedWithPower = QCOM_PromptModal(
                    "Transducer Power",
                    "{0} transducer power from module {1} ?",
                    (currentlyPowered ? "Disable" : "Enable"),
                    unit->moduleSerialNumber);
            }
            if (proceedWithPower)
            {
                action = currentlyPowered ? QD_DISABLE_TRANSDUCER_POWER : QD_ENABLE_TRANSDUCER_POWER;
                QCOM_ModuleShouldApplyTransducerPower[unitNumber] = currentlyPowered ? GUI_NO : GUI_YES;
                status = QD_SetTransducerPowerState(
                    unit->unitHandle,
                    action);
                if (status == QD_SUCCESS)
                {
                    status = QD_GetModuleStatusRegister(unit->unitHandle, (LPBYTE) &statusRegister);
                    if (status == QD_SUCCESS)
                    {
                        if (statusRegister & QD_SREG_TRANSDUCER_POWER_STATE)    // 0x20
                            unit->flags |= QCOM_UNIT_TRANSDUCER_POWER_ENABLED;
                        else
                            unit->flags &= ~QCOM_UNIT_TRANSDUCER_POWER_ENABLED;
                        RecordVerboseEvent("    Transducer power state for unit {0:D} {1}",
                            unitNumber,
                            ((unit->flags & QCOM_UNIT_TRANSDUCER_POWER_ENABLED) ? "enabled" : "disabled"));
//                        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
                    }
                    else
                    {
                        RecordErrorEvent("    QD_GetModuleStatusRegister returned 0x{0:X8}",
                            status);
                    }
                }
                else
                {
                    RecordErrorEvent("    QD_SetTransducerPowerState({0:D}) returned 0x{1:X8}",
                        action, status);
                }
            }                           // end of if (proceedWithReset)
        }                               // end of if (!currentlySampling)
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_ToggleTransducerPowerState()
//----------------------------------------------------------------------------
// QCOM_URLExists
//
// Determines whether the specified URL exists
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_URLExists(
    String          ^URL)
{
    bool            URLExists = GUI_NO;
    String          ^functionName = _T("QCOM_URLExists");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    try
    {
        HttpWebRequest ^webRequest =
            dynamic_cast <HttpWebRequest ^> (WebRequest::Create(URL));
        if (webRequest)
        {
            webRequest->Method = _T("HEAD");
            HttpWebResponse ^webResponse =
                dynamic_cast <HttpWebResponse ^> (webRequest->GetResponse());
            if (webResponse)
            {
                if (webResponse->StatusCode == HttpStatusCode::OK)
                {
                    URLExists = GUI_YES;
                    RecordBasicEvent("    Found {0}", URL);
                    //--------------------------------------------------------
                    // Call the destructor, which will prevent the software
                    // from hanging until it times out, if it ever calls this
                    // function multiple times in rapid succession
                    //--------------------------------------------------------
                    webResponse->~HttpWebResponse();
                }
            }
        }
    }
    catch (WebException ^ex)
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} for {1} failed\nException: {2}",
            functionName, URL, ex->Message);
    }
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (URLExists ? "Found" : "Not Found"));
    return URLExists;
}                                       // end of QCOM_URLExists()
//----------------------------------------------------------------------------
#endif      // DEVICE_CPP
//============================================================================
// End of Device.cpp
//============================================================================
