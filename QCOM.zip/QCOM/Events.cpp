//============================================================================
// Events.cpp
//
// The event methods registered by the source methods
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     EVENTS_CPP
#define     EVENTS_CPP
#include    "Events.h"
//----------------------------------------------------------------------------
// QCOM_AnimateBlinker
//
// Advances the blinking graphic images by invalidating the main form
//
// Called by:   QCOM_StartPausedBlinker
//              QCOM_StopPausedBlinker
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_AnimateBlinker(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (blinkerCurrentlyAnimating)
    {
        Invalidate();
        ImageAnimator::UpdateFrames();
    }
}                                       // end of QCOM_AnimateBlinker()
//----------------------------------------------------------------------------
// QCOM_ComboBoxAcceptEnterKey
//
// Handles the acceptance of the Enter key in a combo box
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ComboBoxAcceptEnterKey(
    Object          ^sender,
    PreviewKeyDownEventArgs
                    ^evt)
{
    if (evt->KeyCode == Keys::Enter)
    {
        evt->IsInputKey = GUI_YES;
    }
}                                       // end of QCOM_ComboBoxAcceptEnterKey()
//----------------------------------------------------------------------------
// QCOM_ComputerGoingToHibernation
//
// Handles the computer going into hibernation event
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ComputerGoingToHibernation(
    Object          ^sender,
    PowerModeChangedEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    if (evt->Mode == PowerModes::Suspend)
    {
        RecordBasicEvent("Computer {0} is going into hibernation", Environment::MachineName);
        //--------------------------------------------------------------------
        // Clean up
        //--------------------------------------------------------------------
        QCOM_ShutDownSoftware();
        //--------------------------------------------------------------------
        // TODO: The permanent solution would be to prevent going into
        // hibernation altogether, but in the mean time, just bail
        //--------------------------------------------------------------------
        Environment::Exit(0);
    }
}                                       // end of QCOM_ComputerGoingToHibernation()
//----------------------------------------------------------------------------
// QCOM_ComputerShuttingDown
//
// Handles the computer shutdown event
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ComputerShuttingDown(
    Object          ^sender,
    SessionEndedEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    if (evt->Reason == SessionEndReasons::SystemShutdown)
    {
        RecordBasicEvent("Computer {0} is shutting down", Environment::MachineName);
        //--------------------------------------------------------------------
        // Clean up, then bail
        //--------------------------------------------------------------------
        QCOM_ShutDownSoftware();
        Environment::Exit(0);
    }
}                                       // end of QCOM_ComputerShuttingDown()
//----------------------------------------------------------------------------
// QCOM_ConfigFileSaveDontSaveAreaClicked
//
// Handles the click of the Save / Don't Save Config File area
//
// Called by:   QCOM_InstallToolStrip
//              QCOM_MiscSetUpControls
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConfigFileSaveDontSaveAreaClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DONT_SAVE)
        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_CONFIG_DONT_SAVE;
    else
        QCOM_GeneralInfo->flags |= QCOM_GENERAL_CONFIG_DONT_SAVE;
    if (configFileTSButton)
    {
        configFileTSButton->Text =
            (QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DONT_SAVE) ?
                GUI_ENABLE_CONFIG_SAVE_STRING : GUI_DISABLE_CONFIG_SAVE_STRING;
    }
    RecordBasicEvent(
        "{0}Save Config File selected",
        ((QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DONT_SAVE) ? _T("Don't ") : QCOM_STRING_EMPTY));
    QCOM_MiscUpdateChecks();
}                                       // end of QCOM_ConfigFileSaveDontSaveAreaClicked()
//----------------------------------------------------------------------------
// QCOM_DefaultExceptionHandler
//
// Handles any exception not already handled elsewhere in the program
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DefaultExceptionHandler(
    Object          ^sender,
    UnhandledExceptionEventArgs
                    ^evt)
{
    Exception       ^defaultException = dynamic_cast <Exception ^> (evt->ExceptionObject);
    //------------------------------------------------------------------------
    GUI_DisplayMandatoryError(
        "QCOM Exception",
        defaultException->Message);
    //------------------------------------------------------------------------
    // Clean up, then bail
    //------------------------------------------------------------------------
    QCOM_ShutDownSoftware();
}                                       // end of QCOM_DefaultExceptionHandler()
//----------------------------------------------------------------------------
// QCOM_EmailMessageClearComboBox
//
// Clears the Email combo box
//
// Called by:   QCOM_GenerateSupportLog
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_EmailMessageClearComboBox(
    Object          ^sender,
    EventArgs       ^evt)
{
    EmailInfo       ^emailInfo =
        dynamic_cast <EmailInfo ^> ((dynamic_cast <ComboBox ^> (sender))->Tag);
    //------------------------------------------------------------------------
}                                       // end of QCOM_EmailMessageClearComboBox()
//----------------------------------------------------------------------------
// QCOM_EmailMessageProcessComboEnterKey
//
// Processes the result of accepting the Enter key in the Email Support Log
// combo box
//
// Called by:   QCOM_GenerateSupportLog
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_EmailMessageProcessComboEnterKey(
    Object          ^sender,
    KeyEventArgs    ^evt)
{
    EmailInfo       ^emailInfo =
        dynamic_cast <EmailInfo ^> ((dynamic_cast <ComboBox ^> (sender))->Tag);
    //------------------------------------------------------------------------
    if (evt->KeyCode == Keys::Enter)
    {
        if (emailInfo)
        {
            RecordBasicEvent(
                "Email Support Log Box Enter Key pressed for email address\n{0}",
                emailInfo->toAddress);
            emailInfo->toAddress = emailToCombo->Text;
            emailInfo->fromAddress = emailFromCombo->Text;
            emailInfo->subjectString = emailSubjectBox->Text;
            emailInfo->messageString = emailMessageBox->Text;
            QCOM_VerifyAndSendEmail(emailInfo);
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "Email Support Log Box Enter Key pressed with an invalid email structure");
        }
        //--------------------------------------------------------------------
        // The following line prevents the handler from reacting to this key
        // press as though it was done in error (ding!)
        //--------------------------------------------------------------------
        evt->SuppressKeyPress = GUI_YES;
    }
}                                       // end of QCOM_EmailMessageProcessComboEnterKey()
//----------------------------------------------------------------------------
// QCOM_EmailMessageSendButtonClicked
//
// Event that handles the click of the Send Email button
//
// Called by:   QCOM_GenerateSupportLog
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_EmailMessageSendButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    EmailInfo       ^emailInfo =
        dynamic_cast <EmailInfo ^> ((dynamic_cast <Button ^> (sender))->Tag);
    //------------------------------------------------------------------------
    RecordBasicEvent("Send Email button clicked");
    if (emailInfo)
    {
        emailInfo->toAddress = emailToCombo->Text;
        emailInfo->fromAddress = emailFromCombo->Text;
        emailInfo->replyAddress = emailFromCombo->Text;
        emailInfo->subjectString = emailSubjectBox->Text;
        emailInfo->messageString = String::Concat(
            _T("From: "),
            emailFromCombo->Text,
            QCOM_STRING_LF, QCOM_STRING_LF,
            emailMessageBox->Text);
        QCOM_VerifyAndSendEmail(emailInfo);
    }
}                                       // end of QCOM_EmailMessageSendButtonClicked()
//----------------------------------------------------------------------------
// QCOM_EmailSupportLogCloseWindow
//
// Event that closes the Email Support Log window
//
// Called by:   QCOM_GenerateSupportLog
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_EmailSupportLogCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Email Support Log window closed");
    if (emailSupportLogWindow)
    {
        emailSupportLogWindow->Close();
    }
}                                       // end of QCOM_EmailSupportLogCloseWindow()
//----------------------------------------------------------------------------
// QCOM_EventLogCloseWindow
//
// Event that closes the Display Event Log window
//
// Called by:   QCOM_DisplayMostRecentEventLog
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_EventLogCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("QCOM_EventLogCloseWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("Close Event Log button clicked");
    eventLogWindow->Close();
}                                       // end of QCOM_EventLogCloseWindow()
//----------------------------------------------------------------------------
// QCOM_ExitProgram
//
// Event that closes the home window, effectively exiting the program, if no
// other windows are opened in QCOM_Main
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExitProgram(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Exit Program button clicked");
    //------------------------------------------------------------------------
    // Exit the home window (this actually forces a call to
    // QCOM_HomeClosingWindow, which presents the user with a modal choice
    // whether to remain running or proceed to exit the program)
    //------------------------------------------------------------------------
    this->Close();
}                                       // end of QCOM_ExitProgram()
//----------------------------------------------------------------------------
// QCOM_ExpertBasicMessagesChecked
//
// Handles the check of the Basic Messages box
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertBasicMessagesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_BasicMessagesEnabled = (QCOM_BasicMessagesEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Basic Messages {0}",
        (QCOM_BasicMessagesEnabled ? "checked" : "un-checked"));
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ExpertBasicMessagesChecked()
//----------------------------------------------------------------------------
// QCOM_ExpertDetailedMessagesChecked
//
// Handles the check of the Detailed Messages box
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertDetailedMessagesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_DetailedMessagesEnabled = (QCOM_DetailedMessagesEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Detailed Messages {0}",
        (QCOM_DetailedMessagesEnabled ? "checked" : "un-checked"));
    if (QCOM_DetailedMessagesEnabled)
    {
        QCOM_VerboseMessagesEnabled = GUI_YES;
        QCOM_BasicMessagesEnabled = GUI_YES;
        QCOM_ErrorMessagesEnabled = GUI_YES;
    }
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ExpertDetailedMessagesChecked()
//----------------------------------------------------------------------------
// QCOM_ExpertDLLMessagesChecked
//
// Handles the check of the DLL Messages box
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertDLLMessagesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QD_DLLMessagesEnabled = (QD_DLLMessagesEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "DLL Messages {0}",
        (QD_DLLMessagesEnabled ? "checked" : "un-checked"));
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ExpertDLLMessagesChecked()
//----------------------------------------------------------------------------
// QCOM_ExpertErrorMessagesChecked
//
// Handles the check of the Error Messages box
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertErrorMessagesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ErrorMessagesEnabled = (QCOM_ErrorMessagesEnabled ? GUI_NO : GUI_YES);
    if (QCOM_StackTracesEnabled && !QCOM_ErrorMessagesEnabled)
        QCOM_StackTracesEnabled = GUI_NO;
    RecordBasicEvent(
        "Error Messages {0}",
        (QCOM_ErrorMessagesEnabled ? "checked" : "un-checked"));
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ExpertErrorMessagesChecked()
//----------------------------------------------------------------------------
// QCOM_ExpertExperimentalButtonClicked
//
// Handles the click of the Experimental button
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertExperimentalButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Experimental button clicked");
    QCOM_PerformExperimentalExercise();
}                                       // end of QCOM_ExpertExperimentalButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ExpertExperimentsChecked
//
// Handles the check of the Experiments box
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertExperimentsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ExperimentsEnabled = QCOM_ExperimentsEnabled ? GUI_NO : GUI_YES;
    RecordBasicEvent(
        "Enable Experiments {0}",
        (QCOM_ExperimentsEnabled ? "checked" : "un-checked"));
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ExpertExperimentsChecked()
//----------------------------------------------------------------------------
// QCOM_ExpertExpMessagesChecked
//
// Handles the check of the Exp Messages checkbox
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertExpMessagesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ExpMessagesEnabled = (QCOM_ExpMessagesEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Experimental Messages {0}",
        (QCOM_ExpMessagesEnabled ? "checked" : "un-checked"));
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ExpertExpMessagesChecked()
//----------------------------------------------------------------------------
// QCOM_ExpertHaltOperationsOnErrorsChecked
//
// Handles the check of the Halt Operations on Errors checkbox
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertHaltOperationsOnErrorsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_HaltOperationsOnErrors = (QCOM_HaltOperationsOnErrors ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Halt Operations on Errors {0}",
        (QCOM_HaltOperationsOnErrors ? "checked" : "un-checked"));
    if (!QCOM_HaltOperationsOnErrors && (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_STOP_ON_ERRORS))
    {
        QCOM_ToggleGeneralTestFlagThenSetUnitFlags(
            QCOM_GENERAL_TEST_STOP_ON_ERRORS,
            QCOM_UNIT_TEST_STOP_ON_ERRORS);
    }
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ExpertHaltOperationsOnErrorsChecked()
//----------------------------------------------------------------------------
// QCOM_ExpertPerformExperimentsButtonClicked
//
// Handles the click of the Run Experiments button
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertPerformExperimentsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Perform Experiments button clicked");
    QCOM_PerformExperiments();
}                                       // end of QCOM_ExpertPerformExperimentsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ExpertProgramIntervalChecked
//
// Handles the selection of the Enable Program Poller checkbox
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertProgramIntervalChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ProgramIntervalEnabled = (QCOM_ProgramIntervalEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Program Interval Poller {0}",
        (QCOM_ProgramIntervalEnabled ? "checked" : "un-checked"));
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
}                                       // end of QCOM_ExpertProgramIntervalChecked()
//----------------------------------------------------------------------------
// QCOM_ExpertRealTimeWeightDemoButtonClicked
//
// Handles the click of the Weight Demo button
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//
// Note:    Hard-coded to unit 0 for now
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertRealTimeWeightDemoButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("QCOM_ExpertRealTimeWeightDemoButtonClicked");
    //------------------------------------------------------------------------
    QCOM_RealTimeWeightDisplayWindow(0);
}                                       // end of QCOM_ExpertRealTimeWeightDemoButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ExpertResetAllMessagesButtonClicked
//
// Handles the click of the Reset All Modal Messages button
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertResetAllMessagesButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Reset All Modal Messages button clicked");
    QCOM_BasicMessagesEnabled = GUI_NO;
    QCOM_ErrorMessagesEnabled = GUI_NO;
    QCOM_VerboseMessagesEnabled = GUI_NO;
    QCOM_DetailedMessagesEnabled = GUI_NO;
    QCOM_StackTracesEnabled = GUI_NO;
    QCOM_ExpMessagesEnabled = GUI_NO;
    QD_DLLMessagesEnabled = GUI_NO;
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ExpertResetAllMessagesButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ExpertSendAllTransducerReadingsChecked
//
// Handles the check of the Send Transducer Readings box
//
// Called by:   QCOM_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertSendAllTransducerReadingsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            stopSending = GUI_NO;
    String          ^functionName = _T("QCOM_ExpertSendAllTransducerReadingsChecked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(expertTextMessageToNumberBox->Text) || StringSet(expertEmailMessageToAddressBox->Text))
    {
        bool atLeastOneUnitSending = GUI_NO;
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                if (unit->flags & QCOM_UNIT_SEND_XD_READINGS)
                {
                    atLeastOneUnitSending = GUI_YES;
                }
            }
        }
        if (atLeastOneUnitSending)
            stopSending = GUI_YES;
    }                                   // end of if (StringSet(expertTextMessageToNumberBox->Text) || ...)
    else
    {
        stopSending = GUI_YES;
    }
    if (stopSending)
    {
        //--------------------------------------------------------------------
        // Disable them all (stop all of them from sending)
        //--------------------------------------------------------------------
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                if (unit->flags & QCOM_UNIT_SEND_XD_READINGS)
                {
                    unit->flags &= ~QCOM_UNIT_SEND_XD_READINGS;
                    expertSendEveryLabelArray[unitNumber]->Visible = GUI_NO;
                    expertSendEveryBoxArray[unitNumber]->Visible = GUI_NO;
                    expertSendEveryMinutesLabelArray[unitNumber]->Visible = GUI_NO;
                    expertSendEveryMinutesRemainingLabelArray[unitNumber]->Visible = GUI_NO;
                    sendEveryTimerArray[unitNumber]->Stop();
                }
            }
        }                               // end of for (DWORD unitNumber = 0; ...)
        RecordBasicEvent("    All Send Transducer Readings disabled");
    }
    else
    {
        //--------------------------------------------------------------------
        // Enable them all (start all of them sending)
        //--------------------------------------------------------------------
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                if (!(unit->flags & QCOM_UNIT_SEND_XD_READINGS))
                {
                    unit->flags |= QCOM_UNIT_SEND_XD_READINGS;
                    expertSendEveryLabelArray[unitNumber]->Visible = GUI_YES;
                    expertSendEveryBoxArray[unitNumber]->Visible = GUI_YES;
                    expertSendEveryMinutesLabelArray[unitNumber]->Visible = GUI_YES;
                    expertSendEveryMinutesRemainingLabelArray[unitNumber]->Visible = GUI_YES;
                    sendEveryTimerArray[unitNumber]->Start();
                }
            }
        }                               // end of for (DWORD unitNumber = 0; ...)
        RecordBasicEvent("    All Send Transducer Readings enabled");
    }
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ExpertSendAllTransducerReadingsChecked()
//----------------------------------------------------------------------------
// QCOM_ExpertSendEmailErrorMessageChecked
//
// Handles the check of the Send Email Messages on Errors checkbox
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertSendEmailErrorMessageChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_SendEmailErrorMessagesEnabled = (QCOM_SendEmailErrorMessagesEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Sending Email Messages on Errors {0}",
        (QCOM_SendEmailErrorMessagesEnabled ? "checked" : "un-checked"));
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ExpertSendEmailErrorMessageChecked()
//----------------------------------------------------------------------------
// QCOM_ExpertSendTextErrorMessageChecked
//
// Handles the check of the Send Text Messages on Errors checkbox
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertSendTextErrorMessageChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_SendTextErrorMessagesEnabled = (QCOM_SendTextErrorMessagesEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Sending Text Messages on Errors {0}",
        (QCOM_SendTextErrorMessagesEnabled ? "checked" : "un-checked"));
    QCOM_UpdateGlobalObjectsPerFlags();
}                                       // end of QCOM_ExpertSendTextErrorMessageChecked()
//----------------------------------------------------------------------------
// QCOM_ExpertStackTraceChecked
//
// Handles the check of the Display Stack Trace on Errors checkbox
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertStackTraceChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_StackTracesEnabled = (QCOM_StackTracesEnabled ? GUI_NO : GUI_YES);
    if (QCOM_StackTracesEnabled && !QCOM_ErrorMessagesEnabled)
        QCOM_ErrorMessagesEnabled = GUI_YES;
    RecordBasicEvent(
        "Stack Trace on Error {0}",
        (QCOM_StackTracesEnabled ? "checked" : "un-checked"));
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ExpertStackTraceChecked()
//----------------------------------------------------------------------------
// QCOM_ExpertUnitSendTransducerReadingsChecked
//
// Handles the check of the unit Send Transducer Readings box
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertUnitSendTransducerReadingsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_ExpertUnitSendTransducerReadingsChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        if (StringSet(expertTextMessageToNumberBox->Text) || StringSet(expertEmailMessageToAddressBox->Text))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
            QCOM_ToggleUnitFlagThenSetGeneralFlag(
                unit,
                QCOM_GENERAL_ZERO_FLAG,
                QCOM_UNIT_SEND_XD_READINGS);
            RecordBasicEvent(
                "Send Transducer Readings every {0:D} minutes for module {1} {2}",
                QCOM_CurrentSendEveryInterval[unitNumber],
                unit->moduleSerialNumber,
                ((unit->flags & QCOM_UNIT_SEND_XD_READINGS) ? "checked" : "un-checked"));
            if (unit->flags & QCOM_UNIT_SEND_XD_READINGS)
            {
                expertSendEveryLabelArray[unitNumber]->Visible = GUI_YES;
                expertSendEveryBoxArray[unitNumber]->Visible = GUI_YES;
                expertSendEveryMinutesLabelArray[unitNumber]->Visible = GUI_YES;
                expertSendEveryMinutesRemainingLabelArray[unitNumber]->Visible = GUI_YES;
                sendEveryTimerArray[unitNumber]->Start();
            }
            else
            {
                expertSendEveryLabelArray[unitNumber]->Visible = GUI_NO;
                expertSendEveryBoxArray[unitNumber]->Visible = GUI_NO;
                expertSendEveryMinutesLabelArray[unitNumber]->Visible = GUI_NO;
                expertSendEveryMinutesRemainingLabelArray[unitNumber]->Visible = GUI_NO;
                sendEveryTimerArray[unitNumber]->Stop();
            }
        }                               // end of if (StringSet(expertTextMessageToNumberBox->Text) || ...)
    }                                   // end of if (QCOM_UnitNumberValid(unitNumber))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_ExpertUnitSendTransducerReadingsChecked()
//----------------------------------------------------------------------------
// QCOM_ExpertUnitTransducerPowerButtonClicked
//
// Handles the click of the Transducer Power button
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertUnitTransducerPowerButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_ExpertUnitTransducerPowerButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Transducer Power button clicked for module {0}...power {1}",
            unit->moduleSerialNumber,
            ((unit->flags & QCOM_UNIT_TRANSDUCER_POWER_ENABLED) ? "disabled" : "enabled"));
        QCOM_ToggleTransducerPowerState(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_ExpertUnitTransducerPowerButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ExpertVerboseMessagesChecked
//
// Handles the check of the Verbose Messages box
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertVerboseMessagesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_VerboseMessagesEnabled = (QCOM_VerboseMessagesEnabled ? GUI_NO : GUI_YES);
    RecordBasicEvent(
        "Verbose Messages {0}",
        (QCOM_VerboseMessagesEnabled ? "checked" : "un-checked"));
    if (QCOM_VerboseMessagesEnabled)
    {
        QCOM_BasicMessagesEnabled = GUI_YES;
        QCOM_ErrorMessagesEnabled = GUI_YES;
    }
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ExpertVerboseMessagesChecked()
//----------------------------------------------------------------------------
// QCOM_HelpCloseWindow
//
// Event that closes the help window
//
// Called by:   QCOM_AboutHelp
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_HelpCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("About window closed");
    if (aboutHelpWindow)
    {
        aboutHelpWindow->Close();
    }
}                                       // end of QCOM_HelpCloseWindow()
//----------------------------------------------------------------------------
// QCOM_HomeClosingWindow
//
// Handles the closing of the home window
//
// Called by:   QCOM_InitializeGUIComponents
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_HomeClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    bool            proceedWithExit = GUI_YES;
    bool            promptToExit = GUI_YES;
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE)
        promptToExit = GUI_NO;
    if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING) ||
        (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING) ||
        (QCOM_GeneralInfo->flags & QCOM_GENERAL_FIRMWARE_UPDATING) ||
        (QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_REDRAWING))
        promptToExit = GUI_YES;
    if (promptToExit)
    {
        proceedWithExit = QCOM_PromptYesNoModal(
            "Exit QCOM",
            "Exit", "Cancel",
            "Proceed to Exit or Cancel ?");
    }
    if (proceedWithExit)
    {
        evt->Cancel = GUI_NO;       // proceed to close the window (don't cancel)
    }
    else
    {
        evt->Cancel = GUI_YES;      // cancel the closing of the window
    }
    //------------------------------------------------------------------------
    // The user has selected to exit the program, so shut down everything
    //------------------------------------------------------------------------
    if (proceedWithExit)
    {
        QCOM_GeneralInfo->flags |= QCOM_GENERAL_PROGRAM_EXITING;
        //--------------------------------------------------------------------
        // Shut down the software by releasing resources
        //--------------------------------------------------------------------
        QCOM_ShutDownSoftware();
    }
}                                       // end of QCOM_HomeClosingWindow()
//----------------------------------------------------------------------------
// QCOM_HomeTabSelected
//
// Handles the click of a tab
//
// Called by:   QCOM_ConstructHomeTabPages
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_HomeTabSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^tabName = QCOM_STRING_UNKNOWN;
    UnitInfo        ^unit;
    //------------------------------------------------------------------------
    if (homeTabControl && homeTabControl->SelectedTab)
    {
        switch (homeTabControl->SelectedTab->TabIndex)
        {
            case GUI_TAB_PAGE_READOUT :                                         // 0
                tabName = _T("Readout");
                break;
            case GUI_TAB_PAGE_UTILITIES :                                       // 1
                tabName = _T("Utilities");
                break;
            case GUI_TAB_PAGE_TESTING :                                         // 2
                tabName = _T("Testing");
                //------------------------------------------------------------
                // The following works around a problem with two different kinds
                // of text boxes sharing the same spot in the group box
                //------------------------------------------------------------
                for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
                {
                    if (QCOM_UnitNumberValid(unitNumber))
                    {
                        testingSummaryResultsBoxArray[unitNumber]->Visible = GUI_YES;
                        testingDetailedResultsBoxArray[unitNumber]->Visible = GUI_YES;
                        unit = QCOM_UnitInfoArray[unitNumber];
                        if (QCOM_TestResultsDetailed(unit))
                            testingSummaryResultsBoxArray[unitNumber]->Visible = GUI_NO;
                        else
                            testingDetailedResultsBoxArray[unitNumber]->Visible = GUI_NO;
                    }
                }
                break;
            case GUI_TAB_PAGE_EXPERT :                                          // 3
                tabName = _T("Expert");
                break;
            default :
                tabName = QCOM_STRING_INVALID;
                break;
        }
    }
    RecordBasicEvent("{0} tab selected", tabName);
}                                       // end of QCOM_HomeTabSelected()
//----------------------------------------------------------------------------
// QCOM_InternetHyperLinkClicked
//
// Event that handles the click of a hyperlink
//
// Called by:   QCOM_DisplayHelpLink
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InternetHyperLinkClicked(
    Object          ^sender,
    LinkLabelLinkClickedEventArgs
                    ^evt)
{
    int             timeout = 10;
    LinkLabel       ^hyperLink = dynamic_cast <LinkLabel ^> (sender);
    String          ^target = dynamic_cast <String ^> (evt->Link->LinkData);
    //------------------------------------------------------------------------
    RecordBasicEvent("Internet Hyperlink clicked");
    if (target && hyperLink)
    {
        while (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_INTERNET_AVAILABLE) && timeout)
        {
            QCOM_InternetIsAvailable();
            if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_INTERNET_AVAILABLE))
            {
                Thread::Sleep(100);
                timeout--;
            }
        }
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_INTERNET_AVAILABLE)
        {
            RecordVerboseEvent("    Link: {0}", target);
            System::Diagnostics::Process::Start(target);
            hyperLink->Links[hyperLink->Links->IndexOf(evt->Link)]->Visited = GUI_YES;
        }
        else
        {
            GUI_DisplaySimpleError(
                "Internet Access",
                "The web is unavailable at this time");
        }
    }
}                                       // end of QCOM_InternetHyperLinkClicked()
//----------------------------------------------------------------------------
// QCOM_OneMinuteTimerElapsed
//
// Handles the lapsing of the one-minute timer
//
// Called by:   QCOM_InitializeGUIComponents
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_OneMinuteTimerElapsed(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            atLeastOneUnitSampling = GUI_NO;
    UnitInfo        ^unit;
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("QCOM_OneMinuteTimerElapsed");
    //------------------------------------------------------------------------
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            if (unit->flags & QCOM_UNIT_SEND_XD_READINGS)
            {
                QCOM_CurrentSendEveryIntervalRemaining[unitNumber]--;
                if (QCOM_CurrentSendEveryIntervalRemaining[unitNumber] == 0)
                    QCOM_CurrentSendEveryIntervalRemaining[unitNumber] =
                    QCOM_CurrentSendEveryInterval[unitNumber];
                QCOM_UpdateSendEveryMinutesRemainingLabel(unitNumber);
            }
        }
    }
}                                       // end of QCOM_OneMinuteTimerElapsed()
//----------------------------------------------------------------------------
// QCOM_OneSecondTimerElapsed
//
// Handles the lapsing of the one-second timer
//
// Called by:   QCOM_InitializeGUIComponents
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_OneSecondTimerElapsed(
    Object          ^sender,
    EventArgs       ^evt)
{
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("QCOM_OneSecondTimerElapsed");
    //------------------------------------------------------------------------
    nowStatusLineTSSLabel->Text = String::Format(
        "{0,9} {1:D2} {2} {3:D4} {4:D2}:{5:D2}:{6:D2}",
        dateTime.DayOfWeek,
        dateTime.Day,
        QCOM_MonthStringArray[dateTime.Month],
        dateTime.Year,
        dateTime.Hour,
        dateTime.Minute,
        dateTime.Second);
    QCOM_ReadyToMarkSampleTime = GUI_YES;
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            QCOM_ReadyToMarkLoggingTime[unitNumber] = GUI_YES;
            QCOM_ReadyToMarkTestingTime[unitNumber] = GUI_YES;
        }
    }
}                                       // end of QCOM_OneSecondTimerElapsed()
//----------------------------------------------------------------------------
// QCOM_PauseResumeButtonClicked
//
// Handles the click of the Pause / Resume button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//              QCOM_ConstructGeneralTestingGroupBox
//              QCOM_SetUpAllDataLoggingWindows
//              QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PauseResumeButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED)
    {
        RecordBasicEvent("Resume button clicked");
        QCOM_ResumeElapsedTime();
        readoutPauseResumeButton->Text = GUI_PAUSE_OPERATIONS_STRING;
        logAllPauseResumeButton->Text = GUI_PAUSE_ALL_STRING;
        testingPauseResumeButton->Text = GUI_PAUSE_ALL_STRING;
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                graphingSingleStepButtonArray[unitNumber]->Enabled = GUI_YES;
                logUnitPauseResumeButtonArray[unitNumber]->Text = GUI_PAUSE_ALL_STRING;
                graphingPauseResumeButtonArray[unitNumber]->Text = GUI_PAUSE_ALL_STRING;
                if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING)
                    testingStateLabelArray[unitNumber]->Text = testingStateLabelArray[unitNumber]->Name;
            }
        }
    }
    else
    {
        RecordBasicEvent("Pause button clicked");
        QCOM_PauseElapsedTime();
        readoutPauseResumeButton->Text = GUI_RESUME_OPERATIONS_STRING;
        logAllPauseResumeButton->Text = GUI_RESUME_ALL_STRING;
        testingPauseResumeButton->Text = GUI_RESUME_ALL_STRING;
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                graphingSingleStepButtonArray[unitNumber]->Enabled = GUI_NO;
                logUnitPauseResumeButtonArray[unitNumber]->Text = GUI_RESUME_ALL_STRING;
                graphingPauseResumeButtonArray[unitNumber]->Text = GUI_RESUME_ALL_STRING;
                if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING)
                {
                    testingStateLabelArray[unitNumber]->Name = testingStateLabelArray[unitNumber]->Text;
                    testingStateLabelArray[unitNumber]->Text = GUI_TEST_PAUSED_STRING;
                }
            }
        }
    }
}                                       // end of QCOM_PauseResumeButtonClicked()
//----------------------------------------------------------------------------
// QCOM_PleaseWaitClosingWindow
//
// Handles the closing of the Please wait window by the red X or similar method
//
// Called by:   QCOM_PleaseWait
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PleaseWaitClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    if (pleaseWaitWindow)
    {
        pleaseWaitWindow->Tag = GUI_PLEASE_WAIT_STATE_HIDDEN;
        pleaseWaitWindow->Hide();
        pleaseWaitWindow->Update();
    }
}                                       // end of QCOM_PleaseWaitClosingWindow()
//----------------------------------------------------------------------------
// QCOM_PrecisionUpDownClicked
//
// Handles the click of the Precision boxes
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//              QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PrecisionUpDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Precision Up/Down clicked");
    QCOM_SetDecimalPrecision();
}                                       // end of QCOM_PrecisionUpDownClicked()
//----------------------------------------------------------------------------
// QCOM_PrecisionUpDownDoubleClicked
//
// Handles the double-click of the Precision boxes
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//              QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PrecisionUpDownDoubleClicked(
    Object          ^sender,
    MouseEventArgs  ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Precision Up/Down double-clicked");
    QCOM_SetDecimalPrecision();
}                                       // end of QCOM_PrecisionUpDownDoubleClicked()
//----------------------------------------------------------------------------
// QCOM_PrintFileButtonClicked
//
// Handles the click of the PrintFile button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PrintFileButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Print function clicked");
    ModalV("Function under development");
}                                       // end of QCOM_PrintFileButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ProgramTimerElapsed
//
// Handles the lapsing of the program timer
//
// Called by:   QCOM_InitializeGUIComponents
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ProgramTimerElapsed(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            noUnitsInBootLoaderMode = GUI_YES;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_ProgramTimerElapsed");
    //------------------------------------------------------------------------
    programTimer->Stop();
    QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_PROGRAM_TIMER_RUNNING;
    if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_EXITING))
    {
        if (pleaseWaitWindow)
        {
            if (((int) pleaseWaitWindow->Tag) == GUI_PLEASE_WAIT_STATE_HIDDEN)
                pleaseWaitWindow->Hide();
            pleaseWaitWindow->Update();
        }
        for (int unitNumber = 0; unitNumber < (int) QCOM_GeneralInfo->maximumNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                unit = QCOM_UnitInfoArray[unitNumber];
                if (unitNumber < (int) QCOM_CurrentNumberOfUnits)
                {
                    if (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE)
                        noUnitsInBootLoaderMode = GUI_NO;
                }
            }
        }
        //--------------------------------------------------------------------
        // Obtain fresh unit and transducer counts in case a change was made,
        // but only if it is safe to do so
        //--------------------------------------------------------------------
        if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_GUI_UP_AND_RUNNING) &&
            !(QCOM_GeneralInfo->flags & QCOM_GENERAL_FIRMWARE_UPDATING) &&
            !(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_REDRAWING) &&
            QCOM_SafeToRun() &&
            noUnitsInBootLoaderMode)
        {
            DWORD hotPlugLevel = QCOM_HOT_PLUG_LEVEL_NO_CHANGE;
            DWORD numberOfUnits = QD_GetNumberOfModules();
            if (QCOM_GeneralInfo->numberOfUnits != numberOfUnits)
            {
                RecordBasicEvent(
                    "{0}\nDetected number of modules changed from {1:D} to {2:D}",
                    functionName,
                    QCOM_GeneralInfo->numberOfUnits,
                    numberOfUnits);
                if (hotPlugLevel == QCOM_HOT_PLUG_LEVEL_NO_CHANGE)
                {
                    if (QCOM_GeneralInfo->numberOfUnits > numberOfUnits)
                        hotPlugLevel = QCOM_HOT_PLUG_LEVEL_MODULE_REMOVED;
                    else
                        hotPlugLevel = QCOM_HOT_PLUG_LEVEL_MODULE_ADDED;
                }
                QCOM_GeneralInfo->numberOfUnits = numberOfUnits;
            }
            DWORD numberOfTransducers = QCOM_GetNumberOfTransducers();
            if (QCOM_GeneralInfo->numberOfTransducers != numberOfTransducers)
            {
                RecordBasicEvent(
                    "{0}\nDetected number of transducers changed from {1:D} to {2:D}",
                    functionName,
                    QCOM_GeneralInfo->numberOfTransducers,
                    numberOfTransducers);
                if (hotPlugLevel == QCOM_HOT_PLUG_LEVEL_NO_CHANGE)
                {
                    if (QCOM_GeneralInfo->numberOfTransducers > numberOfTransducers)
                        hotPlugLevel = QCOM_HOT_PLUG_LEVEL_TRANSDUCER_REMOVED;
                    else
                        hotPlugLevel = QCOM_HOT_PLUG_LEVEL_TRANSDUCER_ADDED;
                }
                QCOM_GeneralInfo->numberOfTransducers = numberOfTransducers;
            }
            if ((hotPlugLevel != QCOM_HOT_PLUG_LEVEL_NO_CHANGE) &&
                !(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_REDRAWING))
            {
                Thread ^drawThread =
                    gcnew Thread(gcnew ParameterizedThreadStart(this, &QCOM_GUIClass::QCOM_ReDrawWindows));
                drawThread->Start(hotPlugLevel);
            }
        }                               // end of if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_GUI_UP_AND_RUNNING) && ...)
        if (QCOM_ProgramIntervalEnabled)
        {
            programTimer->Start();
            QCOM_GeneralInfo->flags |= QCOM_GENERAL_PROGRAM_TIMER_RUNNING;
        }
    }                                   // end of if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_EXITING))
}                                       // end of QCOM_ProgramTimerElapsed()
//----------------------------------------------------------------------------
// QCOM_PromptKeyPressed
//
// Handles the press of a keystroke in the PromptYesNoModal or PromptInput
// window
//
// Called by:   QCOM_PromptInputModal
//              QCOM_PromptPulldownModal
//              QCOM_PromptYesNoModal
//
// Note:    Must only be registered as an event to a Button object
//
// Note:    Enter, Esc, and Space are already handled by ShowDialog, which
//          will leave QCOM_ModalKeyStroke at 0
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PromptKeyPressed(
    Object          ^sender,
    KeyPressEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ModalKeyStroke = 0;
    if ((evt->KeyChar == (int) 'b') || (evt->KeyChar == (int) 'B') ||           // browse
        (evt->KeyChar == (int) 'd') || (evt->KeyChar == (int) 'D') ||           // delete
        (evt->KeyChar == (int) 'k') || (evt->KeyChar == (int) 'K') ||
        (evt->KeyChar == (int) 'n') || (evt->KeyChar == (int) 'N') ||           // no
        (evt->KeyChar == (int) 's') || (evt->KeyChar == (int) 'S') ||           // search / save
        (evt->KeyChar == (int) 'x') || (evt->KeyChar == (int) 'X') ||
        (evt->KeyChar == (int) 'y') || (evt->KeyChar == (int) 'Y'))             // yes
    {
        if ((evt->KeyChar == (int) 'b') || (evt->KeyChar == (int) 'B') ||
            (evt->KeyChar == (int) 'd') || (evt->KeyChar == (int) 'D') ||
            (evt->KeyChar == (int) 'n') || (evt->KeyChar == (int) 'N'))
            QCOM_ModalKeyStroke = (DWORD) 'N';
        else
            QCOM_ModalKeyStroke = (DWORD) 'Y';
        evt->Handled = GUI_YES;
        (dynamic_cast <Button ^> (sender))->PerformClick();
    }
    else
    {
        QCOM_ModalKeyStroke = Convert::ToByte(evt->KeyChar);
        switch (QCOM_ModalKeyStroke)
        {
            case GUI_KEY_ESC :                                                  // 27
            case GUI_KEY_SPACE :                                                // 32
                evt->Handled = GUI_YES;
                (dynamic_cast <Button ^> (sender))->PerformClick();
                break;
            default :
                break;
        }
    }
    RecordBasicEvent(
        "Prompt key '{0}' (0x{1:X2}) pressed, resulting in a key stroke value of {2:D}",
        evt->KeyChar, Convert::ToByte(evt->KeyChar), QCOM_ModalKeyStroke);
}                                       // end of QCOM_PromptKeyPressed()
//----------------------------------------------------------------------------
// QCOM_ResetAllButtonClicked
//
// Handles the click of the Reset All function drop-down button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//              QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ResetAllButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Reset All button clicked");
    QCOM_ResetAll();
}                                       // end of QCOM_ResetAllButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ResetUnitSoftwareButtonClicked
//
// Handles the click of the Reset Software State button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ResetUnitSoftwareButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_ResetUnitSoftwareButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Software Reset button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_ResetUnitSoftware(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_ResetUnitSoftwareButtonClicked()
//----------------------------------------------------------------------------
// QCOM_SaveAsFileButtonClicked
//
// Handles the click of the OpenFile button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SaveAsFileButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Save As function clicked");
    ModalE("Function under development");
}                                       // end of QCOM_SaveAsFileButtonClicked()
//----------------------------------------------------------------------------
// QCOM_SendEveryTimerElapsed
//
// Handles the lapsing of the Send Every timer
//
// Called by:   QCOM_InitializeGUIComponents
//
// Note:    This function is not affected by the pause / resume state
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SendEveryTimerElapsed(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Windows::Forms::Timer ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_SendEveryTimerElapsed");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        sendEveryTimerArray[unitNumber]->Stop();
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE) &&
            (StringSet(QCOM_GeneralInfo->emailMessageToAddress) ||
            StringSet(QCOM_GeneralInfo->textMessageToNumber)))
        {
            int pressureUnits = QCOM_CurrentPressureUnits;
            int temperatureUnits = QCOM_CurrentTemperatureUnits;
            DWORD status = QCOM_RetrieveTransducerReadings(unit);
            if (status == QCOM_SUCCESS)
            {
                QCOM_UpdateReadout(unit);
            }
            String ^subjectString = String::Concat(
                unit->transducerSerialNumber,
                " Readings");
            if (unit->flags & QCOM_UNIT_DISPLAY_COUNTS)
            {
                pressureUnits = QCOM_DefaultPressureUnits;
                temperatureUnits = QCOM_DefaultTemperatureUnits;
            }
            String ^messageString = String::Format(
                "Module {0}\nPres = {1:F3} {2}\nTemp = {3:F3} {4}\n{5}",
                unit->moduleSerialNumber,
                QCOM_GetPressureValue(unit, pressureUnits),
                QCOM_PressureUnitsStringArray[pressureUnits],
                QCOM_GetTemperatureValue(unit, temperatureUnits),
                QCOM_TemperatureUnitsStringArray[temperatureUnits]->Substring(
                    QCOM_TemperatureUnitsStringArray[temperatureUnits]->Length - 1),
                (QD_DLLStatus ? _T("Errors present") : _T("No errors")));
            if (StringSet(QCOM_GeneralInfo->emailMessageToAddress))
            {
                QCOM_SendEmailMessage(subjectString, messageString);
            }
            if (StringSet(QCOM_GeneralInfo->textMessageToNumber))
            {
                messageString = String::Concat(
                    messageString, QCOM_STRING_LF, QCOM_STRING_DOT);
                QCOM_SendTextMessage(subjectString, messageString);
            }
            RecordVerboseEvent(
                "Send Every {0:D} minutes timer elapsed for Module {1} Transducer {2}:\n{3}",
                QCOM_CurrentSendEveryInterval[unitNumber],
                unit->moduleSerialNumber,
                subjectString,
                messageString);
            delete messageString;
            delete subjectString;
        }                               // end of if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE) && ...)
        QCOM_CurrentSendEveryIntervalRemaining[unitNumber] =
            QCOM_CurrentSendEveryInterval[unitNumber];
        sendEveryTimerArray[unitNumber]->Start();
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_SendEveryTimerElapsed()
//----------------------------------------------------------------------------
// QCOM_TabPageAddDelegate
//
// Delegate for the Add Tab Page thread
//
// Called by:   QCOM_UpdateGlobalObjects
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TabPageAddDelegate(
    TabControl      ^parentTabControl,
    TabPage         ^childTabPage)
{
    //------------------------------------------------------------------------
    parentTabControl->Controls->Add(childTabPage);
}                                       // end of QCOM_TabPageAddDelegate()
//----------------------------------------------------------------------------
// QCOM_TabPageRemoveDelegate
//
// Delegate for the Remove Tab Page thread
//
// Called by:   QCOM_UpdateGlobalObjects
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TabPageRemoveDelegate(
    TabControl      ^parentTabControl,
    TabPage         ^childTabPage)
{
    //------------------------------------------------------------------------
    parentTabControl->Controls->Remove(childTabPage);
}                                       // end of QCOM_TabPageRemoveDelegate()
//----------------------------------------------------------------------------
// QCOM_ToolStripAboutDropDownClicked
//
// Handles the click of the About drop down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripAboutDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("About drop-down button clicked");
    QCOM_AboutHelp();
}                                       // end of QCOM_ToolStripAboutDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripCheckForUpdateDropDownClicked
//
// Handles the click of the Check for Update drop down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripCheckForUpdateDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            proceedToCheck = GUI_NO;
    //------------------------------------------------------------------------
    RecordBasicEvent("Check for Update drop-down button clicked");
    proceedToCheck = QCOM_PromptModal(
        "Check for Update",
        "You are running QCOM software version {0}\n"
        "Check online for an updated version?",
        QCOM_PROGRAM_VERSION_STRING);
    if (proceedToCheck)
        QCOM_CheckForCurrentSoftwareVersion(GUI_YES);
}                                       // end of QCOM_ToolStripCheckForUpdateDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteAllDataCSVFilesDropDownClicked
//
// Handles the click of the Delete All Data CSV Files button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteAllDataCSVFilesDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Delete All Data CSV Files drop-down button clicked");
    QCOM_DeleteLogFiles(GUI_DELETE_ALL_DATA_CSV_FILES);
}                                       // end of QCOM_ToolStripDeleteAllDataCSVFilesDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteAllDataLogFilesDropDownClicked
//
// Handles the click of the Delete All Data Log Files button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteAllDataLogFilesDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Delete All Data Log Files drop-down button clicked");
    QCOM_DeleteLogFiles(GUI_DELETE_ALL_DATA_LOG_FILES);
}                                       // end of QCOM_ToolStripDeleteAllDataLogFilesDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteAllErrorLogFilesDropDownClicked
//
// Handles the click of the Delete All Error Log Files button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteAllErrorLogFilesDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Delete All Error Log Files drop-down button clicked");
    QCOM_DeleteLogFiles(GUI_DELETE_ALL_ERROR_LOG_FILES);
}                                       // end of QCOM_ToolStripDeleteAllErrorLogFilesDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteAllEventLogFilesDropDownClicked
//
// Handles the click of the Delete All Event Log Files button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteAllEventLogFilesDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Delete All Event Log Files drop-down button clicked");
    QCOM_DeleteLogFiles(GUI_DELETE_ALL_EVENT_LOG_FILES);
}                                       // end of QCOM_ToolStripDeleteAllEventLogFilesDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteAllLogFilesDropDownClicked
//
// Handles the click of the Delete All Log Files button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteAllLogFilesDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Delete All Log Files drop-down button clicked");
    QCOM_DeleteLogFiles(GUI_DELETE_ALL_LOG_FILES);
}                                       // end of QCOM_ToolStripDeleteAllLogFilesDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteAllTestResultsFilesDropDownClicked
//
// Handles the click of the Delete All Test Results Files button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteAllTestResultsFilesDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Delete All Test Results Files drop-down button clicked");
    QCOM_DeleteLogFiles(GUI_DELETE_ALL_TEST_LOG_FILES);
}                                       // end of QCOM_ToolStripDeleteAllTestResultsFilesDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripDownloadTheLatestDropDownClicked
//
// Handles the click of the Download the Latest drop down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDownloadTheLatestDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            proceedToCheck = GUI_NO;
    //------------------------------------------------------------------------
    RecordBasicEvent("Download the Latest drop-down button clicked");
    proceedToCheck = QCOM_PromptModal(
        "Download the Latest Software",
        "You are running QCOM software version {0}\n"
        "Download the latest version anyway?",
        QCOM_PROGRAM_VERSION_STRING);
    if (proceedToCheck)
        QCOM_DownloadLatestSoftwareVersion(GUI_YES);
}                                       // end of QCOM_ToolStripDownloadTheLatestDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripExpertModeDropDownClicked
//
// Handles the click of the Expert Mode button by adding the Expert tab to the
//      set of tabs already present as the third tab, or removes it if the tab
//      is present
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripExpertModeDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Expert Mode drop-down button clicked");
    QCOM_ToggleExpertMode();
}                                       // end of QCOM_ToolStripExpertModeDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripLogFilesSaveDropDownClicked
//
// Handles the click of the Save / Don't Save Log Files drop down
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripLogFilesSaveDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DONT_SAVE_ON_EXIT)
    {
        QCOM_GeneralInfo->logFlags &= ~QCOM_GENERAL_LOG_DONT_SAVE_ON_EXIT;
        QCOM_GeneralInfo->testFlags &= ~QCOM_GENERAL_TEST_DONT_SAVE_ON_EXIT;
    }
    else
    {
        QCOM_GeneralInfo->logFlags |= QCOM_GENERAL_LOG_DONT_SAVE_ON_EXIT;
        QCOM_GeneralInfo->testFlags |= QCOM_GENERAL_TEST_DONT_SAVE_ON_EXIT;
    }
    saveLogFilesOnExitTSButton->Text =
        (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DONT_SAVE_ON_EXIT) ?
            GUI_ENABLE_LOGS_SAVE_STRING : GUI_DISABLE_LOGS_SAVE_STRING;
    RecordBasicEvent(
        "{0}Save Data Log and Test Result File selected",
        ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DONT_SAVE_ON_EXIT) ? _T("Don't ") : QCOM_STRING_EMPTY));
}                                       // end of QCOM_ToolStripLogFilesSaveDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripMiscControlsDropDownClicked
//
// Handles the click of the Misc Controls button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripMiscControlsDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Miscellaneous Controls drop-down button clicked");
    if (miscControlWindow)
    {
        //--------------------------------------------------------------------
        // Promote the window and make it active, if possible
        //--------------------------------------------------------------------
        if (miscControlWindow->WindowState == FormWindowState::Minimized)
            miscControlWindow->WindowState = FormWindowState::Normal;
        else
            miscControlWindow->Show();
        if (miscControlWindow->CanSelect)
            miscControlWindow->Select();
    }
}                                       // end of QCOM_ToolStripMiscControlsDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripOnlineHelpDropDownClicked
//
// Event that invokes the default browser to display the QCOM online help
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripOnlineHelpDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Online Help URL drop-down button clicked");
    if (QCOM_InternetIsAvailable())
        System::Diagnostics::Process::Start(QCOM_HELP_URL);
    else
        GUI_DisplaySimpleError(
            "Online Help",
            "The web is unavailable at this time");
}                                       // end of QCOM_ToolStripOnlineHelpDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripProgInfoDropDownClicked
//
// Handles the click of the Program Info button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripProgInfoDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Program Info drop-down button clicked");
    QCOM_ProgramInformationDisplayWindow();
}                                       // end of QCOM_ToolStripProgInfoDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripReScanDropDownClicked
//
// Handles the click of the ReScan Function button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripReScanDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Re-scan function drop-down button clicked");
    QCOM_ReScanSystem();
}                                       // end of QCOM_ToolStripReScanDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripResetAllModulesDropDownClicked
//
// Handles the click of the Reset Module Function button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripResetAllModulesDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Reset All Modules function drop-down button clicked");
    QCOM_ResetAllModules();
}                                       // end of QCOM_ToolStripResetAllModulesDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripResetAllSoftwareDropDownClicked
//
// Handles the click of the Reset SoftWare function button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripResetAllSoftwareDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Reset All Software function drop-down button clicked");
    QCOM_ResetAllSoftware();
}                                       // end of QCOM_ToolStripResetAllSoftwareDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripResetAllTransducersDropDownClicked
//
// Handles the click of the Reset All Transducers function button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripResetAllTransducersDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Reset All Transducers function drop-down button clicked");
    QCOM_ResetAllTransducers();
}                                       // end of QCOM_ToolStripResetAllTransducersDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripSupportLogDropDownClicked
//
// Handles the click of the Support Log button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripSupportLogDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Support Log drop-down button clicked");
    QCOM_GenerateSupportLog();
}                                       // end of QCOM_ToolStripSupportLogDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_UtilConvertReadingsButtonClicked
//
// Handles the click of the util Convert Readings button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertReadingsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Convert Readings button clicked");
    QCOM_UtilConvertReadings();
}                                       // end of QCOM_UtilConvertReadingsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_UtilConvertReadingsCloseWindow
//
// Event that closes the Convert Readings window
//
// Called by:   QCOM_UtilConvertReadings
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertReadingsCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Convert Readings window closed");
    convertReadingsWindow->Close();
}                                       // end of QCOM_UtilConvertReadingsCloseWindow()
//----------------------------------------------------------------------------
// QCOM_UtilConvertReadingsLoadFileButtonClicked
//
// Handles the click of the util Load Readings File button
//
// Called by:   QCOM_UtilConvertReadings
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertReadingsLoadFileButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Convert Readings Load File button clicked");
    QCOM_UtilConvertReadingsLoadFile();
}                                       // end of QCOM_UtilConvertReadingsLoadFileButtonClicked()
//----------------------------------------------------------------------------
// QCOM_UtilResetModuleButtonClicked
//
// Handles the click of the Reset Module button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilResetModuleButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_UtilResetModuleButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Reset button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_ResetUnit(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_UtilResetModuleButtonClicked()
//----------------------------------------------------------------------------
// QCOM_UtilUnitResetTransducerButtonClicked
//
// Handles the click of the unit Reset Transducer button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilUnitResetTransducerButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_UtilUnitResetTransducerButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if (QCOM_XDSNValid(unit))
        {
            RecordBasicEvent(
                "Reset button clicked for transducer {0}",
                unit->transducerSerialNumber);
        }
        else
        {
            RecordBasicEvent(
                "Reset Transducer button clicked for module {0}",
                unit->moduleSerialNumber);
        }
        QCOM_ResetTransducer(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_UtilUnitResetTransducerButtonClicked()
//----------------------------------------------------------------------------
// QCOM_UtilVerifyHexFileButtonClicked
//
// Handles the click of the Test Hex File button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilVerifyHexFileButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Verify Hex File button clicked");
    QCOM_PromptAndVerifyHexFile();
}                                       // end of QCOM_UtilVerifyHexFileButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ValidateConvertReadingsTransducerSerialNumber
//
// Handles changes of the Transducer Serial Number field
//
// Called by:   QCOM_UtilConvertReadings
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateConvertReadingsTransducerSerialNumber(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^functionName = _T("QCOM_ValidateConvertReadingsTransducerSerialNumber");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    String ^serialNumberString = utilConvertReadingsTransducerSerialNumberBox->Text;
    if (StringSet(serialNumberString))
    {
        if (serialNumberString->Length == 6)
        {
            DWORD serialNumber = 0;
            bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
                serialNumberString,
                &serialNumber);
            if (isCorrectFormat)
            {
                utilConvertReadingsUnit->transducerSerialNumber = serialNumberString;
                QCOM_GeneralInfo->searchString = serialNumberString;
                //--------------------------------------------
                // Search the database
                //--------------------------------------------
                QCOM_PleaseWait(
                    GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
                    "Searching for Transducer {0} Coefficient File",
                    serialNumberString);
                StringBuilder ^filePathBuilder =
                    gcnew StringBuilder(QCOM_MAXIMUM_FILE_PATH_LENGTH);
                bool fileLocated = QCOM_SearchForCoefficientFile(
                    serialNumberString,
                    filePathBuilder);
                utilConvertReadingsUnit->coefficientFilePath = filePathBuilder->ToString();
                utilConvertReadingsUnit->flags |= QCOM_UNIT_COEFFICIENT_FILE_SPECIFIED;
                delete filePathBuilder;
                QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
                Thread::Sleep(100);
                if (fileLocated)
                {
                    DWORD status = QCOM_ReadCoefficientDataFromFile(
                        utilConvertReadingsUnit->coefficientFilePath,
                        utilConvertReadingsUnit->coefficientData);
                    if (status == QCOM_SUCCESS)
                    {
                        utilConvertReadingsUnit->flags |= QCOM_UNIT_COEFFICIENTS_VERIFIED;
                        utilConvertReadingsLoadFileButton->Enabled = GUI_YES;
                        utilConvertReadingsPressureCountBox->Clear();
                        utilConvertReadingsPressureCountBox->Enabled = GUI_YES;
                        utilConvertReadingsPressureCountBox->BackColor = Color::White;
                        utilConvertReadingsTemperatureCountBox->Clear();
                        utilConvertReadingsTemperatureCountBox->Enabled = GUI_YES;
                        utilConvertReadingsTemperatureCountBox->BackColor = Color::White;
                        utilConvertReadingsPressureFrequencyBox->Clear();
                        utilConvertReadingsPressureFrequencyBox->Enabled = GUI_YES;
                        utilConvertReadingsPressureFrequencyBox->BackColor = Color::White;
                        utilConvertReadingsTemperatureFrequencyBox->Clear();
                        utilConvertReadingsTemperatureFrequencyBox->Enabled = GUI_YES;
                        utilConvertReadingsTemperatureFrequencyBox->BackColor = Color::White;
                    }
                }
            }
            else
                Modal("S/N {0} bad format", serialNumberString);
        }
        else
        {
            Modal("S/N {0} bad length", serialNumberString);
        }
    }
    else
    {
        utilConvertReadingsLoadFileButton->Enabled = GUI_NO;
        utilConvertReadingsPressureCountBox->Enabled = GUI_NO;
        utilConvertReadingsTemperatureCountBox->Enabled = GUI_NO;
        utilConvertReadingsPressureFrequencyBox->Enabled = GUI_NO;
        utilConvertReadingsTemperatureFrequencyBox->Enabled = GUI_NO;
    }
    evt->Cancel = GUI_NO;
    RecordBasicEvent("{0} concluded: Accept", functionName);
}                                       // end of QCOM_ValidateConvertReadingsTransducerSerialNumber()
//----------------------------------------------------------------------------
// QCOM_ValidateConvertReadingsPressureCount
//
// Handles changes of the pressure count field
//
// Called by:   QCOM_UtilConvertReadings
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateConvertReadingsPressureCount(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^functionName = _T("QCOM_ValidateConvertReadingsPressureCount");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    String ^pressureCountString = utilConvertReadingsPressureCountBox->Text;
    if (StringSet(pressureCountString))
    {
        if (pressureCountString->Length)
        {
            DWORD pressureCount = 0;
            bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
                pressureCountString,
                &pressureCount);
            if (isCorrectFormat)
            {
                utilConvertReadingsUnit->pressureCountString = pressureCountString;
                utilConvertReadingsUnit->pressureCount = (long) pressureCount;
                if (StringSet(utilConvertReadingsPressureCountBox->Text) &&
                    StringSet(utilConvertReadingsTemperatureCountBox->Text))
                {
                    QCOM_UtilConvertTransducerCounts();
                }
            }
            else
                Modal("Pressure Count {0} invalid value", pressureCountString);
        }
        else
        {
            Modal("Pressure Count missing");
        }
    }
    evt->Cancel = GUI_NO;
    RecordBasicEvent("{0} concluded: Accept", functionName);
}                                       // end of QCOM_ValidateConvertReadingsPressureCount()
//----------------------------------------------------------------------------
// QCOM_ValidateConvertReadingsPressureFrequency
//
// Handles changes of the pressure frequency field
//
// Called by:   QCOM_UtilConvertReadings
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateConvertReadingsPressureFrequency(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^functionName = _T("QCOM_ValidateConvertReadingsPressureFrequency");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    String ^pressureFrequencyString = utilConvertReadingsPressureFrequencyBox->Text;
    if (StringSet(pressureFrequencyString))
    {
        if (pressureFrequencyString->Length)
        {
            double pressureFrequency = 0.0;
            bool isCorrectFormat = QCOM_ParseAndConvertStringToDouble(
                pressureFrequencyString,
                &pressureFrequency);
            if (isCorrectFormat)
            {
                utilConvertReadingsUnit->pressureFrequencyString = pressureFrequencyString;
                utilConvertReadingsUnit->pressureFrequency = pressureFrequency;
                long pressureCount = (long) (pressureFrequency / QCOM_FREQUENCY_MULTIPLIER);
                utilConvertReadingsUnit->pressureCount = pressureCount;
                utilConvertReadingsUnit->pressureCountString = String::Format(
                    "{0:D8}", pressureCount);
                if (StringSet(utilConvertReadingsPressureFrequencyBox->Text) &&
                    StringSet(utilConvertReadingsTemperatureFrequencyBox->Text))
                {
                    QCOM_UtilConvertTransducerFrequencies();
                }
            }
            else
                Modal("Pressure Frequency {0} invalid value", pressureFrequencyString);
        }
        else
        {
            Modal("Pressure Frequency value missing");
        }
    }
    evt->Cancel = GUI_NO;
    RecordBasicEvent("{0} concluded: Accept", functionName);
}                                       // end of QCOM_ValidateConvertReadingsPressureFrequency()
//----------------------------------------------------------------------------
// QCOM_ValidateConvertReadingsTemperatureCount
//
// Handles changes of the temperature count field
//
// Called by:   QCOM_UtilConvertReadings
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateConvertReadingsTemperatureCount(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^functionName = _T("QCOM_ValidateConvertReadingsTemperatureCount");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    String ^temperatureCountString = utilConvertReadingsTemperatureCountBox->Text;
    if (StringSet(temperatureCountString))
    {
        if (temperatureCountString->Length == 8)
        {
            DWORD temperatureCount = 0;
            bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
                temperatureCountString,
                &temperatureCount);
            if (isCorrectFormat)
            {
                utilConvertReadingsUnit->temperatureCountString = temperatureCountString;
                utilConvertReadingsUnit->temperatureCount = (long) temperatureCount;
                QCOM_UtilConvertTransducerCounts();
            }
            else
                Modal("Temperature Count {0} bad format", temperatureCountString);
        }
        else
        {
            Modal("Temperature Count {0} bad length", temperatureCountString);
        }
    }
    evt->Cancel = GUI_NO;
    RecordBasicEvent("{0} concluded: Accept", functionName);
}                                       // end of QCOM_ValidateConvertReadingsTemperatureCount()
//----------------------------------------------------------------------------
// QCOM_ValidateConvertReadingsTemperatureFrequency
//
// Handles changes of the temperature frequency field
//
// Called by:   QCOM_UtilConvertReadings
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateConvertReadingsTemperatureFrequency(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^functionName = _T("QCOM_ValidateConvertReadingsTemperatureFrequency");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    String ^temperatureFrequencyString = utilConvertReadingsTemperatureFrequencyBox->Text;
    if (StringSet(temperatureFrequencyString))
    {
        if (temperatureFrequencyString->Length >= 5)
        {
            double temperatureFrequency = 0.0;
            bool isCorrectFormat = QCOM_ParseAndConvertStringToDouble(
                temperatureFrequencyString,
                &temperatureFrequency);
            if (isCorrectFormat && (temperatureFrequency >= 10000.0))
            {
                utilConvertReadingsUnit->temperatureFrequencyString = temperatureFrequencyString;
                utilConvertReadingsUnit->temperatureFrequency = temperatureFrequency;
                long temperatureCount = (long) (temperatureFrequency / QCOM_FREQUENCY_MULTIPLIER);
                utilConvertReadingsUnit->temperatureCount = temperatureCount;
                utilConvertReadingsUnit->temperatureCountString = String::Format(
                    "{0:D8}", temperatureCount);
                if (StringSet(utilConvertReadingsPressureFrequencyBox->Text) &&
                    StringSet(utilConvertReadingsTemperatureFrequencyBox->Text))
                {
                    QCOM_UtilConvertTransducerFrequencies();
                }
            }
            else
                Modal("Temperature Frequency {0}\ninvalid value (too low)", temperatureFrequencyString);
        }
        else
        {
            Modal("Temperature Frequency {0} bad length", temperatureFrequencyString);
        }
    }
    evt->Cancel = GUI_NO;
    RecordBasicEvent("{0} concluded: Accept", functionName);
}                                       // end of QCOM_ValidateConvertReadingsTemperatureFrequency()
//----------------------------------------------------------------------------
// QCOM_ValidateEmailMessageAddresses
//
// Handles changes of the Send Email Message To and CC fields; ensures that the
// field format meets the criteria for a proper email address
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateEmailMessageAddresses(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^functionName = _T("QCOM_ValidateEmailMessageAddresses");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(expertEmailMessageToAddressBox->Text))
    {
        if (QCOM_EmailAddressFormatIsValid(expertEmailMessageToAddressBox->Text))
        {
            QCOM_GeneralInfo->emailMessageToAddress =
                expertEmailMessageToAddressBox->Text;
            RecordBasicEvent(
                "    Email Message To address set as {0}",
                QCOM_GeneralInfo->emailMessageToAddress);
        }
        else
        {
            QCOM_PromptOKModal(
                "Invalid Email Address",
                "Attempt to set Email Message To address as '{0}'",
                expertEmailMessageToAddressBox->Text);
            RecordErrorEvent(
                "    Attempt to set Email Message To address as '{0}'",
                expertEmailMessageToAddressBox->Text);
        }
    }
    else
    {
        QCOM_GeneralInfo->emailMessageToAddress = String::Empty;
    }
    if (StringSet(expertEmailMessageCCAddressBox->Text))
    {
        if (QCOM_EmailAddressFormatIsValid(expertEmailMessageCCAddressBox->Text))
        {
            QCOM_GeneralInfo->emailMessageCCAddress =
                expertEmailMessageCCAddressBox->Text;
            RecordBasicEvent(
                "    Email Message CC address set as {0}",
                QCOM_GeneralInfo->emailMessageCCAddress);
        }
        else
        {
            QCOM_PromptOKModal(
                "Invalid Email Address",
                "Attempt to set Email Message CC address as '{0}'",
                expertEmailMessageCCAddressBox->Text);
            RecordErrorEvent(
                "    Attempted setting Email Message CC address as '{0}'",
                expertEmailMessageToAddressBox->Text);
        }
    }
    else
    {
        QCOM_GeneralInfo->emailMessageCCAddress = String::Empty;
    }
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
//    QCOM_UpdateMessageChecks();
//    QCOM_UpdateGlobalObjectsPerFlags();
    evt->Cancel = GUI_NO;
    RecordBasicEvent("{0} concluded: Accept", functionName);
}                                       // end of QCOM_ValidateEmailMessageAddresses()
//----------------------------------------------------------------------------
// QCOM_ValidateExperimentNumberValue
//
// Handles changes of the experiment number field; ensures that the
// integer value of the field falls within the appropriate limits
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateExperimentNumberValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    bool            revertToOriginalValue = GUI_NO;
    DWORD           newValue;
    String          ^functionName = _T("QCOM_ValidateExperimentNumberValue");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(expertExperimentNumberBox->Text))
    {
        bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
            expertExperimentNumberBox->Text,
            &newValue);
        if (isCorrectFormat)
        {
            if ((newValue < GUI_MINIMUM_EXPERIMENT_NUMBER) ||
                (newValue > GUI_MAXIMUM_EXPERIMENT_NUMBER))
            {
                QCOM_PromptOKModal(
                    "Invalid Experiment Number",
                    "Valid values are {0:D} through {1:D}, inclusive",
                    GUI_MINIMUM_EXPERIMENT_NUMBER,
                    GUI_MAXIMUM_EXPERIMENT_NUMBER);
                RecordErrorEvent(
                    "    Attempted setting experiment number to '{0:D}'",
                    newValue);
                revertToOriginalValue = GUI_YES;
            }
            else
            {
                if (newValue != QCOM_CurrentExperimentNumber)
                {
                    RecordBasicEvent(
                        "    The Experiment Number changed from {0:D} to {1:D} ms",
                        QCOM_CurrentExperimentNumber,
                        newValue);
                    QCOM_CurrentExperimentNumber = newValue;
                }
                evt->Cancel = GUI_NO;
                RecordBasicEvent("{0} concluded: Accept {1:D}",
                    functionName, QCOM_CurrentExperimentNumber);
                return;
            }
        }                               // end of if (isCorrectFormat)
        else
        {
            QCOM_PromptOKModal(
                "Invalid Characters",
                "The entry contains invalid characters;\n"
                "enter only decimal digits");
            RecordErrorEvent(
                "    Attempted setting experiment number to '{0}'",
                expertExperimentNumberBox->Text);
            revertToOriginalValue = GUI_YES;
        }
    }
    else
    {
        revertToOriginalValue = GUI_YES;
    }
    if (revertToOriginalValue)
    {
        expertExperimentNumberBox->Text = String::Concat(QCOM_CurrentExperimentNumber);
    }
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_ValidateExperimentNumberValue()
//----------------------------------------------------------------------------
// QCOM_ValidateProgramIntervalValue
//
// Handles changes of the program timer interval field; ensures that the
// integer value of the field falls within the appropriate limits
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateProgramIntervalValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    bool            revertToOriginalValue = GUI_NO;
    DWORD           newInterval;
    String          ^functionName = _T("QCOM_ValidateProgramIntervalValue");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(expertProgramIntervalBox->Text))
    {
        bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
            expertProgramIntervalBox->Text,
            &newInterval);
        if (isCorrectFormat)
        {
            if ((newInterval < GUI_MINIMUM_PROGRAM_INTERVAL) ||
                (newInterval > GUI_MAXIMUM_PROGRAM_INTERVAL))
            {
                QCOM_PromptOKModal(
                    "Invalid Interval Value",
                    "Valid values are {0:D} through {1:D}, inclusive",
                    GUI_MINIMUM_PROGRAM_INTERVAL,
                    GUI_MAXIMUM_PROGRAM_INTERVAL);
                RecordErrorEvent(
                    "    Attempted setting program interval value to '{0:D}'",
                    newInterval);
                revertToOriginalValue = GUI_YES;
            }
            else
            {
                if (newInterval != QCOM_CurrentProgramInterval)
                {
                    RecordBasicEvent(
                        "    The Program Interval changed from {0:D} to {1:D} ms",
                        QCOM_CurrentProgramInterval,
                        newInterval);
                    QCOM_CurrentProgramInterval = newInterval;
                    programTimer->Interval = newInterval;
                }
                evt->Cancel = GUI_NO;
                RecordBasicEvent("{0} concluded: Accept {1:D}",
                    functionName, QCOM_CurrentProgramInterval);
                return;
            }
        }                               // end of if (isCorrectFormat)
        else
        {
            QCOM_PromptOKModal(
                "Invalid Characters",
                "The entry contains invalid characters;\n"
                "enter only decimal digits");
            RecordErrorEvent(
                "    Attempted setting program interval value to '{0}'",
                expertProgramIntervalBox->Text);
            revertToOriginalValue = GUI_YES;
        }
    }
    else
    {
        revertToOriginalValue = GUI_YES;
    }
    if (revertToOriginalValue)
    {
        expertProgramIntervalBox->Text = String::Concat(QCOM_CurrentProgramInterval);
    }
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_ValidateProgramIntervalValue()
//----------------------------------------------------------------------------
// QCOM_ValidateRealTimeWeightMultiplierValue
//
// Handles changes of the Real Time Weight value field
//
// Called by:   QCOM_RealTimeWeightDisplayWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateRealTimeWeightMultiplierValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^functionName = _T("QCOM_ValidateExperimentNumberValue");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(realTimeWeightMultiplierBox->Text))
    {
        QCOM_RealTimeWeightMultiplier = Convert::ToDouble(
            realTimeWeightMultiplierBox->Text->Trim());
        QCOM_RealTimeWeightUpdateDisplayWindow(QCOM_UnitInfoArray[0]);
    }
    evt->Cancel = GUI_NO;
    RecordBasicEvent("{0} concluded: Accept", functionName);
}                                       // end of QCOM_ValidateRealTimeWeightMultiplierValue()
//----------------------------------------------------------------------------
// QCOM_ValidateSendEveryIntervalValue
//
// Handles changes of the Send Transducer Readings Every interval field; ensures
// that the integer value of the field falls within the appropriate limits
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateSendEveryIntervalValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    bool            revertToOriginalValue = GUI_NO;
    DWORD           newInterval;
    DWORD           unitNumber = (DWORD) (dynamic_cast <TextBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_ValidateSendEveryIntervalValue");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(expertSendEveryBoxArray[unitNumber]->Text))
    {
        bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
            expertSendEveryBoxArray[unitNumber]->Text,
            &newInterval);
        if (isCorrectFormat)
        {
            if ((newInterval < GUI_MINIMUM_SEND_EVERY_INTERVAL) ||
                (newInterval > GUI_MAXIMUM_SEND_EVERY_INTERVAL))
            {
                QCOM_PromptOKModal(
                    "Invalid Interval Value",
                    "Valid values are {0:D} through {1:D}, inclusive",
                    GUI_MINIMUM_SEND_EVERY_INTERVAL,
                    GUI_MAXIMUM_SEND_EVERY_INTERVAL);
                RecordErrorEvent(
                    "    Attempted setting send every interval value to '{0:D}'",
                    newInterval);
                revertToOriginalValue = GUI_YES;
            }
            else
            {
                if (newInterval != QCOM_CurrentSendEveryInterval[unitNumber])
                {
                    RecordBasicEvent(
                        "    The Program Interval changed from {0:D} to {1:D} ms",
                        QCOM_CurrentSendEveryInterval[unitNumber],
                        newInterval);
                    QCOM_CurrentSendEveryInterval[unitNumber] = newInterval;
                    QCOM_CurrentSendEveryIntervalRemaining[unitNumber] =
                        QCOM_CurrentSendEveryInterval[unitNumber];
                    sendEveryTimerArray[unitNumber]->Interval = newInterval * 60000;
                    QCOM_UpdateSendEveryMinutesRemainingLabel(unitNumber);
                }
                evt->Cancel = GUI_NO;
                RecordBasicEvent("{0} concluded: Accept {1:D}",
                    functionName, QCOM_CurrentSendEveryInterval[unitNumber]);
                return;
            }
        }                               // end of if (isCorrectFormat)
        else
        {
            QCOM_PromptOKModal(
                "Invalid Characters",
                "The entry contains invalid characters;\n"
                "enter only decimal digits");
            RecordErrorEvent(
                "    Attempted setting every interval value to '{0}'",
                expertSendEveryBoxArray[unitNumber]->Text);
            revertToOriginalValue = GUI_YES;
        }
    }
    else
    {
        revertToOriginalValue = GUI_YES;
    }
    if (revertToOriginalValue)
    {
        expertSendEveryBoxArray[unitNumber]->Text = String::Concat(
            QCOM_CurrentSendEveryInterval[unitNumber]);
    }
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_ValidateSendEveryIntervalValue()
//----------------------------------------------------------------------------
// QCOM_ValidateTextMessageNumbers
//
// Handles changes of the Send Text Message To and CC fields; ensures that the
// field format meets the criteria for a proper phone number
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateTextMessageNumbers(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    String          ^functionName = _T("QCOM_ValidateTextMessageNumbers");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(expertTextMessageToNumberBox->Text))
    {
        expertTextMessageToNumberBox->Text = QCOM_CleanUpTextBoxTextString(
            expertTextMessageToNumberBox->Text);
        QCOM_GeneralInfo->textMessageToNumber =
            expertTextMessageToNumberBox->Text;
        RecordBasicEvent(
            "    Text Message To number set as {0}",
            QCOM_GeneralInfo->textMessageToNumber);
    }
    else
    {
        QCOM_GeneralInfo->textMessageToNumber = String::Empty;
    }
    if (StringSet(expertTextMessageCCNumberBox->Text))
    {
        expertTextMessageCCNumberBox->Text = QCOM_CleanUpTextBoxTextString(
            expertTextMessageCCNumberBox->Text);
        QCOM_GeneralInfo->textMessageCCNumber =
            expertTextMessageCCNumberBox->Text;
        RecordBasicEvent(
            "    Text Message CC number set as {0}",
            expertTextMessageCCNumberBox->Text);
    }
    else
    {
        QCOM_GeneralInfo->textMessageCCNumber = String::Empty;
    }
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    evt->Cancel = GUI_NO;
    RecordBasicEvent("{0} concluded: Accept", functionName);
}                                       // end of QCOM_ValidateTextMessageNumbers()
//----------------------------------------------------------------------------
#endif      // EVENTS_CPP
//============================================================================
// End of Events.cpp
//============================================================================
