//============================================================================
// FakeDLL.cpp
//
// Equivalents to the functions embedded in qdUSB.dll
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 02-25-2014
//============================================================================
#include    "stdafx.h"
#ifndef     FAKEDLL_CPP
#define     FAKEDLL_CPP
#ifndef     QDUSB_CPP
#define     QDUSB_CPP
#include    "FakeDLL.h"
//----------------------------------------------------------------------------
// FQD_CalculateFirmwarePageCRC
//
// Returns the CRC calculated from the specified page of the specified
// firmware data buffer
//
// Note:    firmwareData must point to at least QD_FIRMWARE_MAXIMUM_DATA_SIZE
//          (63 * 1024) bytes of available memory
//
// D11813 B1 section 3.34
//----------------------------------------------------------------------------
    DWORD
FQD_CalculateFirmwarePageCRC(
    LPBYTE          firmwareData,
    BYTE            pageNumber)
{
    BYTE            newByte;
    DWORD           pageCRC = 0;
    //------------------------------------------------------------------------
    if (firmwareData)
    {
        for (DWORD offset = 0; offset < QD_FIRMWARE_PAGE_SIZE; offset++)        // 512
        {
            newByte = firmwareData[(QD_FIRMWARE_PAGE_SIZE * pageNumber) + offset];
            pageCRC ^= newByte;
            for (BYTE bitCount = 0; bitCount < 8; bitCount++)
            {
                if (pageCRC & 0x01)
                {
                    pageCRC >>= 1;
                    pageCRC ^= QD_FIRMWARE_CRC_POLYNOMIAL;                      // 0x8408
                }
                else
                {
                    pageCRC >>= 1;
                }
            }
        }
    }
    return pageCRC;
}                                       // end of FQD_CalculateFirmwarePageCRC()
//----------------------------------------------------------------------------
// FQD_CalculatePressureAndTemperature
//
// Returns the pressure in PSI and temperature in Cesius for the given
// transducer coefficient data and pressure and temperature counts
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.35
//----------------------------------------------------------------------------
    DWORD
FQD_CalculatePressureAndTemperature(
    LPBYTE          coefficientData,
    DWORD           pressureCount,
    DWORD           temperatureCount,
    DOUBLE          *pressurePSI,
    DOUBLE          *temperatureCelsius)
{
    DWORD           status = QD_SUCCESS;
    //------------------------------------------------------------------------
    status = FQD_CalculatePressureOrTemperature(
        QD_CALCULATE_PRESSURE_PSI,                                              // 0
        coefficientData,
        pressureCount,
        temperatureCount,
        pressurePSI);
    if (status == QD_SUCCESS)
    {
        status = FQD_CalculatePressureOrTemperature(
            QD_CALCULATE_TEMPERATURE_CELSIUS,                                   // 1
            coefficientData,
            pressureCount,
            temperatureCount,
            temperatureCelsius);
    }
    if (status && !(status & QD_ERROR_CODE_FUNCTION_MASK))
        status |= QD_LOCUS_CALCULATE_P_AND_T;                                   // 0x10000000
    return status;
}                                       // end of FQD_CalculatePressureAndTemperature()
//----------------------------------------------------------------------------
// FQD_CalculatePressureOrTemperature
//
// Returns the pressure in PSI and temperature in Cesius for the specified
// transducer, given the transducer coefficients and the counts
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    Commented code shows how to calculate values based on alternate
//          units
//
// D11813 B1 section 3.11
//----------------------------------------------------------------------------
    DWORD
FQD_CalculatePressureOrTemperature(
    BYTE            PorT,
    LPBYTE          coefficientData,
    DWORD           pressureCount,
    DWORD           temperatureCount,
    DOUBLE          *result)
{
    bool            negative = false;
//    int             alternateOffset;
//    int             alternateOffsetOffset;
    int             coefficientOffset;
    int             lowByte1;
    int             lowByte2;
    int             N1;
    int             N2;
    int             numberOfCoefficients;
    int             scaleFactorOffset;
//    int             alternateScaleOffset;
    long            aggregate;
    long            Temp;
    long            Zint = 0;
//    DWORD           alternateScale;
    DWORD           coefficient[QD_MAXIMUM_NUMBER_OF_COEFFICIENTS];
    DWORD           multiplierHigh;
    DWORD           multiplierLow;
    DWORD           scaleFactor;
    DWORD           pressureCountHigh = (pressureCount >> 16) & 0x0000FFFF;
    DWORD           pressureCountLow = pressureCount & 0x0000FFFF;
    DWORD           temperatureCountHigh = (temperatureCount >> 16) & 0x0000FFFF;
    DWORD           temperatureCountLow = temperatureCount & 0x0000FFFF;
    float           Zout = 0.0;
    float           *pScaleFactor = (float *) &scaleFactor;
    DWORD           status = QD_SUCCESS;
    DWORD           locus = QD_LOCUS_CALCULATE_P_OR_T;                          // 0x11000000
    //------------------------------------------------------------------------
    if (coefficientData && result)
    {
        *result = 0.0;
        if (*coefficientData == QD_QUARTZDYNE_ID)                               // 0x0D
        {
            if (PorT == QD_CALCULATE_PRESSURE_PSI)                              // 0
            {
                locus = QD_LOCUS_CALCULATE_P_OR_T_3;                            // 0x11030000
                //------------------------------------------------------------
                // Retrieve the pressure calculation values and offsets
                //------------------------------------------------------------
                N1 = coefficientData[0x1A];     // pressure fit order X1
                N2 = coefficientData[0x1B];     // temperature fit order X2
                scaleFactorOffset = 0x1C;
//                alternateScaleOffset = 0x20;
//                alternateOffsetOffset = 0x24;
                coefficientOffset = 0x28;
            }
            else
            {
                locus = QD_LOCUS_CALCULATE_P_OR_T_4;                            // 0x11040000
                //------------------------------------------------------------
                // Retrieve the temperature calculation values and offsets
                //------------------------------------------------------------
                N1 = coefficientData[0x8E];     // pressure fit order X1
                N2 = coefficientData[0x8F];     // temperature fit order X2
                scaleFactorOffset = 0x90;
//                alternateScaleOffset = 0x94;
//                alternateOffsetOffset = 0x98;
                coefficientOffset = 0x9C;
            }
            scaleFactor =
                (coefficientData[scaleFactorOffset] << 24) |
                (coefficientData[scaleFactorOffset + 1] << 16) |
                (coefficientData[scaleFactorOffset + 2] << 8) |
                (coefficientData[scaleFactorOffset + 3]);
            //----------------------------------------------------------------
            // The following are provided for an alternate units (Fahrenheit
            // or bar) value and its offset calculation
            //----------------------------------------------------------------
//            alternateScale =
//                (coefficientData[alternateScaleOffset] << 24) |
//                (coefficientData[alternateScaleOffset + 1] << 16) |
//                (coefficientData[alternateScaleOffset + 2] << 8) |
//                (coefficientData[alternateScaleOffset + 3]);
//            alternateOffset =
//                (coefficientData[alternateOffsetOffset] << 24) |
//                (coefficientData[alternateOffsetOffset + 1] << 16) |
//                (coefficientData[alternateOffsetOffset + 2] << 8) |
//                (coefficientData[alternateOffsetOffset + 3]);
            numberOfCoefficients = ((N1 + 1) * (N2 + 1)) - 1;
            for (int index = 0; index <= numberOfCoefficients; index++)
            {
                coefficient[index] =
                    (coefficientData[coefficientOffset + (index * 4)] << 24) |
                    (coefficientData[coefficientOffset + (index * 4) + 1] << 16) |
                    (coefficientData[coefficientOffset + (index * 4) + 2] << 8) |
                    (coefficientData[coefficientOffset + (index * 4) + 3]);
            }
            //----------------------------------------------------------------
            // The published pseudocode for the floating-point interpretation
            // of the transducer pressure count value includes the following:
            //
            //      Zint = (Zint X pressureCount) >> 24
            //
            // This calculation can result in an overflow condition if Zint is
            // a long integer, and the multiplication should be performed
            // using integer, not floating-point, operations. So, perform the
            // integer multiplication in pieces and add the results, to
            // prevent overflow.
            //----------------------------------------------------------------
            for (int fit1 = 0; fit1 <= N1; fit1++)
            {
                //------------------------------------------------------------
                // The sign of Zint must be preserved, so do not mask off the
                // high-order bit following the shift
                //------------------------------------------------------------
                multiplierHigh = Zint >> 16;
                multiplierLow = Zint & 0x0000FFFF;
                //------------------------------------------------------------
                // Remove the least significant bits
                //------------------------------------------------------------
                Zint = (pressureCountLow * multiplierLow) >> 16;
                //------------------------------------------------------------
                // Overflow is not possible in the following
                //------------------------------------------------------------
                Zint += pressureCountLow * multiplierHigh;
                //------------------------------------------------------------
                // Overflow is likely in the subsequent addition
                // (lowByte1 + lowByte2), so first save (carry) the least
                // significant bits before shifting them out
                //------------------------------------------------------------
                lowByte1 = (int) (Zint & 0x000000FF);
                Zint >>= 8;
                aggregate = pressureCountHigh * multiplierLow;
                lowByte2 = (int) (aggregate & 0x000000FF);
                if ((lowByte1 + lowByte2) > 0xFF)
                    Zint++;
                aggregate >>= 8;
                Zint += aggregate;
                Zint += ((pressureCountHigh * multiplierHigh) << 8);
                //------------------------------------------------------------
                // The same applies to the floating-point interpretation of
                // the temperature count value, so perform that multiplication
                // in pieces as well
                //------------------------------------------------------------
                Temp = 0;
                for (int fit2 = 0; fit2 <= N2; fit2++)
                {
                    //--------------------------------------------------------
                    // If Temp goes negative, save the sign, twos-complement
                    // Temp, then twos-complement the result later
                    //--------------------------------------------------------
                    if (Temp < 0)
                    {
                        negative = true;
                        Temp = -Temp;
                    }
                    else
                        negative = false;
                    //--------------------------------------------------------
                    // The sign of Temp must be preserved, so do not mask off
                    // the high-order bit following the shift
                    //--------------------------------------------------------
                    multiplierHigh = Temp >> 16;
                    multiplierLow = Temp & 0x0000FFFF;
                    //--------------------------------------------------------
                    // Remove the least significant bits
                    //--------------------------------------------------------
                    Temp = (temperatureCountLow * multiplierLow) >> 16;
                    //--------------------------------------------------------
                    // Overflow is not possible in the following
                    //--------------------------------------------------------
                    Temp += (temperatureCountLow * multiplierHigh);
                    //--------------------------------------------------------
                    // Overflow is likely in the subsequent addition
                    // (lowByte1 + lowByte2), so first save (carry) the least
                    // significant bits before shifting them out
                    //--------------------------------------------------------
                    lowByte1 = (int) (Temp & 0x000000FF);
                    Temp >>= 8;
                    aggregate = temperatureCountHigh * multiplierLow;
                    lowByte2 = (int) (aggregate & 0x000000FF);
                    if ((lowByte1 + lowByte2) > 0xFF)
                        Temp++;
                    aggregate >>= 8;
                    Temp += aggregate;
                    Temp += ((temperatureCountHigh * multiplierHigh) << 8);
                    //--------------------------------------------------------
                    // Restore the negative sign if needed
                    //--------------------------------------------------------
                    if (negative)
                        Temp = -Temp;
                    Temp += coefficient[numberOfCoefficients--];
                }                       // end of for (int fit2 = 0, Temp = 0; ...)
                Zint += Temp;
            }                           // end of for (int fit1 = 0; ...)
            Zout = Zint * (*pScaleFactor);
            *result = (DOUBLE) Zout;
        }                               // end of if (*coefficientData == QD_QUARTZDYNE_ID)
        else
        {
            locus = QD_LOCUS_CALCULATE_P_OR_T_2;                                // 0x11020000
            status = QD_ERROR_INVALID_COEFFICIENT_DATA;                         // 0x00000040
        }
    }                                   // end of if (coefficientData && result)
    else
    {
        locus = QD_LOCUS_CALCULATE_P_OR_T_1;                                    // 0x11010000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_CalculatePressureOrTemperature()
//----------------------------------------------------------------------------
// FQD_CheckReceiveQueue
//
// Returns the number of response bytes in, and the status of, the Receive
// Queue (see FQD_WaitForReply)
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.7
//----------------------------------------------------------------------------
    DWORD
FQD_CheckReceiveQueue(
    HANDLE          unitHandle,
    LPDWORD         numberOfBytesInQueue,
    LPDWORD         queueStatus)
{
    DWORD           status = QD_SUCCESS;
    DWORD           locus = QD_LOCUS_CHECK_RECEIVE_QUEUE;                       // 0x12000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_CHECK_RECEIVE_QUEUE_1;                                 // 0x12010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (numberOfBytesInQueue && queueStatus)
    {
        *numberOfBytesInQueue = 0;
        *queueStatus = 0;
        //--------------------------------------------------------------------
        // Silicon Labs AN169 Rev. 1.8 section 2.10 : SI_CheckRXQueue
        //--------------------------------------------------------------------
        status = (DWORD) SI_CheckRXQueue(
            unitHandle,
            numberOfBytesInQueue,
            queueStatus);
    }                                   // end of if (numberOfBytesInQueue && queueStatus)
    else
    {
        if (!numberOfBytesInQueue && !queueStatus)
        {
            //----------------------------------------------------------------
            // Both pointers are null
            //----------------------------------------------------------------
            locus = QD_LOCUS_CHECK_RECEIVE_QUEUE_2;                             // 0x12020000
        }
        else
        {
            if (numberOfBytesInQueue)
            {
                //------------------------------------------------------------
                // queueStatus is null
                //------------------------------------------------------------
                locus = QD_LOCUS_CHECK_RECEIVE_QUEUE_3;                         // 0x12030000
            }
            else
            {
                //------------------------------------------------------------
                // numberOfBytesInQueue is null
                //------------------------------------------------------------
                locus = QD_LOCUS_CHECK_RECEIVE_QUEUE_4;                         // 0x12040000
            }
        }
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_CheckReceiveQueue()
//----------------------------------------------------------------------------
// FQD_ClearInternalError
//
// Clears the specified module internal error register
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B3 section 3.31
//----------------------------------------------------------------------------
    DWORD
FQD_ClearInternalError(
    HANDLE          unitHandle)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 1;
    DWORD           status;
    DWORD           locus = QD_LOCUS_CLEAR_INTERNAL_ERROR;                      // 0x13000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_CLEAR_INTERNAL_ERROR_1;                                // 0x13010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    while (attempts--)
    {
        ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                           // 16
        //--------------------------------------------------------------------
        // HX0D16 B0 section 3.19: Clear Error
        //--------------------------------------------------------------------
        command[0] = QD_CMD_CLEAR_ERROR;                                        // 0x1C
        status = FQD_Write(
            unitHandle,
            (LPBYTE) command,
            numberOfCommandBytes,
            (LPDWORD) &bytesTransmitted);
        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
        {
            attempts = 0;
        }
        else
        {
            if (attempts)
            {
                Sleep(100);
            }
            else
            {
                locus = QD_LOCUS_CLEAR_INTERNAL_ERROR_2;                        // 0x13020000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
        }
    }                                   // end of while (attempts--)
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_ClearInternalError()
//----------------------------------------------------------------------------
// FQD_Close
//
// Closes the handle of the associated device unit
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0, B1 section 3.4
//----------------------------------------------------------------------------
    DWORD
FQD_Close(
    HANDLE          unitHandle)
{
    DWORD           status = QD_SUCCESS;
    DWORD           locus = QD_LOCUS_CLOSE;                                     // 0x14000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_CLOSE_1;                                               // 0x14010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    //------------------------------------------------------------------------
    // Silicon Labs AN169 Rev. 1.8 section 2.4 : SI_Close
    //------------------------------------------------------------------------
    status = (DWORD) SI_Close(unitHandle);
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_Close()
//----------------------------------------------------------------------------
// FQD_CoefficientDataIsValid
//
// Determines whether the specified coefficient data is valid
//
// D11813 B1 section 3.36
//
// Confirmed identical to 1.0.8
//----------------------------------------------------------------------------
    bool
FQD_CoefficientDataIsValid(
    LPBYTE          coefficientData)
{
    char            *data = (char *) coefficientData;
    bool            dataIsValid = true;         // innocent until proven guilty
    CoefficientFormatDef
                    *format = (CoefficientFormatDef *) coefficientData;
    BYTE            checksum;
    //------------------------------------------------------------------------
    if (!coefficientData)
    {
Modal("BP 1 : Pointer is bad");
        return false;
    }
    //------------------------------------------------------------------------
    // Must start with the Quartzdyne ID and acceptable file types
    //------------------------------------------------------------------------
    if ((format->fileType != QD_QUARTZDYNE_CF_TYPE_BIG_ENDIAN) &&               // 0x010D
        (format->fileType != QD_QUARTZDYNE_CF_TYPE_LITTLE_ENDIAN))              // 0x040D
    {
Modal("BP 2 : Bad file type {0:X4}", format->fileType);
        return false;
    }
    //------------------------------------------------------------------------
    // These are the only acceptable file versions
    //------------------------------------------------------------------------
    if ((format->fileVersion != QD_QUARTZDYNE_CF_VERSION_123) &&                // 0x2301
        (format->fileVersion != QD_QUARTZDYNE_CF_VERSION_100))                  // 0x00000001
    {
Modal("BP 3 : Bad file version {0:X4}", format->fileVersion);
        return false;
    }
    //------------------------------------------------------------------------
    // The serial number must also contain the Quartzdyne ID
    //------------------------------------------------------------------------
    if (((format->serialNumber & 0x000000FF) != QD_QUARTZDYNE_ID) ||            // 0x0D
        (!(format->serialNumber & 0xFFFFFF00)))
    {
Modal("BP 4 : Invalid serial number {0:X8}", format->serialNumber);
        return false;
    }
    switch (format->calibrationMonth)
    {
        //--------------------------------------------------------------------
        // All possible months in BCD
        //--------------------------------------------------------------------
        case 0x01 :     case 0x02 :     case 0x03 :     case 0x04 :
        case 0x05 :     case 0x06 :     case 0x07 :     case 0x08 :
        case 0x09 :     case 0x10 :     case 0x11 :     case 0x12 :
            break;
        default :
Modal("BP 5 : Invalid month {0:X2}", format->calibrationMonth);
            return false;
    }
    switch (format->calibrationDate)
    {
        //--------------------------------------------------------------------
        // All possible days-of-the-month in BCD
        //--------------------------------------------------------------------
        case 0x01 :     case 0x02 :     case 0x03 :     case 0x04 :
        case 0x05 :     case 0x06 :     case 0x07 :     case 0x08 :
        case 0x09 :     case 0x10 :     case 0x11 :     case 0x12 :
        case 0x13 :     case 0x14 :     case 0x15 :     case 0x16 :
        case 0x17 :     case 0x18 :     case 0x19 :     case 0x20 :
        case 0x21 :     case 0x22 :     case 0x23 :     case 0x24 :
        case 0x25 :     case 0x26 :     case 0x27 :     case 0x28 :
        case 0x29 :     case 0x30 :     case 0x31 :
            switch (format->calibrationMonth)
            {
                //------------------------------------------------------------
                // Months that have 30 days
                //------------------------------------------------------------
                case 0x04 :     case 0x06 :     case 0x09 :     case 0x11 :
                    if (format->calibrationDate > 0x30)
                    {
Modal("BP 6 : Invalid date {0:X2}", format->calibrationDate);
                        return false;
                    }
                    break;
                //------------------------------------------------------------
                // February - no effort made to determine leap years, etc.
                //------------------------------------------------------------
                case 0x02 :
                    if (format->calibrationDate > 0x29)
                    {
Modal("BP 7 : Invalid date {0:X2}", format->calibrationDate);
                        return false;
                    }
                    break;
                //------------------------------------------------------------
                // The remaining months have 31 days
                //------------------------------------------------------------
                default :
                    break;
            }
            break;
        default :
Modal("BP 8 : Invalid date {0:X2}", format->calibrationDate);
            return false;
    }                                   // end of switch (format->calibrationDate)
    //------------------------------------------------------------------------
    // The century number in BCD - this is only good for 200 years
    //------------------------------------------------------------------------
    if (((format->calibrationYear & 0x00FF) != 0x19) && ((format->calibrationYear & 0x00FF) != 0x20))
    {
Modal("BP 9 : Invalid year {0:X4}", format->calibrationYear);
        return false;
    }
    if ((format->calibration1Type != 0x01) && (format->calibration1Type != 0x02))
    {
Modal("BP 10 : Invalid calibration type {0:X2}", format->calibration1Type);
        return false;
    }
    if ((format->calibration2Type != 0x01) && (format->calibration2Type != 0x02))
    {
Modal("BP 11 : Invalid calibration type {0:X2}", format->calibration2Type);
        return false;
    }
    //------------------------------------------------------------------------
    // End-of-file marker must be present
    //------------------------------------------------------------------------
    if ((*((DWORD *) format->endOfFile) & 0x00FFFFFF) != 0x0000FF)
    {
Modal("BP 12 : Invalid hex file marker");
        return false;
    }
    //------------------------------------------------------------------------
    // Calculate the checksum
    //------------------------------------------------------------------------
    for (int offset = checksum = 0; offset < QD_COEFFICIENT_DATA_SIZE; offset++)
    {
        checksum += (BYTE) data[offset];
    }
    if (checksum)
    {
Modal("BP 13 : Invalid checksum");
        return false;
    }
    return dataIsValid;
}                                       // end of FQD_CoefficientDataIsValid()
//----------------------------------------------------------------------------
// FQD_CoefficientHexFileDataIsValid
//
// Determines whether the specified hex file data is valid by first verifying
// whether the file data is in valid Intel Hex File Data format, then whether
// it contains appropriate coefficient data
//
// D11813 B1 section 3.37
//
// Confirmed identical to 1.0.8
//----------------------------------------------------------------------------
    bool
FQD_CoefficientHexFileDataIsValid(
    LPBYTE          hexFileData)
{
    bool            dataIsValid;
    int             address;
    int             recordLength;
    int             recordType = 0;
    char            *hexFileLine = (char *) hexFileData;
    //------------------------------------------------------------------------
    dataIsValid = FQD_HexFileFormatIsValid(hexFileData);                        // verified
    if (dataIsValid)
    {
        while ((hexFileLine[0] == ':') && (recordType != 0x01) && dataIsValid)
        {
            address =
                ((AtoX(hexFileLine[3]) << 12) & 0xF000) | ((AtoX(hexFileLine[4]) << 8) & 0x0F00) |
                ((AtoX(hexFileLine[5]) << 4) & 0x00F0) | (AtoX(hexFileLine[6]) & 0x000F);
            recordLength =
                ((AtoX(hexFileLine[1]) << 4) & 0xF0) | (AtoX(hexFileLine[2]) & 0x0F);
            recordType =
                ((AtoX(hexFileLine[7]) << 4) & 0xF0) | (AtoX(hexFileLine[8]) & 0x0F);
            if (address > 0x00F0)
            {
                //------------------------------------------------------------
                // The highest coefficient data starting address must not be
                // higher than 0x00F0
                //------------------------------------------------------------
                dataIsValid = false;
            }
            if (recordType != 0x01)
            {
                hexFileLine = &hexFileLine[(recordLength * 2) + 13];
            }
        }                               // end of while ((hexFileLine[0] == ':') ...)
        if (dataIsValid)
        {
            LPBYTE coefficientData = (LPBYTE) malloc(QD_COEFFICIENT_DATA_SIZE); // 256
            if (coefficientData)
            {
                ClearBuffer(coefficientData, QD_COEFFICIENT_DATA_SIZE);         // 256
                DWORD numberOfDataBytes = FQD_UnFormatHexFileData(              // verified
                    hexFileData,
                    coefficientData);
                if (numberOfDataBytes == QD_COEFFICIENT_DATA_SIZE)
                {
                    dataIsValid = FQD_CoefficientDataIsValid(coefficientData);  // verified
                }                       // end of if (numberOfDataBytes == QD_COEFFICIENT_DATA_SIZE)
                else
                {
                    dataIsValid = false;
                }
                free((void *) coefficientData);
            }
            else
            {
                dataIsValid = false;
            }
        }                               // end of if (dataIsValid)
    }
    return dataIsValid;
}                                       // end of FQD_CoefficientHexFileDataIsValid()
//----------------------------------------------------------------------------
// FQD_DataIsInHexFileFormat
//
// Determines whether the specified data generally complies with the Intel Hex
// File Format, but does not make a determination on whether the data is valid
//
// D11813 B1 section 3.38
//
// Confirmed identical to 1.0.8
//----------------------------------------------------------------------------
    bool
FQD_DataIsInHexFileFormat(
    LPBYTE          hexFileData)
{
    int             recordLength;
    int             recordType = 0;
    char            *hexFileLine = (char *) hexFileData;
    bool            inHexFileFormat = false;
    //------------------------------------------------------------------------
    if (hexFileLine && strlen((char *) hexFileData))
    {
        if (_strnicmp(strrchr(hexFileLine, ':'), ":00000001FF", 11) == 0)
            inHexFileFormat = true;
        while ((hexFileLine[0] == ':') && (recordType != 0x01) && inHexFileFormat)
        {
            recordLength =
                ((AtoX(hexFileLine[1]) << 4) & 0xF0) | (AtoX(hexFileLine[2]) & 0x0F);
            recordType =
                ((AtoX(hexFileLine[7]) << 4) & 0xF0) | (AtoX(hexFileLine[8]) & 0x0F);
            if (recordType != 0x01)
               hexFileLine = &hexFileLine[(recordLength * 2) + 13];
            if (hexFileLine[0] != ':')
                inHexFileFormat = false;
        }
    }
    return inHexFileFormat;
}                                       // end of FQD_DataIsInHexFileFormat()
//----------------------------------------------------------------------------
// FQD_EraseFirmwarePage
//
// Erases the firmware data from the specified page of the module
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.39
//----------------------------------------------------------------------------
    DWORD
FQD_EraseFirmwarePage(
    HANDLE          unitHandle,
    BYTE            pageNumber)
{
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 1;
    DWORD           status;
    DWORD           locus = QD_LOCUS_ERASE_FIRMWARE_PAGE;                       // 0x15000000
    //------------------------------------------------------------------------
    status = FQD_SetFirmwarePage(unitHandle, pageNumber);
    if (status == QD_SUCCESS)
    {
        ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                           // 16
        //--------------------------------------------------------------------
        // HX0D16 B0 section 3.??: Erase Current Page
        //--------------------------------------------------------------------
        command[0] = QD_CMD_ERASE_CURRENT_PAGE;                                 // 0x02
        status = FQD_Write(
            unitHandle,
            (LPBYTE) command,
            numberOfCommandBytes,
            (LPDWORD) &bytesTransmitted);
        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
        {
            status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
            if (status == QD_SUCCESS)
            {
                //------------------------------------------------------------
                // Retrieve the command status
                //------------------------------------------------------------
                command[0] = QD_STATUS_INITIALIZE;                              // 0x01
                status = FQD_Read(
                    unitHandle,
                    (LPBYTE) command,
                    numberOfCommandBytes,
                    (LPDWORD) &bytesTransmitted);
                if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                {
                    if (command[0] != QD_STATUS_SUCCESS)                        // 0x00
                    {
                        locus = QD_LOCUS_ERASE_FIRMWARE_PAGE_4;                 // 0x15040000
                        status = QD_ERROR_WRITE_ACKNOWLEDGE_FAILED;             // 0x00000028
                    }
                }
                else
                {
                    locus = QD_LOCUS_ERASE_FIRMWARE_PAGE_3;                     // 0x15030000
                    status = VerifyI2CTransfer(
                        status, bytesTransmitted, numberOfCommandBytes);
                }
            }
            else
            {
                locus = QD_LOCUS_ERASE_FIRMWARE_PAGE_2;                         // 0x15020000
            }
        }
        else
        {
            locus = QD_LOCUS_ERASE_FIRMWARE_PAGE_1;                             // 0x15010000
            status = VerifyI2CTransfer(
                status, bytesTransmitted, numberOfCommandBytes);
        }
        if (status)
            status |= locus;
    }                                   // end of if (status == QD_SUCCESS)
    return status;
}                                       // end of FQD_EraseFirmwarePage()
//----------------------------------------------------------------------------
// FQD_ExecuteI2CCommand
//
// Sends an appropriately formed I2C command to the device unit
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    replyString must point to QD_MAXIMUM_TRANSFER_SIZE (768) bytes of
//          available memory
//
// D11813 B1 section 3.16
//----------------------------------------------------------------------------
    DWORD
FQD_ExecuteI2CCommand(
    HANDLE          unitHandle,
    LPBYTE          commandString,
    LPBYTE          replyString)
{
    bool            stopCharacterFound = false;
    int             attempts = 3;
    int             commandStringLength = strlen((char *) commandString);
    int             stringLengthSoFar = 0;
    char            *commandStringCopy;
    char            *transferBuffer;
    DWORD           bytesTransmitted;
    DWORD           numberOfCommandBytes;
    DWORD           status = QD_SUCCESS;
    DWORD           locus = QD_LOCUS_EXECUTE_I2C_COMMAND;                       // 0x16000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_EXECUTE_I2C_COMMAND_1;                                 // 0x16010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (commandString && replyString && commandStringLength)
    {
        transferBuffer = (char *) malloc(QD_MAXIMUM_TRANSFER_SIZE * 2);         // 768 X 2
        if (transferBuffer)
        {
            ClearBuffer(transferBuffer, (QD_MAXIMUM_TRANSFER_SIZE * 2));
            ClearBuffer(replyString, QD_MAXIMUM_TRANSFER_SIZE);                 // 768
            //----------------------------------------------------------------
            // Locate the command termination character after changing only the
            // command characters to uppercase
            //----------------------------------------------------------------
            commandStringCopy = transferBuffer + QD_MAXIMUM_TRANSFER_SIZE;
            do
            {
                commandStringCopy[stringLengthSoFar] =
                    toupper(commandString[stringLengthSoFar]);
                if (commandStringCopy[stringLengthSoFar++] == 'P')
                    stopCharacterFound = true;
            }
            while ((stringLengthSoFar < commandStringLength) && !stopCharacterFound);
            if (stopCharacterFound && (commandStringLength < QD_MAXIMUM_TRANSFER_SIZE))
            {
                while (attempts--)
                {
                    //--------------------------------------------------------
                    // Flush buffers ahead of the Read command
                    //--------------------------------------------------------
                    FQD_FlushAllBuffers(unitHandle);
                    ClearBuffer(transferBuffer, QD_MAXIMUM_TRANSFER_SIZE);      // 768 X 2
                    //--------------------------------------------------------
                    // HX0D16 B0 section 3.11: Send I2C Command
                    //--------------------------------------------------------
                    transferBuffer[0] = QD_CMD_SEND_I2C_COMMAND;                // 0x14
                    transferBuffer[1] = (BYTE) ((commandStringLength - 1) / QD_PACKET_SIZE) + 1;
                    numberOfCommandBytes = 2;
                    status = FQD_Write(
                        unitHandle,
                        (LPBYTE) transferBuffer,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        memcpy(transferBuffer, commandStringCopy, commandStringLength);
                        numberOfCommandBytes = commandStringLength;
                        status = FQD_Write(
                            unitHandle,
                            (LPBYTE) transferBuffer,
                            numberOfCommandBytes,
                            (LPDWORD) &bytesTransmitted);
                        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                        {
                            numberOfCommandBytes = QD_MAXIMUM_TRANSFER_SIZE;
                            status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                            if (status == QD_SUCCESS)
                            {
                                status = FQD_Read(
                                    unitHandle,
                                    (LPBYTE) transferBuffer,
                                    numberOfCommandBytes,
                                    (LPDWORD) &bytesTransmitted);
                                if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                                {
                                    memcpy(replyString, transferBuffer, QD_MAXIMUM_TRANSFER_SIZE);
                                }
                                else
                                {
                                    locus = QD_LOCUS_EXECUTE_I2C_COMMAND_A;     // 0x160A0000
                                    status = VerifyI2CTransfer(
                                        status, bytesTransmitted, numberOfCommandBytes);
                                }
                            }
                            else
                            {
                                locus = QD_LOCUS_EXECUTE_I2C_COMMAND_9;         // 0x16090000
                            }
                        }
                        else
                        {
                            locus = QD_LOCUS_EXECUTE_I2C_COMMAND_8;             // 0x16080000
                            status = VerifyI2CTransfer(
                                status, bytesTransmitted, numberOfCommandBytes);
                        }
                    }
                    else
                    {
                        locus = QD_LOCUS_EXECUTE_I2C_COMMAND_7;                 // 0x16070000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                    if (status == QD_SUCCESS)
                    {
                        attempts = 0;
                    }
                    else
                    {
                        if (attempts)
                        {
                            Sleep(100);
                        }
                    }
                }                       // end of while (attempts--)
            }                           // end of if (stopCharacterFound && ...)
            free((void *) transferBuffer);
        }                               // end of if (transferBuffer)
        else
        {
            locus = QD_LOCUS_EXECUTE_I2C_COMMAND_6;                             // 0x16060000
            status = QD_ERROR_MEMORY_ALLOCATION_FAILED;                         // 0x00000014
        }
    }                                   // end of if (commandString && replyString && commandStringLength)
    else
    {
        //--------------------------------------------------------------------
        // One of the input pointers has a problem
        //--------------------------------------------------------------------
        if (commandString && replyString)
        {
            //----------------------------------------------------------------
            // commandString points to zero-length data
            //----------------------------------------------------------------
            locus = QD_LOCUS_EXECUTE_I2C_COMMAND_5;                             // 0x16050000
            status = QD_ERROR_ZERO_LENGTH_STRING_PARAMETER;                     // 0x0000002B
        }
        else
        {
            if (!commandString && !replyString)
            {
                //------------------------------------------------------------
                // Both pointers are null
                //------------------------------------------------------------
                locus = QD_LOCUS_EXECUTE_I2C_COMMAND_2;                         // 0x16020000
            }
            else
            {
                if (commandString)
                {
                    //--------------------------------------------------------
                    // replyString is null
                    //--------------------------------------------------------
                    locus = QD_LOCUS_EXECUTE_I2C_COMMAND_3;                     // 0x16030000
                }
                else
                {
                    //--------------------------------------------------------
                    // commandString is null
                    //--------------------------------------------------------
                    locus = QD_LOCUS_EXECUTE_I2C_COMMAND_4;                     // 0x16040000
                }
            }
            status = QD_ERROR_NULL_POINTER_PARAMETER;                           // 0x0000002A
        }
    }                                   // end of else of if (commandString && replyString && commandStringLength)
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_ExecuteI2CCommand()
//----------------------------------------------------------------------------
// FQD_FirmwareHexFileDataIsValid
//
// Determines whether the specified hex file data is valid by first verifying
// whether the file data is in valid Intel Hex File Data format, then whether
// it contains appropriate firmware data
//
// D11813 B1 section 3.40
//----------------------------------------------------------------------------
    bool
FQD_FirmwareHexFileDataIsValid(
    LPBYTE          hexFileData)
{
    bool            dataIsValid;
    bool            firmwareAddressFound = false;
    int             address;
    int             recordLength;
    int             recordType = 0;
    char            *hexFileLine = (char *) hexFileData;
    //------------------------------------------------------------------------
    dataIsValid = FQD_HexFileFormatIsValid(hexFileData);
    if (dataIsValid)
    {
        while ((hexFileLine[0] == ':') && (recordType != 0x01) && dataIsValid)
        {
            address =
                ((AtoX(hexFileLine[3]) << 12) & 0xF000) | ((AtoX(hexFileLine[4]) << 8) & 0x0F00) |
                ((AtoX(hexFileLine[5]) << 4) & 0x00F0) | (AtoX(hexFileLine[6]) & 0x000F);
            recordLength =
                ((AtoX(hexFileLine[1]) << 4) & 0xF0) | (AtoX(hexFileLine[2]) & 0x0F);
            recordType =
                ((AtoX(hexFileLine[7]) << 4) & 0xF0) | (AtoX(hexFileLine[8]) & 0x0F);
            if (address == ((QD_FIRMWARE_LAST_PAGE_C8051F320 + 1) * QD_FIRMWARE_PAGE_SIZE) - 5)
            {
                //------------------------------------------------------------
                // The file must contain the Device ID address
                //------------------------------------------------------------
                firmwareAddressFound = true;
            }
            if (recordType != 0x01)
            {
                hexFileLine = &hexFileLine[(recordLength * 2) + 13];
            }
        }                               // end of while ((hexFileLine[0] == ':') ...)
        if (!firmwareAddressFound)
            dataIsValid = false;
    }
    return dataIsValid;
}                                       // end of FQD_FirmwareHexFileDataIsValid()
//----------------------------------------------------------------------------
// FQD_FlushBuffers
//
// Flushes the specified buffer(s) to the respective device unit
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0, B1 section 3.8
//----------------------------------------------------------------------------
    DWORD
FQD_FlushBuffers(
    HANDLE          unitHandle,
    BYTE            flushTransmitBuffer,
    BYTE            flushReceiveBuffer)
{
    DWORD           status = QD_SUCCESS;
    DWORD           locus = QD_LOCUS_FLUSH_BUFFERS;                             // 0x17000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_FLUSH_BUFFERS_1;                                       // 0x17010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (flushTransmitBuffer || flushReceiveBuffer)
    {
        //--------------------------------------------------------------------
        // Silicon Labs AN169 Rev. 1.8 section 2.7 : SI_FlushBuffers
        //--------------------------------------------------------------------
        status = (DWORD) SI_FlushBuffers(
            unitHandle,
            flushTransmitBuffer,
            flushReceiveBuffer);
    }
    else
    {
        //--------------------------------------------------------------------
        // Both parameters are zero
        //--------------------------------------------------------------------
        locus = QD_LOCUS_FLUSH_BUFFERS_2;                                       // 0x17020000
        status = QD_ERROR_INVALID_PARAMETER;                                    // 0x00000006
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_FlushBuffers()
//----------------------------------------------------------------------------
// FQD_FormatCoefficientHexFileData
//
// Formats the specified data string into a hex file data format, limiting
// each line to 16 hex bytes of data (32 characters), and returns the number
// of formatted data bytes, which must be QD_COEFFICIENT_DATA_HEX_FILE_SIZE
// (733) bytes
//
// Returns the number of bytes in the formatted string
//
// Note:    unformattedData must point to a NULL-terminated string
//
// Note:    formattedData must point to at least
//          QD_COEFFICIENT_DATA_HEX_FILE_SIZE + 1 (734) bytes of allocated
//          memory (an extra one for the null character)
//
// D11813 B1 section 3.41
//
// Confirmed identical to 1.0.8
//----------------------------------------------------------------------------
    DWORD
FQD_FormatCoefficientHexFileData(
    LPBYTE          unformattedData,
    LPBYTE          formattedData)
{
    int             dataRunSize;
    int             length = QD_COEFFICIENT_DATA_SIZE;                          // 256
    int             lineNumber = 0;
    unsigned        checksum;
    char            *dataAfter = (char *) formattedData;
    char            *dataBefore = (char *) unformattedData;
    char            *beginningOfFormattedData = dataAfter;
    char            *line;
    //------------------------------------------------------------------------
    if (unformattedData && formattedData && strlen(dataBefore))
    {
        ClearBuffer(dataAfter, QD_COEFFICIENT_DATA_HEX_FILE_SIZE + 1);          // 734
        if (!(length % 2))
        {
            while (length)
            {
                line = dataAfter + 1;
                memcpy(dataAfter, ":10000000", 9);
                dataAfter += 5;
                *dataAfter = XtoA(lineNumber);
                dataAfter += 4;
                dataRunSize = ((length >= 16) ? 16 : length);
                for (int byteOffset = 0; byteOffset < dataRunSize; byteOffset++)
                {
                    *dataAfter++ = XtoA((*dataBefore) >> 4);
                    *dataAfter++ = XtoA(*dataBefore);
                    dataBefore++;
                }
                length -= dataRunSize;
                lineNumber++;
                dataRunSize = (dataRunSize * 2) + 8;
                checksum = 0;
                while (dataRunSize)
                {
                    checksum += (AtoX(*line) << 4) | AtoX(*(line + 1));
                    line += 2;
                    dataRunSize -= 2;
                }
                checksum = (~checksum + 1) & 0xFF;
                *dataAfter++ = XtoA(checksum >> 4);
                *dataAfter++ = XtoA(checksum);
                *dataAfter++ = QD_CR_CHAR;
                *dataAfter++ = QD_LF_CHAR;
            }
        }
        memcpy(dataAfter, ":00000001FF", 11);
        dataAfter += 11;
        *dataAfter++ = QD_CR_CHAR;
        *dataAfter++ = QD_LF_CHAR;
    }                                   // end of if (unformattedData && formattedData && strlen(dataBefore))
    return (DWORD) strlen(beginningOfFormattedData);
}                                       // end of FQD_FormatCoefficientHexFileData()
//----------------------------------------------------------------------------
// FQD_GetCadenceTimer
//
// Retrieves the cadence timer used to acquire transducer counts
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.26
//----------------------------------------------------------------------------
    DWORD
FQD_GetCadenceTimer(
    HANDLE          unitHandle,
    LPDWORD         cadenceTimerValue)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    DWORD           numberOfCommandBytes;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_CADENCE_TIMER;                         // 0x18000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_GET_CADENCE_TIMER_1;                                   // 0x18010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (cadenceTimerValue)
    {
        *cadenceTimerValue = 0;
        while (attempts--)
        {
            //----------------------------------------------------------------
            // Flush buffers ahead of the Read command
            //----------------------------------------------------------------
            FQD_FlushAllBuffers(unitHandle);
            ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                       // 16
            //----------------------------------------------------------------
            // HX0D16 B0 section 3.17: Get Cadence Timer
            //----------------------------------------------------------------
            command[0] = QD_CMD_GET_CADENCE_TIMER;                              // 0x1A
            numberOfCommandBytes = 1;
            status = FQD_Write(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                numberOfCommandBytes = 2;
                status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                if (status == QD_SUCCESS)
                {
                    status = FQD_Read(
                        unitHandle,
                        (LPBYTE) command,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        *cadenceTimerValue = (DWORD) (command[0] << 8 | command[1]);
                    }
                    else
                    {
                        locus = QD_LOCUS_GET_CADENCE_TIMER_5;                   // 0x18050000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }
                else
                {
                    locus = QD_LOCUS_GET_CADENCE_TIMER_4;                       // 0x18040000
                }
            }
            else
            {
                locus = QD_LOCUS_GET_CADENCE_TIMER_3;                           // 0x18030000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
            if ((status == QD_SUCCESS) && *cadenceTimerValue)
            {
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    Sleep(100);
                }
                else
                {
                    if (status == QD_SUCCESS)
                    {
                        if (*cadenceTimerValue == 0)
                        {
                            locus = QD_LOCUS_GET_CADENCE_TIMER_6;               // 0x18060000
                            status = QD_ERROR_CADENCE_TIMER_ZERO;               // 0x0000001C
                        }
                        else
                        {
                            locus = QD_LOCUS_GET_CADENCE_TIMER_7;               // 0x18070000
                            status = QD_ERROR_UNREACHABLE_CONDITION;            // 0x00000029
                        }
                    }
                    else
                    {
                        locus = QD_LOCUS_GET_CADENCE_TIMER_8;                   // 0x18080000
                        *cadenceTimerValue = 0;
                    }
                }
            }
        }                               // end of while (attempts--)
    }                                   // end of if (cadenceTimerValue)
    else
    {
        locus = QD_LOCUS_GET_CADENCE_TIMER_2;                                   // 0x18020000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetCadenceTimer()
//----------------------------------------------------------------------------
// FQD_GetFirmwareCRC
//
// Retrieves the firmware CRC for the specified page of the firmware installed
// in the module
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.42
//----------------------------------------------------------------------------
    DWORD
FQD_GetFirmwareCRC(
    HANDLE          unitHandle,
    BYTE            pageNumber,
    LPWORD          pageCRC)
{
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    DWORD           numberOfCommandBytes;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_FIRMWARE_CRC;                          // 0x19000000
    //------------------------------------------------------------------------
    status = FQD_SetFirmwarePage(unitHandle, pageNumber);
    if (status == QD_SUCCESS)
    {
        if (pageCRC)
        {
            *pageCRC = 0;
            ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                       // 16
            //----------------------------------------------------------------
            // HX0D16 B0 section 3.??: Get Current Page CRC
            //----------------------------------------------------------------
            command[0] = QD_CMD_GET_CURRENT_PAGE_CRC;                           // 0x04
            numberOfCommandBytes = 1;
            status = FQD_Write(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                numberOfCommandBytes = 2;
                status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                if (status == QD_SUCCESS)
                {
                    //--------------------------------------------------------
                    // Retrieve the command status
                    //--------------------------------------------------------
                    status = FQD_Read(
                        unitHandle,
                        (LPBYTE) command,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        *pageCRC = (command[0] << 8) | command[1];
                    }
                    else
                    {
                        locus = QD_LOCUS_GET_FIRMWARE_CRC_4;                    // 0x19040000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }
                else
                {
                    locus = QD_LOCUS_GET_FIRMWARE_CRC_3;                        // 0x19030000
                }
            }
            else
            {
                locus = QD_LOCUS_GET_FIRMWARE_CRC_2;                            // 0x19020000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
        }                               // end of if (pageCRC)
        else
        {
            locus = QD_LOCUS_GET_FIRMWARE_CRC_1;                                // 0x19010000
            status = QD_ERROR_NULL_POINTER_PARAMETER;                           // 0x0000002A
        }
        if (status)
            status |= locus;
    }                                   // end of if (status == QD_SUCCESS)
    return status;
}                                       // end of FQD_GetFirmwareCRC()
//----------------------------------------------------------------------------
// FQD_GetFirmwareDeviceInfo
//
// Retrieves the Device Info from the firmware of the specified module
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    unitInfo must point to at least QD_FIRMWARE_DEVICE_INFO_SIZE (9)
//          bytes of available memory
//
// D11813 B1 section 3.43
//----------------------------------------------------------------------------
    DWORD
FQD_GetFirmwareDeviceInfo(
    HANDLE          unitHandle,
    LPBYTE          unitInfo)
{
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    BYTE            swapByte6;
    BYTE            swapByte7;
    DWORD           bytesTransmitted;
    DWORD           numberOfCommandBytes;
    UnitDeviceInfoDef
                    *deviceInfo = (UnitDeviceInfoDef *) unitInfo;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_FIRMWARE_DEVICE_INFO;                  // 0x1A000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_GET_FIRMWARE_DEVICE_INFO_1;                            // 0x1A010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (unitInfo)
    {
        ClearBuffer(unitInfo, QD_FIRMWARE_DEVICE_INFO_SIZE);                    // 9
        ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                           // 16
        //--------------------------------------------------------------------
        // HX0D16 B0 section 3.??: Get Device Info
        //--------------------------------------------------------------------
        command[0] = QD_CMD_GET_DEVICE_INFO;                                    // 0x00
        numberOfCommandBytes = 1;
        status = FQD_Write(
            unitHandle,
            (LPBYTE) command,
            numberOfCommandBytes,
            (LPDWORD) &bytesTransmitted);
        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
        {
            numberOfCommandBytes = QD_FIRMWARE_DEVICE_INFO_SIZE;                // 9
            status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
            if (status == QD_SUCCESS)
            {
                status = FQD_Read(
                    unitHandle,
                    (LPBYTE) unitInfo,
                    numberOfCommandBytes,
                    (LPDWORD) &bytesTransmitted);
                if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                {
                    //--------------------------------------------------------
                    // Must swap the signature bytes to store it as a WORD for
                    // the _UnitDeviceInfo structure
                    //--------------------------------------------------------
                    swapByte6 = unitInfo[6];
                    swapByte7 = unitInfo[7];
                    unitInfo[6] = swapByte7;
                    unitInfo[7] = swapByte6;
                }
                else
                {
                    locus = QD_LOCUS_GET_FIRMWARE_DEVICE_INFO_5;                // 0x1A050000
                    status = VerifyI2CTransfer(
                        status, bytesTransmitted, numberOfCommandBytes);
                }
            }
            else
            {
                locus = QD_LOCUS_GET_FIRMWARE_DEVICE_INFO_4;                    // 0x1A040000
            }
        }
        else
        {
            locus = QD_LOCUS_GET_FIRMWARE_DEVICE_INFO_3;                        // 0x1A030000
            status = VerifyI2CTransfer(
                status, bytesTransmitted, numberOfCommandBytes);
        }
    }                                   // end of if (unitInfo)
    else
    {
        locus = QD_LOCUS_GET_FIRMWARE_DEVICE_INFO_2;                            // 0x1A020000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetFirmwareDeviceInfo()
//----------------------------------------------------------------------------
// FQD_GetI2CDataRate
//
// Retrieves the specified device unit I2C data rate
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B3 section 3.33
//----------------------------------------------------------------------------
    DWORD
FQD_GetI2CDataRate(
    HANDLE          unitHandle,
    DOUBLE          *currentDataRate)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 1;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_I2C_DATA_RATE;                         // 0x1B000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_GET_I2C_DATA_RATE_1;                                   // 0x1B010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (currentDataRate)
    {
        *currentDataRate = 0.0;
        while (attempts--)
        {
            //----------------------------------------------------------------
            // Flush buffers ahead of the Read command
            //----------------------------------------------------------------
            FQD_FlushAllBuffers(unitHandle);
            ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                       // 16
            //----------------------------------------------------------------
            // HX0D16 B0 section 3.21: Get I2C Data Rate
            //----------------------------------------------------------------
            command[0] = QD_CMD_GET_I2C_DATA_RATE;                              // 0x1E
            status = FQD_Write(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                if (status == QD_SUCCESS)
                {
                    status = FQD_Read(
                        unitHandle,
                        (LPBYTE) command,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        *currentDataRate = (DOUBLE)
                            (QD_SYSTEM_CLOCK_BASE / (DOUBLE) (3000 * (255 - command[0])));
                    }
                    else
                    {
                        locus = QD_LOCUS_GET_I2C_DATA_RATE_5;                   // 0x1B050000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }
                else
                {
                    locus = QD_LOCUS_GET_I2C_DATA_RATE_4;                       // 0x1B040000
                }
            }
            else
            {
                locus = QD_LOCUS_GET_I2C_DATA_RATE_3;                           // 0x1B030000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
            if ((status == QD_SUCCESS) && *currentDataRate)
            {
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    Sleep(100);
                }
                else
                {
                    if (status == QD_SUCCESS)
                    {
                        if (*currentDataRate == 0.0)
                        {
                            locus = QD_LOCUS_GET_I2C_DATA_RATE_6;               // 0x1B060000
                            status = QD_ERROR_DATA_RATE_ZERO;                   // 0x0000001D
                        }
                        else
                        {
                            locus = QD_LOCUS_GET_I2C_DATA_RATE_7;               // 0x1B070000
                            status = QD_ERROR_UNREACHABLE_CONDITION;            // 0x00000029
                        }
                    }
                    else
                    {
                        *currentDataRate = 0.0;
                    }
                }
            }
        }                               // end of while (attempts--)
    }                                   // end of if (currentDataRate)
    else
    {
        locus = QD_LOCUS_GET_I2C_DATA_RATE_2;                                   // 0x1B020000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetI2CDataRate()
//----------------------------------------------------------------------------
// FQD_GetInternalErrorCode
//
// Retrieves the internal error code
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B3 section 3.30
//----------------------------------------------------------------------------
    DWORD
FQD_GetInternalErrorCode(
    HANDLE          unitHandle,
    LPWORD          errorCode)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    DWORD           numberOfCommandBytes;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_INTERNAL_ERROR_CODE;                   // 0x1C000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_GET_INTERNAL_ERROR_CODE_1;                             // 0x1C010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (errorCode)
    {
        *errorCode = 0;
        while (attempts--)
        {
            //----------------------------------------------------------------
            // Flush buffers ahead of the Read command
            //----------------------------------------------------------------
            FQD_FlushAllBuffers(unitHandle);
            ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                       // 16
            //----------------------------------------------------------------
            // HX0D16 B0 section 3.18: Get Error Code
            //----------------------------------------------------------------
            command[0] = QD_CMD_GET_ERROR_CODE;                                 // 0x1B
            numberOfCommandBytes = 1;
            status = FQD_Write(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                numberOfCommandBytes = 2;
                status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                if (status == QD_SUCCESS)
                {
                    status = FQD_Read(
                        unitHandle,
                        (LPBYTE) command,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        *errorCode = (DWORD) (command[0] << 8 | command[1]);
                    }
                    else
                    {
                        locus = QD_LOCUS_GET_INTERNAL_ERROR_CODE_5;             // 0x1C050000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }
                else
                {
                    locus = QD_LOCUS_GET_INTERNAL_ERROR_CODE_4;                 // 0x1C040000
                }
            }
            else
            {
                locus = QD_LOCUS_GET_INTERNAL_ERROR_CODE_3;                     // 0x1C030000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
            if (status == QD_SUCCESS)
            {
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    Sleep(100);
                }
                else
                {
                    *errorCode = 0xFFFF;
                }
            }
        }                               // end of while (attempts--)
    }                                   // end of if (errorCode)
    else
    {
        locus = QD_LOCUS_GET_INTERNAL_ERROR_CODE_2;                             // 0x1C020000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetInternalErrorCode()
//----------------------------------------------------------------------------
// FQD_GetMemoryType
//
// Retrieves the memory type of the specified device
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B2 section 3.62
//----------------------------------------------------------------------------
    DWORD
FQD_GetMemoryType(
    HANDLE          unitHandle,
    BYTE            device,
    LPBYTE          memoryType)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    DWORD           numberOfCommandBytes;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_MEMORY_TYPE;                           // 0x1D000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_GET_MEMORY_TYPE_1;                                     // 0x1D010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (memoryType)
    {
        *memoryType = 0;
        while (attempts--)
        {
            //----------------------------------------------------------------
            // Flush buffers ahead of the Read command
            //----------------------------------------------------------------
            FQD_FlushAllBuffers(unitHandle);
            ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                       // 16
            //----------------------------------------------------------------
            // HX0D16 B0 section 3.22: Get Memory Type
            //----------------------------------------------------------------
            command[0] = QD_CMD_GET_MEMORY_TYPE;                                // 0x1F
            command[1] = device;
            numberOfCommandBytes = 2;
            status = FQD_Write(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                numberOfCommandBytes = 1;
                status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                if (status == QD_SUCCESS)
                {
                    status = FQD_Read(
                        unitHandle,
                        (LPBYTE) command,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        *memoryType = command[0];
                    }
                    else
                    {
                        locus = QD_LOCUS_GET_MEMORY_TYPE_5;                     // 0x1D050000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }
                else
                {
                    locus = QD_LOCUS_GET_MEMORY_TYPE_4;                         // 0x1D040000
                }
            }
            else
            {
                locus = QD_LOCUS_GET_MEMORY_TYPE_3;                             // 0x1D030000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
            if ((status == QD_SUCCESS) && *memoryType)
            {
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    *memoryType = QD_MEMORY_TYPE_ABSENT;
                    Sleep(100);
                }
            }
        }                               // end of while (attempts--)
    }                                   // end of if (memoryType)
    else
    {
        locus = QD_LOCUS_GET_MEMORY_TYPE_2;                                     // 0x1D020000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetMemoryType()
//----------------------------------------------------------------------------
// FQD_GetModuleSerialNumber
//
// Retrieves the specified device unit serial number
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    serialNumber must point to at least SI_MAX_DEVICE_STRLEN (256)
//          bytes of available memory
//
// D11813 B1 section 3.46
//----------------------------------------------------------------------------
    DWORD
FQD_GetModuleSerialNumber(
    DWORD           unitNumber,
    LPBYTE          serialNumber)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = (DWORD) FQD_GetProductInfo(
        unitNumber,
        serialNumber,
        SI_RETURN_SERIAL_NUMBER);                                               // 0x00
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_GET_MODULE_SERIAL_NUMBER;                            // 0x29000000
    }
    return status;
}                                       // end of FQD_GetModuleSerialNumber()
//----------------------------------------------------------------------------
// FQD_GetNumberOfUnits
//
// Returns the number of QCOM modules
//
// Returns: nonzero     Number of QCOM modules detected
//          0           Failure or no modules detected
//
// D11813 B1 section 3.1
//----------------------------------------------------------------------------
    DWORD
FQD_GetNumberOfUnits(void)
{
    DWORD           numberOfUnits = 0;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_NUMBER_OF_MODULES;                       // 0x1E000000
    //------------------------------------------------------------------------
    // Silicon Labs AN169 Rev. 1.8 section 2.1 : SI_GetNumDevices
    //------------------------------------------------------------------------
    status = (DWORD) SI_GetNumDevices(&numberOfUnits);
    if (status == QD_SUCCESS)                                                   // 0x00000000
    {
        return numberOfUnits;
    }
    else
    {
        //--------------------------------------------------------------------
        // Typically SI_GetNumDevices returns SI_DEVICE_NOT_FOUND (0xFF) if no
        // devices are detected
        //--------------------------------------------------------------------
        if (status == SI_DEVICE_NOT_FOUND)                                      // 0xFF
        {
        }
        else
        {
        }
        return 0;
    }
}                                       // end of FQD_GetNumberOfUnits()
//----------------------------------------------------------------------------
// FQD_GetPressureAndTemperature
//
// Returns the values of both the pressure in PSI and temperature in Celsius
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.12
//----------------------------------------------------------------------------
    DWORD
FQD_GetPressureAndTemperature(
    HANDLE          unitHandle,
    LPBYTE          coefficientData,
    DOUBLE          *pressurePSI,
    DOUBLE          *temperatureCelsius)
{
    DWORD           pressureCount;
    DWORD           temperatureCount;
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetTransducerCounts(
        unitHandle,
        &pressureCount,
        &temperatureCount);
    if (status == QD_SUCCESS)
    {
        status = FQD_CalculatePressureAndTemperature(
            coefficientData,
            pressureCount,
            temperatureCount,
            pressurePSI,
            temperatureCelsius);
    }
    if (status && !(status & QD_ERROR_CODE_FUNCTION_MASK))
        status |= QD_LOCUS_GET_PRESSURE_AND_TEMPERATURE;                        // 0x1F000000
    return status;
}                                       // end of FQD_GetPressureAndTemperature()
//----------------------------------------------------------------------------
// FQD_GetProductInfo
//
// Retrieves the specified module serial number (and other info)
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    productInfoString must point to at least SI_MAX_DEVICE_STRLEN (256)
//          bytes of available memory
//
// Note:    For QCOM purposes, SI_RETURN_LINK_NAME (5) has been retired
//
// D11813 B3 section 3.2
//----------------------------------------------------------------------------
    DWORD
FQD_GetProductInfo(
    DWORD           unitNumber,
    LPBYTE          productInfoString,
    DWORD           item)
{
    DWORD           numberOfUnits;
    DWORD           status = QD_SUCCESS;
    DWORD           locus = QD_LOCUS_GET_PRODUCT_INFO;                          // 0x20000000
    //------------------------------------------------------------------------
    if (productInfoString)
    {
        ClearBuffer(productInfoString, SI_MAX_DEVICE_STRLEN);
        numberOfUnits = FQD_GetNumberOfUnits();
        if (numberOfUnits)
        {
            if (unitNumber < numberOfUnits)
            {
                //------------------------------------------------------------
                // Intercept specific items
                //------------------------------------------------------------
                switch (item)
                {
                    case QD_RETURN_SERIAL_NUMBER :                              // 0
                    case QD_RETURN_VID :                                        // 3
                    case QD_RETURN_PID :                                        // 4
                        status = (DWORD) SI_GetProductString(
                            unitNumber,
                            (LPVOID) productInfoString,
                            item);
                        if (status == QD_SUCCESS)
                        {
                            //------------------------------------------------
                            // Change all the characters to uppercase
                            //------------------------------------------------
                            _strupr_s((char *) productInfoString, SI_MAX_DEVICE_STRLEN);
                        }
                        else
                        {
                            locus = QD_LOCUS_GET_PRODUCT_INFO_4;                // 0x20040000
                        }
                        break;
                    case QD_RETURN_DESCRIPTION :                                // 1
                        sprintf_s(
                            (char *) productInfoString,
                            SI_MAX_DEVICE_STRLEN,                               // 256
                            "QCOM Module %02d",
                            unitNumber);
                        break;
                    case QD_RETURN_COMPANY :                                    // 2
                        strcpy_s(
                            (char *) productInfoString,
                            SI_MAX_DEVICE_STRLEN,
                            "Quartzdyne, Inc.");
                        break;
                    case QD_RETURN_AUTHOR :                                     // 5
                        strcpy_s(
                            (char *) productInfoString,
                            SI_MAX_DEVICE_STRLEN,
                            "Noji Ratzlaff (noji@quartzdyne.com)");
                        break;
                    default :
                        locus = QD_LOCUS_GET_PRODUCT_INFO_5;                    // 0x20050000
                        status = QD_ERROR_FUNCTION_NOT_SUPPORTED;               // 0x0000000A
                        break;
                }                       // end of switch (item)
            }                           // end of if (unitNumber < numberOfUnits)
            else
            {
                //------------------------------------------------------------
                // unitNumber is not valid
                //------------------------------------------------------------
                locus = QD_LOCUS_GET_PRODUCT_INFO_3;                            // 0x20030000
                status = QD_ERROR_INVALID_PARAMETER;                            // 0x00000006
            }
        }                               // end of if (numberOfUnits)
        else
        {
            locus = QD_LOCUS_GET_PRODUCT_INFO_2;                                // 0x20020000
            status = QD_ERROR_NO_DEVICE_FOUND;                                  // 0x000000FF
        }
    }                                   // end of if (productInfoString)
    else
    {
        locus = QD_LOCUS_GET_PRODUCT_INFO_1;                                    // 0x20010000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
    {
        status |= locus;
        status |= ((item << 20) & QD_ERROR_CODE_LOCUS_MASK);                    // 0x00FF0000
    }
    return status;
}                                       // end of FQD_GetProductInfo()
//----------------------------------------------------------------------------
// FQD_GetQDDLLVersion
//
// Returns the version of the installed Quartzdyne DLL (qdUSB.dll)
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B2 section 3.63
//----------------------------------------------------------------------------
    DWORD
FQD_GetQDDLLVersion(
    LPBYTE          majorVersion,
    LPBYTE          minorVersion,
    LPBYTE          buildVersion)
{
    DWORD           status = QD_SUCCESS;
    DWORD           locus = QD_LOCUS_GET_DLL_VERSION;                           // 0x47000000
    //------------------------------------------------------------------------
    if (majorVersion && minorVersion && buildVersion)
    {
        *majorVersion = QDUSB_DLL_MAJOR_VERSION;
        *minorVersion = QDUSB_DLL_MINOR_VERSION;
        *buildVersion = QDUSB_DLL_BUILD_VERSION;
    }
    else
    {
        locus = QD_LOCUS_GET_DLL_VERSION_1;                                     // 0x47010000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
    {
        status |= locus;
    }
    return status;
}                                       // end of FQD_GetQDDLLVersion()
//----------------------------------------------------------------------------
// FQD_GetTimeouts
//
// Returns the Read and Write timeouts as they are currently set
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0, B1 section 3.6
//----------------------------------------------------------------------------
    DWORD
FQD_GetTimeouts(
    LPDWORD         readTimeout,
    LPDWORD         writeTimeout)
{
    DWORD           status = QD_SUCCESS;
    DWORD           locus = QD_LOCUS_GET_TIMEOUTS;                              // 0x21000000
    //------------------------------------------------------------------------
    if (readTimeout && writeTimeout)
    {
        *readTimeout = 0;
        *writeTimeout = 0;
        //--------------------------------------------------------------------
        // Silicon Labs AN169 Rev. 1.8 section 2.9 : SI_GetTimeouts
        //--------------------------------------------------------------------
        status = (DWORD) SI_GetTimeouts(readTimeout, writeTimeout);
    }                                   // end of if (readTimeout && writeTimeout)
    else
    {
        if (!readTimeout && !writeTimeout)
        {
            locus = QD_LOCUS_GET_TIMEOUTS_1;                                    // 0x21010000
        }
        else
        {
            if (readTimeout)
                locus = QD_LOCUS_GET_TIMEOUTS_2;                                // 0x21020000
            else
                locus = QD_LOCUS_GET_TIMEOUTS_3;                                // 0x21030000
        }
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetTimeouts()
//----------------------------------------------------------------------------
// FQD_GetTransducerCounts
//
// Returns the pressure and temperature counts for the specified transducer
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.10
//----------------------------------------------------------------------------
    DWORD
FQD_GetTransducerCounts(
    HANDLE          unitHandle,
    LPDWORD         pressureCount,
    LPDWORD         temperatureCount)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    DWORD           numberOfCommandBytes;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_TRANSDUCER_COUNTS;                     // 0x22000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_GET_TRANSDUCER_COUNTS_1;                               // 0x22010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (pressureCount && temperatureCount)
    {
        *pressureCount = 0;
        *temperatureCount = 0;
        while (attempts--)
        {
            //----------------------------------------------------------------
            // Flush buffers ahead of the Read command
            //----------------------------------------------------------------
            FQD_FlushAllBuffers(unitHandle);
            ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                       // 16
            //----------------------------------------------------------------
            // HX0D16 B0 section 3.8: Get Counts
            //----------------------------------------------------------------
            command[0] = QD_CMD_GET_TRANSDUCER_COUNTS;                          // 0x11
            command[1] = QD_GET_BOTH_COUNTS;                                    // 0x00
            numberOfCommandBytes = 2;
            status = FQD_Write(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                numberOfCommandBytes = 8;
                status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                if (status == QD_SUCCESS)
                {
                    status = FQD_Read(
                        unitHandle,
                        (LPBYTE) command,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        *pressureCount = (DWORD)
                            ((command[3] << 24) | (command[2] << 16) | (command[1] << 8) | command[0]);
                        *temperatureCount = (DWORD)
                            ((command[7] << 24) | (command[6] << 16) | (command[5] << 8) | command[4]);
                    }
                    else
                    {
                        locus = QD_LOCUS_GET_TRANSDUCER_COUNTS_6;               // 0x22060000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }
                else
                {
                    locus = QD_LOCUS_GET_TRANSDUCER_COUNTS_5;                   // 0x22050000
                }
            }
            else
            {
                locus = QD_LOCUS_GET_TRANSDUCER_COUNTS_4;                       // 0x22040000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
            if ((status == QD_SUCCESS) && *pressureCount && *temperatureCount)
            {
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    Sleep(100);
                }
                else
                {
                    if (status == QD_SUCCESS)
                    {
                        if ((*pressureCount == 0) || (*temperatureCount == 0))
                        {
                            if ((*pressureCount == 0) && (*temperatureCount == 0))
                            {
                                locus = QD_LOCUS_GET_TRANSDUCER_COUNTS_7;       // 0x22070000
                                status = QD_ERROR_XD_BOTH_COUNTS_ZERO;          // 0x00000013
                            }
                            else
                            {
                                if (*pressureCount == 0)
                                {
                                    locus = QD_LOCUS_GET_TRANSDUCER_COUNTS_8;   // 0x22080000
                                    status = QD_ERROR_XD_PRESSURE_COUNT_ZERO;   // 0x00000011
                                }
                                if (*temperatureCount == 0)
                                {
                                    locus = QD_LOCUS_GET_TRANSDUCER_COUNTS_9;   // 0x22090000
                                    status = QD_ERROR_XD_TEMPERATURE_COUNT_ZERO;// 0x00000012
                                }
                            }
                        }
                        else
                        {
                            locus = QD_LOCUS_GET_TRANSDUCER_COUNTS_B;           // 0x220B0000
                            status = QD_ERROR_UNREACHABLE_CONDITION;            // 0x00000029
                        }
                    }
                    else
                    {
                        *pressureCount = *temperatureCount = 0;
                    }
                }
            }
        }                               // end of while (attempts--)
    }                                   // end of if (pressureCount && temperatureCount)
    else
    {
        if (!pressureCount && !temperatureCount)
        {
            //----------------------------------------------------------------
            // Both pointers are null
            //----------------------------------------------------------------
            locus = QD_LOCUS_GET_TRANSDUCER_COUNTS_A;                           // 0x220A0000
        }
        else
        {
            if (pressureCount)
            {
                //------------------------------------------------------------
                // temperatureCount
                //------------------------------------------------------------
                locus = QD_LOCUS_GET_TRANSDUCER_COUNTS_2;                       // 0x22020000
            }
            else
            {
                //------------------------------------------------------------
                // pressureCount is null
                //------------------------------------------------------------
                locus = QD_LOCUS_GET_TRANSDUCER_COUNTS_3;                       // 0x22030000
            }
        }
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }                                   // end of else of if (pressureCount && temperatureCount)
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetTransducerCounts()
//----------------------------------------------------------------------------
// FQD_GetTransducerCurrent
//
// Returns the DC current in milliamps being drawn by the transducer
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.18
//----------------------------------------------------------------------------
    DWORD
FQD_GetTransducerCurrent(
    HANDLE          unitHandle,
    DOUBLE          *transducerCurrent)
{
    bool            acceptableCurrentLevel = true;
    int             attempts = 10;
    DWORD           currentCount;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_TRANSDUCER_CURRENT;                    // 0x23000000
    //------------------------------------------------------------------------
    if (transducerCurrent)
    {
        *transducerCurrent = 0.0;
        while (attempts--)
        {
            //----------------------------------------------------------------
            // D11814 B0 section 3.17: FQD_ReadUnitADC
            //----------------------------------------------------------------
            status = FQD_ReadUnitADC(
                unitHandle,
                QD_READ_ADC_CHANNEL_CURRENT,                                    // 0x04
                &currentCount);
            if (status == QD_SUCCESS)
            {
                *transducerCurrent = (DOUBLE) currentCount * QD_SCALE_CURRENT * 1000.0; // 0.00002819
                if (*transducerCurrent > QD_MAXIMUM_ACCEPTABLE_CURRENT)
                {
                    acceptableCurrentLevel = false;
                    locus = QD_LOCUS_GET_TRANSDUCER_CURRENT_2;                  // 0x23020000
                    status = QD_ERROR_XD_CURRENT_TOO_HIGH;
                }
                if (*transducerCurrent < QD_MINIMUM_ACCEPTABLE_CURRENT)
                {
                    acceptableCurrentLevel = false;
                    locus = QD_LOCUS_GET_TRANSDUCER_CURRENT_3;                  // 0x23030000
                    status = QD_ERROR_XD_CURRENT_TOO_LOW;
                }
            }
            if ((status == QD_SUCCESS) && acceptableCurrentLevel)
            {
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    acceptableCurrentLevel = true;
                    Sleep(100);
                }
                else
                {
                    *transducerCurrent = 0.0;
                }
            }
        }                               // end of while (attempts--)
    }                                   // end of if (transducerCurrent)
    else
    {
        locus = QD_LOCUS_GET_TRANSDUCER_CURRENT_1;                              // 0x23010000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetTransducerCurrent()
//----------------------------------------------------------------------------
// FQD_GetTransducerType
//
// Retrieves the specified device unit transducer type
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.9
//----------------------------------------------------------------------------
    DWORD
FQD_GetTransducerType(
    HANDLE          unitHandle,
    LPBYTE          transducerType)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 1;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_TRANSDUCER_TYPE;                       // 0x24000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_GET_TRANSDUCER_TYPE_1;                                 // 0x24010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (transducerType)
    {
        *transducerType = 0;
        while (attempts--)
        {
            //----------------------------------------------------------------
            // Flush buffers ahead of the Read command
            //----------------------------------------------------------------
            FQD_FlushAllBuffers(unitHandle);
            ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                       // 16
            //----------------------------------------------------------------
            // HX0D16 B0 section 3.7: Get Transducer Type
            //----------------------------------------------------------------
            command[0] = QD_CMD_GET_TRANSDUCER_TYPE;                            // 0x10
            status = FQD_Write(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                if (status == QD_SUCCESS)
                {
                    status = FQD_Read(
                        unitHandle,
                        (LPBYTE) command,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        *transducerType = command[0];
                    }
                    else
                    {
                        locus = QD_LOCUS_GET_TRANSDUCER_TYPE_5;                 // 0x24050000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }
                else
                {
                    locus = QD_LOCUS_GET_TRANSDUCER_TYPE_4;                     // 0x24040000
                }
            }
            else
            {
                locus = QD_LOCUS_GET_TRANSDUCER_TYPE_3;                         // 0x24030000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
            if ((status == QD_SUCCESS) && *transducerType)
            {
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    Sleep(100);
                }
                *transducerType = QD_TRANSDUCER_TYPE_ABSENT;                    // 0
            }
        }                               // end of while (attempts--)
    }                                   // end of if (transducerType)
    else
    {
        locus = QD_LOCUS_GET_TRANSDUCER_TYPE_2;                                 // 0x24020000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetTransducerType()
//----------------------------------------------------------------------------
// FQD_GetTransducerVoltage
//
// Returns the DC voltage in volts being applied to the transducer
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.19
//----------------------------------------------------------------------------
    DWORD
FQD_GetTransducerVoltage(
    HANDLE          unitHandle,
    DOUBLE          *transducerVoltage)
{
    bool            acceptableVoltageLevel = true;
    int             attempts = 10;
    DWORD           voltageCount;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_TRANSDUCER_VOLTAGE;                    // 0x25000000
    //------------------------------------------------------------------------
    if (transducerVoltage)
    {
        *transducerVoltage = 0.0;
        while (attempts--)
        {
            //----------------------------------------------------------------
            // D11814 B0 section 3.17: FQD_ReadUnitADC
            //----------------------------------------------------------------
            status = FQD_ReadUnitADC(
                unitHandle,
                QD_READ_ADC_CHANNEL_VOLTAGE,                                    // 0x04
                &voltageCount);
            if (status == QD_SUCCESS)
            {
                *transducerVoltage = (DOUBLE) voltageCount * QD_SCALE_VOLTAGE;  // 0.005957
                if (*transducerVoltage > QD_MAXIMUM_ACCEPTABLE_VOLTAGE)
                {
                    acceptableVoltageLevel = false;
                    locus = QD_LOCUS_GET_TRANSDUCER_VOLTAGE_2;                  // 0x25020000
                    status = QD_ERROR_XD_VOLTAGE_TOO_HIGH;
                }
                if (*transducerVoltage < QD_MINIMUM_ACCEPTABLE_VOLTAGE)
                {
                    acceptableVoltageLevel = false;
                    locus = QD_LOCUS_GET_TRANSDUCER_VOLTAGE_3;                  // 0x25030000
                    status = QD_ERROR_XD_VOLTAGE_TOO_LOW;
                }
            }
            if ((status == QD_SUCCESS) && acceptableVoltageLevel)
            {
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    acceptableVoltageLevel = true;
                    Sleep(100);
                }
                else
                {
                    *transducerVoltage = 0.0;
                }
            }
        }                               // end of while (attempts--)
    }                                   // end of if (transducerVoltage)
    else
    {
        locus = QD_LOCUS_GET_TRANSDUCER_VOLTAGE_1;                              // 0x25010000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetTransducerVoltage()
//----------------------------------------------------------------------------
// FQD_GetUnitControlRegister
//
// Retrieves the specified device unit control register value
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.21
//----------------------------------------------------------------------------
    DWORD
FQD_GetUnitControlRegister(
    HANDLE          unitHandle,
    LPBYTE          registerValue)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 1;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_MODULE_CONTROL_REGISTER;                 // 0x26000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_GET_MODULE_CONTROL_REGISTER_1;                           // 0x26010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (registerValue)
    {
        *registerValue = 0;
        while (attempts--)
        {
            //----------------------------------------------------------------
            // Flush buffers ahead of the Read command
            //----------------------------------------------------------------
            FQD_FlushAllBuffers(unitHandle);
            ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                       // 16
            //----------------------------------------------------------------
            // HX0D16 B0 section 3.4: Get Control Register
            //----------------------------------------------------------------
            command[0] = QD_CMD_GET_CONTROL_REG;                                // 0x0B
            status = FQD_Write(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                if (status == QD_SUCCESS)
                {
                    status = FQD_Read(
                        unitHandle,
                        (LPBYTE) command,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        *registerValue = command[0];
                    }
                    else
                    {
                        locus = QD_LOCUS_GET_MODULE_CONTROL_REGISTER_5;           // 0x26050000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }
                else
                {
                    locus = QD_LOCUS_GET_MODULE_CONTROL_REGISTER_4;               // 0x26040000
                }
            }
            else
            {
                locus = QD_LOCUS_GET_MODULE_CONTROL_REGISTER_3;                   // 0x26030000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
            if ((status == QD_SUCCESS) && *registerValue)
            {
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    Sleep(100);
                }
                else
                {
                    if (status)
                    {
                        *registerValue = 0;
                    }
                }
            }
        }                               // end of while (attempts--)
    }                                   // end of if (registerValue)
    else
    {
        locus = QD_LOCUS_GET_MODULE_CONTROL_REGISTER_2;                           // 0x26020000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetUnitControlRegister()
//----------------------------------------------------------------------------
// FQD_GetUnitFirmwareID
//
// Retrieves the specified device unit firmware ID and version
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    firmwareID must point to at least QD_FIRMWARE_ID_LENGTH (4) bytes
//          of available memory
//
// D11813 B1 section 3.24
//----------------------------------------------------------------------------
    DWORD
FQD_GetUnitFirmwareID(
    HANDLE          unitHandle,
    LPBYTE          firmwareID)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    DWORD           numberOfCommandBytes;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_MODULE_FIRMWARE_ID;                      // 0x27000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_GET_MODULE_FIRMWARE_ID_1;                                // 0x27010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (firmwareID)
    {
        while (attempts--)
        {
            //----------------------------------------------------------------
            // Flush buffers ahead of the Read command
            //----------------------------------------------------------------
            FQD_FlushAllBuffers(unitHandle);
            ClearBuffer(firmwareID, QD_FIRMWARE_ID_LENGTH);                     // 4
            ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                       // 16
            //----------------------------------------------------------------
            // HX0D16 B0 section 3.3: Get Firmware Version and ID
            //----------------------------------------------------------------
            command[0] = QD_CMD_GET_FIRMWARE_ID;                           // 0x08
            numberOfCommandBytes = 1;
            status = FQD_Write(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                numberOfCommandBytes = QD_FIRMWARE_ID_LENGTH;                   // 4
                status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                if (status == QD_SUCCESS)
                {
                    status = FQD_Read(
                        unitHandle,
                        (LPBYTE) command,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        memcpy((void *) firmwareID, (void *) command, QD_FIRMWARE_ID_LENGTH);
                    }
                    else
                    {
                        locus = QD_LOCUS_GET_MODULE_FIRMWARE_ID_5;                // 0x27050000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }
                else
                {
                    locus = QD_LOCUS_GET_MODULE_FIRMWARE_ID_4;                    // 0x27040000
                }
            }
            else
            {
                locus = QD_LOCUS_GET_MODULE_FIRMWARE_ID_3;                        // 0x27030000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
            if ((status == QD_SUCCESS) && (*firmwareID == QD_QUARTZDYNE_ID))
            {
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    Sleep(100);
                }
                else
                {
                    if (status == QD_SUCCESS)
                    {
                        if (*firmwareID == QD_QUARTZDYNE_ID)
                        {
                            locus = QD_LOCUS_GET_MODULE_FIRMWARE_ID_7;            // 0x27070000
                            status = QD_ERROR_UNREACHABLE_CONDITION;            // 0x00000029
                        }
                        else
                        {
                            locus = QD_LOCUS_GET_MODULE_FIRMWARE_ID_6;            // 0x27060000
                            status = QD_ERROR_FIRMWARE_ID_ZERO;                 // 0x0000001F
                        }
                    }
                }
            }
        }                               // end of while (attempts--)
    }                                   // end of if (firmwareID)
    else
    {
        locus = QD_LOCUS_GET_MODULE_FIRMWARE_ID_2;                                // 0x27020000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetUnitFirmwareID()
//----------------------------------------------------------------------------
// FQD_GetUnitModeSwitchSetting
//
// Retrieves the specified device unit mode switch setting
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.27
//----------------------------------------------------------------------------
    DWORD
FQD_GetUnitModeSwitchSetting(
    HANDLE          unitHandle,
    LPBYTE          modeSwitchSetting)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 1;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_MODULE_MODE_SWITCH_SETTING;              // 0x28000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_GET_MODULE_MODE_SWITCH_SETTING_1;                        // 0x28010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (modeSwitchSetting)
    {
        *modeSwitchSetting = 0;
        while (attempts--)
        {
            //----------------------------------------------------------------
            // Flush buffers ahead of the Read command
            //----------------------------------------------------------------
            FQD_FlushAllBuffers(unitHandle);
            ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                       // 16
            //----------------------------------------------------------------
            // HX0D16 B0 section 3.2: Read Mode Switch Setting
            //----------------------------------------------------------------
            command[0] = QD_CMD_READ_MODE_SWITCH;                               // 0x04
            status = FQD_Write(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                if (status == QD_SUCCESS)
                {
                    status = FQD_Read(
                        unitHandle,
                        (LPBYTE) command,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        *modeSwitchSetting = command[0];
                    }
                    else
                    {
                        locus = QD_LOCUS_GET_MODULE_MODE_SWITCH_SETTING_5;        // 0x28050000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }
                else
                {
                    locus = QD_LOCUS_GET_MODULE_MODE_SWITCH_SETTING_4;            // 0x28040000
                }
            }
            else
            {
                locus = QD_LOCUS_GET_MODULE_MODE_SWITCH_SETTING_3;                // 0x28030000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
            if (status == QD_SUCCESS)
            {
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    Sleep(100);
                }
                else
                {
                    if (status)
                    {
                        *modeSwitchSetting = QD_MODE_SWITCH_NOT_PRESSED;        // 0x01
                    }
                }
            }
        }                               // end of while (attempts--)
    }                                   // end of if (modeSwitchSetting)
    else
    {
        locus = QD_LOCUS_GET_MODULE_MODE_SWITCH_SETTING_2;                        // 0x28020000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetUnitModeSwitchSetting()
//----------------------------------------------------------------------------
// FQD_GetUnitStatusRegister
//
// Retrieves the specified device unit status register value
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.23
//----------------------------------------------------------------------------
    DWORD
FQD_GetUnitStatusRegister(
    HANDLE          unitHandle,
    LPBYTE          registerValue)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 1;
    DWORD           status;
    DWORD           locus = QD_LOCUS_GET_MODULE_STATUS_REGISTER;                  // 0x2A000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_GET_MODULE_STATUS_REGISTER_1;                            // 0x2A010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (registerValue)
    {
        *registerValue = 0;
        while (attempts--)
        {
            //----------------------------------------------------------------
            // Flush buffers ahead of the Read command
            //----------------------------------------------------------------
            FQD_FlushAllBuffers(unitHandle);
            ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                       // 16
            //----------------------------------------------------------------
            // HX0D16 B0 section 3.12: Get Status Register
            //----------------------------------------------------------------
            command[0] = QD_CMD_GET_STATUS_REG;                                 // 0x15
            status = FQD_Write(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                if (status == QD_SUCCESS)
                {
                    status = FQD_Read(
                        unitHandle,
                        (LPBYTE) command,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        *registerValue = command[0];
                    }
                    else
                    {
                        locus = QD_LOCUS_GET_MODULE_STATUS_REGISTER_5;            // 0x2A050000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }
                else
                {
                    locus = QD_LOCUS_GET_MODULE_STATUS_REGISTER_4;                // 0x2A040000
                }
            }
            else
            {
                locus = QD_LOCUS_GET_MODULE_STATUS_REGISTER_3;                    // 0x2A030000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
            if ((status == QD_SUCCESS) && *registerValue)
            {
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    Sleep(100);
                }
                else
                {
                    if (status)
                    {
                        *registerValue = 0;
                    }
                }
            }
        }                               // end of while (attempts--)
    }                                   // end of if (registerValue)
    else
    {
        locus = QD_LOCUS_GET_MODULE_STATUS_REGISTER_2;                            // 0x2A020000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetUnitStatusRegister()
//----------------------------------------------------------------------------
// FQD_GetUSBDLLVersion
//
// Returns the version of the installed Silicon Labs USB DLL
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.44
//----------------------------------------------------------------------------
    DWORD
FQD_GetUSBDLLVersion(
    LPDWORD         upperVersion,
    LPDWORD         lowerVersion)
{
    DWORD           status = QD_SUCCESS;
    DWORD           locus = QD_LOCUS_GET_USB_DLL_VERSION;                       // 0x2B000000
    //------------------------------------------------------------------------
    if (upperVersion && lowerVersion)
    {
        *upperVersion = *lowerVersion = 0;
        //--------------------------------------------------------------------
        // Silicon Labs AN169 Rev. 1.8 section (undocumented)
        //--------------------------------------------------------------------
        status = (DWORD) SI_GetDLLVersion(upperVersion, lowerVersion);
    }                                   // end of if (upperVersion && lowerVersion)
    else
    {
        if (!upperVersion && !lowerVersion)
        {
            locus = QD_LOCUS_GET_USB_DLL_VERSION_1;                             // 0x2B010000
        }
        else
        {
            if (upperVersion)
                locus = QD_LOCUS_GET_USB_DLL_VERSION_2;                         // 0x2B020000
            else
                locus = QD_LOCUS_GET_USB_DLL_VERSION_3;                         // 0x2B030000
        }
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetUSBDLLVersion()
//----------------------------------------------------------------------------
// FQD_GetUSBDriverVersion
//
// Returns the version of the installed Silicon Labs USB driver
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.45
//----------------------------------------------------------------------------
    DWORD
FQD_GetUSBDriverVersion(
    LPDWORD         upperVersion,
    LPDWORD         lowerVersion)
{
    DWORD           status = QD_SUCCESS;
    DWORD           locus = QD_LOCUS_GET_USB_DRIVER_VERSION;                    // 0x2C000000
    //------------------------------------------------------------------------
    if (upperVersion && lowerVersion)
    {
        *upperVersion = *lowerVersion = 0;
        //--------------------------------------------------------------------
        // Silicon Labs AN169 Rev. 1.8 section (undocumented)
        //--------------------------------------------------------------------
        status = (DWORD) SI_GetDriverVersion(upperVersion, lowerVersion);
    }                                   // end of if (upperVersion && lowerVersion)
    else
    {
        if (!upperVersion && !lowerVersion)
        {
            locus = QD_LOCUS_GET_USB_DRIVER_VERSION_1;                          // 0x2C010000
        }
        else
        {
            if (upperVersion)
                locus = QD_LOCUS_GET_USB_DRIVER_VERSION_2;                      // 0x2C020000
            else
                locus = QD_LOCUS_GET_USB_DRIVER_VERSION_3;                      // 0x2C030000
        }
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_GetUSBDriverVersion()
//----------------------------------------------------------------------------
// FQD_HexFileFormatIsValid
//
// Determines whether the specified hex file data is valid by verifying its
// length fields, checksums, and other rules, including
// -   Each line must start with a ':' character
// -   The record type of each line must be "00" unless it is the last line
//     (file types of "02" and "04" are also permitted)
// -   The file must be in DOS text format, so each line must end with a
//     CR/LF pair
// -   The file must end with ":00000001FF"
//
// Note:    The address fields are not verified
//
// D11813 B2 section 3.47
//
// Confirmed identical to 1.0.8
//----------------------------------------------------------------------------
    bool
FQD_HexFileFormatIsValid(
    LPBYTE          hexFileData)
{
    bool            dataIsValid = true;     // innocent until proven guilty
    int             lineNumber = 0;         // 1-relative 'line' number
    int             recordLength;
    int             recordType = 0;
    char            *hexFileLine = (char *) hexFileData;
    unsigned        checksumActual;
    unsigned        checksumSpecified;
    //------------------------------------------------------------------------
    if (hexFileData)
    {
        if (FQD_DataIsInHexFileFormat(hexFileData))
        {
            while ((hexFileLine[0] == ':') && (recordType != 0x01) && dataIsValid)
            {
                lineNumber++;
                recordLength =
                    ((AtoX(hexFileLine[1]) << 4) & 0xF0) | (AtoX(hexFileLine[2]) & 0x0F);
                recordType =
                    ((AtoX(hexFileLine[7]) << 4) & 0xF0) | (AtoX(hexFileLine[8]) & 0x0F);
                if (recordType != 0x01)
                {
                    checksumSpecified =
                        ((AtoX(hexFileLine[(recordLength * 2) + 9]) << 4) & 0xF0) |
                        (AtoX(hexFileLine[(recordLength * 2) + 10]) & 0x0F);
                    checksumActual = 0;
                    for (int offset = 1; offset < ((recordLength * 2) + 9); offset += 2)
                    {
                        checksumActual +=
                            ((AtoX(hexFileLine[offset]) << 4) & 0xF0) |
                            (AtoX(hexFileLine[offset + 1]) & 0x0F);
                    }
                    checksumActual = (~checksumActual + 1) & 0xFF;
                    if (checksumActual == checksumSpecified)
                    {
                        if ((hexFileLine[(recordLength * 2) + 11] == QD_CR_CHAR) &&
                            (hexFileLine[(recordLength * 2) + 12] == QD_LF_CHAR))
                        {
                            hexFileLine = &hexFileLine[(recordLength * 2) + 13];
                        }
                        else
                        {
                            dataIsValid = false;
                        }
                    }
                    else
                    {
                        dataIsValid = false;
                    }
                }
            }                           // end of while ((hexFileLine[0] == ':') ...)
        }
        else
        {
            dataIsValid = false;
        }
    }
    return dataIsValid;
}                                       // end of FQD_HexFileFormatIsValid()
//----------------------------------------------------------------------------
// FQD_InterpretErrorCode
//
// Translates the specified error code into a somewhat user-friendly string
//
// Returns: The error description string
//
// Note:    errorDescription must point to at least
//          QD_MAXIMUM_ERROR_STRING_SIZE (256) bytes of available memory
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B? section 3.??
//----------------------------------------------------------------------------
    char *
FQD_InterpretErrorCode(
    DWORD           errorCode,
    char            *errorDescription)
{
    bool            useStaticString = true;
    char            *errorString;
    //------------------------------------------------------------------------
    ClearBuffer(errorDescription, QD_MAXIMUM_ERROR_STRING_SIZE);
    switch (errorCode & QD_ERROR_CODE_MASK)                                     // 0x0000FFFF
    {
        case QD_ERROR_NO_ERROR :                                                // 0x00000000
            errorString = "Not an error";
            break;
        case QD_ERROR_INVALID_HANDLE :                                          // 0x00000001
            errorString = "An invalid unit handle was passed to the function";
            break;
        case QD_ERROR_READ_ERROR :                                              // 0x00000002
            errorString = "Read Error: Trouble encountered retrieving data from the unit";
            break;
        case QD_ERROR_RECEIVE_QUEUE_NOT_READY :                                 // 0x00000003
            errorString = "The Receive Queue is not ready to transmit data";
            break;
        case QD_ERROR_WRITE_ERROR :                                             // 0x00000004
            errorString = "Write Error: Trouble encountered sending data to the unit";
            break;
        case QD_ERROR_RESET_ERROR :                                             // 0x00000005
            errorString = "Reset Error: Trouble encountered while attempting to reset the unit";
            break;
        case QD_ERROR_INVALID_PARAMETER :                                       // 0x00000006
            errorString = "An invalid parameter was passed to the function";
            break;
        case QD_ERROR_INVALID_REQUEST_LENGTH :                                  // 0x00000007
            errorString = "The request size did not match the expected length";
            break;
        case QD_ERROR_DEVICE_IO_FAILED :                                        // 0x00000008
            errorString = "An I/O request to the device did not complete as expected";
            break;
        case QD_ERROR_INVALID_DATA_RATE :                                       // 0x00000009
            errorString = "Attempt to set an invalid value for the I2C data rate";
            break;
        case QD_ERROR_FUNCTION_NOT_SUPPORTED :                                  // 0x0000000A
            errorString = "The specified operation is not supported";
            break;
        case QD_ERROR_GLOBAL_DATA_ERROR :                                       // 0x0000000B
            errorString = "A system-level data error was encountered";
            break;
        case QD_ERROR_SYSTEM_ERROR :                                            // 0x0000000C
            errorString = "A general system error was encountered";
            break;
        case QD_ERROR_READ_TIMED_OUT :                                          // 0x0000000D
            errorString = "The read request has timed out";
            break;
        case QD_ERROR_WRITE_TIMED_OUT :                                         // 0x0000000E
            errorString = "The write request has timed out";
            break;
        case QD_ERROR_IO_PENDING :                                              // 0x0000000F
            errorString = "An outstanding I/O request has not yet been serviced";
            break;
        case QD_ERROR_CHECKSUM_ERROR :                                          // 0x00000010
            errorString = "The data checksum did not match the expected value";
            break;
        case QD_ERROR_XD_PRESSURE_COUNT_ZERO :                                  // 0x00000011
            errorString = "The pressure count reports zero value";
            break;
        case QD_ERROR_XD_TEMPERATURE_COUNT_ZERO :                               // 0x00000012
            errorString = "The temperature count reports zero value";
            break;
        case QD_ERROR_XD_BOTH_COUNTS_ZERO :                                     // 0x00000013
            errorString = "Both pressure and temperature counts report zero value";
            break;
        case QD_ERROR_MEMORY_ALLOCATION_FAILED :                                // 0x00000014
            errorString = "Unable to allocate the specified amount of memory";
            break;
        case QD_ERROR_FILE_OPEN_FAILURE :                                       // 0x00000015
            errorString = "Unable to open the specified file";
            break;
        case QD_ERROR_ADC_COUNT_ZERO :                                          // 0x00000016
            errorString = "The ADC reported a zero value";
            break;
        case QD_ERROR_FILE_SIZE_MISMATCH :                                      // 0x00000017
            errorString = "The size of the specified file does not match that listed in the directory";
            break;
        case QD_ERROR_INVALID_HEX_FILE_DATA :                                   // 0x00000018
            errorString = "The specified hex data file contains an invalid format";
            break;
        case QD_ERROR_INCORRECT_DATA_SIZE :                                     // 0x00000019
            errorString = "The resulting data size is incorrect";
            break;
        case QD_ERROR_INVALID_FIRMWARE_PAGE :                                   // 0x0000001A
            errorString = "The specified firmware page is invalid";
            break;
        case QD_ERROR_UNIT_NOT_READY :                                          // 0x0000001B
            errorString = "The transducer cannot be accessed";
            break;
        case QD_ERROR_CADENCE_TIMER_ZERO :                                      // 0x0000001C
            errorString = "The cadence timer reports a zero value";
            break;
        case QD_ERROR_DATA_RATE_ZERO :                                          // 0x0000001D
            errorString = "The I2C data rate is reported as a zero value";
            break;
        case QD_ERROR_INVALID_I2C_REPLY :                                       // 0x0000001E
            errorString = "The I2C command resulted in an invalid reply string";
            break;
        case QD_ERROR_FIRMWARE_ID_ZERO :                                        // 0x0000001F
            errorString = "The firmware ID reports an invalid value";
            break;
        case QD_ERROR_DATA_TRANSFER_FAILURE :                                   // 0x00000020
            errorString = "The data did not transfer properly";
            break;
        case QD_ERROR_DEVICE_TIMED_OUT :                                        // 0x00000021
            errorString = "A request to the specified unit timed out";
            break;
        case QD_ERROR_RECEIVE_QUEUE_OVERRUN :                                   // 0x00000022
            errorString = "The request queue reported an overrun condition";
            break;
        case QD_ERROR_FIRMWARE_SIGNATURE_NOT_ERASED :                           // 0x00000023
            errorString = "The firmware signature has not been erased";
            break;
        case QD_ERROR_XD_VOLTAGE_TOO_HIGH :                                     // 0x00000024
            errorString = "The transducer voltage measures over 8.0 V";
            break;
        case QD_ERROR_XD_VOLTAGE_TOO_LOW :                                      // 0x00000025
            errorString = "The transducer voltage measures under 3.0 V";
            break;
        case QD_ERROR_XD_CURRENT_TOO_HIGH :                                     // 0x00000026
            errorString = "The transducer current measures over 30.0 mA";
            break;
        case QD_ERROR_XD_CURRENT_TOO_LOW :                                      // 0x00000027
            errorString = "The transducer current measures under 2.5 mA";
            break;
        case QD_ERROR_WRITE_ACKNOWLEDGE_FAILED :                                // 0x00000028
            errorString = "The write operation failed completion confirmation (ACK)";
            break;
        case QD_ERROR_UNREACHABLE_CONDITION :                                   // 0x00000029
            errorString = "It shouldn't have been possible to reach this point";
            break;
        case QD_ERROR_NULL_POINTER_PARAMETER :                                  // 0x0000002A
            errorString = "One of the parameters is a null pointer";
            break;
        case QD_ERROR_ZERO_LENGTH_STRING_PARAMETER :                            // 0x0000002B
            errorString = "One of the parameters is a zero-length string";
            break;
        case QD_ERROR_INVALID_COEFFICIENT_DATA :                                // 0x00000040
            errorString = "The coefficient data is invalid";
            break;
        case QD_ERROR_FILE_NOT_FOUND :                                          // 0x00000070
            errorString = "The specified file could not be found";
            break;
        case QD_ERROR_INVALID_FILE_NAME :                                       // 0x00000071
            errorString = "The specified file has an invalid name";
            break;
        case QD_ERROR_INVALID_FILE_FOUND :                                      // 0x00000072
            errorString = "The specified file was found but is invalid";
            break;
        case QD_ERROR_NO_DEVICE_FOUND :                                         // 0x000000FF
            errorString = "No device found";
            break;
        default :
            useStaticString = false;
            sprintf_s(
                errorDescription,
                QD_MAXIMUM_ERROR_STRING_SIZE,
                "Unknown error code 0x%04X encountered",
                errorCode);
            break;
    }
    if (useStaticString)
    {
        strcpy_s(
            errorDescription,
            QD_MAXIMUM_ERROR_STRING_SIZE,
            errorString);
    }
    return errorDescription;
}                                       // end of FQD_InterpretErrorCode()
//----------------------------------------------------------------------------
// FQD_KickStartUSB
//
// Kick-starts the USB interface
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B? section 3.??
//----------------------------------------------------------------------------
    DWORD
FQD_KickStartUSB(
    HANDLE          unitHandle)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 1;
    DWORD           status;
    //------------------------------------------------------------------------
    if (!unitHandle || (unitHandle == INVALID_HANDLE_VALUE))
    {
        return QD_ERROR_INVALID_HANDLE;                                         // 0x00000001
    }
    while (attempts--)
    {
//        FQD_FlushAllBuffers(unitHandle);     // for ClearError only
        ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                           // 16
        //--------------------------------------------------------------------
        // HX0D16 B0 section 3.15: Reset FPGA
        //--------------------------------------------------------------------
        command[0] = QD_CMD_RESET_FPGA;                                         // 0x18
        // HX0D16 B0 section 3.19: Clear Error
//        command[0] = QD_CMD_CLEAR_ERROR;                                        // 0x1C
        status = FQD_Write(
            unitHandle,
            (LPBYTE) command,
            numberOfCommandBytes,
            (LPDWORD) &bytesTransmitted);
        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
        {
            attempts = 0;
        }
        else
        {
            if (attempts)
            {
                Sleep(100);
            }
        }
    }                                   // end of while (attempts--)
    return status;
}                                       // end of FQD_KickStartUSB()
//----------------------------------------------------------------------------
// FQD_Open
//
// Opens a handle to the specified device unit
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0, B1 section 3.3
//----------------------------------------------------------------------------
    DWORD
FQD_Open(
    DWORD           unitNumber,
    HANDLE          *unitHandle)
{
    int             attempts = 3;
    DWORD           numberOfUnits;
    DWORD           status;
    DWORD           locus = QD_LOCUS_OPEN;                                      // 0x2D000000
    //------------------------------------------------------------------------
    numberOfUnits = FQD_GetNumberOfUnits();
    if (numberOfUnits)
    {
        if (unitNumber < numberOfUnits)
        {
            if (unitHandle)
            {
                while (attempts--)
                {
                    //--------------------------------------------------------
                    // Silicon Labs AN169 Rev. 1.8 section 2.3 : SI_Open
                    //--------------------------------------------------------
                    status = (DWORD) SI_Open(unitNumber, unitHandle);
                    if (status == QD_SUCCESS)
                    {
                        if (!*unitHandle || (*unitHandle == INVALID_HANDLE_VALUE))
                        {
                            locus = QD_LOCUS_OPEN_5;                            // 0x2D050000
                            status = QD_ERROR_INVALID_HANDLE;                   // 0x00000001
                        }
                    }
                    else
                    {
                        locus = QD_LOCUS_OPEN_4;                                // 0x2D040000
                    }
                    if (status == QD_SUCCESS)
                    {
                        attempts = 0;
                    }
                    else
                    {
                        if (attempts)
                        {
                            Sleep(100);
                        }
                    }
                }                       // end of while (attempts--)
            }                           // end of if (unitHandle)
            else
            {
                locus = QD_LOCUS_OPEN_3;                                        // 0x2D030000
                status = QD_ERROR_NULL_POINTER_PARAMETER;                       // 0x0000002A
            }
        }                               // end of if (unitNumber < numberOfUnits)
        else
        {
            //----------------------------------------------------------------
            // unitNumber is not valid
            //----------------------------------------------------------------
            locus = QD_LOCUS_OPEN_2;                                            // 0x2D020000
            status = QD_ERROR_INVALID_PARAMETER;                                // 0x00000006
        }
    }                                   // end of if (numberOfUnits)
    else
    {
        locus = QD_LOCUS_OPEN_1;                                                // 0x2D010000
        status = QD_ERROR_NO_DEVICE_FOUND;                                      // 0x000000FF
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_Open()
//----------------------------------------------------------------------------
// FQD_Read
//
// Reads data from the specified module
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.48
//----------------------------------------------------------------------------
    DWORD
FQD_Read(
    HANDLE          unitHandle,
    LPBYTE          readBuffer,
    DWORD           readBufferSize,
    LPDWORD         bytesRead)
{
    int             attempts = 3;
    DWORD           status = QD_SUCCESS;
    DWORD           locus = QD_LOCUS_READ;                                      // 0x2E000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_READ_1;                                                // 0x2E010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (readBuffer && bytesRead)
    {
        while (attempts--)
        {
            *bytesRead = 0;
            //----------------------------------------------------------------
            // Silicon Labs AN169 Rev. 1.8 section 2.5 : SI_Read
            //----------------------------------------------------------------
            status = (DWORD) SI_Read(
                unitHandle,
                (LPVOID) readBuffer,
                readBufferSize,
                bytesRead,
                NULL);
            if (status == QD_SUCCESS)
            {
                if (*bytesRead == readBufferSize)
                {
                    attempts = 0;
                }
                else
                {
                    if (attempts)
                    {
                        Sleep(100);
                    }
                    else
                    {
                        //----------------------------------------------------
                        // The data transfer possibly resulted in a data underrun
                        //----------------------------------------------------
                        locus = QD_LOCUS_READ_6;                                // 0x2E060000
                        status = QD_ERROR_DATA_TRANSFER_FAILURE;                // 0x00000020
                    }
                }
            }
            else
            {
                if (attempts)
                {
                    Sleep(100);
                }
                else
                {
                    locus = QD_LOCUS_READ_5;                                    // 0x2E050000
                }
            }
        }                               // end of while (attempts--)
    }                                   // end of if (readBuffer && bytesRead)
    else
    {
        if (!readBuffer && !bytesRead)
        {
            //----------------------------------------------------------------
            // Both readBuffer and bytesRead are null
            //----------------------------------------------------------------
            locus = QD_LOCUS_READ_4;                                            // 0x2E040000
        }
        else
        {
            if (readBuffer)
            {
                //------------------------------------------------------------
                // bytesRead is null
                //------------------------------------------------------------
                locus = QD_LOCUS_READ_3;                                        // 0x2E030000
            }
            else
            {
                //------------------------------------------------------------
                // readBuffer is null
                //------------------------------------------------------------
                locus = QD_LOCUS_READ_2;                                        // 0x2E020000
            }
        }
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_Read()
//----------------------------------------------------------------------------
// FQD_ReadCoefficientDataFromDevice
//
// Retrieves the coefficient data from the memory of the specified device, the
// QCOM memory in the case of an analog transducer, and the transducer memory
// in the case of a digital one
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    coefficientData must point to at least QD_COEFFICIENT_DATA_SIZE
//          (256) bytes of available memory
//
// D11813 B1 section 3.49
//----------------------------------------------------------------------------
    DWORD
FQD_ReadCoefficientDataFromDevice(
    HANDLE          unitHandle,
    LPBYTE          coefficientData)
{
    BYTE            device = QD_DEVICE_TRANSDUCER;                              // 0
    BYTE            statusRegister = 0;
    BYTE            transducerType = QD_TRANSDUCER_TYPE_ABSENT;                 // 0
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetUnitStatusRegister(unitHandle, (LPBYTE) &statusRegister);
    if (status == QD_SUCCESS)
    {
        transducerType = statusRegister & QD_SREG_TRANSDUCER_TYPE_MASK;         // 0x07
    }
    if ((transducerType == QD_TRANSDUCER_TYPE_ABSENT) ||                        // 0
        (transducerType == QD_TRANSDUCER_TYPE_FREQUENCY) ||                     // 1
        (transducerType == QD_TRANSDUCER_TYPE_DIGITAL_NOMEM))                   // 5
        device = QD_DEVICE_MODULE;                                              // 1
    for (BYTE pageNumber = 0; pageNumber < QD_NUMBER_OF_LOWER_QMEM_PAGES; pageNumber++)
    {
        status = FQD_ReadCoefficientDataFromSourcePage(
            unitHandle,
            device,
            pageNumber,
            coefficientData);
        if (status == QD_SUCCESS)
        {
            break;
        }
    }
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_READ_CF_DATA_FROM_DEVICE;                            // 0x2F000000
    }
    return status;
}                                       // end of FQD_ReadCoefficientDataFromDevice()
//----------------------------------------------------------------------------
// FQD_ReadCoefficientDataFromHexFile
//
// Retrieves the coefficient data from the specified file path
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    coefficientData must point to at least QD_COEFFICIENT_DATA_SIZE
//          (256) bytes of available memory
//
// D11813 B3 section 3.15
//
// Confirmed identical to 1.0.8
//----------------------------------------------------------------------------
    DWORD
FQD_ReadCoefficientDataFromHexFile(
    LPBYTE          pathName,
    LPBYTE          coefficientData)
{
    LPBYTE          fileData;
    long            bytesRead;
    long            fileSize;
    FILE            *filePointer;
    errno_t         result;
    DWORD           numberOfDataBytes;
    DWORD           status = QD_SUCCESS;
    DWORD           locus = QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE;                // 0x30000000
    //------------------------------------------------------------------------
    if (pathName && coefficientData)
    {
        if (strlen((char *) pathName))
        {
            if (FileExists((char *) pathName))
            {
                result = fopen_s(&filePointer, (char *) pathName, "rb");
                if (filePointer && (result == 0))
                {
                    //--------------------------------------------------------
                    // Determine the size of the data file
                    //--------------------------------------------------------
                    fseek(filePointer, 0, SEEK_END);
                    fileSize = ftell(filePointer);
                    fseek(filePointer, 0, SEEK_SET);
                    if (fileSize >= QD_COEFFICIENT_DATA_HEX_FILE_SIZE)          // 733
                    {
                        //----------------------------------------------------
                        // Allocate a buffer that matches the size of the data
                        // file
                        //----------------------------------------------------
                        fileData = (LPBYTE) malloc(fileSize);
                        if (fileData)
                        {
                            ClearBuffer(fileData, fileSize);
                            //------------------------------------------------
                            // Read the entire file into memory
                            //------------------------------------------------
                            bytesRead = fread((void *) fileData, 1, fileSize, filePointer);
                            if (bytesRead == fileSize)
                            {
                                //--------------------------------------------
                                // If the data format is valid, return the data
                                //--------------------------------------------
                                if (FQD_CoefficientHexFileDataIsValid(fileData))// verified
                                {
                                    numberOfDataBytes = FQD_UnFormatHexFileData(// verified
                                        fileData,
                                        coefficientData);
                                    if (numberOfDataBytes == QD_COEFFICIENT_DATA_SIZE)
                                    {
//                                        if (!FQD_CoefficientDataIsValid(coefficientData))
//                                        {
//                                            locus = QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_A;  // 0x300A0000
//                                            status = QD_ERROR_INVALID_COEFFICIENT_DATA;     // 0x00000040
//                                        }
                                    }   // end of if (numberOfDataBytes == QD_COEFFICIENT_DATA_SIZE)
                                    else
                                    {
                                        locus = QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_9;      // 0x30090000
                                        status = QD_ERROR_INCORRECT_DATA_SIZE;              // 0x00000019
                                    }
                                }       // end of if (FQD_CoefficientHexFileDataIsValid(fileData))
                                else
                                {
                                    locus = QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_8;          // 0x30080000
                                    status = QD_ERROR_INVALID_HEX_FILE_DATA;                // 0x00000018
                                }
                            }           // end of if (bytesRead == fileSize)
                            else
                            {
                                locus = QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_7;              // 0x30070000
                                status = QD_ERROR_FILE_SIZE_MISMATCH;                       // 0x00000017
                            }
                            free((void *) fileData);
                        }               // end of if (fileData)
                        else
                        {
                            locus = QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_6;                  // 0x30060000
                            status = QD_ERROR_MEMORY_ALLOCATION_FAILED;                     // 0x00000014
                        }
                    }                   // end of if (fileSize >= QD_COEFFICIENT_DATA_HEX_FILE_SIZE)
                    else
                    {
                        locus = QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_5;          // 0x30050000
                        status = QD_ERROR_INVALID_FILE_FOUND;                   // 0x00000072
                    }
                    fclose(filePointer);
                }                       // end of if (filePointer && (result == 0))
                else
                {
                    locus = QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_4;              // 0x30040000
                    status = QD_ERROR_FILE_OPEN_FAILURE;                        // 0x00000015
                }
            }                           // end of if (FileExists((char *) pathName))
            else
            {
                locus = QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_3;                  // 0x30030000
                status = QD_ERROR_FILE_NOT_FOUND;                               // 0x00000070
            }
            if (status)
                ClearBuffer(coefficientData, QD_COEFFICIENT_DATA_SIZE);         // 256
        }                               // end of if (strlen((char *) pathName))
        else
        {
            locus = QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_2;                      // 0x30020000
            status = QD_ERROR_ZERO_LENGTH_STRING_PARAMETER;                     // 0x0000002B
        }
    }                                   // end of if (pathName && coefficientData)
    else
    {
        locus = QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_1;                          // 0x30010000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_ReadCoefficientDataFromHexFile()
//----------------------------------------------------------------------------
// FQD_ReadCoefficientDataFromModulePage
//
// Retrieves the coefficient data from the memory of the specified module at
// the specified page
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    It is the responsibility of the calling function to ensure that
//          the target page number actually exists in the specified device
//
// Note:    coefficientData must point to at least QD_COEFFICIENT_DATA_SIZE
//          (256) bytes of available memory
//
// D11813 B4 section 3.50
//----------------------------------------------------------------------------
    DWORD
FQD_ReadCoefficientDataFromModulePage(
    HANDLE          unitHandle,
    BYTE            pageNumber,
    LPBYTE          coefficientData)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_ReadCoefficientDataFromSourcePage(
        unitHandle,
        QD_DEVICE_MODULE,                                                       // 1
        pageNumber,
        coefficientData);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_READ_CF_DATA_FROM_MODULE_PAGE;                       // 0x32000000
    }
    return status;
}                                       // end of FQD_ReadCoefficientDataFromModulePage()
//----------------------------------------------------------------------------
// FQD_ReadCoefficientDataFromSourcePage
//
// Retrieves the coefficient data from the memory of the specified source at
// the specified page
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    coefficientData must point to at least QD_COEFFICIENT_DATA_SIZE
//          (256) bytes of available memory
//
// D11813 B1 section 3.13
//
// Confirmed identical to 1.0.8
//----------------------------------------------------------------------------
    DWORD
FQD_ReadCoefficientDataFromSourcePage(
    HANDLE          unitHandle,
    BYTE            targetDevice,
    BYTE            pageNumber,
    LPBYTE          coefficientData)
{
    int             attempts = 3;
    BYTE            checkSum;
    BYTE            dataBuffer[QD_COEFFICIENT_DATA_SIZE];
    DWORD           bytesTransmitted;
    DWORD           devPage;
    DWORD           numberOfCommandBytes;
    DWORD           status = QD_SUCCESS;
    //------------------------------------------------------------------------
    // The destination byte (devPage) at 0x00FF0000 replaces the locus, and is
    // mapped as follows:
    //
    // The highest two bits (0xC0) = device, the lower six bits (0x3F) = pageNumber
    //
    //      00 000000b = Read from the transducer memory page 0  (0x3100XXXX)
    //      00 000001b = Read from the transducer memory page 1  (0x3101XXXX)
    //      00 000010b = Read from the transducer memory page 2  (0x3102XXXX)
    //          .
    //          .
    //          .
    //      00 111111b = Read from the transducer memory page 63  (0x313FXXXX)
    //
    //      01 000000b = Read from the QCOM module memory page 0 (0x3140XXXX)
    //      01 000001b = Read from the QCOM module memory page 1 (0x3141XXXX)
    //      01 000010b = Read from the QCOM module memory page 2 (0x3142XXXX)
    //          .
    //          .
    //          .
    //      01 111111b = Read from the QCOM module memory page 63 (0x317FXXXX)
    //
    // The destination byte will reflect the target device and memory page
    // until over-written by an error locus
    //------------------------------------------------------------------------
    devPage = (((targetDevice << 22) & 0x00C00000) | ((pageNumber << 16) & 0x003F0000));
    devPage |= QD_LOCUS_READ_CF_DATA_FROM_SOURCE_PAGE;                          // 0x31000000
    if (!unitHandle || (unitHandle == INVALID_HANDLE_VALUE))
        return (devPage | QD_ERROR_INVALID_HANDLE);                             // 0x00000001
    if (coefficientData)
    {
        switch (targetDevice)
        {
            case QD_DEVICE_TRANSDUCER :                                         // 0
            case QD_DEVICE_MODULE :                                             // 1
                while (attempts--)
                {
                    //--------------------------------------------------------
                    // Flush buffers ahead of the Read command
                    //--------------------------------------------------------
                    QD_FlushAllBuffers(unitHandle);
                    ClearBuffer(dataBuffer, QD_COEFFICIENT_DATA_SIZE);          // 256
                    //--------------------------------------------------------
                    // HX0D16 B0 section 3.9: Get Coefficient File Data
                    // From Device Memory
                    //--------------------------------------------------------
                    dataBuffer[0] = QD_CMD_READ_CF_FROM_DEVICE;                 // 0x12
                    dataBuffer[1] = targetDevice;
                    dataBuffer[2] = pageNumber;
                    numberOfCommandBytes = 3;
                    status = FQD_Write(
                        unitHandle,
                        (LPBYTE) dataBuffer,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        numberOfCommandBytes = QD_COEFFICIENT_DATA_SIZE;        // 256
                        status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                        if (status == QD_SUCCESS)
                        {
                            status = FQD_Read(
                                unitHandle,
                                (LPBYTE) dataBuffer,
                                numberOfCommandBytes,
                                (LPDWORD) &bytesTransmitted);
                            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                            {
                                //--------------------------------------------
                                // Unconditionally retrieve the data,
                                // regardless of contents
                                //--------------------------------------------
                                for (int index = checkSum = 0; index < QD_COEFFICIENT_DATA_SIZE; index++)
                                {
                                    coefficientData[index] = dataBuffer[index];
                                    checkSum += dataBuffer[index];
                                }
                                if (*dataBuffer == QD_QUARTZDYNE_ID)
                                {
                                    if (checkSum)
                                    {
                                        status = QD_ERROR_CHECKSUM_ERROR;       // 0x00000010
                                    }
                                }
                                else
                                {
                                    status = QD_ERROR_INVALID_COEFFICIENT_DATA; // 0x00000040
                                }
                            }
                            else
                            {
                                status = VerifyI2CTransfer(
                                    status, bytesTransmitted, numberOfCommandBytes);
                            }
                        }
                    }
                    else
                    {
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                    if (status == QD_SUCCESS)
                    {
                        attempts = 0;
                    }
                    else
                    {
                        if (attempts)
                        {
                            Sleep(100);
                        }
                    }
                }                       // end of while (attempts--)
                break;
            default :
                status = QD_ERROR_INVALID_PARAMETER;                            // 0x00000006
                status |= (targetDevice << 8);
                break;
        }                               // end of switch (targetDevice)
    }                                   // end of if (coefficientData)
    else
    {
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= devPage;
    return status;
}                                       // end of FQD_ReadCoefficientDataFromSourcePage()
//----------------------------------------------------------------------------
// FQD_ReadCoefficientDataFromUnitPage
//
// Retrieves the coefficient data from the memory of the specified module at
// the specified page
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    coefficientData must point to at least QD_COEFFICIENT_DATA_SIZE
//          (256) bytes of available memory
//
// D11813 B1 section 3.50
//----------------------------------------------------------------------------
    DWORD
FQD_ReadCoefficientDataFromUnitPage(
    HANDLE          unitHandle,
    BYTE            pageNumber,
    LPBYTE          coefficientData)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_ReadCoefficientDataFromSourcePage(
        unitHandle,
        QD_DEVICE_MODULE,                                                       // 1
        pageNumber,
        coefficientData);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_READ_CF_DATA_FROM_MODULE_PAGE;                         // 0x32000000
    }
    return status;
}                                       // end of FQD_ReadCoefficientDataFromUnitPage()
//----------------------------------------------------------------------------
// FQD_ReadFirmwareDataFromFile
//
// Retrieves the firmware data from the specified file path
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    firmwareData must point to at least QD_FIRMWARE_MAXIMUM_DATA_SIZE
//          (63 * 1024) bytes of available memory
//
// D11813 B1 section 3.51
//----------------------------------------------------------------------------
    DWORD
FQD_ReadFirmwareDataFromFile(
    LPBYTE          pathName,
    LPBYTE          firmwareData)
{
    LPBYTE          fileData;
    long            bytesRead;
    long            fileSize;
    FILE            *filePointer;
    errno_t         result;
    DWORD           numberOfDataBytes;
    DWORD           status = QD_SUCCESS;                                        // 0x00000000
    DWORD           locus = QD_LOCUS_READ_FW_DATA_FROM_FILE;                    // 0x33000000
    //------------------------------------------------------------------------
    if (pathName && firmwareData)
    {
        if (strlen((char *) pathName))
        {
            if (FileExists((char *) pathName))
            {
                result = fopen_s(&filePointer, (char *) pathName, "rb");
                if (filePointer && (result == 0))
                {
                    //--------------------------------------------------------
                    // Determine the size of the data file
                    //--------------------------------------------------------
                    fseek(filePointer, 0, SEEK_END);
                    fileSize = ftell(filePointer);
                    fseek(filePointer, 0, SEEK_SET);
                    //--------------------------------------------------------
                    // Allocate a buffer that matches the size of the data file
                    //--------------------------------------------------------
                    fileData = (LPBYTE) malloc(fileSize);
                    if (fileData)
                    {
                        ClearBuffer(fileData, fileSize);
                        //----------------------------------------------------
                        // Read the entire file into memory
                        //----------------------------------------------------
                        bytesRead = fread((void *) fileData, 1, fileSize, filePointer);
                        if (bytesRead == fileSize)
                        {
                            //------------------------------------------------
                            // If the data format is valid, return the data
                            //------------------------------------------------
                            if (FQD_FirmwareHexFileDataIsValid(fileData))
                            {
                                memset(
                                    (void *) firmwareData,
                                    0xFF,
                                    (size_t) QD_FIRMWARE_MAXIMUM_DATA_SIZE);
                                numberOfDataBytes = FQD_UnFormatHexFileData(
                                    fileData,
                                    firmwareData);
                                if (numberOfDataBytes == 0)
                                {
                                    locus = QD_LOCUS_READ_FW_DATA_FROM_FILE_8;  // 0x33080000
                                    status = QD_ERROR_INVALID_HEX_FILE_DATA;    // 0x00000018
                                }
                            }           // end of if (FQD_FirmwareHexFileDataIsValid(fileData))
                            else
                            {
                                locus = QD_LOCUS_READ_FW_DATA_FROM_FILE_7;      // 0x33070000
                                status = QD_ERROR_INVALID_HEX_FILE_DATA;        // 0x00000018
                            }
                        }               // end of if (bytesRead == fileSize)
                        else
                        {
                            locus = QD_LOCUS_READ_FW_DATA_FROM_FILE_6;          // 0x33060000
                            status = QD_ERROR_FILE_SIZE_MISMATCH;               // 0x00000017
                        }
                        free((void *) fileData);
                    }                   // end of if (fileData)
                    else
                    {
                        locus = QD_LOCUS_READ_FW_DATA_FROM_FILE_5;              // 0x33050000
                        status = QD_ERROR_MEMORY_ALLOCATION_FAILED;             // 0x00000014
                    }
                    fclose(filePointer);
                }                       // end of if (filePointer && (result == 0))
                else
                {
                    locus = QD_LOCUS_READ_FW_DATA_FROM_FILE_4;                  // 0x33040000
                    status = QD_ERROR_FILE_OPEN_FAILURE;                        // 0x00000015
                }
            }                           // end of if (FileExists((char *) pathName))
            else
            {
                locus = QD_LOCUS_READ_FW_DATA_FROM_FILE_3;                      // 0x33030000
                status = QD_ERROR_FILE_NOT_FOUND;                               // 0x00000070
            }
        }                               // end of if (strlen((char *) pathName))
        else
        {
            locus = QD_LOCUS_READ_FW_DATA_FROM_FILE_2;                          // 0x33020000
            status = QD_ERROR_ZERO_LENGTH_STRING_PARAMETER;                     // 0x0000002B
        }
    }                                   // end of if (pathName && firmwareData)
    else
    {
        locus = QD_LOCUS_READ_FW_DATA_FROM_FILE_1;                              // 0x33010000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_ReadFirmwareDataFromFile()
//----------------------------------------------------------------------------
// FQD_ReadUnitADC
//
// Reads the specified count register of the ADC associated with the specified
//      device unit
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.17
//----------------------------------------------------------------------------
    DWORD
FQD_ReadUnitADC(
    HANDLE          unitHandle,
    BYTE            ADCChannel,
    LPDWORD         ADCCount)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 2;
    DWORD           status;
    DWORD           locus = QD_LOCUS_READ_UNIT_ADC;                             // 0x34000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_READ_UNIT_ADC_1;                                       // 0x34010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (ADCCount)
    {
        *ADCCount = 0;
        while (attempts--)
        {
            //----------------------------------------------------------------
            // Flush buffers ahead of the Read command
            //----------------------------------------------------------------
            FQD_FlushAllBuffers(unitHandle);
            ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                       // 16
            //----------------------------------------------------------------
            // HX0D16 B0 section 3.13: Read Unit ADC
            //----------------------------------------------------------------
            command[0] = QD_CMD_READ_UNIT_ADC;                                  // 0x16
            command[1] = ADCChannel;        // 3 = transducer current, 4 = transducer voltage
            status = FQD_Write(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                if (status == QD_SUCCESS)
                {
                    status = FQD_Read(
                        unitHandle,
                        (LPBYTE) command,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        *ADCCount = (DWORD) ((command[0] << 8) | command[1]);
                    }
                    else
                    {
                        locus = QD_LOCUS_READ_UNIT_ADC_5;                       // 0x34050000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }
                else
                {
                    locus = QD_LOCUS_READ_UNIT_ADC_4;                           // 0x34040000
                }
            }
            else
            {
                locus = QD_LOCUS_READ_UNIT_ADC_3;                               // 0x34030000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
            if ((status == QD_SUCCESS) && *ADCCount)
            {
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    Sleep(100);
                }
                else
                {
                    if (status == QD_SUCCESS)
                    {
                        if (*ADCCount == 0)
                        {
                            locus = QD_LOCUS_READ_UNIT_ADC_6;                   // 0x34060000
                            status = QD_ERROR_ADC_COUNT_ZERO;                   // 0x00000016
                        }
                        else
                        {
                            locus = QD_LOCUS_READ_UNIT_ADC_7;                   // 0x34070000
                            status = QD_ERROR_UNREACHABLE_CONDITION;            // 0x00000029
                        }
                    }
                    else
                    {
                        *ADCCount = 0;
                    }
                }
            }
        }                               // end of while (attempts--)
    }                                   // end of if (ADCCount)
    else
    {
        locus = QD_LOCUS_READ_UNIT_ADC_2;                                       // 0x34020000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_ReadUnitADC()
//----------------------------------------------------------------------------
// FQD_ResetUnit
//
// Resets the specified device unit (not transducer) FPGA
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.29
//----------------------------------------------------------------------------
    DWORD
FQD_ResetUnit(
    HANDLE          unitHandle)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 1;
    DWORD           status;
    DWORD           locus = QD_LOCUS_RESET_MODULE;                                // 0x35000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_RESET_MODULE_1;                                          // 0x35010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    while (attempts--)
    {
        ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                           // 16
        //--------------------------------------------------------------------
        // HX0D16 B0 section 3.15: Reset FPGA
        //--------------------------------------------------------------------
        command[0] = QD_CMD_RESET_FPGA;                                         // 0x18
        status = FQD_Write(
            unitHandle,
            (LPBYTE) command,
            numberOfCommandBytes,
            (LPDWORD) &bytesTransmitted);
        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
        {
            attempts = 0;
        }
        else
        {
            if (attempts)
            {
                Sleep(100);
            }
            else
            {
                locus = QD_LOCUS_RESET_MODULE_2;                                  // 0x35020000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
        }
    }                                   // end of while (attempts--)
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_ResetUnit()
//----------------------------------------------------------------------------
// FQD_SetCadenceTimer
//
// Sets the cadence timer used to acquire transducer counts
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.25
//----------------------------------------------------------------------------
    DWORD
FQD_SetCadenceTimer(
    HANDLE          unitHandle,
    DWORD           cadenceTimerValue)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 3;
    DWORD           status;
    DWORD           locus = QD_LOCUS_SET_CADENCE_TIMER;                         // 0x36000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_SET_CADENCE_TIMER_1;                                   // 0x36010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (cadenceTimerValue < QD_MINIMUM_CADENCE_TIMER_MS)
    {
        cadenceTimerValue = QD_MINIMUM_CADENCE_TIMER_MS;
    }
    else
    {
        if (cadenceTimerValue > QD_MAXIMUM_CADENCE_TIMER_MS)
        {
            cadenceTimerValue = QD_MAXIMUM_CADENCE_TIMER_MS;
        }
    }
    while (attempts--)
    {
        ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                           // 16
        //--------------------------------------------------------------------
        // HX0D16 B0 section 3.16: Set Cadence Timer
        //--------------------------------------------------------------------
        command[0] = QD_CMD_SET_CADENCE_TIMER;                                  // 0x19
        command[1] = (cadenceTimerValue >> 8) & 0xFF;
        command[2] = cadenceTimerValue & 0xFF;
        status = FQD_Write(
            unitHandle,
            (LPBYTE) command,
            numberOfCommandBytes,
            (LPDWORD) &bytesTransmitted);
        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
        {
            attempts = 0;
        }
        else
        {
            if (attempts)
            {
                Sleep(100);
            }
            else
            {
                locus = QD_LOCUS_SET_CADENCE_TIMER_2;                           // 0x36020000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
        }
    }                                   // end of while (attempts--)
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_SetCadenceTimer()
//----------------------------------------------------------------------------
// FQD_SetFirmwareKeyCodes
//
// Sets the flash key codes in the module, to allow for erasing and writing
// firmware to flash memory
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.52
//----------------------------------------------------------------------------
    DWORD
FQD_SetFirmwareKeyCodes(
    HANDLE          unitHandle,
    BYTE            key0,
    BYTE            key1)
{
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    DWORD           numberOfCommandBytes;
    DWORD           status;
    DWORD           locus = QD_LOCUS_SET_FIRMWARE_KEY_CODES;                    // 0x37000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_SET_FIRMWARE_KEY_CODES_1;                              // 0x37010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                               // 16
    //------------------------------------------------------------------------
    // HX0D16 B0 section 3.??: Set Flash Key Codes
    //------------------------------------------------------------------------
    command[0] = QD_CMD_SET_FLASH_KEY_CODES;                                    // 0x06
    command[1] = key0;
    command[2] = key1;
    numberOfCommandBytes = 3;
    status = FQD_Write(
        unitHandle,
        (LPBYTE) command,
        numberOfCommandBytes,
        (LPDWORD) &bytesTransmitted);
    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
    {
        numberOfCommandBytes = 1;
        status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
        if (status == QD_SUCCESS)
        {
            //----------------------------------------------------------------
            // Retrieve the command acknowledge
            //----------------------------------------------------------------
            command[0] = QD_STATUS_INITIALIZE;                                  // 0x01
            status = FQD_Read(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                if (command[0] != QD_STATUS_SUCCESS)                            // 0x00
                {
                    locus = QD_LOCUS_SET_FIRMWARE_KEY_CODES_5;                  // 0x37050000
                    status = QD_ERROR_WRITE_ACKNOWLEDGE_FAILED;                 // 0x00000028
                }
            }
            else
            {
                locus = QD_LOCUS_SET_FIRMWARE_KEY_CODES_4;                      // 0x37040000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
        }
        else
        {
            locus = QD_LOCUS_SET_FIRMWARE_KEY_CODES_3;                          // 0x37030000
        }
    }
    else
    {
        locus = QD_LOCUS_SET_FIRMWARE_KEY_CODES_2;                              // 0x37020000
        status = VerifyI2CTransfer(
            status, bytesTransmitted, numberOfCommandBytes);
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_SetFirmwareKeyCodes()
//----------------------------------------------------------------------------
// FQD_SetFirmwareMode
//
// Transitions the specified device unit firmware to Boot-loader Mode or
// Application Mode
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.28
//----------------------------------------------------------------------------
    DWORD
FQD_SetFirmwareMode(
    HANDLE          unitHandle,
    BYTE            mode)
{
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 1;
    DWORD           status;
    DWORD           locus = QD_LOCUS_SET_FIRMWARE_MODE;                         // 0x38000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_SET_FIRMWARE_MODE_1;                                   // 0x38010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                               // 16
    if (mode == QD_SET_BOOT_LOADER_MODE)                                        // 0x01
    {
        //--------------------------------------------------------------------
        // HX0D16 B0 section 3.6: Set Bootloader Mode
        //--------------------------------------------------------------------
        command[0] = QD_CMD_SET_BOOTLOADER_MODE;                                // 0x0D
        status = FQD_Write(
            unitHandle,
            (LPBYTE) command,
            numberOfCommandBytes,  
            (LPDWORD) &bytesTransmitted);
        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
        {
        }
        else
        {
            locus = QD_LOCUS_SET_FIRMWARE_MODE_2;                               // 0x38020000
            status = VerifyI2CTransfer(
                status, bytesTransmitted, numberOfCommandBytes);
        }
    }
    else
    {
        //--------------------------------------------------------------------
        // HX0D16 B0 section 3.??: Firmware Reset
        //--------------------------------------------------------------------
        command[0] = QD_CMD_DEVICE_FIRMWARE_RESET;                              // 0x05
        status = FQD_Write(
            unitHandle,
            (LPBYTE) command,
            numberOfCommandBytes,
            (LPDWORD) &bytesTransmitted);
        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
        {
        }
        else
        {
            locus = QD_LOCUS_SET_FIRMWARE_MODE_3;                               // 0x38030000
            status = VerifyI2CTransfer(
                status, bytesTransmitted, numberOfCommandBytes);
        }
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_SetFirmwareMode()
//----------------------------------------------------------------------------
// FQD_SetFirmwarePage
//
// Sets the current page of the device unit application firmware
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.53
//----------------------------------------------------------------------------
    DWORD
FQD_SetFirmwarePage(
    HANDLE          unitHandle,
    BYTE            pageNumber)
{
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    DWORD           numberOfCommandBytes;
    DWORD           status;
    DWORD           locus = QD_LOCUS_SET_FIRMWARE_PAGE;                         // 0x39000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_SET_FIRMWARE_PAGE_1;                                   // 0x39010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                               // 16
    //------------------------------------------------------------------------
    // HX0D16 B0 section 3.??: Set Current Page
    //------------------------------------------------------------------------
    command[0] = QD_CMD_SET_CURRENT_PAGE;                                       // 0x01
    command[1] = pageNumber;
    numberOfCommandBytes = 2;
    status = FQD_Write(
        unitHandle,
        (LPBYTE) command,
        numberOfCommandBytes,
        (LPDWORD) &bytesTransmitted);
    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
    {
        numberOfCommandBytes = 1;
        status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
        if (status == QD_SUCCESS)
        {
            //----------------------------------------------------------------
            // Retrieve the command acknowledge
            //----------------------------------------------------------------
            command[0] = QD_STATUS_INITIALIZE;                                  // 0x01
            status = FQD_Read(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                if (command[0] != QD_STATUS_SUCCESS)                            // 0x00
                {
                    locus = QD_LOCUS_SET_FIRMWARE_PAGE_5;                       // 0x39050000
                    status = QD_ERROR_WRITE_ACKNOWLEDGE_FAILED;                 // 0x00000028
                }
            }
            else
            {
                locus = QD_LOCUS_SET_FIRMWARE_PAGE_4;                           // 0x39040000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
        }
        else
        {
            locus = QD_LOCUS_SET_FIRMWARE_PAGE_3;                               // 0x39030000
        }
    }
    else
    {
        locus = QD_LOCUS_SET_FIRMWARE_PAGE_2;                                   // 0x39020000
        status = VerifyI2CTransfer(
            status, bytesTransmitted, numberOfCommandBytes);
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_SetFirmwarePage()
//----------------------------------------------------------------------------
// FQD_SetI2CDataRate
//
// Updates the specified device unit I2C data transfer rate
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B3 section 3.32
//----------------------------------------------------------------------------
    DWORD
FQD_SetI2CDataRate(
    HANDLE          unitHandle,
    DOUBLE          newDataRate)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 2;
    DOUBLE          TH0Float;
    BYTE            TH0Register;
    DWORD           status;
    DWORD           locus = QD_LOCUS_SET_I2C_DATA_RATE;                         // 0x3A000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_SET_I2C_DATA_RATE_1;                                   // 0x3A010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (newDataRate < QD_MINIMUM_I2C_DATA_RATE)
    {
        newDataRate = QD_MINIMUM_I2C_DATA_RATE;
    }
    else
    {
        if (newDataRate > QD_MAXIMUM_I2C_DATA_RATE)
        {
            newDataRate = QD_MAXIMUM_I2C_DATA_RATE;
        }
    }
    TH0Float = QD_SYSTEM_CLOCK_BASE / (newDataRate * 3000.0);                   // 24000000.0
    TH0Register = (BYTE) TH0Float;
    TH0Register = 255 - TH0Register;
    while (attempts--)
    {
        ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                           // 16
        //--------------------------------------------------------------------
        // HX0D16 B0 section 3.20: Set I2C Data Rate
        //--------------------------------------------------------------------
        command[0] = QD_CMD_SET_I2C_DATA_RATE;                                  // 0x1D
        command[1] = TH0Register;
        status = FQD_Write(
            unitHandle,
            (LPBYTE) command,
            numberOfCommandBytes,
            (LPDWORD) &bytesTransmitted);
        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
        {
            attempts = 0;
        }
        else
        {
            if (attempts)
            {
                Sleep(100);
            }
            else
            {
                locus = QD_LOCUS_SET_I2C_DATA_RATE_2;                           // 0x3A020000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
        }
    }                                   // end of while (attempts--)
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_SetI2CDataRate()
//----------------------------------------------------------------------------
// FQD_SetTimeouts
//
// Sets the Read and Write timeouts for the QCOM module
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0, B1 section 3.5
//----------------------------------------------------------------------------
    DWORD
FQD_SetTimeouts(
    DWORD           readTimeout,
    DWORD           writeTimeout)
{
    DWORD           status;
    //------------------------------------------------------------------------
    // Silicon Labs AN169 Rev. 1.8 section 2.8 : SI_SetTimeouts
    //------------------------------------------------------------------------
    status = (DWORD) SI_SetTimeouts(readTimeout, writeTimeout);
    if (status)
        status |= QD_LOCUS_SET_TIMEOUTS;                                        // 0x3B000000
    return status;
}                                       // end of FQD_SetTimeouts()
//----------------------------------------------------------------------------
// FQD_SetTransducerPowerState
//
// Enables or disables power to the specified transducer
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.20
//----------------------------------------------------------------------------
    DWORD
FQD_SetTransducerPowerState(
    HANDLE          unitHandle,
    BYTE            powerState)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 2;
    DWORD           status;
    DWORD           locus = QD_LOCUS_SET_TRANSDUCER_POWER_STATE;                // 0x3C000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_SET_TRANSDUCER_POWER_STATE_1;                          // 0x3C010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    while (attempts--)
    {
        ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                           // 16
        //--------------------------------------------------------------------
        // HX0D16 B0 section 3.14: Set Transducer Power State
        //--------------------------------------------------------------------
        command[0] = QD_CMD_SET_TRANSDUCER_POWER;                               // 0x17
        command[1] = powerState;        // 0x00 == Off / 0x01 == On
        status = FQD_Write(
            unitHandle,
            (LPBYTE) command,
            numberOfCommandBytes,
            (LPDWORD) &bytesTransmitted);
        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
        {
            attempts = 0;
        }
        else
        {
            if (attempts)
            {
                Sleep(100);
            }
            else
            {
                locus = QD_LOCUS_SET_TRANSDUCER_POWER_STATE_2;                  // 0x3C020000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
        }
    }                                   // end of while (attempts--)
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_SetTransducerPowerState()
//----------------------------------------------------------------------------
// FQD_SetUnitControlRegister
//
// Updates the specified device unit control register
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.22
//----------------------------------------------------------------------------
    DWORD
FQD_SetUnitControlRegister(
    HANDLE          unitHandle,
    BYTE            registerValue)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    const DWORD     numberOfCommandBytes = 2;
    DWORD           status;
    DWORD           locus = QD_LOCUS_SET_MODULE_CONTROL_REGISTER;                 // 0x3D000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_SET_MODULE_CONTROL_REGISTER_1;                           // 0x3D010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    while (attempts--)
    {
        ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                           // 16
        //--------------------------------------------------------------------
        // HX0D16 B0 section 3.5: Set Control Register
        //--------------------------------------------------------------------
        command[0] = QD_CMD_SET_CONTROL_REG;                                    // 0x0C
        command[1] = registerValue;
        status = FQD_Write(
            unitHandle,
            (LPBYTE) command,
            numberOfCommandBytes,
            (LPDWORD) &bytesTransmitted);
        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
        {
            attempts = 0;
        }
        else
        {
            if (attempts)
            {
                Sleep(100);
            }
            else
            {
                locus = QD_LOCUS_SET_MODULE_CONTROL_REGISTER_2;                   // 0x3D020000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
        }
    }                                   // end of while (attempts--)
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_SetUnitControlRegister()
//----------------------------------------------------------------------------
// FQD_TransducerMemoryPresent
//
// Determines whether the transducer attached to the specified module contains
// memory
//
// D11813 B? section 3.??
//----------------------------------------------------------------------------
    bool
FQD_TransducerMemoryPresent(
    HANDLE          unitHandle)
{
    bool            memoryPresent = false;
    int             attempts = 3;
    int             commandStringLength;
    char            *commandString = "SAC0000RADFFP";
    char            *errorString = "SACNP";
    char            *transferBuffer;
    BYTE            statusRegister;
    DWORD           bytesTransmitted;
    DWORD           numberOfCommandBytes;
    DWORD           status;
    //------------------------------------------------------------------------
    if (!unitHandle || (unitHandle == INVALID_HANDLE_VALUE))
    {
        return memoryPresent;
    }
    FQD_GetUnitStatusRegister(unitHandle, (LPBYTE) &statusRegister);
    if (statusRegister & QD_SREG_TRANSDUCER_PRESENT)
    {
        transferBuffer = (char *) malloc(QD_MAXIMUM_TRANSFER_SIZE);             // 768
        if (transferBuffer)
        {
            commandStringLength = strlen(commandString);
            while (attempts--)
            {
                //------------------------------------------------------------
                // Flush buffers ahead of the Read command
                //------------------------------------------------------------
                FQD_FlushAllBuffers(unitHandle);
                ClearBuffer(transferBuffer, QD_MAXIMUM_TRANSFER_SIZE);          // 768
                //------------------------------------------------------------
                // HX0D16 B0 section 3.11: Send I2C Command
                //------------------------------------------------------------
                transferBuffer[0] = QD_CMD_SEND_I2C_COMMAND;                    // 0x14
                transferBuffer[1] = (BYTE) ((commandStringLength - 1) / QD_PACKET_SIZE) + 1;
                numberOfCommandBytes = 2;
                status = FQD_Write(
                    unitHandle,
                    (LPBYTE) transferBuffer,
                    numberOfCommandBytes,
                    (LPDWORD) &bytesTransmitted);
                if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                {
                    for (int offset = 0; offset < commandStringLength; offset++)
                    {
                        transferBuffer[offset] = commandString[offset];
                    }
                    numberOfCommandBytes = commandStringLength;
                    status = FQD_Write(
                        unitHandle,
                        (LPBYTE) transferBuffer,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        numberOfCommandBytes = QD_MAXIMUM_TRANSFER_SIZE;
                        status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                        if (status == QD_SUCCESS)
                        {
                            status = FQD_Read(
                                unitHandle,
                                (LPBYTE) transferBuffer,
                                numberOfCommandBytes,
                                (LPDWORD) &bytesTransmitted);
                            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                            {
                                if (memcmp(transferBuffer, commandString, 10) == 0)
                                {
                                    memoryPresent = true;
                                }
                                else
                                {
                                    if (memcmp(transferBuffer, errorString, 5) == 0)
                                    {
                                        memoryPresent = false;
                                    }
                                    else
                                    {
                                        status = QD_ERROR_INVALID_I2C_REPLY;    // 0x0000001E
                                    }
                                }
                            }
                            else
                            {
                                status = VerifyI2CTransfer(
                                    status, bytesTransmitted, numberOfCommandBytes);
                            }
                        }
                    }
                    else
                    {
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }
                else
                {
                    status = VerifyI2CTransfer(
                        status, bytesTransmitted, numberOfCommandBytes);
                }
                if (status == QD_SUCCESS)
                {
                    attempts = 0;
                }
                else
                {
                    if (attempts)
                    {
                        Sleep(100);
                    }
                }
            }                           // end of while (attempts--)
            free((void *) transferBuffer);
        }                               // end of if (transferBuffer)
        else
        {
            status = QD_ERROR_MEMORY_ALLOCATION_FAILED;                         // 0x00000014
        }
    }
    return memoryPresent;
}                                       // end of FQD_TransducerMemoryPresent()
//----------------------------------------------------------------------------
// FQD_UnFormatHexFileData
//
// Strips the specified data of its hex data format and converts the character
// representations into data values, preparatory to sending the data to the
// target device as raw data, and returns the number of bytes in the resulting
// data
//
// Returns the number of unformatted bytes
//
// Note:    unformattedData must point to at least the number of bytes required
//          to hold the resulting data
//
// D11813 B1 section 3.54
//
// Confirmed identical to 1.0.8
//----------------------------------------------------------------------------
    DWORD
FQD_UnFormatHexFileData(
    LPBYTE          formattedData,
    LPBYTE          unformattedData)
{
    char            *hexFileLine = (char *) formattedData;
    DWORD           address;
    DWORD           extendedAddress = 0;
    int             recordLength;
    int             recordType = 0;
    DWORD           dataLength = 0;
    //------------------------------------------------------------------------
    if (formattedData && unformattedData)
    {
        while ((hexFileLine[0] == ':') && (recordType != 0x01))
        {
            recordLength =
                ((AtoX(hexFileLine[1]) << 4) & 0xF0) | (AtoX(hexFileLine[2]) & 0x0F);
            recordType =
                ((AtoX(hexFileLine[7]) << 4) & 0xF0) | (AtoX(hexFileLine[8]) & 0x0F);
            switch (recordType)
            {
                case 0x00 :
                    address =
                        ((AtoX(hexFileLine[3]) << 12) & 0xF000) | ((AtoX(hexFileLine[4]) << 8) & 0x0F00) |
                        ((AtoX(hexFileLine[5]) << 4) & 0x00F0) | (AtoX(hexFileLine[6]) & 0x000F);
                    dataLength = Max(dataLength, (address + extendedAddress + recordLength));
                    for (int offset = 0; offset < (recordLength * 2); offset += 2)
                    {
                        unformattedData[address + extendedAddress + (offset / 2)] =
                            ((AtoX(hexFileLine[offset + 9]) << 4) & 0xF0) |
                            (AtoX(hexFileLine[offset + 10]) & 0x0F);
                    }
                    break;
                case 0x02 :
                case 0x04 :
                case 0x05 :
                    if (recordType == 0x05)
                    {
                        extendedAddress =
                            ((AtoX(hexFileLine[9]) << 28) & 0xF0000000) |
                            ((AtoX(hexFileLine[10]) << 24) & 0x0F000000) |
                            ((AtoX(hexFileLine[11]) << 20) & 0x00F00000) |
                            ((AtoX(hexFileLine[12]) << 16) & 0x000F0000) |
                            ((AtoX(hexFileLine[13]) << 12) & 0x0000F000) |
                            ((AtoX(hexFileLine[14]) << 8) & 0x00000F00) |
                            ((AtoX(hexFileLine[15]) << 4) & 0x000000F0) |
                            (AtoX(hexFileLine[16]) & 0x0000000F);
                        //----------------------------------------------------
                        // Note: extendedAddress is the EIP register value for
                        // the subsequent code data
                        //----------------------------------------------------
                    }
                    else
                    {
                        extendedAddress =
                            ((AtoX(hexFileLine[9]) << 12) & 0xF000) |
                            ((AtoX(hexFileLine[10]) << 8) & 0x0F00) |
                            ((AtoX(hexFileLine[11]) << 4) & 0x00F0) |
                            (AtoX(hexFileLine[12]) & 0x000F);
                        if (recordType == 0x02)
                        {
                            extendedAddress = (extendedAddress << 4) & 0xFFFF0;
                        }
                        else
                        {
                            extendedAddress = (extendedAddress << 16) & 0xFFFF0000;
                        }
                    }
                default :
                    break;
            }                           // end of switch (recordType)
            hexFileLine = &hexFileLine[(recordLength * 2) + 13];
        }                               // end of while ((hexFileLine[0] == ':') && (recordType != 0x01))
    }                                   // end of if (formattedData && unformattedData)
    return dataLength;
}                                       // end of FQD_UnFormatHexFileData()
//----------------------------------------------------------------------------
// FQD_WaitForReply
//
// Checks the Receive Queue to ensure that it is ready for processing and that
// at least the specified number of bytes is in the queue, waiting to be read
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.55
//----------------------------------------------------------------------------
    DWORD
FQD_WaitForReply(
    HANDLE          unitHandle,
    DWORD           bytesExpected)
{
    bool            timedOut = false;
    DWORD           bytesInQueue;
    DWORD           queueStatus;
    DWORD           startTime = GetTickCount();
    DWORD           status;
    DWORD           locus = QD_LOCUS_WAIT_FOR_REPLY;                            // 0x3E000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_WAIT_FOR_REPLY_1;                                      // 0x3E010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    do
    {
        bytesInQueue = 0;
        queueStatus = 0;
        status = FQD_CheckReceiveQueue(unitHandle, &bytesInQueue, &queueStatus);
        if (status == QD_SUCCESS)
        {
            if ((GetTickCount() - startTime) > QD_CHECK_RECEIVE_QUEUE_TIMEOUT)  // 500 (ms)
            {
                timedOut = true;
                status = QD_ERROR_DEVICE_TIMED_OUT;                             // 0x00000021
            }
            if (((bytesInQueue < bytesExpected) || !(queueStatus & SI_RX_READY)) && !timedOut)
            {
                Sleep(10);
            }
        }
        else
        {
            break;
        }
        if (queueStatus & SI_RX_OVERRUN)                                        // 0x01
        {
            FQD_FlushAllBuffers(unitHandle);
            CancelIo(unitHandle);
            Sleep(2000);
            status = QD_ERROR_RECEIVE_QUEUE_OVERRUN;                            // 0x00000022
        }
    }
    while ((bytesInQueue < bytesExpected) && !timedOut);
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_WaitForReply()
//----------------------------------------------------------------------------
// FQD_Write
//
// Writes data to the specified device unit
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.56
//----------------------------------------------------------------------------
    DWORD
FQD_Write(
    HANDLE          unitHandle,
    LPBYTE          writeBuffer,
    DWORD           writeBufferSize,
    LPDWORD         bytesWritten)
{
    DWORD           status;
    DWORD           locus = QD_LOCUS_WRITE;                                     // 0x3F000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_WRITE_1;                                               // 0x3F010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (writeBuffer && bytesWritten)
    {
        //--------------------------------------------------------------------
        // Silicon Labs AN169 Rev. 1.8 section 2.6 : SI_Write
        //--------------------------------------------------------------------
        *bytesWritten = 0;
        status = (DWORD) SI_Write(
            unitHandle,
            (LPVOID) writeBuffer,
            writeBufferSize,
            bytesWritten,
            NULL);
        if (status == QD_SUCCESS)
        {
            if (*bytesWritten != writeBufferSize)
            {
                //------------------------------------------------------------
                // The data transfer possibly resulted in a data underrun
                //------------------------------------------------------------
                locus = QD_LOCUS_WRITE_6;                                       // 0x3F060000
                status = QD_ERROR_DATA_TRANSFER_FAILURE;                        // 0x00000020
            }
        }
        else
        {
            locus = QD_LOCUS_WRITE_5;                                           // 0x3F050000
        }
    }                                   // end of if (writeBuffer && bytesWritten)
    else
    {
        if (!writeBuffer && !bytesWritten)
        {
            //----------------------------------------------------------------
            // Both writeBuffer and bytesWritten are null
            //----------------------------------------------------------------
            locus = QD_LOCUS_WRITE_4;                                           // 0x3F040000
        }
        else
        {
            if (writeBuffer)
            {
                //------------------------------------------------------------
                // bytesWritten is null
                //------------------------------------------------------------
                locus = QD_LOCUS_WRITE_3;                                       // 0x3F030000
            }
            else
            {
                //------------------------------------------------------------
                // writeBuffer is null
                //------------------------------------------------------------
                locus = QD_LOCUS_WRITE_2;                                       // 0x3F020000
            }
        }
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_Write()
//----------------------------------------------------------------------------
// FQD_WriteCoefficientDataToDevice
//
// Writes the specified coefficient data to the memory of the specified device,
// the QCOM memory in the case of an analog transducer, and the transducer
// memory in the case of a digital one
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.57
//----------------------------------------------------------------------------
    DWORD
FQD_WriteCoefficientDataToDevice(
    HANDLE          unitHandle,
    LPBYTE          coefficientData)
{
    BYTE            device = QD_DEVICE_TRANSDUCER;                              // 0
    BYTE            statusRegister = 0;
    BYTE            transducerType = QD_TRANSDUCER_TYPE_ABSENT;                 // 0
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetUnitStatusRegister(unitHandle, (LPBYTE) &statusRegister);
    if (status == QD_SUCCESS)
    {
        transducerType = statusRegister & QD_SREG_TRANSDUCER_TYPE_MASK;         // 0x07
    }
    else
    {
        status = QD_SUCCESS;
    }
    if ((transducerType == QD_TRANSDUCER_TYPE_ABSENT) ||                        // 0
        (transducerType == QD_TRANSDUCER_TYPE_FREQUENCY) ||                     // 1
        (transducerType == QD_TRANSDUCER_TYPE_DIGITAL_NOMEM))                   // 5
        device = QD_DEVICE_MODULE;                                              // 1
    for (BYTE pageNumber = 0; pageNumber < QD_NUMBER_OF_LOWER_QMEM_PAGES; pageNumber++)
    {
        if (status == QD_SUCCESS)
        {
            status = FQD_WriteCoefficientDataToTargetPage(
                unitHandle,
                device,
                pageNumber,
                coefficientData);
        }
    }
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_WRITE_CF_DATA_TO_DEVICE;                             // 0x40000000
    }
    return status;
}                                       // end of FQD_WriteCoefficientDataToDevice()
//----------------------------------------------------------------------------
// FQD_WriteCoefficientDataToHexFile
//
// Writes the coefficient data to the specified file path
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.58
//
// Confirmed identical to 1.0.8
//----------------------------------------------------------------------------
    DWORD
FQD_WriteCoefficientDataToHexFile(
    LPBYTE          coefficientData,
    LPBYTE          pathName)
{
    char            *dataPointer;
    long            bytesWritten;
    errno_t         result;
    LPBYTE          fileData;
    FILE            *filePointer;
    DWORD           fileSize;
    DWORD           status = QD_SUCCESS;                                        // 0x00000000
    DWORD           locus = QD_LOCUS_WRITE_CF_DATA_TO_HEX_FILE;                 // 0x41000000
    //------------------------------------------------------------------------
    if (coefficientData && pathName)
    {
        if (strlen((char *) coefficientData) && strlen((char *) pathName))
        {
//            if (FileExists((char *) pathName))      // bug fixed in 1.0.8
//            {
                result = fopen_s(&filePointer, (char *) pathName, "wb");
                if (filePointer && (result == 0))
                {
                    fileData = (LPBYTE) malloc(QD_COEFFICIENT_DATA_HEX_FILE_SIZE + 1);  // 734
                    if (fileData)
                    {
                        fileSize = FQD_FormatCoefficientHexFileData(coefficientData, fileData); // verified
                        //----------------------------------------------------
                        // Write out the entire file
                        //----------------------------------------------------
                        dataPointer = (char *) fileData;
                        bytesWritten = (long) fwrite(
                            (void *) dataPointer,
                            1,
                            fileSize,
                            filePointer);
                        if (bytesWritten == fileSize)
                        {
                        }
                        else
                        {
                            locus = QD_LOCUS_WRITE_CF_DATA_TO_HEX_FILE_6;       // 0x41060000
                            status = QD_ERROR_FILE_SIZE_MISMATCH;               // 0x00000017
                        }
                        free((void *) fileData);
                    }                   // end of if (fileData)
                    else
                    {
                        locus = QD_LOCUS_WRITE_CF_DATA_TO_HEX_FILE_5;           // 0x41050000
                        status = QD_ERROR_MEMORY_ALLOCATION_FAILED;             // 0x00000014
                    }
                    fclose(filePointer);
                }                       // end of if (filePointer && (result == 0))
//            }                           // end of if (FileExists(pathName))
//            else
//            {
//                locus = QD_LOCUS_WRITE_CF_DATA_TO_HEX_FILE_3;                   // 0x41030000
//                status = QD_ERROR_FILE_OPEN_FAILURE;                            // 0x00000015
//            }
        }                               // end of if (strlen((char *) coefficientData) && ...)
        else
        {
            locus = QD_LOCUS_WRITE_CF_DATA_TO_HEX_FILE_2;                       // 0x41020000
            status = QD_ERROR_FILE_NOT_FOUND;                                   // 0x00000070
        }
    }                                   // end of if (coefficientData && pathName)
    else
    {
        locus = QD_LOCUS_WRITE_CF_DATA_TO_HEX_FILE_1;                           // 0x41010000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
    {
        ClearBuffer(coefficientData, QD_COEFFICIENT_DATA_SIZE);                 // 256
        status |= locus;
    }
    return status;
}                                       // end of FQD_WriteCoefficientDataToHexFile()
//----------------------------------------------------------------------------
// FQD_WriteCoefficientDataToTargetPage
//
// Writes the specified coefficient data to the memory of the specified device
// at the the specified page
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.14
//----------------------------------------------------------------------------
    DWORD
FQD_WriteCoefficientDataToTargetPage(
    HANDLE          unitHandle,
    BYTE            targetDevice,
    BYTE            pageNumber,
    LPBYTE          coefficientData)
{
    int             attempts = 3;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    DWORD           devPage;
    DWORD           numberOfCommandBytes;
    DWORD           status = QD_SUCCESS;
    //------------------------------------------------------------------------
    // The destination byte (devPage) at 0x00FF0000 replaces the locus, and is
    // mapped as follows:
    //
    // The highest two bits (0xC0) = device, the lower six bits (0x3F) = pageNumber
    //
    //      00 000000b = Write to the transducer memory page 0  (0x4200XXXX)
    //      00 000001b = Write to the transducer memory page 1  (0x4201XXXX)
    //      00 000010b = Write to the transducer memory page 2  (0x4202XXXX)
    //          .
    //          .
    //          .
    //      00 111111b = Write to the transducer memory page 63  (0x423FXXXX)
    //
    //      01 000000b = Write to the QCOM module memory page 0 (0x4240XXXX)
    //      01 000001b = Write to the QCOM module memory page 1 (0x4241XXXX)
    //      01 000010b = Write to the QCOM module memory page 2 (0x4242XXXX)
    //          .
    //          .
    //          .
    //      01 111111b = Write to the QCOM module memory page 63 (0x427FXXXX)
    //
    // The destination byte will reflect the target device and memory page
    // until over-written by an error locus
    //------------------------------------------------------------------------
    devPage = (((targetDevice << 22) & 0x00C00000) | ((pageNumber << 16) & 0x003F0000));
    devPage |= QD_LOCUS_WRITE_CF_DATA_TO_TARGET_PAGE;                           // 0x42000000
    if (!unitHandle || (unitHandle == INVALID_HANDLE_VALUE))
        return (devPage | QD_ERROR_INVALID_HANDLE);                             // 0x00000001
    if (coefficientData)
    {
        switch (targetDevice)
        {
            case QD_DEVICE_TRANSDUCER :                                         // 0
            case QD_DEVICE_MODULE :                                             // 1
                while (attempts--)
                {
                    ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);               // 16
                    //--------------------------------------------------------
                    // HX0D16 B0 section 3.10: Write Coefficient File Data to
                    // Device Memory
                    //--------------------------------------------------------
                    command[0] = QD_CMD_WRITE_CF_TO_DEVICE;                     // 0x13
                    command[1] = targetDevice;
                    command[2] = pageNumber;
                    numberOfCommandBytes = 3;
                    status = FQD_Write(
                        unitHandle,
                        (LPBYTE) command,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        numberOfCommandBytes = QD_COEFFICIENT_DATA_SIZE;        // 256
                        status = FQD_Write(
                            unitHandle,
                            (LPBYTE) coefficientData,
                            numberOfCommandBytes,
                            (LPDWORD) &bytesTransmitted);
                        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                        {
                            numberOfCommandBytes = 1;
                            command[0] = QD_STATUS_INITIALIZE;                  // 0x01
                            status = FQD_Read(
                                unitHandle,
                                (LPBYTE) command,
                                numberOfCommandBytes,
                                (LPDWORD) &bytesTransmitted);
                            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                            {
                                if (command[0] != QD_STATUS_SUCCESS)            // 0x00
                                {
                                    status = QD_ERROR_WRITE_ACKNOWLEDGE_FAILED; // 0x00000028
                                    Sleep(2000);
                                }
                            }
                            else
                            {
                                status = VerifyI2CTransfer(
                                    status, bytesTransmitted, numberOfCommandBytes);
                            }
                        }
                        else
                        {
                            status = VerifyI2CTransfer(
                                status, bytesTransmitted, numberOfCommandBytes);
                        }
                    }
                    else
                    {
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                    if (status == QD_SUCCESS)
                    {
                        attempts = 0;
                    }
                    else
                    {
                        if (attempts)
                        {
                            status = QD_SUCCESS;
                            Sleep(100);
                        }
                    }
                }                       // end of while (attempts--)
                break;
            default :
                status = QD_ERROR_INVALID_PARAMETER;                            // 0x00000006
                status |= (targetDevice << 8);
                break;
        }                               // end of switch (targetDevice)
    }                                   // end of if (coefficientData)
    else
    {
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= devPage;
    return status;
}                                       // end of FQD_WriteCoefficientDataToTargetPage()
//----------------------------------------------------------------------------
// FQD_WriteCoefficientDataToUnitPage
//
// Writes the specified coefficient data to the memory of the module at the
// specified page
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.59
//----------------------------------------------------------------------------
    DWORD
FQD_WriteCoefficientDataToUnitPage(
    HANDLE          unitHandle,
    BYTE            pageNumber,
    LPBYTE          coefficientData)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_WriteCoefficientDataToTargetPage(
        unitHandle,
        QD_DEVICE_MODULE,                                                       // 1
        pageNumber,
        coefficientData);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_WRITE_CF_DATA_TO_MODULE_PAGE;                          // 0x43000000
    }
    return status;
}                                       // end of FQD_WriteCoefficientDataToUnitPage()
//----------------------------------------------------------------------------
// FQD_WriteFirmwareData
//
// Writes the firmware data to the specified device unit
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    firmwareData must point to at least QD_FIRMWARE_MAXIMUM_DATA_SIZE
//          (63 * 1024) bytes of available memory
//
// D11813 B? section 3.??
//----------------------------------------------------------------------------
    DWORD
FQD_WriteFirmwareData(
    HANDLE          unitHandle,
    LPBYTE          firmwareData)
{
    DWORD           status = QD_SUCCESS;
    DWORD           locus = QD_LOCUS_WRITE_FIRMWARE_DATA;               // 0x44000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_WRITE_FIRMWARE_DATA_1;                         // 0x44010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    if (firmwareData)
    {
        if (strlen((char *) firmwareData))
        {
        }                               // end of if (strlen((char *) firmwareData))
        else
        {
            locus = QD_LOCUS_WRITE_FIRMWARE_DATA_3;                     // 0x44030000
            status = QD_ERROR_ZERO_LENGTH_STRING_PARAMETER;                     // 0x0000002B
        }
    }                                   // end of if (firmwareData)
    else
    {
        locus = QD_LOCUS_WRITE_FIRMWARE_DATA_2;                         // 0x44020000
        status = QD_ERROR_NULL_POINTER_PARAMETER;                               // 0x0000002A
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_WriteFirmwareData()
//----------------------------------------------------------------------------
// FQD_WriteFirmwarePage
//
// Writes the firmware data to the specified page of the module
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.60
//----------------------------------------------------------------------------
    DWORD
FQD_WriteFirmwarePage(
    HANDLE          unitHandle,
    LPBYTE          firmwareData,
    BYTE            pageNumber,
    LPWORD          pageCRC)
{
    int             pageOffset;
    BYTE            *pageData;
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    DWORD           numberOfCommandBytes;
    DWORD           status;
    DWORD           locus = QD_LOCUS_WRITE_FIRMWARE_PAGE;                       // 0x45000000
    //------------------------------------------------------------------------
    status = FQD_EraseFirmwarePage(unitHandle, pageNumber);
    if (status == QD_SUCCESS)
    {
        if (firmwareData && pageCRC)
        {
            *pageCRC = 0;
            pageData = (BYTE *) malloc(QD_FIRMWARE_PAGE_SIZE);                  // 512
            if (pageData)
            {
                for (BYTE pageHalf = 0; pageHalf < 2; pageHalf++)
                {
                    ClearBuffer(pageData, QD_FIRMWARE_PAGE_SIZE);               // 512
                    ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);               // 16
                    //--------------------------------------------------------
                    // HX0D16 B0 section 3.??: Erase Current Page
                    //--------------------------------------------------------
                    pageData[0] = QD_CMD_WRITE_CURRENT_PAGE;                    // 0x03
                    pageData[1] = pageHalf;
                    pageOffset =
                        (pageNumber * QD_FIRMWARE_PAGE_SIZE) + (pageHalf * QD_FIRMWARE_PAGE_SIZE / 2);
                    memcpy(&pageData[2], &firmwareData[pageOffset], (QD_FIRMWARE_PAGE_SIZE / 2));
                    numberOfCommandBytes = (QD_FIRMWARE_PAGE_SIZE / 2) + 2;
                    status = FQD_Write(
                        unitHandle,
                        (LPBYTE) pageData,
                        numberOfCommandBytes,
                        (LPDWORD) &bytesTransmitted);
                    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                    {
                        numberOfCommandBytes = 1;
                        status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                        if (status == QD_SUCCESS)
                        {
                            //------------------------------------------------
                            // Retrieve the command status (first ACK, indicating
                            // that the device has received the data)
                            //------------------------------------------------
                            command[0] = QD_STATUS_INITIALIZE;                      // 0x01
                            status = FQD_Read(
                                unitHandle,
                                (LPBYTE) command,
                                numberOfCommandBytes,
                                (LPDWORD) &bytesTransmitted);
                            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                            {
                                if (command[0] == QD_STATUS_SUCCESS)                // 0x00
                                {
                                    status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                                    if (status == QD_SUCCESS)
                                    {
                                        //------------------------------------
                                        // Retrieve the command status (second
                                        // ACK, indicating that the device has
                                        // written the data to the flash)
                                        //------------------------------------
                                        command[0] = QD_STATUS_INITIALIZE;                          // 0x01
                                        status = FQD_Read(
                                            unitHandle,
                                            (LPBYTE) command,
                                            numberOfCommandBytes,
                                            (LPDWORD) &bytesTransmitted);
                                        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                                        {
                                            if (command[0] == QD_STATUS_SUCCESS)                    // 0x00
                                            {
                                                if (pageHalf == 1)
                                                {
                                                    numberOfCommandBytes = 2;
                                                    status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
                                                    if (status == QD_SUCCESS)
                                                    {
                                                        //--------------------
                                                        // Read the CRC
                                                        //--------------------
                                                        ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);        
                                                        status = FQD_Read(
                                                            unitHandle,
                                                            (LPBYTE) command,
                                                            numberOfCommandBytes,
                                                            (LPDWORD) &bytesTransmitted);
                                                        if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
                                                        {
                                                            *pageCRC = (command[0] << 8) | command[1];
                                                        }
                                                        else
                                                        {
                                                            locus = QD_LOCUS_WRITE_FIRMWARE_PAGE_B; // 0x450B0000
                                                            status = VerifyI2CTransfer(
                                                                status, bytesTransmitted, numberOfCommandBytes);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        locus = QD_LOCUS_WRITE_FIRMWARE_PAGE_A;     // 0x450A0000
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                locus = QD_LOCUS_WRITE_FIRMWARE_PAGE_9;             // 0x45090000
                                                status = QD_ERROR_WRITE_ACKNOWLEDGE_FAILED;         // 0x00000028
                                            }
                                        }
                                        else
                                        {
                                            locus = QD_LOCUS_WRITE_FIRMWARE_PAGE_8;                 // 0x45080000
                                            status = VerifyI2CTransfer(
                                                status, bytesTransmitted, numberOfCommandBytes);
                                        }
                                    }
                                    else
                                    {
                                        locus = QD_LOCUS_WRITE_FIRMWARE_PAGE_7; // 0x45070000
                                    }
                                }
                                else
                                {
                                    locus = QD_LOCUS_WRITE_FIRMWARE_PAGE_6;     // 0x45060000
                                    status = QD_ERROR_WRITE_ACKNOWLEDGE_FAILED; // 0x00000028
                                }
                            }
                            else
                            {
                                locus = QD_LOCUS_WRITE_FIRMWARE_PAGE_5;         // 0x45050000
                                status = VerifyI2CTransfer(
                                    status, bytesTransmitted, numberOfCommandBytes);
                            }
                        }
                        else
                        {
                            locus = QD_LOCUS_WRITE_FIRMWARE_PAGE_4;             // 0x45040000
                        }
                    }
                    else
                    {
                        locus = QD_LOCUS_WRITE_FIRMWARE_PAGE_3;                 // 0x45030000
                        status = VerifyI2CTransfer(
                            status, bytesTransmitted, numberOfCommandBytes);
                    }
                }                       // end of for (BYTE pageHalf = 0; ...)
                free((void *) pageData);
            }                           // end of if (pageData)
            else
            {
                locus = QD_LOCUS_WRITE_FIRMWARE_PAGE_2;                         // 0x45020000
                status = QD_ERROR_MEMORY_ALLOCATION_FAILED;                     // 0x00000014
            }
        }                               // end of if (firmwareData && pageCRC)
        else
        {
            locus = QD_LOCUS_WRITE_FIRMWARE_PAGE_1;                             // 0x45010000
            status = QD_ERROR_NULL_POINTER_PARAMETER;                           // 0x0000002A
        }
        if (status)
            status |= locus;
    }                                   // end of if (status == QD_SUCCESS)
    return status;
}                                       // end of FQD_WriteFirmwarePage()
//----------------------------------------------------------------------------
// FQD_WriteFirmwareSignature
//
// Writes the signature to the specified module firmware
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 B1 section 3.61
//----------------------------------------------------------------------------
    DWORD
FQD_WriteFirmwareSignature(
    HANDLE          unitHandle)
{
    BYTE            command[QD_COMMAND_BUFFER_SIZE];                            // 16
    DWORD           bytesTransmitted;
    DWORD           numberOfCommandBytes;
    DWORD           status;
    DWORD           locus = QD_LOCUS_WRITE_FIRMWARE_SIGNATURE;                  // 0x46000000
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
        locus = QD_LOCUS_WRITE_FIRMWARE_SIGNATURE_1;                            // 0x46010000
    else
        return (locus | QD_ERROR_INVALID_HANDLE);                               // 0x00000001
    ClearBuffer(command, QD_COMMAND_BUFFER_SIZE);                               // 16
    //------------------------------------------------------------------------
    // HX0D16 B0 section 3.??: Write Signature
    //------------------------------------------------------------------------
    command[0] = QD_CMD_WRITE_SIGNATURE_TO_FLASH;                               // 0x07
    command[1] = (BYTE) (QD_FIRMWARE_SIGNATURE & 0x00FF);                       // 0x3DC2
    command[2] = (BYTE) ((QD_FIRMWARE_SIGNATURE >> 8) & 0x00FF);
    numberOfCommandBytes = 3;
    status = FQD_Write(
        unitHandle,
        (LPBYTE) command,
        numberOfCommandBytes,
        (LPDWORD) &bytesTransmitted);
    if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
    {
        numberOfCommandBytes = 1;
        status = FQD_WaitForReply(unitHandle, numberOfCommandBytes);
        if (status == QD_SUCCESS)
        {
            //----------------------------------------------------------------
            // Retrieve the command acknowledge
            //----------------------------------------------------------------
            command[0] = QD_STATUS_INITIALIZE;                                  // 0x01
            status = FQD_Read(
                unitHandle,
                (LPBYTE) command,
                numberOfCommandBytes,
                (LPDWORD) &bytesTransmitted);
            if ((status == QD_SUCCESS) && (bytesTransmitted == numberOfCommandBytes))
            {
                if (command[0] != QD_STATUS_SUCCESS)                            // 0x00
                {
                    if (command[0] == QD_ERROR_SIGNATURE_NOT_ERASED)            // 0x03
                    {
                        locus = QD_LOCUS_WRITE_FIRMWARE_SIGNATURE_5;            // 0x46050000
                        status = QD_ERROR_FIRMWARE_SIGNATURE_NOT_ERASED;        // 0x00000023
                    }
                    else
                    {
                        locus = QD_LOCUS_WRITE_FIRMWARE_SIGNATURE_6;            // 0x46060000
                        status = QD_ERROR_WRITE_ACKNOWLEDGE_FAILED;             // 0x00000028
                    }
                }
            }
            else
            {
                locus = QD_LOCUS_WRITE_FIRMWARE_SIGNATURE_4;                    // 0x46040000
                status = VerifyI2CTransfer(
                    status, bytesTransmitted, numberOfCommandBytes);
            }
        }
        else
        {
            locus = QD_LOCUS_WRITE_FIRMWARE_SIGNATURE_3;                        // 0x46030000
        }
    }
    else
    {
        locus = QD_LOCUS_WRITE_FIRMWARE_SIGNATURE_2;                            // 0x46020000
        status = VerifyI2CTransfer(
            status, bytesTransmitted, numberOfCommandBytes);
    }
    if (status)
        status |= locus;
    return status;
}                                       // end of FQD_WriteFirmwareSignature()
//----------------------------------------------------------------------------
// DisplayStackTrace
//
// Displays a stack trace
//----------------------------------------------------------------------------
    void
DisplayStackTrace(
    String          ^messageString)
{
    String          ^stack;
    //------------------------------------------------------------------------
    if (StringSet(messageString))
    {
        stack = String::Concat(
            messageString,
            Environment::NewLine,
            Environment::StackTrace);
    }
    else
    {
        stack = String::Concat(Environment::StackTrace);
    }
    //------------------------------------------------------------------------
    // Create an invisible window, from which to force the modal window to the
    // forefront
    //------------------------------------------------------------------------
    Form ^invisibleWindow = gcnew Form;
    invisibleWindow->Size = Drawing::Size(1, 1);
    invisibleWindow->Location = Point(1, 1);
    invisibleWindow->Show();
    invisibleWindow->Focus();
    invisibleWindow->BringToFront();
    invisibleWindow->TopMost = true;
    if (invisibleWindow->CanSelect)
        invisibleWindow->Select();
    invisibleWindow->Visible = false;
    MessageBox::Show(
        invisibleWindow,
        stack,
        _T("Stack Trace"),
        MessageBoxButtons::OK,
        MessageBoxIcon::Exclamation);
    delete invisibleWindow;
}                                       // end of DisplayStackTrace()
//----------------------------------------------------------------------------
// ReadyForIO
//
// Determines whether I/O bus is ready to transmit data
//
// D11813 B13 section 3.??
//----------------------------------------------------------------------------
    bool
ReadyForIO(
    HANDLE          unitHandle)
{
    bool            readyForIO = true;
    bool            timedOut = false;
    DWORD           bytesInQueue;
    DWORD           queueStatus;
    DWORD           startTime = GetTickCount();
    DWORD           status;
    //------------------------------------------------------------------------
    if (unitHandle && (unitHandle != INVALID_HANDLE_VALUE))
    {
        do
        {
            bytesInQueue = 0;
            queueStatus = 0;
            status = FQD_CheckReceiveQueue(unitHandle, &bytesInQueue, &queueStatus);
            if (status == QD_SUCCESS)
            {
                if ((GetTickCount() - startTime) > QD_CHECK_RECEIVE_QUEUE_TIMEOUT)  // 500 (ms)
                {
                    readyForIO = false;
                    timedOut = true;
                }
                if ((bytesInQueue || !(queueStatus & SI_RX_READY)) && !timedOut)
                {
                    Sleep(10);
                }
            }
            else
            {
                readyForIO = false;
                break;
            }
            if (queueStatus & SI_RX_OVERRUN)                                    // 0x01
            {
                readyForIO = false;
                FQD_FlushAllBuffers(unitHandle);
            }
        }
        while (bytesInQueue && !timedOut);
    }
    else
        readyForIO = false;
    return readyForIO;
}                                       // end of ReadyForIO()
//----------------------------------------------------------------------------
// VerifyI2CTransfer
//
// Determines whether the I2C transfer completed without problems by checking
// the number of bytes actually transmitted against the expected number of
// bytes that should have been transmitted
//
// Returns: 0           Success
//          nonzero     Failure
//----------------------------------------------------------------------------
    DWORD
VerifyI2CTransfer(
    DWORD           status,
    DWORD           bytesTransmitted,
    DWORD           numberOfCommandBytes)
{
    //------------------------------------------------------------------------
    if ((status == QD_SUCCESS) && (bytesTransmitted != numberOfCommandBytes))
    {
        Sleep(100);
        status = QD_ERROR_DATA_TRANSFER_FAILURE;                                // 0x00000020
    }
    if (status)
    {
        DisplayStackTrace(
            String::Format("VerifyI2CTransfer : status = 0x{0:X8} xmit = {1:D} cmd = {2:D}",
                status, bytesTransmitted, numberOfCommandBytes));
        FQD_DLLErrorEncountered = true;
    }
    return status;
}                                       // end of VerifyI2CTransfer()
//----------------------------------------------------------------------------
// Functions below this line have been deprecated
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// FQD_CalcPT (deprecated)
//
// Returns the pressure in PSI and temperature in Cesius for the specified
//      transducer, given the transducer coefficients and the counts
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.11
//----------------------------------------------------------------------------
    DWORD
FQD_CalcPT(
    BYTE            PorT,
    LPBYTE          coefficientData,
    DWORD           pressureCount,
    DWORD           temperatureCount,
    DOUBLE          *result)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_CalculatePressureOrTemperature(
        PorT,
        coefficientData,
        pressureCount,
        temperatureCount,
        result);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_CALC_PT;                                           // 0xD0000000
    }
    return status;
}                                       // end of FQD_CalcPT()
//----------------------------------------------------------------------------
// FQD_CheckRXQueue (deprecated)
//
// Returns the status of the Receive Queue
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.7
//----------------------------------------------------------------------------
    DWORD
FQD_CheckRXQueue(
    HANDLE          unitHandle,
    LPDWORD         numberOfBytesInQueue,
    LPDWORD         queueStatus)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_CheckReceiveQueue(
        unitHandle,
        numberOfBytesInQueue,
        queueStatus);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_CHECK_RX_QUEUE;                                    // 0xD1000000
    }
    return status;
}                                       // end of FQD_CheckRXQueue()
//----------------------------------------------------------------------------
// FQD_ClearError (deprecated)
//
// Clears the specified module internal error register
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0, B1 section 3.31
//----------------------------------------------------------------------------
    DWORD
FQD_ClearError(
    HANDLE          unitHandle)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_ClearInternalError(unitHandle);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_CLEAR_ERROR;                                       // 0xD2000000
    }
    return status;
}                                       // end of FQD_ClearError()
//----------------------------------------------------------------------------
// FQD_GetCadenceTmr (deprecated)
//
// Retrieves the cadence timer used to acquire transducer counts
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.26
//----------------------------------------------------------------------------
    DWORD
FQD_GetCadenceTmr(
    HANDLE          unitHandle,
    LPDWORD         cadenceTimerValue)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetCadenceTimer(unitHandle, cadenceTimerValue);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_GET_CADENCE_TIMER;                                 // 0xD3000000
    }
    return status;
}                                       // end of FQD_GetCadenceTmr()
//----------------------------------------------------------------------------
// FQD_GetCFfromFile (deprecated)
//
// Retrieves the coefficient data from the specified file path
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    coefficientData must point to at least QD_COEFFICIENT_DATA_SIZE (256)
//          bytes of available memory
//
// D11813 A0 section 3.15
//----------------------------------------------------------------------------
    DWORD
FQD_GetCFfromFile(
    LPBYTE          pathName,
    LPBYTE          coefficientData)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_ReadCoefficientDataFromHexFile(pathName, coefficientData);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_GET_CF_FROM_FILE;                                  // 0xD4000000
    }
    return status;
}                                       // end of FQD_GetCFfromFile()
//----------------------------------------------------------------------------
// FQD_GetCFfromMemDevice (deprecated)
//
// Retrieves the coefficient data from the memory of the specified device, the
// QCOM memory in the case of an analog transducer, and the transducer memory
// in the case of a digital one
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    coefficientData must point to at least QD_COEFFICIENT_DATA_SIZE (256)
//          bytes of available memory
//
// D11813 A0 section 3.13
//----------------------------------------------------------------------------
    DWORD
FQD_GetCFfromMemDevice(
    HANDLE          unitHandle,
    BYTE            device,
    BYTE            pageNumber,
    LPBYTE          coefficientData)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_ReadCoefficientDataFromSourcePage(
        unitHandle,
        device,
        pageNumber,
        coefficientData);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_GET_CF_FROM_DEVICE;                                // 0xD5000000
    }
    return status;
}                                       // end of FQD_GetCFfromMemDevice()
//----------------------------------------------------------------------------
// FQD_GetCounts (deprecated)
//
// Returns the pressure and / or temperature counts for the specified transducer
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    The function retrieves both counts, regardless of the PorT setting
//
// D11813 A0 section 3.10
//----------------------------------------------------------------------------
    DWORD
FQD_GetCounts(
    HANDLE          unitHandle,
    BYTE            PorT,
    LPDWORD         pressureCount,
    LPDWORD         temperatureCount)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetTransducerCounts(
        unitHandle,
        pressureCount,
        temperatureCount);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_GET_COUNTS;                                        // 0xD6000000
    }
    return status;
}                                       // end of FQD_GetCounts()
//----------------------------------------------------------------------------
// FQD_GetErrorCode (deprecated)
//
// Retrieves the error code
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0, B1 section 3.30
//----------------------------------------------------------------------------
    DWORD
FQD_GetErrorCode(
    HANDLE          unitHandle,
    LPWORD          errorCode)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetInternalErrorCode(unitHandle, errorCode);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_GET_ERROR_CODE;                                    // 0xD7000000
    }
    return status;
}                                       // end of FQD_GetErrorCode()
//----------------------------------------------------------------------------
// FQD_GetI2CBaudRate (deprecated)
//
// Retrieves the specified device unit I2C data rate
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0, B1 section 3.33
//----------------------------------------------------------------------------
    DWORD
FQD_GetI2CBaudRate(
    HANDLE          unitHandle,
    DOUBLE          *currentBaudRate)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetI2CDataRate(unitHandle, currentBaudRate);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_GET_I2C_BAUD_RATE;                                 // 0xD8000000
    }
    return status;
}                                       // end of FQD_GetI2CBaudRate()
//----------------------------------------------------------------------------
// FQD_GetNumDevices (deprecated)
//
// Returns the number of QCOM device units
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.1
//----------------------------------------------------------------------------
    DWORD
FQD_GetNumDevices(
    LPDWORD         numberOfDevices)
{
    DWORD           status;
    //------------------------------------------------------------------------
    // Silicon Labs AN169 Rev. 1.8 section 2.1 : SI_GetNumDevices
    //------------------------------------------------------------------------
    status = (DWORD) SI_GetNumDevices(numberOfDevices);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_GET_NUM_DEVICES;                                   // 0xD9000000
    }
    return status;
}                                       // end of FQD_GetNumDevices()
//----------------------------------------------------------------------------
// FQD_GetProductString
//
// Retrieves the specified module information (deprecated)
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0, B1 section 3.2
//----------------------------------------------------------------------------
    DWORD
FQD_GetProductString(
    DWORD           unitNumber,
    LPVOID          productInfoString,
    DWORD           item)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetProductInfo(unitNumber, (LPBYTE) productInfoString, item);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_GET_PRODUCT_STRING;                                // 0xDA000000
    }
    return status;
}                                       // end of FQD_GetProductString()
//----------------------------------------------------------------------------
// FQD_GetPT (deprecated)
//
// Returns the value of either the pressure in PSI or temperature in Celsius
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.12
//----------------------------------------------------------------------------
    DWORD
FQD_GetPT(
    HANDLE          unitHandle,
    BYTE            PorT,
    LPBYTE          coefficientData,
    DOUBLE          *result,
    LPBYTE          error)
{
    DOUBLE          pressurePSI;
    DOUBLE          temperatureCelsius;
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetPressureAndTemperature(
        unitHandle,
        coefficientData,
        &pressurePSI,
        &temperatureCelsius);
    if (status == QD_SUCCESS)
    {
        if (PorT == QD_CALCULATE_PRESSURE_PSI)
            *result = pressurePSI;
        else
            *result = temperatureCelsius;
    }
    else
    {
        *result = 0.0;
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_GET_PT;                                            // 0xDB000000
    }
    *error = (BYTE) status;
    return status;
}                                       // end of FQD_GetPT()
//----------------------------------------------------------------------------
// FQD_GetXDCurrent (deprecated)
//
// Returns the DC current in milliamps being drawn by the transducer
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.18
//----------------------------------------------------------------------------
    DWORD
FQD_GetXDCurrent(
    HANDLE          unitHandle,
    DOUBLE          *transducerCurrent)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetTransducerCurrent(unitHandle, transducerCurrent);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_GET_XD_CURRENT;                                    // 0xDC000000
    }
    return status;
}                                       // end of FQD_GetXDCurrent()
//----------------------------------------------------------------------------
// FQD_GetXDType (deprecated)
//
// Retrieves the specified device unit transducer type
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.9
//----------------------------------------------------------------------------
    DWORD
FQD_GetXDType(
    HANDLE          unitHandle,
    LPBYTE          transducerType)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetTransducerType(unitHandle, transducerType);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_GET_XD_TYPE;                                       // 0xDD000000
    }
    return status;
}                                       // end of FQD_GetXDType()
//----------------------------------------------------------------------------
// FQD_GetXDVoltage (deprecated)
//
// Returns the DC voltage in volts being applied to the transducer
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.19
//----------------------------------------------------------------------------
    DWORD
FQD_GetXDVoltage(
    HANDLE          unitHandle,
    DOUBLE          *transducerVoltage)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetTransducerVoltage(unitHandle, transducerVoltage);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_GET_XD_VOLTAGE;                                    // 0xDE000000
    }
    return status;
}                                       // end of FQD_GetXDVoltage()
//----------------------------------------------------------------------------
// FQD_PodFPGAReset (deprecated)
//
// Resets the specified device unit FPGA
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.29
//----------------------------------------------------------------------------
    DWORD
FQD_PodFPGAReset(
    HANDLE          unitHandle)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_ResetUnit(unitHandle);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_POD_FPGA_RESET;                                    // 0xDF000000
    }
    return status;
}                                       // end of FQD_PodFPGAReset()
//----------------------------------------------------------------------------
// FQD_RawI2C (deprecated)
//
// Sends an appropriately formed I2C command to the device unit
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    Both commandString and replyString must point to
//          QD_MAXIMUM_TRANSFER_SIZE (768) bytes of available memory
//
// D11813 A0 section 3.16
//----------------------------------------------------------------------------
    DWORD
FQD_RawI2C(
    HANDLE          unitHandle,
    LPBYTE          commandString,
    LPBYTE          replyString)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_ExecuteI2CCommand(
        unitHandle,
        commandString,
        replyString);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_RAW_I2C;                                           // 0xE0000000
    }
    return status;
}                                       // end of FQD_RawI2C()
//----------------------------------------------------------------------------
// FQD_ReadADC (deprecated)
//
// Reads the specified count register of the ADC associated with the specified
//      device unit
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.17
//----------------------------------------------------------------------------
    DWORD
FQD_ReadADC(
    HANDLE          unitHandle,
    BYTE            ADCChannel,
    LPDWORD         ADCCount)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_ReadUnitADC(unitHandle, ADCChannel, ADCCount);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_READ_ADC;                                          // 0xE1000000
    }
    return status;
}                                       // end of FQD_ReadADC()
//----------------------------------------------------------------------------
// FQD_ReadPodControlReg (deprecated)
//
// Retrieves the specified device unit control register value
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.21
//----------------------------------------------------------------------------
    DWORD
FQD_ReadPodControlReg(
    HANDLE          unitHandle,
    LPBYTE          registerValue)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetUnitControlRegister(unitHandle, registerValue);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_READ_POD_CONTROL_REG;                              // 0xE2000000
    }
    return status;
}                                       // end of FQD_ReadPodControlReg()
//----------------------------------------------------------------------------
// FQD_ReadPodFWID (deprecated)
//
// Retrieves the specified device unit firmware ID and version
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    firmwareID must point to at least QD_FIRMWARE_ID_LENGTH (4) bytes
//          of available memory
//
// D11813 A0 section 3.24
//----------------------------------------------------------------------------
    DWORD
FQD_ReadPodFWID(
    HANDLE          unitHandle,
    LPBYTE          firmwareID)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetUnitFirmwareID(unitHandle, firmwareID);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_READ_POD_FWID;                                     // 0xE3000000
    }
    return status;
}                                       // end of FQD_ReadPodFWID()
//----------------------------------------------------------------------------
// FQD_ReadPodModeSwitch (deprecated)
//
// Retrieves the specified device unit mode switch setting
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.27
//----------------------------------------------------------------------------
    DWORD
FQD_ReadPodModeSwitch(
    HANDLE          unitHandle,
    LPBYTE          modeSwitchSetting)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetUnitModeSwitchSetting(unitHandle, modeSwitchSetting);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_READ_POD_MODE_SWITCH;                              // 0xE4000000
    }
    return status;
}                                       // end of FQD_ReadPodModeSwitch()
//----------------------------------------------------------------------------
// FQD_ReadPodStatusReg (deprecated)
//
// Retrieves the specified device unit status register value
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.23
//----------------------------------------------------------------------------
    DWORD
FQD_ReadPodStatusReg(
    HANDLE          unitHandle,
    LPBYTE          registerValue)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_GetUnitStatusRegister(unitHandle, registerValue);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_READ_POD_STATUS_REG;                               // 0xE5000000
    }
    return status;
}                                       // end of FQD_ReadPodStatusReg()
//----------------------------------------------------------------------------
// FQD_SetBootLoad (deprecated)
//
// Puts the specified device unit in boot-loader mode
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.28
//----------------------------------------------------------------------------
    DWORD
FQD_SetBootLoad(
    HANDLE          unitHandle)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_SetFirmwareMode(unitHandle, QD_SET_BOOT_LOADER_MODE);           // 0x01
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_SET_BOOT_LOAD;                                     // 0xE6000000
    }
    return status;
}                                       // end of FQD_SetBootLoad()
//----------------------------------------------------------------------------
// FQD_SetCadenceTmr (deprecated)
//
// Sets the cadence timer used to acquire transducer counts
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.25
//----------------------------------------------------------------------------
    DWORD
FQD_SetCadenceTmr(
    HANDLE          unitHandle,
    DWORD           cadenceTimerValue)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_SetCadenceTimer(unitHandle, cadenceTimerValue);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_SET_CADENCE_TIMER;                                 // 0xE7000000
    }
    return status;
}                                       // end of FQD_SetCadenceTmr()
//----------------------------------------------------------------------------
// FQD_SetI2CBaudRate (deprecated)
//
// Updates the specified device unit I2C data transfer rate
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0, B1 section 3.32
//----------------------------------------------------------------------------
    DWORD
FQD_SetI2CBaudRate(
    HANDLE          unitHandle,
    DOUBLE          newBaudRate)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_SetI2CDataRate(unitHandle, newBaudRate);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_SET_I2C_BAUD_RATE;                                 // 0xE8000000
    }
    return status;
}                                       // end of FQD_SetI2CBaudRate()
//----------------------------------------------------------------------------
// FQD_SetXDPower (deprecated)
//
// Enables or disables power to the specified transducer
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.20
//----------------------------------------------------------------------------
    DWORD
FQD_SetXDPower(
    HANDLE          unitHandle,
    BYTE            powerState)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_SetTransducerPowerState(unitHandle, powerState);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_SET_XD_POWER;                                      // 0xE9000000
    }
    return status;
}                                       // end of FQD_SetXDPower()
//----------------------------------------------------------------------------
// FQD_WriteCFtoMemDevice (deprecated)
//
// Writes the specified coefficient data to the memory of the specified device,
// the QCOM memory in the case of an analog transducer, and the transducer
// memory in the case of a digital one
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    coefficientData must point to at least QD_COEFFICIENT_DATA_SIZE
//          (256) bytes of available memory
//
// D11813 A0 section 3.14
//----------------------------------------------------------------------------
    DWORD
FQD_WriteCFtoMemDevice(
    HANDLE          unitHandle,
    BYTE            device,
    BYTE            pageNumber,
    LPBYTE          coefficientData)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_WriteCoefficientDataToTargetPage(
        unitHandle,
        device,
        pageNumber,
        coefficientData);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_WRITE_CF_TO_DEVICE;                                // 0xEA000000
    }
    return status;
}                                       // end of FQD_WriteCFtoMemDevice()
//----------------------------------------------------------------------------
// FQD_WritePodControlReg (deprecated)
//
// Updates the specified device unit control register
//
// Returns: 0           Success
//          nonzero     Failure
//
// D11813 A0 section 3.22
//----------------------------------------------------------------------------
    DWORD
FQD_WritePodControlReg(
    HANDLE          unitHandle,
    BYTE            registerValue)
{
    DWORD           status;
    //------------------------------------------------------------------------
    status = FQD_SetUnitControlRegister(unitHandle, registerValue);
    if (status)
    {
        status &= QD_ERROR_CODE_AND_LOCUS_MASK;                                 // 0x00FFFFFF
        status |= QD_LOCUS_X_WRITE_POD_CONTOL_REG;                              // 0xEB000000
    }
    return status;
}                                       // end of FQD_WritePodControlReg()
#endif      // QDUSB_CPP
#endif      // FAKEDLL_CPP
//============================================================================
// End of FakeDLL.cpp
//============================================================================
