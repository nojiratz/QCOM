//============================================================================
// FakeDLL.h
//
// Header for FakeDLL.cpp
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 02-25-2014
//============================================================================
#pragma once
#ifndef     FAKEDLL_H  // provided for legacy compilers, but unnecessary for
#define     FAKEDLL_H  // recent compilers, due to the preceding pragma
//----------------------------------------------------------------------------
// Function prototypes
//----------------------------------------------------------------------------
DWORD FQD_CalculateFirmwarePageCRC(                        // B1 3.34
                    LPBYTE          firmwareData,
                    BYTE            pageNumber);
DWORD FQD_CalculatePressureAndTemperature(                 // B1 3.35
                    LPBYTE          coefficientData,
                    DWORD           pressureCount,
                    DWORD           temperatureCount,
                    DOUBLE          *pressurePSI,
                    DOUBLE          *temperatureCelsius);
DWORD FQD_CalculatePressureOrTemperature(                  // B1 3.11
                    BYTE            PorT,
                    LPBYTE          coefficientData,
                    DWORD           pressureCount,
                    DWORD           temperatureCount,
                    DOUBLE          *result);
DWORD FQD_Close(                                           // 3.4
                    HANDLE          unitHandle);
DWORD FQD_CheckReceiveQueue(                               // B1 3.7
                    HANDLE          unitHandle,
                    LPDWORD         numberOfBytesInQueue,
                    LPDWORD         queueStatus);
DWORD FQD_ClearInternalError(                              // B3 3.31
                    HANDLE          unitHandle);
bool FQD_CoefficientDataIsValid(                           // B1 3.36
                    LPBYTE          coefficientData);
bool FQD_CoefficientHexFileDataIsValid(                    // B1 3.37
                    LPBYTE          hexFileData);
bool FQD_DataIsInHexFileFormat(                            // B1 3.38
                    LPBYTE          hexFileData);
DWORD FQD_EraseFirmwarePage(                               // B1 3.39
                    HANDLE          unitHandle,
                    BYTE            pageNumber);
DWORD FQD_ExecuteI2CCommand(                               // B1 3.16
                    HANDLE          unitHandle,
                    LPBYTE          commandString,
                    LPBYTE          replyString);
bool FQD_FirmwareHexFileDataIsValid(                       // B1 3.40
                    LPBYTE          hexFileData);
DWORD FQD_FlushBuffers(                                    // 3.8
                    HANDLE          unitHandle,
                    BYTE            flushTransmitBuffer,
                    BYTE            flushReceiveBuffer);
DWORD FQD_FormatCoefficientHexFileData(                    // B1 3.41
                    LPBYTE          unformattedData,
                    LPBYTE          formattedData);
DWORD FQD_GetCadenceTimer(                                 // B1 3.26
                    HANDLE          unitHandle,
                    LPDWORD         cadenceTimerValue);
DWORD FQD_GetInternalErrorCode(                            // B3 3.30
                    HANDLE          unitHandle,
                    LPWORD          errorCode);
DWORD FQD_GetFirmwareCRC(                                  // B1 3.42
                    HANDLE          unitHandle,
                    BYTE            pageNumber,
                    LPWORD          pageCRC);
DWORD FQD_GetFirmwareDeviceInfo(                           // B1 3.43
                    HANDLE          unitHandle,
                    LPBYTE          unitInfo);
DWORD FQD_GetI2CDataRate(                                  // B3 3.33
                    HANDLE          unitHandle,
                    DOUBLE          *currentDataRate);
DWORD FQD_GetMemoryType(                                   // B2 3.62
                    HANDLE          unitHandle,
                    BYTE            device,
                    LPBYTE          memoryType);
DWORD FQD_GetNumberOfUnits(void);                          // B1 3.1
DWORD FQD_GetPressureAndTemperature(                       // B1 3.12
                    HANDLE          unitHandle,
                    LPBYTE          coefficientData,
                    DOUBLE          *pressurePSI,
                    DOUBLE          *temperatureCelsius);
DWORD FQD_GetProductInfo(                                  // B3 3.2
                    DWORD           unitNumber,
                    LPBYTE          productInfoString,
                    DWORD           flags);
DWORD FQD_GetQDDLLVersion(                                 // 3.63
                    LPBYTE          majorVersion,
                    LPBYTE          minorVersion,
                    LPBYTE          buildVersion);
DWORD FQD_GetTimeouts(                                     // 3.6
                    LPDWORD         readTimeout,
                    LPDWORD         writeTimeout);
DWORD FQD_GetUnitFirmwareID(                               // B1 3.24
                    HANDLE          unitHandle,
                    LPBYTE          firmwareID);
DWORD FQD_GetTransducerCounts(                             // B1 3.10
                    HANDLE          unitHandle,
                    LPDWORD         pressureCount,
                    LPDWORD         temperatureCount);
DWORD FQD_GetTransducerCurrent(                            // B1 3.18
                    HANDLE          unitHandle,
                    DOUBLE          *transducerCurrent);
DWORD FQD_GetTransducerType(                               // B1 3.9
                    HANDLE          unitHandle,
                    LPBYTE          transducerType);
DWORD FQD_GetTransducerVoltage(                            // B1 3.19
                    HANDLE          unitHandle,
                    DOUBLE          *transducerVoltage);
DWORD FQD_GetUnitControlRegister(                          // B1 3.21
                    HANDLE          unitHandle,
                    LPBYTE          registerValue);
DWORD FQD_GetUnitModeSwitchSetting(                        // B1 3.27
                    HANDLE          unitHandle,
                    LPBYTE          modeSwitchSetting);
DWORD FQD_GetUnitSerialNumber(                             // B1 3.46
                    DWORD           unitNumber,
                    LPBYTE          serialNumber);
DWORD FQD_GetUnitStatusRegister(                           // B1 3.23
                    HANDLE          unitHandle,
                    LPBYTE          registerValue);
DWORD FQD_GetUSBDLLVersion(                                // B1 3.44
                    LPDWORD         upperVersion,
                    LPDWORD         lowerVersion);
DWORD FQD_GetUSBDriverVersion(                             // B1 3.45
                    LPDWORD         upperVersion,
                    LPDWORD         lowerVersion);
bool FQD_HexFileFormatIsValid(                             // B1 3.47
                    LPBYTE          hexFileData);
char *FQD_InterpretErrorCode(                              // B? 3.??
                    DWORD           errorCode,
                    char            *errorDescription);
DWORD FQD_Open(                                            // 3.3
                    DWORD           unitNumber,
                    HANDLE          *unitHandle);
DWORD FQD_Read(                                            // B1 3.48
                    HANDLE          unitHandle,
                    LPBYTE          readBuffer,
                    DWORD           readBufferSize,
                    LPDWORD         bytesRead);
DWORD FQD_ReadCoefficientDataFromDevice(                   // B1 3.49
                    HANDLE          unitHandle,
                    LPBYTE          coefficientData);
DWORD FQD_ReadCoefficientDataFromHexFile(                  // B1 3.15
                    LPBYTE          pathName,
                    LPBYTE          coefficientData);
DWORD FQD_ReadCoefficientDataFromModulePage(               // B4 3.50
                    HANDLE          unitHandle,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DWORD FQD_ReadCoefficientDataFromSourcePage(               // B1 3.13
                    HANDLE          unitHandle,
                    BYTE            device,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DWORD FQD_ReadCoefficientDataFromUnitPage(                 // B1 3.50
                    HANDLE          unitHandle,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DWORD FQD_ReadFirmwareDataFromFile(                        // B1 3.51
                    LPBYTE          pathName,
                    LPBYTE          firmwareData);
DWORD FQD_ReadUnitADC(                                     // B1 3.17
                    HANDLE          unitHandle,
                    BYTE            ADCChannel,
                    LPDWORD         ADCCount);
DWORD FQD_ResetUnit(                                       // B1 3.29
                    HANDLE          unitHandle);
DWORD FQD_SetCadenceTimer(                                 // B1 3.25
                    HANDLE          unitHandle,
                    DWORD           cadenceTimerValue);
DWORD FQD_SetFirmwareKeyCodes(                             // B1 3.52
                    HANDLE          unitHandle,
                    BYTE            key0,
                    BYTE            key1);
DWORD FQD_SetFirmwareMode(                                 // B1 3.28
                    HANDLE          unitHandle,
                    BYTE            mode);
DWORD FQD_SetFirmwarePage(                                 // B1 3.53
                    HANDLE          unitHandle,
                    BYTE            pageNumber);
DWORD FQD_SetI2CDataRate(                                  // B3 3.32
                    HANDLE          unitHandle,
                    DOUBLE          newDataRate);
DWORD FQD_SetTimeouts(                                     // 3.5
                    DWORD           readTimeout,
                    DWORD           writeTimeout);
DWORD FQD_SetTransducerPowerState(                         // B1 3.20
                    HANDLE          unitHandle,
                    BYTE            powerState);
DWORD FQD_SetUnitControlRegister(                          // B1 3.22
                    HANDLE          unitHandle,
                    BYTE            registerValue);
bool FQD_TransducerMemoryPresent(                          // B? 3.??
                    HANDLE          unitHandle);
DWORD FQD_UnFormatHexFileData(                             // B1 3.54
                    LPBYTE          formattedData,
                    LPBYTE          unformattedData);
DWORD FQD_WaitForReply(                                    // B1 3.55
                    HANDLE          unitHandle,
                    DWORD           bytesExpected);
DWORD FQD_Write(                                           // B1 3.56
                    HANDLE          unitHandle,
                    LPBYTE          writeBuffer,
                    DWORD           writeBufferSize,
                    LPDWORD         bytesWritten);
DWORD FQD_WriteCoefficientDataToDevice(                    // B1 3.57
                    HANDLE          unitHandle,
                    LPBYTE          coefficientData);
DWORD FQD_WriteCoefficientDataToHexFile(                   // B1 3.58
                    LPBYTE          coefficientData,
                    LPBYTE          pathName);
DWORD FQD_WriteCoefficientDataToTargetPage(                // B1 3.14
                    HANDLE          unitHandle,
                    BYTE            device,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DWORD FQD_WriteCoefficientDataToUnitPage(                  // B1 3.59
                    HANDLE          unitHandle,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DWORD FQD_WriteFirmwarePage(                               // B1 3.60
                    HANDLE          unitHandle,
                    LPBYTE          firmwareData,
                    BYTE            pageNumber,
                    LPWORD          pageCRC);
DWORD FQD_WriteFirmwareSignature(                          // B1 3.61
                    HANDLE          unitHandle);
//----------------------------------------------------------------------------
// Prototypes of experimental QD USB DLL functions
//----------------------------------------------------------------------------
DWORD FQD_KickStartUSB(
                    HANDLE          unitHandle);
DWORD FQD_WriteFirmwareData(                         // B1 3.??
                    HANDLE          unitHandle,
                    LPBYTE          firmwareData);
//----------------------------------------------------------------------------
// Prototypes of deprecated QD USB DLL functions (included for backward-compatibility)
//----------------------------------------------------------------------------
DWORD FQD_CalcPT(                                          // A0 3.11
                    BYTE            PorT,
                    LPBYTE          coefficientData,
                    DWORD           pressureCount,
                    DWORD           temperatureCount,
                    DOUBLE          *result);
DWORD FQD_CheckRXQueue(                                    // A0 3.7
                    HANDLE          unitHandle,
                    LPDWORD         numberOfBytesInQueue,
                    LPDWORD         queueStatus);
DWORD FQD_ClearError(                                      // B2 3.31
                    HANDLE          unitHandle);
DWORD FQD_GetCadenceTmr(                                   // A0 3.26
                    HANDLE          unitHandle,
                    LPDWORD         cadenceTimerValue);
DWORD FQD_GetCFfromFile(                                   // A0 3.15
                    LPBYTE          path,
                    LPBYTE          coefficientData);
DWORD FQD_GetCFfromMemDevice(                              // A0 3.13
                    HANDLE          unitHandle,
                    BYTE            device,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DWORD FQD_GetCounts(                                       // A0 3.10
                    HANDLE          unitHandle,
                    BYTE            which,
                    LPDWORD         pressureCount,
                    LPDWORD         temperatureCount);
DWORD FQD_GetErrorCode(                                    // B2 3.30
                    HANDLE          unitHandle,
                    LPWORD          errorCode);
DWORD FQD_GetI2CBaudRate(                                  // 3.33
                    HANDLE          unitHandle,
                    DOUBLE          *currentBaudRate);
DWORD FQD_GetNumDevices(                                   // A0 3.1
                    LPDWORD         numberOfDevices);
DWORD FQD_GetProductString(                                // 3.2
                    DWORD           unitNumber,
                    LPVOID          productInfoString,
                    DWORD           flags);
DWORD FQD_GetPT(                                           // A0 3.12
                    HANDLE          unitHandle,
                    BYTE            PorT,
                    LPBYTE          coefficientData,
                    DOUBLE          *result,
                    LPBYTE          error);
DWORD FQD_GetXDCurrent(                                    // A0 3.18
                    HANDLE          unitHandle,
                    DOUBLE          *transducerCurrent);
DWORD FQD_GetXDType(                                       // A0 3.9
                    HANDLE          unitHandle,
                    LPBYTE          transducerType);
DWORD FQD_GetXDVoltage(                                    // A0 3.19
                    HANDLE          unitHandle,
                    DOUBLE          *transducerVoltage);
DWORD FQD_PodFPGAReset(                                    // A0 3.29
                    HANDLE          unitHandle);
DWORD FQD_RawI2C(                                          // A0 3.16
                    HANDLE          unitHandle,
                    LPBYTE          commandString,
                    LPBYTE          replyString);
DWORD FQD_ReadADC(                                         // A0 3.17
                    HANDLE          unitHandle,
                    BYTE            ADCChannel,
                    LPDWORD         ADCCount);
DWORD FQD_ReadPodControlReg(                               // A0 3.21
                    HANDLE          unitHandle,
                    LPBYTE          registerValue);
DWORD FQD_ReadPodFWID(                                     // A0 3.24
                    HANDLE          unitHandle,
                    LPBYTE          firmwareID);
DWORD FQD_ReadPodModeSwitch(                               // A0 3.27
                    HANDLE          unitHandle,
                    LPBYTE          modeSwitchSetting);
DWORD FQD_ReadPodStatusReg(                                // A0 3.23
                    HANDLE          unitHandle,
                    LPBYTE          registerValue);
DWORD FQD_SetBootLoad(                                     // A0 3.28
                    HANDLE          unitHandle);
DWORD FQD_SetCadenceTmr(                                   // A0 3.25
                    HANDLE          unitHandle,
                    DWORD           cadenceTimerValue);
DWORD FQD_SetI2CBaudRate(                                  // B2 3.32
                    HANDLE          unitHandle,
                    DOUBLE          newBaudRate);
DWORD FQD_SetXDPower(                                      // A0 3.20
                    HANDLE          unitHandle,
                    BYTE            powerState);
DWORD FQD_WriteCFtoMemDevice(                              // A0 3.14
                    HANDLE          unitHandle,
                    BYTE            device,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DWORD FQD_WritePodControlReg(                              // A0 3.22
                    HANDLE          unitHandle,
                    BYTE            registerValue);
//----------------------------------------------------------------------------
// The following lines are only seen by FakeDLL.cpp
//----------------------------------------------------------------------------
#ifdef      FAKEDLL_CPP
#include    "QDDefs.h"
#include    "SiUSBXp.h"
//----------------------------------------------------------------------------
// Declarations and definitions
//----------------------------------------------------------------------------
#using      <mscorlib.dll>
#using      <System.dll>
#using      <System.Drawing.dll>
#using      <System.Windows.Forms.dll>
using       namespace System;
using       namespace System::Drawing;
using       namespace System::IO;
using       namespace System::Text;
using       namespace System::Windows::Forms;
bool            FQD_DLLErrorEncountered;
void            DisplayStackTrace(
                    String          ^messageString);
System::Windows::Forms::DialogResult
                QCOM_ModalMessage(
                    bool            allow,
                    DWORD           flag,
                    String          ^titleString,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
#define     FQD_FlushAllBuffers(H)              SI_FlushBuffers((H), QD_FLUSH_TRANSMIT_BUFFER, QD_FLUSH_RECEIVE_BUFFER)
#define     FunctionName()                      (String::Concat(__FUNCTION__)->Contains("::") ? \
                                                    String::Concat(__FUNCTION__)->Substring(String::Concat(__FUNCTION__)->IndexOf("::") + 2) : \
                                                    __FUNCTION__)
#define     Modal(M,...)                        QCOM_ModalMessage(true, 1, FunctionName(), (M), __VA_ARGS__)
#define     StringICompare(A,B)                 String::Compare((A), (B), StringComparison::OrdinalIgnoreCase)
#define     StringSet(S)                        ((S) && (S)->Length)
//----------------------------------------------------------------------------
// End of the lines that are only seen by FakeDLL.cpp
//----------------------------------------------------------------------------
#else
extern bool     FQD_DLLErrorEncountered;
#endif      // FAKEDLL_CPP
#endif      // FAKEDLL_H
//============================================================================
// End of FakeDLL.h
//============================================================================
