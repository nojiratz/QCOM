//============================================================================
// Firmware.cpp
//
// The methods used by GUI.cpp for firmware tasks
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     FIRMWARE_CPP
#define     FIRMWARE_CPP
#include    "Firmware.h"
//----------------------------------------------------------------------------
// QCOM_CheckForCurrentFirmwareVersion
//
// Prompts the user if the specified unit has a firmware version that is not
// current
//
// Called by:   QCOM_InitializeGUIComponents
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_CheckForCurrentFirmwareVersion(
    UnitInfo        ^unit)
{
    bool            upgradeFirmwareNow = GUI_YES;
    String          ^functionName = _T("QCOM_CheckForCurrentFirmwareVersion");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_UnitValid(unit))
    {
        if (unit->flags & QCOM_UNIT_FIRMWARE_ID_PRESENT)
        {
            if (((unit->firmwareID[2] << 8) | unit->firmwareID[3]) <
                ((QCOM_MINIMUM_FIRMWARE_MAJOR_VERSION << 8) | QCOM_MINIMUM_FIRMWARE_MINOR_VERSION))
            {
                //------------------------------------------------------------
                // An outdated firmware version is detected on the module,
                // so display an alert, and prompt for an update
                //------------------------------------------------------------
                upgradeFirmwareNow = QCOM_PromptYesNoModal(
                    "Upgrade Module Firmware",
                    "Now", "Later",
                    "Module {0} reports its firmware version is {1:D}.{2:D}\n"
                    "and should be upgraded to at least version {3:D}.{4:D}.\n"
                    "If you choose to upgrade later, some QCOM services\n"
                    "might not work correctly.  Upgrade now or later?",
                    unit->moduleSerialNumber,
                    unit->firmwareID[2],
                    unit->firmwareID[3],
                    QCOM_MINIMUM_FIRMWARE_MAJOR_VERSION,
                    QCOM_MINIMUM_FIRMWARE_MINOR_VERSION);
                if (upgradeFirmwareNow)
                {
                    QCOM_UpdateModuleFirmware(unit);
                }
            }
            else
            {
                QCOM_RecordAndModalEventByFlags(
                    QCOM_EventLogVerboseEnabled,
                    QCOM_VerboseMessagesEnabled,
                    functionName,
                    "The installed firmware version in module {0}\n"
                    "is up-to-date (version {1:D}.{2:D})",
                    unit->moduleSerialNumber,
                    unit->firmwareID[2], unit->firmwareID[3]);
            }
        }
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_CheckForCurrentFirmwareVersion()
//----------------------------------------------------------------------------
// QCOM_RetrieveFirmwareInformation
//
// Retrieves the firmware version and ID of the specified unit and populates
// the appropriate firmware fields
//
// Called by:   QCOM_ScanForDevices
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_RetrieveFirmwareInformation(
    UnitInfo        ^unit)
{
    BYTE            firmwareID[QD_FIRMWARE_ID_LENGTH];                          // 4
    DWORD           status;
    String          ^companyString = QCOM_STRING_UNKNOWN;
    String          ^functionName = _T("QCOM_RetrieveFirmwareInformation");
    //------------------------------------------------------------------------
    if (QCOM_UnitOpen(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        status = QD_GetModuleFirmwareID(
            unit->unitHandle,
            (LPBYTE) firmwareID);
        if (status == QD_SUCCESS)
        {
            for each (int ID in unit->firmwareID)
                unit->firmwareID[Array::IndexOf(unit->firmwareID, ID)] =
                    firmwareID[Array::IndexOf(unit->firmwareID, ID)];
            if ((firmwareID[0] == QD_FIRMWARE_QUARTZDYNE_ID) &&                 // 0x0D
                (firmwareID[1] == QD_FIRMWARE_QCOM_ID))                         // 0x16
                companyString = _T("Quartzdyne QCOM");
            unit->firmwareString = String::Format(
                "{0} v{1:D}.{2:D}",
                companyString,
                firmwareID[2],
                firmwareID[3]);
            unit->flags |= QCOM_UNIT_FIRMWARE_ID_PRESENT;                       // 0x00000004
            RecordVerboseEvent(
                "    Module {0} firmware string resulted in '{1}'",
                unit->moduleSerialNumber,
                unit->firmwareString);
        }
        else
        {
            RecordErrorEvent(
                "    QD_GetModuleFirmwareID failed with status 0x{0:X8}",
                status);
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitOpen(unit))
    else
    {
        if (!unit)
            RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_RetrieveFirmwareInformation()
//----------------------------------------------------------------------------
// QCOM_SwitchFromBootLoaderMode
//
// Switches the specified unit to Application Mode
//
// Called by:   QCOM_CheckModuleRegistryEntry
//              QCOM_ScanForDevices
//              QCOM_ToggleBootLoaderMode
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SwitchFromBootLoaderMode(
    UnitInfo        ^unit)
{
    DWORD           status;
    DWORD           waited = 0;
    String          ^functionName = _T("QCOM_SwitchFromBootLoaderMode");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        status = QD_SetFirmwareMode(
            unit->unitHandle,
            QD_SET_APPLICATION_MODE);                                           // 0x00
        if (status == QD_SUCCESS)
        {
            Sleep(QD_MINIMUM_BOOT_LOADER_MODE_WAIT_TIME);
            QCOM_CloseUnit(unit);
            status = QCOM_OpenUnit(unit);
            if (status == QCOM_SUCCESS)
            {
                if (unit->unitHandle == INVALID_HANDLE_VALUE)
                {
                    RecordErrorEvent(
                        "    QCOM_OpenUnit({0:D}) succeeded but returned handle 0x{1:X4}",
                        unit->physicalUnitNumber, (int) unit->unitHandle);
                }
                else
                {
                    QCOM_GetModuleInfo(unit);
                    while ((unit->flags & QCOM_UNIT_BOOT_LOADER_MODE) &&
                        (waited < QD_MAXIMUM_BOOT_LOADER_MODE_WAIT_TIME))
                    {
                        if (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE)
                        {
                            waited++;
                            Sleep(50);
                            QCOM_GetModuleInfo(unit);
                        }
                    }
                    if (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE)
                        RecordErrorEvent(
                            "    Module on unit {0:D} failed to transition from Boot Loader mode",
                            unit->physicalUnitNumber);
                    else
                        RecordBasicEvent(
                            "    Module on unit {0:D} successfully transitioned from Boot Loader mode",
                            unit->physicalUnitNumber);
                }
            }
            else
            {
                RecordErrorEvent(
                    "    QCOM_OpenUnit({0:D}) failed with status 0x{1:X8}",
                    unit->physicalUnitNumber, status);
            }
        }
        RecordBasicEvent("{0} concluded", functionName);
    }
    else
    {
        if (!unit)
            RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_SwitchFromBootLoaderMode()
//----------------------------------------------------------------------------
// QCOM_SwitchToBootLoaderMode
//
// Switches the specified unit to BootLoader Mode
//
// Called by:   QCOM_CheckModuleRegistryEntry
//              QCOM_ToggleBootLoaderMode
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SwitchToBootLoaderMode(
    UnitInfo        ^unit)
{
    DWORD           status;
    DWORD           waited = 0;
    String          ^functionName = _T("QCOM_SwitchToBootLoaderMode");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        unit->flags |= QCOM_UNIT_BOOT_LOADER_MODE;
        status = QD_SetFirmwareMode(
            unit->unitHandle,
            QD_SET_BOOT_LOADER_MODE);                                           // 0x01
        if (status == QD_SUCCESS)
        {
            Sleep(QD_MINIMUM_BOOT_LOADER_MODE_WAIT_TIME);
            QCOM_CloseUnit(unit);
            status = QCOM_OpenUnit(unit);
            if (status == QCOM_SUCCESS)
            {
                if (unit->unitHandle == INVALID_HANDLE_VALUE)
                {
                    RecordErrorEvent(
                        "    QCOM_OpenUnit({0:D}) succeeded but returned handle 0x{1:X4}",
                        unit->physicalUnitNumber, (int) unit->unitHandle);
                }
                else
                {
                    QCOM_GetModuleInfo(unit);
                    while (!(unit->flags & QCOM_UNIT_BOOT_LOADER_MODE) &&
                        (waited < QD_MAXIMUM_BOOT_LOADER_MODE_WAIT_TIME))
                    {
                        if (!(unit->flags & QCOM_UNIT_BOOT_LOADER_MODE))
                        {
                            waited++;
                            Sleep(50);
                            QCOM_GetModuleInfo(unit);
                        }
                    }
                    if (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE)
                        RecordBasicEvent(
                            "    Module on unit {0:D} successfully transitioned to Boot Loader mode",
                            unit->physicalUnitNumber);
                    else
                        RecordErrorEvent(
                            "    Module on unit {0:D} failed to transition to Boot Loader mode",
                            unit->physicalUnitNumber);
                }
            }
            else
            {
                RecordErrorEvent(
                    "    QCOM_OpenUnit({0:D}) failed with status 0x{1:X8}",
                    unit->physicalUnitNumber, status);
            }
        }
        else
        {
            QCOM_GetModuleInfo(unit);
        }
        RecordBasicEvent("{0} concluded", functionName);
    }
    else
    {
        if (!unit)
            RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_SwitchToBootLoaderMode()
//----------------------------------------------------------------------------
// QCOM_ToggleBootLoaderMode
//
// Toggle to enter or exit BootLoader Mode
//
// Called by:   GUI_BootLoaderButtonClicked
//              GUI_ConfigureDriverForBootLoaderMode
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToggleBootLoaderMode(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_ToggleBootLoaderMode");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        miscBootLoaderButtonArray[unit->unitNumber]->Enabled = GUI_NO;
        if (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE)
        {
            QCOM_SwitchFromBootLoaderMode(unit);
        }
        else
        {
            QCOM_SwitchToBootLoaderMode(unit);
        }
        miscBootLoaderButtonArray[unit->unitNumber]->Text =
            (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE) ?
                GUI_RESET_BOOT_LOADER_MODE : GUI_ENTER_BOOT_LOADER_MODE;
        miscTabPageArray[unit->unitNumber]->Text = unit->moduleSerialNumber;
        miscBootLoaderButtonArray[unit->unitNumber]->Enabled = GUI_YES;
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        if (!unit)
            RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_ToggleBootLoaderMode()
//----------------------------------------------------------------------------
// QCOM_UpdateFirmwareDisplays
//
// Updates the objects that display firmware information
//
// Called by:   QCOM_UpdateGlobalObjects
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateFirmwareDisplays(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_UpdateFirmwareDisplays");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_GUI_READY_FOR_UPDATING)
        {
            readoutFirmwareInfoLabelArray[unit->unitNumber]->Text = String::Concat(
                "Firmware ID and Version: ", unit->firmwareString);
        }
    }
    else
    {
        if (!unit)
            RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_UpdateFirmwareDisplays()
//----------------------------------------------------------------------------
// QCOM_UpdateModuleFirmware
//
// Prompts the user to update the firmware of the specified unit, then updates
// the firmware with the data from the selected file
//
// Called by:   QCOM_UtilUnitUpdateFirmwareButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateModuleFirmware(
    UnitInfo        ^unit)
{
    bool            currentlySampling;
    bool            currentlyTesting;
    bool            firmwareVersionChanged = GUI_NO;
    bool            proceedWithUpdate = GUI_YES;
    bool            promptResult = GUI_ACCEPT;
    bool            someUpdating = GUI_NO;
    bool            upgrade = GUI_NO;
    int             address;
    int             lastPage = QD_FIRMWARE_LAST_PAGE_C8051F320;                 // 29
    int             SIOffset;
    int             recordLength;
    int             recordType;
    char            *firmwareFilePath;
    BYTE            deviceCode;
    BYTE            deviceInfoBuffer[sizeof(UnitDeviceInfoDef)];
    BYTE            firmwarePageFlags[QD_FIRMWARE_MAXIMUM_DATA_SIZE / QD_FIRMWARE_PAGE_SIZE];   // 126
    BYTE            FWVHigh;
    BYTE            FWVLow;
    BYTE            highPage = 0;
    BYTE            pageNumber;
    LPBYTE          firmwareData;
    DWORD           moduleNumber;
    DWORD           status = QCOM_SUCCESS;
    DWORD           stepsCompleted = 0;
    DWORD           stepsToComplete = 53;
    WORD            pageCRC;
    UnitDeviceInfoDef
                    *deviceInfo = (UnitDeviceInfoDef *) deviceInfoBuffer;
    String          ^firmwareFilePathString;
    String          ^hexFileLine;
    String          ^promptString;
    String          ^promptTitle;
    StreamReader    ^textReader;
    String          ^functionName = _T("QCOM_UpdateModuleFirmware");
    //------------------------------------------------------------------------
    if (QCOM_UnitOpen(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        firmwareFilePath = (char *) malloc(QCOM_MAXIMUM_FILE_PATH_LENGTH);      // 512
        firmwareData = (LPBYTE) malloc(QD_FIRMWARE_MAXIMUM_DATA_SIZE);          // (63 * 1024)
        if (firmwareFilePath && firmwareData)
        {
            currentlySampling = QCOM_QueryStopSampling(
                "Firmware cannot be updated during transducer sampling.");
            currentlyTesting = QCOM_QueryStopTesting(
                "Firmware cannot be updated while tests are running.");
            if (!currentlySampling && !currentlyTesting)
            {
                ClearBuffer(firmwareFilePath, QCOM_MAXIMUM_FILE_PATH_LENGTH);
                do
                {
                    promptTitle = String::Format(
                        "Updating Firmware for QCOM Module {0}",
                        unit->moduleSerialNumber);
                    StringBuilder ^firmwareFilePathBuilder =
                        gcnew StringBuilder(QCOM_MAXIMUM_FILE_PATH_LENGTH);
                    promptResult = QCOM_PromptForReadFile(
                        promptTitle,
                        firmwareFilePathBuilder,
                        nullptr,
                        GUI_FILE_TYPE_HEX);
                    if (promptResult == GUI_ACCEPT)
                    {
                        firmwareFilePathString = firmwareFilePathBuilder->ToString();
                        delete firmwareFilePathBuilder;
                        if (File::Exists(firmwareFilePathString))
                        {
                            QCOM_ConvertString(
                                firmwareFilePathString,
                                firmwareFilePath,
                                QCOM_MAXIMUM_FILE_PATH_LENGTH);
                                status = QD_ReadFirmwareDataFromFile(
                                    (LPBYTE) firmwareFilePath,
                                    firmwareData);
                                if (status == QD_SUCCESS)
                                {
                                    if ((firmwareData[QD_FIRMWARE_TEST_OFFSET] != 0xFF) &&
                                        (memcmp(&firmwareData[QD_FIRMWARE_TEST_OFFSET], "Test", 4) == 0))
                                    {
                                        promptResult = QCOM_PromptModal(
                                            "Test Firmware File",
                                            "The selected firmware file is used only for testing.\n"
                                            "Install it anyway?");
                                    }
                                    if (promptResult == GUI_ACCEPT)
                                    {
                                        memset(&firmwareData[QD_FIRMWARE_TEST_OFFSET], 0xFF, 4);
                                    }
                                }
                                else
                                {
                                    GUI_DisplaySimpleError(functionName,
                                        "{0}\ndoes not appear to be a firmware file",
                                        firmwareFilePathString);
                                }
                        }               // end of if (File::Exists(firmwareFilePathString))
                        else
                        {
                            promptResult = QCOM_PromptOKModal(
                                "Select Firmware File",
                                "The file {0}\ncould not be found",
                                firmwareFilePathString);
                            status = QCOM_ERROR_FILE_NOT_FOUND;
                        }
                    }                   // end of if (promptResult == GUI_ACCEPT)
                }
                while ((status != QCOM_SUCCESS) && (promptResult == GUI_ACCEPT));
                if ((promptResult == GUI_ACCEPT) && StringSet(firmwareFilePathString) && (status == QCOM_SUCCESS))
                {
                    QCOM_RecordAndModalEventByFlags(
                        QCOM_EventLogBasicEnabled,
                        QCOM_DetailedMessagesEnabled,
                        functionName,
                        "Firmware data successfully read from\n{0}",
                        firmwareFilePathString);
                    //--------------------------------------------------------
                    // The firmware data file was successfully imported; next
                    // verify the data's integrity
                    //--------------------------------------------------------
                    unit->flags &= ~QCOM_UNIT_FIRMWARE_UPDATED;
                    for (pageNumber = 0; pageNumber < (QD_FIRMWARE_MAXIMUM_DATA_SIZE / QD_FIRMWARE_PAGE_SIZE); pageNumber++)
                    {
                        firmwarePageFlags[pageNumber] = 0;
                    }
                    //--------------------------------------------------------
                    // Determine which firmware pages actually contain data
                    // that needs updating
                    //--------------------------------------------------------
                    textReader = File::OpenText(firmwareFilePathString);
                    if (textReader)
                    {
                        while (hexFileLine = textReader->ReadLine())
                        {
                            recordLength =
                                ((AtoX(hexFileLine[1]) << 4) & 0xF0) | (AtoX(hexFileLine[2]) & 0x0F);
                            address =
                                ((AtoX(hexFileLine[3]) << 12) & 0xF000) | ((AtoX(hexFileLine[4]) << 8) & 0x0F00) |
                                ((AtoX(hexFileLine[5]) << 4) & 0x00F0) | (AtoX(hexFileLine[6]) & 0x000F);
                            recordType =
                                ((AtoX(hexFileLine[7]) << 4) & 0xF0) | (AtoX(hexFileLine[8]) & 0x0F);
                            if ((recordType != 0x01) && recordLength)
                            {
                                firmwarePageFlags[address >> 9] = 1;
                                highPage = Max(highPage, (address >> 9));
                            }
                        }
                        textReader->Close();
                    }                   // end of if (textReader)
                    else
                    {
                        GUI_DisplaySimpleError(functionName,
                            "File cannot be opened for reading:\n{0}",
                            firmwareFilePathString);
                    }
                    if (highPage == lastPage)
                    {
                        SIOffset = ((lastPage + 1) * QD_FIRMWARE_PAGE_SIZE) - 5;// 0x3BFB
                        deviceCode = firmwareData[SIOffset];
                        FWVHigh = firmwareData[SIOffset + 1];
                        FWVLow = firmwareData[SIOffset + 2];
                        unit->flags |= QCOM_UNIT_FIRMWARE_UPDATING;
                        QCOM_GeneralInfo->flags |= QCOM_GENERAL_FIRMWARE_UPDATING;
                        QCOM_HomeUpdateStatusLine("Firmware update in progress");
                        QCOM_PleaseWait(
                            GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
                            promptTitle);
                        status = QD_SetFirmwareMode(
                            unit->unitHandle,
                            QD_SET_BOOT_LOADER_MODE);
                        if (status == QD_SUCCESS)
                        {
                            RecordVerboseEvent("    Firmware mode set successfully");
                            Sleep(QD_MINIMUM_BOOT_LOADER_MODE_WAIT_TIME);
                            QCOM_CloseUnit(unit);
                            status = QCOM_OpenUnit(unit);
                            if (status == QCOM_SUCCESS)
                            {
                                status = QD_GetFirmwareDeviceInfo(
                                    unit->unitHandle,
                                    (LPBYTE) deviceInfo);
                                if (status == QD_SUCCESS)
                                {
                                    QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
                                    Thread::Sleep(100);
                                    QCOM_RecordAndModalEventByFlags(
                                        QCOM_EventLogBasicEnabled,
                                        QCOM_DetailedMessagesEnabled,
                                        functionName,
                                        "Current firmware: device = {0:X2} version = {1:X}.{2:X2} sig = {3:X4}",
                                        deviceInfo->deviceCode,
                                        deviceInfo->applicationFWVersionHigh,
                                        deviceInfo->applicationFWVersionLow,
                                        deviceInfo->signature);
                                    //----------------------------------------
                                    // Determine whether the update is an
                                    // upgrade or a downgrade
                                    //----------------------------------------
                                    if (((FWVHigh << 8) | (FWVLow)) >=
                                        ((deviceInfo->applicationFWVersionHigh << 8) | (deviceInfo->applicationFWVersionLow)))
                                        upgrade = GUI_YES;
                                    promptString = String::Format(
                                        "Version of firmware currently installed = {0:D}.{1:D}\n"
                                        "Version of firmware contained in the file = {2:D}.{3:D}\n"
                                        "Proceed to update the QCOM module {4} firmware?",
                                        deviceInfo->applicationFWVersionHigh,
                                        deviceInfo->applicationFWVersionLow,
                                        FWVHigh, FWVLow,
                                        unit->moduleSerialNumber);
                                    proceedWithUpdate = QCOM_PromptModal(
                                        (upgrade ?
                                            "QCOM Firmware Upgrade" :
                                            "QCOM Firmware Downgrade"),
                                        promptString);
                                    if (proceedWithUpdate)
                                    {
                                        if ((deviceInfo->deviceCode == QD_FIRMWARE_DEVICE_CODE_C8051F320) &&    // 0x81
                                            (deviceInfo->signature == QD_FIRMWARE_SIGNATURE))                   // 0x3DC2
                                        {
                                            if (deviceInfo->deviceCode == deviceCode)
                                            {
                                                QCOM_HomeUpdateProgressBar(stepsCompleted++, stepsToComplete);
                                                status = QD_SetFirmwareKeyCodes(
                                                    unit->unitHandle,
                                                    QD_FIRMWARE_KEY_0,      // 0xA5
                                                    QD_FIRMWARE_KEY_1);     // 0xF1
                                                if (status == QD_SUCCESS)
                                                {
                                                    RecordVerboseEvent("    Firmware key codes set successfully");
                                                    QCOM_HomeUpdateProgressBar(stepsCompleted++, stepsToComplete);
                                                    status = QD_EraseFirmwarePage(unit->unitHandle, lastPage);
                                                    if (status == QD_SUCCESS)
                                                    {
                                                        QCOM_HomeUpdateProgressBar(stepsCompleted++, stepsToComplete);
                                                        for (pageNumber = QD_FIRMWARE_FIRST_PAGE_C8051F320;
                                                            ((pageNumber <= lastPage) && (status == QCOM_SUCCESS));
                                                            pageNumber++)
                                                        {
                                                            pageCRC = 0;
                                                            QCOM_HomeUpdateProgressBar(stepsCompleted++, stepsToComplete);
                                                            if (firmwarePageFlags[pageNumber])
                                                            {
                                                                status = QD_WriteFirmwarePage(
                                                                    unit->unitHandle,
                                                                    firmwareData,
                                                                    pageNumber,
                                                                    (LPWORD) &pageCRC);
                                                                if (status == QD_SUCCESS)
                                                                {
                                                                    QCOM_HomeUpdateProgressBar(stepsCompleted++, stepsToComplete);
                                                                    if (pageCRC == QD_CalculateFirmwarePageCRC(firmwareData, pageNumber))
                                                                    {
                                                                        QCOM_RecordAndModalEventByFlags(
                                                                            QCOM_EventLogBasicEnabled,
                                                                            QCOM_DetailedMessagesEnabled,
                                                                            functionName,
                                                                            "The CRC ({0:X4}) checks out for page {1:D}",
                                                                            pageCRC, pageNumber);
                                                                    }
                                                                    else
                                                                    {
                                                                        GUI_DisplaySimpleError(functionName,
                                                                            "Incorrect CRC for page {0:D}",
                                                                            pageNumber);
                                                                        status = QD_ERROR_CHECKSUM_ERROR;
                                                                        break;
                                                                    }
                                                                    QCOM_HomeUpdateProgressBar(stepsCompleted++, stepsToComplete);
                                                                }
                                                                else
                                                                {
                                                                    QCOM_RecordAndModalErrorEvent(
                                                                        "    Error 0x{0:X8} writing firmware page {1}",
                                                                        status, pageNumber);
                                                                }
                                                            }
                                                        }
                                                        if (status == QD_SUCCESS)
                                                        {
                                                            RecordVerboseEvent("    Firmware pages updated successfully");
                                                            status = QD_WriteFirmwareSignature(unit->unitHandle);
                                                            if (status == QD_SUCCESS)
                                                            {
                                                                RecordVerboseEvent("    Firmware signatures written successfully");
                                                                QCOM_HomeUpdateProgressBar(stepsCompleted++, stepsToComplete);
                                                                status = QD_GetFirmwareDeviceInfo(
                                                                    unit->unitHandle,
                                                                    (LPBYTE) deviceInfo);
                                                                if (status == QD_SUCCESS)
                                                                {
                                                                    QCOM_HomeUpdateProgressBar(stepsCompleted++, stepsToComplete);
                                                                    if (deviceInfo->signature == QD_FIRMWARE_SIGNATURE)   // 0x3DC2
                                                                    {
                                                                        QCOM_RecordAndModalEventByFlags(
                                                                            QCOM_EventLogBasicEnabled,
                                                                            QCOM_DetailedMessagesEnabled,
                                                                            functionName,
                                                                            "The final firmware signatures match");
                                                                    }
                                                                    else
                                                                    {
                                                                        GUI_DisplaySimpleError(functionName,
                                                                            "Error: DeviceInfo sig = {0:X4}  defined sig = {1:X4}",
                                                                            deviceInfo->signature,
                                                                            QD_FIRMWARE_SIGNATURE);
                                                                    }
                                                                }
                                                                status = QD_SetFirmwareKeyCodes(
                                                                    unit->unitHandle,
                                                                    0x00,
                                                                    0x00);
                                                                if (status == QD_SUCCESS)
                                                                {
                                                                    QCOM_RecordAndModalEventByFlags(
                                                                        QCOM_EventLogVerboseEnabled,
                                                                        QCOM_DetailedMessagesEnabled,
                                                                        functionName,
                                                                        "Key codes successfully erased");
                                                                }
                                                                else
                                                                {
                                                                    GUI_DisplayUnitErrorWithStatus(functionName,
                                                                        "Attempt to set firmware key codes 0x00 and 0x00",
                                                                        unit,
                                                                        status);
                                                                }
                                                                QCOM_HomeUpdateProgressBar(stepsToComplete, stepsToComplete);
                                                                if (status == QD_SUCCESS)
                                                                {
                                                                    firmwareVersionChanged = GUI_YES;
                                                                    promptString = String::Format(
                                                                        "Firmware for module {0} updated successfully",
                                                                        unit->moduleSerialNumber);
                                                                    QCOM_HomeUpdateStatusLine(promptString);
                                                                    GUI_PlaySound(tadaSound);
                                                                    QCOM_PromptOKModal(
                                                                        "Firmware Update Completed",
                                                                        promptString);
                                                                    unit->flags |= QCOM_UNIT_FIRMWARE_UPDATED;
                                                                }
                                                                else
                                                                {
                                                                    promptString = String::Format(
                                                                        "Firmware for module {0} failed to update",
                                                                        unit->moduleSerialNumber);
                                                                    QCOM_HomeUpdateStatusLine(promptString);
                                                                    GUI_DisplaySimpleError(
                                                                        "Firmware Update Failed",
                                                                        promptString);
                                                                }
                                                            }
                                                            else
                                                            {
                                                                GUI_DisplayUnitErrorWithStatus(functionName,
                                                                    "Attempt to write the firmware signature",
                                                                    unit,
                                                                    status);
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        GUI_DisplayUnitErrorWithStatus(functionName,
                                                            "Attempt to erase the firmware page",
                                                            unit,
                                                            status);
                                                    }
                                                }
                                                else
                                                {
                                                    GUI_DisplayUnitErrorWithStatus(functionName,
                                                        String::Format(
                                                            "Attempt to set firmware key codes 0x{0:X2} and 0x{1:X2}",
                                                            QD_FIRMWARE_KEY_0,
                                                            QD_FIRMWARE_KEY_1),
                                                        unit,
                                                        status);
                                                }
                                            }
                                            else
                                            {
                                                if (deviceInfo->deviceCode != deviceCode)
                                                {
                                                    GUI_DisplaySimpleError(functionName,
                                                        "The device code in the current firmware is 0x{0:X2}\n"
                                                        "and the device code in the file is 0x{1:X2}",
                                                        deviceInfo->deviceCode, deviceCode);
                                                }
                                            }
                                        }
                                        else
                                        {
                                            GUI_DisplaySimpleError(functionName,
                                                "The device code in the current firmware is 0x{0:X2} and should be 0x{1:X2}\n"
                                                "The signature in the current firmware is 0x{2:X4} and should be 0x{3:X4}",
                                                deviceInfo->deviceCode, QD_FIRMWARE_DEVICE_CODE_C8051F320,
                                                deviceInfo->signature, QD_FIRMWARE_SIGNATURE);
                                        }
                                        QCOM_HomeUpdateStatusLine(nullptr);
                                        QCOM_HomeUpdateProgressBar(0, 0);
                                    }
                                    else
                                    {
                                        promptString = String::Format(
                                            "Firmware update for module {0} canceled",
                                            unit->moduleSerialNumber);
                                        QCOM_HomeUpdateStatusLine(promptString);
                                        QCOM_PromptOKModal(
                                            "Firmware Update Canceled",
                                            promptString);
                                    }
                                }
                                else
                                {
                                    GUI_DisplayUnitErrorWithStatus(functionName,
                                        "Attempt to retrieve firmware device info",
                                        unit,
                                        status);
                                }
                                QCOM_PleaseWait(
                                    GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
                                    "Restarting the Firmware for QCOM Module {0}",
                                    unit->moduleSerialNumber);
                                status = QD_SetFirmwareMode(
                                    unit->unitHandle,
                                    QD_SET_APPLICATION_MODE);
                                if (status == QD_SUCCESS)
                                {
                                    RecordVerboseEvent("    Firmware mode restored successfully");
                                    Sleep(QD_MINIMUM_BOOT_LOADER_MODE_WAIT_TIME);
                                    QCOM_CloseUnit(unit);
                                    status = QCOM_OpenUnit(unit);
                                    if (status)
                                    {
                                        GUI_DisplayUnitErrorWithStatus(functionName,
                                            "QD_Open (1)",
                                            unit,
                                            status);
                                    }
                                }
                                unit->flags &= ~QCOM_UNIT_FIRMWARE_UPDATING;
                                QCOM_GetModuleInfo(unit);
                                if (firmwareVersionChanged)
                                {
                                    QCOM_RetrieveFirmwareInformation(unit);
                                    QCOM_UpdateFirmwareDisplays(unit);
                                    RecordBasicEvent("    Firmware updated successfully");
                                }
                                QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
                                Thread::Sleep(100);
                            }
                            else
                            {
                                GUI_DisplayUnitErrorWithStatus(functionName,
                                    "QD_Open (2)",
                                    unit,
                                    status);
                            }
                        }
                        else
                        {
                            GUI_DisplayUnitErrorWithStatus(functionName,
                                "Attempt to set the firmware to BootLoader mode",
                                unit,
                                status);
                        }
                        unit->flags &= ~QCOM_UNIT_FIRMWARE_UPDATING;
                        for (moduleNumber = 0; moduleNumber < QCOM_CurrentNumberOfUnits; moduleNumber++)
                        {
                            if (QCOM_UnitNumberValid(moduleNumber))
                            {
                                if (QCOM_UnitInfoArray[moduleNumber]->flags & QCOM_UNIT_FIRMWARE_UPDATING)
                                    someUpdating = GUI_YES;
                            }
                        }
                        if (someUpdating)
                            QCOM_GeneralInfo->flags |= QCOM_GENERAL_FIRMWARE_UPDATING;
                        else
                            QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_FIRMWARE_UPDATING;
                    }
                    else
                    {
                        GUI_DisplaySimpleError(functionName,
                            "The last page is {0:D} and should be {1:D}",
                            highPage, lastPage);
                        status = QD_ERROR_INVALID_FIRMWARE_PAGE;                // 0x001A
                    }
                }
                else
                {
                    if (status == QD_SUCCESS)
                    {
                        // do nothing ?
                    }
                    else
                    {
                        GUI_DisplayUnitErrorWithStatus(functionName,
                            "Attempt to read firmware data from the file",
                            unit,
                            status);
                    }
                }
            }                           // end of if (!currentlySampling && !currentlyTesting)
            free((void *) firmwareData);
            free((void *) firmwareFilePath);
            QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
            Thread::Sleep(100);
        }                               // end of if (firmwareFilePath && firmwareData)
        else
        {
            GUI_DisplayUnitError(functionName,
                "Insufficient memory to update firmware",
                unit);
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitOpen(unit))
    else
    {
        if (unit)
        {
            if (QCOM_UnitOpen(unit))
                GUI_DisplaySimpleError(
                    functionName,
                    "Module {0} is invalid",
                    unit->moduleSerialNumber);
            else
                GUI_DisplaySimpleError(
                    functionName,
                    "Unit {0:D} is not open",
                    unit->unitNumber);
        }
        else
        {
            RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
        }
    }
}                                       // end of QCOM_UpdateModuleFirmware()
//----------------------------------------------------------------------------
// QCOM_UtilUnitUpdateFirmwareButtonClicked
//
// Handles the click of the unit Update Firmware button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilUnitUpdateFirmwareButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_UtilUnitUpdateFirmwareButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Update Firmware button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_UpdateModuleFirmware(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_UtilUnitUpdateFirmwareButtonClicked()
//----------------------------------------------------------------------------
#endif      // FIRMWARE_CPP
//============================================================================
// End of Firmware.cpp
//============================================================================
