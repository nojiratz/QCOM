//============================================================================
// GUI.cpp
//
// A collection of C++ methods, classes, definitions, and other tools for the
// support of the QCOM Windows graphical user interfaces
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     GUI_CPP
#define     GUI_CPP
#include    "GUI.h"
//----------------------------------------------------------------------------
// QCOM_GUIClass
//
// Class constructor
//
// Called by:   QCOM_Main
//----------------------------------------------------------------------------
    QCOM_GUIClass::
QCOM_GUIClass()
{
    //------------------------------------------------------------------------
    // Register the default (unhandled) exception handler before any class
    // methods are called, to catch all exceptions not already handled
    //------------------------------------------------------------------------
    AppDomain::CurrentDomain->UnhandledException +=
        gcnew UnhandledExceptionEventHandler(this, &QCOM_GUIClass::QCOM_DefaultExceptionHandler);
    //------------------------------------------------------------------------
    // Register for the event in which the computer is shutting down
    //------------------------------------------------------------------------
    SystemEvents::SessionEnded +=
        gcnew SessionEndedEventHandler(this, &QCOM_GUIClass::QCOM_ComputerShuttingDown);
    //------------------------------------------------------------------------
    // Register for the event in which the computer is going into hibernation
    //------------------------------------------------------------------------
    SystemEvents::PowerModeChanged +=
        gcnew PowerModeChangedEventHandler(this, &QCOM_GUIClass::QCOM_ComputerGoingToHibernation);
    //------------------------------------------------------------------------
    // Start the GUI
    //------------------------------------------------------------------------
    QCOM_Start();
}                                       // end of QCOM_GUIClass
//----------------------------------------------------------------------------
// QCOM_Start
//
// Starts the QCOM software
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_Start(void)
{
    DWORD           mainStatus;
    String          ^functionName = _T("QCOM_Start");
    //------------------------------------------------------------------------
    // Initialize the QCOM hardware, if present, and the software
    //------------------------------------------------------------------------
    mainStatus = QCOM_InitializeQCOM();
    if (mainStatus == QCOM_SUCCESS)
    {
        if (QCOM_CommandLineOnly)
        {
            QCOM_PerformCommandLineTasks();
            //----------------------------------------------------------------
            // Conclude the program
            //----------------------------------------------------------------
            QCOM_Finalize(String::Concat(functionName, " concluded"));
            //----------------------------------------------------------------
            // Manually exit the program (to terminate the Form process)
            //----------------------------------------------------------------
            Environment::Exit(mainStatus);
        }
        else
        {
            RecordBasicEvent("Begin GUI initialization");
            QCOM_ConstructAndPresentUserInterface();
            RecordBasicEvent("End GUI initialization");
        }                               // end of else of if (QCOM_CommandLineOnly)
    }                                   // end of if (mainStatus == QCOM_SUCCESS)
    else
    {
        //--------------------------------------------------------------------
        // Initialization failed, so exit the program (this automatically
        // releases the mutex
        //--------------------------------------------------------------------
        Environment::Exit(mainStatus);
    }
}                                       // end of QCOM_Start
//----------------------------------------------------------------------------
// QCOM_ConstructAndPresentUserInterface
//
// Constructs the home window and all associated graphics, then presents them
//
// Called by:   QCOM_Start
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConstructAndPresentUserInterface(void)
{
    String          ^functionName = _T("QCOM_ConstructAndPresentUserInterface");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Initialize global and other program entities
    //------------------------------------------------------------------------
    QCOM_InitializeGUIComponents();
    //------------------------------------------------------------------------
    // Define the home window
    //------------------------------------------------------------------------
    QCOM_ConstructHomeWindow();
    //------------------------------------------------------------------------
    // Install the program utilities and their components
    //------------------------------------------------------------------------
    QCOM_InstallUtilities();
    //------------------------------------------------------------------------
    // Make all global objects reflect flag and state settings
    //------------------------------------------------------------------------
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    //------------------------------------------------------------------------
    // Populate the user interface with initial values
    //------------------------------------------------------------------------
    QCOM_InitializeUserInterface();
    //------------------------------------------------------------------------
    // Remove the "Please wait . . ." window
    //------------------------------------------------------------------------
    QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ConstructAndPresentUserInterface()
//----------------------------------------------------------------------------
// QCOM_ConstructHomeWindow
//
// Displays the home window, except for the size
//
// Called by:   QCOM_ConstructAndPresentUserInterface
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConstructHomeWindow(void)
{
    String          ^functionName = _T("QCOM_ConstructHomeWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    this->Width = GUI_HOME_WINDOW_WIDTH;
    this->Height = GUI_HOME_WINDOW_HEIGHT;
    this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
    this->MaximizeBox = GUI_NO;
    //------------------------------------------------------------------------
    // Home window title
    //------------------------------------------------------------------------
     this->Text = String::Concat(
        GUI_HOME_WINDOW_TITLE, QCOM_STRING_SPACE, QCOM_PROGRAM_VER_STRING);
//     this->DoubleBuffered = GUI_YES;
    //------------------------------------------------------------------------
    // QCOM icon
    //------------------------------------------------------------------------
    this->Icon = QCOM_SoftwareIcon;
    //------------------------------------------------------------------------
    // Background
    //------------------------------------------------------------------------
    this->BackgroundImage = woodGrainBackground;
    //------------------------------------------------------------------------
    // Opening banner, 'Exit' button, tool strip, status strip, and status
    // lights
    //------------------------------------------------------------------------
    QCOM_InstallHomeWindowGraphics();
    //------------------------------------------------------------------------
    // Home window mouse movement detection
    //------------------------------------------------------------------------
    this->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_HomeWindowEntered);
    this->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_HomeWindowExited);
    //------------------------------------------------------------------------
    // Register a method to handle the FormClosing event
    //------------------------------------------------------------------------
    this->FormClosing +=
        gcnew FormClosingEventHandler(this, &QCOM_GUIClass::QCOM_HomeClosingWindow);
    //------------------------------------------------------------------------
    // Create the home window tabs
    //------------------------------------------------------------------------
    QCOM_ConstructHomeTabPages();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ConstructHomeWindow()
//----------------------------------------------------------------------------
// QCOM_InitializeGUIComponents
//
// Initializes the remaining program entities prior to displaying and running
//
// Called by:   QCOM_ConstructAndPresentUserInterface
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InitializeGUIComponents(void)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_InitializeGUIComponents");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Initialize global managed arrays for all possible instances
    //------------------------------------------------------------------------
    expertManageMultipleCFButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    expertRealTimeWeightCalibrateButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    expertRealTimeWeightStartStopButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    expertTransducerPowerButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingClearGraphButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingClearLogButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingPauseResumeButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingSaveGraphButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingSingleStepButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingStartStopLoggingButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingStartStopSamplingButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllClearButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllSelectFileButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllSnapshotDataButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllStartStopButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitClearButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitInsertCommentButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitPauseResumeButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitSelectFileButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitSnapshotDataButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitStartStopButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscBootLoaderButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscDisplayRawModuleCoeffButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscDisplayRawXDCoeffButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscDisplayDLLFunctionsButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscI2CSendButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscReadXDMemoryButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscToggleTransducerTypeButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscWriteXDMemoryButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    multipleModuleCopyButtonArray = gcnew array <array <Button ^> ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutDisplayDataGraphButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutClearLogButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutStartStopLoggingButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutStartStopSamplingButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingClearResultsButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingSaveResultsButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingSelectResultsFileButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingStartStopButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    utilDisplayTCCheckButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    utilImportCoefficientDataFileButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    utilExportCoefficientDataFileButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    utilLogUnitDisplayButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    utilResetModuleButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    utilResetTransducerButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    utilUpdateFirmwareButtonArray = gcnew array <Button ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);

    expertSendTransducerReadingsCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingBothFileFormatsCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingDisplayAmperageDrawCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingMilitaryTimeFormatCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingSuperimposePressureTemperatureCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingUseThickLinesCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllDisplayCaptionCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllEmbedCaptionCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitAllCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitAltPressureCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitAltTemperatureCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitBothFileFormatsCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitCountsInHexCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitDateStampCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitDefaultsCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitDefPressureCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitDefTemperatureCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitDisplayCaptionAllCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitDisplaySummaryCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitDisplayWrapCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitEmbedCaptionCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitInsertCommentTimeStampCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitPrependEntryNumbersCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitMillisecondsCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitPressureCountCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitPressureFrequencyCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitSaveLoggedDataImmediatelyCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitTemperatureCountCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitTemperatureFrequencyCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitTimeStampLogCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitTransducerAmperageCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitTransducerVoltageCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutDisplayFrequenciesCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutDisplayVIValuesCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutIncludeInSamplingCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingAllModuleCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingAllTransducerCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingQMEMCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingDetailedCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingFirmwareCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingI2CCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingReadingsCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingTimeStampCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingX2CheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingX3CheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingX4CheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingXDCommCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingXDIntegrityCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingXDMemoryCheckArray = gcnew array <CheckBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);

    miscI2CCommandComboArray = gcnew array <ComboBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);

    displayCFDataWindowArray = gcnew array <Form ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS + 1);
    displayRawCFDataWindowArray = gcnew array <Form ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS + 1);
    graphingWindowArray = gcnew array <Form ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitWindowArray = gcnew array <Form ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscDisplayDLLFunctionsWindowArray = gcnew array <Form ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    multipleCoefficientDataWindowArray = gcnew array <Form ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);

    expertGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllAppendOverwriteGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitAppendOverwriteGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetCadenceTimerGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetControlRegisterGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetErrorCodeGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetFirmwareIDGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetMemoryTypeGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetSetI2CDataRateGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetTransducerChipIDGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetTransducerTypeGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetModuleSerialNumberGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetStatusRegisterGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscI2CSendCommandGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscUnitGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testUnitGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
//    unitTestsGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    utilitiesGroupBoxArray = gcnew array <GroupBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);

    expertSendEveryLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    expertSendEveryMinutesLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    expertSendEveryMinutesRemainingLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingAmperageHighBoundaryLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingAmperageHighBoundaryUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingAmperageLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingAmperageLowBoundaryLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingAmperageLowBoundaryUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingAmperageUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingAmperageValueLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingPressureHighBoundaryUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingPressureLowBoundaryUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingPressureUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingPressureValueLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingTemperatureHighBoundaryUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingTemperatureLowBoundaryUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingTemperatureUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingTemperatureValueLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingTimeBetweenSamplesLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingTransducerPartNumberLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingTransducerSerialNumberLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllCaptionLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllFileLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllPercentFullLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitCaptionLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitFileLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitPercentFullLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitTimeLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscI2CReplyInterpLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    multipleSerialNumberModuleLabelArray = gcnew array <array <Label ^> ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    multipleSerialNumberTransducerLabelArray = gcnew array <array <Label ^> ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutAmperageTitleLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutAmperageUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutTemperatureTitleLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutTemperatureUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutFirmwareInfoLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutPressureFrequencyTitleLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutPressureFrequencyUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutPressureTitleLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutPressureUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutTemperatureFrequencyTitleLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutTemperatureFrequencyUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutVoltageTitleLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutVoltageUnitsLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingPassCountLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingPercentCompleteLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingResultsFileLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingRunningTimeLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingStateLabelArray = gcnew array <Label ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);

    graphingPictureBoxArray = gcnew array <PictureBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);

    logAllPercentFullProgressArray = gcnew array <ProgressBar ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitPercentFullProgressArray = gcnew array <ProgressBar ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingPercentCompleteProgressArray = gcnew array <ProgressBar ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);

    graphingAlternatePTUnitsRadioArray = gcnew array <RadioButton ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingDefaultPTUnitsRadioArray = gcnew array <RadioButton ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllAppendRadioArray = gcnew array <RadioButton ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllAutoSaveAllRadioArray = gcnew array <RadioButton ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllOverwriteRadioArray = gcnew array <RadioButton ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllPromptRadioArray = gcnew array <RadioButton ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitAppendRadioArray = gcnew array <RadioButton ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitAutoSaveRadioArray = gcnew array <RadioButton ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitOverwriteRadioArray = gcnew array <RadioButton ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitPromptRadioArray = gcnew array <RadioButton ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);

    testingDetailedResultsBoxArray = gcnew array <RichTextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingSummaryResultsBoxArray = gcnew array <RichTextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);

    QCOM_IntervalUnitsStringArray = gcnew array <String ^>
        {
            _T("ms"), _T("sec"), _T("min"), _T("hr")
        };
    QCOM_PressureUnitsStringArray = gcnew array <String ^>
        {
            _T("psi"), _T("bar"), _T("mbar"), _T("Pa (N/m�)"), _T("kPa"), _T("MPa"), _T("hPa"),
            _T("mmHg"), _T("inHg"), _T("mH2O"), _T("inH2O"), _T("atm"), _T("Torr"), _T("dyn/cm�"), _T("msw")
        };
    QCOM_TemperatureUnitsStringArray = gcnew array <String ^>
        {
            _T("�C"), _T("�F"), _T("K"), _T("�R")
        };
    QCOM_AmperageUnitsStringArray = gcnew array <String ^>
        {
            _T("mA"), _T("A")
        };
    //------------------------------------------------------------------------
    // Note: If the strings that contain Extended ASCII characters in this
    // file get copied to another file, care must be taken to ensure the
    // special characters get translated correctly during the copy process
    //------------------------------------------------------------------------
    expertUnitTabPageArray = gcnew array <TabPage ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllUnitTabPageArray = gcnew array <TabPage ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscTabPageArray = gcnew array <TabPage ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    pInfoTabPageArray = gcnew array <TabPage ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutUnitTabPageArray = gcnew array <TabPage ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    testingUnitTabPageArray = gcnew array <TabPage ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    utilitiesUnitTabPageArray = gcnew array <TabPage ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);

    expertSendEveryBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingAmperageHighBoundaryBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingAmperageLowBoundaryBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingPressureHighBoundaryBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingPressureLowBoundaryBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingTemperatureHighBoundaryBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    graphingTemperatureLowBoundaryBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logAllBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    logUnitInsertCommentBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetDataRateBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetCadenceTimerBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetControlRegisterBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetErrorCodeBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetFirmwareIDBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetMemoryTypeBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetStatusRegisterBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetTransducerChipIDBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetTransducerTypeBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscGetModuleSerialNumberBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    miscI2CResponseBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutAmperageBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutPressureBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutPressureFrequencyBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutTemperatureBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutTemperatureFrequencyBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    readoutVoltageBoxArray = gcnew array <TextBox ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    //------------------------------------------------------------------------
    // Initialize global unit elements
    //------------------------------------------------------------------------
    QCOM_LogSpinLockArray = gcnew array <SpinLock ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    QCOM_TestSpinLockArray = gcnew array <SpinLock ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    QCOM_UnitAccessSpinLockArray = gcnew array <SpinLock ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    sendEveryTimerArray = gcnew array <Windows::Forms::Timer ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        QCOM_LogSpinLockArray[unitNumber] = gcnew SpinLock;
        QCOM_TestSpinLockArray[unitNumber] = gcnew SpinLock;
        QCOM_UnitAccessSpinLockArray[unitNumber] = gcnew SpinLock;
        sendEveryTimerArray[unitNumber] = gcnew Windows::Forms::Timer;
        sendEveryTimerArray[unitNumber]->Tag = unitNumber;
        sendEveryTimerArray[unitNumber]->Stop();
        sendEveryTimerArray[unitNumber]->Tick +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_SendEveryTimerElapsed);
        multipleSerialNumberModuleLabelArray[unitNumber] = gcnew array <Label ^> (4);
        multipleSerialNumberTransducerLabelArray[unitNumber] = gcnew array <Label ^> (4);
        multipleModuleCopyButtonArray[unitNumber] = gcnew array <Button ^> (4);
        if (QCOM_UnitNumberValid(unitNumber))
        {
            unit = QCOM_UnitInfoArray[unitNumber];
//            QCOM_SetUnitFlagsToInitialValues(unit);
            QCOM_GraphingSetGraphingThresholds(unit);
            unit->graphingPressureVerticalPosition = QCOM_GraphingCalculateVerticalPosition(
                unit,
                GUI_UNIT_GRAPH_CONTEXT_PRESSURE);
            unit->graphingTemperatureVerticalPosition = QCOM_GraphingCalculateVerticalPosition(
                unit,
                GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE);
            unit->graphingAmperageVerticalPosition = QCOM_GraphingCalculateVerticalPosition(
                unit,
                GUI_UNIT_GRAPH_CONTEXT_AMPERAGE);
        }
    }
    QCOM_PrecisionFormatString = String::Concat("{0:F", QCOM_CurrentPrecision, "}");
    //------------------------------------------------------------------------
    // Set up the one-second (heartbeat) timer
    //
    // This non-adjustable timer is for anything that needs a one-second
    // interval
    //------------------------------------------------------------------------
    oneSecondTimer = gcnew Windows::Forms::Timer;
    oneSecondTimer->Interval = GUI_ONE_SECOND_INTERVAL;
    oneSecondTimer->Stop();
    oneSecondTimer->Tick +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_OneSecondTimerElapsed);
    //------------------------------------------------------------------------
    // Set up the one-minute timer
    //
    // This non-adjustable timer is for anything that needs a one-minute
    // interval
    //------------------------------------------------------------------------
    oneMinuteTimer = gcnew Windows::Forms::Timer;
    oneMinuteTimer->Interval = GUI_ONE_MINUTE_INTERVAL;
    oneMinuteTimer->Stop();
    oneMinuteTimer->Tick +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_OneMinuteTimerElapsed);
    //------------------------------------------------------------------------
    // Set up the general program timer
    //
    // This adjustable timer is used primarily for GUI updates and hot-pug
    // support
    //------------------------------------------------------------------------
    programTimer = gcnew Windows::Forms::Timer;
    programTimer->Stop();
    programTimer->Tick +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ProgramTimerElapsed);
    //------------------------------------------------------------------------
    // Set up the sampling timer
    //
    // This adjustable timer is used to control the interval at which the
    // program samples the transducers for data
    //------------------------------------------------------------------------
    samplingTimer = gcnew Windows::Forms::Timer;
    samplingTimer->Stop();
    samplingTimer->Tick +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_SamplingTimerElapsed);
//    GC::KeepAlive(samplingTimer); // use only if this timer is declared in this method (it's not)
    //------------------------------------------------------------------------
    // Other tasks needed prior to user interface construction
    //------------------------------------------------------------------------
    QCOM_AffirmStartupConditions();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_InitializeGUIComponents()
//----------------------------------------------------------------------------
// QCOM_InitializeUserInterface
//
// Populates the user interface with initial values
//
// Note:    These are the last lines to execute before going to idle, and
//          should only be run once
//
// Called by:   QCOM_ConstructAndPresentUserInterface
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InitializeUserInterface(void)
{
    bool            atLeastOneTransducerAvailable = GUI_NO;
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("QCOM_InitializeUserInterface");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Populate the readout text boxes with initial values
    //------------------------------------------------------------------------
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
            if (QCOM_XDPresent(unit))
            {
                atLeastOneTransducerAvailable = GUI_YES;
            }
            if (QCOM_UnitReady(unit))
            {
                QCOM_RetrieveTransducerReadings(unit);
            }
            QCOM_LogUnitDetermineDataLogFilePaths(unit);
            QCOM_TestDetermineResultsFilePath(unit);
            QCOM_TestDetermineDataFilePath(unit);
            QCOM_TestDetermineFirmwareFilePath(unit);
            QCOM_UpdateReadout(unit);
            testingRunningTimeLabelArray[unitNumber]->Enabled = GUI_NO;
            sendEveryTimerArray[unitNumber]->Interval =
                QCOM_CurrentSendEveryInterval[unitNumber] * GUI_INTERVAL_MIN_MULTIPLIER;
            //----------------------------------------------------------------
            // Copy and reset the module-transducer pair structures
            //----------------------------------------------------------------
            ModuleTransducerPair ^unitPair = QCOM_ModuleTransducerPairArray[unitNumber];
            if (unitPair)
            {
                unitPair->currentUnitPair = String::Concat(
                    unitPair->newModuleSerialNumber,
                    unitPair->newTransducerSerialNumber);
                unitPair->currentModuleSerialNumber = unitPair->newModuleSerialNumber;
                unitPair->currentTransducerSerialNumber = unitPair->newTransducerSerialNumber;
                unitPair->newModuleSerialNumber = String::Empty;
                unitPair->newTransducerSerialNumber = String::Empty;
            }
        }                               // end of if (QCOM_UnitNumberValid(unitNumber))
    }                                   // end of for (DWORD unitNumber = 0; ...)
    //------------------------------------------------------------------------
    // Initialize the status line with the current date-and-time, and a welcome
    //------------------------------------------------------------------------
    if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_GUI_UP_AND_RUNNING))
    {
        nowStatusLineTSSLabel->Text = String::Format(
            "{0,9} {1:D2} {2} {3:D4} {4:D2}:{5:D2}:{6:D2}",
            dateTime.DayOfWeek,
            dateTime.Day,
            QCOM_MonthStringArray[dateTime.Month],
            dateTime.Year,
            dateTime.Hour,
            dateTime.Minute,
            dateTime.Second);
        QCOM_HomeUpdateProgressBar(0, 0);
        QCOM_UpdateStatusLine("Welcome to QCOM");
        //--------------------------------------------------------------------
        // Signal that the GUI is up and running, ready for interaction
        //--------------------------------------------------------------------
        QCOM_GeneralInfo->flags |= QCOM_GENERAL_GUI_UP_AND_RUNNING;
    }
    oneSecondTimer->Start();
    oneMinuteTimer->Start();
    if (QCOM_ProgramIntervalEnabled)
    {
        programTimer->Interval = QCOM_CurrentProgramInterval;
        programTimer->Start();
        QCOM_GeneralInfo->flags |= QCOM_GENERAL_PROGRAM_TIMER_RUNNING;
    }
    samplingTimer->Interval = QCOM_MapDisplayIntervalToActual(QCOM_CurrentSamplingInterval);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_InitializeUserInterface()
//----------------------------------------------------------------------------
// QCOM_InstallHomeWindowGraphics
//
// Displays an active Exit button and three LED icons in the home window
//
// Called by:   QCOM_ConstructUserInterface
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InstallHomeWindowGraphics(void)
{
    String          ^functionName = _T("QCOM_InstallHomeWindowGraphics");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    this->SuspendLayout();
    //------------------------------------------------------------------------
    // Toolbar (actually, a tool strip)
    //------------------------------------------------------------------------
    QCOM_InstallToolStrip();
    //------------------------------------------------------------------------
    // Status bar (actually, a status strip)
    //------------------------------------------------------------------------
    QCOM_InstallStatusStrip();
    //------------------------------------------------------------------------
    // Opening banner, displaying the number of transducers detected
    //------------------------------------------------------------------------
    openingBannerLabel = gcnew Label;
    openingBannerLabel->Location = Point(10, 20);
    openingBannerLabel->Size = Drawing::Size(GUI_HOME_TAB_PAGE_WIDTH, 40);
    openingBannerLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        20.0F,                          // em-size of the font
        FontStyle::Bold);               // choose from Bold, Italic, Underline, Strikeout
    openingBannerLabel->ForeColor = Color::OliveDrab;
    openingBannerLabel->BackColor = Color::Transparent;
    openingBannerLabel->TextAlign = Drawing::ContentAlignment::BottomLeft;
    openingBannerLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_HomeOpeningBannerMouseEntered);
    openingBannerLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    Controls->Add(openingBannerLabel);
    //------------------------------------------------------------------------
    // Exit button
    //------------------------------------------------------------------------
    Image ^exitImage = Image::FromFile(GUI_PIC_EXIT_BUTTON);
    Button ^exitButton = gcnew Button;
    exitButton->Location = Point(
        GUI_HOME_WINDOW_WIDTH - 110,
        50);
    exitButton->Size = Drawing::Size(75, 75);
    exitButton->BackgroundImage = exitImage;
    exitButton->BackgroundImageLayout = ImageLayout::Center;
    exitButton->TabIndex = 0;
    GUI_SetObjectInterfaceProperties(exitButton);
    exitButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExitProgram);
    exitButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_HomeExitButtonMouseEntered);
    exitButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    this->AcceptButton = exitButton;
    this->CancelButton = exitButton;
    //------------------------------------------------------------------------
    // Sampling Status LED and label
    //------------------------------------------------------------------------
    homeSamplingStatusButton = gcnew Button;
    homeSamplingStatusButton->Location = Point(
        GUI_HOME_WINDOW_WIDTH - 88,
        exitButton->Bottom + 20);
    homeSamplingStatusButton->Size = Drawing::Size(30, 30);
    homeSamplingStatusButton->BackgroundImageLayout = ImageLayout::Center;
    GUI_SetObjectInterfaceProperties(homeSamplingStatusButton);
    homeSamplingStatusButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_StartStopSamplingButtonClicked);
    homeSamplingStatusButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutStartStopSamplingButtonMouseEntered);
    homeSamplingStatusButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    homeSamplingStatusLabel = gcnew Label;
    homeSamplingStatusLabel->Size = Drawing::Size(100, 18);
    homeSamplingStatusLabel->Location = Point(
        homeSamplingStatusButton->Left - 35,
        homeSamplingStatusButton->Bottom + 4);
    homeSamplingStatusLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    homeSamplingStatusLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    GUI_SetObjectInterfaceProperties(homeSamplingStatusLabel);
    homeSamplingStatusLabel->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_StartStopSamplingButtonClicked);
    homeSamplingStatusLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutStartStopSamplingButtonMouseEntered);
    homeSamplingStatusLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Logging Status LED and label
    //------------------------------------------------------------------------
    homeLoggingStatusButton = gcnew Button;
    homeLoggingStatusButton->Location = Point(
        homeSamplingStatusButton->Left,
        homeSamplingStatusLabel->Bottom + 20);
    homeLoggingStatusButton->Size = homeSamplingStatusButton->Size;
    homeLoggingStatusButton->BackgroundImageLayout = ImageLayout::Center;
    GUI_SetObjectInterfaceProperties(homeLoggingStatusButton);
    homeLoggingStatusButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllStartStopButtonClicked);
    homeLoggingStatusButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutStartStopLoggingAllButtonMouseEntered);
    homeLoggingStatusButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    homeLoggingStatusLabel = gcnew Label;
    homeLoggingStatusLabel->Size = homeSamplingStatusLabel->Size;
    homeLoggingStatusLabel->Location = Point(
        homeSamplingStatusLabel->Left,
        homeLoggingStatusButton->Bottom + 4);
    homeLoggingStatusLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    homeLoggingStatusLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    GUI_SetObjectInterfaceProperties(homeLoggingStatusLabel);
    homeLoggingStatusLabel->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllStartStopButtonClicked);
    homeLoggingStatusLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutStartStopLoggingAllButtonMouseEntered);
    homeLoggingStatusLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Testing Status LED and label
    //------------------------------------------------------------------------
    homeTestingStatusButton = gcnew Button;
    homeTestingStatusButton->Location = Point(
        homeLoggingStatusButton->Left,
        homeLoggingStatusLabel->Bottom + 20);
    homeTestingStatusButton->Size = homeLoggingStatusButton->Size;
    homeTestingStatusButton->BackgroundImageLayout = ImageLayout::Center;
    GUI_SetObjectInterfaceProperties(homeTestingStatusButton);
    homeTestingStatusButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllStartStopTestingButtonClicked);
    homeTestingStatusButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllStartStopTestingButtonMouseEntered);
    homeTestingStatusButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    homeTestingStatusLabel = gcnew Label;
    homeTestingStatusLabel->Size = homeLoggingStatusLabel->Size;
    homeTestingStatusLabel->Location = Point(
        homeLoggingStatusLabel->Left,
        homeTestingStatusButton->Bottom + 4);
    homeTestingStatusLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    homeTestingStatusLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    GUI_SetObjectInterfaceProperties(homeTestingStatusLabel);
    homeTestingStatusLabel->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllStartStopTestingButtonClicked);
    homeTestingStatusLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllStartStopTestingButtonMouseEntered);
    homeTestingStatusLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Sending Status LED and label
    //------------------------------------------------------------------------
    homeSendingStatusButton = gcnew Button;
    homeSendingStatusButton->Location = Point(
        homeTestingStatusButton->Left,
        homeTestingStatusLabel->Bottom + 20);
    homeSendingStatusButton->Size = homeTestingStatusButton->Size;
    homeSendingStatusButton->BackgroundImageLayout = ImageLayout::Center;
    GUI_SetObjectInterfaceProperties(homeSendingStatusButton);
    homeSendingStatusButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertSendAllTransducerReadingsChecked);
    homeSendingStatusButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertSendAllTransducerReadingsAreaMouseEntered);
    homeSendingStatusButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    homeSendingStatusLabel = gcnew Label;
    homeSendingStatusLabel->Size = homeTestingStatusLabel->Size;
    homeSendingStatusLabel->Location = Point(
        homeTestingStatusLabel->Left,
        homeSendingStatusButton->Bottom + 4);
    homeSendingStatusLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    homeSendingStatusLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    GUI_SetObjectInterfaceProperties(homeSendingStatusLabel);
    homeSendingStatusLabel->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertSendAllTransducerReadingsChecked);
    homeSendingStatusLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertSendAllTransducerReadingsAreaMouseEntered);
    homeSendingStatusLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE)
    {
        homeSendingStatusButton->Visible = GUI_YES;
        homeSendingStatusLabel->Visible = GUI_YES;
    }
    else
    {
        homeSendingStatusButton->Visible = GUI_NO;
        homeSendingStatusLabel->Visible = GUI_NO;
    }
    //------------------------------------------------------------------------
    // Add the components to the home window
    //------------------------------------------------------------------------
    array <Button ^> ^homeWindowButtons =
    {
        exitButton,
        homeSamplingStatusButton,
        homeLoggingStatusButton,
        homeTestingStatusButton,
        homeSendingStatusButton
    };
    Controls->AddRange(homeWindowButtons);
    array <Label ^> ^homeWindowLabels =
    {
        homeSamplingStatusLabel,
        homeLoggingStatusLabel,
        homeTestingStatusLabel,
        homeSendingStatusLabel
    };
    Controls->AddRange(homeWindowLabels);
    //------------------------------------------------------------------------
    // Resume the window display
    //------------------------------------------------------------------------
    this->ResumeLayout();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_InstallHomeWindowGraphics()
//----------------------------------------------------------------------------
// QCOM_InstallStatusStrip
//
// Displays the status strip (bottom status bar) in the home window
//
// Note:    A statusstrip is organized by the following hierarchy of classes:
//
//              StatusStrip
//              ToolStripStatusLabel / ToolStripSeparator / ToolStripProgressBar
//
// Called by:   QCOM_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InstallStatusStrip(void)
{
    String          ^functionName = _T("QCOM_InstallStatusStrip");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    this->SuspendLayout();
    homeStatusStrip = gcnew StatusStrip;
    //------------------------------------------------------------------------
    // Specify the status strip properties
    //------------------------------------------------------------------------
    homeStatusStrip->ShowItemToolTips = GUI_NO;
    homeStatusStrip->GripStyle = ToolStripGripStyle::Hidden;
    homeStatusStrip->SizingGrip = GUI_NO;
    homeStatusStrip->LayoutStyle = ToolStripLayoutStyle::Table;
    //------------------------------------------------------------------------
    // Create the left (main) panel
    //------------------------------------------------------------------------
    homeStatusLineTSSLabel = gcnew ToolStripStatusLabel;
    homeStatusLineTSSLabel->Spring = GUI_YES;
    homeStatusLineTSSLabel->Alignment = ToolStripItemAlignment::Left;
    homeStatusLineTSSLabel->BorderStyle = Border3DStyle::Sunken;
    homeStatusLineTSSLabel->BorderSides = ToolStripStatusLabelBorderSides::All;
    homeStatusLineTSSLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    homeStatusStrip->Items->Add(homeStatusLineTSSLabel);
    //------------------------------------------------------------------------
    // Create the progress bar and label, then initialize it
    //------------------------------------------------------------------------
    ToolStripSeparator ^verticalSeparator1 = gcnew ToolStripSeparator;
    verticalSeparator1->Width = 4;
    homeStatusStrip->Items->Add(verticalSeparator1);
    homeTSProgressBar = gcnew ToolStripProgressBar;
    homeTSProgressBar->Minimum = 0;
    homeTSProgressBar->Maximum = 100;
    homeTSProgressBar->Style = ProgressBarStyle::Continuous;
    homeStatusStrip->Items->Add(homeTSProgressBar);
    //------------------------------------------------------------------------
    // Create the right (time-of-day) panel
    //------------------------------------------------------------------------
    ToolStripSeparator ^verticalSeparator2 = gcnew ToolStripSeparator;
    verticalSeparator2->Width = 4;
    homeStatusStrip->Items->Add(verticalSeparator2);
    nowStatusLineTSSLabel = gcnew ToolStripStatusLabel;
    nowStatusLineTSSLabel->Alignment = ToolStripItemAlignment::Right;
    nowStatusLineTSSLabel->BorderStyle = Border3DStyle::Sunken;
    nowStatusLineTSSLabel->BorderSides = ToolStripStatusLabelBorderSides::All;
    homeStatusStrip->Items->Add(nowStatusLineTSSLabel);
    //------------------------------------------------------------------------
    // Display and initialize the resulting status strip
    //------------------------------------------------------------------------
    Controls->Add(homeStatusStrip);
    this->ResumeLayout();
    QCOM_GeneralInfo->flags |= QCOM_GENERAL_STATUS_LINE_AVAILABLE;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_InstallStatusStrip()
//----------------------------------------------------------------------------
// QCOM_InstallToolStrip
//
// Displays the tool strip (tool bar) in the home window
//
// Note:    A toolstrip is organized by the following hierarchy of classes:
//
//              ToolStrip
//              ToolStripDropDownButton
//              ToolStripDropDown
//              ToolStripButton (ToolStripButton)
//
// Called by:   QCOM_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InstallToolStrip(void)
{
    String          ^functionName = _T("QCOM_InstallToolStrip");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    this->SuspendLayout();
    ToolStrip ^toolStrip = gcnew ToolStrip;
    //------------------------------------------------------------------------
    // Tool strip properties
    //------------------------------------------------------------------------
    Bitmap ^toolStripBG = gcnew Bitmap(GUI_BG_TOOLSTRIP, GUI_YES);
    toolStrip->ShowItemToolTips = GUI_NO;
    toolStrip->AutoSize = GUI_YES;
    toolStrip->Size = Drawing::Size(this->Width, 25);
    toolStrip->BackgroundImage = toolStripBG;
    //------------------------------------------------------------------------
    // Open drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^openFileTSButton = gcnew ToolStripButton("Open");
    openFileTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilImportCoefficientDataFileButtonClicked);
    openFileTSButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // SaveAs drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^saveAsFileTSButton = gcnew ToolStripButton("Save As . . .");
    saveAsFileTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExportCoefficientDataFileButtonClicked);
    saveAsFileTSButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Print drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^printFileTSButton = gcnew ToolStripButton("Print");
    printFileTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_PrintFileButtonClicked);
    printFileTSButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Delete All Log Files drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    deleteAllLogFilesTSButton = gcnew ToolStripButton("Delete All Log Files");
    deleteAllLogFilesTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteAllLogFilesDropDownClicked);
    deleteAllLogFilesTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteAllLogFilesDropDownMouseEntered);
    deleteAllLogFilesTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Delete All Data Log drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    deleteAllDataLogFilesTSButton = gcnew ToolStripButton("Delete All Data Log Files");
    deleteAllDataLogFilesTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteAllDataLogFilesDropDownClicked);
    deleteAllDataLogFilesTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteAllDataLogFilesDropDownMouseEntered);
    deleteAllDataLogFilesTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Delete All Data CSV drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    deleteAllDataCSVFilesTSButton = gcnew ToolStripButton("Delete All Data CSV Files");
    deleteAllDataCSVFilesTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteAllDataCSVFilesDropDownClicked);
    deleteAllDataCSVFilesTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteAllDataCSVFilesDropDownMouseEntered);
    deleteAllDataCSVFilesTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Delete All Test Results drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    deleteAllTestResultsFilesTSButton = gcnew ToolStripButton("Delete All Test Results Files");
    deleteAllTestResultsFilesTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteAllTestResultsFilesDropDownClicked);
    deleteAllTestResultsFilesTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteAllTestResultsFilesDropDownMouseEntered);
    deleteAllTestResultsFilesTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Delete All Event Log drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    deleteAllEventLogFilesTSButton = gcnew ToolStripButton("Delete All Event Log Files");
    deleteAllEventLogFilesTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteAllEventLogFilesDropDownClicked);
    deleteAllEventLogFilesTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteAllEventLogFilesDropDownMouseEntered);
    deleteAllEventLogFilesTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Delete All Error Log drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    deleteAllErrorLogFilesTSButton = gcnew ToolStripButton("Delete All Error Log Files");
    deleteAllErrorLogFilesTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteAllErrorLogFilesDropDownClicked);
    deleteAllErrorLogFilesTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteAllErrorLogFilesDropDownMouseEntered);
    deleteAllErrorLogFilesTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Reset drop-down and its properties
    //------------------------------------------------------------------------
    ToolStripDropDown ^deleteDropDown = gcnew ToolStripDropDown;
    deleteDropDown->BackColor = Color::Wheat;
    deleteDropDown->ShowItemToolTips = GUI_NO;
    deleteDropDown->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteLogFilesMouseExited);
    //------------------------------------------------------------------------
    // Add these entries to the Delete drop-down
    //------------------------------------------------------------------------
    array <ToolStripItem ^> ^deleteDropDownItems =
    {
        deleteAllLogFilesTSButton,
        deleteAllDataLogFilesTSButton,
        deleteAllDataCSVFilesTSButton,
        deleteAllTestResultsFilesTSButton,
        deleteAllEventLogFilesTSButton,
        deleteAllErrorLogFilesTSButton
    };
    deleteDropDown->Items->AddRange(deleteDropDownItems);
    //------------------------------------------------------------------------
    // Delete toolstrip button as a sub-drop-down
    //------------------------------------------------------------------------
    deleteTSDDButton = gcnew ToolStripDropDownButton("Delete Log Files");
    deleteTSDDButton->DropDown = deleteDropDown;
    deleteTSDDButton->ShowDropDownArrow = GUI_NO;
    deleteTSDDButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDeleteDropDownMouseEntered);
    deleteTSDDButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Config Save drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    configFileTSButton = gcnew ToolStripButton;
    configFileTSButton->Text =
        (QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DONT_SAVE) ?
            GUI_ENABLE_CONFIG_SAVE_STRING : GUI_DISABLE_CONFIG_SAVE_STRING;
    configFileTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ConfigFileSaveDontSaveAreaClicked);
    configFileTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripConfigFileSaveDontSaveAreaMouseEntered);
    configFileTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Log Save drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    saveLogFilesOnExitTSButton = gcnew ToolStripButton;
    saveLogFilesOnExitTSButton->Text =
        (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DONT_SAVE_ON_EXIT) ?
            GUI_ENABLE_LOGS_SAVE_STRING : GUI_DISABLE_LOGS_SAVE_STRING;
    saveLogFilesOnExitTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripLogFilesSaveDropDownClicked);
    saveLogFilesOnExitTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripLogFilesSaveDropDownMouseEntered);
    saveLogFilesOnExitTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Exit drop-down 'button' for the File drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^exitProgramTSButton = gcnew ToolStripButton("Exit QCOM");
    exitProgramTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExitProgram);
    exitProgramTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_HomeExitButtonMouseEntered);
    exitProgramTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // File toolstrip drop-down and its properties
    //------------------------------------------------------------------------
    ToolStripDropDown ^fileDropDown = gcnew ToolStripDropDown;
    fileDropDown->BackColor = Color::Wheat;
    fileDropDown->ShowItemToolTips = GUI_NO;
    fileDropDown->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDropDownsMouseExited);
    //------------------------------------------------------------------------
    // Add the tool strip buttons to the File drop-down
    //------------------------------------------------------------------------
    array <ToolStripItem ^> ^fileDropDownItems =
    {
        openFileTSButton,
        saveAsFileTSButton,
        printFileTSButton,
        deleteTSDDButton,
        configFileTSButton,
        saveLogFilesOnExitTSButton,
        exitProgramTSButton
    };
    fileDropDown->Items->AddRange(fileDropDownItems);
    //------------------------------------------------------------------------
    // File toolstrip button as a drop-down
    //------------------------------------------------------------------------
    fileTSDDButton = gcnew ToolStripDropDownButton("File");
    fileTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    fileTSDDButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    fileTSDDButton->DropDown = fileDropDown;
    fileTSDDButton->ShowDropDownArrow = GUI_NO;
    fileTSDDButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripFileButtonMouseEntered);
    fileTSDDButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripButtonsMouseExited);
    fileTSDDButton->MouseMove +=
        gcnew MouseEventHandler(this, &QCOM_GUIClass::QCOM_ToolStripFileButtonMouseMoved);
    //------------------------------------------------------------------------
    // Reset All Modules drop-down 'button' for the Functions drop-down
    //------------------------------------------------------------------------
    resetAllModulesFunctionTSButton = gcnew ToolStripButton("Reset All QCOM Modules");
    resetAllModulesFunctionTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripResetAllModulesDropDownClicked);
    resetAllModulesFunctionTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripResetAllModulesDropDownMouseEntered);
    resetAllModulesFunctionTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Reset All Transducers drop-down 'button' for the Functions drop-down
    //------------------------------------------------------------------------
    resetAllTransducersFunctionTSButton = gcnew ToolStripButton("Reset All Transducers");
    resetAllTransducersFunctionTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripResetAllTransducersDropDownClicked);
    resetAllTransducersFunctionTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripResetAllTransducersDropDownMouseEntered);
    resetAllTransducersFunctionTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Reset Software drop-down 'button' for the Functions drop-down
    //------------------------------------------------------------------------
    resetSoftwareFunctionTSButton = gcnew ToolStripButton("Reset All QCOM Software");
    resetSoftwareFunctionTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripResetAllSoftwareDropDownClicked);
    resetSoftwareFunctionTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripResetAllSoftwareDropDownMouseEntered);
    resetSoftwareFunctionTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Reset All drop-down 'button' for the Functions drop-down
    //------------------------------------------------------------------------
    resetAllFunctionTSButton = gcnew ToolStripButton("Reset All QCOM Hardware and Software");
    resetAllFunctionTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ResetAllButtonClicked);
    resetAllFunctionTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripResetAllDropDownMouseEntered);
    resetAllFunctionTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Reset drop-down and its properties
    //------------------------------------------------------------------------
    ToolStripDropDown ^resetDropDown = gcnew ToolStripDropDown;
    resetDropDown->BackColor = Color::Wheat;
    resetDropDown->ShowItemToolTips = GUI_NO;
    resetDropDown->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripResetFunctionMouseExited);
    //------------------------------------------------------------------------
    // Add these entries to the Reset drop-down
    //------------------------------------------------------------------------
    array <ToolStripItem ^> ^resetDropDownItems =
    {
        resetAllModulesFunctionTSButton,
        resetAllTransducersFunctionTSButton,
        resetSoftwareFunctionTSButton,
        resetAllFunctionTSButton
    };
    resetDropDown->Items->AddRange(resetDropDownItems);
    //------------------------------------------------------------------------
    // Reset toolstrip button as a sub-drop-down
    //------------------------------------------------------------------------
    resetTSDDButton = gcnew ToolStripDropDownButton("Reset");
    resetTSDDButton->DropDown = resetDropDown;
    resetTSDDButton->ShowDropDownArrow = GUI_NO;
    resetTSDDButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripResetDropDownMouseEntered);
    resetTSDDButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Rescan drop-down 'button' for the Functions drop-down
    //------------------------------------------------------------------------
    rescanFunctionTSButton = gcnew ToolStripButton("Rescan QCOM Devices");
    rescanFunctionTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripReScanDropDownClicked);
    rescanFunctionTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripReScanDropDownMouseEntered);
    rescanFunctionTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Expert Mode drop-down 'button' for the Functions drop-down
    //------------------------------------------------------------------------
    expertFunctionTSButton = gcnew ToolStripButton;
    expertFunctionTSButton->Text =
        (QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE) ?
            GUI_DISABLE_EXPERT_MODE_STRING : GUI_ENABLE_EXPERT_MODE_STRING;
    expertFunctionTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripExpertModeDropDownClicked);
    expertFunctionTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripExpertModeDropDownMouseEntered);
    expertFunctionTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Functions drop-down and its properties
    //------------------------------------------------------------------------
    ToolStripDropDown ^functionsDropDown = gcnew ToolStripDropDown;
    functionsDropDown->BackColor = Color::Wheat;
    functionsDropDown->ShowItemToolTips = GUI_NO;
//    functionsDropDown->AutoClose = GUI_YES;
    functionsDropDown->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDropDownsMouseExited);
    //------------------------------------------------------------------------
    // Functions buttons to the Functions drop-down
    //------------------------------------------------------------------------
    array <ToolStripItem ^> ^functionsDropDownItems =
    {
        resetTSDDButton,
        rescanFunctionTSButton,
        expertFunctionTSButton
    };
    functionsDropDown->Items->AddRange(functionsDropDownItems);
    //------------------------------------------------------------------------
    // Functions toolstrip button as a drop-down
    //------------------------------------------------------------------------
    functionsTSDDButton = gcnew ToolStripDropDownButton("Functions");
    functionsTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    functionsTSDDButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    functionsTSDDButton->DropDown = functionsDropDown;
    functionsTSDDButton->ShowDropDownArrow = GUI_NO;
    functionsTSDDButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripFunctionsButtonMouseEntered);
    functionsTSDDButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripButtonsMouseExited);
    functionsTSDDButton->MouseMove +=
        gcnew MouseEventHandler(this, &QCOM_GUIClass::QCOM_ToolStripFunctionsButtonMouseMoved);
    //------------------------------------------------------------------------
    // About drop-down 'button' for the Help drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^aboutTSButton = gcnew ToolStripButton("About QCOM");
    aboutTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripAboutDropDownClicked);
    aboutTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripAboutDropDownMouseEntered);
    aboutTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Online Help drop-down 'button' for the Help drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^onlineHelpTSButton = gcnew ToolStripButton("Online Help");
    onlineHelpTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripOnlineHelpDropDownClicked);
    onlineHelpTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripOnlineHelpDropDownMouseEntered);
    onlineHelpTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Support Log drop-down 'button' for the Help drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^supportLogTSButton = gcnew ToolStripButton("Create a Support Log");
    supportLogTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripSupportLogDropDownClicked);
    supportLogTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripSupportLogDropDownMouseEntered);
    supportLogTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Check For Update drop-down 'button' for the Help drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^checkForUpdateTSButton = gcnew ToolStripButton("Check for Update");
    checkForUpdateTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripCheckForUpdateDropDownClicked);
    checkForUpdateTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripCheckForUpdateDropDownMouseEntered);
    checkForUpdateTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Download the Latest drop-down 'button' for the Help drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^downloadTheLatestTSButton = gcnew ToolStripButton("Download the Latest");
    downloadTheLatestTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDownloadTheLatestDropDownClicked);
    downloadTheLatestTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDownloadTheLatestDropDownMouseEntered);
    downloadTheLatestTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Help toolstrip drop-down and its properties
    //------------------------------------------------------------------------
    helpTSDropDown = gcnew ToolStripDropDown;
    helpTSDropDown->BackColor = Color::Wheat;
    helpTSDropDown->ShowItemToolTips = GUI_NO;
    helpTSDropDown->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDropDownsMouseExited);
    //------------------------------------------------------------------------
    // Add these entries to the Help drop-down
    //------------------------------------------------------------------------
    array <ToolStripItem ^> ^helpTSDropDownItems =
    {
        aboutTSButton,
        onlineHelpTSButton,
        supportLogTSButton,
        checkForUpdateTSButton,
        downloadTheLatestTSButton
    };
    helpTSDropDown->Items->AddRange(helpTSDropDownItems);
    //------------------------------------------------------------------------
    // Help toolstrip button as a drop-down
    //------------------------------------------------------------------------
    helpTSDDButton = gcnew ToolStripDropDownButton("Help");
    helpTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    helpTSDDButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    helpTSDDButton->DropDown = helpTSDropDown;
    helpTSDDButton->ShowDropDownArrow = GUI_NO;
    helpTSDDButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripHelpButtonMouseEntered);
    helpTSDDButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripButtonsMouseExited);
    helpTSDDButton->MouseMove +=
        gcnew MouseEventHandler(this, &QCOM_GUIClass::QCOM_ToolStripHelpButtonMouseMoved);
    //------------------------------------------------------------------------
    // Log All Events drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    eventLogAllTSButton = gcnew ToolStripButton;
    eventLogAllTSButton->Text =
        (QCOM_EventLogBasicEnabled || QCOM_EventLogVerboseEnabled || QCOM_EventLogDetailedEnabled) ?
            GUI_ELOG_ALL_STOP_STRING : GUI_ELOG_ALL_START_STRING;
    eventLogAllTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripEventLogAllDropDownClicked);
    eventLogAllTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripEventLogAllDropDownMouseEntered);
    eventLogAllTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Log Basic Events drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    eventLogBasicTSButton = gcnew ToolStripButton;
    eventLogBasicTSButton->Text =
        QCOM_EventLogBasicEnabled ?
            GUI_ELOG_BASIC_STOP_STRING : GUI_ELOG_BASIC_START_STRING;
    eventLogBasicTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripEventLogBasicDropDownClicked);
    eventLogBasicTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripEventLogBasicDropDownMouseEntered);
    eventLogBasicTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Log Verbose Events drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    eventLogVerboseTSButton = gcnew ToolStripButton;
    eventLogVerboseTSButton->Text =
        QCOM_EventLogVerboseEnabled ?
            GUI_ELOG_VERBOSE_STOP_STRING : GUI_ELOG_VERBOSE_START_STRING;
    eventLogVerboseTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripEventLogVerboseDropDownClicked);
    eventLogVerboseTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripEventLogVerboseDropDownMouseEntered);
    eventLogVerboseTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Log Detailed Events drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    eventLogDetailedTSButton = gcnew ToolStripButton;
    eventLogDetailedTSButton->Text =
        QCOM_EventLogDetailedEnabled ?
            GUI_ELOG_DETAILED_STOP_STRING : GUI_ELOG_DETAILED_START_STRING;
    eventLogDetailedTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripEventLogDetailedDropDownClicked);
    eventLogDetailedTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripEventLogDetailedDropDownMouseEntered);
    eventLogDetailedTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Log Test Events drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    eventLogTestTSButton = gcnew ToolStripButton;
    eventLogTestTSButton->Text =
        QCOM_EventLogTestEnabled ?
            GUI_ELOG_TEST_STOP_STRING : GUI_ELOG_TEST_START_STRING;
    eventLogTestTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripEventLogTestDropDownClicked);
    eventLogTestTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripEventLogTestDropDownMouseEntered);
    eventLogTestTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Event Log drop-down and its properties
    //------------------------------------------------------------------------
    ToolStripDropDown ^eventLogDropDown = gcnew ToolStripDropDown;
    eventLogDropDown->BackColor = Color::Wheat;
    eventLogDropDown->ShowItemToolTips = GUI_NO;
    eventLogDropDown->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripEventLogDropDownMouseExited);
    //------------------------------------------------------------------------
    // Add these entries to the Event Log drop-down
    //------------------------------------------------------------------------
    array <ToolStripItem ^> ^eventLogDropDownItems =
    {
        eventLogAllTSButton,
        eventLogBasicTSButton,
        eventLogVerboseTSButton,
        eventLogDetailedTSButton,
        eventLogTestTSButton
    };
    eventLogDropDown->Items->AddRange(eventLogDropDownItems);
    //------------------------------------------------------------------------
    // Program Info drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^programInfoTSButton = gcnew ToolStripButton("Program Information");
    programInfoTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripProgInfoDropDownClicked);
    programInfoTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripProgInfoDropDownMouseEntered);
    programInfoTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Misc Controls drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    ToolStripButton ^miscControlsTSButton = gcnew ToolStripButton("Miscellaneous Controls");
    miscControlsTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripMiscControlsDropDownClicked);
    miscControlsTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripMiscControlsDropDownMouseEntered);
    miscControlsTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Event Log Recording toolstrip button as a sub-drop-down
    //------------------------------------------------------------------------
    eventLogRecordingTSDDButton = gcnew ToolStripDropDownButton("Event Log Recording");
    eventLogRecordingTSDDButton->DropDown = eventLogDropDown;
    eventLogRecordingTSDDButton->ShowDropDownArrow = GUI_NO;
    eventLogRecordingTSDDButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripEventLogDropDownMouseEntered);
    eventLogRecordingTSDDButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Display Event Log drop-down 'button' for the Advanced drop-down
    //------------------------------------------------------------------------
    displayEventLogTSButton = gcnew ToolStripButton("Display Last Event Log");
    displayEventLogTSButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDisplayEventLogDropDownClicked);
    displayEventLogTSButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDisplayEventLogDropDownMouseEntered);
    displayEventLogTSButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
//    displayEventLogTSButton->Enabled =
//        StringSet(QCOM_GeneralInfo->mostRecentEventLogPath) ?
//            GUI_YES : GUI_NO;
    //------------------------------------------------------------------------
    // Advanced toolstrip drop-down and its properties
    //------------------------------------------------------------------------
    ToolStripDropDown ^advancedDropDown = gcnew ToolStripDropDown;
    advancedDropDown->BackColor = Color::Wheat;
    advancedDropDown->ShowItemToolTips = GUI_NO;
    advancedDropDown->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripDropDownsMouseExited);
    //------------------------------------------------------------------------
    // Add these entries to the Advanced drop-down
    //------------------------------------------------------------------------
    array <ToolStripItem ^> ^advancedDropDownItems =
    {
        programInfoTSButton,
        miscControlsTSButton,
        eventLogRecordingTSDDButton,
        displayEventLogTSButton
    };
    advancedDropDown->Items->AddRange(advancedDropDownItems);
    //------------------------------------------------------------------------
    // Advanced toolstrip button as a drop-down
    //------------------------------------------------------------------------
    advancedTSDDButton = gcnew ToolStripDropDownButton("Advanced");
    advancedTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    advancedTSDDButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    advancedTSDDButton->DropDown = advancedDropDown;
    advancedTSDDButton->ShowDropDownArrow = GUI_NO;
    advancedTSDDButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripAdvancedButtonMouseEntered);
    advancedTSDDButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripButtonsMouseExited);
    advancedTSDDButton->MouseMove +=
        gcnew MouseEventHandler(this, &QCOM_GUIClass::QCOM_ToolStripAdvancedButtonMouseMoved);
    advancedTSDDButton->Visible =
        (QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE) ?
            GUI_YES : GUI_NO;
    //------------------------------------------------------------------------
    // Attach the components to the tool strip
    //------------------------------------------------------------------------
    array <ToolStripDropDownButton ^> ^toolStripButtons =
    {
        fileTSDDButton,
        functionsTSDDButton,
        helpTSDDButton,
        advancedTSDDButton
     };
    toolStrip->Items->AddRange(toolStripButtons);
    //------------------------------------------------------------------------
    // Finish the layout of the resulting tool strip
    //------------------------------------------------------------------------
    QCOM_UpdateDeleteLogFilesDropDown();
    Controls->Add(toolStrip);
    this->ResumeLayout();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_InstallToolStrip()
//----------------------------------------------------------------------------
// QCOM_LoadImagesAndSounds
//
// Initializes the background image pointers
//
// Called by:   QCOM_InitializeProgramComponents
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LoadImagesAndSounds(void)
{
    String          ^functionName = _T("QCOM_LoadImagesAndSounds");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (!QCOM_CommandLineOnly)
    {
        //--------------------------------------------------------------------
        // Install the program icon
        //--------------------------------------------------------------------
        if (File::Exists(GUI_PROGRAM_ICON))
            QCOM_SoftwareIcon = gcnew Drawing::Icon(GUI_PROGRAM_ICON);
        else
            RecordErrorEvent("    File {0} is missing", GUI_PROGRAM_ICON);
        //--------------------------------------------------------------------
        // Install the backgrounds
        //--------------------------------------------------------------------
        if (File::Exists(GUI_BG_GREEN_MARBLE))
            greenMarbleBackground = gcnew Bitmap(GUI_BG_GREEN_MARBLE, GUI_YES);
        else
            RecordErrorEvent("    File {0} is missing", GUI_BG_GREEN_MARBLE);
        if (File::Exists(GUI_BG_PINK_TEXTURE))
            pinkTextureBackground = gcnew Bitmap(GUI_BG_PINK_TEXTURE, GUI_YES);
        else
            RecordErrorEvent("    File {0} is missing", GUI_BG_PINK_TEXTURE);
        if (File::Exists(GUI_BG_SAND))
            sandBackground = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
        else
            RecordErrorEvent("    File {0} is missing", GUI_BG_SAND);
        if (File::Exists(GUI_BG_VIOLET_STUCCO))
            violetStuccoBackground = gcnew Bitmap(GUI_BG_VIOLET_STUCCO, GUI_YES);
        else
            RecordErrorEvent("    File {0} is missing", GUI_BG_VIOLET_STUCCO);
        if (File::Exists(GUI_BG_WHITE_MARBLE))
            whiteMarbleBackground = gcnew Bitmap(GUI_BG_WHITE_MARBLE, GUI_YES);
        else
            RecordErrorEvent("    File {0} is missing", GUI_BG_WHITE_MARBLE);
        if (File::Exists(GUI_BG_WHITE_SAND))
            whiteSandBackground = gcnew Bitmap(GUI_BG_WHITE_SAND, GUI_YES);
        else
            RecordErrorEvent("    File {0} is missing", GUI_BG_WHITE_SAND);
        if (File::Exists(GUI_BG_WOOD_PANEL))
            woodGrainBackground = gcnew Bitmap(GUI_BG_WOOD_PANEL, GUI_YES);
        else
            RecordErrorEvent("    File {0} is missing", GUI_BG_WOOD_PANEL);
        //--------------------------------------------------------------------
        // Install images
        //--------------------------------------------------------------------
        if (File::Exists(GUI_IMAGE_YELLOW_LED_OFF))
            yellowLEDOffImage = gcnew Bitmap(GUI_IMAGE_YELLOW_LED_OFF, GUI_YES);
        else
            RecordErrorEvent("    File {0} is missing", GUI_IMAGE_YELLOW_LED_OFF);
        if (File::Exists(GUI_IMAGE_YELLOW_LED_ON))
            yellowLEDOnImage = gcnew Bitmap(GUI_IMAGE_YELLOW_LED_ON, GUI_YES);
        else
            RecordErrorEvent("    File {0} is missing", GUI_IMAGE_YELLOW_LED_ON);
        if (File::Exists(GUI_IMAGE_YELLOW_LED_BLINK))
            yellowLEDBlinkImage = gcnew Bitmap(GUI_IMAGE_YELLOW_LED_BLINK, GUI_YES);
        else
            RecordErrorEvent("    File {0} is missing", GUI_IMAGE_YELLOW_LED_BLINK);
        //--------------------------------------------------------------------
        // Install the sounds
        //--------------------------------------------------------------------
        if (File::Exists(GUI_SOUND_DOWN))
        {
            downSound = gcnew Media::SoundPlayer(GUI_SOUND_DOWN);
            downSound->Load();
        }
        else
            RecordErrorEvent("    File {0} is missing", GUI_SOUND_DOWN);
        if (File::Exists(GUI_SOUND_ERROR))
        {
            errorSound = gcnew Media::SoundPlayer(GUI_SOUND_ERROR);
            errorSound->Load();
        }
        else
            RecordErrorEvent("    File {0} is missing", GUI_SOUND_ERROR);
        if (File::Exists(GUI_SOUND_OPEN))
        {
            openSound = gcnew Media::SoundPlayer(GUI_SOUND_OPEN);
            openSound->Load();
        }
        else
            RecordErrorEvent("    File {0} is missing", GUI_SOUND_OPEN);
        if (File::Exists(GUI_SOUND_TADA))
        {
            tadaSound = gcnew Media::SoundPlayer(GUI_SOUND_TADA);
            tadaSound->Load();
        }
        else
            RecordErrorEvent("    File {0} is missing", GUI_SOUND_TADA);
    }                                   // end of if (!QCOM_CommandLineOnly)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_LoadImagesAndSounds()
//----------------------------------------------------------------------------
// QCOM_StartPausedBlinker
//
// Starts the blinking of the Paused lights
//
// Called by:   QCOM_PauseElapsedTime
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StartPausedBlinker(void)
{
    bool            atLeastOneUnitSending = GUI_NO;
    String          ^functionName = _T("QCOM_StartPausedBlinker");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    if (yellowLEDBlinkImage && !blinkerCurrentlyAnimating)
    {
        if (homeSamplingStatusButton &&
            (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING))
        {
            homeSamplingStatusButton->BackgroundImage = yellowLEDBlinkImage;
            homeSamplingStatusButton->Update();
        }
        if (homeLoggingStatusButton &&
            (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING))
        {
            homeLoggingStatusButton->BackgroundImage = yellowLEDBlinkImage;
            homeLoggingStatusButton->Update();
        }
        if (homeTestingStatusButton &&
            (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING))
        {
            homeTestingStatusButton->BackgroundImage = yellowLEDBlinkImage;
            homeTestingStatusButton->Update();
        }
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE)
        {
            for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
            {
                if (QCOM_UnitNumberValid(unitNumber))
                {
                    UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                    if (unit->flags & QCOM_UNIT_SEND_XD_READINGS)
                    {
                        atLeastOneUnitSending = GUI_YES;
                    }
                }
            }
            if (homeSendingStatusButton && atLeastOneUnitSending)
            {
                homeSendingStatusButton->BackgroundImage = yellowLEDBlinkImage;
                homeSendingStatusButton->Update();
            }
        }
        ImageAnimator::Animate(
            yellowLEDBlinkImage,
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnimateBlinker));
        blinkerCurrentlyAnimating = GUI_YES;
    }
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_StartPausedBlinker()
//----------------------------------------------------------------------------
// QCOM_StopPausedBlinker
//
// Stops the blinking of the Paused lights
//
// Called by:   QCOM_ResumeElapsedTime
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StopPausedBlinker(void)
{
    bool            atLeastOneUnitSending = GUI_NO;
    String          ^functionName = _T("QCOM_StopPausedBlinker");
    //------------------------------------------------------------------------
    RecordDetailedEvent("{0} called", functionName);
    if (yellowLEDBlinkImage && blinkerCurrentlyAnimating)
    {
        ImageAnimator::StopAnimate(
            yellowLEDBlinkImage,
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnimateBlinker));
        blinkerCurrentlyAnimating = GUI_NO;
        //--------------------------------------------------------------------
        // Reset the blinker to the first (off) frame
        //
        // The commented-out code below demonstrates an alternate method of
        // resetting the multi-frame graphic image to a particular (0) frame,
        // which is useful when a separate still image is unavailable
        //
        // This requires the System::Drawing::Imaging namespace, by adding
        //
        // using       namespace System::Drawing::Imaging;
        //--------------------------------------------------------------------
//        FrameDimension ^FD = gcnew FrameDimension(yellowLEDBlinkImage->FrameDimensionsList[0]);
//        yellowLEDBlinkImage->SelectActiveFrame(FD, 0);
//        delete FD;
//        Invalidate();
        if (homeSamplingStatusButton)
        {
            if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
                homeSamplingStatusButton->BackgroundImage = yellowLEDOnImage;
            else
                homeSamplingStatusButton->BackgroundImage = yellowLEDOffImage;
            homeSamplingStatusButton->Update();
        }
        if (homeLoggingStatusButton)
        {
            if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING)
                homeLoggingStatusButton->BackgroundImage = yellowLEDOnImage;
            else
                homeLoggingStatusButton->BackgroundImage = yellowLEDOffImage;
            homeLoggingStatusButton->Update();
        }
        if (homeTestingStatusButton)
        {
            if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING)
                homeTestingStatusButton->BackgroundImage = yellowLEDOnImage;
            else
                homeTestingStatusButton->BackgroundImage = yellowLEDOffImage;
            homeTestingStatusButton->Update();
        }
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE)
        {
            for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
            {
                if (QCOM_UnitNumberValid(unitNumber))
                {
                    UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                    if (unit->flags & QCOM_UNIT_SEND_XD_READINGS)
                    {
                        atLeastOneUnitSending = GUI_YES;
                    }
                }
            }
            if (homeSendingStatusButton)
            {
                if (atLeastOneUnitSending)
                    homeSendingStatusButton->BackgroundImage = yellowLEDOnImage;
                else
                    homeSendingStatusButton->BackgroundImage = yellowLEDOffImage;
            }
        }
    }                                   // end of if (yellowLEDBlinkImage && blinkerCurrentlyAnimating)
    RecordDetailedEvent("{0} concluded", functionName);
}                                       // end of QCOM_StopPausedBlinker()
//----------------------------------------------------------------------------
#endif      // GUI_CPP
//============================================================================
// End of GUI.cpp
//============================================================================
