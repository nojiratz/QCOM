//============================================================================
// GUI.h
//
// Header for GUI.cpp, which defines GUI tools for Windows
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#pragma once
#ifndef     GUI_H       // provided for legacy compilers, but unnecessary for
#define     GUI_H       // recent compilers, due to the preceding pragma
//----------------------------------------------------------------------------
// Include appropriate headers
//----------------------------------------------------------------------------
#include    "QCOMDefs.h"
//----------------------------------------------------------------------------
// Specify libraries and namespaces
//----------------------------------------------------------------------------
#using      <mscorlib.dll>
#using      <System.dll>
#using      <System.Data.dll>
#using      <System.Drawing.dll>
#using      <System.Windows.Forms.dll>
#using      <WindowsBase.dll>
//----------------------------------------------------------------------------
// To get WindowsBase.dll, copy it from
// C:\Program Files\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.0
// to C:\WINDOWS\Microsoft.NET\Framework\v4.0.30319
//----------------------------------------------------------------------------
using       namespace System;
using       namespace System::ComponentModel;
using       namespace System::Data;
using       namespace System::Data::Odbc;
using       namespace System::Diagnostics;
using       namespace System::Drawing;
//using       namespace System::Drawing::Imaging;
using       namespace System::IO;
using       namespace System::IO::Packaging;
using       namespace System::Net;
using       namespace System::Net::Mail;
using       namespace System::Net::Mime;
using       namespace System::Net::NetworkInformation;
using       namespace System::Security::Permissions;
using       namespace System::Text;
using       namespace System::Threading;
using       namespace System::Windows::Forms;
using       namespace Microsoft::Win32;
//----------------------------------------------------------------------------
// Email information structure
//----------------------------------------------------------------------------
public value struct EmailInfo
{
    public:
        String                  ^toAddress;
        array <String ^>        ^toAddressArray;
        String                  ^fromAddress;
        array <String ^>        ^fromAddressArray;
        String                  ^ccAddress;
        array <String ^>        ^ccAddressArray;
        String                  ^replyAddress;
        array <String ^>        ^replyAddressArray;
        String                  ^messageString;
        array <String ^>        ^messageStringArray;
        String                  ^subjectString;
        array <String ^>        ^subjectStringArray;
        String                  ^attachment;
        array <String ^>        ^attachmentArray;
};
//----------------------------------------------------------------------------
// Logging Statistics structure
//----------------------------------------------------------------------------
public value struct LoggingStatsInfo
{
    public:
        DWORD                   startTime;
        DWORD                   cumulative;
        double                  lowDefPres;
        double                  highDefPres;
        double                  totalDefPres;
        double                  lowAltPres;
        double                  highAltPres;
        double                  totalAltPres;
        long                    lowPCount;
        long                    highPCount;
        long long               totalPCount;
        double                  lowPFreq;
        double                  highPFreq;
        double                  totalPFreq;
        double                  lowDefTemp;
        double                  highDefTemp;
        double                  totalDefTemp;
        double                  lowAltTemp;
        double                  highAltTemp;
        double                  totalAltTemp;
        long                    lowTCount;
        long                    highTCount;
        long long               totalTCount;
        double                  lowTFreq;
        double                  highTFreq;
        double                  totalTFreq;
        double                  lowVoltage;
        double                  highVoltage;
        double                  totalVoltage;
        double                  lowAmperage;
        double                  highAmperage;
        double                  totalAmperage;
        DWORD                   numberOfSamples;
        DWORD                   numberOfUnsavedSamples;
};
//----------------------------------------------------------------------------
// Testing Statistics structure
//----------------------------------------------------------------------------
public value struct TestingStatsInfo
{
    public:
        DWORD                   startTime;
        DWORD                   cumulative;
        DWORD                   startLoopTime;
        DWORD                   cumulativeLoop;
};
//----------------------------------------------------------------------------
// Unit information structure
//----------------------------------------------------------------------------
public value struct UnitInfo
{
    public:
        //--------------------------------------------------------------------
        // Applicable to the unit instance
        //--------------------------------------------------------------------
        DWORD                   unitNumber;                     // copy of its own unit context
        DWORD                   physicalUnitNumber;
        HANDLE                  unitHandle;
        String                  ^moduleSerialNumber;            // 256
        String                  ^unitDescriptionString;
        DWORD                   flags;
        DWORD                   stateFlags;
        DWORD                   unitSize;
        long                    moduleMemorySize;
        int                     numberOfModuleMemoryPages;
        double                  dataRate;
        //--------------------------------------------------------------------
        // Unit firmware
        //--------------------------------------------------------------------
        array <int>             ^firmwareID;
        String                  ^firmwareString;
        //--------------------------------------------------------------------
        // Attached transducer
        //--------------------------------------------------------------------
        DWORD                   transducerType;                 // Analog, Digital, etc., or None
        String                  ^transducerSerialNumber;
        String                  ^transducerPartNumber;
        array <int>             ^transducerChipID;
        long                    transducerMemorySize;
        int                     numberOfTransducerMemoryPages;
        long                    pressureCount;
        long                    temperatureCount;
        double                  pressureValuePSI;
        double                  temperatureValueCelsius;
        double                  transducerVoltage;
        double                  transducerAmperage;
        String                  ^coefficientFilePath;
        CoefficientFormatDef    *coefficientData;
        //--------------------------------------------------------------------
        // Data logging
        //--------------------------------------------------------------------
        StringBuilder           ^dataLog;
        DWORD                   dataLogSize;                    // maximum String size
        DWORD                   dataLogRemaining;
        StringBuilder           ^dataLogLine;
        StringBuilder           ^dataLogDisplay;
        String                  ^dataLogFilePath;
        String                  ^dataLogSnapshotFilePath;
        DWORD                   dataLogFlags;
        DWORD                   dataLogPoints;
        LoggingStatsInfo        ^loggingStats;
        //--------------------------------------------------------------------
        // Graphing
        //--------------------------------------------------------------------
        DWORD                   graphingFlags;
        int                     graphingLeft;
        int                     graphingPointsDisplayed;
        int                     graphingPressureTop;
        int                     graphingPressureVerticalPosition;
        int                     graphingPressureBottom;
        int                     graphingPressureGraphSize;
        double                  graphingPressureKReciprocalDeltaBoundary;
        double                  graphingPressureLowBoundaryPSI;
        double                  graphingPressureHighBoundaryPSI;
        int                     graphingTemperatureTop;
        int                     graphingTemperatureVerticalPosition;
        int                     graphingTemperatureBottom;
        int                     graphingTemperatureGraphSize;
        double                  graphingTemperatureKReciprocalDeltaBoundary;
        double                  graphingTemperatureLowBoundaryCelsius;
        double                  graphingTemperatureHighBoundaryCelsius;
        int                     graphingAmperageTop;
        int                     graphingAmperageVerticalPosition;
        int                     graphingAmperageBottom;
        int                     graphingAmperageGraphSize;
        double                  graphingAmperageKReciprocalDeltaBoundary;
        double                  graphingAmperageLowBoundarymA;
        double                  graphingAmperageHighBoundarymA;
        int                     graphingSamplesSinceDisplayedTime;
        int                     graphingPreviousTimeStampMinute;
        int                     graphingTimelineTop;
        bool                    graphingTimelineDrawDot;
        bool                    graphingGraphChanged;
        bool                    graphingGraphHasData;
        //--------------------------------------------------------------------
        // Testing
        //--------------------------------------------------------------------
        StringBuilder           ^testSummaryResultsLog;
        DWORD                   testSummaryResultsLogSize;
        DWORD                   testSummaryResultsLogRemaining;
        StringBuilder           ^testDetailedResultsLog;
        DWORD                   testDetailedResultsLogSize;
        DWORD                   testDetailedResultsLogRemaining;
        String                  ^testResultsLine;
        String                  ^testResultsLogHeader;
        String                  ^testResultsFilePath;
        String                  ^testDataFilePath;
        String                  ^testFirmwareFilePath;
        DWORD                   testsCompleted;
        DWORD                   testsToComplete;
        DWORD                   testFlags;
        DWORD                   testSuites;
        TestingStatsInfo        ^testingStats;
        //--------------------------------------------------------------------
        // Other
        //--------------------------------------------------------------------
        String                  ^convertReadingsFilePath;
        String                  ^pressureCountString;
        double                  pressureFrequency;
        String                  ^pressureFrequencyString;
        String                  ^temperatureCountString;
        double                  temperatureFrequency;
        String                  ^temperatureFrequencyString;
};
//----------------------------------------------------------------------------
// General information structure
//----------------------------------------------------------------------------
public value struct GeneralInfo
{
    public:
        DWORD                   numberOfUnits;
        DWORD                   maximumNumberOfUnits;
        DWORD                   numberOfTransducers;
        DWORD                   validUnitBitMap;
        DWORD                   readyUnitBitMap;
        DWORD                   flags;
        DWORD                   stateFlags;
        DWORD                   logFlags;
        DWORD                   testFlags;
        DWORD                   testSuites;
        DWORD                   persistentFlags;
        DWORD                   persistentLogFlags;
        DWORD                   persistentTestFlags;
        DWORD                   persistentUnitFlags;
        DWORD                   persistentUnitLogFlags;
        DWORD                   persistentUnitLogDataPoints;
        DWORD                   persistentUnitTestFlags;
        DWORD                   persistentUnitGraphingFlags;
        String                  ^commandLine;
        String                  ^configFilePath;
        String                  ^generalUsePath;
        String                  ^logDirectory;
        String                  ^errorLogPath;
        String                  ^eventLogPath;
        String                  ^mostRecentEventLogPath;
        String                  ^windowsVersion;
        String                  ^emailAddress;
        String                  ^textMessageToNumber;
        String                  ^textMessageCCNumber;
        String                  ^emailMessageToAddress;
        String                  ^emailMessageCCAddress;
        String                  ^searchString;
        String                  ^convertReadingsFilePath;
};
//----------------------------------------------------------------------------
// ModuleTransducerPair information structure
//----------------------------------------------------------------------------
public value struct ModuleTransducerPair
{
    public:
        String                  ^currentUnitPair;
        String                  ^currentModuleSerialNumber;
        String                  ^currentTransducerSerialNumber;
        String                  ^newModuleSerialNumber;
        String                  ^newTransducerSerialNumber;
};
//----------------------------------------------------------------------------
// QCOM_GUIClass
//
// The main window class, an extension of the Form class that allows the
// software to create a window as its first GUI object
//
// Note:    [SecurityPermissionAttribute(...)] is needed to support the
//          unhandled exception handler QCOM_DefaultExceptionHandler
//----------------------------------------------------------------------------
    public ref class        // __gc class has been replaced by ref class
QCOM_GUIClass :
    public Form
{
    public:
        [SecurityPermissionAttribute(SecurityAction::Demand, ControlAppDomain = true)]
        QCOM_GUIClass();
    private:
        //--------------------------------------------------------------------
        // Single-element variable members
        //--------------------------------------------------------------------
        bool                    blinkerCurrentlyAnimating;
        Bitmap                  ^greenMarbleBackground;
        Bitmap                  ^pinkTextureBackground;
        Bitmap                  ^sandBackground;
        Bitmap                  ^violetStuccoBackground;
        Bitmap                  ^whiteMarbleBackground;
        Bitmap                  ^whiteSandBackground;
        Bitmap                  ^woodGrainBackground;
        Bitmap                  ^yellowLEDBlinkImage;
        Bitmap                  ^yellowLEDOffImage;
        Bitmap                  ^yellowLEDOnImage;
        Button                  ^expertExperimentalButton;
        Button                  ^expertExperimentsButton;
        Button                  ^expertRealTimeWeightDemoButton;
        Button                  ^expertResetMessagesButton;
        Button                  ^homeLoggingStatusButton;
        Button                  ^homeSamplingStatusButton;
        Button                  ^homeSendingStatusButton;
        Button                  ^homeTestingStatusButton;
        Button                  ^logAllClearButton;
        Button                  ^logAllCloseButton;
        Button                  ^logAllPauseResumeButton;
        Button                  ^logAllSnapshotDataButton;
        Button                  ^logAllStartStopButton;
        Button                  ^readoutClearAllLogsButton;
        Button                  ^readoutPauseResumeButton;
        Button                  ^readoutStartStopAllLoggingButton;
        Button                  ^readoutStartStopAllSamplingButton;
        Button                  ^realTimeWeightStartStopButton;
        Button                  ^testingPauseResumeButton;
        Button                  ^testingResetAllTestsButton;
        Button                  ^testingClearAllResultsButton;
        Button                  ^testingSaveAllResultsButton;
        Button                  ^testingStartStopAllButton;
        Button                  ^utilConvertReadingsLoadFileButton;
        Button                  ^utilDownloadCoefficientFilesButton;
        Button                  ^utilLogAllDisplayButton;
        Button                  ^utilResetAllUnitsButton;
        Button                  ^utilVerifyHexFileButton;
        CheckBox                ^expertDetailedMessagesCheck;
        CheckBox                ^expertBasicMessagesCheck;
        CheckBox                ^expertDLLMessagesCheck;
        CheckBox                ^expertErrorMessagesCheck;
        CheckBox                ^expertExperimentsCheck;
        CheckBox                ^expertExpMessagesCheck;
        CheckBox                ^expertHaltOperationsOnErrorsCheck;
        CheckBox                ^expertProgramIntervalCheck;
        CheckBox                ^expertSendEmailErrorMessageCheck;
        CheckBox                ^expertSendTextErrorMessageCheck;
        CheckBox                ^expertStackTraceCheck;
        CheckBox                ^expertVerboseMessagesCheck;
        CheckBox                ^logAllBothFileFormatsCheck;
        CheckBox                ^logAllDisplaySummariesCheck;
        CheckBox                ^logAllDisplayWrapCheck;
        CheckBox                ^logAllInsertCommentTimeStampCheck;
        CheckBox                ^logAllPrependEntryNumbersCheck;
        CheckBox                ^logAllRunLoggingTimedCheck;
        CheckBox                ^logAllSaveLoggedDataImmediatelyCheck;
        CheckBox                ^miscDeleteConfigCheck;
        CheckBox                ^miscDontSaveConfigCheck;
        CheckBox                ^miscEnableSoundsCheck;
        CheckBox                ^miscPFGeneralLogBothFileFormatsCheck;
        CheckBox                ^miscPFGeneralLogDataSaveImmediatelyCheck;
        CheckBox                ^miscPFGeneralLogDisplayAllSummariesCheck;
        CheckBox                ^miscPFGeneralLogDisplayAllWrappedCheck;
        CheckBox                ^miscPFGeneralLogPrependEntryNumbersCheck;
        CheckBox                ^miscPFGeneralSoundsEnabledCheck;
        CheckBox                ^miscPFGeneralTestDisplayXDTestsCheck;
        CheckBox                ^miscPFUnitEmailXDReadingsCheck;
        CheckBox                ^miscPFUnitHexCountsCheck;
        CheckBox                ^miscPFUnitLogDataSaveImmediatelyCheck;
        CheckBox                ^miscPFUnitSendXDReadingsCheck;
        CheckBox                ^miscPFUnitTestResultsDisplayCheck;
        CheckBox                ^miscPFUnitTextXDReadingsCheck;
        CheckBox                ^readoutDisplayAllFrequenciesCheck;
        CheckBox                ^readoutDisplayAllVIValuesCheck;
        CheckBox                ^readoutHexCheck;
        CheckBox                ^readoutIncludeAllInSamplingCheck;
        CheckBox                ^readoutRunSamplingTimedCheck;
        CheckBox                ^testingAppendCheck;
        CheckBox                ^testingAutoSaveCheck;
        CheckBox                ^testingDetailAllCheck;
        CheckBox                ^testingDisplayTestResultsCheck;
        CheckBox                ^testingDisplayTransducerTestsCheck;
        CheckBox                ^testingInsertCommentTimeStampCheck;
        CheckBox                ^testingLoopCheck;
        CheckBox                ^testingLoopForeverCheck;
        CheckBox                ^testingStopOnErrorsCheck;
        CheckBox                ^testingWrapCheck;
        ComboBox                ^emailFromCombo;
        ComboBox                ^emailToCombo;
        ComboBox                ^readoutAlternatePressureUnitsCombo;
        ComboBox                ^readoutAlternateTemperatureUnitsCombo;
        Drawing::Icon           ^QCOM_SoftwareIcon;
        Form                    ^aboutHelpWindow;
        Form                    ^convertReadingsWindow;
        Form                    ^displayHexCFParametersWindow;
        Form                    ^displayNativeCFParametersWindow;
        Form                    ^emailSupportLogWindow;
        Form                    ^eventLogWindow;
        Form                    ^logAllDataWindow;
        Form                    ^miscControlWindow;
        Form                    ^miscPFControlWindow;
        Form                    ^pleaseWaitWindow;
        Form                    ^programInfoWindow;
        Form                    ^realTimeWeightWindow;
        GroupBox                ^logAllHeaderGroupBox;
        GroupBox                ^logAllInsertCommentGroupBox;
        GroupBox                ^testingGeneralGroupBox;
        GroupBox                ^testingInsertCommentGroupBox;
        Label                   ^emailStatusLabel;
        Label                   ^expertEmailMessageCCAddressLabel;
        Label                   ^expertEmailMessageToAddressLabel;
        Label                   ^expertTextMessageCCNumberLabel;
        Label                   ^expertTextMessageToNumberLabel;
        Label                   ^homeLoggingStatusLabel;
        Label                   ^homeSamplingStatusLabel;
        Label                   ^homeSendingStatusLabel;
        Label                   ^homeTestingStatusLabel;
        Label                   ^logAllIntervalRangeLabel;
        Label                   ^logAllIntervalUnitsLabel;
        Label                   ^logAllLimitLoggingTimeLabel;
        Label                   ^logAllLimitLoggingTimeMinutesLabel;
        Label                   ^logAllLimitLoggingTimeMinutesRemainingLabel;
        Label                   ^logAllContinuousLoggingTimeLabel;
        Label                   ^openingBannerLabel;
        Label                   ^pleaseWaitLabel;
        Label                   ^readoutContinuousSamplingTimeLabel;
        Label                   ^readoutIntervalUnitsLabel;
        Label                   ^readoutLimitSamplingTimeLabel;
        Label                   ^readoutLimitSamplingTimeMinutesLabel;
        Label                   ^readoutLimitSamplingTimeMinutesRemainingLabel;
        Label                   ^readoutIntervalRangeLabel;
        Label                   ^readoutPrecisionLabel;
        Label                   ^realTimeWeightPoundsLabel;
        Label                   ^realTimeWeightPSILabel;
        Label                   ^testingLoopLimitsLabel;
        Label                   ^utilConvertReadingsLoadFileLabel;
        Media::SoundPlayer      ^downSound;
        Media::SoundPlayer      ^errorSound;
        Media::SoundPlayer      ^openSound;
        Media::SoundPlayer      ^tadaSound;
        NumericUpDown           ^logAllPrecisionNumeric;
        NumericUpDown           ^readoutPrecisionNumeric;
        RadioButton             ^logAllHoursRadio;
        RadioButton             ^logAllMillisecondsRadio;
        RadioButton             ^logAllMinutesRadio;
        RadioButton             ^logAllSecondsRadio;
        RadioButton             ^readoutAlternatePressureTemperatureRadio;
        RadioButton             ^readoutCountsRadio;
        RadioButton             ^readoutDefaultPressureTemperatureRadio;
        RadioButton             ^readoutHoursRadio;
        RadioButton             ^readoutMillisecondsRadio;
        RadioButton             ^readoutMinutesRadio;
        RadioButton             ^readoutSecondsRadio;
        StatusStrip             ^homeStatusStrip;
        String                  ^QCOM_PrecisionFormatString;
        TabControl              ^expertTabControl;
        TabControl              ^homeTabControl;
        TabControl              ^loggingTabControl;
        TabControl              ^miscTabControl;
        TabControl              ^pInfoTabControl;
        TabControl              ^readoutTabControl;
        TabControl              ^testingTabControl;
        TabControl              ^utilitiesTabControl;
        TabPage                 ^expertHomeTabPage;
        TextBox                 ^expertEmailMessageCCAddressBox;
        TextBox                 ^expertEmailMessageToAddressBox;
        TextBox                 ^emailMessageBox;
        TextBox                 ^emailSubjectBox;
        TextBox                 ^expertExperimentNumberBox;
        TextBox                 ^expertProgramIntervalBox;
        TextBox                 ^expertTextMessageCCNumberBox;
        TextBox                 ^expertTextMessageToNumberBox;
        TextBox                 ^logAllInsertCommentBox;
        TextBox                 ^logAllIntervalBox;
        TextBox                 ^logAllLimitLoggingTimeBox;
        TextBox                 ^miscGetNumberOfModulesBox;
        TextBox                 ^miscGetQCOMDLLVersionBox;
        TextBox                 ^miscReadTimeoutBox;
        TextBox                 ^miscWriteTimeoutBox;
        TextBox                 ^readoutLimitSamplingTimeBox;
        TextBox                 ^readoutSamplingIntervalBox;
        TextBox                 ^realTimeWeightMultiplierBox;
        TextBox                 ^testingInsertCommentBox;
        TextBox                 ^testingLoopCountBox;
        TextBox                 ^utilConvertReadingsPressureActualBox;
        TextBox                 ^utilConvertReadingsPressureCountBox;
        TextBox                 ^utilConvertReadingsPressureFrequencyBox;
        TextBox                 ^utilConvertReadingsTemperatureActualBox;
        TextBox                 ^utilConvertReadingsTemperatureCountBox;
        TextBox                 ^utilConvertReadingsTemperatureFrequencyBox;
        TextBox                 ^utilConvertReadingsTransducerSerialNumberBox;
        Windows::Forms::Timer   ^oneMinuteTimer;
        Windows::Forms::Timer   ^oneSecondTimer;
        Windows::Forms::Timer   ^programTimer;
        Windows::Forms::Timer   ^samplingTimer;
        ToolStripButton         ^configFileTSButton;
        ToolStripButton         ^deleteAllDataCSVFilesTSButton;
        ToolStripButton         ^deleteAllDataLogFilesTSButton;
        ToolStripButton         ^deleteAllErrorLogFilesTSButton;
        ToolStripButton         ^deleteAllEventLogFilesTSButton;
        ToolStripButton         ^deleteAllLogFilesTSButton;
        ToolStripButton         ^deleteAllTestResultsFilesTSButton;
        ToolStripButton         ^displayEventLogTSButton;
        ToolStripButton         ^eventLogAllTSButton;
        ToolStripButton         ^eventLogBasicTSButton;
        ToolStripButton         ^eventLogDetailedTSButton;
        ToolStripButton         ^eventLogVerboseTSButton;
        ToolStripButton         ^eventLogTestTSButton;
        ToolStripButton         ^expertFunctionTSButton;
        ToolStripButton         ^refreshFunctionTSButton;
        ToolStripButton         ^rescanFunctionTSButton;
        ToolStripButton         ^resetAllFunctionTSButton;
        ToolStripButton         ^resetAllModulesFunctionTSButton;
        ToolStripButton         ^resetAllTransducersFunctionTSButton;
        ToolStripButton         ^resetSoftwareFunctionTSButton;
        ToolStripButton         ^saveLogFilesOnExitTSButton;
        ToolStripDropDown       ^helpTSDropDown;
        ToolStripDropDownButton ^advancedTSDDButton;
        ToolStripDropDownButton ^deleteTSDDButton;
        ToolStripDropDownButton ^eventLogRecordingTSDDButton;
        ToolStripDropDownButton ^fileTSDDButton;
        ToolStripDropDownButton ^functionsTSDDButton;
        ToolStripDropDownButton ^helpTSDDButton;
        ToolStripDropDownButton ^resetTSDDButton;
        ToolStripProgressBar    ^homeTSProgressBar;
        ToolStripStatusLabel    ^homeStatusLineTSSLabel;
        ToolStripStatusLabel    ^nowStatusLineTSSLabel;
        UnitInfo                ^utilConvertReadingsUnit;
        GeneralInfo             ^QCOM_GeneralInfo;
        //--------------------------------------------------------------------
        // Array members
        //--------------------------------------------------------------------
        array <Button ^>        ^expertManageMultipleCFButtonArray;
        array <Button ^>        ^expertRealTimeWeightCalibrateButtonArray;
        array <Button ^>        ^expertRealTimeWeightStartStopButtonArray;
        array <Button ^>        ^expertTransducerPowerButtonArray;
        array <Button ^>        ^graphingClearGraphButtonArray;
        array <Button ^>        ^graphingClearLogButtonArray;
        array <Button ^>        ^graphingPauseResumeButtonArray;
        array <Button ^>        ^graphingSaveGraphButtonArray;
        array <Button ^>        ^graphingSingleStepButtonArray;
        array <Button ^>        ^graphingStartStopLoggingButtonArray;
        array <Button ^>        ^graphingStartStopSamplingButtonArray;
        array <Button ^>        ^logAllClearButtonArray;
        array <Button ^>        ^logAllSelectFileButtonArray;
        array <Button ^>        ^logAllSnapshotDataButtonArray;
        array <Button ^>        ^logAllStartStopButtonArray;
        array <Button ^>        ^logUnitAllInsertCommentButtonArray;
        array <Button ^>        ^logUnitClearButtonArray;
        array <Button ^>        ^logUnitInsertCommentButtonArray;
        array <Button ^>        ^logUnitPauseResumeButtonArray;
        array <Button ^>        ^logUnitSelectFileButtonArray;
        array <Button ^>        ^logUnitSnapshotDataButtonArray;
        array <Button ^>        ^logUnitStartStopButtonArray;
        array <Button ^>        ^miscBootLoaderButtonArray;
        array <Button ^>        ^miscDisplayDLLFunctionsButtonArray;
        array <Button ^>        ^miscDisplayRawModuleCoeffButtonArray;
        array <Button ^>        ^miscDisplayRawXDCoeffButtonArray;
        array <Button ^>        ^miscI2CSendButtonArray;
        array <Button ^>        ^miscReadXDMemoryButtonArray;
        array <Button ^>        ^miscToggleTransducerTypeButtonArray;
        array <Button ^>        ^miscWriteXDMemoryButtonArray;
        array <array <Button ^> ^>
                                ^multipleModuleCopyButtonArray;
        array <Button ^>        ^readoutClearLogButtonArray;
        array <Button ^>        ^readoutDisplayDataGraphButtonArray;
        array <Button ^>        ^readoutStartStopLoggingButtonArray;
        array <Button ^>        ^readoutStartStopSamplingButtonArray;
        array <Button ^>        ^testingClearResultsButtonArray;
        array <Button ^>        ^testingSaveResultsButtonArray;
        array <Button ^>        ^testingSelectResultsFileButtonArray;
        array <Button ^>        ^testingStartStopButtonArray;
        array <Button ^>        ^utilDisplayTCCheckButtonArray;
        array <Button ^>        ^utilExportCoefficientDataFileButtonArray;
        array <Button ^>        ^utilImportCoefficientDataFileButtonArray;
        array <Button ^>        ^utilLogUnitDisplayButtonArray;
        array <Button ^>        ^utilResetModuleButtonArray;
        array <Button ^>        ^utilResetTransducerButtonArray;
        array <Button ^>        ^utilUpdateFirmwareButtonArray;
        array <CheckBox ^>      ^expertSendTransducerReadingsCheckArray;
        array <CheckBox ^>      ^graphingBothFileFormatsCheckArray;
        array <CheckBox ^>      ^graphingDisplayAmperageDrawCheckArray;
        array <CheckBox ^>      ^graphingMilitaryTimeFormatCheckArray;
        array <CheckBox ^>      ^graphingSuperimposePressureTemperatureCheckArray;
        array <CheckBox ^>      ^graphingUseThickLinesCheckArray;
        array <CheckBox ^>      ^logAllDisplayCaptionCheckArray;
        array <CheckBox ^>      ^logAllEmbedCaptionCheckArray;
        array <CheckBox ^>      ^logUnitAllCheckArray;
        array <CheckBox ^>      ^logUnitAltPressureCheckArray;
        array <CheckBox ^>      ^logUnitAltTemperatureCheckArray;
        array <CheckBox ^>      ^logUnitBothFileFormatsCheckArray;
        array <CheckBox ^>      ^logUnitCountsInHexCheckArray;
        array <CheckBox ^>      ^logUnitDateStampCheckArray;
        array <CheckBox ^>      ^logUnitDefaultsCheckArray;
        array <CheckBox ^>      ^logUnitDefPressureCheckArray;
        array <CheckBox ^>      ^logUnitDefTemperatureCheckArray;
        array <CheckBox ^>      ^logUnitDisplayCaptionAllCheckArray;
        array <CheckBox ^>      ^logUnitDisplaySummaryCheckArray;
        array <CheckBox ^>      ^logUnitDisplayWrapCheckArray;
        array <CheckBox ^>      ^logUnitEmbedCaptionCheckArray;
        array <CheckBox ^>      ^logUnitInsertCommentTimeStampCheckArray;
        array <CheckBox ^>      ^logUnitMillisecondsCheckArray;
        array <CheckBox ^>      ^logUnitPrependEntryNumbersCheckArray;
        array <CheckBox ^>      ^logUnitPressureCountCheckArray;
        array <CheckBox ^>      ^logUnitPressureFrequencyCheckArray;
        array <CheckBox ^>      ^logUnitSaveLoggedDataImmediatelyCheckArray;
        array <CheckBox ^>      ^logUnitTemperatureCountCheckArray;
        array <CheckBox ^>      ^logUnitTemperatureFrequencyCheckArray;
        array <CheckBox ^>      ^logUnitTimeStampLogCheckArray;
        array <CheckBox ^>      ^logUnitTransducerAmperageCheckArray;
        array <CheckBox ^>      ^logUnitTransducerVoltageCheckArray;
        array <CheckBox ^>      ^readoutDisplayFrequenciesCheckArray;
        array <CheckBox ^>      ^readoutDisplayVIValuesCheckArray;
        array <CheckBox ^>      ^readoutIncludeInSamplingCheckArray;
        array <CheckBox ^>      ^testingAllModuleCheckArray;
        array <CheckBox ^>      ^testingAllTransducerCheckArray;
        array <CheckBox ^>      ^testingDetailedCheckArray;
        array <CheckBox ^>      ^testingFirmwareCheckArray;
        array <CheckBox ^>      ^testingI2CCheckArray;
        array <CheckBox ^>      ^testingQMEMCheckArray;
        array <CheckBox ^>      ^testingReadingsCheckArray;
        array <CheckBox ^>      ^testingTimeStampCheckArray;
    array <CheckBox ^>      ^testingX2CheckArray;
    array <CheckBox ^>      ^testingX3CheckArray;
    array <CheckBox ^>      ^testingX4CheckArray;
        array <CheckBox ^>      ^testingXDCommCheckArray;
        array <CheckBox ^>      ^testingXDIntegrityCheckArray;
        array <CheckBox ^>      ^testingXDMemoryCheckArray;
        array <ComboBox ^>      ^miscI2CCommandComboArray;
        array <Form ^>          ^displayCFDataWindowArray;
        array <Form ^>          ^displayRawCFDataWindowArray;
        array <Form ^>          ^graphingWindowArray;
        array <Form ^>          ^logUnitWindowArray;
        array <Form ^>          ^miscDisplayDLLFunctionsWindowArray;
        array <Form ^>          ^multipleCoefficientDataWindowArray;
        array <GroupBox ^>      ^expertGroupBoxArray;
        array <GroupBox ^>      ^logAllAppendOverwriteGroupBoxArray;
        array <GroupBox ^>      ^logAllGroupBoxArray;
        array <GroupBox ^>      ^logUnitAppendOverwriteGroupBoxArray;
        array <GroupBox ^>      ^miscGetCadenceTimerGroupBoxArray;
        array <GroupBox ^>      ^miscGetControlRegisterGroupBoxArray;
        array <GroupBox ^>      ^miscGetErrorCodeGroupBoxArray;
        array <GroupBox ^>      ^miscGetFirmwareIDGroupBoxArray;
        array <GroupBox ^>      ^miscGetMemoryTypeGroupBoxArray;
        array <GroupBox ^>      ^miscGetSetI2CDataRateGroupBoxArray;
        array <GroupBox ^>      ^miscGetModuleSerialNumberGroupBoxArray;
        array <GroupBox ^>      ^miscGetTransducerChipIDGroupBoxArray;
        array <GroupBox ^>      ^miscGetTransducerTypeGroupBoxArray;
        array <GroupBox ^>      ^miscGetStatusRegisterGroupBoxArray;
        array <GroupBox ^>      ^miscI2CSendCommandGroupBoxArray;
        array <GroupBox ^>      ^miscUnitGroupBoxArray;
        array <GroupBox ^>      ^readoutGroupBoxArray;
        array <GroupBox ^>      ^testingGroupBoxArray;
        array <GroupBox ^>      ^testUnitGroupBoxArray;
        array <GroupBox ^>      ^utilitiesGroupBoxArray;
//        array <GroupBox ^>      ^unitTestsGroupBoxArray;
        array <Label ^>         ^expertSendEveryLabelArray;
        array <Label ^>         ^expertSendEveryMinutesLabelArray;
        array <Label ^>         ^expertSendEveryMinutesRemainingLabelArray;
        array <Label ^>         ^graphingAmperageHighBoundaryLabelArray;
        array <Label ^>         ^graphingAmperageHighBoundaryUnitsLabelArray;
        array <Label ^>         ^graphingAmperageLabelArray;
        array <Label ^>         ^graphingAmperageLowBoundaryLabelArray;
        array <Label ^>         ^graphingAmperageLowBoundaryUnitsLabelArray;
        array <Label ^>         ^graphingAmperageUnitsLabelArray;
        array <Label ^>         ^graphingAmperageValueLabelArray;
        array <Label ^>         ^graphingPressureHighBoundaryUnitsLabelArray;
        array <Label ^>         ^graphingPressureLowBoundaryUnitsLabelArray;
        array <Label ^>         ^graphingPressureUnitsLabelArray;
        array <Label ^>         ^graphingPressureValueLabelArray;
        array <Label ^>         ^graphingTemperatureHighBoundaryUnitsLabelArray;
        array <Label ^>         ^graphingTemperatureLowBoundaryUnitsLabelArray;
        array <Label ^>         ^graphingTemperatureUnitsLabelArray;
        array <Label ^>         ^graphingTemperatureValueLabelArray;
        array <Label ^>         ^graphingTimeBetweenSamplesLabelArray;
        array <Label ^>         ^graphingTransducerPartNumberLabelArray;
        array <Label ^>         ^graphingTransducerSerialNumberLabelArray;
        array <Label ^>         ^logAllCaptionLabelArray;
        array <Label ^>         ^logAllFileLabelArray;
        array <Label ^>         ^logAllPercentFullLabelArray;
        array <Label ^>         ^logUnitCaptionLabelArray;
        array <Label ^>         ^logUnitFileLabelArray;
        array <Label ^>         ^logUnitTimeLabelArray;
        array <Label ^>         ^logUnitPercentFullLabelArray;
        array <Label ^>         ^miscI2CReplyInterpLabelArray;
        array <array <Label ^> ^>
                                ^multipleSerialNumberModuleLabelArray;
        array <array <Label ^> ^>
                                ^multipleSerialNumberTransducerLabelArray;
        array <Label ^>         ^readoutAmperageTitleLabelArray;
        array <Label ^>         ^readoutAmperageUnitsLabelArray;
        array <Label ^>         ^readoutTemperatureUnitsLabelArray;
        array <Label ^>         ^readoutFirmwareInfoLabelArray;
        array <Label ^>         ^readoutPressureFrequencyTitleLabelArray;
        array <Label ^>         ^readoutPressureFrequencyUnitsLabelArray;
        array <Label ^>         ^readoutPressureTitleLabelArray;
        array <Label ^>         ^readoutPressureUnitsLabelArray;
        array <Label ^>         ^readoutTemperatureFrequencyTitleLabelArray;
        array <Label ^>         ^readoutTemperatureFrequencyUnitsLabelArray;
        array <Label ^>         ^readoutTemperatureTitleLabelArray;
        array <Label ^>         ^readoutVoltageTitleLabelArray;
        array <Label ^>         ^readoutVoltageUnitsLabelArray;
        array <Label ^>         ^testingPassCountLabelArray;
        array <Label ^>         ^testingPercentCompleteLabelArray;
        array <Label ^>         ^testingResultsFileLabelArray;
        array <Label ^>         ^testingStateLabelArray;
        array <Label ^>         ^testingRunningTimeLabelArray;
        array <PictureBox ^>    ^graphingPictureBoxArray;
        array <ProgressBar ^>   ^logAllPercentFullProgressArray;
        array <ProgressBar ^>   ^logUnitPercentFullProgressArray;
        array <ProgressBar ^>   ^testingPercentCompleteProgressArray;
        array <RadioButton ^>   ^graphingAlternatePTUnitsRadioArray;
        array <RadioButton ^>   ^graphingDefaultPTUnitsRadioArray;
        array <RadioButton ^>   ^logAllAppendRadioArray;
        array <RadioButton ^>   ^logAllAutoSaveAllRadioArray;
        array <RadioButton ^>   ^logAllOverwriteRadioArray;
        array <RadioButton ^>   ^logAllPromptRadioArray;
        array <RadioButton ^>   ^logUnitAppendRadioArray;
        array <RadioButton ^>   ^logUnitAutoSaveRadioArray;
        array <RadioButton ^>   ^logUnitOverwriteRadioArray;
        array <RadioButton ^>   ^logUnitPromptRadioArray;
        array <RichTextBox ^>   ^testingDetailedResultsBoxArray;
        array <RichTextBox ^>   ^testingSummaryResultsBoxArray;
        array <SpinLock ^>      ^QCOM_LogSpinLockArray;
        array <SpinLock ^>      ^QCOM_TestSpinLockArray;
        array <SpinLock ^>      ^QCOM_UnitAccessSpinLockArray;
        array <String ^>        ^QCOM_AmperageUnitsStringArray;
        array <String ^>        ^QCOM_IntervalUnitsStringArray;
        array <String ^>        ^QCOM_MonthStringArray;
        array <String ^>        ^QCOM_PressureUnitsStringArray;
        array <String ^>        ^QCOM_TemperatureUnitsStringArray;
        array <TabPage ^>       ^expertUnitTabPageArray;
        array <TabPage ^>       ^miscTabPageArray;
        array <TabPage ^>       ^pInfoTabPageArray;
        array <TabPage ^>       ^logAllUnitTabPageArray;
        array <TabPage ^>       ^readoutUnitTabPageArray;
        array <TabPage ^>       ^testingUnitTabPageArray;
        array <TabPage ^>       ^utilitiesUnitTabPageArray;
        array <TextBox ^>       ^expertSendEveryBoxArray;
        array <TextBox ^>       ^graphingAmperageHighBoundaryBoxArray;
        array <TextBox ^>       ^graphingAmperageLowBoundaryBoxArray;
        array <TextBox ^>       ^graphingPressureHighBoundaryBoxArray;
        array <TextBox ^>       ^graphingPressureLowBoundaryBoxArray;
        array <TextBox ^>       ^graphingTemperatureHighBoundaryBoxArray;
        array <TextBox ^>       ^graphingTemperatureLowBoundaryBoxArray;
        array <TextBox ^>       ^logAllBoxArray;
        array <TextBox ^>       ^logUnitBoxArray;
        array <TextBox ^>       ^logUnitInsertCommentBoxArray;
        array <TextBox ^>       ^miscGetDataRateBoxArray;
        array <TextBox ^>       ^miscGetCadenceTimerBoxArray;
        array <TextBox ^>       ^miscGetControlRegisterBoxArray;
        array <TextBox ^>       ^miscGetErrorCodeBoxArray;
        array <TextBox ^>       ^miscGetFirmwareIDBoxArray;
        array <TextBox ^>       ^miscGetMemoryTypeBoxArray;
        array <TextBox ^>       ^miscGetStatusRegisterBoxArray;
        array <TextBox ^>       ^miscGetTransducerChipIDBoxArray;
        array <TextBox ^>       ^miscGetTransducerTypeBoxArray;
        array <TextBox ^>       ^miscGetModuleSerialNumberBoxArray;
        array <TextBox ^>       ^miscI2CResponseBoxArray;
        array <TextBox ^>       ^readoutAmperageBoxArray;
        array <TextBox ^>       ^readoutPressureBoxArray;
        array <TextBox ^>       ^readoutPressureFrequencyBoxArray;
        array <TextBox ^>       ^readoutTemperatureBoxArray;
        array <TextBox ^>       ^readoutTemperatureFrequencyBoxArray;
        array <TextBox ^>       ^readoutVoltageBoxArray;
        array <Windows::Forms::Timer ^>
                                ^sendEveryTimerArray;
        array <UnitInfo ^>      ^QCOM_UnitInfoArray;
        array <ModuleTransducerPair ^>
                                ^QCOM_ModuleTransducerPairArray;
        //--------------------------------------------------------------------
        // Methods
        //--------------------------------------------------------------------
        void    QCOM_Start(void);
        void    QCOM_AboutHelp(void);
        void    QCOM_AffirmStartupConditions(void);
        void    QCOM_AnimateBlinker(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_AnyObjectMouseExited(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_AppendTestResults(
                    UnitInfo        ^unit,
                    DWORD           actionFlags,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    QCOM_AppendTestResultsError(
                    UnitInfo        ^unit,
                    String          ^prefix,
                    DWORD           errorCode,
                    DWORD           actionFlags);
        void    QCOM_ApplyCoefficientDataInfoToProgram(
                    UnitInfo        ^unit);
        void    QCOM_ApplyGeneralFlagToUnitFlags(
                    DWORD           generalFlag,
                    DWORD           unitFlag);
        void    QCOM_ApplyGeneralLogFlagToUnitFlags(
                    DWORD           generalLogFlag,
                    DWORD           unitLogFlag);
        void    QCOM_ApplyGeneralTestFlagToUnitFlags(
                    DWORD           generalTestFlag,
                    DWORD           unitTestFlag);
        void    QCOM_BuildDoubleDisplayCaptionString(
                    String          ^captionToAdd,
                    double          value,
                    int             precision,
                    int             prependSpaces,
                    int             appendSpaces,
                    StringBuilder   ^captionBuilder);
        void    QCOM_BuildIntegerDisplayCaptionString(
                    String          ^captionToAdd,
                    int             value,
                    bool            displayInHex,
                    int             prependSpaces,
                    int             appendSpaces,
                    StringBuilder   ^captionBuilder);
        void    QCOM_CaptureCommandLine(void);
        void    QCOM_CheckAllTransducerCoefficientData(void);
        void    QCOM_CheckForCurrentFirmwareVersion(
                    UnitInfo        ^unit);
        void    QCOM_CheckForCurrentSoftwareVersion(
                    bool            announceResults);
        void    QCOM_CheckForTransducerCoefficientData(
                    UnitInfo        ^unit);
        void    QCOM_CheckModuleRegistryEntry(
                    UnitInfo        ^unit);
        String  ^QCOM_CleanUpTextBoxTextString(
                    String          ^textBoxText);
        void    QCOM_ClearAllDataLogs(void);
        void    QCOM_ClearAllDataLogsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ClearDataLog(
                    UnitInfo        ^unit);
        void    QCOM_ClearTestResults(
                    UnitInfo        ^unit);
        void    QCOM_CloseCFWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_CloseRawCFWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_CloseUnit(
                    UnitInfo        ^unit);
        void    QCOM_CollectDataSample(
                    DWORD           unitNumber);
        void    QCOM_ComboBoxAcceptEnterKey(
                    Object          ^sender,
                    PreviewKeyDownEventArgs
                                    ^evt);
        void    QCOM_ComputerGoingToHibernation(
                    Object          ^sender,
                    PowerModeChangedEventArgs
                                    ^evt);
        void    QCOM_ComputerShuttingDown(
                    Object          ^sender,
                    SessionEndedEventArgs
                                    ^evt);
        void    QCOM_ConcludeDataLoggingUnit(
                    UnitInfo        ^unit);
        void    QCOM_ConcludeErrorLog(
                    String          ^finalErrorEntry);
        void    QCOM_ConcludeEventLog(
                    String          ^finalEventEntry);
        void    QCOM_ConcludeGeneralLogs(
                    String          ^finalEventEntry);
        void    QCOM_ConfigFileSaveDontSaveAreaClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ConstructAndPresentUserInterface(void);
        void    QCOM_ConstructGeneralExpertGroupBox(
                    TabPage         ^tabPage);
        void    QCOM_ConstructGeneralReadoutGroupBox(
                    TabPage         ^tabPage);
        void    QCOM_ConstructGeneralTestingGroupBox(
                    TabPage         ^tabPage);
        void    QCOM_ConstructGeneralUtilitiesGroupBox(
                    TabPage         ^tabPage);
        void    QCOM_ConstructHomeWindow(void);
        void    QCOM_ConstructHomeTabPages(void);
        void    QCOM_ConstructUnitDescriptionString(
                    UnitInfo        ^unit);
        void    QCOM_ConstructUnitExpertGroupBox(
                    UnitInfo        ^unit);
        void    QCOM_ConstructUnitLogTabInAllWindow(
                    UnitInfo        ^unit);
        void    QCOM_ConstructUnitReadoutGroupBox(
                    UnitInfo        ^unit);
        void    QCOM_ConstructUnitTestingGroupBox(
                    UnitInfo        ^unit);
        void    QCOM_ConstructUnitUtilitiesGroupBox(
                    UnitInfo        ^unit);
        bool    QCOM_ContinueTestingWithErrors(
                    UnitInfo        ^unit);
        String  ^QCOM_ConvertCSVToLogData(
                    String          ^preFormattedData);
        String  ^QCOM_ConvertLogDataToCSV(
                    String          ^preFormattedData);
        void    QCOM_ConvertNativeCoefficientFileSet(void);
        void    QCOM_DefaultExceptionHandler(
                    Object          ^sender,
                    UnhandledExceptionEventArgs
                                    ^evt);
        void    QCOM_DeleteLogFiles(
                    DWORD           logFileSetMask);
        void    QCOM_DetermineTestsViability(
                    UnitInfo        ^unit);
        void    QCOM_DisplayCaptionInLogChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        DWORD   QCOM_DisplayFunctionStatus(
                    DWORD           status,
                    String          ^sourceFunctionName);
        void    QCOM_DisplayHelpLink(
                    Form            ^helpWindow,
                    String          ^textString,
                    DWORD           yPosition,
                    DWORD           fieldWidth,
                    DWORD           firstLinkCharacterOffset,
                    DWORD           numberOfLinkCharacters);
        void    QCOM_DisplayHelpTextLine(
                    Form            ^helpWindow,
                    String          ^textString,
                    DWORD           yPosition,
                    DWORD           fieldWidth);
        void    QCOM_DisplayHexCFParameters(
                    String          ^filePathString,
                    bool            primaryDisplay);
        void    QCOM_DisplayHexCFParametersButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DisplayHexCFParametersCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DisplayLoadedCoefficientData(
                    UnitInfo        ^unit);
        void    QCOM_DisplayLoadedCoefficientDataButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DisplayLoggingStatistics(
                    UnitInfo        ^unit);
        System::Windows::Forms::DialogResult
                QCOM_DisplayModalMessage(
                    bool            allow,
                    DWORD           flag,
                    String          ^titleString,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    QCOM_DisplayMostRecentEventLog(void);
        void    QCOM_DisplayNativeCFParameters(
                    String          ^filePathString,
                    bool            primaryDisplay);
        void    QCOM_DisplayNativeCFParametersCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DisplayNativeNonRefCFParametersButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DisplayNativeRefCFParametersButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DisplayRawCoefficientData(
                    UnitInfo        ^unit,
                    BYTE            device);
        void    QCOM_DisplayStackTrace(
                    String          ^messageString);
        void    QCOM_DisplayStatusLine(
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    QCOM_DisplayTCCheck(
                    UnitInfo        ^unit);
        void    QCOM_DLAllChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DLCountsInHexChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DLDateStampChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DLDefaultsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DLMillisecondsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DLPressureCountChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DLPressureFrequencyChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DLTemperatureCountChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DLTemperatureFrequencyChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DLTimeStampChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DLTransducerAmperageChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DLTransducerVoltageChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_DownloadLatestSoftwareVersion(
                    bool            announceResults);
        bool    QCOM_DriverInstalled(void);
        bool    QCOM_EmailAddressFormatIsValid(
                    String          ^emailAddress);
        void    QCOM_EmailMessageClearComboBox(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_EmailMessageCloseButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_EmailMessageProcessComboEnterKey(
                    Object          ^sender,
                    KeyEventArgs    ^evt);
        void    QCOM_EmailMessageSendButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_EmailMessageSendButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_EmailSupportLogCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_EmbedCaptionInFileChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        DWORD   QCOM_EnsureMinimumEnvironment(void);
        void    QCOM_EraseCoefficientDataFromDevice(
                    UnitInfo        ^unit);
        void    QCOM_ErrorAlert(
                    String          ^titleString,
                    UnitInfo        ^unit,
                    DWORD           status,
                    DWORD           messageFlags,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    QCOM_EstablishErrorLog(void);
        void    QCOM_EstablishEventLog(
                    String          ^initialEventEntry);
        void    QCOM_EstablishLogDirectory(void);
        void    QCOM_EventLogCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExitProgram(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertDetailedMessagesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertDetailedMessagesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertBasicMessagesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertBasicMessagesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertDisplayCoefficientDataButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertDLLMessagesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertDLLMessagesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertEmailMessageCCAddressBoxMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertEmailMessageToAddressBoxMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertEraseCoefficientDataButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertEraseCoefficientDataButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertErrorMessagesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertErrorMessagesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertExperimentalButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertExperimentalButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertExperimentsAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertExperimentsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertExpMessagesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertExpMessagesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertHaltOperationsOnErrorsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertHaltOperationsOnErrorsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertManageMultipleCoefficientDataButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertManageMultipleCoefficientDataButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertMiscButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertPerformExperimentsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertPerformExperimentsButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertProgramInfoButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertProgramInfoButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertProgramIntervalChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertProgramIntervalCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertProgramIntervalMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertRealTimeWeightDemoButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertRealTimeWeightDemoButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertResetAllMessagesButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertResetAllMessagesButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertSendAllTransducerReadingsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertSendAllTransducerReadingsAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertSendEmailErrorMessageChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertSendEmailErrorMessageCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertSendTextErrorMessageChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertSendTextErrorMessageCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertStackTraceChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertStackTraceCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertTextMessageCCNumberBoxMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertTextMessageToNumberBoxMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertUnitSendTransducerReadingsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertUnitSendTransducerReadingsAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertUnitTransducerPowerButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertUnitTransducerPowerButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertVerboseMessagesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExpertVerboseMessagesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ExportCoefficientDataToFile(
                    UnitInfo        ^unit);
        void    QCOM_ExportCoefficientDataFileButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_Finalize(
                    String          ^finalEventEntry);
        void    QCOM_FreeGeneralElements(void);
        void    QCOM_GenerateSupportLog(void);
        void    QCOM_GetModuleInfo(
                    UnitInfo        ^unit);
        DWORD   QCOM_GetNumberOfTransducers(void);
        void    QCOM_GetOperatingEnvironment(void);
        double  QCOM_GetPressureValue(
                    UnitInfo        ^unit,
                    int             units);
        double  QCOM_GetTemperatureValue(
                    UnitInfo        ^unit,
                    int             units);
        DWORD   QCOM_GetTransducerInfo(
                    UnitInfo        ^unit);
        DWORD   QCOM_GetTransducerPowerState(
                    UnitInfo        ^unit);
        void    QCOM_GetWindowsVersion(void);
        bool    QCOM_GlobalFileSearch(
                    String          ^fileName,
                    StringBuilder   ^filePathBuilder);
        int     QCOM_GraphingCalculateVerticalPosition(
                    UnitInfo        ^unit,
                    DWORD           graphContext);
        void    QCOM_GraphingClearGraph(
                    UnitInfo        ^unit);
        void    QCOM_GraphingClearGraphButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_GraphingCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_GraphingClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        double  QCOM_GraphingConvertToCurrentUnits(
                    double          value,
                    DWORD           valueType);
        double  QCOM_GraphingConvertToDefaultUnits(
                    double          value,
                    DWORD           valueType);
        void    QCOM_GraphingDisplayAmperageDrawChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_GraphingDisplayCurrentBoundaryValues(
                    UnitInfo        ^unit);
        void    QCOM_GraphingDisplayLargeFormattedValues(
                    UnitInfo        ^unit);
        void    QCOM_GraphingMilitaryTimeFormatChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_GraphingPictureBoxClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_GraphingReflectBoundaryValues(
                    UnitInfo        ^unit);
        void    QCOM_GraphingSaveGraph(
                    UnitInfo        ^unit);
        void    QCOM_GraphingSaveGraphButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_GraphingSetDefaultBoundaryValues(
                    UnitInfo        ^unit);
        void    QCOM_GraphingSetDefaultBoundaryValuesButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_GraphingSetGraphingThresholds(
                    UnitInfo        ^unit);
        void    QCOM_GraphingSingleStepButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_GraphingSuperimposePressureTemperatureChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_GraphingUpdateDisplayWindow(
                    UnitInfo        ^unit);
        void    QCOM_GraphingUpdateGraphCalculations(
                    UnitInfo        ^unit);
        void    QCOM_GraphingUseThickLinesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_GraphingValidateAmperageHighBoundaryValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_GraphingValidateAmperageLowBoundaryValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_GraphingValidatePressureHighBoundaryValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_GraphingValidatePressureLowBoundaryValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_GraphingValidateTemperatureHighBoundaryValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_GraphingValidateTemperatureLowBoundaryValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_HaltAllUserActivity(void);
        void    QCOM_HelpAboutQuartzdyneLogoMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_HelpAboutSoftwareLogoMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_HelpCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_HomeClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    QCOM_HomeExitButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_HomeOpeningBannerMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_HomeTabSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_HomeTabMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_HomeUpdateProgressBar(
                    DWORD           itemsCompleted,
                    DWORD           itemsToComplete);
        void    QCOM_HomeUpdateStatusLine(
                    String          ^statusString);
        void    QCOM_HomeWindowEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_HomeWindowExited(
                    Object          ^sender,
                    EventArgs       ^evt);
        bool    QCOM_I2CChecksumVerified(
                    char            *i2CReplyData);
        bool    QCOM_ImportCoefficientDataFromFile(
                    UnitInfo        ^unit,
                    String          ^filePathString);
        void    QCOM_InitializeGeneralFields(void);
        void    QCOM_InitializeGUIComponents(void);
        void    QCOM_InitializeProgramComponents(void);
        DWORD   QCOM_InitializeQCOM(void);
        DWORD   QCOM_InitializeSoftwareBase(void);
        void    QCOM_InitializeUnitFields(
                    UnitInfo        ^unit);
        void    QCOM_InitializeUserInterface(void);
        void    QCOM_InitiateUnitTests(
                    Object          ^moduleNumber);
        void    QCOM_InstallConvertReadingsObjects(void);
        void    QCOM_InstallDataLogging(void);
        void    QCOM_InstallGraphingWindows(void);
        void    QCOM_InstallHomeWindowGraphics(void);
        void    QCOM_InstallMultipleCoefficientWindows(void);
        void    QCOM_InstallRealTimeWeightWindows(void);
        void    QCOM_InstallStatusStrip(void);
        void    QCOM_InstallToolStrip(void);
        void    QCOM_InstallUtilities(void);
        void    QCOM_InternetHyperLinkClicked(
                    Object          ^sender,
                    LinkLabelLinkClickedEventArgs
                                    ^evt);
        bool    QCOM_InternetIsAvailable(void);
        void    QCOM_InterpretCoefficientData(
                    UnitInfo        ^unit);
        String  ^QCOM_LimitFilePathStringWidth(
                    String          ^filePath,
                    DWORD           maximumWidth);
        String  ^QCOM_LimitStringWidth(
                    String          ^textString,
                    DWORD           maximumWidth,
                    bool            truncateString);
        void    QCOM_LoadImagesAndSounds(void);
        void    QCOM_LogAllBothFileFormatsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogAllDisplayButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogAllClearCommentButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogAllCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogAllClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    QCOM_LogAllCommentTimeStampChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogAllDisplayAllSummariesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogAllInsertComment(
                    UnitInfo        ^unit);
        void    QCOM_LogAllInsertCommentButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogAllPrependEntryNumbersChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogAllSaveLoggedDataImmediatelyChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogAllSnapshotData(void);
        void    QCOM_LogAllSnapshotDataButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogAllStartStopButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogAllUpdateCaptions(void);
        void    QCOM_LogAllWrapDisplayChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogFileAppendRadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogFileAutoSaveRadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogFileMovePair(
                    String          ^sourcePathString,
                    String          ^destinationPathString);
        void    QCOM_LogFileOverwriteRadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogFilePromptRadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogPromptAndConvertCSVToDataLogFormat(void);
        void    QCOM_LogPromptAndConvertDataLogToCSVFormat(void);
        void    QCOM_LogUnitAltPressureChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitAltTemperatureChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitBothFileFormatsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitClearCommentButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitClearDataButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    QCOM_LogUnitCommentTimeStampChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitDataSample(
                    UnitInfo        ^unit);
        void    QCOM_LogUnitDefPressureChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitDefTemperatureChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitDetermineDataLogFilePaths(
                    UnitInfo        ^unit);
        void    QCOM_LogUnitDisplayButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitDisplaySummaryChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitInitializeStatistics(
                    UnitInfo        ^unit);
        void    QCOM_LogUnitInsertComment(
                    UnitInfo        ^unit);
        void    QCOM_LogUnitInsertCommentButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitPrependEntryNumbersChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitReflectDataPresence(
                    UnitInfo        ^unit);
        DWORD   QCOM_LogUnitSaveDataLog(
                    UnitInfo        ^unit,
                    String          ^pathString);
        DWORD   QCOM_LogUnitSaveDataLogLine(
                    UnitInfo        ^unit);
        void    QCOM_LogUnitSaveLoggedDataImmediatelyChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitSelectDataLogFileButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitSnapshotData(
                    UnitInfo        ^unit);
        void    QCOM_LogUnitSnapshotDataButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitStartStopButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_LogUnitUpdateCaptions(
                    UnitInfo        ^unit);
        void    QCOM_LogUnitUpdateChecks(
                    UnitInfo        ^unit);
        void    QCOM_LogUnitUpdateDataLog(
                    UnitInfo        ^unit,
                    DWORD           actionFlags);
        void    QCOM_LogUnitUpdateFullProgressBars(
                    UnitInfo        ^unit);
        void    QCOM_LogUnitWrapDisplayChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        DWORD   QCOM_MapDisplayIntervalToActual(
                    DWORD           displayInterval);
        void    QCOM_MarkSampleTimeThread(void);
        void    QCOM_MarkTestingTime(
                    Object          ^moduleNumber);
        void    QCOM_MiscBootLoaderButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscClearErrorCodeButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscClearI2CCommandBox(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscCloseDisplayDLLFunctionsWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscClosingPFCWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    QCOM_MiscClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    QCOM_MiscConstructUnitControlTab(
                    UnitInfo        ^unit);
        void    QCOM_MiscControlsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscCopyModuleMemoryToXD(
                    UnitInfo        ^unit);
        void    QCOM_MiscCopyXDMemoryToModule(
                    UnitInfo        ^unit);
        void    QCOM_MiscDeleteConfigChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscDisplayDLLFunctions(
                    UnitInfo        ^unit);
        void    QCOM_MiscDisplayDLLFunctionsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscDisplayRawModuleCoeffButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscDisplayRawXDCoeffButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscEnableSoundsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscGetAndPostI2CDataRate(
                    UnitInfo        ^unit);
        void    QCOM_MiscGetControlRegisterButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscGetFirmwareIDButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscGetI2CDataRateButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscGetNumberOfModulesButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscGetQCOMDLLVersionButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscGetSetI2CDataRateBoxClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscGetMemoryTypeButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscGetStatusRegisterButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscGetTimeoutsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscGetTransducerChipIDButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscGetTransducerTypeButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFGeneralLogBothFileFormatsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFGeneralLogDataSaveImmediatelyChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFGeneralLogDisplayAllSummariesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFGeneralLogDisplayAllWrappedChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFGeneralLogPrependEntryNumbersChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFGeneralSoundsEnabledChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFGeneralTestDisplayXDTestsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFSetAllDefaultsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFSetGeneralDefaultsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFSetUnitDefaultsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFSetUpControl(void);
        void    QCOM_MiscPFUnitDisplayHexCountsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFUnitEmailXDReadingsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFUnitLogDataSaveImmediatelyChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFUnitSendXDReadingsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFUnitTestResultsDisplayChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscPFUnitTextXDReadingsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscProcessI2CCommandBoxEnterKey(
                    Object          ^sender,
                    KeyEventArgs    ^evt);
        void    QCOM_MiscReadCadenceTimerButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscReadErrorCodeButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscReadModuleSerialNumberButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscReadXDMemoryButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscSendI2CCommand(
                    UnitInfo        ^unit);
        void    QCOM_MiscSendI2CCommandButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscSetAndPostCadenceTimer(
                    UnitInfo        ^unit);
        void    QCOM_MiscSetAndPostControlRegister(
                    UnitInfo        ^unit);
        void    QCOM_MiscSetAndPostI2CDataRate(
                    UnitInfo        ^unit);
        void    QCOM_MiscSetAndPostTimeouts(void);
        void    QCOM_MiscSetCadenceTimerButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscSetControlRegisterButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscSetI2CDataRateButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscSetTimeoutsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscSetUpControls(void);
        void    QCOM_MiscToggleTransducerType(
                    UnitInfo        ^unit);
        void    QCOM_MiscToggleTransducerTypeButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MiscUpdateChecks(void);
        void    QCOM_MiscUpdatePersistentChecks(void);
        void    QCOM_MiscValidateI2CDataRateBox(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_MiscWriteXDMemoryButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MultipleCoefficientCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MultipleCoefficientClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    QCOM_MultipleCoefficientModuleClearButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MultipleCoefficientModuleClearSlot(
                    UnitInfo        ^unit,
                    BYTE            slotNumber);
        void    QCOM_MultipleCoefficientModuleCopyButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MultipleCoefficientModuleCopyToTransducer(
                    UnitInfo        ^unit,
                    BYTE            slotNumber);
        void    QCOM_MultipleCoefficientModuleLoadSlot(
                    UnitInfo        ^unit,
                    BYTE            slotNumber);
        void    QCOM_MultipleCoefficientModuleUpdateButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MultipleCoefficientModuleVerifyButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MultipleCoefficientModuleVerifySlot(
                    UnitInfo        ^unit,
                    BYTE            slotNumber);
        void    QCOM_MultipleCoefficientTransducerClearButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MultipleCoefficientTransducerClearSlot(
                    UnitInfo        ^unit,
                    BYTE            slotNumber);
        void    QCOM_MultipleCoefficientTransducerCopyButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MultipleCoefficientTransducerCopyToModule(
                    UnitInfo        ^unit,
                    BYTE            slotNumber);
        void    QCOM_MultipleCoefficientTransducerLoadSlot(
                    UnitInfo        ^unit,
                    BYTE            slotNumber);
        void    QCOM_MultipleCoefficientTransducerUpdateButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MultipleCoefficientTransducerVerifyButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_MultipleCoefficientTransducerVerifySlot(
                    UnitInfo        ^unit,
                    BYTE            slotNumber);
        void    QCOM_OneMinuteTimerElapsed(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_OneSecondTimerElapsed(
                    Object          ^sender,
                    EventArgs       ^evt);
        DWORD   QCOM_OpenUnit(
                    UnitInfo        ^unit);
        bool    QCOM_ParseAndConvertStringToDouble(
                    String          ^doubleString,
                    double          *doubleEquivalent);
        bool    QCOM_ParseAndConvertStringToUnsigned(
                    String          ^integerString,
                    DWORD           *unsignedEquivalent);
        void    QCOM_PauseElapsedTime(void);
        void    QCOM_PauseResumeButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_PauseResumeButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_PerformCommandLineTasks(void);
        void    QCOM_PerformExperimentalExercise(void);
        void    QCOM_PerformExperiments(void);
        void    QCOM_PleaseWait(
                    DWORD           action,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    QCOM_PleaseWaitClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    QCOM_PostTest(
                    UnitInfo        ^unit);
        void    QCOM_PrecisionUpDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_PrecisionUpDownDoubleClicked(
                    Object          ^sender,
                    MouseEventArgs  ^evt);
        void    QCOM_PreTest(
                    UnitInfo        ^unit);
        void    QCOM_PrintFileButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        DWORD   QCOM_ProcessCommandLineParameters(void);
        DWORD   QCOM_ProcessI2CCommand(
                    UnitInfo        ^unit,
                    char            *commandString,
                    char            *replyString,
                    char            *interpretationString);
        void    QCOM_ProgramInformationCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ProgramInformationDisplayTab(
                    UnitInfo        ^unit);
        void    QCOM_ProgramInformationDisplayWindow(void);
        void    QCOM_ProgramTimerElapsed(
                    Object          ^sender,
                    EventArgs       ^evt);
        bool    QCOM_PromptAndSaveDataLog(
                    UnitInfo        ^unit,
                    String          ^filePathString,
                    DWORD           dataLogFlag);
        bool    QCOM_PromptAndSaveTestResultsFile(
                    UnitInfo        ^unit);
        void    QCOM_PromptAndVerifyHexFile(void);
        void    QCOM_PromptForDownloadCoefficientFiles(void);
        void    QCOM_PromptForImportCoefficientDataFromFile(
                    UnitInfo        ^unit);
        bool    QCOM_PromptForReadFile(
                    String          ^titleString,
                    StringBuilder   ^filePathBuilder,
                    String          ^suggestedFileName,
                    DWORD           fileType);
        void    QCOM_PromptForRetrieveCoefficientFileParameters(void);
        bool    QCOM_PromptForSaveFile(
                    String          ^titleString,
                    StringBuilder   ^filePathBuilder,
                    String          ^suggestedFileName,
                    DWORD           fileType);
        bool    QCOM_PromptInputModal(
                    String          ^titleString,
                    String          ^suggestedInputString,
                    DWORD           *inputValue,
                    StringBuilder   ^inputStringBuilder,
                    DWORD           maximumInputStringSize,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    QCOM_PromptKeyPressed(
                    Object          ^sender,
                    KeyPressEventArgs
                                    ^evt);
        bool    QCOM_PromptPulldownModal(
                    String          ^titleString,
                    array <String ^>
                                    ^pulldownList,
                    DWORD           *listOffset,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        bool    QCOM_PromptYesNoModal(
                    String          ^titleString,
                    String          ^yesText,
                    String          ^noText,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        bool    QCOM_QueryEnableTransducerPower(
                    UnitInfo        ^unit);
        bool    QCOM_QueryIncreaseSamplingTimeForLogging(void);
        bool    QCOM_QuerySaveDataLog(
                    UnitInfo        ^unit);
        bool    QCOM_QuerySaveTestResultsFile(
                    UnitInfo        ^unit);
        void    QCOM_QuerySaveUnsavedLogData(void);
        void    QCOM_QuerySaveUnsavedTestResults(void);
        bool    QCOM_QuerySelectDataLogFile(
                    UnitInfo        ^unit);
        bool    QCOM_QuerySelectTestResultsFile(
                    UnitInfo        ^unit);
        bool    QCOM_QueryStopLogging(
                    UnitInfo        ^unit,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        bool    QCOM_QueryStopSampling(
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        bool    QCOM_QueryStopTesting(
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        DWORD   QCOM_ReadCoefficientDataFromFile(
                    String          ^filePathString,
                    CoefficientFormatDef
                                    *coefficientData);
        String  ^QCOM_ReadFilePathFromLine(
                    String          ^lineString,
                    String          ^parameter);
        void    QCOM_ReadoutAlternatePressureTemperatureRadioMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutAlternatePressureTemperatureRadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutAlternatePressureUnitsAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutAlternatePressureUnitsComboProcessEnterKey(
                    Object          ^sender,
                    KeyEventArgs    ^evt);
        void    QCOM_ReadoutAlternatePressureUnitsComboProcessSelection(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutAlternateTemperatureUnitsAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutAlternateTemperatureUnitsComboProcessEnterKey(
                    Object          ^sender,
                    KeyEventArgs    ^evt);
        void    QCOM_ReadoutAlternateTemperatureUnitsComboProcessSelection(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutClearAllLogsButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutClearUnitLogButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutContinuousSamplingTimeLabelMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutCountsRadioMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutCountsRadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutCountsSelected(void);
        void    QCOM_ReadoutDefaultPressureTemperatureRadioMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutDefaultPressureTemperatureRadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutDisplayAllFrequenciesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutDisplayAllFrequenciesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutDisplayAllVIValuesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutDisplayAllVIValuesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutDisplayAlternateUnits(void);
        void    QCOM_ReadoutDisplayUnitGraphButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutDisplayUnitGraphButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutDisplayDefaultUnits(void);
        void    QCOM_ReadoutDisplayUnitFrequenciesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutDisplayUnitFrequenciesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutDisplayUnitVIValuesChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutDisplayUnitVIValuesCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutFirmwareInfoLabelMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutHexCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutHexCountsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutIncludeAllInSamplingChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutIncludeAllInSamplingCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutIncludeUnitInSamplingChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutIncludeUnitInSamplingCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutLimitSamplingTimeAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutLimitSamplingTimeChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutLimitSamplingTimeCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutLogUnitStartStopButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutPrecisionNumericMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutPressureAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutPressureFrequencyMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutSamplingIntervalMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutStartStopLoggingAllButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutStartStopSamplingButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutTemperatureAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutTemperatureFrequencyMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutTransducerAmperageAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutTransducerVoltageAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutUnitStartStopSamplingButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ReadoutUnitStartStopSamplingButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_RealTimeWeightCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_RealTimeWeightClosingWindow(
                    Object          ^sender,
                    FormClosingEventArgs
                                    ^evt);
        void    QCOM_RealTimeWeightCalibrateButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_RealTimeWeightCreateWindow(
                    DWORD           unitNumber);
        void    QCOM_RealTimeWeightDisplayWindow(
                    DWORD           unitNumber);
        void    QCOM_RealTimeWeightStartStopButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_RealTimeWeightUpdateDisplayWindow(
                    UnitInfo        ^unit);
        void    QCOM_RecordAndModalErrorEvent(
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    QCOM_RecordAndModalEventByFlags(
                    bool            eventFlag,
                    bool            messageFlag,
                    String          ^sourceFunction,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    QCOM_RecordEvent(
                    bool            allow,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
        void    QCOM_ReDrawGraphingWindow(
                    UnitInfo        ^unit);
        void    QCOM_ReDrawWindows(
                    Object          ^hotPlugContext);
        void    QCOM_ReInitializeUserInterface(
                    DWORD           hotPlugLevel);
        void    QCOM_ReScanForDevices(
                    DWORD           hotPlugLevel);
        void    QCOM_ReScanModules(void);
        void    QCOM_ReScanSystem(void);
        void    QCOM_ResetAll(void);
        void    QCOM_ResetAllButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
//        void    QCOM_ResetAllHardware(void);
        void    QCOM_ResetAllModules(void);
        void    QCOM_ResetAllSoftware(void);
        void    QCOM_ResetAllTransducers(void);
        void    QCOM_ResetModule(
                    UnitInfo        ^unit);
        void    QCOM_ResetSystem(void);
        void    QCOM_ResetTransducer(
                    UnitInfo        ^unit);
        void    QCOM_ResetUnit(
                    UnitInfo        ^unit);
        void    QCOM_ResetUnitSoftware(
                    UnitInfo        ^unit);
        void    QCOM_ResetUnitSoftwareButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ResumeElapsedTime(void);
        DWORD   QCOM_RetrieveCoefficientData(
                    UnitInfo        ^unit);
        DWORD   QCOM_RetrieveCoefficientFileParameters(
                    String          ^filePathString,
                    array <String ^>
                                    ^coefficientParametersList);
        void    QCOM_RetrieveConfigData(void);
        void    QCOM_RetrieveFirmwareInformation(
                    UnitInfo        ^unit);
        DWORD   QCOM_RetrieveTransducerReadings(
                    UnitInfo        ^unit);
        void    QCOM_SamplingHoursRadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_SamplingMillisecondsRadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_SamplingMinutesRadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_SamplingSecondsRadioSelected(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_SamplingTimerElapsed(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_SaveAsFileButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_SaveBinaryData(
                    array <Byte>    ^binaryData,
                    String          ^binaryFileName);
        void    QCOM_SaveConfigData(void);
        void    QCOM_ScanForDevices(void);
        bool    QCOM_SearchForCoefficientFile(
                    String          ^serialNumberString,
                    StringBuilder   ^filePathBuilder);
        bool    QCOM_SelectDataLogFile(
                    UnitInfo        ^unit);
        bool    QCOM_SelectTestDataFile(
                    UnitInfo        ^unit);
        bool    QCOM_SelectTestFirmwareFile(
                    UnitInfo        ^unit);
        bool    QCOM_SelectTestResultsFile(
                    UnitInfo        ^unit);
        DWORD   QCOM_SendEmailMessage(
                    String          ^emailSubjectString,
                    String          ^emailMessageString);
        DWORD   QCOM_SendEmailMessageStructure(
                    EmailInfo       ^emailInfo);
        void    QCOM_SendEveryTimerElapsed(
                    Object          ^sender,
                    EventArgs       ^evt);
        DWORD   QCOM_SendSMTPMail(
                    MailMessage     ^mailPackage);
        DWORD   QCOM_SendTextMessage(
                    String          ^textSubjectString,
                    String          ^textMessageString);
        void    QCOM_SetBuildNumber(void);
        void    QCOM_SetCurrentNumberOfUnits(void);
        void    QCOM_SetDecimalPrecision(void);
        double  QCOM_SetTransducerMaximumDataRate(
                    UnitInfo        ^unit);
        void    QCOM_SetUnitFlagsToInitialValues(
                    UnitInfo        ^unit);
        void    QCOM_SetUpAllDataLoggingWindows(void);
        void    QCOM_SetUpUnitDataLoggingWindow(
                    UnitInfo        ^unit);
        void    QCOM_SetUpUnitGraphingWindow(
                    UnitInfo        ^unit);
        void    QCOM_SetUpUnitMultipleCoefficientWindow(
                    UnitInfo        ^unit);
        void    QCOM_ShutDownSoftware(void);
        void    QCOM_StampDataLogStarted(
                    UnitInfo        ^unit);
        void    QCOM_StampDataLogStopped(
                    UnitInfo        ^unit);
        void    QCOM_StampDataLogTruncated(
                    UnitInfo        ^unit,
                    bool            logWasSaved);
        void    QCOM_StampTestResultsLogBeginLoop(
                    UnitInfo        ^unit,
                    DWORD           loopNumber,
                    DWORD           maximumLoopCount);
        void    QCOM_StampTestResultsLogEndLoop(
                    UnitInfo        ^unit,
                    DWORD           loopNumber,
                    DWORD           maximumLoopCount,
                    bool            endOfTest);
        void    QCOM_StampTestResultsLogTruncated(
                    UnitInfo        ^unit,
                    bool            resultsWereSaved);
        void    QCOM_StartDataLoggingUnit(
                    UnitInfo        ^unit);
        void    QCOM_StartPausedBlinker(void);
        void    QCOM_StartSamplingUnit(
                    UnitInfo        ^unit);
        void    QCOM_StartStopDataLoggingAll(void);
        void    QCOM_StartStopDataLoggingUnit(
                    UnitInfo        ^unit);
        void    QCOM_StartStopSamplingAll(void);
        void    QCOM_StartStopSamplingButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_StartStopSamplingUnit(
                    UnitInfo        ^unit);
        void    QCOM_StopDataLoggingUnit(
                    UnitInfo        ^unit);
        void    QCOM_StopPausedBlinker(void);
        void    QCOM_StopSamplingUnit(
                    UnitInfo        ^unit);
        DWORD   QCOM_StringWidth(
                    String          ^textString);
        void    QCOM_SwitchFromBootLoaderMode(
                    UnitInfo        ^unit);
        void    QCOM_SwitchToBootLoaderMode(
                    UnitInfo        ^unit);
        void    QCOM_TabPageAddDelegate(
                    TabControl      ^parentTabControl,
                    TabPage         ^childTabPage);
        void    QCOM_TabPageRemoveDelegate(
                    TabControl      ^parentTabControl,
                    TabPage         ^childTabPage);
        void    QCOM_TerminateDataLogging(void);
        void    QCOM_TerminateTesting(void);
        void    QCOM_TestAllAppendResultsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllAppendResultsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllAutoSaveResultsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllAutoSaveResultsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllClearResultsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllClearResultsButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllDetailedResultsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllDetailedResultsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllDisplayResultsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllDisplayResultsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllDisplayTransducerTestsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllDisplayTransducerTestsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllLoopAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllLoopChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllLoopForeverChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllResetButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllResetTestsButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllSaveResultsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllSaveResultsButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllStartStopTestingButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllStartStopTestingButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllStopOnErrorsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllStopOnErrorsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllWrapResultsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestAllWrapResultsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestClearCommentButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestClearCommentButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestCommentTimeStampChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestCommentTimeStampCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestDetermineDataFilePath(
                    UnitInfo        ^unit);
        void    QCOM_TestDetermineFirmwareFilePath(
                    UnitInfo        ^unit);
        void    QCOM_TestDetermineResultsFilePath(
                    UnitInfo        ^unit);
        void    QCOM_TestFileMove(
                    String          ^sourcePathString,
                    String          ^destinationPathString);
        void    QCOM_TestInsertComment(
                    UnitInfo        ^unit);
        void    QCOM_TestInsertCommentAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestInsertCommentButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestInsertCommentButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestReflectDataPresence(
                    UnitInfo        ^unit);
        void    QCOM_TestStartStopTestingAllUnits(void);
        bool    QCOM_TestSuiteFirmware(
                    UnitInfo        ^unit);
        bool    QCOM_TestSuiteI2C(
                    UnitInfo        ^unit);
        bool    QCOM_TestSuiteQMEM(
                    UnitInfo        ^unit);
        bool    QCOM_TestSuiteReadings(
                    UnitInfo        ^unit);
        bool    QCOM_TestSuiteTransducerCommunication(
                    UnitInfo        ^unit);
        bool    QCOM_TestSuiteTransducerIntegrity(
                    UnitInfo        ^unit);
        bool    QCOM_TestSuiteTransducerMemory(
                    UnitInfo        ^unit);
        bool    QCOM_TestSuiteX2(
                    UnitInfo        ^unit);
        bool    QCOM_TestSuiteX3(
                    UnitInfo        ^unit);
        bool    QCOM_TestSuiteX4(
                    UnitInfo        ^unit);
        void    QCOM_TestUnitAllModuleChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitAllModuleCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitAllTransducerChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitAllTransducerCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitClearResultsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitClearResultsButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitDetailedResultsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitDetailedResultsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitFirmwareChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitFirmwareCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitI2CChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitI2CCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitInitializeStatistics(
                    UnitInfo        ^unit);
        void    QCOM_TestUnitPassCountLabelMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitProgressBarAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitQMEMChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitQMEMCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitReadingsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitReadingsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitResultsBoxMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitResultsFileLabelMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitRunningTimeLabelMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitSaveResultsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitSaveResultsButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        DWORD   QCOM_TestUnitSaveResultsLog(
                    UnitInfo        ^unit,
                    String          ^pathString);
        void    QCOM_TestUnitSelectResultsFileButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitSelectResultsFileButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitStartStopTests(
                    UnitInfo        ^unit);
        void    QCOM_TestUnitStartStopButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitStartStopButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitStateAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitTimeStampResultsChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitTimeStampResultsCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitUpdateProgressBar(
                    UnitInfo        ^unit);
        void    QCOM_TestUnitUpdateResultsLog(
                    UnitInfo        ^unit,
                    DWORD           actionFlags);
        void    QCOM_TestUnitXDCommChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitXDCommCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitXDIntegrityChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitXDIntegrityCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitXDMemoryChecked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitXDMemoryCheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitX2Checked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitX2CheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitUpdateChecks(
                    UnitInfo        ^unit);
        void    QCOM_TestUnitX3Checked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitX3CheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitX4Checked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_TestUnitX4CheckMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToggleBootLoaderMode(
                    UnitInfo        ^unit);
        void    QCOM_ToggleExpertMode(void);
        void    QCOM_ToggleGeneralFlagThenSetUnitFlags(
                    DWORD           generalFlag,
                    DWORD           unitFlag);
        void    QCOM_ToggleGeneralLogFlagThenSetUnitFlags(
                    DWORD           generalLogFlag,
                    DWORD           unitLogFlag);
        void    QCOM_ToggleGeneralTestFlagThenSetUnitFlags(
                    DWORD           generalTestFlag,
                    DWORD           unitTestFlag);
        void    QCOM_ToggleTransducerPowerState(
                    UnitInfo        ^unit);
        void    QCOM_ToggleUnitFlagThenSetGeneralFlag(
                    UnitInfo        ^unit,
                    DWORD           generalFlag,
                    DWORD unitFlag);
        void    QCOM_ToggleUnitLogFlagThenSetGeneralFlag(
                    UnitInfo        ^unit,
                    DWORD           generalLogFlag,
                    DWORD           unitLogFlag);
        void    QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
                    UnitInfo        ^unit,
                    DWORD           generalTestFlag,
                    DWORD           unitTestFlag);
        void    QCOM_ToolStripAboutDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripAboutDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripAdvancedButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripAdvancedButtonMouseMoved(
                    Object          ^sender,
                    MouseEventArgs  ^evt);
        void    QCOM_ToolStripButtonsMouseExited(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripCheckForUpdateDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripCheckForUpdateDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripConfigFileSaveDontSaveAreaMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteAllDataCSVFilesDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteAllDataCSVFilesDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteAllDataLogFilesDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteAllDataLogFilesDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteAllErrorLogFilesDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteAllErrorLogFilesDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteAllEventLogFilesDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteAllEventLogFilesDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteAllLogFilesDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteAllLogFilesDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteAllTestResultsFilesDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteAllTestResultsFilesDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDeleteLogFilesMouseExited(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDisplayEventLogDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDisplayEventLogDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDownloadTheLatestDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDownloadTheLatestDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripDropDownsMouseExited(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripEventLogAllDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripEventLogAllDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripEventLogBasicDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripEventLogBasicDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripEventLogDetailedDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripEventLogDetailedDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripEventLogDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripEventLogDropDownMouseExited(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripEventLogTestDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripEventLogTestDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripEventLogVerboseDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripEventLogVerboseDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripExpertModeDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripExpertModeDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripFileButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripFileButtonMouseMoved(
                    Object          ^sender,
                    MouseEventArgs  ^evt);
        void    QCOM_ToolStripFunctionsButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripFunctionsButtonMouseMoved(
                    Object          ^sender,
                    MouseEventArgs  ^evt);
        void    QCOM_ToolStripHelpButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripHelpButtonMouseMoved(
                    Object          ^sender,
                    MouseEventArgs  ^evt);
        void    QCOM_ToolStripLogFilesSaveDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripLogFilesSaveDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripMiscControlsDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripMiscControlsDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripOnlineHelpDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripOnlineHelpDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripProgInfoDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripProgInfoDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripRefreshDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripReScanDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripReScanDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripResetAllDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripResetAllModulesDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripResetAllModulesDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripResetAllSoftwareDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripResetAllSoftwareDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripResetAllTransducersDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripResetAllTransducersDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripResetDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripResetFunctionMouseExited(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripSupportLogDropDownClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ToolStripSupportLogDropDownMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        bool    QCOM_TransferDataLogToFile(
                    UnitInfo        ^unit,
                    bool            targetMainLog);
        bool    QCOM_TransferTestResultsToFile(
                    UnitInfo        ^unit);
        void    QCOM_UpdateAllReadouts(void);
        void    QCOM_UpdateDeleteLogFilesDropDown(void);
        void    QCOM_UpdateErrorLog(
                    String          ^descriptionString);
        void    QCOM_UpdateEventLog(
                    String      ^descriptionString);
        void    QCOM_UpdateFirmwareDisplays(
                    UnitInfo        ^unit);
        void    QCOM_UpdateGlobalObjects(
                    DWORD           context);
        void    QCOM_UpdateGlobalObjectsPerFlags(void);
        void    QCOM_UpdateGlobalUnitObjectsPerFlags(
                    UnitInfo        ^unit);
//        void    QCOM_UpdateIncludeCheck(UnitDef *unit);
        void    QCOM_UpdateMessageChecks(void);
        void    QCOM_UpdateModuleFirmware(
                    UnitInfo        ^unit);
        void    QCOM_UpdateMultipleCoefficientWindow(
                    UnitInfo        ^unit);
        void    QCOM_UpdateSendEveryMinutesRemainingLabel(
                    DWORD           unitNumber);
        void    QCOM_UpdateStatusLine(
                    String          ^statusString);
        void    QCOM_UpdateReadout(
                    UnitInfo        ^unit);
        bool    QCOM_URLExists(
                    String          ^URL);
        void    QCOM_UtilConvertNativeCoefficientFileSetButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilConvertNativeCoefficientFileSetButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilConvertCSVToDataLogButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilConvertCSVToDataLogButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilConvertDataLogToCSVButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilConvertDataLogToCSVButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilConvertReadings(void);
        void    QCOM_UtilConvertReadingsCloseWindow(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilConvertReadingsButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilConvertReadingsButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilConvertReadingsLoadFile(void);
        void    QCOM_UtilConvertReadingsLoadFileButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilConvertReadingsProcessFile(
                    String          ^convertReadingsPath);
        void    QCOM_UtilConvertTransducerCounts(void);
        void    QCOM_UtilConvertTransducerFrequencies(void);
        void    QCOM_UtilLogAllDisplayButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilLogUnitDisplayButtonMouseEntered(
                    Object          ^sender, 
                    EventArgs       ^evt);
        void    QCOM_UtilDisplayTCCheckButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilDisplayTCCheckButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilDownloadCoefficientFilesButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilDownloadCoefficientFilesButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilExportCoefficientDataFileButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilImportCoefficientDataFileButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilImportCoefficientDataFileButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilResetAllButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilResetModuleButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilResetModuleButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilUnitResetTransducerButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilUnitResetTransducerButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilRetrieveCoefficientFileParametersButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilRetrieveCoefficientFileParametersButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilUnitUpdateFirmwareButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilUnitUpdateFirmwareButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilVerifyHexFileButtonClicked(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_UtilVerifyHexFileButtonMouseEntered(
                    Object          ^sender,
                    EventArgs       ^evt);
        void    QCOM_ValidateConvertReadingsPressureCount(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateConvertReadingsPressureFrequency(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateConvertReadingsTemperatureCount(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateConvertReadingsTemperatureFrequency(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateConvertReadingsTransducerSerialNumber(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateEmailMessageAddresses(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateExperimentNumberValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateLoggingIntervalValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateLoggingLimitValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateProgramIntervalValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateRealTimeWeightMultiplierValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateSamplingIntervalValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateSamplingLimitValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateSendEveryIntervalValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateTestLoopCountValue(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_ValidateTextMessageNumbers(
                    Object          ^sender,
                    CancelEventArgs ^evt);
        void    QCOM_VerifyAndSendEmail(
                    EmailInfo       ^emailInfo);
        void    QCOM_VerifyHexFileFormat(
                    String          ^filePathString);
        void    QCOM_ZipFiles(
                    array <String ^>
                                    ^filesToZip,
                    String          ^zipFileName);
    //------------------------------------------------------------------------
    // Custom delegates
    //------------------------------------------------------------------------
    delegate
        void    QCOM_AddTabPageDelegate(
                    TabControl      ^parentTabControl,
                    TabPage         ^childTabPage);
    delegate
        void    QCOM_RemoveTabPageDelegate(
                    TabControl      ^parentTabControl,
                    TabPage         ^childTabPage);
    delegate
        void    InvokeDelegate(void);
};                                      // end of QCOM_GUIClass
//----------------------------------------------------------------------------
// Boolean definitions
//----------------------------------------------------------------------------
#define     GUI_YES                                             true
#define     GUI_NO                                              false
#define     GUI_MAIN_LOG                                        GUI_YES
#define     GUI_SNAPSHOT_LOG                                    GUI_NO
#define     GUI_ACCEPT                                          GUI_YES
#define     GUI_CANCEL                                          GUI_NO
#define     GUI_DETAILED_LOG                                    GUI_YES
#define     GUI_SIMPLE_LOG                                      GUI_NO
#define     GUI_TRUNCATE_STRING                                 GUI_YES
#define     GUI_LOP_STRING                                      GUI_NO
#define     GUI_CLEAR_LOG_WITH_SAVE                             GUI_YES
#define     GUI_CLEAR_LOG_WITHOUT_SAVE                          GUI_NO
#define     GUI_PRIMARY_DISPLAY                                 GUI_YES
#define     GUI_SECONDARY_DISPLAY                               GUI_NO
//----------------------------------------------------------------------------
// Program limits
//----------------------------------------------------------------------------
#define     GUI_MINIMUM_NUMBER_OF_HOME_TAB_PAGES                4
#define     GUI_ONE_SECOND_INTERVAL                             1000
#define     GUI_ONE_MINUTE_INTERVAL                             60000
#define     GUI_MAXIMUM_PROGRAM_INTERVAL                        10000
#define     GUI_MINIMUM_PROGRAM_INTERVAL                        500
#define     GUI_DEFAULT_PROGRAM_INTERVAL                        1000
#define     GUI_MAXIMUM_READOUT_DECIMAL_POINTS                  7
#define     GUI_MINIMUM_READOUT_DECIMAL_POINTS                  0
#define     GUI_DEFAULT_READOUT_DECIMAL_POINTS                  4
#define     GUI_DEFAULT_FREQUENCY_DECIMAL_POINTS                3
#define     GUI_DEFAULT_VI_DECIMAL_POINTS                       2
#define     GUI_MAXIMUM_PROMPT_STRING_SIZE                      180
#define     GUI_LARGE_PROMPT_STRING_SIZE                        1024
#define     GUI_MAXIMUM_LABEL_STRING_SIZE                       256
#define     GUI_MAXIMUM_DISPLAY_STRING_SIZE                     512
#define     GUI_MAXIMUM_MODAL_TITLE_SIZE                        256
#define     GUI_MAXIMUM_VERSION_STRING_SIZE                     80
#define     GUI_MAXIMUM_CONVERT_STRING_SIZE                     128
#define     GUI_MAXIMUM_TEXT_BOX_NUMERIC_STRING_SIZE            16
#define     GUI_MAXIMUM_STATUS_LINE_SIZE                        110
#define     GUI_MAXIMUM_STATUS_LINE_PIXEL_SIZE                  556
#define     GUI_MAXIMUM_LOG_COMMENT_SIZE                        QCOM_MAXIMUM_DATA_LOG_LINE_SIZE
#define     GUI_MAXIMUM_LOG_NUMBER_OF_CAPTIONS                  16
#define     GUI_MAXIMUM_LOG_SINGLE_CAPTION_SIZE                 64
#define     GUI_MAXIMUM_LOG_CAPTION_SIZE                        (GUI_MAXIMUM_LOG_SINGLE_CAPTION_SIZE * GUI_MAXIMUM_LOG_NUMBER_OF_CAPTIONS)
#define     GUI_MAXIMUM_SEND_EVERY_INTERVAL                     20160
#define     GUI_MINIMUM_SEND_EVERY_INTERVAL                     10
#define     GUI_DEFAULT_SEND_EVERY_INTERVAL                     1440
#define     GUI_MAXIMUM_EXPERIMENT_NUMBER                       99
#define     GUI_MINIMUM_EXPERIMENT_NUMBER                       1
#define     GUI_DEFAULT_EXPERIMENT_NUMBER                       1
//----------------------------------------------------------------------------
// Window component dimensions
//
// Many of the object dimensions are relative to GUI_DEFAULT_GROUP_BOX_WIDTH
// and GUI_UNIT_GROUP_BOX_HEIGHT because the unit group boxes display the
// fundamental objects, around which all other objects must be aligned
//----------------------------------------------------------------------------
#define     GUI_DEFAULT_BUTTON_WIDTH                            122
#define     GUI_REGULAR_BUTTON_HEIGHT                           25
#define     GUI_DOUBLE_BUTTON_HEIGHT                            32
#define     GUI_LARGE_LABEL_HEIGHT                              20
#define     GUI_REGULAR_LABEL_HEIGHT                            14
#define     GUI_INFO_LABEL_HEIGHT                               16
#define     GUI_SMALL_TEXT_BOX_HEIGHT                           16
#define     GUI_REGULAR_TEXT_BOX_HEIGHT                         20
#define     GUI_REGULAR_COMBO_BOX_HEIGHT                        GUI_REGULAR_TEXT_BOX_HEIGHT
#define     GUI_LARGE_CHECK_BOX_HEIGHT                          20
#define     GUI_REGULAR_CHECK_BOX_HEIGHT                        16
#define     GUI_REGULAR_RADIO_BUTTON_HEIGHT                     16
//----------------------------------------------------------------------------
// Specific window component dimensions
//----------------------------------------------------------------------------
#define     GUI_GENERAL_GROUP_BOX_HEIGHT                        170
#define     GUI_DEFAULT_GROUP_BOX_WIDTH                         850
#define     GUI_UNIT_GROUP_BOX_HEIGHT                           165
#define     GUI_HOME_WINDOW_WIDTH                               GUI_DEFAULT_GROUP_BOX_WIDTH + 215
#define     GUI_UNIT_TAB_PAGE_WIDTH                             GUI_DEFAULT_GROUP_BOX_WIDTH + 25
#define     GUI_UNIT_TAB_PAGE_HEIGHT                            GUI_UNIT_GROUP_BOX_HEIGHT + 40
#define     GUI_HOME_TAB_PAGE_WIDTH                             GUI_DEFAULT_GROUP_BOX_WIDTH + 70
#define     GUI_HOME_TAB_PAGE_HEIGHT                            GUI_GENERAL_GROUP_BOX_HEIGHT + GUI_UNIT_GROUP_BOX_HEIGHT + 75
#define     GUI_HOME_WINDOW_HEIGHT                              GUI_HOME_TAB_PAGE_HEIGHT + 125
#define     GUI_READOUT_OBJECT_WIDTH                            90
#define     GUI_LOG_ALL_GROUP_BOX_WIDTH                         GUI_DEFAULT_GROUP_BOX_WIDTH - 20
#define     GUI_LOG_ALL_HEADER_GROUP_BOX_HEIGHT                 125
#define     GUI_LOG_ALL_UNIT_GROUP_BOX_HEIGHT                   240
#define     GUI_LOG_ALL_TAB_PAGE_WIDTH                          GUI_LOG_ALL_GROUP_BOX_WIDTH + 25
#define     GUI_LOG_ALL_TAB_PAGE_HEIGHT                         280
#define     GUI_LOG_ALL_WINDOW_WIDTH                            GUI_LOG_ALL_TAB_PAGE_WIDTH + 30
#define     GUI_LOG_ALL_WINDOW_HEIGHT                           GUI_LOG_ALL_HEADER_GROUP_BOX_HEIGHT + GUI_LOG_ALL_TAB_PAGE_HEIGHT + 120
#define     GUI_LOG_UNIT_WINDOW_WIDTH                           GUI_DEFAULT_GROUP_BOX_WIDTH + 10
#define     GUI_LOG_UNIT_WINDOW_HEIGHT                          610
#define     GUI_LOG_UNIT_BOX_HEIGHT                             300
#define     GUI_CLOSE_BUTTON_WIDTH                              75
#define     GUI_YES_NO_BUTTON_WIDTH                             40
#define     GUI_GET_SET_BUTTON_WIDTH                            30
#define     GUI_PROMPT_LABEL_HEIGHT                             17
#define     GUI_COEFFICIENT_LABEL_HEIGHT                        18
#define     GUI_HELP_LABEL_HEIGHT                               22
#define     GUI_TEST_GROUP_BOX_WIDTH                            GUI_DEFAULT_GROUP_BOX_WIDTH
#define     GUI_COEFFICIENT_DATA_WINDOW_WIDTH                   (GUI_HOME_WINDOW_WIDTH - 190)
#define     GUI_MISC_WINDOW_WIDTH                               780
#define     GUI_MISC_WINDOW_HEIGHT                              630
#define     GUI_MISC_DLL_FUNCTIONS_GROUP_BOX_WIDTH              GUI_DEFAULT_GROUP_BOX_WIDTH
#define     GUI_PROG_INFO_WINDOW_WIDTH                          910
#define     GUI_PROG_INFO_WINDOW_HEIGHT                         660
#define     GUI_PROG_INFO_GENERAL_GROUP_BOX_HEIGHT              320
#define     GUI_PF_WINDOW_WIDTH                                 820
#define     GUI_PF_WINDOW_HEIGHT                                640
#define     GUI_COMMENT_GROUP_BOX_WIDTH                         570
#define     GUI_COMMENT_GROUP_BOX_HEIGHT                        50
//----------------------------------------------------------------------------
// Graphing component dimensions
//----------------------------------------------------------------------------
#define     GUI_UNIT_GRAPH_BOX_WIDTH                            680
#define     GUI_UNIT_GRAPH_BOX_HEIGHT                           362
#define     GUI_UNIT_GRAPH_WINDOW_WIDTH                         1000
#define     GUI_UNIT_GRAPH_WINDOW_HEIGHT                        GUI_UNIT_GRAPH_BOX_HEIGHT + 236
#define     GUI_UNIT_GRAPH_BOX_LEFT_MARGIN                      22
#define     GUI_UNIT_GRAPH_BOX_RIGHT_MARGIN                     GUI_UNIT_GRAPH_BOX_WIDTH - GUI_UNIT_GRAPH_BOX_LEFT_MARGIN
#define     GUI_UNIT_GRAPH_BOX_BOTTOM_MARGIN                    GUI_UNIT_GRAPH_BOX_HEIGHT - 4
#define     GUI_UNIT_GRAPH_DATELINE_TOP                         0
#define     GUI_UNIT_GRAPH_DATELINE_HEIGHT                      18
#define     GUI_UNIT_GRAPH_DATELINE_BOTTOM                      GUI_UNIT_GRAPH_DATELINE_TOP + GUI_UNIT_GRAPH_DATELINE_HEIGHT
#define     GUI_UNIT_GRAPH_TIMELINE_HEIGHT                      GUI_UNIT_GRAPH_DATELINE_HEIGHT
#define     GUI_UNIT_GRAPH_TIMELINE_TOP                         GUI_UNIT_GRAPH_BOX_BOTTOM_MARGIN - GUI_UNIT_GRAPH_TIMELINE_HEIGHT
#define     GUI_UNIT_GRAPH_TIMELINE_MINIMUM_SEPARATION          80
#define     GUI_UNIT_GRAPH_UPPER_GRAPH_TOP                      GUI_UNIT_GRAPH_DATELINE_BOTTOM + 2
#define     GUI_UNIT_GRAPH_UPPER_GRAPH_SIZE                     200
#define     GUI_UNIT_GRAPH_UPPER_GRAPH_BOTTOM                   GUI_UNIT_GRAPH_UPPER_GRAPH_TOP + GUI_UNIT_GRAPH_UPPER_GRAPH_SIZE
#define     GUI_UNIT_GRAPH_LOWER_GRAPH_TOP                      GUI_UNIT_GRAPH_UPPER_GRAPH_BOTTOM + 20
#define     GUI_UNIT_GRAPH_LOWER_GRAPH_SIZE                     100
#define     GUI_UNIT_GRAPH_LOWER_GRAPH_BOTTOM                   GUI_UNIT_GRAPH_LOWER_GRAPH_TOP + GUI_UNIT_GRAPH_LOWER_GRAPH_SIZE
#define     GUI_UNIT_GRAPH_SINGLE_GRAPH_TOP                     GUI_UNIT_GRAPH_UPPER_GRAPH_TOP
#define     GUI_UNIT_GRAPH_SINGLE_GRAPH_SIZE                    GUI_UNIT_GRAPH_LOWER_GRAPH_BOTTOM - GUI_UNIT_GRAPH_SINGLE_GRAPH_TOP
#define     GUI_UNIT_GRAPH_SINGLE_GRAPH_BOTTOM                  GUI_UNIT_GRAPH_LOWER_GRAPH_BOTTOM
#define     GUI_UNIT_GRAPH_DEFAULT_LINE_WIDTH                   0.5F
#define     GUI_UNIT_GRAPH_THICK_LINE_WIDTH                     4.0F
//----------------------------------------------------------------------------
// Graph contexts
//----------------------------------------------------------------------------
#define     GUI_UNIT_GRAPH_CONTEXT_PRESSURE                     0
#define     GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE                  1
#define     GUI_UNIT_GRAPH_CONTEXT_AMPERAGE                     2
//----------------------------------------------------------------------------
// Multiple Coefficient Management component dimensions
//----------------------------------------------------------------------------
#define     GUI_UNIT_MULTIPLE_CF_WINDOW_WIDTH                   800
#define     GUI_UNIT_MULTIPLE_CF_WINDOW_HEIGHT_XD               384
#define     GUI_UNIT_MULTIPLE_CF_WINDOW_HEIGHT_NO_XD            210
#define     GUI_UNIT_MULTIPLE_CF_GROUP_BOX_HEIGHT               154
//----------------------------------------------------------------------------
// Error message flags
//----------------------------------------------------------------------------
#define     GUI_EMSG_INTERPRET_STATUS                           0x00000001
#define     GUI_EMSG_USE_UNIT_SN                                0x00000002
#define     GUI_EMSG_USE_TRANSDUCER_SN                          0x00000004
#define     GUI_EMSG_MUST_DISPLAY                               0x00000010
#define     GUI_EMSG_PLAY_SOUND                                 0x00000100
//----------------------------------------------------------------------------
// Tab pages
//----------------------------------------------------------------------------
#define     GUI_TAB_PAGE_READOUT                                0
#define     GUI_TAB_PAGE_UTILITIES                              1
#define     GUI_TAB_PAGE_TESTING                                2
#define     GUI_TAB_PAGE_EXPERT                                 3
//----------------------------------------------------------------------------
// Sampling and Logging timer limits and offsets
//----------------------------------------------------------------------------
#define     GUI_MAXIMUM_SAMPLING_RUN_TIME_MINUTES               30000
#define     GUI_MINIMUM_SAMPLING_RUN_TIME_MINUTES               1
#define     GUI_DEFAULT_SAMPLING_RUN_TIME_MINUTES               30
#define     GUI_INTERVAL_NUMBER_OF_UNITS                        4
#define     GUI_INTERVAL_NUMBER_OF_OFFSETS                      4
#define     GUI_INTERVAL_MINIMUM_OFFSET                         0
#define     GUI_INTERVAL_MAXIMUM_OFFSET                         1
#define     GUI_INTERVAL_DEFAULT_OFFSET                         2
#define     GUI_INTERVAL_MULTIPLIER_OFFSET                      3
#define     GUI_INTERVAL_RECENT_OFFSET                          GUI_INTERVAL_DEFAULT_OFFSET
#define     GUI_INTERVAL_MS_OFFSET                              0
#define     GUI_INTERVAL_MS_MINIMUM                             10
#define     GUI_INTERVAL_MS_MAXIMUM                             90000
#define     GUI_INTERVAL_MS_DEFAULT                             500
#define     GUI_INTERVAL_MS_MULTIPLIER                          1
#define     GUI_INTERVAL_SEC_OFFSET                             1
#define     GUI_INTERVAL_SEC_MINIMUM                            1
#define     GUI_INTERVAL_SEC_MAXIMUM                            90000
#define     GUI_INTERVAL_SEC_DEFAULT                            60
#define     GUI_INTERVAL_SEC_MULTIPLIER                         1000
#define     GUI_INTERVAL_MIN_OFFSET                             2
#define     GUI_INTERVAL_MIN_MINIMUM                            GUI_MINIMUM_SAMPLING_RUN_TIME_MINUTES
#define     GUI_INTERVAL_MIN_MAXIMUM                            GUI_MAXIMUM_SAMPLING_RUN_TIME_MINUTES
#define     GUI_INTERVAL_MIN_DEFAULT                            60
#define     GUI_INTERVAL_MIN_MULTIPLIER                         60000
#define     GUI_INTERVAL_HR_OFFSET                              3
#define     GUI_INTERVAL_HR_MINIMUM                             1
#define     GUI_INTERVAL_HR_MAXIMUM                             500
#define     GUI_INTERVAL_HR_DEFAULT                             24
#define     GUI_INTERVAL_HR_MULTIPLIER                          3600000
#define     GUI_INTERVAL_DEFAULT_UNITS                          GUI_INTERVAL_MS_OFFSET
#define     GUI_INTERVAL_DEFAULT_MINIMUM                        GUI_INTERVAL_MS_MINIMUM
#define     GUI_INTERVAL_DEFAULT_MAXIMUM                        GUI_INTERVAL_MS_MAXIMUM
#define     GUI_INTERVAL_DEFAULT_MULTIPLIER                     GUI_INTERVAL_MS_MULTIPLIER
//----------------------------------------------------------------------------
// Log action flags
//----------------------------------------------------------------------------
#define     GUI_LOG_ACTION_NO_ACTION                            0x00000000
#define     GUI_LOG_ACTION_APPEND_NEWLINE                       0x00000001
#define     GUI_LOG_ACTION_CLEAR_LOG                            0x00000002
#define     GUI_LOG_ACTION_CLEAR_DISPLAY                        0x00000004
#define     GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY                  0x00000008
#define     GUI_LOG_ACTION_REPLACE_DISPLAY                      0x00000010
#define     GUI_LOG_ACTION_PREPEND_TIME_STAMP                   0x00000020
#define     GUI_LOG_ACTION_PREVENT_TIME_STAMP                   0x00000040
#define     GUI_LOG_ACTION_RETAIN_LOG_HEADER                    0x00000080
#define     GUI_LOG_ACTION_DISPLAY_ONLY                         0x00000100
#define     GUI_LOG_ACTION_FILE_ONLY                            0x00000200
#define     GUI_LOG_ACTION_DETAILED_LOG                         0x00001000
#define     GUI_LOG_ACTION_SUMMARY_LOG                          0x00002000
#define     GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY            0x00004000
#define     GUI_LOG_ACTION_SUCCESS_TEXT                         0x00010000
#define     GUI_LOG_ACTION_BOLD_TEXT                            0x00020000
#define     GUI_LOG_ACTION_COMMENT_TEXT                         0x00100000
#define     GUI_LOG_ACTION_CAUTION_TEXT                         0x00200000
#define     GUI_LOG_ACTION_WARNING_TEXT                         0x00400000
#define     GUI_LOG_ACTION_FAILURE_TEXT                         0x00800000
#define     GUI_LOG_ACTION_COMMENT                              0x80000000
#define     GUI_LOG_ACTION_COLOR_TEXT                           (GUI_LOG_ACTION_NO_ACTION |         \
                                                                    GUI_LOG_ACTION_SUCCESS_TEXT |   \
                                                                    GUI_LOG_ACTION_BOLD_TEXT |      \
                                                                    GUI_LOG_ACTION_COMMENT_TEXT |   \
                                                                    GUI_LOG_ACTION_CAUTION_TEXT |   \
                                                                    GUI_LOG_ACTION_WARNING_TEXT |   \
                                                                    GUI_LOG_ACTION_FAILURE_TEXT |   \
                                                                    GUI_LOG_ACTION_NO_ACTION)
//----------------------------------------------------------------------------
// Please Wait values and actions
//----------------------------------------------------------------------------
#define     GUI_PLEASE_WAIT_STATE_HIDDEN                        1
#define     GUI_PLEASE_WAIT_STATE_VISIBLE                       2
#define     GUI_PLEASE_WAIT_INSTALL                             1
#define     GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE                   2
#define     GUI_PLEASE_WAIT_DISPLAY_CURRENT_TITLE               3
#define     GUI_PLEASE_WAIT_HIDE                                4
#define     GUI_PLEASE_WAIT_REMOVE                              5
#define     GUI_PLEASE_WAIT_DISPOSE                             7
//----------------------------------------------------------------------------
// Modal icon types
//----------------------------------------------------------------------------
#define     GUI_MODAL_ICON_NONE                                 0x00000000
#define     GUI_MODAL_ICON_INFORMATION                          0x00000001
#define     GUI_MODAL_ICON_WARNING                              0x00000002
#define     GUI_MODAL_ICON_ERROR                                0x00000003
#define     GUI_MODAL_ICON_CRITICAL                             0x00000004
//----------------------------------------------------------------------------
// Modal message levels
//----------------------------------------------------------------------------
#define     GUI_MODAL_BASIC                                     0x00000001
#define     GUI_MODAL_ERROR                                     0x00000002
#define     GUI_MODAL_VERBOSE                                   0x00000004
#define     GUI_MODAL_DETAILED                                  0x00000008
#define     GUI_MODAL_EXP                                       0x00000010
#define     GUI_MODAL_STACK                                     0x00000020
#define     GUI_MODAL_TEXT                                      0x00000040
#define     GUI_MODAL_EMAIL                                     0x00000080
#define     GUI_MODAL_DLL                                       0x00000100
//----------------------------------------------------------------------------
// Event log recording levels
//----------------------------------------------------------------------------
#define     GUI_ELOG_BASIC                                      0x00001000
#define     GUI_ELOG_VERBOSE                                    0x00002000
#define     GUI_ELOG_DETAILED                                   0x00004000
#define     GUI_ELOG_TEST                                       0x00008000
//----------------------------------------------------------------------------
// Software states
//----------------------------------------------------------------------------
#define     GUI_INTERVAL_ENABLED                                0x01000000
#define     GUI_EXPERIMENTS_BASIC                               0x02000000
#define     GUI_HALT_ON_ERRORS                                  0x04000000
#define     GUI_COMMAND_LINE_ONLY                               0x40000000
#define     GUI_SOFTWARE_UPDATE                                 0x80000000
//----------------------------------------------------------------------------
// Update contexts
//----------------------------------------------------------------------------
#define     GUI_UPDATE_CONTEXT_NONE                             0x00000000
#define     GUI_UPDATE_CONTEXT_GENERAL_READOUT                  0x00000001
#define     GUI_UPDATE_CONTEXT_GENERAL_UTILITIES                0x00000002
#define     GUI_UPDATE_CONTEXT_GENERAL_EXPERT                   0x00000004
#define     GUI_UPDATE_CONTEXT_GENERAL_SAMPLING                 0x00000008
#define     GUI_UPDATE_CONTEXT_GENERAL_LOGGING                  0x00000010
#define     GUI_UPDATE_CONTEXT_GENERAL_TESTING                  0x00000020
#define     GUI_UPDATE_CONTEXT_GENERAL_MISC                     0x00000040
#define     GUI_UPDATE_CONTEXT_UNIT_READOUT                     0x00010000
#define     GUI_UPDATE_CONTEXT_UNIT_UTILITIES                   0x00020000
#define     GUI_UPDATE_CONTEXT_UNIT_EXPERT                      0x00040000
#define     GUI_UPDATE_CONTEXT_UNIT_SAMPLING                    0x00080000
#define     GUI_UPDATE_CONTEXT_UNIT_LOGGING                     0x00100000
#define     GUI_UPDATE_CONTEXT_UNIT_TESTING                     0x00200000
#define     GUI_UPDATE_CONTEXT_UNIT_MISC                        0x00400000
#define     GUI_UPDATE_CONTEXT_GENERAL_ALL                      (GUI_UPDATE_CONTEXT_GENERAL_READOUT |       \
                                                                    GUI_UPDATE_CONTEXT_GENERAL_UTILITIES |  \
                                                                    GUI_UPDATE_CONTEXT_GENERAL_EXPERT |     \
                                                                    GUI_UPDATE_CONTEXT_GENERAL_SAMPLING |   \
                                                                    GUI_UPDATE_CONTEXT_GENERAL_LOGGING |    \
                                                                    GUI_UPDATE_CONTEXT_GENERAL_TESTING |    \
                                                                    GUI_UPDATE_CONTEXT_GENERAL_MISC |       \
                                                                    GUI_UPDATE_CONTEXT_NONE)
#define     GUI_UPDATE_CONTEXT_UNIT_ALL                         (GUI_UPDATE_CONTEXT_UNIT_READOUT |          \
                                                                    GUI_UPDATE_CONTEXT_UNIT_UTILITIES |     \
                                                                    GUI_UPDATE_CONTEXT_UNIT_EXPERT |        \
                                                                    GUI_UPDATE_CONTEXT_UNIT_SAMPLING |      \
                                                                    GUI_UPDATE_CONTEXT_UNIT_LOGGING |       \
                                                                    GUI_UPDATE_CONTEXT_UNIT_TESTING |       \
                                                                    GUI_UPDATE_CONTEXT_UNIT_MISC |          \
                                                                    GUI_UPDATE_CONTEXT_NONE)
#define     GUI_UPDATE_CONTEXT_ALL                              (GUI_UPDATE_CONTEXT_GENERAL_ALL |           \
                                                                    GUI_UPDATE_CONTEXT_UNIT_ALL)
//----------------------------------------------------------------------------
// Test definitions
//----------------------------------------------------------------------------
#define     GUI_MAXIMUM_TEST_LOOP_COUNT                         9999
#define     GUI_MINIMUM_TEST_LOOP_COUNT                         1
#define     GUI_DEFAULT_TEST_LOOP_COUNT                         1
#define     GUI_MAXIMUM_NUMBER_OF_QMEM_TESTS                    354
#define     GUI_NUMBER_OF_I2C_TESTS                             6
#define     GUI_NUMBER_OF_READINGS_TESTS                        5
#define     GUI_NUMBER_OF_FIRMWARE_TESTS                        7
#define     GUI_NUMBER_OF_X2_TESTS                              5
#define     GUI_NUMBER_OF_X3_TESTS                              5
#define     GUI_NUMBER_OF_X4_TESTS                              5
#define     GUI_TOTAL_NUMBER_OF_UNIT_TESTS                      (GUI_MAXIMUM_NUMBER_OF_QMEM_TESTS +         \
                                                                    GUI_NUMBER_OF_I2C_TESTS +               \
                                                                    GUI_NUMBER_OF_READINGS_TESTS +          \
                                                                    GUI_NUMBER_OF_FIRMWARE_TESTS +          \
                                                                    GUI_NUMBER_OF_X2_TESTS +                \
                                                                    GUI_NUMBER_OF_X3_TESTS +                \
                                                                    GUI_NUMBER_OF_X4_TESTS)
#define     GUI_NUMBER_OF_XD_COMM_TESTS                         5
#define     GUI_NUMBER_OF_XD_INTEGRITY_TESTS                    6
#define     GUI_MAXIMUM_NUMBER_OF_XD_MEMORY_TESTS               354
#define     GUI_TOTAL_NUMBER_OF_TRANSDUCER_TESTS                (GUI_NUMBER_OF_XD_COMM_TESTS +              \
                                                                    GUI_NUMBER_OF_XD_INTEGRITY_TESTS +      \
                                                                    GUI_MAXIMUM_NUMBER_OF_XD_MEMORY_TESTS)
#define     GUI_TOTAL_NUMBER_OF_TESTS                           (GUI_TOTAL_NUMBER_OF_TRANSDUCER_TESTS +     \
                                                                    GUI_TOTAL_NUMBER_OF_UNIT_TESTS)
//----------------------------------------------------------------------------
// File type enumeration
//----------------------------------------------------------------------------
#define     GUI_FILE_TYPE_UNKNOWN                               0
#define     GUI_FILE_TYPE_TEXT                                  1
#define     GUI_FILE_TYPE_HEX                                   2
#define     GUI_FILE_TYPE_LOG                                   3
#define     GUI_FILE_TYPE_DAT                                   4
#define     GUI_FILE_TYPE_HEX_NATIVE_REF                        5
#define     GUI_FILE_TYPE_HEX_NATIVE_ALL                        6
#define     GUI_FILE_TYPE_NATIVE_REF                            7
#define     GUI_FILE_TYPE_CSV                                   8
#define     GUI_FILE_TYPE_CONFIG                                9
#define     GUI_FILE_TYPE_BIN                                   10
#define     GUI_FILE_TYPE_EXE                                   11
#define     GUI_FILE_TYPE_ZIP                                   12
#define     GUI_FILE_TYPE_DLL                                   13
#define     GUI_FILE_TYPE_LOG_CSV                               14
#define     GUI_FILE_TYPE_COF2                                  15
#define     GUI_FILE_TYPE_PNG                                   16
#define     GUI_FILE_TYPE_PDF                                   17
//----------------------------------------------------------------------------
// File type specifications
//----------------------------------------------------------------------------
#define     GUI_FILE_SPEC_ALL                           _T("All files (*.*)|*.*|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_TEXT                          _T("Text files (*.txt)|*.txt|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_HEX                           _T("Hex files (*.hex)|*.hex|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_LOG                           _T("Log files (*.log)|*.log|Text files (*.txt)|*.txt|")         \
                                                            _T("All files (*.*)|*.*")
#define     GUI_FILE_SPEC_DAT                           _T("Data files (*.dat)|*.dat|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_HEX_NATIVE_REF                _T("Hex files (*.hex)|*.hex|")                                  \
                                                            _T("Native pressure coefficient files (*.crf)|*.crf|")      \
                                                            _T("Native temperature coefficient files (*.crt)|*.crt|")   \
                                                            _T("All files (*.*)|*.*")
#define     GUI_FILE_SPEC_HEX_NATIVE_ALL                _T("Hex files (*.hex)|*.hex|")                                  \
                                                            _T("Native (with ref) coefficient files (*.crf / *.crt)|*.cr?|")\
                                                            _T("Native (w/o ref) coefficient files (*.cff / *.cft)|*.cf?|") \
                                                            _T("All files (*.*)|*.*")
#define     GUI_FILE_SPEC_NATIVE_REF                    _T("Native pressure coefficient files (*.crf)|*.crf|")          \
                                                            _T("Native temperature coefficient files (*.crt)|*.crt|")   \
                                                            _T("Hex files (*.hex)|*.hex|")                              \
                                                            _T("All files (*.*)|*.*")
#define     GUI_FILE_SPEC_CSV                           _T("Excel-ready text files (*.csv)|*.csv|")                     \
                                                            _T("Log files (*.log)|*.log|Text files (*.txt)|*.txt|")     \
                                                            _T("All files (*.*)|*.*")
#define     GUI_FILE_SPEC_CONFIG                        _T("Config files (*.config)|*.config|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_BIN                           _T("Binary files (*.bin)|*.bin|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_EXE                           _T("Executable files (*.exe)|*.exe|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_ZIP                           _T("Compressed files (*.zip)|*.zip|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_DLL                           _T("Dynamic-link library files (*.dll)|*.dll|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_LOG_CSV                       _T("Log files (*.log)|*.log|Text files (*.txt)|*.txt|")         \
                                                            _T("Excel-ready text files (*.csv)|*.csv|")                 \
                                                            _T("All files (*.*)|*.*")
#define     GUI_FILE_SPEC_COF2                          _T("COF2 coefficient files (*.cof2)|*.cof2|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_PNG                           _T("Image files (*.png)|*.png|All files (*.*)|*.*")
#define     GUI_FILE_SPEC_PDF                           _T("PDF files (*.pdf)|*.pdf|All files (*.*)|*.*")
//----------------------------------------------------------------------------
// Drop-down button states and masks
//----------------------------------------------------------------------------
#define     GUI_DROP_DOWN_CLOSED                                0x00010000
#define     GUI_DROP_DOWN_OPENED                                0x00020000
#define     GUI_DROP_DOWN_DISPLAY_MASK                          0xFFFF0000
#define     GUI_DROP_DOWN_VERTICAL_POSITION_MASK                0x0000FFFF
//----------------------------------------------------------------------------
// Delete log files masks
//----------------------------------------------------------------------------
#define     GUI_DELETE_ZERO_MASK                                0x00000000
#define     GUI_DELETE_ALL_DATA_LOG_FILES                       0x00000001
#define     GUI_DELETE_ALL_DATA_CSV_FILES                       0x00000002
#define     GUI_DELETE_ALL_TEST_LOG_FILES                       0x00000004
#define     GUI_DELETE_ALL_EVENT_LOG_FILES                      0x00000008
#define     GUI_DELETE_ALL_ERROR_LOG_FILES                      0x00000010
#define     GUI_DELETE_ALL_SNAPSHOT_LOG_FILES                   0x00000020
#define     GUI_DELETE_ALL_SNAPSHOT_CSV_FILES                   0x00000040
#define     GUI_DELETE_ALL_LOG_FILES                            (GUI_DELETE_ZERO_MASK |                     \
                                                                    GUI_DELETE_ALL_DATA_LOG_FILES |         \
                                                                    GUI_DELETE_ALL_DATA_CSV_FILES |         \
                                                                    GUI_DELETE_ALL_TEST_LOG_FILES |         \
                                                                    GUI_DELETE_ALL_EVENT_LOG_FILES |        \
                                                                    GUI_DELETE_ALL_ERROR_LOG_FILES |        \
                                                                    GUI_DELETE_ALL_SNAPSHOT_LOG_FILES |     \
                                                                    GUI_DELETE_ALL_SNAPSHOT_CSV_FILES |     \
                                                                    GUI_DELETE_ZERO_MASK)
//----------------------------------------------------------------------------
// Key values
//----------------------------------------------------------------------------
#define     GUI_KEY_ESC                                         27
#define     GUI_KEY_SPACE                                       32
//----------------------------------------------------------------------------
// External function prototypes
//----------------------------------------------------------------------------
extern int      QCOM_CalculatePercentage(
                    DWORD           dividend,
                    DWORD           divisor);
extern char     *QCOM_ConvertString(
                    String          ^managedString,
                    char            *unmanagedString,
                    size_t          unmanagedBufferSize);
extern int      QCOM_ExtractSerialNumberFromCoefficientData(
                    CoefficientFormatDef
                                    *format,
                    char            *transducerSerialNumber);
extern System::Windows::Forms::DialogResult
                QCOM_ModalMessage(
                    bool            allow,
                    DWORD           flag,
                    String          ^titleString,
                    String          ^formatString,
                    ...array <Object ^>
                                    ^parameters);
extern char     *QCOM_FilenameContainsExtension(
                    char            *pathName,
                    char            *extension);
extern char     *QCOM_ItoA(
                    DWORD           value,
                    char            *valueString);
extern char     *QCOM_ItoX(
                    DWORD           value,
                    char            *valueString);
extern float    QCOM_ReverseFloatValue(
                    float           forwardValue);
extern DWORD    QCOM_ReverseIntegerValue(
                    DWORD           forwardValue);
extern void     QCOM_TimeElapsed(
                    DWORD           lapsedTimeMilliseconds,
                    int             *lapsedDays,
                    int             *lapsedHours,
                    int             *lapsedMinutes,
                    int             *lapsedSeconds,
                    int             *lapsedMilliseconds);
extern void     QCOM_WaitMS(
                    DWORD           ms);
//----------------------------------------------------------------------------
// Graphic file names
//----------------------------------------------------------------------------
#define     GUI_PROGRAM_ICON                    String::Concat(Application::StartupPath, _T("\\QCOM.ico"))
#define     GUI_PROGRAM_LOGO                    String::Concat(Application::StartupPath, _T("\\QCOM.png"))
#define     GUI_BG_CHALK                        String::Concat(Application::StartupPath, _T("\\QCOM-BG-Chalk.jpg"))
#define     GUI_BG_WOOD_PANEL                   String::Concat(Application::StartupPath, _T("\\QCOM-BG-LightPoplar.bmp"))
#define     GUI_BG_TOOLSTRIP                    String::Concat(Application::StartupPath, _T("\\QCOM-BG-OrangeGradient.png"))
#define     GUI_BG_GREEN_MARBLE                 String::Concat(Application::StartupPath, _T("\\QCOM-BG-GreenMarble.jpg"))
#define     GUI_BG_PINE_WOOD                    String::Concat(Application::StartupPath, _T("\\QCOM-BG-PineWood.gif"))
#define     GUI_BG_PINK_TEXTURE                 String::Concat(Application::StartupPath, _T("\\QCOM-BG-PinkTexture.jpg"))
#define     GUI_BG_STUCCO                       String::Concat(Application::StartupPath, _T("\\QCOM-BG-WhiteStucco.jpg"))
#define     GUI_BG_VIOLET_STUCCO                String::Concat(Application::StartupPath, _T("\\QCOM-BG-VioletStucco.jpg"))
#define     GUI_BG_WHITE_MARBLE                 String::Concat(Application::StartupPath, _T("\\QCOM-BG-WhiteMarble.gif"))
#define     GUI_BG_WHITE_SAND                   String::Concat(Application::StartupPath, _T("\\QCOM-BG-WhiteSand.jpg"))
#define     GUI_BG_SAND                         String::Concat(Application::StartupPath, _T("\\QCOM-BG-Sand.jpg"))
#define     GUI_BG_YELLOW_GRADIENT              String::Concat(Application::StartupPath, _T("\\QCOM-BG-YellowGradient.jpg"))
#define     GUI_PIC_EXIT_BUTTON                 String::Concat(Application::StartupPath, _T("\\QCOM-Exit-Button.png"))
#define     GUI_IMAGE_YELLOW_LED_OFF            String::Concat(Application::StartupPath, _T("\\QCOM-IMG-Yellow-LED-Off.gif"))
#define     GUI_IMAGE_YELLOW_LED_ON             String::Concat(Application::StartupPath, _T("\\QCOM-IMG-Yellow-LED-On.gif"))
#define     GUI_IMAGE_YELLOW_LED_BLINK          String::Concat(Application::StartupPath, _T("\\QCOM-IMG-Yellow-LED-Blink.gif"))
//----------------------------------------------------------------------------
// Sound file names
//----------------------------------------------------------------------------
#define     GUI_SOUND_DOWN                      String::Concat(Application::StartupPath, _T("\\QCOM-Down.wav"))
#define     GUI_SOUND_ERROR                     String::Concat(Application::StartupPath, _T("\\QCOM-Error.wav"))
#define     GUI_SOUND_OPEN                      String::Concat(Application::StartupPath, _T("\\QCOM-Open.wav"))
#define     GUI_SOUND_TADA                      String::Concat(Application::StartupPath, _T("\\QCOM-Tada.wav"))
//----------------------------------------------------------------------------
// Test result strings
//----------------------------------------------------------------------------
#define     GUI_TEST_PASSED_STRING                      _T("Passed")
#define     GUI_TEST_FAILED_STRING                      _T("Failed")
#define     GUI_TEST_INCOMPLETE_STRING                  _T("Incomplete")
#define     GUI_TEST_UNTESTED_STRING                    _T("Untested")
#define     GUI_TEST_RUNNING_STRING                     _T("Running")
#define     GUI_TEST_STOPPED_STRING                     _T("Stopped")
#define     GUI_TEST_PAUSED_STRING                      _T("Paused")
//----------------------------------------------------------------------------
// Button titles
//----------------------------------------------------------------------------
#define     GUI_START_ALL_LOGGING_STRING_1              _T("Start All Logging")
#define     GUI_STOP_ALL_LOGGING_STRING_1               _T("Stop All Logging")
#define     GUI_START_ALL_LOGGING_STRING_2              _T("Start All Units\nLogging")
#define     GUI_STOP_ALL_LOGGING_STRING_2               _T("Stop All Units\nLogging")
#define     GUI_START_LOGGING_STRING_1                  _T("Start Logging")
#define     GUI_STOP_LOGGING_STRING_1                   _T("Stop Logging")
#define     GUI_CLEAR_ALL_DATA_LOGS_1                   _T("Clear All Data Logs")
#define     GUI_CLEAR_ALL_DATA_LOGS_2                   _T("Clear All\nData Logs")
#define     GUI_SELECT_DATA_LOG_FILE                    _T("Select Data Log File")
#define     GUI_CHANGE_DATA_LOG_FILE                    _T("Change Data Log File")
#define     GUI_START_SAMPLING_STRING_1                 _T("Start Sampling")
#define     GUI_STOP_SAMPLING_STRING_1                  _T("Stop Sampling")
#define     GUI_START_SAMPLING_STRING_2                 _T("Start All Units\nSampling")
#define     GUI_STOP_SAMPLING_STRING_2                  _T("Stop All Units\nSampling")
#define     GUI_ENABLE_EXPERT_MODE_STRING               _T("Enable Expert Mode")
#define     GUI_DISABLE_EXPERT_MODE_STRING              _T("Disable Expert Mode")
#define     GUI_ELOG_ALL_START_STRING                   _T("Start Recording All Events")
#define     GUI_ELOG_ALL_STOP_STRING                    _T("Stop Recording All Events")
#define     GUI_ELOG_BASIC_START_STRING                 _T("Start Recording Basic Events")
#define     GUI_ELOG_BASIC_STOP_STRING                  _T("Stop Recording Basic Events")
#define     GUI_ELOG_VERBOSE_START_STRING               _T("Start Recording Verbose Events")
#define     GUI_ELOG_VERBOSE_STOP_STRING                _T("Stop Recording Verbose Events")
#define     GUI_ELOG_DETAILED_START_STRING              _T("Start Recording Detailed Events")
#define     GUI_ELOG_DETAILED_STOP_STRING               _T("Stop Recording Detailed Events")
#define     GUI_ELOG_TEST_START_STRING                  _T("Start Recording Test Events")
#define     GUI_ELOG_TEST_STOP_STRING                   _T("Stop Recording Test Events")
#define     GUI_TEST_ALL_UNITS_STRING                   _T("Test All Units")
#define     GUI_STOP_ALL_TESTS_STRING                   _T("Stop All Tests")
#define     GUI_RUN_SELECTED_TESTS_STRING               _T("Run Selected Tests")
#define     GUI_STOP_ALL_UNIT_TESTS_STRING              _T("Stop All Unit Tests")
#define     GUI_SELECT_TEST_RESULTS_FILE                _T("Select Results File")
#define     GUI_CHANGE_TEST_RESULTS_FILE                _T("Change Results File")
#define     GUI_ENTER_BOOT_LOADER_MODE                  _T("Enter Boot Loader Mode")
#define     GUI_RESET_BOOT_LOADER_MODE                  _T("Reset Boot Loader Mode")
#define     GUI_SWITCH_TO_DIGITAL_TRANSDUCER            _T("Digital Transducer")
#define     GUI_SWITCH_TO_FREQUENCY_TRANSDUCER          _T("Frequency Transducer")
#define     GUI_ENABLE_CONFIG_SAVE_STRING               _T("Save Config File on Exit")
#define     GUI_DISABLE_CONFIG_SAVE_STRING              _T("Don't Save Config File on Exit")
#define     GUI_ENABLE_LOGS_SAVE_STRING                 _T("Save Unsaved Log Files on Exit")
#define     GUI_DISABLE_LOGS_SAVE_STRING                _T("Don't Save Unsaved Log Files on Exit")
#define     GUI_PAUSE_OPERATIONS_STRING                 _T("Pause\nOperations")
#define     GUI_RESUME_OPERATIONS_STRING                _T("Resume\nOperations")
#define     GUI_PAUSE_ALL_STRING                        _T("Pause All")
#define     GUI_RESUME_ALL_STRING                       _T("Resume All")
//----------------------------------------------------------------------------
// Status LED strings
//----------------------------------------------------------------------------
#define     GUI_STATUS_SAMPLING_STRING                  _T("Sampling")
#define     GUI_STATUS_NOT_SAMPLING_STRING              _T("Not Sampling")
#define     GUI_STATUS_LOGGING_STRING                   _T("Logging")
#define     GUI_STATUS_NOT_LOGGING_STRING               _T("Not Logging")
#define     GUI_STATUS_TESTING_STRING                   _T("Testing")
#define     GUI_STATUS_NOT_TESTING_STRING               _T("Not Testing")
#define     GUI_STATUS_SENDING_STRING                   _T("Sending")
#define     GUI_STATUS_NOT_SENDING_STRING               _T("Not Sending")
//----------------------------------------------------------------------------
// Other strings
//----------------------------------------------------------------------------
#define     GUI_HOME_WINDOW_TITLE               _T("QCOM (Quartzdyne Transducer Communication)")
#define     GUI_PLEASE_WAIT_STRING              _T("Please wait . . .")
#define     GUI_TEXT_FILE_BORDER                String::Concat("#", gcnew String('=', 77))
#define     GUI_TEXT_FILE_HALF_BORDER           String::Concat("#", gcnew String('-', 77))
//----------------------------------------------------------------------------
// Modal macros
//----------------------------------------------------------------------------
#define     Modal(M,...)                        QCOM_DisplayModalMessage(true, GUI_MODAL_ICON_INFORMATION, FunctionName(), (M), __VA_ARGS__)
#define     ModalB(M,...)                       QCOM_DisplayModalMessage(QCOM_BasicMessagesEnabled, GUI_MODAL_ICON_WARNING, FunctionName(), (M), __VA_ARGS__)
#define     ModalD(M,...)                       QCOM_DisplayModalMessage(QCOM_DetailedMessagesEnabled, GUI_MODAL_ICON_INFORMATION, FunctionName(), (M), __VA_ARGS__)
#define     ModalE(M,...)                       QCOM_DisplayModalMessage(QCOM_ErrorMessagesEnabled, GUI_MODAL_ICON_ERROR, FunctionName(), (M), __VA_ARGS__)
#define     ModalT(T,M,...)                     QCOM_DisplayModalMessage(true, GUI_MODAL_ICON_INFORMATION, (T), (M), __VA_ARGS__)
#define     ModalV(M,...)                       QCOM_DisplayModalMessage(QCOM_VerboseMessagesEnabled, GUI_MODAL_ICON_INFORMATION, FunctionName(), (M), __VA_ARGS__)
#define     ModalX(M,...)                       QCOM_DisplayModalMessage(QCOM_ExpMessagesEnabled, GUI_MODAL_ICON_INFORMATION, FunctionName(), (M), __VA_ARGS__)
//----------------------------------------------------------------------------
// Shortcut Macros
//----------------------------------------------------------------------------
#define     GUI_DisplayHandCursorOnHover(X)     (X)->Cursor = Cursors::Hand
#define     GUI_PlaySound(S)                    ((QCOM_GeneralInfo->flags & QCOM_GENERAL_SOUNDS_ENABLED) ? (S)->Play() : (S)->Stop())
#define     QCOM_PromptModal(T,P,...)           QCOM_PromptYesNoModal((T), String::Empty, String::Empty, (P), __VA_ARGS__)
#define     QCOM_PromptOKFunction(P,...)        QCOM_PromptYesNoModal(FunctionName(), nullptr, nullptr, (P), __VA_ARGS__)
#define     QCOM_PromptOKModal(T,P,...)         QCOM_PromptYesNoModal((T), nullptr, nullptr, (P), __VA_ARGS__)
//----------------------------------------------------------------------------
// Shortcut Error Message Macros
//----------------------------------------------------------------------------
#define     GUI_DisplayErrorWithStatus(T,M,U,S)     QCOM_ErrorAlert(                    \
                                                        (T), (U), (S),                  \
                                                        (GUI_EMSG_INTERPRET_STATUS |    \
                                                         GUI_EMSG_USE_UNIT_SN |         \
                                                         GUI_EMSG_USE_TRANSDUCER_SN |   \
                                                         GUI_EMSG_PLAY_SOUND), (M))
#define     GUI_DisplayGeneralErrorWithStatus(T,M,S)                                    \
                                                    QCOM_ErrorAlert(                    \
                                                        (T), nullptr, (S),              \
                                                        (GUI_EMSG_INTERPRET_STATUS |    \
                                                         GUI_EMSG_PLAY_SOUND), (M))
#define     GUI_DisplayMandatoryError(T,M,...)      QCOM_ErrorAlert(                    \
                                                        (T), nullptr, QCOM_SUCCESS,     \
                                                        (GUI_EMSG_MUST_DISPLAY |        \
                                                        GUI_EMSG_PLAY_SOUND),           \
                                                        (M), __VA_ARGS__)
#define     GUI_DisplaySimpleError(T,M,...)         QCOM_ErrorAlert(                    \
                                                        (T), nullptr, QCOM_SUCCESS,     \
                                                        GUI_EMSG_PLAY_SOUND,            \
                                                        (M), __VA_ARGS__)
#define     GUI_DisplayTransducerError(T,M,U)       QCOM_ErrorAlert(                    \
                                                        (T), (U), QCOM_SUCCESS,         \
                                                        (GUI_EMSG_USE_UNIT_SN |         \
                                                         GUI_EMSG_USE_TRANSDUCER_SN |   \
                                                         GUI_EMSG_PLAY_SOUND), (M))
#define     GUI_DisplayUnitError(T,M,U)             QCOM_ErrorAlert(                    \
                                                        (T), (U), QCOM_SUCCESS,         \
                                                        (GUI_EMSG_USE_UNIT_SN |         \
                                                         GUI_EMSG_PLAY_SOUND), (M))
#define     GUI_DisplayUnitErrorWithStatus(T,M,U,S) QCOM_ErrorAlert(                    \
                                                        (T), (U), (S),                  \
                                                        (GUI_EMSG_INTERPRET_STATUS |    \
                                                         GUI_EMSG_USE_UNIT_SN |         \
                                                         GUI_EMSG_PLAY_SOUND), (M))
//----------------------------------------------------------------------------
// Compound macros
//----------------------------------------------------------------------------
#define     GUI_PositionBelow(thisObject,aboveObject,N)                                 \
                {                                                                       \
                    if ((thisObject) && (aboveObject))                                  \
                    {                                                                   \
                        (thisObject)->Location = Point(                                 \
                            (aboveObject)->Left, (aboveObject)->Bottom + (N));          \
                        (thisObject)->BackColor = Color::Transparent;                   \
                    }                                                                   \
                }
#define     GUI_PositionAndSizeBelow(thisObject,aboveObject,N)                          \
                {                                                                       \
                    if ((thisObject) && (aboveObject))                                  \
                    {                                                                   \
                        GUI_PositionBelow((thisObject), (aboveObject), (N));            \
                        (thisObject)->Size = (aboveObject)->Size;                       \
                    }                                                                   \
                }
#define     GUI_SetButtonInterfaceProperties(X)                                         \
                {                                                                       \
                    if (X)                                                              \
                    {                                                                   \
                        (X)->BackgroundImage = sandBackground;                          \
                        (X)->BackColor = Color::Transparent;                            \
                        GUI_DisplayHandCursorOnHover(X);                                \
                    }                                                                   \
                }
#define     GUI_SetObjectInterfaceProperties(X)                                         \
                {                                                                       \
                    if (X)                                                              \
                    {                                                                   \
                        (X)->BackColor = Color::Transparent;                            \
                        GUI_DisplayHandCursorOnHover(X);                                \
                    }                                                                   \
                }
#define     GUI_SetUnitButtonInterfaceProperties(X,U)                                   \
                {                                                                       \
                    if (X)                                                              \
                    {                                                                   \
                        (X)->Tag = (U);                                                 \
                        GUI_SetButtonInterfaceProperties(X);                            \
                    }                                                                   \
                }
#define     GUI_SetUnitObjectInterfaceProperties(X,U)                                   \
                {                                                                       \
                    if (X)                                                              \
                    {                                                                   \
                        (X)->Tag = (U);                                                 \
                        GUI_SetObjectInterfaceProperties(X);                            \
                    }                                                                   \
                }
#define     GUI_StringToBuilder(S,B)                                                    \
                {                                                                       \
                    if (StringSet(S) && (B))                                            \
                    {                                                                   \
                        (B)->Clear();                                                   \
                        (B)->Insert(0, (S));                                            \
                    }                                                                   \
                }
//----------------------------------------------------------------------------
// Structures
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// External global variables
//----------------------------------------------------------------------------
extern int      QCOM_AlternatePressureUnits;
extern int      QCOM_AlternateTemperatureUnits;
extern bool     QCOM_BasicMessagesEnabled;
extern DWORD    QCOM_BuildNumber;
extern bool     QCOM_CommandLineOnly;
extern DWORD    QCOM_CurrentExperimentNumber;
extern DWORD    QCOM_CurrentIntervalUnitsArray[GUI_INTERVAL_NUMBER_OF_UNITS][GUI_INTERVAL_NUMBER_OF_OFFSETS];
extern DWORD    QCOM_CurrentIntervalUnitsOffset;
extern bool     QCOM_CurrentlyEventLogging;
extern DWORD    QCOM_CurrentNumberOfUnits;
extern BYTE     QCOM_CurrentPagesPerMemorySlot;
extern DWORD    QCOM_CurrentPrecision;
extern int      QCOM_CurrentPressureUnits;
extern DWORD    QCOM_CurrentProgramInterval;
extern DWORD    QCOM_CurrentSamplingInterval;
extern DWORD    QCOM_CurrentSendEveryInterval[QCOM_MAXIMUM_NUMBER_OF_UNITS];
extern DWORD    QCOM_CurrentSendEveryIntervalRemaining[QCOM_MAXIMUM_NUMBER_OF_UNITS];
extern int      QCOM_CurrentTemperatureUnits;
extern int      QCOM_DefaultPressureUnits;
extern int      QCOM_DefaultTemperatureUnits;
extern bool     QCOM_DetailedMessagesEnabled;
extern bool     QCOM_ErrorMessagesEnabled;
extern bool     QCOM_EventLogBasicEnabled;
extern bool     QCOM_EventLogDetailedEnabled;
extern bool     QCOM_EventLogTestEnabled;
extern bool     QCOM_EventLogVerboseEnabled;
extern bool     QCOM_ExperimentsEnabled;
extern bool     QCOM_ExpMessagesEnabled;
extern int      QCOM_FormerPressureUnits;
extern int      QCOM_FormerTemperatureUnits;
extern bool     QCOM_HaltOperationsOnErrors;
extern DWORD    QCOM_LoggingElapsedTime;
extern DWORD    QCOM_LoggingStartTime;
extern DWORD    QCOM_MaximumSamplingRunTimeMinutes;
extern DWORD    QCOM_ModalKeyStroke;
extern bool     QCOM_ModuleShouldApplyTransducerPower[QCOM_MAXIMUM_NUMBER_OF_UNITS];
extern BYTE     QCOM_OriginalTransducerType[QCOM_MAXIMUM_NUMBER_OF_UNITS];
extern DWORD    QCOM_PauseTime;
extern double   QCOM_PressureUnitsPerPSI[];
extern bool     QCOM_ProgramIntervalEnabled;
extern bool     QCOM_ReadyToMarkLoggingTime[QCOM_MAXIMUM_NUMBER_OF_UNITS];
extern bool     QCOM_ReadyToMarkSampleTime;
extern bool     QCOM_ReadyToMarkTestingTime[QCOM_MAXIMUM_NUMBER_OF_UNITS];
extern double   QCOM_RealTimeWeightCalibration;
extern double   QCOM_RealTimeWeightMultiplier;
extern bool     QCOM_RealTimeWeightWindowOpen;
extern DWORD    QCOM_SamplingElapsedTime;
extern DWORD    QCOM_SamplingStartTime;
extern bool     QCOM_SendEmailErrorMessagesEnabled;
extern bool     QCOM_SendTextErrorMessagesEnabled;
extern bool     QCOM_SoftwareUpdateInProgress;
extern bool     QCOM_StackTracesEnabled;
extern DWORD    QCOM_StartTime;
extern DWORD    QCOM_TestLoopCount;
extern bool     QCOM_VerboseMessagesEnabled;
extern DWORD    QCOM_WindowsVersion;
//----------------------------------------------------------------------------
// The following lines are only seen by GUI.cpp
//----------------------------------------------------------------------------
#ifdef      GUI_CPP
//----------------------------------------------------------------------------
// Internal global variables
//----------------------------------------------------------------------------
int             QCOM_AlternatePressureUnits = QCOM_PRESSURE_UNITS_ALT_DEFAULT;
int             QCOM_AlternateTemperatureUnits = QCOM_TEMPERATURE_UNITS_ALT_DEFAULT;
DWORD           QCOM_CurrentExperimentNumber = GUI_DEFAULT_EXPERIMENT_NUMBER;
DWORD           QCOM_CurrentIntervalUnitsArray[][GUI_INTERVAL_NUMBER_OF_OFFSETS] =
                    {
                        { GUI_INTERVAL_MS_MINIMUM, GUI_INTERVAL_MS_MAXIMUM, GUI_INTERVAL_MS_DEFAULT, GUI_INTERVAL_MS_MULTIPLIER },
                        { GUI_INTERVAL_SEC_MINIMUM, GUI_INTERVAL_SEC_MAXIMUM, GUI_INTERVAL_SEC_DEFAULT, GUI_INTERVAL_SEC_MULTIPLIER },
                        { GUI_INTERVAL_MIN_MINIMUM, GUI_INTERVAL_MIN_MAXIMUM, GUI_INTERVAL_MIN_DEFAULT, GUI_INTERVAL_MIN_MULTIPLIER },
                        { GUI_INTERVAL_HR_MINIMUM, GUI_INTERVAL_HR_MAXIMUM, GUI_INTERVAL_HR_DEFAULT, GUI_INTERVAL_HR_MULTIPLIER }
                    };
DWORD           QCOM_CurrentIntervalUnitsOffset = GUI_INTERVAL_DEFAULT_UNITS;
bool            QCOM_CurrentlyEventLogging = GUI_NO;
BYTE            QCOM_CurrentPagesPerMemorySlot = QCOM_DEFAULT_PAGES_PER_MEMORY_SLOT;
DWORD           QCOM_CurrentPrecision = GUI_DEFAULT_READOUT_DECIMAL_POINTS;
int             QCOM_CurrentPressureUnits = QCOM_PRESSURE_UNITS_DEFAULT;
DWORD           QCOM_CurrentProgramInterval = GUI_DEFAULT_PROGRAM_INTERVAL;
DWORD           QCOM_CurrentSamplingInterval = QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_DEFAULT_OFFSET];
DWORD           QCOM_CurrentSendEveryInterval[QCOM_MAXIMUM_NUMBER_OF_UNITS];
DWORD           QCOM_CurrentSendEveryIntervalRemaining[QCOM_MAXIMUM_NUMBER_OF_UNITS];
int             QCOM_CurrentTemperatureUnits = QCOM_TEMPERATURE_UNITS_DEFAULT;
int             QCOM_DefaultPressureUnits = QCOM_PRESSURE_UNITS_DEFAULT;
int             QCOM_DefaultTemperatureUnits = QCOM_TEMPERATURE_UNITS_DEFAULT;
int             QCOM_FormerPressureUnits = QCOM_PRESSURE_UNITS_DEFAULT;
int             QCOM_FormerTemperatureUnits = QCOM_TEMPERATURE_UNITS_DEFAULT;
DWORD           QCOM_LoggingElapsedTime = 0;
DWORD           QCOM_LoggingStartTime = 0;
DWORD           QCOM_MaximumSamplingRunTimeMinutes = GUI_DEFAULT_SAMPLING_RUN_TIME_MINUTES;
DWORD           QCOM_ModalKeyStroke = 0;
bool            QCOM_ModuleShouldApplyTransducerPower[QCOM_MAXIMUM_NUMBER_OF_UNITS];
BYTE            QCOM_OriginalTransducerType[QCOM_MAXIMUM_NUMBER_OF_UNITS];
DWORD           QCOM_PauseTime = 0;
double          QCOM_PressureUnitsPerPSI[] =
                    {
                        1.0,
                        QCOM_BAR_PER_PSI,
                        QCOM_MBAR_PER_PSI,
                        QCOM_PA_PER_PSI,
                        QCOM_KPA_PER_PSI,
                        QCOM_MPA_PER_PSI,
                        QCOM_HPA_PER_PSI,
                        QCOM_MMHG_PER_PSI,
                        QCOM_INHG_PER_PSI,
                        QCOM_MH2O_PER_PSI,
                        QCOM_INH2O_PER_PSI,
                        QCOM_ATM_PER_PSI,
                        QCOM_TORR_PER_PSI,
                        QCOM_DCM2_PER_PSI,
                        QCOM_MSW_PER_PSI
                    };
bool            QCOM_ReadyToMarkLoggingTime[QCOM_MAXIMUM_NUMBER_OF_UNITS];
bool            QCOM_ReadyToMarkSampleTime = GUI_NO;
bool            QCOM_ReadyToMarkTestingTime[QCOM_MAXIMUM_NUMBER_OF_UNITS];
double          QCOM_RealTimeWeightCalibration = 0.0;
double          QCOM_RealTimeWeightMultiplier = 1.0;
bool            QCOM_RealTimeWeightWindowOpen = GUI_NO;
DWORD           QCOM_SamplingElapsedTime = 0;
DWORD           QCOM_SamplingStartTime = 0;
DWORD           QCOM_TestLoopCount = GUI_DEFAULT_TEST_LOOP_COUNT;
//----------------------------------------------------------------------------
// End of the lines that are only seen by GUI.cpp
//----------------------------------------------------------------------------
#endif      // GUI_CPP
#endif      // GUI_H
//============================================================================
// End of GUI.h
//============================================================================
