//============================================================================
// GraphEvents.cpp
//
// The event methods used by Logging.cpp for data log-related tasks
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     GRAPHEVENTS_CPP
#define     GRAPHEVENTS_CPP
#include    "GraphEvents.h"
//----------------------------------------------------------------------------
// QCOM_GraphingClearGraphButtonClicked
//
// Event that clears the graph boxes in the Graphing window
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingClearGraphButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingClearGraphButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        QCOM_GraphingClearGraph(QCOM_UnitInfoArray[unitNumber]);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_GraphingClearGraphButtonClicked()
//----------------------------------------------------------------------------
// QCOM_GraphingCloseWindow
//
// Event that closes the unit Graphing window by hiding it
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingCloseWindow");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Graphing window closed for module {0}",
            unit->moduleSerialNumber);
        graphingWindowArray[unitNumber]->Hide();
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_GraphingCloseWindow()
//----------------------------------------------------------------------------
// QCOM_GraphingClosingWindow
//
// Handles the closing of the unit graphing window by the red X or similar
// method
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Form ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingClosingWindow");
    //------------------------------------------------------------------------
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Graphing window closing for module {0}",
            unit->moduleSerialNumber);
        graphingWindowArray[unitNumber]->Hide();
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_GraphingClosingWindow()
//----------------------------------------------------------------------------
// QCOM_GraphingDisplayAmperageDrawChecked
//
// Event that handles the check of the Display Current Draw box in the
// specified Graphing window
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingDisplayAmperageDrawChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingDisplayAmperageDrawChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if (unit->graphingFlags & QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW)
            unit->graphingFlags &= ~QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW;
        else
            unit->graphingFlags |= QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW;
        graphingDisplayAmperageDrawCheckArray[unitNumber]->Checked =
            (unit->graphingFlags & QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW) ?
                GUI_YES : GUI_NO;
        RecordBasicEvent(
            "    Display current draw {0} for transducer {1} on module {2}",
            ((unit->graphingFlags & QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW) ? "checked" : "un-checked"),
            unit->transducerSerialNumber,
            unit->moduleSerialNumber);
        if (unit->graphingFlags & QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW)
        {
            graphingAmperageLabelArray[unitNumber]->Visible = GUI_YES;
            graphingAmperageUnitsLabelArray[unitNumber]->Visible = GUI_YES;
            graphingAmperageValueLabelArray[unitNumber]->Visible = GUI_YES;
            graphingAmperageHighBoundaryLabelArray[unitNumber]->Visible = GUI_YES;
            graphingAmperageHighBoundaryBoxArray[unitNumber]->Visible = GUI_YES;
            graphingAmperageHighBoundaryUnitsLabelArray[unitNumber]->Visible = GUI_YES;
            graphingAmperageLowBoundaryLabelArray[unitNumber]->Visible = GUI_YES;
            graphingAmperageLowBoundaryBoxArray[unitNumber]->Visible = GUI_YES;
            graphingAmperageLowBoundaryUnitsLabelArray[unitNumber]->Visible = GUI_YES;
            graphingSuperimposePressureTemperatureCheckArray[unitNumber]->Enabled = GUI_NO;
            unit->dataLogPoints |= QCOM_UNIT_LOG_XD_AMPERAGE;
            logUnitTransducerAmperageCheckArray[unitNumber]->Checked = GUI_YES;
        }
        else
        {
            graphingAmperageLabelArray[unitNumber]->Visible = GUI_NO;
            graphingAmperageUnitsLabelArray[unitNumber]->Visible = GUI_NO;
            graphingAmperageValueLabelArray[unitNumber]->Visible = GUI_NO;
            graphingAmperageHighBoundaryLabelArray[unitNumber]->Visible = GUI_NO;
            graphingAmperageHighBoundaryBoxArray[unitNumber]->Visible = GUI_NO;
            graphingAmperageHighBoundaryUnitsLabelArray[unitNumber]->Visible = GUI_NO;
            graphingAmperageLowBoundaryLabelArray[unitNumber]->Visible = GUI_NO;
            graphingAmperageLowBoundaryBoxArray[unitNumber]->Visible = GUI_NO;
            graphingAmperageLowBoundaryUnitsLabelArray[unitNumber]->Visible = GUI_NO;
            graphingSuperimposePressureTemperatureCheckArray[unitNumber]->Enabled = GUI_YES;
            unit->dataLogPoints &= ~QCOM_UNIT_LOG_XD_AMPERAGE;
            logUnitTransducerAmperageCheckArray[unitNumber]->Checked = GUI_NO;
        }
        QCOM_LogUnitUpdateCaptions(unit);
        QCOM_GraphingSetGraphingThresholds(unit);
        QCOM_GraphingClearGraph(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_GraphingDisplayAmperageDrawChecked()
//----------------------------------------------------------------------------
// QCOM_GraphingMilitaryTimeFormatChecked
//
// Event that handles the check of the Military Time box in the specified
// Graphing window
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingMilitaryTimeFormatChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingMilitaryTimeFormatChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if (unit->graphingFlags & QCOM_UNIT_GRAPH_MILITARY_TIME_FORMAT)
            unit->graphingFlags &= ~QCOM_UNIT_GRAPH_MILITARY_TIME_FORMAT;
        else
            unit->graphingFlags |= QCOM_UNIT_GRAPH_MILITARY_TIME_FORMAT;
        graphingMilitaryTimeFormatCheckArray[unitNumber]->Checked =
            (unit->graphingFlags & QCOM_UNIT_GRAPH_MILITARY_TIME_FORMAT) ?
                GUI_YES : GUI_NO;
        unit->graphingGraphChanged = GUI_YES;
        RecordBasicEvent(
            "    Military time format {0} for transducer {1} on module {2}",
            ((unit->graphingFlags & QCOM_UNIT_GRAPH_MILITARY_TIME_FORMAT) ? "checked" : "un-checked"),
            unit->transducerSerialNumber,
            unit->moduleSerialNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_GraphingMilitaryTimeFormatChecked()
//----------------------------------------------------------------------------
// QCOM_GraphingPictureBoxClicked
//
// Event that handles the click of the Picture Box for the specified unit by
// prompting to save only a .png copy of the image
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingPictureBoxClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            proceedToSaveFile = GUI_YES;
    DWORD           unitNumber = (DWORD) (dynamic_cast <PictureBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingPictureBoxClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if (graphingPictureBoxArray[unitNumber]->Image)
        {
            String ^pathString;
            int fileInstance = 1;
            DateTime dateTime = DateTime::Now;
            do
            {
                String ^fileString = String::Format(
                    "QCOM-Graph-{0}-{1}-{2:D2}{3:D2}{4:D2}-{5:D3}.png",
                    unit->moduleSerialNumber,
                    unit->transducerSerialNumber,
                    (dateTime.Year % 100),
                    dateTime.Month,
                    dateTime.Day,
                    fileInstance);
                pathString = String::Concat(
                    QCOM_GeneralInfo->logDirectory,
                    "\\",
                    fileString);
                if (File::Exists(pathString))
                    fileInstance++;
            }
            while (File::Exists(pathString));
            String ^savePromptString = String::Concat(
                "Save graph image for ",
                unit->transducerSerialNumber,
                " on ",
                unit->moduleSerialNumber);
            StringBuilder ^imagePathBuilder = gcnew StringBuilder(pathString);
            proceedToSaveFile = QCOM_PromptForSaveFile(
                savePromptString,
                imagePathBuilder,
                pathString,
                GUI_FILE_TYPE_PNG);
            pathString = imagePathBuilder->ToString();
            delete imagePathBuilder;
            if (proceedToSaveFile)
            {
                Bitmap ^graphingPictureBoxImage = gcnew Bitmap(
                    graphingPictureBoxArray[unitNumber]->Width,
                    graphingPictureBoxArray[unitNumber]->Height);
                Graphics ^graphingGraph = Graphics::FromImage(graphingPictureBoxImage);
                graphingGraph->DrawImage(graphingPictureBoxArray[unitNumber]->Image, 0, 0);
                graphingPictureBoxImage->Save(pathString);
                delete graphingGraph;
                RecordBasicEvent(
                    "    Graph image file saved as {0}", pathString);
            }
            delete savePromptString;
        }                               // end of if (graphingPictureBoxArray[unitNumber]->Image)
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_GraphingPictureBoxClicked()
//----------------------------------------------------------------------------
// QCOM_GraphingSaveGraphButtonClicked
//
// Event that saves or prints the graph in the Graphing window
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingSaveGraphButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingSaveGraphButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        QCOM_GraphingSaveGraph(QCOM_UnitInfoArray[unitNumber]);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_GraphingSaveGraphButtonClicked()
//----------------------------------------------------------------------------
// QCOM_GraphingSetDefaultBoundaryValuesButtonClicked
//
// Handles the click of the readout unit Set Default Boundary Values button
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingSetDefaultBoundaryValuesButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingSetDefaultBoundaryValuesButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_GraphingSetDefaultBoundaryValues(unit);
        QCOM_GraphingReflectBoundaryValues(unit);
        QCOM_GraphingClearGraph(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_GraphingSetDefaultBoundaryValuesButtonClicked()
//----------------------------------------------------------------------------
// QCOM_GraphingSingleStepButtonClicked
//
// Event that handles the click of the Single Step button in the specified
// Graphing window
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingSingleStepButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingSingleStepButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if (unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING)
        {
            QCOM_StartStopSamplingUnit(unit);
            QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
        }
        DWORD status = QCOM_RetrieveTransducerReadings(unit);
        if (status == QCOM_SUCCESS)
        {
            QCOM_UpdateReadout(unit);
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_GraphingSingleStepButtonClicked()
//----------------------------------------------------------------------------
// QCOM_GraphingSuperimposePressureTemperatureChecked
//
// Event that handles the click of the Superimpose Pressure Temperature box in
// the Graphing window
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingSuperimposePressureTemperatureChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingSuperimposePressureTemperatureChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if (unit->graphingFlags & QCOM_UNIT_GRAPH_SUPERIMPOSE_PT)
            unit->graphingFlags &= ~QCOM_UNIT_GRAPH_SUPERIMPOSE_PT;
        else
            unit->graphingFlags |= QCOM_UNIT_GRAPH_SUPERIMPOSE_PT;
        graphingSuperimposePressureTemperatureCheckArray[unitNumber]->Checked =
            (unit->graphingFlags & QCOM_UNIT_GRAPH_SUPERIMPOSE_PT) ?
                GUI_YES : GUI_NO;
        QCOM_GraphingSetGraphingThresholds(unit);
        QCOM_GraphingClearGraph(unit);
        RecordBasicEvent(
            "    Superimpose Pressure and Temperature {0} for transducer {1} on module {2}",
            ((unit->graphingFlags & QCOM_UNIT_GRAPH_SUPERIMPOSE_PT) ? "checked" : "un-checked"),
            unit->transducerSerialNumber,
            unit->moduleSerialNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_GraphingSuperimposePressureTemperatureChecked()
//----------------------------------------------------------------------------
// QCOM_GraphingUseThickLinesChecked
//
// Event that handles the check of the Use Thick Lines box in the specified
// Graphing window
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingUseThickLinesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingUseThickLinesChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if (unit->graphingFlags & QCOM_UNIT_GRAPH_THICK_LINES)
            unit->graphingFlags &= ~QCOM_UNIT_GRAPH_THICK_LINES;
        else
            unit->graphingFlags |= QCOM_UNIT_GRAPH_THICK_LINES;
        graphingUseThickLinesCheckArray[unitNumber]->Checked =
            (unit->graphingFlags & QCOM_UNIT_GRAPH_THICK_LINES) ?
                GUI_YES : GUI_NO;
        RecordBasicEvent(
            "    Thick-line graphs {0} for transducer {1} on module {2}",
            ((unit->graphingFlags & QCOM_UNIT_GRAPH_THICK_LINES) ? "checked" : "un-checked"),
            unit->transducerSerialNumber,
            unit->moduleSerialNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_GraphingUseThickLinesChecked()
//----------------------------------------------------------------------------
// QCOM_GraphingValidateAmperageHighBoundaryValue
//
// Validates the Current high boundary text box
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingValidateAmperageHighBoundaryValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <TextBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingValidateAmperageHighBoundaryValue");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if (StringSet(graphingAmperageHighBoundaryBoxArray[unitNumber]->Text))
        {
            double newBoundary = Convert::ToDouble(graphingAmperageHighBoundaryBoxArray[unitNumber]->Text);
            double newDefaultBoundary = QCOM_GraphingConvertToDefaultUnits(newBoundary, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE);
            double lowBoundary = Convert::ToDouble(graphingAmperageLowBoundaryBoxArray[unitNumber]->Text);
            if (newBoundary <= lowBoundary)
            {
                //------------------------------------------------------------
                // Force the Low value to be 1/10 of the new High value
                //------------------------------------------------------------
                lowBoundary = newBoundary * 0.1;
                RecordBasicEvent(
                    "    A conflict in boundary values forced a change in the Current Low Boundary from {0:F4} to {1:F4} {2}",
                    QCOM_GraphingConvertToCurrentUnits(unit->graphingAmperageLowBoundarymA, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE),
                    lowBoundary,
                    QCOM_AmperageUnitsStringArray[QCOM_AMPERAGE_UNITS_DEFAULT]);
                unit->graphingAmperageLowBoundarymA =
                    QCOM_GraphingConvertToDefaultUnits(lowBoundary, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE);
                graphingAmperageLowBoundaryBoxArray[unitNumber]->Text = String::Format(
                    "{0:F4}", lowBoundary);
            }
            if (newDefaultBoundary != unit->graphingAmperageHighBoundarymA)
            {
                RecordBasicEvent(
                    "    The Current High Boundary changed from {0:F4} to {1:F4} {2}",
                    QCOM_GraphingConvertToCurrentUnits(unit->graphingAmperageHighBoundarymA, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE),
                    newBoundary,
                    QCOM_AmperageUnitsStringArray[QCOM_AMPERAGE_UNITS_DEFAULT]);
                unit->graphingAmperageHighBoundarymA = newDefaultBoundary;
                QCOM_GraphingClearGraph(unit);
                graphingAmperageHighBoundaryBoxArray[unitNumber]->Text = String::Format(
                    "{0:F4}", newBoundary);
            }
            evt->Cancel = GUI_NO;
            RecordBasicEvent("{0} concluded: Accept {1:F4}",
                functionName, newBoundary);
            return;
        }                                   // end of if (StringSet(graphingAmperageHighBoundaryBoxArray[unitNumber]->Text))
        else
        {
            graphingAmperageHighBoundaryBoxArray[unitNumber]->Text = String::Format(
                "{0:F4}",
                QCOM_GraphingConvertToCurrentUnits(unit->graphingAmperageHighBoundarymA, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE));
        }
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_GraphingValidateAmperageHighBoundaryValue()
//----------------------------------------------------------------------------
// QCOM_GraphingValidateAmperageLowBoundaryValue
//
// Validates the Current low boundary text box
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingValidateAmperageLowBoundaryValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <TextBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingValidateAmperageLowBoundaryValue");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if (StringSet(graphingAmperageLowBoundaryBoxArray[unitNumber]->Text))
        {
            double newBoundary = Convert::ToDouble(graphingAmperageLowBoundaryBoxArray[unitNumber]->Text);
            double newDefaultBoundary = QCOM_GraphingConvertToDefaultUnits(newBoundary, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE);
            double highBoundary = Convert::ToDouble(graphingAmperageHighBoundaryBoxArray[unitNumber]->Text);
            if (newBoundary >= highBoundary)
            {
                //------------------------------------------------------------
                // Force the High value to be 10 times the new Low value
                //------------------------------------------------------------
                highBoundary = newBoundary * 10.0;
                RecordBasicEvent(
                    "    A conflict in boundary values forced a change in the Current High Boundary from {0:F4} to {1:F4} {2}",
                    QCOM_GraphingConvertToCurrentUnits(unit->graphingAmperageHighBoundarymA, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE),
                    highBoundary,
                    QCOM_AmperageUnitsStringArray[QCOM_AMPERAGE_UNITS_DEFAULT]);
                unit->graphingAmperageHighBoundarymA =
                    QCOM_GraphingConvertToDefaultUnits(highBoundary, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE);
                graphingAmperageHighBoundaryBoxArray[unitNumber]->Text = String::Format(
                    "{0:F4}", highBoundary);
            }
            if (newDefaultBoundary != unit->graphingAmperageLowBoundarymA)
            {
                RecordBasicEvent(
                    "    The Current Low Boundary changed from {0:F4} to {1:F4} {2}",
                    QCOM_GraphingConvertToCurrentUnits(unit->graphingAmperageLowBoundarymA, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE),
                    newBoundary,
                    QCOM_AmperageUnitsStringArray[QCOM_AMPERAGE_UNITS_DEFAULT]);
                unit->graphingAmperageLowBoundarymA = newDefaultBoundary;
                QCOM_GraphingClearGraph(unit);
                graphingAmperageLowBoundaryBoxArray[unitNumber]->Text = String::Format(
                    "{0:F4}", newBoundary);
            }
            evt->Cancel = GUI_NO;
            RecordBasicEvent("{0} concluded: Accept {1:F4}",
                functionName, newBoundary);
            return;
        }                                   // end of if (StringSet(graphingAmperageLowBoundaryBoxArray[unitNumber]->Text))
        else
        {
            graphingAmperageLowBoundaryBoxArray[unitNumber]->Text = String::Format(
                "{0:F4}",
                QCOM_GraphingConvertToCurrentUnits(unit->graphingAmperageLowBoundarymA, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE));
        }
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_GraphingValidateAmperageLowBoundaryValue()
//----------------------------------------------------------------------------
// QCOM_GraphingValidatePressureHighBoundaryValue
//
// Validates the Pressure high boundary text box
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingValidatePressureHighBoundaryValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <TextBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingValidatePressureHighBoundaryValue");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if (StringSet(graphingPressureHighBoundaryBoxArray[unitNumber]->Text))
        {
            double newBoundary = Convert::ToDouble(graphingPressureHighBoundaryBoxArray[unitNumber]->Text);
            double newDefaultBoundary = QCOM_GraphingConvertToDefaultUnits(newBoundary, GUI_UNIT_GRAPH_CONTEXT_PRESSURE);
            double lowBoundary = Convert::ToDouble(graphingPressureLowBoundaryBoxArray[unitNumber]->Text);
            if (newBoundary <= lowBoundary)
            {
                //------------------------------------------------------------
                // Force the Low value to be 1/10 of the new High value
                //------------------------------------------------------------
                lowBoundary = newBoundary * 0.1;
                RecordBasicEvent(
                    "    A conflict in boundary values forced a change in the Pressure Low Boundary from {0:F4} to {1:F4} {2}",
                    QCOM_GraphingConvertToCurrentUnits(unit->graphingPressureLowBoundaryPSI, GUI_UNIT_GRAPH_CONTEXT_PRESSURE),
                    lowBoundary,
                    QCOM_PressureUnitsStringArray[QCOM_CurrentPressureUnits]);
                unit->graphingPressureLowBoundaryPSI =
                    QCOM_GraphingConvertToDefaultUnits(lowBoundary, GUI_UNIT_GRAPH_CONTEXT_PRESSURE);
                graphingPressureLowBoundaryBoxArray[unitNumber]->Text = String::Format(
                    "{0:F4}", lowBoundary);
            }
            if (newDefaultBoundary != unit->graphingPressureHighBoundaryPSI)
            {
                RecordBasicEvent(
                    "    The Pressure High Boundary changed from {0:F4} to {1:F4} {2}",
                    QCOM_GraphingConvertToCurrentUnits(unit->graphingPressureHighBoundaryPSI, GUI_UNIT_GRAPH_CONTEXT_PRESSURE),
                    newBoundary,
                    QCOM_PressureUnitsStringArray[QCOM_CurrentPressureUnits]);
                unit->graphingPressureHighBoundaryPSI = newDefaultBoundary;
                QCOM_GraphingClearGraph(unit);
                graphingPressureHighBoundaryBoxArray[unitNumber]->Text = String::Format(
                    "{0:F4}", newBoundary);
            }
            evt->Cancel = GUI_NO;
            RecordBasicEvent("{0} concluded: Accept {1:F4}",
                functionName, newBoundary);
            return;
        }                                   // end of if (StringSet(graphingPressureHighBoundaryBoxArray[unitNumber]->Text))
        else
        {
            graphingPressureHighBoundaryBoxArray[unitNumber]->Text = String::Format(
                "{0:F4}",
                QCOM_GraphingConvertToCurrentUnits(unit->graphingPressureHighBoundaryPSI, GUI_UNIT_GRAPH_CONTEXT_PRESSURE));
        }
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_GraphingValidatePressureHighBoundaryValue()
//----------------------------------------------------------------------------
// QCOM_GraphingValidatePressureLowBoundaryValue
//
// Validates the Pressure low boundary text box
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingValidatePressureLowBoundaryValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <TextBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingValidatePressureLowBoundaryValue");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if (StringSet(graphingPressureLowBoundaryBoxArray[unitNumber]->Text))
        {
            double newBoundary = Convert::ToDouble(graphingPressureLowBoundaryBoxArray[unitNumber]->Text);
            double newDefaultBoundary = QCOM_GraphingConvertToDefaultUnits(newBoundary, GUI_UNIT_GRAPH_CONTEXT_PRESSURE);
            double highBoundary = Convert::ToDouble(graphingPressureHighBoundaryBoxArray[unitNumber]->Text);
            if (newBoundary >= highBoundary)
            {
                //------------------------------------------------------------
                // Force the High value to be 10 times the new Low value
                //------------------------------------------------------------
                highBoundary = newBoundary * 10.0;
                RecordBasicEvent(
                    "    A conflict in boundary values forced a change in the Pressure High Boundary from {0:F4} to {1:F4} {2}",
                    QCOM_GraphingConvertToCurrentUnits(unit->graphingPressureHighBoundaryPSI, GUI_UNIT_GRAPH_CONTEXT_PRESSURE),
                    highBoundary,
                    QCOM_PressureUnitsStringArray[QCOM_CurrentPressureUnits]);
                unit->graphingPressureHighBoundaryPSI =
                    QCOM_GraphingConvertToDefaultUnits(highBoundary, GUI_UNIT_GRAPH_CONTEXT_PRESSURE);
                graphingPressureHighBoundaryBoxArray[unitNumber]->Text = String::Format(
                    "{0:F4}", highBoundary);
            }
            if (newDefaultBoundary != unit->graphingPressureLowBoundaryPSI)
            {
                RecordBasicEvent(
                    "    The Pressure Low Boundary changed from {0:F4} to {1:F4} {2}",
                    QCOM_GraphingConvertToCurrentUnits(unit->graphingPressureLowBoundaryPSI, GUI_UNIT_GRAPH_CONTEXT_PRESSURE),
                    newBoundary,
                    QCOM_PressureUnitsStringArray[QCOM_CurrentPressureUnits]);
                unit->graphingPressureLowBoundaryPSI = newDefaultBoundary;
                QCOM_GraphingClearGraph(unit);
                graphingPressureLowBoundaryBoxArray[unitNumber]->Text = String::Format(
                    "{0:F4}", newBoundary);
            }
            evt->Cancel = GUI_NO;
            RecordBasicEvent("{0} concluded: Accept {1:F4}",
                functionName, newBoundary);
            return;
        }                                   // end of if (StringSet(graphingPressureLowBoundaryBoxArray[unitNumber]->Text))
        else
        {
            graphingPressureLowBoundaryBoxArray[unitNumber]->Text = String::Format(
                "{0:F4}",
                QCOM_GraphingConvertToCurrentUnits(unit->graphingPressureLowBoundaryPSI, GUI_UNIT_GRAPH_CONTEXT_PRESSURE));
        }
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_GraphingValidatePressureLowBoundaryValue()
//----------------------------------------------------------------------------
// QCOM_GraphingValidateTemperatureHighBoundaryValue
//
// Validates the Temperature high boundary text box
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingValidateTemperatureHighBoundaryValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <TextBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingValidateTemperatureHighBoundaryValue");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if (StringSet(graphingTemperatureHighBoundaryBoxArray[unitNumber]->Text))
        {
            double newBoundary = Convert::ToDouble(graphingTemperatureHighBoundaryBoxArray[unitNumber]->Text);
            double newDefaultBoundary = QCOM_GraphingConvertToDefaultUnits(newBoundary, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE);
            double lowBoundary = Convert::ToDouble(graphingTemperatureLowBoundaryBoxArray[unitNumber]->Text);
            if (newBoundary <= lowBoundary)
            {
                //------------------------------------------------------------
                // Force the Low value to be 1/10 the new High value
                //------------------------------------------------------------
                lowBoundary = newBoundary * 0.1;
                RecordBasicEvent(
                    "    A conflict in boundary values forced a change in the Temperature Low Boundary from {0:F4} to {1:F4} {2}",
                    QCOM_GraphingConvertToCurrentUnits(unit->graphingTemperatureLowBoundaryCelsius, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE),
                    lowBoundary,
                    QCOM_TemperatureUnitsStringArray[QCOM_CurrentTemperatureUnits]);
                unit->graphingTemperatureLowBoundaryCelsius =
                    QCOM_GraphingConvertToDefaultUnits(lowBoundary, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE);
                graphingTemperatureLowBoundaryBoxArray[unitNumber]->Text = String::Format(
                    "{0:F4}", lowBoundary);
            }
            if (newDefaultBoundary != unit->graphingTemperatureHighBoundaryCelsius)
            {
                RecordBasicEvent(
                    "    The Temperature High Boundary changed from {0:F4} to {1:F4} {2}",
                    QCOM_GraphingConvertToCurrentUnits(unit->graphingTemperatureHighBoundaryCelsius, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE),
                    newBoundary,
                    QCOM_TemperatureUnitsStringArray[QCOM_CurrentTemperatureUnits]);
                unit->graphingTemperatureHighBoundaryCelsius = newDefaultBoundary;
                QCOM_GraphingClearGraph(unit);
                graphingTemperatureHighBoundaryBoxArray[unitNumber]->Text = String::Format(
                    "{0:F4}", newBoundary);
            }
            evt->Cancel = GUI_NO;
            RecordBasicEvent("{0} concluded: Accept {1:F4}",
                functionName, newBoundary);
            return;
        }                                   // end of if (StringSet(graphingTemperatureHighBoundaryBoxArray[unitNumber]->Text))
        else
        {
            graphingTemperatureHighBoundaryBoxArray[unitNumber]->Text = String::Format(
                "{0:F4}",
                QCOM_GraphingConvertToCurrentUnits(unit->graphingTemperatureHighBoundaryCelsius, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE));
        }
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_GraphingValidateTemperatureHighBoundaryValue()
//----------------------------------------------------------------------------
// QCOM_GraphingValidateTemperatureLowBoundaryValue
//
// Validates the Temperature low boundary text box
//
// Called by:   QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingValidateTemperatureLowBoundaryValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <TextBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_GraphingValidateTemperatureLowBoundaryValue");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if (StringSet(graphingTemperatureLowBoundaryBoxArray[unitNumber]->Text))
        {
            double newBoundary = Convert::ToDouble(graphingTemperatureLowBoundaryBoxArray[unitNumber]->Text);
            double newDefaultBoundary = QCOM_GraphingConvertToDefaultUnits(newBoundary, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE);
            double highBoundary = Convert::ToDouble(graphingTemperatureHighBoundaryBoxArray[unitNumber]->Text);
            if (newBoundary >= highBoundary)
            {
                //------------------------------------------------------------
                // Force the High value to be 10 times the new Low value
                //------------------------------------------------------------
                highBoundary = newBoundary * 10.0;
                RecordBasicEvent(
                    "    A conflict in boundary values forced a change in the Temperature High Boundary from {0:F4} to {1:F4} {2}",
                    QCOM_GraphingConvertToCurrentUnits(unit->graphingTemperatureHighBoundaryCelsius, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE),
                    highBoundary,
                    QCOM_TemperatureUnitsStringArray[QCOM_CurrentTemperatureUnits]);
                unit->graphingTemperatureHighBoundaryCelsius =
                    QCOM_GraphingConvertToDefaultUnits(highBoundary, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE);
                graphingTemperatureHighBoundaryBoxArray[unitNumber]->Text = String::Format(
                    "{0:F4}", highBoundary);
            }
            if (newDefaultBoundary != unit->graphingTemperatureLowBoundaryCelsius)
            {
                RecordBasicEvent(
                    "    The Temperature Low Boundary changed from {0:F4} to {1:F4} {2}",
                    QCOM_GraphingConvertToCurrentUnits(unit->graphingTemperatureLowBoundaryCelsius, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE),
                    newBoundary,
                    QCOM_TemperatureUnitsStringArray[QCOM_CurrentTemperatureUnits]);
                unit->graphingTemperatureLowBoundaryCelsius = newDefaultBoundary;
                QCOM_GraphingClearGraph(unit);
                graphingTemperatureLowBoundaryBoxArray[unitNumber]->Text = String::Format(
                    "{0:F4}", newBoundary);
            }
            evt->Cancel = GUI_NO;
            RecordBasicEvent("{0} concluded: Accept {1:F4}",
                functionName, newBoundary);
            return;
        }                                   // end of if (StringSet(graphingTemperatureLowBoundaryBoxArray[unitNumber]->Text))
        else
        {
            graphingTemperatureLowBoundaryBoxArray[unitNumber]->Text = String::Format(
                "{0:F4}",
                QCOM_GraphingConvertToCurrentUnits(unit->graphingTemperatureLowBoundaryCelsius, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE));
        }
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_GraphingValidateTemperatureLowBoundaryValue()
//----------------------------------------------------------------------------
// QCOM_ReadoutDisplayUnitGraphButtonClicked
//
// Handles the click of the readout unit Display Graph button
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDisplayUnitGraphButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_ReadoutDisplayUnitGraphButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Display Graph button clicked for module {0}",
            unit->moduleSerialNumber);
        if (graphingWindowArray[unitNumber]->WindowState == FormWindowState::Minimized)
            graphingWindowArray[unitNumber]->WindowState = FormWindowState::Normal;
        else
            graphingWindowArray[unitNumber]->Show();
        graphingWindowArray[unitNumber]->BringToFront();
        if (graphingWindowArray[unitNumber]->CanFocus)
            graphingWindowArray[unitNumber]->Focus();
        if (graphingWindowArray[unitNumber]->CanSelect)
            graphingWindowArray[unitNumber]->Select();
        DWORD status = QCOM_RetrieveTransducerReadings(unit);
        if (status == QCOM_SUCCESS)
        {
            QCOM_UpdateReadout(unit);
        }
    }
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_ReadoutDisplayUnitGraphButtonClicked()
//----------------------------------------------------------------------------
#endif      // GRAPHEVENTS_CPP
//============================================================================
// End of GraphEvents.cpp
//============================================================================
