//============================================================================
// Graphing.cpp
//
// The regular and event methods used by GUI.cpp for data logging
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     GRAPHING_CPP
#define     GRAPHING_CPP
#include    "Graphing.h"
//----------------------------------------------------------------------------
// QCOM_GraphingCalculateVerticalPosition
//
// Calculates the vertical graphing position in the specified graphing window
// for the given graph context
//
// Returns: -1      :   Failure
//          other   :   The vertical position of the graph context
//
// Called by:   QCOM_GraphingUpdateDisplayWindow
//              QCOM_InitializeGUIComponents
//
// Note:    No filtering is done to prevent the returned vertical position
//          fro exceeding the bounds of the graphing window
//----------------------------------------------------------------------------
    int QCOM_GUIClass::
QCOM_GraphingCalculateVerticalPosition(
    UnitInfo        ^unit,
    DWORD           graphContext)
{
    int             verticalPosition = QCOM_FAILURE;
    String          ^functionName = _T("QCOM_GraphingCalculateVerticalPosition");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        switch (graphContext)
        {
            case GUI_UNIT_GRAPH_CONTEXT_PRESSURE :                              // 0
                {
                    double middleValue =
                        unit->graphingPressureKReciprocalDeltaBoundary *
                        (unit->pressureValuePSI - unit->graphingPressureLowBoundaryPSI);
                    int mNum = 0;
                    if (middleValue > 1000000.0)
                    {
                        middleValue /= 1000.0;
                        verticalPosition = unit->graphingPressureBottom -
                            (unit->graphingPressureGraphSize * Convert::ToInt32(middleValue));
                        mNum = 1;
                    }
                    else
                    {
                        verticalPosition = unit->graphingPressureBottom -
                            ((unit->graphingPressureGraphSize * Convert::ToInt32(middleValue)) / 1000);
                        mNum = 2;
                    }
                }
                break;
            case GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE :                           // 1
                {
                    double middleValue =
                        unit->graphingTemperatureKReciprocalDeltaBoundary *
                        (unit->temperatureValueCelsius - unit->graphingTemperatureLowBoundaryCelsius);
                    if (middleValue > 1000000.0)
                    {
                        middleValue /= 1000.0;
                        verticalPosition = unit->graphingTemperatureBottom -
                            (unit->graphingTemperatureGraphSize * Convert::ToInt32(middleValue));
                    }
                    else
                    {
                        verticalPosition = unit->graphingTemperatureBottom -
                            ((unit->graphingTemperatureGraphSize * Convert::ToInt32(middleValue)) / 1000);
                    }
                }
                break;
            case GUI_UNIT_GRAPH_CONTEXT_AMPERAGE :                              // 2
                verticalPosition = unit->graphingAmperageBottom -
                    ((unit->graphingAmperageGraphSize * Convert::ToInt32(
                        unit->graphingAmperageKReciprocalDeltaBoundary *
                        (unit->transducerAmperage - unit->graphingAmperageLowBoundarymA))) /
                    1000);
                break;
            default :
                RecordErrorEvent("    Invalid graph context '{0:D}' selected", graphContext);
                break;
        }                               // end of switch (graphContext)
        if (verticalPosition < 0)
            verticalPosition = QCOM_FAILURE;
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    return verticalPosition;
}                                       // end of QCOM_GraphingCalculateVerticalPosition()
//----------------------------------------------------------------------------
// QCOM_GraphingClearGraph
//
// Clears the graph boxes in the specified Graphing window
//
// Called by:   QCOM_GraphingClearGraphButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingClearGraph(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_GraphingClearGraph");
    //------------------------------------------------------------------------
    if (QCOM_UnitLegal(unit))
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        RecordBasicEvent(
            "    Graphs cleared for module {0}",
            unit->moduleSerialNumber);
        QCOM_GraphingUpdateGraphCalculations(unit);
        graphingPictureBoxArray[unitNumber]->Image = nullptr;
        graphingPictureBoxArray[unitNumber]->Invalidate();
        unit->graphingLeft = GUI_UNIT_GRAPH_BOX_LEFT_MARGIN;
        unit->graphingPressureVerticalPosition = QCOM_GraphingCalculateVerticalPosition(
            unit,
            GUI_UNIT_GRAPH_CONTEXT_PRESSURE);
        unit->graphingTemperatureVerticalPosition = QCOM_GraphingCalculateVerticalPosition(
            unit,
            GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE);
        unit->graphingAmperageVerticalPosition = QCOM_GraphingCalculateVerticalPosition(
            unit,
            GUI_UNIT_GRAPH_CONTEXT_AMPERAGE);
        unit->graphingPointsDisplayed = 0;
        unit->graphingGraphChanged = GUI_NO;
        unit->graphingGraphHasData = GUI_NO;
        graphingClearGraphButtonArray[unitNumber]->Enabled = GUI_NO;
        graphingSaveGraphButtonArray[unitNumber]->Enabled = GUI_NO;
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
}                                       // end of QCOM_GraphingClearGraph()
//----------------------------------------------------------------------------
// QCOM_GraphingConvertToCurrentUnits
//
// Converts the specified value in default units to that in the current units
// for the given value type
//----------------------------------------------------------------------------
    double QCOM_GUIClass::
QCOM_GraphingConvertToCurrentUnits(
    double          value,
    DWORD           valueType)
{
    double          convertedValue = 0.0;
    String          ^functionName = _T("QCOM_GraphingConvertToCurrentUnits");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1:D}) called", functionName, valueType);
    switch (valueType)
    {
        case GUI_UNIT_GRAPH_CONTEXT_PRESSURE :                                  // 0
            //----------------------------------------------------------------
            // It is assumed that value is in psi
            //----------------------------------------------------------------
            convertedValue = value * QCOM_PressureUnitsPerPSI[QCOM_CurrentPressureUnits];
            break;
        case GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE :                               // 1
            //----------------------------------------------------------------
            // It is assumed that value is in Celsius
            //----------------------------------------------------------------
            switch (QCOM_CurrentTemperatureUnits)
            {
                case QCOM_TEMPERATURE_UNITS_CELSIUS :                           // 0
                    convertedValue = value;
                    break;
                case QCOM_TEMPERATURE_UNITS_FAHRENHEIT :                        // 1
                    convertedValue = FahrenheitFromCelsius(value);
                    break;
                case QCOM_TEMPERATURE_UNITS_KELVIN :                            // 2
                    convertedValue = value + QCOM_CELSIUS_TO_KELVIN;
                    break;
                case QCOM_TEMPERATURE_UNITS_RANKINE :                           // 3
                    convertedValue = FahrenheitFromCelsius(value) + QCOM_FAHRENHEIT_TO_RANKINE;
                    break;
                default :
                    QCOM_RecordAndModalErrorEvent(
                        "{0}({1:D}) :\nEncountered invalid temperature units {2:D}",
                        functionName, valueType, QCOM_CurrentTemperatureUnits);
                    break;
            }
            break;
        case GUI_UNIT_GRAPH_CONTEXT_AMPERAGE :                                  // 2
            //----------------------------------------------------------------
            // It is assumed that value is in mA
            //----------------------------------------------------------------
            convertedValue = value;
            break;
        default :
            RecordErrorEvent("    Invalid value type '{0:D}' selected", valueType);
            break;
    }                               // end of switch (valueType)
    RecordBasicEvent("{0} concluded with converted value = {1:F8}",
        functionName, convertedValue);
    return convertedValue;
}                                       // end of QCOM_GraphingConvertToCurrentUnits()
//----------------------------------------------------------------------------
// QCOM_GraphingConvertToDefaultUnits
//
// Converts the specified value in current units to that in the default units
// for the given value type
//----------------------------------------------------------------------------
    double QCOM_GUIClass::
QCOM_GraphingConvertToDefaultUnits(
    double          value,
    DWORD           valueType)
{
    double          convertedValue = 0.0;
    String          ^functionName = _T("QCOM_GraphingConvertToDefaultUnits");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1:D}) called", functionName, valueType);
    switch (valueType)
    {
        case GUI_UNIT_GRAPH_CONTEXT_PRESSURE :                                  // 0
            //----------------------------------------------------------------
            // It is assumed that value is in the current pressure units
            //----------------------------------------------------------------
            {
                double unitsPerPSI = QCOM_PressureUnitsPerPSI[QCOM_CurrentPressureUnits];
                if (unitsPerPSI)
                    convertedValue = value / unitsPerPSI;
                else
                    QCOM_RecordAndModalErrorEvent(
                        "{0}({1:D}) :\nEncountered invalid pressure units {2:D}",
                        functionName, valueType, QCOM_CurrentPressureUnits);
            }
            break;
        case GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE :                               // 1
            //----------------------------------------------------------------
            // It is assumed that value is in the current temperature units
            //----------------------------------------------------------------
            switch (QCOM_CurrentTemperatureUnits)
            {
                case QCOM_TEMPERATURE_UNITS_KELVIN :                            // 2
                    value -= QCOM_CELSIUS_TO_KELVIN;
                case QCOM_TEMPERATURE_UNITS_CELSIUS :                           // 0
                    convertedValue = value;
                    break;
                case QCOM_TEMPERATURE_UNITS_RANKINE :                           // 3
                    value -= QCOM_FAHRENHEIT_TO_RANKINE;
                case QCOM_TEMPERATURE_UNITS_FAHRENHEIT :                        // 1
                    convertedValue = ((value - 32.0) * 5.0) / 9.0;
                    break;
                default :
                    QCOM_RecordAndModalErrorEvent(
                        "{0}({1:D}) :\nEncountered invalid temperature units {2:D}",
                        functionName, valueType, QCOM_CurrentTemperatureUnits);
                    break;
            }
            break;
        case GUI_UNIT_GRAPH_CONTEXT_AMPERAGE :                                  // 2
            //----------------------------------------------------------------
            // It is assumed that value is in mA
            //----------------------------------------------------------------
            convertedValue = value;
            break;
        default :
            RecordErrorEvent("    Invalid value type '{0:D}' selected", valueType);
            break;
    }                               // end of switch (valueType)
    RecordBasicEvent("{0} concluded with converted value = {1:F8}",
        functionName, convertedValue);
    return convertedValue;
}                                       // end of QCOM_GraphingConvertToDefaultUnits()
//----------------------------------------------------------------------------
// QCOM_GraphingDisplayCurrentBoundaryValues
//
// Displays the boundary values currently set for pressure, temperature, and
// current
//
// Called by:   QCOM_GraphingSetDefaultBoundaryValuesButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingDisplayCurrentBoundaryValues(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_GraphingDisplayCurrentBoundaryValues");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        QCOM_GraphingReflectBoundaryValues(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_GraphingDisplayCurrentBoundaryValues()
//----------------------------------------------------------------------------
// QCOM_GraphingDisplayLargeFormattedValues
//
// Displays the pressure, temperature, and current values as large, formatted
// numerals in the specified Graphing window
//
// Called by:   QCOM_GraphingUpdateDisplayWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingDisplayLargeFormattedValues(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_GraphingDisplayLargeFormattedValues");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        DWORD unitNumber = unit->unitNumber;
        RecordDetailedEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Format and display the large numeric values
        //--------------------------------------------------------------------
        double pressureValue = QCOM_GraphingConvertToCurrentUnits(
            unit->pressureValuePSI, GUI_UNIT_GRAPH_CONTEXT_PRESSURE);
        if ((pressureValue >= 10000.0) || (pressureValue <= -1000.0))
        {
            graphingPressureValueLabelArray[unitNumber]->Text = String::Format(
                "{0:D}", Convert::ToInt32(pressureValue));
        }
        else
        {
            String ^pressureFormat;
            if ((pressureValue >= 1000.0) || (pressureValue <= -100.0))
            {
                pressureFormat = _T("{0:F1}");
            }
            else
            {
                if ((pressureValue >= 100.0) || (pressureValue <= -10.0))
                {
                    pressureFormat = _T("{0:F2}");
                }
                else
                {
                    if ((pressureValue >= 10.0) || (pressureValue <= -1.0))
                    {
                        pressureFormat = _T("{0:F3}");
                    }
                    else
                    {
                        pressureFormat = _T("{0:F4}");
                    }
                }
            }
            graphingPressureValueLabelArray[unitNumber]->Text = String::Format(
                pressureFormat, pressureValue);
        }
        double temperatureValue = QCOM_GraphingConvertToCurrentUnits(
            unit->temperatureValueCelsius, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE);
        if ((temperatureValue >= 10000.0) || (temperatureValue <= -1000.0))
        {
            graphingTemperatureValueLabelArray[unitNumber]->Text = String::Format(
                "{0:D}", Convert::ToInt32(temperatureValue));
        }
        else
        {
            String ^temperatureFormat;
            if ((temperatureValue >= 1000.0) || (temperatureValue <= -100.0))
            {
                temperatureFormat = _T("{0:F1}");
            }
            else
            {
                if ((temperatureValue >= 100.0) || (temperatureValue <= -10.0))
                {
                    temperatureFormat = _T("{0:F2}");
                }
                else
                {
                    if ((temperatureValue >= 10.0) || (temperatureValue <= -1.0))
                    {
                        temperatureFormat = _T("{0:F3}");
                    }
                    else
                    {
                        temperatureFormat = _T("{0:F4}");
                    }
                }
            }
            graphingTemperatureValueLabelArray[unitNumber]->Text = String::Format(
                temperatureFormat, temperatureValue);
        }
        graphingAmperageValueLabelArray[unitNumber]->Text = String::Format(
            "{0:F2}",
            QCOM_GraphingConvertToCurrentUnits(unit->transducerAmperage, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE));
        RecordDetailedEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_GraphingDisplayLargeFormattedValues()
//----------------------------------------------------------------------------
// QCOM_GraphingReflectBoundaryValues
//
// Sets appropriate objects according to the boundary values
//
// Called by:   QCOM_GraphingSetDefaultBoundaryValuesButtonClicked
//              QCOM_GraphingDisplayCurrentBoundaryValues
//              QCOM_InstallGraphingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingReflectBoundaryValues(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_GraphingReflectBoundaryValues");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        graphingPressureLowBoundaryBoxArray[unitNumber]->Text = String::Format(
            "{0:F4}",
            QCOM_GraphingConvertToCurrentUnits(unit->graphingPressureLowBoundaryPSI, GUI_UNIT_GRAPH_CONTEXT_PRESSURE));
        graphingPressureHighBoundaryBoxArray[unitNumber]->Text = String::Format(
            "{0:F4}",
            QCOM_GraphingConvertToCurrentUnits(unit->graphingPressureHighBoundaryPSI, GUI_UNIT_GRAPH_CONTEXT_PRESSURE));
        graphingTemperatureLowBoundaryBoxArray[unitNumber]->Text = String::Format(
            "{0:F4}",
            QCOM_GraphingConvertToCurrentUnits(unit->graphingTemperatureLowBoundaryCelsius, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE));
        graphingTemperatureHighBoundaryBoxArray[unitNumber]->Text = String::Format(
            "{0:F4}",
            QCOM_GraphingConvertToCurrentUnits(unit->graphingTemperatureHighBoundaryCelsius, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE));
        graphingAmperageLowBoundaryBoxArray[unitNumber]->Text = String::Format(
            "{0:F4}",
            QCOM_GraphingConvertToCurrentUnits(unit->graphingAmperageLowBoundarymA, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE));
        graphingAmperageHighBoundaryBoxArray[unitNumber]->Text = String::Format(
            "{0:F4}",
            QCOM_GraphingConvertToCurrentUnits(unit->graphingAmperageHighBoundarymA, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE));
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_GraphingReflectBoundaryValues()
//----------------------------------------------------------------------------
// QCOM_GraphingSaveGraph
//
// Saves or prints the graph boxes in the specified Graphing window
//
// Called by:   QCOM_GraphingSaveGraphButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingSaveGraph(
    UnitInfo        ^unit)
{
    bool            proceedToSaveFile = GUI_YES;
    String          ^functionName = _T("QCOM_GraphingSaveGraph");
    //------------------------------------------------------------------------
    if (QCOM_UnitLegal(unit))
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("    {0}({1:D}) called", functionName, unitNumber);
        if (graphingPictureBoxArray[unitNumber]->Image)
        {
            //----------------------------------------------------------------
            // Pick an unused image file name
            //----------------------------------------------------------------
            String ^imagePathString;
            int fileInstance = 1;
            DateTime dateTime = DateTime::Now;
            do
            {
                String ^imageFileString = String::Format(
                    "QCOM-Graph-{0}-{1}-{2:D2}{3:D2}{4:D2}-{5:D3}.png",
                    unit->moduleSerialNumber,
                    unit->transducerSerialNumber,
                    (dateTime.Year % 100),
                    dateTime.Month,
                    dateTime.Day,
                    fileInstance);
                imagePathString = String::Concat(
                    QCOM_GeneralInfo->logDirectory,
                    "\\",
                    imageFileString);
                if (File::Exists(imagePathString))
                    fileInstance++;
            }
            while (File::Exists(imagePathString));
            //----------------------------------------------------------------
            // Save the graph image to file
            //----------------------------------------------------------------
            Bitmap ^graphingPictureBoxImage = gcnew Bitmap(
                graphingPictureBoxArray[unitNumber]->Width,
                graphingPictureBoxArray[unitNumber]->Height);
            Graphics ^graphingGraph = Graphics::FromImage(graphingPictureBoxImage);
            graphingGraph->DrawImage(graphingPictureBoxArray[unitNumber]->Image, 0, 0);
            graphingPictureBoxImage->Save(imagePathString);
            delete graphingGraph;
            //----------------------------------------------------------------
            // Pick an unused PDF file name
            //----------------------------------------------------------------
            String ^PDFFileString;
            String ^PDFPathString;
            fileInstance = 1;
            do
            {
                PDFFileString = String::Format(
                    "QCOM-Graph-{0}-{1}-{2:D2}{3:D2}{4:D2}-{5:D3}.pdf",
                    unit->moduleSerialNumber,
                    unit->transducerSerialNumber,
                    (dateTime.Year % 100),
                    dateTime.Month,
                    dateTime.Day,
                    fileInstance);
                PDFPathString = String::Concat(
                    QCOM_GeneralInfo->logDirectory,
                    "\\",
                    PDFFileString);
                if (File::Exists(PDFPathString))
                    fileInstance++;
            }
            while (File::Exists(PDFPathString));
            String ^savePromptString = String::Concat(
                "Save PDF graph for ",
                unit->transducerSerialNumber,
                " on ",
                unit->moduleSerialNumber);
            StringBuilder ^imagePathBuilder = gcnew StringBuilder(PDFPathString);
            proceedToSaveFile = QCOM_PromptForSaveFile(
                savePromptString,
                imagePathBuilder,
                PDFPathString,
                GUI_FILE_TYPE_PDF);
            PDFPathString = imagePathBuilder->ToString();
            delete imagePathBuilder;
            if (proceedToSaveFile)
            {
                String ^fileBorder = String::Concat("%", gcnew String('=', 77));
                String ^sectionBorder = String::Concat("%", gcnew String('-', 77));
                String ^subSectionBorder = String::Concat("        %", gcnew String('-', 69));
                StreamWriter ^textWriter = File::CreateText(PDFPathString);
                if (textWriter)
                {
                    textWriter->WriteLine("%PDF-1.5");
                    textWriter->WriteLine("%����");
                    textWriter->WriteLine(fileBorder);
                    textWriter->WriteLine(String::Concat("% ", PDFFileString));
                    textWriter->WriteLine("%");
                    textWriter->WriteLine(String::Concat(
                        _T("% PDF for graph image of transducer "),
                        unit->transducerSerialNumber,
                        _T(" on module "),
                        unit->moduleSerialNumber));
                    textWriter->WriteLine("%");
                    textWriter->WriteLine(String::Concat(
                        _T("% Copyright (C) 2014 - "),
                        dateTime.Year,
                        _T(" Quartzdyne, Inc.  All rights reserved.")));
                    textWriter->WriteLine("%");
                    textWriter->WriteLine("% No part of this source code may be reproduced or transmitted in any form or");
                    textWriter->WriteLine("% by any means, electronic or mechanical, including photocopying, recording,");
                    textWriter->WriteLine("% or any information storage and retrieval system, without express written");
                    textWriter->WriteLine("% permission from Quartzdyne, Inc.  Further, no use of this source code is");
                    textWriter->WriteLine("% permitted in any form or means without a valid, written license agreement");
                    textWriter->WriteLine("% with Quartzdyne, Inc.  While every reasonable precaution has been taken in");
                    textWriter->WriteLine("% the preparation of this source code, Quartzdyne, Inc., assumes no");
                    textWriter->WriteLine("% responsibility for errors, omissions, or damages from the use of the source");
                    textWriter->WriteLine("% code contained herein.");
                    textWriter->WriteLine("%");
                    textWriter->WriteLine("% NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR");
                    textWriter->WriteLine("% ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION");
                    textWriter->WriteLine("% WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY");
                    textWriter->WriteLine("% OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY");
                    textWriter->WriteLine("% LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY");
                    textWriter->WriteLine("% PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH");
                    textWriter->WriteLine("% USE.");
                    textWriter->WriteLine("%");
                    textWriter->WriteLine("% Noji Ratzlaff");
                    textWriter->WriteLine("%");
                    textWriter->WriteLine("% Note: Section and page numbers refer to PDF 32000-1:2008");
                    textWriter->WriteLine("%");
                    textWriter->WriteLine(String::Format(
                        "% Created {0:D2}-{1:D2}-{2:D4} at {3:D2}:{4:D2}:{5:D2}",
                        dateTime.Month,
                        dateTime.Day,
                        dateTime.Year,
                        dateTime.Hour,
                        dateTime.Minute,
                        dateTime.Second));
                    textWriter->WriteLine(fileBorder);
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("% Document catalog (7.7.2, p.71-75)");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("1 0 obj");
                    textWriter->WriteLine("    <<  /Type /Catalog");
                    textWriter->WriteLine("        /Outlines 2 0 R");
                    textWriter->WriteLine("        /Pages 3 0 R");
                    textWriter->WriteLine("    >>");
                    textWriter->WriteLine("endobj");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("% File outline");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("2 0 obj");
                    textWriter->WriteLine("    <<  /Type /Outlines");
                    textWriter->WriteLine("        /Count 0");
                    textWriter->WriteLine("    >>");
                    textWriter->WriteLine("endobj");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("% Page tree - root node (7.7.3, p. 75-76)");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("3 0 obj");
                    textWriter->WriteLine("    <<  /Type /Pages");
                    textWriter->WriteLine("        /Kids [4 0 R]");
                    textWriter->WriteLine("        /Count 1");
                    textWriter->WriteLine("    >>");
                    textWriter->WriteLine("endobj");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("% Page tree - leaf node (7.7.3.3, p. 77)");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("4 0 obj");
                    textWriter->WriteLine("    <<  /Type /Page");
                    textWriter->WriteLine("        /Parent 3 0 R");
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine("        % MediaBox (7.7.3.3, p. 77) coordinates specify");
                    textWriter->WriteLine("        %   [lower-left x, lower-left y, upper-right x, upper-right y]");
                    textWriter->WriteLine("        % and");
                    textWriter->WriteLine("        %   8.5 X 72 = 612 and 11 X 72 = 792 (8.3.2.3, p. 115)");
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine("        /MediaBox [0 0 612 792]");
                    textWriter->WriteLine("        /TrimBox [0 0 612 792]");
                    textWriter->WriteLine("        /CropBox [0 0 612 792]");
                    textWriter->WriteLine("        /Contents 5 0 R");
                    textWriter->WriteLine("        /Resources  <<  /ProcSet 6 0 R");
                    textWriter->WriteLine("                        /Font << /F1 7 0 R >>");
                    textWriter->WriteLine("                    >>");
                    textWriter->WriteLine("    >>");
                    textWriter->WriteLine("endobj");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("% Set the text stream and its position");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("5 0 obj");
                    textWriter->WriteLine("    <<  /Length 73");
                    textWriter->WriteLine("    >>");
                    textWriter->WriteLine("stream");
                    textWriter->WriteLine("    BT");
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine("        % Set font size to 24");
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine("        /F1 24 Tf");
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine("        % 20 from the left, 740 from the bottom");
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine("        20 740 Td");
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine("        % 6 Tr and 2 w is roughly equivalent of bold face type");
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine("        6 Tr");
                    textWriter->WriteLine("        2 w");
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine("        % Display the serial number string");
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine(String::Concat(
                        _T("        (S/N "),
                        unit->transducerSerialNumber,
                        _T(") Tj")));
                    textWriter->WriteLine("    ET");
                    textWriter->WriteLine("endstream");
                    textWriter->WriteLine("endobj");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("% Procedure sets");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("6 0 obj");
                    textWriter->WriteLine("    [/PDF /Text /ImageB]");
                    textWriter->WriteLine("endobj");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("% Font definition");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("7 0 obj");
                    textWriter->WriteLine("    <<  /Type /Font");
                    textWriter->WriteLine("        /Subtype /Type1");
                    textWriter->WriteLine("        /Name /F1");
                    textWriter->WriteLine("        /BaseFont /Helvetica");
                    textWriter->WriteLine("        /Encoding /MacRomanEncoding");
                    textWriter->WriteLine("    >>");
                    textWriter->WriteLine("endobj");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("% File information (14.3.3, p. 549-550)");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("10 0 obj");
                    textWriter->WriteLine(String::Format(
                        "    <<  /CreationDate (D:{0:D4}{1:D2}{2:D2}{3:D2}{4:D2}{5:D2})",
                        dateTime.Year,
                        dateTime.Month,
                        dateTime.Day,
                        dateTime.Hour,
                        dateTime.Minute,
                        dateTime.Second));
                    textWriter->WriteLine(String::Format(
                        "        /ModDate (D:{0:D4}{1:D2}{2:D2}{3:D2}{4:D2}{5:D2})",
                        dateTime.Year,
                        dateTime.Month,
                        dateTime.Day,
                        dateTime.Hour,
                        dateTime.Minute,
                        dateTime.Second));
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine("        % Company name (must use octal for special characters: p. 655)");
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine("        /Producer (Quartzdyne, Inc.\\256, a Dover\\222 company)");
                    textWriter->WriteLine("        /Author <FEFF004E006F006A00690020005200610074007A006C006100660066>");
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine("        % Application name");
                    textWriter->WriteLine(subSectionBorder);
                    textWriter->WriteLine(String::Format(
                        "        /Creator (Quartzdyne\\256 QCOM {0} {1:D})",
                        QCOM_PROGRAM_VERSION_STRING,
                        QCOM_BuildNumber));
                    textWriter->WriteLine("        /Title 12 0 R");
                    textWriter->WriteLine("        /Subject 12 0 R");
                    textWriter->WriteLine("    >>");
                    textWriter->WriteLine("endobj");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("% Serial number string object");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("12 0 obj");
                    textWriter->WriteLine(String::Concat(
                        _T("    (S/N "),
                        unit->transducerSerialNumber,
                        _T(")")));
                    textWriter->WriteLine("endobj");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("% Cross-reference table (7.5.4, p. 40-42)");
                    textWriter->WriteLine("%");
                    textWriter->WriteLine("% Contains 13 objects, starting with object 0");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("xref");
                    textWriter->WriteLine("0 13");
                    textWriter->WriteLine("0000000000 65535 f");
                    textWriter->WriteLine("0000000009 00000 n");
                    textWriter->WriteLine("0000000074 00000 n");
                    textWriter->WriteLine("0000000120 00000 n");
                    textWriter->WriteLine("0000000179 00000 n");
                    textWriter->WriteLine("0000000364 00000 n");
                    textWriter->WriteLine("0000000466 00000 n");
                    textWriter->WriteLine("0000000796 00000 n");
                    textWriter->WriteLine("0000000996 00000 n");
                    textWriter->WriteLine("0000001096 00000 n");
                    textWriter->WriteLine("0000001296 00000 n");
                    textWriter->WriteLine("0000001496 00000 n");
                    textWriter->WriteLine("0000001696 00000 n");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("% File trailer (7.5.5, p. 42-43)");
                    textWriter->WriteLine(sectionBorder);
                    textWriter->WriteLine("trailer");
                    textWriter->WriteLine("    <<  /Size 14                % Number of xref entries");
                    textWriter->WriteLine("        /Root 1 0 R             % Which object contains the catalog");
                    textWriter->WriteLine("        /Info 10 0 R            % Which object contains document info");
                    textWriter->WriteLine("    >>");
                    textWriter->WriteLine("startxref");
                    textWriter->WriteLine("625");
                    textWriter->WriteLine("%%EOF");
                    textWriter->WriteLine(fileBorder);
                    textWriter->WriteLine(String::Concat("% End of ", PDFFileString));
                    textWriter->WriteLine(fileBorder);
                    textWriter->Close();
                }                       // end of if (textWriter)
                RecordBasicEvent(
                    "    PDF graph file saved as {0}", PDFPathString);
            }
            delete savePromptString;
        }                               // end of if (graphingPictureBoxArray[unitNumber]->Image)
        RecordBasicEvent("    {0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
}                                       // end of QCOM_GraphingSaveGraph()
//----------------------------------------------------------------------------
// QCOM_GraphingSetDefaultBoundaryValues
//
// Sets the upper and lower graphing boundary values of the pressure,
// temperature, and current graphs in the specified Graphing Window to their
// default values in the default units
//
// Called by:   QCOM_GraphingSetDefaultBoundaryValuesButtonClicked
//
// Note:    These values are very arbitrary
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingSetDefaultBoundaryValues(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_GraphingSetDefaultBoundaryValues");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        unit->graphingPressureLowBoundaryPSI = QCOM_GRAPH_DEFAULT_PRESSURE_LOW_BOUNDARY_PSI;
        unit->graphingPressureHighBoundaryPSI = QCOM_GRAPH_DEFAULT_PRESSURE_HIGH_BOUNDARY_PSI;
        unit->graphingTemperatureLowBoundaryCelsius = QCOM_GRAPH_DEFAULT_TEMPERATURE_LOW_BOUNDARY_C;
        unit->graphingTemperatureHighBoundaryCelsius = QCOM_GRAPH_DEFAULT_TEMPERATURE_HIGH_BOUNDARY_C;
        unit->graphingAmperageLowBoundarymA = QCOM_GRAPH_DEFAULT_AMPERAGE_LOW_BOUNDARY_MA;
        unit->graphingAmperageHighBoundarymA = QCOM_GRAPH_DEFAULT_AMPERAGE_HIGH_BOUNDARY_MA;
        QCOM_GraphingUpdateGraphCalculations(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_GraphingSetDefaultBoundaryValues()
//----------------------------------------------------------------------------
// QCOM_GraphingSetGraphingThresholds
//
// Sets the upper and lower thresholds in the specified graphing window
// for the given target graph
//
// Called by:   QCOM_GraphingDisplayAmperageDrawChecked
//              QCOM_GraphingSuperimposePressureTemperatureChecked
//              QCOM_InitializeGUIComponents
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingSetGraphingThresholds(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_GraphingSetGraphingThresholds");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        unit->graphingPressureTop = GUI_UNIT_GRAPH_UPPER_GRAPH_TOP;
        if (unit->graphingFlags & QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW)
        {
            unit->graphingPressureBottom = GUI_UNIT_GRAPH_UPPER_GRAPH_BOTTOM;
            unit->graphingTemperatureTop = GUI_UNIT_GRAPH_UPPER_GRAPH_TOP;
            unit->graphingTemperatureBottom = GUI_UNIT_GRAPH_UPPER_GRAPH_BOTTOM;
        }
        else
        {
            if (unit->graphingFlags & QCOM_UNIT_GRAPH_SUPERIMPOSE_PT)
            {
                unit->graphingPressureBottom = GUI_UNIT_GRAPH_LOWER_GRAPH_BOTTOM;
                unit->graphingTemperatureTop = GUI_UNIT_GRAPH_UPPER_GRAPH_TOP;
                unit->graphingTemperatureBottom = GUI_UNIT_GRAPH_LOWER_GRAPH_BOTTOM;
            }
            else
            {
                unit->graphingPressureBottom = GUI_UNIT_GRAPH_UPPER_GRAPH_BOTTOM;
                unit->graphingTemperatureTop = GUI_UNIT_GRAPH_LOWER_GRAPH_TOP;
                unit->graphingTemperatureBottom = GUI_UNIT_GRAPH_LOWER_GRAPH_BOTTOM;
            }
        }
        unit->graphingAmperageTop = GUI_UNIT_GRAPH_LOWER_GRAPH_TOP;
        unit->graphingAmperageBottom = GUI_UNIT_GRAPH_LOWER_GRAPH_BOTTOM;
        QCOM_GraphingUpdateGraphCalculations(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_GraphingSetGraphingThresholds()
//----------------------------------------------------------------------------
// QCOM_GraphingUpdateDisplayWindow
//
// Draws the lines and updates the images in the Graphing windows for one
// pixel of graph width
//
// Called by:   QCOM_UpdateReadout
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingUpdateDisplayWindow(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_GraphingUpdateDisplayWindow");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        DWORD unitNumber = unit->unitNumber;
        RecordDetailedEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Format and display the large numeric values
        //--------------------------------------------------------------------
        QCOM_GraphingDisplayLargeFormattedValues(unit);
        //--------------------------------------------------------------------
        // Start plotting the graphs
        //--------------------------------------------------------------------
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_GUI_UP_AND_RUNNING)
        {
            Pen ^dottedLinePen = gcnew Pen(Color::Black, GUI_UNIT_GRAPH_DEFAULT_LINE_WIDTH);
            //----------------------------------------------------------------
            // Move the entire graph left by one pixel
            //----------------------------------------------------------------
            Bitmap ^graphingPictureBoxImage = gcnew Bitmap(
                graphingPictureBoxArray[unitNumber]->Width,
                graphingPictureBoxArray[unitNumber]->Height);
            if (!graphingPictureBoxArray[unitNumber]->Image)
                graphingPictureBoxArray[unitNumber]->Image = graphingPictureBoxImage;
            Graphics ^graphingGraph = Graphics::FromImage(graphingPictureBoxImage);
            if (unit->graphingLeft > GUI_UNIT_GRAPH_BOX_RIGHT_MARGIN)
                graphingGraph->DrawImage(graphingPictureBoxArray[unitNumber]->Image, -1, 0);
            else
                graphingGraph->DrawImage(graphingPictureBoxArray[unitNumber]->Image, 0, 0);
            if (unit->graphingGraphChanged)
            {
                unit->graphingGraphChanged = GUI_NO;
                unit->graphingPressureVerticalPosition = QCOM_GraphingCalculateVerticalPosition(unit, GUI_UNIT_GRAPH_CONTEXT_PRESSURE);
                unit->graphingTemperatureVerticalPosition = QCOM_GraphingCalculateVerticalPosition(unit, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE);
                unit->graphingAmperageVerticalPosition = QCOM_GraphingCalculateVerticalPosition(unit, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE);
            }
            else
            {
                //------------------------------------------------------------
                // Pressure line
                //------------------------------------------------------------
                int newPressureVerticalPosition = QCOM_GraphingCalculateVerticalPosition(unit, GUI_UNIT_GRAPH_CONTEXT_PRESSURE);
                graphingGraph->DrawLine(
                    gcnew Pen(
                        Brushes::Blue,
                        (unit->graphingFlags & QCOM_UNIT_GRAPH_THICK_LINES) ? GUI_UNIT_GRAPH_THICK_LINE_WIDTH : GUI_UNIT_GRAPH_DEFAULT_LINE_WIDTH),
                    Point(
                        unit->graphingLeft,
                        unit->graphingPressureVerticalPosition),
                    Point(
                        unit->graphingLeft + 1,
                        newPressureVerticalPosition));
                unit->graphingPressureVerticalPosition = newPressureVerticalPosition;
                //------------------------------------------------------------
                // Dotted lines for pressure thresholds
                //------------------------------------------------------------
                if (!(unit->graphingPointsDisplayed % 3))
                {
                    graphingGraph->DrawLine(
                        dottedLinePen,
                        PointF(
                            (float) unit->graphingLeft,
                            (float) unit->graphingPressureTop),
                        PointF(
                            (float) unit->graphingLeft,
                            (float) unit->graphingPressureTop + 0.2F));
                    graphingGraph->DrawLine(
                        dottedLinePen,
                        PointF(
                            (float) unit->graphingLeft,
                            (float) unit->graphingPressureBottom),
                        PointF(
                            (float) unit->graphingLeft,
                            (float) unit->graphingPressureBottom + 0.2F));
                }
                //------------------------------------------------------------
                // Temperature line
                //------------------------------------------------------------
                int newTemperatureVerticalPosition = QCOM_GraphingCalculateVerticalPosition(unit, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE);
                graphingGraph->DrawLine(
                    gcnew Pen(
                        Brushes::Green,
                        (unit->graphingFlags & QCOM_UNIT_GRAPH_THICK_LINES) ? GUI_UNIT_GRAPH_THICK_LINE_WIDTH : GUI_UNIT_GRAPH_DEFAULT_LINE_WIDTH),
                    Point(
                        unit->graphingLeft,
                        unit->graphingTemperatureVerticalPosition),
                    Point(
                        unit->graphingLeft + 1,
                        newTemperatureVerticalPosition));
                unit->graphingTemperatureVerticalPosition = newTemperatureVerticalPosition;
                //------------------------------------------------------------
                // Dotted lines for temperature thresholds
                //------------------------------------------------------------
                if ((unit->graphingTemperatureTop != unit->graphingPressureTop) ||
                    (unit->graphingTemperatureBottom != unit->graphingPressureBottom))
                {
                    if (!(unit->graphingPointsDisplayed % 3))
                    {
                        graphingGraph->DrawLine(
                            dottedLinePen,
                            PointF(
                                (float) unit->graphingLeft,
                                (float) unit->graphingTemperatureTop),
                            PointF(
                                (float) unit->graphingLeft,
                                (float) unit->graphingTemperatureTop + 0.2F));
                        graphingGraph->DrawLine(
                            dottedLinePen,
                            PointF(
                                (float) unit->graphingLeft,
                                (float) unit->graphingTemperatureBottom),
                            PointF(
                                (float) unit->graphingLeft,
                                (float) unit->graphingTemperatureBottom + 0.2F));
                    }
                }
                //------------------------------------------------------------
                // Current line, if selected
                //------------------------------------------------------------
                if (unit->graphingFlags & QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW)
                {
                    int newCurrentVerticalPosition = QCOM_GraphingCalculateVerticalPosition(unit, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE);
                    graphingGraph->DrawLine(
                        gcnew Pen(
                            Brushes::DeepPink,
                            (unit->graphingFlags & QCOM_UNIT_GRAPH_THICK_LINES) ? GUI_UNIT_GRAPH_THICK_LINE_WIDTH : GUI_UNIT_GRAPH_DEFAULT_LINE_WIDTH),
                        Point(
                            unit->graphingLeft,
                            unit->graphingAmperageVerticalPosition),
                        Point(
                            unit->graphingLeft + 1,
                            newCurrentVerticalPosition));
                    unit->graphingAmperageVerticalPosition = newCurrentVerticalPosition;
                    //--------------------------------------------------------
                    // Dotted lines for current thresholds
                    //--------------------------------------------------------
                    if (!(unit->graphingPointsDisplayed % 3))
                    {
                        graphingGraph->DrawLine(
                            dottedLinePen,
                            PointF(
                                (float) unit->graphingLeft,
                                (float) unit->graphingAmperageTop),
                            PointF(
                                (float) unit->graphingLeft,
                                (float) unit->graphingAmperageTop + 0.2F));
                        graphingGraph->DrawLine(
                            dottedLinePen,
                            PointF(
                                (float) unit->graphingLeft,
                                (float) unit->graphingAmperageBottom),
                            PointF(
                                (float) unit->graphingLeft,
                                (float) unit->graphingAmperageBottom + 0.2F));
                    }
                }                       // end of if (unit->graphingFlags & QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW)
                //------------------------------------------------------------
                // Time stamp - must be separated by at least 80 pixels
                //------------------------------------------------------------
                if (unit->graphingSamplesSinceDisplayedTime++ > GUI_UNIT_GRAPH_TIMELINE_MINIMUM_SEPARATION)
                {
                    DateTime dateTime = DateTime::Now;
                    int currentMinute = (dateTime.Month * 1000000) + (dateTime.Day * 10000) + (dateTime.Hour * 100) + dateTime.Minute;
                    int currentHour = dateTime.Hour;
                    //--------------------------------------------------------
                    // Not within the same minute
                    //--------------------------------------------------------
                    if (currentMinute != unit->graphingPreviousTimeStampMinute)
                    {
                        //----------------------------------------------------
                        // Time stamps must be separated by at least one minute
                        //----------------------------------------------------
                        unit->graphingSamplesSinceDisplayedTime = 0;
                        unit->graphingPreviousTimeStampMinute = currentMinute;
                        //----------------------------------------------------
                        // Date stamp string
                        //----------------------------------------------------
                        String ^dateString = String::Format(
                            "{0:D2}-{1:D2}",
                            dateTime.Month,
                            dateTime.Day);
                        graphingGraph->DrawString(
                            dateString,
                            gcnew Drawing::Font(
                                FontFamily::GenericSansSerif,
                                10.0F,
                                FontStyle::Regular),
                            gcnew SolidBrush(Color::Purple),
                            PointF(
                                (float) unit->graphingLeft - GUI_UNIT_GRAPH_BOX_LEFT_MARGIN + 4,
                                (float) GUI_UNIT_GRAPH_DATELINE_TOP + 2));
                        //----------------------------------------------------
                        // Top vertical dotted line
                        //----------------------------------------------------
                        Pen ^timeLinePen = dottedLinePen;
                        timeLinePen->DashStyle = Drawing::Drawing2D::DashStyle::Dot;
                        graphingGraph->DrawLine(
                            timeLinePen,
                            Point(
                                unit->graphingLeft,
                                GUI_UNIT_GRAPH_DATELINE_BOTTOM),
                            Point(
                                unit->graphingLeft,
                                unit->graphingTimelineTop + 4));
                        //----------------------------------------------------
                        // Time stamp string
                        //----------------------------------------------------
                        String ^timeString;
                        String ^ampm = _T("a");
                        int negativeTimeStampOffset = GUI_UNIT_GRAPH_BOX_LEFT_MARGIN;
                        if (unit->graphingFlags & QCOM_UNIT_GRAPH_MILITARY_TIME_FORMAT)
                        {
                            negativeTimeStampOffset = GUI_UNIT_GRAPH_BOX_LEFT_MARGIN - 4;
                            timeString = String::Format(
                                "{0:D2}{1:D2}",
                                dateTime.Hour,
                                dateTime.Minute);
                        }
                        else
                        {
                            if (currentHour > 11)
                            {
                                ampm = _T("p");
                                if (currentHour > 12)
                                    currentHour -= 12;
                            }
                            else
                            {
                                if (currentHour == 0)
                                    currentHour = 12;
                            }
                            timeString = String::Format(
                                "{0:D}:{1:D2}{2}",
                                currentHour,
                                dateTime.Minute,
                                ampm);
                        }
                        graphingGraph->DrawString(
                            timeString,
                            gcnew Drawing::Font(
                                FontFamily::GenericSansSerif,
                                10.0F,
                                FontStyle::Regular),
                            gcnew SolidBrush(Color::Purple),
                            PointF(
                                (float) unit->graphingLeft - negativeTimeStampOffset,
                                (float) (unit->graphingTimelineTop + 4)));
                    }                   // end of if (currentMinute != unit->graphingPreviousTimeStampMinute)
                }                       // end of if (unit->graphingSamplesSinceDisplayedTime++ > GUI_UNIT_GRAPH_TIMELINE_MINIMUM_SEPARATION)
                //------------------------------------------------------------
                // Display the updated graph image
                //------------------------------------------------------------
                graphingPictureBoxArray[unitNumber]->Image = graphingPictureBoxImage;
                //------------------------------------------------------------
                // Conclude
                //------------------------------------------------------------
                delete graphingGraph;
                delete dottedLinePen;
                unit->graphingPointsDisplayed++;
                if (unit->graphingLeft <= GUI_UNIT_GRAPH_BOX_RIGHT_MARGIN)
                    unit->graphingLeft++;
                if (!unit->graphingGraphHasData)
                {
                    unit->graphingGraphHasData = GUI_YES;
                    graphingClearGraphButtonArray[unitNumber]->Enabled = GUI_YES;
                    graphingSaveGraphButtonArray[unitNumber]->Enabled = GUI_YES;
                }
            }                           // end of else of if (unit->graphingGraphChanged)
        }                               // end of if (QCOM_GeneralInfo->flags & QCOM_GENERAL_GUI_UP_AND_RUNNING)
        RecordDetailedEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_GraphingUpdateDisplayWindow()
//----------------------------------------------------------------------------
// QCOM_GraphingUpdateGraphCalculations
//
// Updates boundary and calculation shortcut values to reflect current values
//
// Called by:   QCOM_GraphingClearGraph
//              QCOM_GraphingSetDefaultBoundaryValues
//              QCOM_GraphingSetGraphingThresholds
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GraphingUpdateGraphCalculations(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_GraphingUpdateGraphCalculations");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        unit->graphingPressureGraphSize = unit->graphingPressureBottom - unit->graphingPressureTop;
        unit->graphingTemperatureGraphSize = unit->graphingTemperatureBottom - unit->graphingTemperatureTop;
        unit->graphingAmperageGraphSize = GUI_UNIT_GRAPH_LOWER_GRAPH_SIZE;
        if (unit->graphingPressureHighBoundaryPSI == unit->graphingPressureLowBoundaryPSI)
        {
            unit->graphingPressureHighBoundaryPSI = unit->graphingPressureLowBoundaryPSI + 10.0;
            QCOM_RecordAndModalErrorEvent(
                "    Pressure high and low boundary values ({0:F8}) are equal.\n"
                "Changed to Low = {0:F8} and High = {1:F8}",
                QCOM_GraphingConvertToCurrentUnits(unit->graphingPressureLowBoundaryPSI, GUI_UNIT_GRAPH_CONTEXT_PRESSURE),
                QCOM_GraphingConvertToCurrentUnits(unit->graphingPressureHighBoundaryPSI, GUI_UNIT_GRAPH_CONTEXT_PRESSURE));
        }
        unit->graphingPressureKReciprocalDeltaBoundary = 1000.0 /
            (unit->graphingPressureHighBoundaryPSI - unit->graphingPressureLowBoundaryPSI);
        if (unit->graphingTemperatureHighBoundaryCelsius == unit->graphingTemperatureLowBoundaryCelsius)
        {
            unit->graphingTemperatureHighBoundaryCelsius = unit->graphingTemperatureLowBoundaryCelsius + 10.0;
            QCOM_RecordAndModalErrorEvent(
                "    Temperature high and low boundary values ({0:F8}) are equal.\n"
                "Changed to Low = {0:F8} and High = {1:F8}",
                QCOM_GraphingConvertToCurrentUnits(unit->graphingTemperatureLowBoundaryCelsius, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE),
                QCOM_GraphingConvertToCurrentUnits(unit->graphingTemperatureHighBoundaryCelsius, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE));
        }
        unit->graphingTemperatureKReciprocalDeltaBoundary = 1000.0 /
            (unit->graphingTemperatureHighBoundaryCelsius - unit->graphingTemperatureLowBoundaryCelsius);
        if (unit->graphingAmperageHighBoundarymA == unit->graphingAmperageLowBoundarymA)
        {
            unit->graphingAmperageHighBoundarymA = unit->graphingAmperageLowBoundarymA + 10.0;
            QCOM_RecordAndModalErrorEvent(
                "    Current high and low boundary values ({0:F8}) are equal.\n"
                "Changed to Low = {0:F8} and High = {1:F8}",
                QCOM_GraphingConvertToCurrentUnits(unit->graphingAmperageLowBoundarymA, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE),
                QCOM_GraphingConvertToCurrentUnits(unit->graphingAmperageHighBoundarymA, GUI_UNIT_GRAPH_CONTEXT_AMPERAGE));
        }
        unit->graphingAmperageKReciprocalDeltaBoundary = 1000.0 /
            (unit->graphingAmperageHighBoundarymA - unit->graphingAmperageLowBoundarymA);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_GraphingUpdateGraphCalculations()
//----------------------------------------------------------------------------
// QCOM_InstallGraphingWindows
//
// Installs the graphing windows
//
// Called by:   QCOM_InstallUtilities
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InstallGraphingWindows(void)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_InstallGraphingWindows");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_SetUpUnitGraphingWindow(unit);
        QCOM_GraphingReflectBoundaryValues(unit);
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_InstallGraphingWindows()
//----------------------------------------------------------------------------
// QCOM_ReDrawGraphingWindow
//
// Redraws appropriate objects in the specified Graphing window
//
// Called by:   QCOM_
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReDrawGraphingWindow(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_ReDrawGraphingWindow");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        RecordBasicEvent(
            "    Redrawing objects in the graphing window for module {0}",
            unit->moduleSerialNumber);
        //--------------------------------------------------------------------
        // Place redraw operations here
        //--------------------------------------------------------------------
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_ReDrawGraphingWindow()
//----------------------------------------------------------------------------
// QCOM_SetUpUnitGraphingWindow
//
// Creates and populates the unit graphing windows
//
// Called by:   QCOM_InstallGraphingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SetUpUnitGraphingWindow(
    UnitInfo        ^unit)
{
//    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_SetUpUnitGraphingWindow");
    //------------------------------------------------------------------------
    if (unit)
    {
        DWORD unitNumber = unit->unitNumber;
        RecordVerboseEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Create a new window form
        //--------------------------------------------------------------------
        Form ^graphingWindow = gcnew Form;
        graphingWindow->Tag = unitNumber;
        //--------------------------------------------------------------------
        // Appearance attributes
        //--------------------------------------------------------------------
        graphingWindow->MaximizeBox = GUI_NO;
//        graphingWindow->MinimizeBox = GUI_NO;
        graphingWindow->HelpButton = GUI_NO;
        //--------------------------------------------------------------------
        // Window icon
        //--------------------------------------------------------------------
        graphingWindow->Icon = QCOM_SoftwareIcon;
        //--------------------------------------------------------------------
        // Background image
        //--------------------------------------------------------------------
        graphingWindow->BackgroundImage = whiteSandBackground;
        graphingWindow->Size = Drawing::Size(
            GUI_UNIT_GRAPH_WINDOW_WIDTH,
            GUI_UNIT_GRAPH_WINDOW_HEIGHT);
        graphingWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
        //--------------------------------------------------------------------
        // Start/Stop Sampling button
        //--------------------------------------------------------------------
        Button ^graphingStartStopSamplingButton = gcnew Button;
        graphingStartStopSamplingButton->Location = Point(10, 10);
        graphingStartStopSamplingButton->Size = Drawing::Size(
            GUI_READOUT_OBJECT_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            graphingStartStopSamplingButton,
            unitNumber);
        graphingStartStopSamplingButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutUnitStartStopSamplingButtonClicked);
        graphingWindow->Controls->Add(graphingStartStopSamplingButton);
        graphingStartStopSamplingButtonArray[unitNumber] = graphingStartStopSamplingButton;
        //--------------------------------------------------------------------
        // Start/Stop Sampling button tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingStartStopSamplingButtonToolTip = gcnew ToolTip;
        graphingStartStopSamplingButtonToolTip->ShowAlways = GUI_YES;
        graphingStartStopSamplingButtonToolTip->AutoPopDelay = 10000;
        graphingStartStopSamplingButtonToolTip->ToolTipTitle =
            _T("Start / Stop Sampling");
        String ^graphingStartStopSamplingButtonToolTipText = String::Concat(
            "Starts or stops sampling pressure and temperature for", Environment::NewLine,
            "transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, ". Starting sampling", Environment::NewLine,
            "does not automatically start logging, but stopping", Environment::NewLine,
            "sampling will stop logging if this unit is already logging.");
        graphingStartStopSamplingButtonToolTip->SetToolTip(graphingStartStopSamplingButton, graphingStartStopSamplingButtonToolTipText);
        delete graphingStartStopSamplingButtonToolTipText;
        //--------------------------------------------------------------------
        // Start/Stop Logging button
        //--------------------------------------------------------------------
        Button ^graphingStartStopLoggingButton = gcnew Button;
        graphingStartStopLoggingButton->Location = Point(
            graphingStartStopSamplingButton->Right + 15,
            graphingStartStopSamplingButton->Top);
        graphingStartStopLoggingButton->Size = graphingStartStopSamplingButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            graphingStartStopLoggingButton,
            unitNumber);
        graphingStartStopLoggingButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitStartStopButtonClicked);
        graphingWindow->Controls->Add(graphingStartStopLoggingButton);
        graphingStartStopLoggingButtonArray[unitNumber] = graphingStartStopLoggingButton;
        //--------------------------------------------------------------------
        // Start/Stop Logging button tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingStartStopLoggingButtonToolTip = gcnew ToolTip;
        graphingStartStopLoggingButtonToolTip->ShowAlways = GUI_YES;
        graphingStartStopLoggingButtonToolTip->AutoPopDelay = 10000;
        graphingStartStopLoggingButtonToolTip->ToolTipTitle =
            _T("Start / Stop Logging");
        String ^graphingStartStopLoggingButtonToolTipText = String::Concat(
            "Starts or stops logging pre-selected data points for", Environment::NewLine,
            "transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, ". Starting and", Environment::NewLine,
            "stopping logging will also start and stop sampling.");
        graphingStartStopLoggingButtonToolTip->SetToolTip(graphingStartStopLoggingButton, graphingStartStopLoggingButtonToolTipText);
        delete graphingStartStopLoggingButtonToolTipText;
        //--------------------------------------------------------------------
        // Clear Data Log button
        //--------------------------------------------------------------------
        Button ^graphingClearLogButton = gcnew Button;
        graphingClearLogButton->Text = _T("Clear Data Log");
        graphingClearLogButton->Location = Point(
            graphingStartStopLoggingButton->Right + 15,
            graphingStartStopLoggingButton->Top);
        graphingClearLogButton->Size = graphingStartStopLoggingButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            graphingClearLogButton,
            unitNumber);
        graphingClearLogButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitClearDataButtonClicked);
        graphingWindow->Controls->Add(graphingClearLogButton);
        graphingClearLogButtonArray[unitNumber] = graphingClearLogButton;
        //--------------------------------------------------------------------
        // Clear Data Log button tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingClearLogButtonToolTip = gcnew ToolTip;
        graphingClearLogButtonToolTip->ShowAlways = GUI_YES;
        graphingClearLogButtonToolTip->AutoPopDelay = 10000;
        graphingClearLogButtonToolTip->ToolTipTitle =
            _T("Clear Data Log");
        String ^graphingClearLogButtonToolTipText = String::Concat(
            "Erases all data from the data log for", Environment::NewLine,
            "transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, ".");
        graphingClearLogButtonToolTip->SetToolTip(graphingClearLogButton, graphingClearLogButtonToolTipText);
        delete graphingClearLogButtonToolTipText;
        //--------------------------------------------------------------------
        // Clear Graph button
        //--------------------------------------------------------------------
        Button ^graphingClearGraphButton = gcnew Button;
        graphingClearGraphButton->Text = _T("Clear Graph");
        graphingClearGraphButton->Location = Point(
            graphingClearLogButton->Right + 15,
            graphingClearLogButton->Top);
        graphingClearGraphButton->Size = graphingClearLogButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            graphingClearGraphButton,
            unitNumber);
        graphingClearGraphButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_GraphingClearGraphButtonClicked);
        graphingClearGraphButton->Enabled = GUI_NO;
        graphingWindow->Controls->Add(graphingClearGraphButton);
        graphingClearGraphButtonArray[unitNumber] = graphingClearGraphButton;
        //--------------------------------------------------------------------
        // Clear Graph button tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingClearGraphButtonToolTip = gcnew ToolTip;
        graphingClearGraphButtonToolTip->ShowAlways = GUI_YES;
        graphingClearGraphButtonToolTip->AutoPopDelay = 10000;
        graphingClearGraphButtonToolTip->ToolTipTitle =
            _T("Clear Graph");
        String ^graphingClearGraphButtonToolTipText = String::Concat(
            "Clears the plotting areas of the graph for", Environment::NewLine,
            "transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, ", but", Environment::NewLine,
            "does not affect logged data.");
        graphingClearGraphButtonToolTip->SetToolTip(graphingClearGraphButton, graphingClearGraphButtonToolTipText);
        delete graphingClearGraphButtonToolTipText;
        //--------------------------------------------------------------------
        // Pause / Resume button
        //--------------------------------------------------------------------
        Button ^graphingPauseResumeButton = gcnew Button;
        graphingPauseResumeButton->Text = GUI_PAUSE_ALL_STRING;
        graphingPauseResumeButton->Location = Point(
            graphingClearGraphButton->Right + 15,
            graphingClearGraphButton->Top);
        graphingPauseResumeButton->Size = graphingClearGraphButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            graphingPauseResumeButton,
            unitNumber);
        graphingPauseResumeButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_PauseResumeButtonClicked);
        graphingWindow->Controls->Add(graphingPauseResumeButton);
        graphingPauseResumeButtonArray[unitNumber] = graphingPauseResumeButton;
        //--------------------------------------------------------------------
        // Pause / Resume button tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingPauseResumeButtonToolTip = gcnew ToolTip;
        graphingPauseResumeButtonToolTip->ShowAlways = GUI_YES;
        graphingPauseResumeButtonToolTip->AutoPopDelay = 10000;
        graphingPauseResumeButtonToolTip->ToolTipTitle =
            _T("Pause / Resume");
        String ^graphingPauseResumeButtonToolTipText = String::Concat(
            "Pauses or resumes all active sampling, logging,", Environment::NewLine,
            "graphing, and testing for all units.");
        graphingPauseResumeButtonToolTip->SetToolTip(graphingPauseResumeButton, graphingPauseResumeButtonToolTipText);
        delete graphingPauseResumeButtonToolTipText;
        //--------------------------------------------------------------------
        // Save Graph button
        //--------------------------------------------------------------------
        Button ^graphingSaveGraphButton = gcnew Button;
        graphingSaveGraphButton->Text = _T("Save Graph");
        graphingSaveGraphButton->Location = Point(
            graphingPauseResumeButton->Right + 15,
            graphingPauseResumeButton->Top);
        graphingSaveGraphButton->Size = graphingPauseResumeButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            graphingSaveGraphButton,
            unitNumber);
        graphingSaveGraphButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_GraphingSaveGraphButtonClicked);
        graphingSaveGraphButton->Enabled = GUI_NO;
        graphingWindow->Controls->Add(graphingSaveGraphButton);
        graphingSaveGraphButtonArray[unitNumber] = graphingSaveGraphButton;
        //--------------------------------------------------------------------
        // Save Graph button tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingSaveGraphButtonToolTip = gcnew ToolTip;
        graphingSaveGraphButtonToolTip->ShowAlways = GUI_YES;
        graphingSaveGraphButtonToolTip->AutoPopDelay = 10000;
        graphingSaveGraphButtonToolTip->ToolTipTitle =
            _T("Save Graph");
        String ^graphingSaveGraphButtonToolTipText = String::Concat(
            "Saves or prints the graph for transducer ", unit->transducerSerialNumber, Environment::NewLine,
            "on module ", unit->moduleSerialNumber, ", including its parameters,", Environment::NewLine,
            "limits, and other pertinent information.");
        graphingSaveGraphButtonToolTip->SetToolTip(graphingSaveGraphButton, graphingSaveGraphButtonToolTipText);
        delete graphingSaveGraphButtonToolTipText;
        //--------------------------------------------------------------------
        // Time Between Samples label
        //--------------------------------------------------------------------
        Label ^graphingTimeBetweenSamplesLabel = gcnew Label;
        graphingTimeBetweenSamplesLabel->Location = Point(
            GUI_UNIT_GRAPH_BOX_WIDTH + 14,
            10);
        graphingTimeBetweenSamplesLabel->Size = Drawing::Size(
            GUI_UNIT_GRAPH_WINDOW_WIDTH - GUI_UNIT_GRAPH_BOX_WIDTH - 28,
            26);
        graphingTimeBetweenSamplesLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            12.0F,
            FontStyle::Bold);
        graphingTimeBetweenSamplesLabel->BackColor = Color::Transparent;
        graphingTimeBetweenSamplesLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        graphingWindow->Controls->Add(graphingTimeBetweenSamplesLabel);
        graphingTimeBetweenSamplesLabelArray[unitNumber] = graphingTimeBetweenSamplesLabel;
        //--------------------------------------------------------------------
        // Time Between Samples tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingTimeBetweenSamplesLabelToolTip = gcnew ToolTip;
        graphingTimeBetweenSamplesLabelToolTip->ShowAlways = GUI_YES;
        graphingTimeBetweenSamplesLabelToolTip->AutoPopDelay = 10000;
        graphingTimeBetweenSamplesLabelToolTip->ToolTipTitle =
            _T("Time Between Samples");
        String ^graphingTimeBetweenSamplesLabelToolTipText = String::Concat(
            "The amount of time between each sample displayed", Environment::NewLine,
            "on the graphs, and is set in the Readout tab.");
        graphingTimeBetweenSamplesLabelToolTip->SetToolTip(graphingTimeBetweenSamplesLabel, graphingTimeBetweenSamplesLabelToolTipText);
        delete graphingTimeBetweenSamplesLabelToolTipText;
        //--------------------------------------------------------------------
        // The graph box
        //--------------------------------------------------------------------
        PictureBox ^graphingPictureBox = gcnew PictureBox;
        graphingPictureBox->Tag = unitNumber;
        graphingPictureBox->Location = Point(
            graphingStartStopSamplingButton->Left,
            graphingStartStopSamplingButton->Bottom + 10);
        graphingPictureBox->Size = Drawing::Size(
            GUI_UNIT_GRAPH_BOX_WIDTH,
            GUI_UNIT_GRAPH_BOX_HEIGHT);
        graphingPictureBox->BorderStyle = BorderStyle::None;
        GUI_DisplayHandCursorOnHover(graphingPictureBox);
        graphingPictureBox->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_GraphingPictureBoxClicked);
        graphingWindow->Controls->Add(graphingPictureBox);
        graphingPictureBoxArray[unitNumber] = graphingPictureBox;
        //--------------------------------------------------------------------
        // Pressure low boundary
        //--------------------------------------------------------------------
        Label ^graphingPressureLowBoundaryLabel = gcnew Label;
        graphingPressureLowBoundaryLabel->Text = _T("Pressure low boundary:");
        graphingPressureLowBoundaryLabel->Location = Point(
            graphingPictureBox->Left,
            graphingPictureBox->Bottom + 6);
        graphingPressureLowBoundaryLabel->Size = Drawing::Size(
            148, GUI_REGULAR_LABEL_HEIGHT);
        graphingPressureLowBoundaryLabel->BackColor = Color::Transparent;
        graphingPressureLowBoundaryLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingPressureLowBoundaryLabel);
        //--------------------------------------------------------------------
        // Pressure low boundary text box
        //--------------------------------------------------------------------
        TextBox ^graphingPressureLowBoundaryBox = gcnew TextBox;
        graphingPressureLowBoundaryBox->Tag = unitNumber;
        graphingPressureLowBoundaryBox->Location = Point(
            graphingPressureLowBoundaryLabel->Right + 2,
            graphingPressureLowBoundaryLabel->Top - 2);
        graphingPressureLowBoundaryBox->Size = Drawing::Size(
            60, GUI_REGULAR_TEXT_BOX_HEIGHT);
        graphingPressureLowBoundaryBox->Multiline = GUI_NO;
        graphingPressureLowBoundaryBox->AcceptsReturn = GUI_NO;
        graphingPressureLowBoundaryBox->AcceptsTab = GUI_NO;
        graphingPressureLowBoundaryBox->WordWrap = GUI_NO;
        graphingPressureLowBoundaryBox->TextAlign = HorizontalAlignment::Right;
        graphingPressureLowBoundaryBox->BackColor = Color::White;
        graphingPressureLowBoundaryBox->Validating +=
            gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_GraphingValidatePressureLowBoundaryValue);
        graphingWindow->Controls->Add(graphingPressureLowBoundaryBox);
        graphingPressureLowBoundaryBoxArray[unitNumber] = graphingPressureLowBoundaryBox;
        //--------------------------------------------------------------------
        // Pressure low boundary units
        //--------------------------------------------------------------------
        Label ^graphingPressureLowBoundaryUnitsLabel = gcnew Label;
        graphingPressureLowBoundaryUnitsLabel->Location = Point(
            graphingPressureLowBoundaryBox->Right + 2,
            graphingPressureLowBoundaryLabel->Top);
        graphingPressureLowBoundaryUnitsLabel->Size = Drawing::Size(
            58, GUI_REGULAR_LABEL_HEIGHT);
        graphingPressureLowBoundaryUnitsLabel->BackColor = Color::Transparent;
        graphingPressureLowBoundaryUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingPressureLowBoundaryUnitsLabel);
        graphingPressureLowBoundaryUnitsLabelArray[unitNumber] = graphingPressureLowBoundaryUnitsLabel;
        //--------------------------------------------------------------------
        // Pressure low boundary tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingPressureLowBoundaryAreaToolTip = gcnew ToolTip;
        graphingPressureLowBoundaryAreaToolTip->ShowAlways = GUI_YES;
        graphingPressureLowBoundaryAreaToolTip->AutoPopDelay = 10000;
        graphingPressureLowBoundaryAreaToolTip->ToolTipTitle =
            _T("Pressure Low Boundary");
        String ^graphingPressureLowBoundaryAreaToolTipText = String::Concat(
            "The value of the lower dotted line on the", Environment::NewLine,
            "pressure graph.");
        graphingPressureLowBoundaryAreaToolTip->SetToolTip(graphingPressureLowBoundaryLabel, graphingPressureLowBoundaryAreaToolTipText);
        graphingPressureLowBoundaryAreaToolTip->SetToolTip(graphingPressureLowBoundaryBox, graphingPressureLowBoundaryAreaToolTipText);
        graphingPressureLowBoundaryAreaToolTip->SetToolTip(graphingPressureLowBoundaryUnitsLabel, graphingPressureLowBoundaryAreaToolTipText);
        delete graphingPressureLowBoundaryAreaToolTipText;
        //--------------------------------------------------------------------
        // Pressure high boundary
        //--------------------------------------------------------------------
        Label ^graphingPressureHighBoundaryLabel = gcnew Label;
        graphingPressureHighBoundaryLabel->Text = _T("Pressure high boundary:");
        graphingPressureHighBoundaryLabel->Location = Point(
            graphingPressureLowBoundaryUnitsLabel->Right + 30,
            graphingPressureLowBoundaryUnitsLabel->Top);
        graphingPressureHighBoundaryLabel->Size = graphingPressureLowBoundaryLabel->Size;
        graphingPressureHighBoundaryLabel->BackColor = Color::Transparent;
        graphingPressureHighBoundaryLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingPressureHighBoundaryLabel);
        //--------------------------------------------------------------------
        // Pressure high boundary text box
        //--------------------------------------------------------------------
        TextBox ^graphingPressureHighBoundaryBox = gcnew TextBox;
        graphingPressureHighBoundaryBox->Tag = unitNumber;
        graphingPressureHighBoundaryBox->Location = Point(
            graphingPressureHighBoundaryLabel->Right + 2,
            graphingPressureHighBoundaryLabel->Top - 2);
        graphingPressureHighBoundaryBox->Size = graphingPressureLowBoundaryBox->Size;
        graphingPressureHighBoundaryBox->Multiline = GUI_NO;
        graphingPressureHighBoundaryBox->AcceptsReturn = GUI_NO;
        graphingPressureHighBoundaryBox->AcceptsTab = GUI_NO;
        graphingPressureHighBoundaryBox->WordWrap = GUI_NO;
        graphingPressureHighBoundaryBox->TextAlign = HorizontalAlignment::Right;
        graphingPressureHighBoundaryBox->BackColor = Color::White;
        graphingPressureHighBoundaryBox->Validating +=
            gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_GraphingValidatePressureHighBoundaryValue);
        graphingWindow->Controls->Add(graphingPressureHighBoundaryBox);
        graphingPressureHighBoundaryBoxArray[unitNumber] = graphingPressureHighBoundaryBox;
        //--------------------------------------------------------------------
        // Pressure high boundary units
        //--------------------------------------------------------------------
        Label ^graphingPressureHighBoundaryUnitsLabel = gcnew Label;
        graphingPressureHighBoundaryUnitsLabel->Location = Point(
            graphingPressureHighBoundaryBox->Right + 2,
            graphingPressureHighBoundaryLabel->Top);
        graphingPressureHighBoundaryUnitsLabel->Size = graphingPressureLowBoundaryUnitsLabel->Size;
        graphingPressureHighBoundaryUnitsLabel->BackColor = Color::Transparent;
        graphingPressureHighBoundaryUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingPressureHighBoundaryUnitsLabel);
        graphingPressureHighBoundaryUnitsLabelArray[unitNumber] = graphingPressureHighBoundaryUnitsLabel;
        //--------------------------------------------------------------------
        // Pressure high boundary tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingPressureHighBoundaryAreaToolTip = gcnew ToolTip;
        graphingPressureHighBoundaryAreaToolTip->ShowAlways = GUI_YES;
        graphingPressureHighBoundaryAreaToolTip->AutoPopDelay = 10000;
        graphingPressureHighBoundaryAreaToolTip->ToolTipTitle =
            _T("Pressure High Boundary");
        String ^graphingPressureHighBoundaryAreaToolTipText = String::Concat(
            "The value of the upper dotted line on the", Environment::NewLine,
            "pressure graph.");
        graphingPressureHighBoundaryAreaToolTip->SetToolTip(graphingPressureHighBoundaryLabel, graphingPressureHighBoundaryAreaToolTipText);
        graphingPressureHighBoundaryAreaToolTip->SetToolTip(graphingPressureHighBoundaryBox, graphingPressureHighBoundaryAreaToolTipText);
        graphingPressureHighBoundaryAreaToolTip->SetToolTip(graphingPressureHighBoundaryUnitsLabel, graphingPressureHighBoundaryAreaToolTipText);
        delete graphingPressureHighBoundaryAreaToolTipText;
        //--------------------------------------------------------------------
        // Temperature low boundary
        //--------------------------------------------------------------------
        Label ^graphingTemperatureLowBoundaryLabel = gcnew Label;
        graphingTemperatureLowBoundaryLabel->Text = _T("Temperature low boundary:");
        GUI_PositionAndSizeBelow(
            graphingTemperatureLowBoundaryLabel,
            graphingPressureLowBoundaryLabel,
            6);
        graphingTemperatureLowBoundaryLabel->BackColor = Color::Transparent;
        graphingTemperatureLowBoundaryLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingTemperatureLowBoundaryLabel);
        //--------------------------------------------------------------------
        // Temperature low boundary text box
        //--------------------------------------------------------------------
        TextBox ^graphingTemperatureLowBoundaryBox = gcnew TextBox;
        graphingTemperatureLowBoundaryBox->Tag = unitNumber;
        graphingTemperatureLowBoundaryBox->Location = Point(
            graphingTemperatureLowBoundaryLabel->Right + 2,
            graphingTemperatureLowBoundaryLabel->Top - 2);
        graphingTemperatureLowBoundaryBox->Size = graphingPressureLowBoundaryBox->Size;
        graphingTemperatureLowBoundaryBox->Multiline = GUI_NO;
        graphingTemperatureLowBoundaryBox->AcceptsReturn = GUI_NO;
        graphingTemperatureLowBoundaryBox->AcceptsTab = GUI_NO;
        graphingTemperatureLowBoundaryBox->WordWrap = GUI_NO;
        graphingTemperatureLowBoundaryBox->TextAlign = HorizontalAlignment::Right;
        graphingTemperatureLowBoundaryBox->BackColor = Color::White;
        graphingTemperatureLowBoundaryBox->Validating +=
            gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_GraphingValidateTemperatureLowBoundaryValue);
        graphingWindow->Controls->Add(graphingTemperatureLowBoundaryBox);
        graphingTemperatureLowBoundaryBoxArray[unitNumber] = graphingTemperatureLowBoundaryBox;
        //--------------------------------------------------------------------
        // Temperature low boundary units
        //--------------------------------------------------------------------
        Label ^graphingTemperatureLowBoundaryUnitsLabel = gcnew Label;
        graphingTemperatureLowBoundaryUnitsLabel->Location = Point(
            graphingTemperatureLowBoundaryBox->Right + 2,
            graphingTemperatureLowBoundaryLabel->Top);
        graphingTemperatureLowBoundaryUnitsLabel->Size = graphingPressureLowBoundaryUnitsLabel->Size;
        graphingTemperatureLowBoundaryUnitsLabel->BackColor = Color::Transparent;
        graphingTemperatureLowBoundaryUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingTemperatureLowBoundaryUnitsLabel);
        graphingTemperatureLowBoundaryUnitsLabelArray[unitNumber] = graphingTemperatureLowBoundaryUnitsLabel;
        //--------------------------------------------------------------------
        // Temperature low boundary tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingTemperatureLowBoundaryAreaToolTip = gcnew ToolTip;
        graphingTemperatureLowBoundaryAreaToolTip->ShowAlways = GUI_YES;
        graphingTemperatureLowBoundaryAreaToolTip->AutoPopDelay = 10000;
        graphingTemperatureLowBoundaryAreaToolTip->ToolTipTitle =
            _T("Temperature Low Boundary");
        String ^graphingTemperatureLowBoundaryAreaToolTipText = String::Concat(
            "The value of the lower dotted line on the", Environment::NewLine,
            "temperature graph.");
        graphingTemperatureLowBoundaryAreaToolTip->SetToolTip(graphingTemperatureLowBoundaryLabel, graphingTemperatureLowBoundaryAreaToolTipText);
        graphingTemperatureLowBoundaryAreaToolTip->SetToolTip(graphingTemperatureLowBoundaryBox, graphingTemperatureLowBoundaryAreaToolTipText);
        graphingTemperatureLowBoundaryAreaToolTip->SetToolTip(graphingTemperatureLowBoundaryUnitsLabel, graphingTemperatureLowBoundaryAreaToolTipText);
        delete graphingTemperatureLowBoundaryAreaToolTipText;
        //--------------------------------------------------------------------
        // Temperature high boundary
        //--------------------------------------------------------------------
        Label ^graphingTemperatureHighBoundaryLabel = gcnew Label;
        graphingTemperatureHighBoundaryLabel->Text = _T("Temperature high boundary:");
        graphingTemperatureHighBoundaryLabel->Location = Point(
            graphingTemperatureLowBoundaryUnitsLabel->Right + 30,
            graphingTemperatureLowBoundaryUnitsLabel->Top);
        graphingTemperatureHighBoundaryLabel->Size = graphingTemperatureLowBoundaryLabel->Size;
        graphingTemperatureHighBoundaryLabel->BackColor = Color::Transparent;
        graphingTemperatureHighBoundaryLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingTemperatureHighBoundaryLabel);
        //--------------------------------------------------------------------
        // Temperature high boundary text box
        //--------------------------------------------------------------------
        TextBox ^graphingTemperatureHighBoundaryBox = gcnew TextBox;
        graphingTemperatureHighBoundaryBox->Tag = unitNumber;
        graphingTemperatureHighBoundaryBox->Location = Point(
            graphingTemperatureHighBoundaryLabel->Right + 2,
            graphingTemperatureHighBoundaryLabel->Top - 2);
        graphingTemperatureHighBoundaryBox->Size = graphingPressureHighBoundaryBox->Size;
        graphingTemperatureHighBoundaryBox->Multiline = GUI_NO;
        graphingTemperatureHighBoundaryBox->AcceptsReturn = GUI_NO;
        graphingTemperatureHighBoundaryBox->AcceptsTab = GUI_NO;
        graphingTemperatureHighBoundaryBox->WordWrap = GUI_NO;
        graphingTemperatureHighBoundaryBox->TextAlign = HorizontalAlignment::Right;
        graphingTemperatureHighBoundaryBox->BackColor = Color::White;
        graphingTemperatureHighBoundaryBox->Validating +=
            gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_GraphingValidateTemperatureHighBoundaryValue);
        graphingWindow->Controls->Add(graphingTemperatureHighBoundaryBox);
        graphingTemperatureHighBoundaryBoxArray[unitNumber] = graphingTemperatureHighBoundaryBox;
        //--------------------------------------------------------------------
        // Temperature high boundary units
        //--------------------------------------------------------------------
        Label ^graphingTemperatureHighBoundaryUnitsLabel = gcnew Label;
        graphingTemperatureHighBoundaryUnitsLabel->Location = Point(
            graphingTemperatureHighBoundaryBox->Right + 2,
            graphingTemperatureHighBoundaryLabel->Top);
        graphingTemperatureHighBoundaryUnitsLabel->Size = graphingPressureHighBoundaryUnitsLabel->Size;
        graphingTemperatureHighBoundaryUnitsLabel->BackColor = Color::Transparent;
        graphingTemperatureHighBoundaryUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingTemperatureHighBoundaryUnitsLabel);
        graphingTemperatureHighBoundaryUnitsLabelArray[unitNumber] = graphingTemperatureHighBoundaryUnitsLabel;
        //--------------------------------------------------------------------
        // Temperature high boundary tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingTemperatureHighBoundaryAreaToolTip = gcnew ToolTip;
        graphingTemperatureHighBoundaryAreaToolTip->ShowAlways = GUI_YES;
        graphingTemperatureHighBoundaryAreaToolTip->AutoPopDelay = 10000;
        graphingTemperatureHighBoundaryAreaToolTip->ToolTipTitle =
            _T("Temperature High Boundary");
        String ^graphingTemperatureHighBoundaryAreaToolTipText = String::Concat(
            "The value of the upper dotted line on the", Environment::NewLine,
            "temperature graph.");
        graphingTemperatureHighBoundaryAreaToolTip->SetToolTip(graphingTemperatureHighBoundaryLabel, graphingTemperatureHighBoundaryAreaToolTipText);
        graphingTemperatureHighBoundaryAreaToolTip->SetToolTip(graphingTemperatureHighBoundaryBox, graphingTemperatureHighBoundaryAreaToolTipText);
        graphingTemperatureHighBoundaryAreaToolTip->SetToolTip(graphingTemperatureHighBoundaryUnitsLabel, graphingTemperatureHighBoundaryAreaToolTipText);
        delete graphingTemperatureHighBoundaryAreaToolTipText;
        //--------------------------------------------------------------------
        // Current low boundary
        //--------------------------------------------------------------------
        Label ^graphingAmperageLowBoundaryLabel = gcnew Label;
        graphingAmperageLowBoundaryLabel->Text = _T("Current low boundary:");
        GUI_PositionAndSizeBelow(
            graphingAmperageLowBoundaryLabel,
            graphingTemperatureLowBoundaryLabel,
            6);
        graphingAmperageLowBoundaryLabel->BackColor = Color::Transparent;
        graphingAmperageLowBoundaryLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingAmperageLowBoundaryLabel);
        graphingAmperageLowBoundaryLabelArray[unitNumber] = graphingAmperageLowBoundaryLabel;
        //--------------------------------------------------------------------
        // Current low boundary text box
        //--------------------------------------------------------------------
        TextBox ^graphingAmperageLowBoundaryBox = gcnew TextBox;
        graphingAmperageLowBoundaryBox->Tag = unitNumber;
        graphingAmperageLowBoundaryBox->Location = Point(
            graphingAmperageLowBoundaryLabel->Right + 2,
            graphingAmperageLowBoundaryLabel->Top - 2);
        graphingAmperageLowBoundaryBox->Size = graphingTemperatureLowBoundaryBox->Size;
        graphingAmperageLowBoundaryBox->Multiline = GUI_NO;
        graphingAmperageLowBoundaryBox->AcceptsReturn = GUI_NO;
        graphingAmperageLowBoundaryBox->AcceptsTab = GUI_NO;
        graphingAmperageLowBoundaryBox->WordWrap = GUI_NO;
        graphingAmperageLowBoundaryBox->TextAlign = HorizontalAlignment::Right;
        graphingAmperageLowBoundaryBox->BackColor = Color::White;
        graphingAmperageLowBoundaryBox->Validating +=
            gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_GraphingValidateAmperageLowBoundaryValue);
        graphingWindow->Controls->Add(graphingAmperageLowBoundaryBox);
        graphingAmperageLowBoundaryBoxArray[unitNumber] = graphingAmperageLowBoundaryBox;
        //--------------------------------------------------------------------
        // Current low boundary units
        //--------------------------------------------------------------------
        Label ^graphingAmperageLowBoundaryUnitsLabel = gcnew Label;
        graphingAmperageLowBoundaryUnitsLabel->Text = QCOM_AmperageUnitsStringArray[QCOM_AMPERAGE_UNITS_DEFAULT];
        graphingAmperageLowBoundaryUnitsLabel->Location = Point(
            graphingAmperageLowBoundaryBox->Right + 2,
            graphingAmperageLowBoundaryLabel->Top);
        graphingAmperageLowBoundaryUnitsLabel->Size = graphingTemperatureLowBoundaryUnitsLabel->Size;
        graphingAmperageLowBoundaryUnitsLabel->BackColor = Color::Transparent;
        graphingAmperageLowBoundaryUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingAmperageLowBoundaryUnitsLabel);
        graphingAmperageLowBoundaryUnitsLabelArray[unitNumber] = graphingAmperageLowBoundaryUnitsLabel;
        //--------------------------------------------------------------------
        // Current low boundary tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingAmperageLowBoundaryAreaToolTip = gcnew ToolTip;
        graphingAmperageLowBoundaryAreaToolTip->ShowAlways = GUI_YES;
        graphingAmperageLowBoundaryAreaToolTip->AutoPopDelay = 10000;
        graphingAmperageLowBoundaryAreaToolTip->ToolTipTitle =
            _T("Current Low Boundary");
        String ^graphingAmperageLowBoundaryAreaToolTipText = String::Concat(
            "The value of the lower dotted line on the", Environment::NewLine,
            "current graph.");
        graphingAmperageLowBoundaryAreaToolTip->SetToolTip(graphingAmperageLowBoundaryLabel, graphingAmperageLowBoundaryAreaToolTipText);
        graphingAmperageLowBoundaryAreaToolTip->SetToolTip(graphingAmperageLowBoundaryBox, graphingAmperageLowBoundaryAreaToolTipText);
        graphingAmperageLowBoundaryAreaToolTip->SetToolTip(graphingAmperageLowBoundaryUnitsLabel, graphingAmperageLowBoundaryAreaToolTipText);
        delete graphingAmperageLowBoundaryAreaToolTipText;
        //--------------------------------------------------------------------
        // Current high boundary
        //--------------------------------------------------------------------
        Label ^graphingAmperageHighBoundaryLabel = gcnew Label;
        graphingAmperageHighBoundaryLabel->Text = _T("Current high boundary:");
        graphingAmperageHighBoundaryLabel->Location = Point(
            graphingAmperageLowBoundaryUnitsLabel->Right + 30,
            graphingAmperageLowBoundaryUnitsLabel->Top);
        graphingAmperageHighBoundaryLabel->Size = graphingAmperageLowBoundaryLabel->Size;
        graphingAmperageHighBoundaryLabel->BackColor = Color::Transparent;
        graphingAmperageHighBoundaryLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingAmperageHighBoundaryLabel);
        graphingAmperageHighBoundaryLabelArray[unitNumber] = graphingAmperageHighBoundaryLabel;
        //--------------------------------------------------------------------
        // Current high boundary text box
        //--------------------------------------------------------------------
        TextBox ^graphingAmperageHighBoundaryBox = gcnew TextBox;
        graphingAmperageHighBoundaryBox->Tag = unitNumber;
        graphingAmperageHighBoundaryBox->Location = Point(
            graphingAmperageHighBoundaryLabel->Right + 2,
            graphingAmperageHighBoundaryLabel->Top - 2);
        graphingAmperageHighBoundaryBox->Size = graphingTemperatureHighBoundaryBox->Size;
        graphingAmperageHighBoundaryBox->Multiline = GUI_NO;
        graphingAmperageHighBoundaryBox->AcceptsReturn = GUI_NO;
        graphingAmperageHighBoundaryBox->AcceptsTab = GUI_NO;
        graphingAmperageHighBoundaryBox->WordWrap = GUI_NO;
        graphingAmperageHighBoundaryBox->TextAlign = HorizontalAlignment::Right;
        graphingAmperageHighBoundaryBox->BackColor = Color::White;
        graphingAmperageHighBoundaryBox->Validating +=
            gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_GraphingValidateAmperageHighBoundaryValue);
        graphingWindow->Controls->Add(graphingAmperageHighBoundaryBox);
        graphingAmperageHighBoundaryBoxArray[unitNumber] = graphingAmperageHighBoundaryBox;
        //--------------------------------------------------------------------
        // Current high boundary units
        //--------------------------------------------------------------------
        Label ^graphingAmperageHighBoundaryUnitsLabel = gcnew Label;
        graphingAmperageHighBoundaryUnitsLabel->Text = QCOM_AmperageUnitsStringArray[QCOM_AMPERAGE_UNITS_DEFAULT];
        graphingAmperageHighBoundaryUnitsLabel->Location = Point(
            graphingAmperageHighBoundaryBox->Right + 2,
            graphingAmperageHighBoundaryLabel->Top);
        graphingAmperageHighBoundaryUnitsLabel->Size = graphingAmperageLowBoundaryUnitsLabel->Size;
        graphingAmperageHighBoundaryUnitsLabel->BackColor = Color::Transparent;
        graphingAmperageHighBoundaryUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingAmperageHighBoundaryUnitsLabel);
        graphingAmperageHighBoundaryUnitsLabelArray[unitNumber] = graphingAmperageHighBoundaryUnitsLabel;
        //--------------------------------------------------------------------
        // Current high boundary tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingAmperageHighBoundaryAreaToolTip = gcnew ToolTip;
        graphingAmperageHighBoundaryAreaToolTip->ShowAlways = GUI_YES;
        graphingAmperageHighBoundaryAreaToolTip->AutoPopDelay = 10000;
        graphingAmperageHighBoundaryAreaToolTip->ToolTipTitle =
            _T("Current High Boundary");
        String ^graphingAmperageHighBoundaryAreaToolTipText = String::Concat(
            "The value of the upper dotted line on the", Environment::NewLine,
            "current graph.");
        graphingAmperageHighBoundaryAreaToolTip->SetToolTip(graphingAmperageHighBoundaryLabel, graphingAmperageHighBoundaryAreaToolTipText);
        graphingAmperageHighBoundaryAreaToolTip->SetToolTip(graphingAmperageHighBoundaryBox, graphingAmperageHighBoundaryAreaToolTipText);
        graphingAmperageHighBoundaryAreaToolTip->SetToolTip(graphingAmperageHighBoundaryUnitsLabel, graphingAmperageHighBoundaryAreaToolTipText);
        delete graphingAmperageHighBoundaryAreaToolTipText;
        //--------------------------------------------------------------------
        // Reset Boundary Values button
        //--------------------------------------------------------------------
        Button ^graphingResetBoundaryValuesButton = gcnew Button;
        graphingResetBoundaryValuesButton->Text = _T("Reset Boundary\nValues to Defaults");
        graphingResetBoundaryValuesButton->Size = Drawing::Size(
            104,
            GUI_DOUBLE_BUTTON_HEIGHT);
        graphingResetBoundaryValuesButton->Location = Point(
            graphingPictureBox->Right - graphingResetBoundaryValuesButton->Width,
            graphingPictureBox->Bottom + 6);
        GUI_SetUnitButtonInterfaceProperties(
            graphingResetBoundaryValuesButton,
            unitNumber);
        graphingResetBoundaryValuesButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_GraphingSetDefaultBoundaryValuesButtonClicked);
        graphingWindow->Controls->Add(graphingResetBoundaryValuesButton);
        //--------------------------------------------------------------------
        // Reset Boundary Values button tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingResetBoundaryValuesButtonToolTip = gcnew ToolTip;
        graphingResetBoundaryValuesButtonToolTip->ShowAlways = GUI_YES;
        graphingResetBoundaryValuesButtonToolTip->AutoPopDelay = 10000;
        graphingResetBoundaryValuesButtonToolTip->ToolTipTitle =
            _T("Reset Boundary Values");
        String ^graphingResetBoundaryValuesButtonToolTipText = String::Concat(
            "Resets the high and low graphing boundary values for", Environment::NewLine,
            "transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, " to their defaults.");
        graphingResetBoundaryValuesButtonToolTip->SetToolTip(graphingResetBoundaryValuesButton, graphingResetBoundaryValuesButtonToolTipText);
        delete graphingResetBoundaryValuesButtonToolTipText;
        //--------------------------------------------------------------------
        // Single Step button
        //--------------------------------------------------------------------
        Button ^graphingSingleStepButton = gcnew Button;
        graphingSingleStepButton->Text = _T("Single Step");
        GUI_PositionBelow(
            graphingSingleStepButton,
            graphingResetBoundaryValuesButton,
            3);
        graphingSingleStepButton->Size = Drawing::Size(
            graphingResetBoundaryValuesButton->Width,
            GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            graphingSingleStepButton,
            unitNumber);
        graphingSingleStepButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_GraphingSingleStepButtonClicked);
        graphingWindow->Controls->Add(graphingSingleStepButton);
        graphingSingleStepButtonArray[unitNumber] = graphingSingleStepButton;
        //--------------------------------------------------------------------
        // Single Step button tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingSingleStepButtonToolTip = gcnew ToolTip;
        graphingSingleStepButtonToolTip->ShowAlways = GUI_YES;
        graphingSingleStepButtonToolTip->AutoPopDelay = 10000;
        graphingSingleStepButtonToolTip->ToolTipTitle =
            _T("Single Step");
        String ^graphingSingleStepButtonToolTipText = String::Concat(
            "Plots a single snapshot of the set of data currently", Environment::NewLine,
            "selected to display on both the values and the graphs", Environment::NewLine,
            "for transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, ". This will", Environment::NewLine,
            "stop the sampling if it is currently running.");
        graphingSingleStepButtonToolTip->SetToolTip(graphingSingleStepButton, graphingSingleStepButtonToolTipText);
        delete graphingSingleStepButtonToolTipText;
        //--------------------------------------------------------------------
        // Pressure graph measurement and units labels
        //--------------------------------------------------------------------
        Label ^graphingPressureLabel = gcnew Label;
        graphingPressureLabel->Text = _T("Pressure");
        graphingPressureLabel->Location = Point(
            graphingPictureBox->Right + 10,
            graphingPictureBox->Top);
        graphingPressureLabel->Size = Drawing::Size(110, 26);
        graphingPressureLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            12.0F,
            FontStyle::Bold);
        graphingPressureLabel->ForeColor = Color::Blue;
        graphingPressureLabel->BackColor = Color::Transparent;
        graphingPressureLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingPressureLabel);
        //--------------------------------------------------------------------
        Label ^graphingPressureUnitsLabel = gcnew Label;
        graphingPressureUnitsLabel->Location = Point(
            graphingPressureLabel->Right + 2,
            graphingPressureLabel->Top);
        graphingPressureUnitsLabel->Size = Drawing::Size(
            GUI_UNIT_GRAPH_WINDOW_WIDTH - graphingPictureBox->Width - 42 - graphingPressureLabel->Width,
            graphingPressureLabel->Height);
        graphingPressureUnitsLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            14.0F,
            FontStyle::Bold);
        graphingPressureUnitsLabel->ForeColor = Color::Black;
        graphingPressureUnitsLabel->BackColor = Color::Transparent;
        graphingPressureUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleRight;
        graphingWindow->Controls->Add(graphingPressureUnitsLabel);
        graphingPressureUnitsLabelArray[unitNumber] = graphingPressureUnitsLabel;
        //--------------------------------------------------------------------
        Label ^graphingPressureValueLabel = gcnew Label;
        graphingPressureValueLabel->Location = Point(
            graphingPressureLabel->Left,
            graphingPressureLabel->Bottom + 2);
        graphingPressureValueLabel->Size = Drawing::Size(
            graphingPressureLabel->Width + graphingPressureUnitsLabel->Width + 2, 66);
        graphingPressureValueLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            54.0F,
            FontStyle::Bold);
        graphingPressureValueLabel->BackColor = Color::Transparent;
        graphingPressureValueLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        graphingWindow->Controls->Add(graphingPressureValueLabel);
        graphingPressureValueLabelArray[unitNumber] = graphingPressureValueLabel;
        //--------------------------------------------------------------------
        // Temperature graph measurement and units labels
        //--------------------------------------------------------------------
        Label ^graphingTemperatureLabel = gcnew Label;
        graphingTemperatureLabel->Text = _T("Temperature");
        graphingTemperatureLabel->Location = Point(
            graphingPressureValueLabel->Left,
            graphingPressureValueLabel->Bottom + 15);
        graphingTemperatureLabel->Size = graphingPressureLabel->Size;
        graphingTemperatureLabel->Font = graphingPressureLabel->Font;
        graphingTemperatureLabel->ForeColor = Color::Green;
        graphingTemperatureLabel->BackColor = Color::Transparent;
        graphingTemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingTemperatureLabel);
        //--------------------------------------------------------------------
        Label ^graphingTemperatureUnitsLabel = gcnew Label;
        graphingTemperatureUnitsLabel->Location = Point(
            graphingTemperatureLabel->Right + 2,
            graphingTemperatureLabel->Top);
        graphingTemperatureUnitsLabel->Size = graphingPressureUnitsLabel->Size;
        graphingTemperatureUnitsLabel->Font = graphingPressureUnitsLabel->Font;
        graphingTemperatureUnitsLabel->ForeColor = Color::Black;
        graphingTemperatureUnitsLabel->BackColor = Color::Transparent;
        graphingTemperatureUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleRight;
        graphingWindow->Controls->Add(graphingTemperatureUnitsLabel);
        graphingTemperatureUnitsLabelArray[unitNumber] = graphingTemperatureUnitsLabel;
        //--------------------------------------------------------------------
        Label ^graphingTemperatureValueLabel = gcnew Label;
        graphingTemperatureValueLabel->Location = Point(
            graphingTemperatureLabel->Left,
            graphingTemperatureLabel->Bottom + 2);
        graphingTemperatureValueLabel->Size = graphingPressureValueLabel->Size;
        graphingTemperatureValueLabel->Font = graphingPressureValueLabel->Font;
        graphingTemperatureValueLabel->BackColor = Color::Transparent;
        graphingTemperatureValueLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        graphingWindow->Controls->Add(graphingTemperatureValueLabel);
        graphingTemperatureValueLabelArray[unitNumber] = graphingTemperatureValueLabel;
        //--------------------------------------------------------------------
        // Current graph measurement and units labels
        //--------------------------------------------------------------------
        Label ^graphingAmperageLabel = gcnew Label;
        graphingAmperageLabel->Text = _T("Current");
        graphingAmperageLabel->Location = Point(
            graphingTemperatureValueLabel->Left,
            graphingTemperatureValueLabel->Bottom + 15);
        graphingAmperageLabel->Size = graphingTemperatureLabel->Size;
        graphingAmperageLabel->Font = graphingTemperatureLabel->Font;
        graphingAmperageLabel->ForeColor = Color::DeepPink;
        graphingAmperageLabel->BackColor = Color::Transparent;
        graphingAmperageLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingAmperageLabel);
        graphingAmperageLabelArray[unitNumber] = graphingAmperageLabel;
        //--------------------------------------------------------------------
        Label ^graphingAmperageUnitsLabel = gcnew Label;
        graphingAmperageUnitsLabel->Text = QCOM_AmperageUnitsStringArray[QCOM_AMPERAGE_UNITS_DEFAULT];
        graphingAmperageUnitsLabel->Location = Point(
            graphingAmperageLabel->Right + 2,
            graphingAmperageLabel->Top);
        graphingAmperageUnitsLabel->Size = graphingTemperatureUnitsLabel->Size;
        graphingAmperageUnitsLabel->Font = graphingTemperatureUnitsLabel->Font;
        graphingAmperageUnitsLabel->ForeColor = Color::Black;
        graphingAmperageUnitsLabel->BackColor = Color::Transparent;
        graphingAmperageUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleRight;
        graphingWindow->Controls->Add(graphingAmperageUnitsLabel);
        graphingAmperageUnitsLabelArray[unitNumber] = graphingAmperageUnitsLabel;
        //--------------------------------------------------------------------
        Label ^graphingAmperageValueLabel = gcnew Label;
        graphingAmperageValueLabel->Location = Point(
            graphingAmperageLabel->Left,
            graphingAmperageLabel->Bottom + 2);
        graphingAmperageValueLabel->Size = graphingTemperatureValueLabel->Size;
        graphingAmperageValueLabel->Font = graphingTemperatureValueLabel->Font;
        graphingAmperageValueLabel->BackColor = Color::Transparent;
        graphingAmperageValueLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        graphingWindow->Controls->Add(graphingAmperageValueLabel);
        graphingAmperageValueLabelArray[unitNumber] = graphingAmperageValueLabel;
        if (unit->graphingFlags & QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW)
        {
            graphingAmperageLabel->Visible = GUI_YES;
            graphingAmperageUnitsLabel->Visible = GUI_YES;
            graphingAmperageValueLabel->Visible = GUI_YES;
            graphingAmperageHighBoundaryLabel->Visible = GUI_YES;
            graphingAmperageHighBoundaryBox->Visible = GUI_YES;
            graphingAmperageHighBoundaryUnitsLabel->Visible = GUI_YES;
            graphingAmperageLowBoundaryLabel->Visible = GUI_YES;
            graphingAmperageLowBoundaryBox->Visible = GUI_YES;
            graphingAmperageLowBoundaryUnitsLabel->Visible = GUI_YES;
        }
        else
        {
            graphingAmperageLabel->Visible = GUI_NO;
            graphingAmperageUnitsLabel->Visible = GUI_NO;
            graphingAmperageValueLabel->Visible = GUI_NO;
            graphingAmperageHighBoundaryLabel->Visible = GUI_NO;
            graphingAmperageHighBoundaryBox->Visible = GUI_NO;
            graphingAmperageHighBoundaryUnitsLabel->Visible = GUI_NO;
            graphingAmperageLowBoundaryLabel->Visible = GUI_NO;
            graphingAmperageLowBoundaryBox->Visible = GUI_NO;
            graphingAmperageLowBoundaryUnitsLabel->Visible = GUI_NO;
        }
        //--------------------------------------------------------------------
        // Default and alternate units group box and radio buttons
        //--------------------------------------------------------------------
        GroupBox ^graphingPTUnitsGroupBox = gcnew GroupBox;
        graphingPTUnitsGroupBox->Size = Drawing::Size(225, 44);
        graphingPTUnitsGroupBox->Location = Point(
            graphingWindow->Width - graphingPTUnitsGroupBox->Width - 20,
            graphingWindow->Bottom - 223);
        graphingPTUnitsGroupBox->ForeColor = Color::Black;
        graphingPTUnitsGroupBox->BackColor = Color::Transparent;
        graphingWindow->Controls->Add(graphingPTUnitsGroupBox);
        //--------------------------------------------------------------------
        RadioButton ^graphingDefaultPTUnitsRadio = gcnew RadioButton;
        graphingDefaultPTUnitsRadio->Location = Point(5, 8);
        graphingDefaultPTUnitsRadio->Size = Drawing::Size(
            160, GUI_REGULAR_RADIO_BUTTON_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            graphingDefaultPTUnitsRadio,
            unitNumber);
        graphingDefaultPTUnitsRadio->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutDefaultPressureTemperatureRadioSelected);
        graphingPTUnitsGroupBox->Controls->Add(graphingDefaultPTUnitsRadio);
        graphingDefaultPTUnitsRadioArray[unitNumber] = graphingDefaultPTUnitsRadio;
        //--------------------------------------------------------------------
        RadioButton ^graphingAlternatePTUnitsRadio = gcnew RadioButton;
        GUI_PositionAndSizeBelow(
            graphingAlternatePTUnitsRadio,
            graphingDefaultPTUnitsRadio,
            2);
        GUI_SetUnitObjectInterfaceProperties(
            graphingAlternatePTUnitsRadio,
            unitNumber);
        graphingAlternatePTUnitsRadio->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutAlternatePressureTemperatureRadioSelected);
        graphingPTUnitsGroupBox->Controls->Add(graphingAlternatePTUnitsRadio);
        graphingAlternatePTUnitsRadioArray[unitNumber] = graphingAlternatePTUnitsRadio;
        //--------------------------------------------------------------------
        // Default and Alternate Units group box tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingPTUnitsAreaToolTip = gcnew ToolTip;
        graphingPTUnitsAreaToolTip->ShowAlways = GUI_YES;
        graphingPTUnitsAreaToolTip->AutoPopDelay = 10000;
        graphingPTUnitsAreaToolTip->ToolTipTitle =
            _T("Pressure / Temperature Units");
        String ^graphingPTUnitsAreaToolTipText = String::Concat(
            "Controls the pressure and temperature measurement", Environment::NewLine,
            "units of the values that are displayed and graphed for", Environment::NewLine,
            "all modules and transducers. Select default (", QCOM_PressureUnitsStringArray[QCOM_DefaultPressureUnits], " / ",
            QCOM_TemperatureUnitsStringArray[QCOM_DefaultTemperatureUnits], ") ", Environment::NewLine,
            "or alternate (", QCOM_PressureUnitsStringArray[QCOM_AlternatePressureUnits], " / ",
            QCOM_TemperatureUnitsStringArray[QCOM_AlternateTemperatureUnits], ") units. You can select alternate", Environment::NewLine,
            "units from the Readout tab main window.");
        graphingPTUnitsAreaToolTip->SetToolTip(graphingPTUnitsGroupBox, graphingPTUnitsAreaToolTipText);
        graphingPTUnitsAreaToolTip->SetToolTip(graphingDefaultPTUnitsRadio, graphingPTUnitsAreaToolTipText);
        graphingPTUnitsAreaToolTip->SetToolTip(graphingAlternatePTUnitsRadio, graphingPTUnitsAreaToolTipText);
        delete graphingPTUnitsAreaToolTipText;
        //--------------------------------------------------------------------
        // Military Time Format check box
        //--------------------------------------------------------------------
        CheckBox ^graphingMilitaryTimeFormatCheck = gcnew CheckBox;
        graphingMilitaryTimeFormatCheck->Text = _T("Military time format");
        GUI_PositionBelow(
            graphingMilitaryTimeFormatCheck,
            graphingPTUnitsGroupBox,
            4);
        graphingMilitaryTimeFormatCheck->Size = Drawing::Size(
            graphingPTUnitsGroupBox->Width,
            GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            graphingMilitaryTimeFormatCheck,
            unitNumber);
        graphingMilitaryTimeFormatCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_GraphingMilitaryTimeFormatChecked);
        graphingWindow->Controls->Add(graphingMilitaryTimeFormatCheck);
        graphingMilitaryTimeFormatCheckArray[unitNumber] = graphingMilitaryTimeFormatCheck;
        if (unit->graphingFlags & QCOM_UNIT_GRAPH_MILITARY_TIME_FORMAT)
            graphingMilitaryTimeFormatCheck->Checked = GUI_YES;
        else
            graphingMilitaryTimeFormatCheck->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Military Time Format check box tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingMilitaryTimeFormatCheckToolTip = gcnew ToolTip;
        graphingMilitaryTimeFormatCheckToolTip->ShowAlways = GUI_YES;
        graphingMilitaryTimeFormatCheckToolTip->AutoPopDelay = 10000;
        graphingMilitaryTimeFormatCheckToolTip->ToolTipTitle =
            _T("Military Time Format");
        String ^graphingMilitaryTimeFormatCheckToolTipText = String::Concat(
            "You can display the plotting times for the graphs", Environment::NewLine,
            "in either Standard- or Military-style format for", Environment::NewLine,
            "transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, ". The time in", Environment::NewLine,
            "Standard format will display 4:55p, and the same", Environment::NewLine,
            "time in Military format will display 1655, for example.");
        graphingMilitaryTimeFormatCheckToolTip->SetToolTip(graphingMilitaryTimeFormatCheck, graphingMilitaryTimeFormatCheckToolTipText);
        delete graphingMilitaryTimeFormatCheckToolTipText;
        //--------------------------------------------------------------------
        // Log File Format check box
        //--------------------------------------------------------------------
        CheckBox ^graphingBothFileFormatsCheck = gcnew CheckBox;
        graphingBothFileFormatsCheck->Text = _T("Log both CSV and Text formats");
        GUI_PositionBelow(
            graphingBothFileFormatsCheck,
            graphingMilitaryTimeFormatCheck,
            4);
        graphingBothFileFormatsCheck->Size = graphingMilitaryTimeFormatCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            graphingBothFileFormatsCheck,
            unitNumber);
        graphingBothFileFormatsCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitBothFileFormatsChecked);
        graphingWindow->Controls->Add(graphingBothFileFormatsCheck);
        graphingBothFileFormatsCheckArray[unitNumber] = graphingBothFileFormatsCheck;
        if (unit->dataLogFlags & QCOM_UNIT_LOG_FILE_BOTH_FORMATS)
            graphingBothFileFormatsCheck->Checked = GUI_YES;
        else
            graphingBothFileFormatsCheck->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Log File Format check box tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingBothFileFormatsCheckToolTip = gcnew ToolTip;
        graphingBothFileFormatsCheckToolTip->ShowAlways = GUI_YES;
        graphingBothFileFormatsCheckToolTip->AutoPopDelay = 10000;
        graphingBothFileFormatsCheckToolTip->ToolTipTitle =
            _T("Data Log File Format");
        String ^graphingBothFileFormatsCheckToolTipText = String::Concat(
            "By default, logged data is saved only in plain-text", Environment::NewLine,
            "format. Check this box to save the logged data in", Environment::NewLine,
            "both plain-text and CSV (Excel-ready) formats for", Environment::NewLine,
            "transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, ".");
        graphingBothFileFormatsCheckToolTip->SetToolTip(graphingBothFileFormatsCheck, graphingBothFileFormatsCheckToolTipText);
        delete graphingBothFileFormatsCheckToolTipText;
        //--------------------------------------------------------------------
        // Use Thick Lines check box
        //--------------------------------------------------------------------
        CheckBox ^graphingUseThickLinesCheck = gcnew CheckBox;
        graphingUseThickLinesCheck->Text = _T("Use thick graphing lines");
        GUI_PositionBelow(
            graphingUseThickLinesCheck,
            graphingBothFileFormatsCheck,
            4);
        graphingUseThickLinesCheck->Size = graphingBothFileFormatsCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            graphingUseThickLinesCheck,
            unitNumber);
        graphingUseThickLinesCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_GraphingUseThickLinesChecked);
        graphingWindow->Controls->Add(graphingUseThickLinesCheck);
        graphingUseThickLinesCheckArray[unitNumber] = graphingUseThickLinesCheck;
        if (unit->graphingFlags & QCOM_UNIT_GRAPH_THICK_LINES)
            graphingUseThickLinesCheck->Checked = GUI_YES;
        else
            graphingUseThickLinesCheck->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Use Thick Lines check box tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingUseThickLinesCheckToolTip = gcnew ToolTip;
        graphingUseThickLinesCheckToolTip->ShowAlways = GUI_YES;
        graphingUseThickLinesCheckToolTip->AutoPopDelay = 10000;
        graphingUseThickLinesCheckToolTip->ToolTipTitle =
            _T("Use Thick Lines");
        String ^graphingUseThickLinesCheckToolTipText = String::Concat(
            "By default, the software plots the graphs using", Environment::NewLine,
            "thin lines. Check to select a thick-line graph for", Environment::NewLine,
            "transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, ".");
        graphingUseThickLinesCheckToolTip->SetToolTip(graphingUseThickLinesCheck, graphingUseThickLinesCheckToolTipText);
        delete graphingUseThickLinesCheckToolTipText;
        //--------------------------------------------------------------------
        // Superimpose Pressure and Temperature check box
        //--------------------------------------------------------------------
        CheckBox ^graphingSuperimposePressureTemperatureCheck = gcnew CheckBox;
        graphingSuperimposePressureTemperatureCheck->Text = _T("Superimpose Pressure / Temperature");
        GUI_PositionBelow(
            graphingSuperimposePressureTemperatureCheck,
            graphingUseThickLinesCheck,
            4);
        graphingSuperimposePressureTemperatureCheck->Size = graphingUseThickLinesCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            graphingSuperimposePressureTemperatureCheck,
            unitNumber);
        graphingSuperimposePressureTemperatureCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_GraphingSuperimposePressureTemperatureChecked);
        if (unit->graphingFlags & QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW)
            graphingSuperimposePressureTemperatureCheck->Enabled = GUI_NO;
        else
            graphingSuperimposePressureTemperatureCheck->Enabled = GUI_YES;
        graphingWindow->Controls->Add(graphingSuperimposePressureTemperatureCheck);
        graphingSuperimposePressureTemperatureCheckArray[unitNumber] = graphingSuperimposePressureTemperatureCheck;
        if (unit->graphingFlags & QCOM_UNIT_GRAPH_SUPERIMPOSE_PT)
            graphingSuperimposePressureTemperatureCheck->Checked = GUI_YES;
        else
            graphingSuperimposePressureTemperatureCheck->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Superimpose Pressure and Temperature check box tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingSuperimposePressureTemperatureCheckToolTip = gcnew ToolTip;
        graphingSuperimposePressureTemperatureCheckToolTip->ShowAlways = GUI_YES;
        graphingSuperimposePressureTemperatureCheckToolTip->AutoPopDelay = 10000;
        graphingSuperimposePressureTemperatureCheckToolTip->ToolTipTitle =
            _T("Superimpose Pressure and Temperature");
        String ^graphingSuperimposePressureTemperatureCheckToolTipText = String::Concat(
            "Displays the overlapping graphs of both pressure and", Environment::NewLine,
            "temperature for transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, ".");
        graphingSuperimposePressureTemperatureCheckToolTip->SetToolTip(graphingSuperimposePressureTemperatureCheck, graphingSuperimposePressureTemperatureCheckToolTipText);
        delete graphingSuperimposePressureTemperatureCheckToolTipText;
        //--------------------------------------------------------------------
        // Display Current Draw check box
        //--------------------------------------------------------------------
        CheckBox ^graphingDisplayAmperageDrawCheck = gcnew CheckBox;
        graphingDisplayAmperageDrawCheck->Text = String::Concat(
            _T("Display current draw ("),
            QCOM_AmperageUnitsStringArray[QCOM_AMPERAGE_UNITS_DEFAULT],
            _T(")"));
        GUI_PositionBelow(
            graphingDisplayAmperageDrawCheck,
            graphingSuperimposePressureTemperatureCheck,
            4);
        graphingDisplayAmperageDrawCheck->Size = graphingSuperimposePressureTemperatureCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            graphingDisplayAmperageDrawCheck,
            unitNumber);
        graphingDisplayAmperageDrawCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_GraphingDisplayAmperageDrawChecked);
        graphingWindow->Controls->Add(graphingDisplayAmperageDrawCheck);
        graphingDisplayAmperageDrawCheckArray[unitNumber] = graphingDisplayAmperageDrawCheck;
        if (unit->graphingFlags & QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW)
            graphingDisplayAmperageDrawCheck->Checked = GUI_YES;
        else
            graphingDisplayAmperageDrawCheck->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Display Current Draw check box tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingDisplayAmperageDrawCheckToolTip = gcnew ToolTip;
        graphingDisplayAmperageDrawCheckToolTip->ShowAlways = GUI_YES;
        graphingDisplayAmperageDrawCheckToolTip->AutoPopDelay = 10000;
        graphingDisplayAmperageDrawCheckToolTip->ToolTipTitle =
            _T("Display Current Draw");
        String ^graphingDisplayAmperageDrawCheckToolTipText = String::Concat(
            "Displays the graph and values for the current in ", QCOM_AmperageUnitsStringArray[QCOM_AMPERAGE_UNITS_DEFAULT], Environment::NewLine,
            "being drawn by transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, ".");
        graphingDisplayAmperageDrawCheckToolTip->SetToolTip(graphingDisplayAmperageDrawCheck, graphingDisplayAmperageDrawCheckToolTipText);
        delete graphingDisplayAmperageDrawCheckToolTipText;
        //--------------------------------------------------------------------
        // Transducer Part Number label
        //--------------------------------------------------------------------
        Label ^graphingTransducerPartNumberLabel = gcnew Label;
        graphingTransducerPartNumberLabel->Text = unit->transducerPartNumber;
        graphingTransducerPartNumberLabel->Location = Point(
            graphingAmperageLowBoundaryLabel->Left,
            graphingWindow->Bottom - 86);
        graphingTransducerPartNumberLabel->Size = Drawing::Size(440, 46);
        graphingTransducerPartNumberLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            32.0F,
            FontStyle::Bold);
        graphingTransducerPartNumberLabel->BackColor = Color::Transparent;
        graphingTransducerPartNumberLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingTransducerPartNumberLabel);
        graphingTransducerPartNumberLabelArray[unitNumber] = graphingTransducerPartNumberLabel;
        //--------------------------------------------------------------------
        // Transducer Part Number tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingTransducerPartNumberLabelToolTip = gcnew ToolTip;
        graphingTransducerPartNumberLabelToolTip->ShowAlways = GUI_YES;
        graphingTransducerPartNumberLabelToolTip->AutoPopDelay = 10000;
        graphingTransducerPartNumberLabelToolTip->ToolTipTitle =
            _T("Transducer Part Number");
        String ^graphingTransducerPartNumberLabelToolTipText = String::Concat(
            "Displays the part number for", Environment::NewLine,
            "transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, ".");
        graphingTransducerPartNumberLabelToolTip->SetToolTip(graphingTransducerPartNumberLabel, graphingTransducerPartNumberLabelToolTipText);
        delete graphingTransducerPartNumberLabelToolTipText;
        //--------------------------------------------------------------------
        // Transducer Serial Number label
        //--------------------------------------------------------------------
        Label ^graphingTransducerSerialNumberLabel = gcnew Label;
        graphingTransducerSerialNumberLabel->Text = String::Concat(
            _T("S/N "),
            unit->transducerSerialNumber);
        graphingTransducerSerialNumberLabel->Location = Point(
            graphingTransducerPartNumberLabel->Right + 2,
            graphingTransducerPartNumberLabel->Top);
        graphingTransducerSerialNumberLabel->Size = Drawing::Size(
            260, graphingTransducerPartNumberLabel->Height);
        graphingTransducerSerialNumberLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            32.0F,
            FontStyle::Bold);
        graphingTransducerSerialNumberLabel->BackColor = Color::Transparent;
        graphingTransducerSerialNumberLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        graphingWindow->Controls->Add(graphingTransducerSerialNumberLabel);
        graphingTransducerSerialNumberLabelArray[unitNumber] = graphingTransducerSerialNumberLabel;
        //--------------------------------------------------------------------
        // Transducer Serial Number tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingTransducerSerialNumberLabelToolTip = gcnew ToolTip;
        graphingTransducerSerialNumberLabelToolTip->ShowAlways = GUI_YES;
        graphingTransducerSerialNumberLabelToolTip->AutoPopDelay = 10000;
        graphingTransducerSerialNumberLabelToolTip->ToolTipTitle =
            _T("Transducer Serial Number");
        String ^graphingTransducerSerialNumberLabelToolTipText = String::Concat(
            "Displays the serial number for the", Environment::NewLine,
            "transducer attached to module ", unit->moduleSerialNumber, ".");
        graphingTransducerSerialNumberLabelToolTip->SetToolTip(graphingTransducerSerialNumberLabel, graphingTransducerSerialNumberLabelToolTipText);
        delete graphingTransducerSerialNumberLabelToolTipText;
        //--------------------------------------------------------------------
        // Close button
        //--------------------------------------------------------------------
        Button ^graphingCloseButton = gcnew Button;
        graphingCloseButton->Text = _T("Close");
        graphingCloseButton->Location = Point(
            graphingWindow->Right - 100,
            graphingWindow->Bottom - 70);
        graphingCloseButton->Size = Drawing::Size(
            GUI_CLOSE_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        graphingCloseButton->DialogResult = System::Windows::Forms::DialogResult::OK;
        GUI_SetUnitButtonInterfaceProperties(
            graphingCloseButton,
            unitNumber);
        graphingCloseButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_GraphingCloseWindow);
        //--------------------------------------------------------------------
        // Handle the closing of the window by any other way
        //--------------------------------------------------------------------
        graphingWindow->FormClosing +=
            gcnew FormClosingEventHandler(this, &QCOM_GUIClass::QCOM_GraphingClosingWindow);
        graphingWindow->Controls->Add(graphingCloseButton);
        //--------------------------------------------------------------------
        // Close button tool tip
        //--------------------------------------------------------------------
        ToolTip ^graphingCloseButtonToolTip = gcnew ToolTip;
        graphingCloseButtonToolTip->ShowAlways = GUI_YES;
        graphingCloseButtonToolTip->AutoPopDelay = 10000;  // let stand for ten seconds
        graphingCloseButtonToolTip->ToolTipTitle =
            _T("Close Graphing Window");
        String ^graphingCloseButtonToolTipText = String::Concat(
            "Closes the graphing window only for", Environment::NewLine,
            "transducer ", unit->transducerSerialNumber, " on module ", unit->moduleSerialNumber, ".");
        graphingCloseButtonToolTip->SetToolTip(graphingCloseButton, graphingCloseButtonToolTipText);
        delete graphingCloseButtonToolTipText;
        //--------------------------------------------------------------------
        // Set the remaining window properties
        //--------------------------------------------------------------------
        graphingWindow->AcceptButton = graphingCloseButton;
        graphingWindow->CancelButton = graphingCloseButton;
        graphingWindowArray[unitNumber] = graphingWindow;
        graphingWindow->Hide();
    }                                   // end of if (unit)
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_SetUpUnitGraphingWindow()
//----------------------------------------------------------------------------
#endif      // GRAPHING_CPP
//============================================================================
// End of Graphing.cpp
//============================================================================
