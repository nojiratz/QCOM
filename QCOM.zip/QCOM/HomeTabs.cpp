//============================================================================
// HomeTabs.cpp
//
// The methods used by GUI.cpp for creating and displaying the home tab pages
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     HOMETABS_CPP
#define     HOMETABS_CPP
#include    "HomeTabs.h"
//----------------------------------------------------------------------------
// QCOM_ConstructGeneralExpertGroupBox
//
// Displays the general Expert info group box
//
// Called by:   QCOM_ConstructHomeTabPages
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConstructGeneralExpertGroupBox(
    TabPage         ^tabPage)
{
    String          ^functionName = _T("QCOM_ConstructGeneralExpertGroupBox");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Create the group box
    //------------------------------------------------------------------------
    GroupBox ^expertGeneralGroupBox = gcnew GroupBox;
    expertGeneralGroupBox->Text = _T("General Controls");
    expertGeneralGroupBox->Location = Point(25, 6);
    expertGeneralGroupBox->Size = Drawing::Size(
        GUI_DEFAULT_GROUP_BOX_WIDTH,
        GUI_GENERAL_GROUP_BOX_HEIGHT);
    expertGeneralGroupBox->ForeColor = Color::Black;
    expertGeneralGroupBox->BackColor = Color::Transparent;
    tabPage->Controls->Add(expertGeneralGroupBox);
    //------------------------------------------------------------------------
    // Basic messages check box
    //------------------------------------------------------------------------
    expertBasicMessagesCheck = gcnew CheckBox;
    expertBasicMessagesCheck->Text = _T("Enable basic modal messages");
    expertBasicMessagesCheck->Location = Point(10, 20);
    expertBasicMessagesCheck->Size = Drawing::Size(200, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(expertBasicMessagesCheck);
    expertBasicMessagesCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertBasicMessagesChecked);
    expertBasicMessagesCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertBasicMessagesCheckMouseEntered);
    expertBasicMessagesCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertBasicMessagesCheck);
    //------------------------------------------------------------------------
    // Error messages check box
    //------------------------------------------------------------------------
    expertErrorMessagesCheck = gcnew CheckBox;
    expertErrorMessagesCheck->Text = _T("Enable error modal messages");
    GUI_PositionAndSizeBelow(expertErrorMessagesCheck, expertBasicMessagesCheck, 4);
    GUI_SetObjectInterfaceProperties(expertErrorMessagesCheck);
    expertErrorMessagesCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertErrorMessagesChecked);
    expertErrorMessagesCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertErrorMessagesCheckMouseEntered);
    expertErrorMessagesCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertErrorMessagesCheck);
    //------------------------------------------------------------------------
    // Verbose messages check box
    //------------------------------------------------------------------------
    expertVerboseMessagesCheck = gcnew CheckBox;
    expertVerboseMessagesCheck->Text = _T("Enable verbose modal messages");
    GUI_PositionAndSizeBelow(expertVerboseMessagesCheck, expertErrorMessagesCheck, 4);
    GUI_SetObjectInterfaceProperties(expertVerboseMessagesCheck);
    expertVerboseMessagesCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertVerboseMessagesChecked);
    expertVerboseMessagesCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertVerboseMessagesCheckMouseEntered);
    expertVerboseMessagesCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertVerboseMessagesCheck);
    //------------------------------------------------------------------------
    // Detailed messages check box
    //------------------------------------------------------------------------
    expertDetailedMessagesCheck = gcnew CheckBox;
    expertDetailedMessagesCheck->Text = _T("Enable detailed modal messages");
    GUI_PositionAndSizeBelow(expertDetailedMessagesCheck, expertVerboseMessagesCheck, 4);
    GUI_SetObjectInterfaceProperties(expertDetailedMessagesCheck);
    expertDetailedMessagesCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertDetailedMessagesChecked);
    expertDetailedMessagesCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertDetailedMessagesCheckMouseEntered);
    expertDetailedMessagesCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertDetailedMessagesCheck);
    //------------------------------------------------------------------------
    // Experimental messages check box
    //------------------------------------------------------------------------
    expertExpMessagesCheck = gcnew CheckBox;
    expertExpMessagesCheck->Text = _T("Enable experimental messages");
    GUI_PositionAndSizeBelow(expertExpMessagesCheck, expertDetailedMessagesCheck, 4);
    GUI_SetObjectInterfaceProperties(expertExpMessagesCheck);
    expertExpMessagesCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertExpMessagesChecked);
    expertExpMessagesCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertExpMessagesCheckMouseEntered);
    expertExpMessagesCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertExpMessagesCheck);
    //------------------------------------------------------------------------
    // DLL messages check box
    //------------------------------------------------------------------------
    expertDLLMessagesCheck = gcnew CheckBox;
    expertDLLMessagesCheck->Text = _T("Enable DLL modal messages");
    GUI_PositionAndSizeBelow(expertDLLMessagesCheck, expertExpMessagesCheck, 4);
    GUI_SetObjectInterfaceProperties(expertDLLMessagesCheck);
    expertDLLMessagesCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertDLLMessagesChecked);
    expertDLLMessagesCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertDLLMessagesCheckMouseEntered);
    expertDLLMessagesCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertDLLMessagesCheck);
    //------------------------------------------------------------------------
    // Reset All Messages button
    //------------------------------------------------------------------------
    expertResetMessagesButton = gcnew Button;
    expertResetMessagesButton->Text = _T("Reset All Modal Messages");
    GUI_PositionBelow(expertResetMessagesButton, expertDLLMessagesCheck, 2);
    expertResetMessagesButton->Size = Drawing::Size(180, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(expertResetMessagesButton);
    expertResetMessagesButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertResetAllMessagesButtonClicked);
    expertResetMessagesButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertResetAllMessagesButtonMouseEntered);
    expertResetMessagesButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertResetMessagesButton);
    //------------------------------------------------------------------------
    // Enable Poller check box
    //------------------------------------------------------------------------
    expertProgramIntervalCheck = gcnew CheckBox;
    expertProgramIntervalCheck->Text = _T("Enable the program poller");
    expertProgramIntervalCheck->Location = Point(
        expertErrorMessagesCheck->Right + 15,
        expertErrorMessagesCheck->Top);
    expertProgramIntervalCheck->Size = Drawing::Size(220, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(expertProgramIntervalCheck);
    expertProgramIntervalCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertProgramIntervalChecked);
    expertProgramIntervalCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertProgramIntervalCheckMouseEntered);
    expertProgramIntervalCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertProgramIntervalCheck);
    //------------------------------------------------------------------------
    // Stack Trace check box
    //------------------------------------------------------------------------
    expertStackTraceCheck = gcnew CheckBox;
    expertStackTraceCheck->Text = _T("Display stack traces for errors");
    GUI_PositionAndSizeBelow(expertStackTraceCheck, expertProgramIntervalCheck, 4);
    GUI_SetObjectInterfaceProperties(expertStackTraceCheck);
    expertStackTraceCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertStackTraceChecked);
    expertStackTraceCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertStackTraceCheckMouseEntered);
    expertStackTraceCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertStackTraceCheck);
    //------------------------------------------------------------------------
    // Send Text on Errors check box
    //------------------------------------------------------------------------
    expertSendTextErrorMessageCheck = gcnew CheckBox;
    expertSendTextErrorMessageCheck->Text = _T("Send text messages when errors occur");
    GUI_PositionAndSizeBelow(expertSendTextErrorMessageCheck, expertStackTraceCheck, 4);
    GUI_SetObjectInterfaceProperties(expertSendTextErrorMessageCheck);
    expertSendTextErrorMessageCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertSendTextErrorMessageChecked);
    expertSendTextErrorMessageCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertSendTextErrorMessageCheckMouseEntered);
    expertSendTextErrorMessageCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertSendTextErrorMessageCheck);
    //------------------------------------------------------------------------
    // Send Email on Errors check box
    //------------------------------------------------------------------------
    expertSendEmailErrorMessageCheck = gcnew CheckBox;
    expertSendEmailErrorMessageCheck->Text = _T("Send emails when errors occur");
    GUI_PositionAndSizeBelow(expertSendEmailErrorMessageCheck, expertSendTextErrorMessageCheck, 4);
    GUI_SetObjectInterfaceProperties(expertSendEmailErrorMessageCheck);
    expertSendEmailErrorMessageCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertSendEmailErrorMessageChecked);
    expertSendEmailErrorMessageCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertSendEmailErrorMessageCheckMouseEntered);
    expertSendEmailErrorMessageCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertSendEmailErrorMessageCheck);
    //------------------------------------------------------------------------
    // Halt Operations on Errors check box
    //------------------------------------------------------------------------
    expertHaltOperationsOnErrorsCheck = gcnew CheckBox;
    expertHaltOperationsOnErrorsCheck->Text = _T("Halt operations when errors occur");
    GUI_PositionAndSizeBelow(expertHaltOperationsOnErrorsCheck, expertSendEmailErrorMessageCheck, 4);
    GUI_SetObjectInterfaceProperties(expertHaltOperationsOnErrorsCheck);
    expertHaltOperationsOnErrorsCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertHaltOperationsOnErrorsChecked);
    expertHaltOperationsOnErrorsCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertHaltOperationsOnErrorsCheckMouseEntered);
    expertHaltOperationsOnErrorsCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertHaltOperationsOnErrorsCheck);
    //------------------------------------------------------------------------
    // Experiments check box
    //------------------------------------------------------------------------
    expertExperimentsCheck = gcnew CheckBox;
    expertExperimentsCheck->Text = _T("Enable experiments");
    GUI_PositionBelow(expertExperimentsCheck, expertHaltOperationsOnErrorsCheck, 4);
    expertExperimentsCheck->Size = Drawing::Size(124, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(expertExperimentsCheck);
    expertExperimentsCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertExperimentsChecked);
    expertExperimentsCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertExperimentsAreaMouseEntered);
    expertExperimentsCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertExperimentsCheck);
    //------------------------------------------------------------------------
    // Experiment number box
    //------------------------------------------------------------------------
    expertExperimentNumberBox = gcnew TextBox;
    expertExperimentNumberBox->Location = Point(
        expertExperimentsCheck->Right + 2,
        expertExperimentsCheck->Top - 2);
    expertExperimentNumberBox->Size = Drawing::Size(
        30, GUI_REGULAR_TEXT_BOX_HEIGHT);
    expertExperimentNumberBox->Multiline = GUI_NO;
    expertExperimentNumberBox->AcceptsReturn = GUI_NO;
    expertExperimentNumberBox->AcceptsTab = GUI_NO;
    expertExperimentNumberBox->WordWrap = GUI_NO;
    expertExperimentNumberBox->TextAlign = HorizontalAlignment::Center;
    expertExperimentNumberBox->BackColor = Color::White;
    expertExperimentNumberBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateExperimentNumberValue);
    expertExperimentNumberBox->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertExperimentsAreaMouseEntered);
    expertExperimentNumberBox->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertExperimentNumberBox);
    //------------------------------------------------------------------------
    // Experimental button - displayed on the main Form, not the Group Box
    //------------------------------------------------------------------------
    expertExperimentalButton = gcnew Button;
    expertExperimentalButton->Text = _T("Experimental");
    expertExperimentalButton->Location = Point(
        homeTestingStatusLabel->Left,
        GUI_HOME_WINDOW_HEIGHT - 88);
    expertExperimentalButton->Size = Drawing::Size(
        homeTestingStatusLabel->Width,
        GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(expertExperimentalButton);
    expertExperimentalButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertExperimentalButtonClicked);
    expertExperimentalButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertExperimentalButtonMouseEntered);
    expertExperimentalButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    this->Controls->Add(expertExperimentalButton);
    //------------------------------------------------------------------------
    // Program interval (poller) timer prefix label
    //------------------------------------------------------------------------
    Label ^expertIntervalLabel = gcnew Label;
    expertIntervalLabel->Text = _T("Poller");
    expertIntervalLabel->Location = Point(
        expertBasicMessagesCheck->Right + 15,
        expertBasicMessagesCheck->Top);
    expertIntervalLabel->Size = Drawing::Size(34, GUI_REGULAR_LABEL_HEIGHT);
    expertIntervalLabel->BackColor = Color::Transparent;
    expertIntervalLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertProgramIntervalMouseEntered);
    expertIntervalLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertIntervalLabel);
    //------------------------------------------------------------------------
    // Program interval (poller) timer box
    //------------------------------------------------------------------------
    expertProgramIntervalBox = gcnew TextBox;
    expertProgramIntervalBox->Location = Point(
        expertIntervalLabel->Right + 2,
        expertIntervalLabel->Top - 2);
    expertProgramIntervalBox->Size = Drawing::Size(
        38, GUI_REGULAR_TEXT_BOX_HEIGHT);
    expertProgramIntervalBox->Multiline = GUI_NO;
    expertProgramIntervalBox->AcceptsReturn = GUI_NO;
    expertProgramIntervalBox->AcceptsTab = GUI_NO;
    expertProgramIntervalBox->WordWrap = GUI_NO;
    expertProgramIntervalBox->TextAlign = HorizontalAlignment::Right;
    expertProgramIntervalBox->BackColor = Color::White;
    expertProgramIntervalBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateProgramIntervalValue);
    expertProgramIntervalBox->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertProgramIntervalMouseEntered);
    expertProgramIntervalBox->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertProgramIntervalBox);
    //------------------------------------------------------------------------
    // Program interval (poller) timer millisecond label
    //------------------------------------------------------------------------
    Label ^expertMillisecondLabel = gcnew Label;
    expertMillisecondLabel->Text = String::Format(
        "ms ({0:D} to {1:D})",
        GUI_MINIMUM_PROGRAM_INTERVAL,
        GUI_MAXIMUM_PROGRAM_INTERVAL);
    expertMillisecondLabel->BackColor = Color::Transparent;
    expertMillisecondLabel->Location = Point(
        expertProgramIntervalBox->Right + 1,
        expertIntervalLabel->Top);
    expertMillisecondLabel->Size = Drawing::Size(
        126, GUI_REGULAR_LABEL_HEIGHT);
    expertMillisecondLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertProgramIntervalMouseEntered);
    expertMillisecondLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertMillisecondLabel);
    //------------------------------------------------------------------------
    // Text message numbers label
    //------------------------------------------------------------------------
    Label ^expertTextMessageLabel = gcnew Label;
    expertTextMessageLabel->Text = _T("Numbers for sending text messages");
    expertTextMessageLabel->Location = Point(
        expertProgramIntervalCheck->Right + 15,
        expertProgramIntervalBox->Top);
    expertTextMessageLabel->Size = Drawing::Size(220, GUI_INFO_LABEL_HEIGHT);
    expertTextMessageLabel->BackColor = Color::Transparent;
    expertGeneralGroupBox->Controls->Add(expertTextMessageLabel);
    //------------------------------------------------------------------------
    // Text message To Number box
    //------------------------------------------------------------------------
    expertTextMessageToNumberLabel = gcnew Label;
    expertTextMessageToNumberLabel->Text = _T("To:");
    GUI_PositionBelow(expertTextMessageToNumberLabel, expertTextMessageLabel, 6);
    expertTextMessageToNumberLabel->Size = Drawing::Size(24, GUI_REGULAR_LABEL_HEIGHT);
    expertGeneralGroupBox->Controls->Add(expertTextMessageToNumberLabel);
    expertTextMessageToNumberBox = gcnew TextBox;
    expertTextMessageToNumberBox->Text =
        QCOM_GeneralInfo->textMessageToNumber;
    expertTextMessageToNumberBox->Location = Point(
        expertTextMessageToNumberLabel->Right + 2,
        expertTextMessageToNumberLabel->Top - 2);
    expertTextMessageToNumberBox->Size = Drawing::Size(
        194, GUI_REGULAR_TEXT_BOX_HEIGHT);
    expertTextMessageToNumberBox->Multiline = GUI_NO;
    expertTextMessageToNumberBox->AcceptsReturn = GUI_NO;
    expertTextMessageToNumberBox->AcceptsTab = GUI_NO;
    expertTextMessageToNumberBox->WordWrap = GUI_NO;
    expertTextMessageToNumberBox->TextAlign = HorizontalAlignment::Left;
    expertTextMessageToNumberBox->BackColor = Color::White;
    expertTextMessageToNumberBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateTextMessageNumbers);
    expertTextMessageToNumberBox->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertTextMessageToNumberBoxMouseEntered);
    expertTextMessageToNumberBox->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertTextMessageToNumberBox);
    //------------------------------------------------------------------------
    // Text message CC Number box
    //------------------------------------------------------------------------
    expertTextMessageCCNumberLabel = gcnew Label;
    expertTextMessageCCNumberLabel->Text = _T("CC:");
    GUI_PositionBelow(expertTextMessageCCNumberLabel, expertTextMessageToNumberLabel, 12);
    expertTextMessageCCNumberLabel->Size = Drawing::Size(24, GUI_REGULAR_LABEL_HEIGHT);
    expertGeneralGroupBox->Controls->Add(expertTextMessageCCNumberLabel);
    expertTextMessageCCNumberBox = gcnew TextBox;
    expertTextMessageCCNumberBox->Text =
        QCOM_GeneralInfo->textMessageCCNumber;
    expertTextMessageCCNumberBox->Location = Point(
        expertTextMessageCCNumberLabel->Right + 2,
        expertTextMessageCCNumberLabel->Top - 2);
    expertTextMessageCCNumberBox->Size = expertTextMessageToNumberBox->Size;
    expertTextMessageCCNumberBox->Multiline = GUI_NO;
    expertTextMessageCCNumberBox->AcceptsReturn = GUI_NO;
    expertTextMessageCCNumberBox->AcceptsTab = GUI_NO;
    expertTextMessageCCNumberBox->WordWrap = GUI_NO;
    expertTextMessageCCNumberBox->TextAlign = HorizontalAlignment::Left;
    expertTextMessageCCNumberBox->BackColor = Color::White;
    expertTextMessageCCNumberBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateTextMessageNumbers);
    expertTextMessageCCNumberBox->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertTextMessageCCNumberBoxMouseEntered);
    expertTextMessageCCNumberBox->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertTextMessageCCNumberBox);
    //------------------------------------------------------------------------
    // Email message addresses label
    //------------------------------------------------------------------------
    Label ^expertEmailMessageLabel = gcnew Label;
    expertEmailMessageLabel->Text = _T("Addresses for sending email messages");
    GUI_PositionBelow(expertEmailMessageLabel, expertTextMessageCCNumberLabel, 8);
    expertEmailMessageLabel->Size = expertTextMessageLabel->Size;
    expertEmailMessageLabel->BackColor = Color::Transparent;
    expertGeneralGroupBox->Controls->Add(expertEmailMessageLabel);
    //------------------------------------------------------------------------
    // Email message To Address box
    //------------------------------------------------------------------------
    expertEmailMessageToAddressLabel = gcnew Label;
    expertEmailMessageToAddressLabel->Text = _T("To:");
    GUI_PositionBelow(expertEmailMessageToAddressLabel, expertEmailMessageLabel, 6);
    expertEmailMessageToAddressLabel->Size = expertTextMessageCCNumberLabel->Size;
    expertGeneralGroupBox->Controls->Add(expertEmailMessageToAddressLabel);
    expertEmailMessageToAddressBox = gcnew TextBox;
    expertEmailMessageToAddressBox->Text =
        QCOM_GeneralInfo->emailMessageToAddress;
    expertEmailMessageToAddressBox->Location = Point(
        expertEmailMessageToAddressLabel->Right + 2,
        expertEmailMessageToAddressLabel->Top - 2);
    expertEmailMessageToAddressBox->Size = Drawing::Size(
        194, GUI_REGULAR_TEXT_BOX_HEIGHT);
    expertEmailMessageToAddressBox->Multiline = GUI_NO;
    expertEmailMessageToAddressBox->AcceptsReturn = GUI_NO;
    expertEmailMessageToAddressBox->AcceptsTab = GUI_NO;
    expertEmailMessageToAddressBox->WordWrap = GUI_NO;
    expertEmailMessageToAddressBox->TextAlign = HorizontalAlignment::Left;
    expertEmailMessageToAddressBox->BackColor = Color::White;
    expertEmailMessageToAddressBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateEmailMessageAddresses);
    expertEmailMessageToAddressBox->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertEmailMessageToAddressBoxMouseEntered);
    expertEmailMessageToAddressBox->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertEmailMessageToAddressBox);
    //------------------------------------------------------------------------
    // Email message CC Address box
    //------------------------------------------------------------------------
    expertEmailMessageCCAddressLabel = gcnew Label;
    expertEmailMessageCCAddressLabel->Text = _T("CC:");
    GUI_PositionBelow(expertEmailMessageCCAddressLabel, expertEmailMessageToAddressLabel, 12);
    expertEmailMessageCCAddressLabel->Size = expertTextMessageCCNumberLabel->Size;
    expertGeneralGroupBox->Controls->Add(expertEmailMessageCCAddressLabel);
    expertEmailMessageCCAddressBox = gcnew TextBox;
    expertEmailMessageCCAddressBox->Text =
        QCOM_GeneralInfo->emailMessageCCAddress;
    expertEmailMessageCCAddressBox->Location = Point(
        expertEmailMessageCCAddressLabel->Right + 2,
        expertEmailMessageCCAddressLabel->Top - 2);
    expertEmailMessageCCAddressBox->Size = expertEmailMessageToAddressBox->Size;
    expertEmailMessageCCAddressBox->Multiline = GUI_NO;
    expertEmailMessageCCAddressBox->AcceptsReturn = GUI_NO;
    expertEmailMessageCCAddressBox->AcceptsTab = GUI_NO;
    expertEmailMessageCCAddressBox->WordWrap = GUI_NO;
    expertEmailMessageCCAddressBox->TextAlign = HorizontalAlignment::Left;
    expertEmailMessageCCAddressBox->BackColor = Color::White;
    expertEmailMessageCCAddressBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateEmailMessageAddresses);
    expertEmailMessageCCAddressBox->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertEmailMessageCCAddressBoxMouseEntered);
    expertEmailMessageCCAddressBox->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertEmailMessageCCAddressBox);
    //------------------------------------------------------------------------
    // Program info button
    //------------------------------------------------------------------------
    Button ^expertProgInfoButton = gcnew Button;
    expertProgInfoButton->Text = _T("Program Info");
    expertProgInfoButton->Location = Point(
        expertGeneralGroupBox->Right - 136,
        expertBasicMessagesCheck->Top);
    expertProgInfoButton->Size = Drawing::Size(100, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(expertProgInfoButton);
    expertProgInfoButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertProgramInfoButtonClicked);
    expertProgInfoButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertProgramInfoButtonMouseEntered);
    expertProgInfoButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertProgInfoButton);
    //------------------------------------------------------------------------
    // Misc controls
    //------------------------------------------------------------------------
    Button ^expertMiscButton = gcnew Button;
    expertMiscButton->Text = _T("Misc Controls");
    GUI_PositionAndSizeBelow(expertMiscButton, expertProgInfoButton, 10);
    GUI_SetButtonInterfaceProperties(expertMiscButton);
    expertMiscButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscControlsButtonClicked);
    expertMiscButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertMiscButtonMouseEntered);
    expertMiscButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertMiscButton);
    //--------------------------------------------------------------------
    // Real Time Weight Demo button
    //--------------------------------------------------------------------
    expertRealTimeWeightDemoButton = gcnew Button;
    expertRealTimeWeightDemoButton->Text = _T("Weight Demo");
    GUI_PositionAndSizeBelow(
        expertRealTimeWeightDemoButton,
        expertMiscButton,
        10);
    GUI_SetButtonInterfaceProperties(expertRealTimeWeightDemoButton);
    expertRealTimeWeightDemoButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertRealTimeWeightDemoButtonClicked);
    expertRealTimeWeightDemoButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertRealTimeWeightDemoButtonMouseEntered);
    expertRealTimeWeightDemoButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertRealTimeWeightDemoButton);
    //------------------------------------------------------------------------
    // Experiments button
    //------------------------------------------------------------------------
    expertExperimentsButton = gcnew Button;
    expertExperimentsButton->Text = _T("Run Experiments");
    GUI_PositionAndSizeBelow(
        expertExperimentsButton,
        expertRealTimeWeightDemoButton,
        10);
//    GUI_PositionAndSizeBelow(
//        expertExperimentsButton,
//        expertMiscButton,
//        (10 + 10 + GUI_REGULAR_BUTTON_HEIGHT));
    GUI_SetButtonInterfaceProperties(expertExperimentsButton);
    expertExperimentsButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertPerformExperimentsButtonClicked);
    expertExperimentsButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertPerformExperimentsButtonMouseEntered);
    expertExperimentsButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    expertGeneralGroupBox->Controls->Add(expertExperimentsButton);
    //------------------------------------------------------------------------
    // Epilogue
    //------------------------------------------------------------------------
    QCOM_UpdateMessageChecks();
    RecordDetailedEvent("    General Expert group box created");
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ConstructGeneralExpertGroupBox()
//----------------------------------------------------------------------------
// QCOM_ConstructGeneralReadoutGroupBox
//
// Displays the general Readout info group box
//
// Called by:   QCOM_ConstructHomeTabPages
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConstructGeneralReadoutGroupBox(
    TabPage         ^tabPage)
{
    String          ^functionName = _T("QCOM_ConstructGeneralReadoutGroupBox");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Create the group box
    //------------------------------------------------------------------------
    GroupBox ^readoutGeneralGroupBox = gcnew GroupBox;
    readoutGeneralGroupBox->Text = _T("General Readout Controls");
    readoutGeneralGroupBox->Location = Point(25, 6);
    readoutGeneralGroupBox->Size = Drawing::Size(
        GUI_DEFAULT_GROUP_BOX_WIDTH,
        GUI_GENERAL_GROUP_BOX_HEIGHT);
    readoutGeneralGroupBox->ForeColor = Color::Black;
    readoutGeneralGroupBox->BackColor = Color::Transparent;
    tabPage->Controls->Add(readoutGeneralGroupBox);
    //------------------------------------------------------------------------
    // Pressure/Temperature group box
    //------------------------------------------------------------------------
    GroupBox ^readoutCountPTGroupBox = gcnew GroupBox;
    readoutCountPTGroupBox->Text = _T("Pressure/Temperature");
    readoutCountPTGroupBox->Location = Point(15, 16);
    readoutCountPTGroupBox->BackColor = Color::Transparent;
    //------------------------------------------------------------------------
    // Pressure / Temperature radio buttons
    //------------------------------------------------------------------------
    readoutDefaultPressureTemperatureRadio = gcnew RadioButton;
    readoutDefaultPressureTemperatureRadio->Location = Point(5, 20);
    readoutDefaultPressureTemperatureRadio->Size = Drawing::Size(
        150, GUI_REGULAR_RADIO_BUTTON_HEIGHT);
    GUI_SetObjectInterfaceProperties(readoutDefaultPressureTemperatureRadio);
    readoutDefaultPressureTemperatureRadio->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutDefaultPressureTemperatureRadioSelected);
    readoutDefaultPressureTemperatureRadio->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutDefaultPressureTemperatureRadioMouseEntered);
    readoutDefaultPressureTemperatureRadio->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutAlternatePressureTemperatureRadio = gcnew RadioButton;
    GUI_PositionAndSizeBelow(
        readoutAlternatePressureTemperatureRadio,
        readoutDefaultPressureTemperatureRadio,
        4);
    GUI_SetObjectInterfaceProperties(readoutAlternatePressureTemperatureRadio);
    readoutAlternatePressureTemperatureRadio->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutAlternatePressureTemperatureRadioSelected);
    readoutAlternatePressureTemperatureRadio->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutAlternatePressureTemperatureRadioMouseEntered);
    readoutAlternatePressureTemperatureRadio->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutCountsRadio = gcnew RadioButton;
    readoutCountsRadio->Text = _T("Counts");
    GUI_PositionBelow(readoutCountsRadio, readoutAlternatePressureTemperatureRadio, 4);
    readoutCountsRadio->Size = Drawing::Size(
        60, GUI_REGULAR_RADIO_BUTTON_HEIGHT);
    GUI_SetObjectInterfaceProperties(readoutCountsRadio);
    readoutCountsRadio->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutCountsRadioSelected);
    readoutCountsRadio->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutCountsRadioMouseEntered);
    readoutCountsRadio->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutHexCheck = gcnew CheckBox;
    readoutHexCheck->Text = _T("Hex");
    readoutHexCheck->Location = Point(
        readoutCountsRadio->Right + 6,
        readoutCountsRadio->Top);
    readoutHexCheck->Size = Drawing::Size(
        54, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(readoutHexCheck);
    readoutHexCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutHexCountsChecked);
    readoutHexCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutHexCheckMouseEntered);
    readoutHexCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Precision numeric and label
    //------------------------------------------------------------------------
    readoutPrecisionLabel = gcnew Label;
    readoutPrecisionLabel->Text = _T("Decimal Points:");
    GUI_PositionBelow(readoutPrecisionLabel, readoutCountsRadio, 6);
    readoutPrecisionLabel->Size = Drawing::Size(84, GUI_LARGE_LABEL_HEIGHT);
    readoutPrecisionLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutPrecisionNumericMouseEntered);
    readoutPrecisionLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutPrecisionNumeric = gcnew NumericUpDown;
    readoutPrecisionNumeric->Location = Point(
        readoutPrecisionLabel->Right + 2,
        readoutPrecisionLabel->Top - 2);
    readoutPrecisionNumeric->Width = 32;
    readoutPrecisionNumeric->Minimum = GUI_MINIMUM_READOUT_DECIMAL_POINTS;      // 0
    readoutPrecisionNumeric->Maximum = GUI_MAXIMUM_READOUT_DECIMAL_POINTS;      // 7
    readoutPrecisionNumeric->ReadOnly = GUI_YES;
    readoutPrecisionNumeric->TabStop = GUI_NO;
    readoutPrecisionNumeric->BackColor = Color::Lavender;
    GUI_DisplayHandCursorOnHover(readoutPrecisionNumeric);
    readoutPrecisionNumeric->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_PrecisionUpDownClicked);
    readoutPrecisionNumeric->MouseDoubleClick +=
        gcnew MouseEventHandler(this, &QCOM_GUIClass::QCOM_PrecisionUpDownDoubleClicked);
    readoutPrecisionNumeric->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutPrecisionNumericMouseEntered);
    readoutPrecisionNumeric->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutCountPTGroupBox->Size = Drawing::Size(
        readoutDefaultPressureTemperatureRadio->Right + 10,
        readoutPrecisionNumeric->Bottom + 6);
    //------------------------------------------------------------------------
    // Attach the components to the Pressure/Temperature group box
    //------------------------------------------------------------------------
    readoutCountPTGroupBox->Controls->Add(readoutHexCheck);
    array <RadioButton ^> ^readoutCountPTRadios =
    {
        readoutDefaultPressureTemperatureRadio,
        readoutAlternatePressureTemperatureRadio,
        readoutCountsRadio
    };
    readoutCountPTGroupBox->Controls->AddRange(readoutCountPTRadios);
    readoutCountPTGroupBox->Controls->Add(readoutPrecisionLabel);
    readoutCountPTGroupBox->Controls->Add(readoutPrecisionNumeric);
    readoutGeneralGroupBox->Controls->Add(readoutCountPTGroupBox);
    //------------------------------------------------------------------------
    // Interval Units group box and associated components
    //------------------------------------------------------------------------
    GroupBox ^readoutIntervalUnitsGroupBox = gcnew GroupBox;
    readoutIntervalUnitsGroupBox->Text = _T("Time Between Samples");
    readoutIntervalUnitsGroupBox->Location = Point(
        readoutCountPTGroupBox->Right + 16,
        readoutCountPTGroupBox->Top);
    readoutIntervalUnitsGroupBox->Size = Drawing::Size(156, 85);
    readoutIntervalUnitsGroupBox->ForeColor = Color::Black;
    readoutIntervalUnitsGroupBox->BackColor = Color::Transparent;
    readoutIntervalUnitsGroupBox->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutSamplingIntervalMouseEntered);
    readoutIntervalUnitsGroupBox->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Sampling Interval Timer settings and controls
    //------------------------------------------------------------------------
    Label ^readoutIntervalLabel = gcnew Label;
    readoutIntervalLabel->Text = _T("Interval");
    readoutIntervalLabel->Location = Point(2, 22);
    readoutIntervalLabel->Size = Drawing::Size(42, GUI_REGULAR_LABEL_HEIGHT);
    readoutIntervalLabel->BackColor = Color::Transparent;
    readoutIntervalLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutSamplingIntervalMouseEntered);
    readoutIntervalLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutSamplingIntervalBox = gcnew TextBox;
    readoutSamplingIntervalBox->Multiline = GUI_NO;
    readoutSamplingIntervalBox->AcceptsReturn = GUI_NO;
    readoutSamplingIntervalBox->AcceptsTab = GUI_NO;
    readoutSamplingIntervalBox->WordWrap = GUI_NO;
    readoutSamplingIntervalBox->TextAlign = HorizontalAlignment::Right;
    readoutSamplingIntervalBox->Location = Point(
        readoutIntervalLabel->Right + 2,
        readoutIntervalLabel->Top - 2);
    readoutSamplingIntervalBox->Size = Drawing::Size(38, GUI_SMALL_TEXT_BOX_HEIGHT);
    readoutSamplingIntervalBox->BackColor = Color::White;
    readoutSamplingIntervalBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateSamplingIntervalValue);
    readoutSamplingIntervalBox->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutSamplingIntervalMouseEntered);
    readoutSamplingIntervalBox->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutIntervalUnitsLabel = gcnew Label;
    readoutIntervalUnitsLabel->Text = QCOM_IntervalUnitsStringArray[QCOM_CurrentIntervalUnitsOffset];
    readoutIntervalUnitsLabel->BackColor = Color::Transparent;
    readoutIntervalUnitsLabel->Location = Point(
        readoutSamplingIntervalBox->Right + 1,
        readoutIntervalLabel->Top);
    readoutIntervalUnitsLabel->Size = Drawing::Size(24, GUI_REGULAR_LABEL_HEIGHT);
    readoutIntervalUnitsLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutSamplingIntervalMouseEntered);
    readoutIntervalUnitsLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutIntervalRangeLabel = gcnew Label;
    readoutIntervalRangeLabel->Text = String::Format(
        "({0:D} to {1:D} {2})",
        QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET],
        QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MAXIMUM_OFFSET],
        QCOM_IntervalUnitsStringArray[QCOM_CurrentIntervalUnitsOffset]);
    readoutIntervalRangeLabel->Location = Point(
        readoutIntervalLabel->Left,
        readoutSamplingIntervalBox->Bottom + 4);
    readoutIntervalRangeLabel->Size = Drawing::Size(100, GUI_REGULAR_LABEL_HEIGHT);
    readoutIntervalRangeLabel->BackColor = Color::Transparent;
    readoutIntervalRangeLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    readoutIntervalRangeLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutSamplingIntervalMouseEntered);
    readoutIntervalRangeLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Sampling Interval Timer Units radio buttons
    //------------------------------------------------------------------------
    readoutMillisecondsRadio = gcnew RadioButton;
    readoutMillisecondsRadio->Text = QCOM_IntervalUnitsStringArray[GUI_INTERVAL_MS_OFFSET];
    readoutMillisecondsRadio->Location = Point(
        readoutIntervalUnitsLabel->Right + 2,
        readoutIntervalLabel->Top - 6);
    readoutMillisecondsRadio->Size = Drawing::Size(40, 12);
    GUI_SetObjectInterfaceProperties(readoutMillisecondsRadio);
    readoutMillisecondsRadio->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_SamplingMillisecondsRadioSelected);
    readoutSecondsRadio = gcnew RadioButton;
    readoutSecondsRadio->Text = QCOM_IntervalUnitsStringArray[GUI_INTERVAL_SEC_OFFSET];
    GUI_PositionAndSizeBelow(readoutSecondsRadio, readoutMillisecondsRadio, 4);
    GUI_SetObjectInterfaceProperties(readoutSecondsRadio);
    readoutSecondsRadio->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_SamplingSecondsRadioSelected);
    readoutMinutesRadio = gcnew RadioButton;
    readoutMinutesRadio->Text = QCOM_IntervalUnitsStringArray[GUI_INTERVAL_MIN_OFFSET];
    GUI_PositionAndSizeBelow(readoutMinutesRadio, readoutSecondsRadio, 4);
    GUI_SetObjectInterfaceProperties(readoutMinutesRadio);
    readoutMinutesRadio->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_SamplingMinutesRadioSelected);
    readoutHoursRadio = gcnew RadioButton;
    readoutHoursRadio->Text = QCOM_IntervalUnitsStringArray[GUI_INTERVAL_HR_OFFSET];
    GUI_PositionAndSizeBelow(readoutHoursRadio, readoutMinutesRadio, 4);
    GUI_SetObjectInterfaceProperties(readoutHoursRadio);
    readoutHoursRadio->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_SamplingHoursRadioSelected);
    array <Label ^> ^readoutIntervalLabels =
    {
        readoutIntervalLabel,
        readoutIntervalUnitsLabel,
        readoutIntervalRangeLabel
    };
    readoutIntervalUnitsGroupBox->Controls->AddRange(readoutIntervalLabels);
    array <RadioButton ^> ^readoutIntervalRadios =
    {
        readoutMillisecondsRadio,
        readoutSecondsRadio,
        readoutMinutesRadio,
        readoutHoursRadio
    };
    readoutIntervalUnitsGroupBox->Controls->AddRange(readoutIntervalRadios);
    readoutIntervalUnitsGroupBox->Controls->Add(readoutSamplingIntervalBox);
    readoutGeneralGroupBox->Controls->Add(readoutIntervalUnitsGroupBox);
    //------------------------------------------------------------------------
    // Run For a Specified Time check box
    //------------------------------------------------------------------------
    readoutRunSamplingTimedCheck = gcnew CheckBox;
    readoutRunSamplingTimedCheck->Text = _T("Run for a specified time");
    readoutRunSamplingTimedCheck->Location = Point(
        readoutIntervalUnitsGroupBox->Right + 15, 20);
    readoutRunSamplingTimedCheck->Size = Drawing::Size(
        150, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(readoutRunSamplingTimedCheck);
    readoutRunSamplingTimedCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutLimitSamplingTimeChecked);
    readoutRunSamplingTimedCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutLimitSamplingTimeCheckMouseEntered);
    readoutRunSamplingTimedCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutGeneralGroupBox->Controls->Add(readoutRunSamplingTimedCheck);
    //------------------------------------------------------------------------
    // Run For Minutes objects
    //------------------------------------------------------------------------
    readoutLimitSamplingTimeLabel = gcnew Label;
    readoutLimitSamplingTimeLabel->Text = _T("Run for");
    GUI_PositionBelow(readoutLimitSamplingTimeLabel, readoutRunSamplingTimedCheck, 4);
    readoutLimitSamplingTimeLabel->Size = Drawing::Size(
        42, GUI_INFO_LABEL_HEIGHT);
    readoutLimitSamplingTimeLabel->BackColor = Color::Transparent;
    readoutLimitSamplingTimeLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutLimitSamplingTimeAreaMouseEntered);
    readoutLimitSamplingTimeLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutLimitSamplingTimeLabel->Visible = GUI_NO;
    readoutGeneralGroupBox->Controls->Add(readoutLimitSamplingTimeLabel);
    readoutLimitSamplingTimeBox = gcnew TextBox;
    readoutLimitSamplingTimeBox->Location = Point(
        readoutLimitSamplingTimeLabel->Right + 2,
        readoutLimitSamplingTimeLabel->Top - 2);
    readoutLimitSamplingTimeBox->Size = Drawing::Size(
        38, GUI_REGULAR_TEXT_BOX_HEIGHT);
    readoutLimitSamplingTimeBox->Multiline = GUI_NO;
    readoutLimitSamplingTimeBox->AcceptsReturn = GUI_NO;
    readoutLimitSamplingTimeBox->AcceptsTab = GUI_NO;
    readoutLimitSamplingTimeBox->WordWrap = GUI_NO;
    readoutLimitSamplingTimeBox->TextAlign = HorizontalAlignment::Right;
    readoutLimitSamplingTimeBox->BackColor = Color::White;
    readoutLimitSamplingTimeBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateSamplingLimitValue);
    readoutLimitSamplingTimeBox->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutLimitSamplingTimeAreaMouseEntered);
    readoutLimitSamplingTimeBox->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutLimitSamplingTimeBox->Visible = GUI_NO;
    readoutGeneralGroupBox->Controls->Add(readoutLimitSamplingTimeBox);
    readoutLimitSamplingTimeMinutesLabel = gcnew Label;
    readoutLimitSamplingTimeMinutesLabel->Text = _T("minutes");
    readoutLimitSamplingTimeMinutesLabel->Location = Point(
        readoutLimitSamplingTimeBox->Right + 2,
        readoutLimitSamplingTimeLabel->Top);
    readoutLimitSamplingTimeMinutesLabel->Size = Drawing::Size(
        44, GUI_REGULAR_LABEL_HEIGHT);
    readoutLimitSamplingTimeMinutesLabel->BackColor = Color::Transparent;
    readoutLimitSamplingTimeMinutesLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutLimitSamplingTimeAreaMouseEntered);
    readoutLimitSamplingTimeMinutesLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutLimitSamplingTimeMinutesLabel->Visible = GUI_NO;
    readoutGeneralGroupBox->Controls->Add(readoutLimitSamplingTimeMinutesLabel);
    readoutLimitSamplingTimeMinutesRemainingLabel = gcnew Label;
    readoutLimitSamplingTimeMinutesRemainingLabel->Location = Point(
        readoutLimitSamplingTimeMinutesLabel->Right,
        readoutLimitSamplingTimeMinutesLabel->Top);
    readoutLimitSamplingTimeMinutesRemainingLabel->Size = Drawing::Size(
        100, GUI_REGULAR_LABEL_HEIGHT);
    readoutLimitSamplingTimeMinutesRemainingLabel->BackColor = Color::Transparent;
    readoutLimitSamplingTimeMinutesRemainingLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutLimitSamplingTimeAreaMouseEntered);
    readoutLimitSamplingTimeMinutesRemainingLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutLimitSamplingTimeMinutesRemainingLabel->Visible = GUI_NO;
    readoutGeneralGroupBox->Controls->Add(readoutLimitSamplingTimeMinutesRemainingLabel);
    //------------------------------------------------------------------------
    // Display All Frequencies check box
    //------------------------------------------------------------------------
    readoutDisplayAllFrequenciesCheck = gcnew CheckBox;
    readoutDisplayAllFrequenciesCheck->Text = _T("Display frequencies for all transducers");
    readoutDisplayAllFrequenciesCheck->Location = Point(
        readoutGeneralGroupBox->Width - 230, 20);
    readoutDisplayAllFrequenciesCheck->Size = Drawing::Size(
        220, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(readoutDisplayAllFrequenciesCheck);
    readoutDisplayAllFrequenciesCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutDisplayAllFrequenciesChecked);
    readoutDisplayAllFrequenciesCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutDisplayAllFrequenciesCheckMouseEntered);
    readoutDisplayAllFrequenciesCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutGeneralGroupBox->Controls->Add(readoutDisplayAllFrequenciesCheck);
    //------------------------------------------------------------------------
    // Display All V/I Values check box
    //------------------------------------------------------------------------
    readoutDisplayAllVIValuesCheck = gcnew CheckBox;
    readoutDisplayAllVIValuesCheck->Text = _T("Display all voltage and current values");
    GUI_PositionAndSizeBelow(readoutDisplayAllVIValuesCheck, readoutDisplayAllFrequenciesCheck, 4);
    GUI_SetObjectInterfaceProperties(readoutDisplayAllVIValuesCheck);
    readoutDisplayAllVIValuesCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutDisplayAllVIValuesChecked);
    readoutDisplayAllVIValuesCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutDisplayAllVIValuesCheckMouseEntered);
    readoutDisplayAllVIValuesCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutGeneralGroupBox->Controls->Add(readoutDisplayAllVIValuesCheck);
    //------------------------------------------------------------------------
    // Include All In Sampling check box
    //------------------------------------------------------------------------
    readoutIncludeAllInSamplingCheck = gcnew CheckBox;
    readoutIncludeAllInSamplingCheck->Text = _T("Include all units in sampling / logging");
    GUI_PositionAndSizeBelow(readoutIncludeAllInSamplingCheck, readoutDisplayAllVIValuesCheck, 4);
    GUI_SetObjectInterfaceProperties(readoutIncludeAllInSamplingCheck);
    readoutIncludeAllInSamplingCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutIncludeAllInSamplingChecked);
    readoutIncludeAllInSamplingCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutIncludeAllInSamplingCheckMouseEntered);
    readoutIncludeAllInSamplingCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutGeneralGroupBox->Controls->Add(readoutIncludeAllInSamplingCheck);
    //------------------------------------------------------------------------
    // Alternate Pressure Units combo label
    //------------------------------------------------------------------------
    Label ^readoutAlternatePressureUnitsLabel = gcnew Label;
    readoutAlternatePressureUnitsLabel->Text = _T("Alt Pres Units:");
    readoutAlternatePressureUnitsLabel->Location = Point(
        readoutRunSamplingTimedCheck->Left,
        readoutLimitSamplingTimeBox->Bottom + 4);
    readoutAlternatePressureUnitsLabel->Size = Drawing::Size(84, GUI_INFO_LABEL_HEIGHT);
    readoutAlternatePressureUnitsLabel->BackColor = Color::Transparent;
    readoutAlternatePressureUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    readoutAlternatePressureUnitsLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutAlternatePressureUnitsAreaMouseEntered);
    readoutAlternatePressureUnitsLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutGeneralGroupBox->Controls->Add(readoutAlternatePressureUnitsLabel);
    //------------------------------------------------------------------------
    // Alternate Pressure Units combo box
    //------------------------------------------------------------------------
    readoutAlternatePressureUnitsCombo = gcnew ComboBox;
    readoutAlternatePressureUnitsCombo->Location = Point(
        readoutAlternatePressureUnitsLabel->Left,
        readoutAlternatePressureUnitsLabel->Bottom + 2);
    readoutAlternatePressureUnitsCombo->Size = Drawing::Size(
        readoutAlternatePressureUnitsLabel->Width,
        GUI_REGULAR_COMBO_BOX_HEIGHT);
    readoutAlternatePressureUnitsCombo->MaxDropDownItems = QCOM_PressureUnitsStringArray->Length;
    readoutAlternatePressureUnitsCombo->FormattingEnabled = GUI_YES;
    array <String ^> ^pressureUnitsStringArray = gcnew array <String ^>(QCOM_PressureUnitsStringArray->Length);
    for (int offset = 0; offset < QCOM_PressureUnitsStringArray->Length; offset++)
        pressureUnitsStringArray[offset] = String::Concat(_T("  "), QCOM_PressureUnitsStringArray[offset]);
    readoutAlternatePressureUnitsCombo->Items->AddRange(pressureUnitsStringArray);
    readoutAlternatePressureUnitsCombo->Text = pressureUnitsStringArray[QCOM_AlternatePressureUnits];
    delete [] pressureUnitsStringArray;
    readoutAlternatePressureUnitsCombo->BackColor = Color::Lavender;
    GUI_DisplayHandCursorOnHover(readoutAlternatePressureUnitsCombo);
    readoutAlternatePressureUnitsCombo->PreviewKeyDown +=
        gcnew PreviewKeyDownEventHandler(this, &QCOM_GUIClass::QCOM_ComboBoxAcceptEnterKey);
    readoutAlternatePressureUnitsCombo->KeyDown +=
        gcnew KeyEventHandler(this, &QCOM_GUIClass::QCOM_ReadoutAlternatePressureUnitsComboProcessEnterKey);
    readoutAlternatePressureUnitsCombo->SelectedIndexChanged +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutAlternatePressureUnitsComboProcessSelection);
    readoutAlternatePressureUnitsCombo->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutAlternatePressureUnitsAreaMouseEntered);
    readoutAlternatePressureUnitsCombo->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutGeneralGroupBox->Controls->Add(readoutAlternatePressureUnitsCombo);
    //------------------------------------------------------------------------
    // Alternate Temperature Units combo label
    //------------------------------------------------------------------------
    Label ^readoutAlternateTemperatureUnitsLabel = gcnew Label;
    readoutAlternateTemperatureUnitsLabel->Text = _T("Alt Temp Units:");
    readoutAlternateTemperatureUnitsLabel->Location = Point(
        readoutAlternatePressureUnitsLabel->Right + 10,
        readoutAlternatePressureUnitsLabel->Top);
    readoutAlternateTemperatureUnitsLabel->Size = readoutAlternatePressureUnitsLabel->Size;
    readoutAlternateTemperatureUnitsLabel->BackColor = Color::Transparent;
    readoutAlternateTemperatureUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    readoutAlternateTemperatureUnitsLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutAlternateTemperatureUnitsAreaMouseEntered);
    readoutAlternateTemperatureUnitsLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutGeneralGroupBox->Controls->Add(readoutAlternateTemperatureUnitsLabel);
    //------------------------------------------------------------------------
    // Alternate Temperature Units combo box
    //------------------------------------------------------------------------
    readoutAlternateTemperatureUnitsCombo = gcnew ComboBox;
    readoutAlternateTemperatureUnitsCombo->Location = Point(
        readoutAlternateTemperatureUnitsLabel->Left,
        readoutAlternateTemperatureUnitsLabel->Bottom + 2);
    readoutAlternateTemperatureUnitsCombo->Size = Drawing::Size(
        readoutAlternateTemperatureUnitsLabel->Width,
        GUI_REGULAR_COMBO_BOX_HEIGHT);
    readoutAlternateTemperatureUnitsCombo->MaxDropDownItems = QCOM_TemperatureUnitsStringArray->Length;
    readoutAlternateTemperatureUnitsCombo->FormattingEnabled = GUI_YES;
    array <String ^> ^temperatureUnitsStringArray = gcnew array <String ^>(QCOM_TemperatureUnitsStringArray->Length);
    for (int offset = 0; offset < QCOM_TemperatureUnitsStringArray->Length; offset++)
        temperatureUnitsStringArray[offset] = String::Concat(_T("  "), QCOM_TemperatureUnitsStringArray[offset]);
    readoutAlternateTemperatureUnitsCombo->Items->AddRange(temperatureUnitsStringArray);
    readoutAlternateTemperatureUnitsCombo->Text = temperatureUnitsStringArray[QCOM_AlternateTemperatureUnits];
    delete [] temperatureUnitsStringArray;
    readoutAlternateTemperatureUnitsCombo->BackColor = Color::Lavender;
    GUI_DisplayHandCursorOnHover(readoutAlternateTemperatureUnitsCombo);
    readoutAlternateTemperatureUnitsCombo->PreviewKeyDown +=
        gcnew PreviewKeyDownEventHandler(this, &QCOM_GUIClass::QCOM_ComboBoxAcceptEnterKey);
    readoutAlternateTemperatureUnitsCombo->KeyDown +=
        gcnew KeyEventHandler(this, &QCOM_GUIClass::QCOM_ReadoutAlternateTemperatureUnitsComboProcessEnterKey);
    readoutAlternateTemperatureUnitsCombo->SelectedIndexChanged +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutAlternateTemperatureUnitsComboProcessSelection);
    readoutAlternateTemperatureUnitsCombo->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutAlternateTemperatureUnitsAreaMouseEntered);
    readoutAlternateTemperatureUnitsCombo->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutGeneralGroupBox->Controls->Add(readoutAlternateTemperatureUnitsCombo);
    //------------------------------------------------------------------------
    // Start / Stop Sampling button
    //------------------------------------------------------------------------
    readoutStartStopAllSamplingButton = gcnew Button;
    GUI_PositionBelow(readoutStartStopAllSamplingButton, readoutCountPTGroupBox, 6);
    readoutStartStopAllSamplingButton->Size = Drawing::Size(
        GUI_READOUT_OBJECT_WIDTH,
        GUI_DOUBLE_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(readoutStartStopAllSamplingButton);
    readoutStartStopAllSamplingButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_StartStopSamplingButtonClicked);
    readoutStartStopAllSamplingButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutStartStopSamplingButtonMouseEntered);
    readoutStartStopAllSamplingButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutGeneralGroupBox->Controls->Add(readoutStartStopAllSamplingButton);
    //------------------------------------------------------------------------
    // Start Logging All Data button
    //------------------------------------------------------------------------
    readoutStartStopAllLoggingButton = gcnew Button;
    readoutStartStopAllLoggingButton->Location = Point(
        readoutStartStopAllSamplingButton->Right + 15,
        readoutStartStopAllSamplingButton->Top);
    readoutStartStopAllLoggingButton->Size = readoutStartStopAllSamplingButton->Size;
    GUI_SetButtonInterfaceProperties(readoutStartStopAllLoggingButton);
    readoutStartStopAllLoggingButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllStartStopButtonClicked);
    readoutStartStopAllLoggingButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutStartStopLoggingAllButtonMouseEntered);
    readoutStartStopAllLoggingButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutGeneralGroupBox->Controls->Add(readoutStartStopAllLoggingButton);
    //------------------------------------------------------------------------
    // Clear All Logged Data button
    //------------------------------------------------------------------------
    readoutClearAllLogsButton = gcnew Button;
    readoutClearAllLogsButton->Text = GUI_CLEAR_ALL_DATA_LOGS_2;
    readoutClearAllLogsButton->Location = Point(
        readoutStartStopAllLoggingButton->Right + 15,
        readoutStartStopAllLoggingButton->Top);
    readoutClearAllLogsButton->Size = readoutStartStopAllLoggingButton->Size;
    GUI_SetButtonInterfaceProperties(readoutClearAllLogsButton);
    readoutClearAllLogsButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ClearAllDataLogsButtonClicked);
    readoutClearAllLogsButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutClearAllLogsButtonMouseEntered);
    readoutClearAllLogsButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutGeneralGroupBox->Controls->Add(readoutClearAllLogsButton);
    //------------------------------------------------------------------------
    // Pause / Resume button
    //------------------------------------------------------------------------
    readoutPauseResumeButton = gcnew Button;
    readoutPauseResumeButton->Text = GUI_PAUSE_OPERATIONS_STRING;
    readoutPauseResumeButton->Location = Point(
        readoutClearAllLogsButton->Right + 15,
        readoutClearAllLogsButton->Top);
    readoutPauseResumeButton->Size = readoutClearAllLogsButton->Size;
    GUI_SetButtonInterfaceProperties(readoutPauseResumeButton);
    readoutPauseResumeButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_PauseResumeButtonClicked);
    readoutPauseResumeButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_PauseResumeButtonMouseEntered);
    readoutPauseResumeButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutGeneralGroupBox->Controls->Add(readoutPauseResumeButton);
    //------------------------------------------------------------------------
    // Sampling Continuously For label
    //------------------------------------------------------------------------
    readoutContinuousSamplingTimeLabel = gcnew Label;
    readoutContinuousSamplingTimeLabel->Location = Point(
        GUI_DEFAULT_GROUP_BOX_WIDTH - 310,
        readoutGeneralGroupBox->Height - 20);
    readoutContinuousSamplingTimeLabel->Size = Drawing::Size(
        300, GUI_INFO_LABEL_HEIGHT);
    readoutContinuousSamplingTimeLabel->BackColor = Color::Transparent;
    readoutContinuousSamplingTimeLabel->Font = gcnew
        Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Regular);
    readoutContinuousSamplingTimeLabel->TextAlign =
        Drawing::ContentAlignment::MiddleRight;
    readoutContinuousSamplingTimeLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutContinuousSamplingTimeLabelMouseEntered);
    readoutContinuousSamplingTimeLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    readoutGeneralGroupBox->Controls->Add(readoutContinuousSamplingTimeLabel);
    //------------------------------------------------------------------------
    // Epilogue
    //------------------------------------------------------------------------
    RecordDetailedEvent("    General Readout group box created");
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ConstructGeneralReadoutGroupBox()
//----------------------------------------------------------------------------
// QCOM_ConstructGeneralTestingGroupBox
//
// Displays the general Testing group box
//
// Called by:   QCOM_ConstructHomeTabPages
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConstructGeneralTestingGroupBox(
    TabPage         ^tabPage)
{
    String          ^functionName = _T("QCOM_ConstructGeneralTestingGroupBox");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Create the group box
    //------------------------------------------------------------------------
    testingGeneralGroupBox = gcnew GroupBox;
    testingGeneralGroupBox->Text = _T("General Test Controls");
    testingGeneralGroupBox->Location = Point(25, 6);
    testingGeneralGroupBox->Size = Drawing::Size(
        GUI_DEFAULT_GROUP_BOX_WIDTH,
        GUI_GENERAL_GROUP_BOX_HEIGHT);
    testingGeneralGroupBox->ForeColor = Color::Black;
    testingGeneralGroupBox->BackColor = Color::Transparent;
    tabPage->Controls->Add(testingGeneralGroupBox);
    //------------------------------------------------------------------------
    // Start / stop testing button
    //------------------------------------------------------------------------
    testingStartStopAllButton = gcnew Button;
    testingStartStopAllButton->Location = Point(10, 20);
    testingStartStopAllButton->Size = Drawing::Size(
        GUI_DEFAULT_BUTTON_WIDTH,
        GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(testingStartStopAllButton);
    testingStartStopAllButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllStartStopTestingButtonClicked);
    testingStartStopAllButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllStartStopTestingButtonMouseEntered);
    testingStartStopAllButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Save all test results button
    //------------------------------------------------------------------------
    testingSaveAllResultsButton = gcnew Button;
    testingSaveAllResultsButton->Text = _T("Save All Results");
    GUI_PositionAndSizeBelow(testingSaveAllResultsButton, testingStartStopAllButton, 6);
    GUI_SetButtonInterfaceProperties(testingSaveAllResultsButton);
    testingSaveAllResultsButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllSaveResultsButtonClicked);
    testingSaveAllResultsButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllSaveResultsButtonMouseEntered);
    testingSaveAllResultsButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Pause / Resume button
    //------------------------------------------------------------------------
    testingPauseResumeButton = gcnew Button;
    testingPauseResumeButton->Text = GUI_PAUSE_ALL_STRING;
    GUI_PositionAndSizeBelow(testingPauseResumeButton, testingSaveAllResultsButton, 6);
    GUI_SetButtonInterfaceProperties(testingPauseResumeButton);
    testingPauseResumeButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_PauseResumeButtonClicked);
    testingPauseResumeButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_PauseResumeButtonMouseEntered);
    testingPauseResumeButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Reset all test results button
    //------------------------------------------------------------------------
    testingResetAllTestsButton = gcnew Button;
    testingResetAllTestsButton->Text = _T("Reset All Tests");
    testingResetAllTestsButton->Location = Point(
        testingStartStopAllButton->Right + 15,
        testingStartStopAllButton->Top);
    testingResetAllTestsButton->Size = testingStartStopAllButton->Size;
    GUI_SetButtonInterfaceProperties(testingResetAllTestsButton);
    testingResetAllTestsButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllResetButtonClicked);
    testingResetAllTestsButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllResetTestsButtonMouseEntered);
    testingResetAllTestsButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Clear all test results button
    //------------------------------------------------------------------------
    testingClearAllResultsButton = gcnew Button;
    testingClearAllResultsButton->Text = _T("Clear All Results");
    testingClearAllResultsButton->Location = Point(
        testingSaveAllResultsButton->Right + 15,
        testingSaveAllResultsButton->Top);
    testingClearAllResultsButton->Size = testingStartStopAllButton->Size;
    GUI_SetButtonInterfaceProperties(testingClearAllResultsButton);
    testingClearAllResultsButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllClearResultsButtonClicked);
    testingClearAllResultsButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllClearResultsButtonMouseEntered);
    testingClearAllResultsButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Test looping check box
    //------------------------------------------------------------------------
    testingLoopCheck = gcnew CheckBox;
    testingLoopCheck->Text = _T("Run the tests in a loop");
    testingLoopCheck->Location = Point(
        testingResetAllTestsButton->Right + 15,
        testingStartStopAllButton->Top);
    testingLoopCheck->Size = Drawing::Size(135, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(testingLoopCheck);
    testingLoopCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllLoopChecked);
    testingLoopCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllLoopAreaMouseEntered);
    testingLoopCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Test looping time text box
    //------------------------------------------------------------------------
    testingLoopCountBox = gcnew TextBox;
    testingLoopCountBox->Text = String::Concat(QCOM_TestLoopCount);
    testingLoopCountBox->Multiline = GUI_NO;
    testingLoopCountBox->AcceptsReturn = GUI_NO;
    testingLoopCountBox->AcceptsTab = GUI_NO;
    testingLoopCountBox->WordWrap = GUI_NO;
    testingLoopCountBox->TextAlign = HorizontalAlignment::Right;
    testingLoopCountBox->Location = Point(
        testingLoopCheck->Right,
        testingLoopCheck->Top - 2);
    testingLoopCountBox->Size = Drawing::Size(38, GUI_REGULAR_TEXT_BOX_HEIGHT);
    testingLoopCountBox->BackColor = Color::White;
    testingLoopCountBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateTestLoopCountValue);
    testingLoopCountBox->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllLoopAreaMouseEntered);
    testingLoopCountBox->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    testingGeneralGroupBox->Controls->Add(testingLoopCountBox);
    //------------------------------------------------------------------------
    // Test looping time limit label
    //------------------------------------------------------------------------
    testingLoopLimitsLabel = gcnew Label;
    testingLoopLimitsLabel->Text = String::Format(
        "times ({0:D} to {1:D})",
        GUI_MINIMUM_TEST_LOOP_COUNT,
        GUI_MAXIMUM_TEST_LOOP_COUNT);
    testingLoopLimitsLabel->BackColor = Color::Transparent;
    testingLoopLimitsLabel->Location = Point(
        testingLoopCountBox->Right + 1,
        testingLoopCheck->Top);
    testingLoopLimitsLabel->Size = Drawing::Size(
        90, GUI_REGULAR_LABEL_HEIGHT);
    testingLoopLimitsLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllLoopAreaMouseEntered);
    testingLoopLimitsLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    testingGeneralGroupBox->Controls->Add(testingLoopLimitsLabel);
    //------------------------------------------------------------------------
    // Loop forever check box
    //------------------------------------------------------------------------
    testingLoopForeverCheck = gcnew CheckBox;
    testingLoopForeverCheck->Text = _T("Loop forever");
    testingLoopForeverCheck->Location = Point(
        testingResetAllTestsButton->Right + 120,
        testingLoopCheck->Bottom + 4);
    testingLoopForeverCheck->Size = Drawing::Size(
        90, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(testingLoopForeverCheck);
    testingLoopForeverCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllLoopForeverChecked);
    testingLoopForeverCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllLoopAreaMouseEntered);
    testingLoopForeverCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Stop on errors check box
    //------------------------------------------------------------------------
    testingStopOnErrorsCheck = gcnew CheckBox;
    testingStopOnErrorsCheck->Text = _T("Stop on errors");
    GUI_PositionBelow(testingStopOnErrorsCheck, testingLoopCheck, 4);
    testingStopOnErrorsCheck->Size = Drawing::Size(
        102, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(testingStopOnErrorsCheck);
    testingStopOnErrorsCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllStopOnErrorsChecked);
    testingStopOnErrorsCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllStopOnErrorsCheckMouseEntered);
    testingStopOnErrorsCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Detailed test results check box
    //------------------------------------------------------------------------
    testingDetailAllCheck = gcnew CheckBox;
    testingDetailAllCheck->Text = _T("Detailed results");
    testingDetailAllCheck->Location = Point(
        testingLoopCheck->Left,
        testingLoopForeverCheck->Bottom + 4);
    testingDetailAllCheck->Size = testingStopOnErrorsCheck->Size;
    GUI_SetObjectInterfaceProperties(testingDetailAllCheck);
    testingDetailAllCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllDetailedResultsChecked);
    testingDetailAllCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllDetailedResultsCheckMouseEntered);
    testingDetailAllCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Transducer tests check box
    //------------------------------------------------------------------------
    testingDisplayTransducerTestsCheck = gcnew CheckBox;
    testingDisplayTransducerTestsCheck->Text = _T("Display transducer tests");
    GUI_PositionBelow(testingDisplayTransducerTestsCheck, testingLoopForeverCheck, 4);
    testingDisplayTransducerTestsCheck->Size = Drawing::Size(
        150, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(testingDisplayTransducerTestsCheck);
    testingDisplayTransducerTestsCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllDisplayTransducerTestsChecked);
    testingDisplayTransducerTestsCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllDisplayTransducerTestsCheckMouseEntered);
    testingDisplayTransducerTestsCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Test results check box
    //------------------------------------------------------------------------
    testingDisplayTestResultsCheck = gcnew CheckBox;
    testingDisplayTestResultsCheck->Text = _T("Display test results");
    testingDisplayTestResultsCheck->Location = Point(
        testingGeneralGroupBox->Width - 250,
        testingLoopCheck->Top);
    testingDisplayTestResultsCheck->Size = Drawing::Size(
        240, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(testingDisplayTestResultsCheck);
    testingDisplayTestResultsCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllDisplayResultsChecked);
    testingDisplayTestResultsCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllDisplayResultsCheckMouseEntered);
    testingDisplayTestResultsCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Append test results check box
    //------------------------------------------------------------------------
    testingAppendCheck = gcnew CheckBox;
    testingAppendCheck->Text = _T("Append new test results to current results");
    GUI_PositionAndSizeBelow(testingAppendCheck, testingDisplayTestResultsCheck, 4);
    GUI_SetObjectInterfaceProperties(testingAppendCheck);
    testingAppendCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllAppendResultsChecked);
    testingAppendCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllAppendResultsCheckMouseEntered);
    testingAppendCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Auto-save test results check box
    //------------------------------------------------------------------------
    testingAutoSaveCheck = gcnew CheckBox;
    testingAutoSaveCheck->Text = _T("Auto-save the test results to file");
    GUI_PositionAndSizeBelow(testingAutoSaveCheck, testingAppendCheck, 4);
    GUI_SetObjectInterfaceProperties(testingAutoSaveCheck);
    testingAutoSaveCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllAutoSaveResultsChecked);
    testingAutoSaveCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllAutoSaveResultsCheckMouseEntered);
    testingAutoSaveCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Wrap test results check box
    //------------------------------------------------------------------------
    testingWrapCheck = gcnew CheckBox;
    testingWrapCheck->Text = _T("Wrap text in all test results display boxes");
    GUI_PositionAndSizeBelow(testingWrapCheck, testingAutoSaveCheck, 4);
    GUI_SetObjectInterfaceProperties(testingWrapCheck);
    testingWrapCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllWrapResultsChecked);
    testingWrapCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestAllWrapResultsCheckMouseEntered);
    testingWrapCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    //------------------------------------------------------------------------
    // Insert Comment group box
    //------------------------------------------------------------------------
    testingInsertCommentGroupBox = gcnew GroupBox;
    testingInsertCommentGroupBox->Location = Point(
        170, testingGeneralGroupBox->Height - 58);
    testingInsertCommentGroupBox->Size = Drawing::Size(
        GUI_COMMENT_GROUP_BOX_WIDTH,
        GUI_COMMENT_GROUP_BOX_HEIGHT);
    testingInsertCommentGroupBox->BackColor = Color::Transparent;
    testingInsertCommentGroupBox->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestInsertCommentAreaMouseEntered);
    testingInsertCommentGroupBox->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    testingGeneralGroupBox->Controls->Add(testingInsertCommentGroupBox);
    //------------------------------------------------------------------------
    // Insert Comment label
    //------------------------------------------------------------------------
    Label ^testingInsertCommentLabel = gcnew Label;
    testingInsertCommentLabel->Text = _T("Add a comment to all results:");
    testingInsertCommentLabel->Location = Point(4, 10);
    testingInsertCommentLabel->Size = Drawing::Size(
        156, GUI_REGULAR_LABEL_HEIGHT);
    testingInsertCommentLabel->BackColor = Color::Transparent;
    testingInsertCommentLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    testingInsertCommentLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestInsertCommentAreaMouseEntered);
    testingInsertCommentLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    testingInsertCommentGroupBox->Controls->Add(testingInsertCommentLabel);
    //------------------------------------------------------------------------
    // Time Stamp Comments check box
    //------------------------------------------------------------------------
    testingInsertCommentTimeStampCheck = gcnew CheckBox;
    testingInsertCommentTimeStampCheck->Text = _T("Time stamp all comments");
    testingInsertCommentTimeStampCheck->Location = Point(
        testingInsertCommentLabel->Left + 4,
        testingInsertCommentLabel->Bottom + 4);
    testingInsertCommentTimeStampCheck->Size = Drawing::Size(
        testingInsertCommentLabel->Width - 4,
        GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(testingInsertCommentTimeStampCheck);
    testingInsertCommentTimeStampCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestCommentTimeStampChecked);
    testingInsertCommentTimeStampCheck->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestCommentTimeStampCheckMouseEntered);
    testingInsertCommentTimeStampCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    testingInsertCommentGroupBox->Controls->Add(testingInsertCommentTimeStampCheck);
    //------------------------------------------------------------------------
    // Insert Comment text box
    //------------------------------------------------------------------------
    testingInsertCommentBox = gcnew TextBox;
    testingInsertCommentBox->Location = Point(
        testingInsertCommentLabel->Right + 2, 10);
    testingInsertCommentBox->Size = Drawing::Size(
        testingInsertCommentGroupBox->Width - 256, 35);
    testingInsertCommentBox->MaxLength = GUI_MAXIMUM_LOG_COMMENT_SIZE;
    testingInsertCommentBox->Multiline = GUI_YES;
    testingInsertCommentBox->AcceptsReturn = GUI_YES;
    testingInsertCommentBox->AcceptsTab = GUI_YES;
    testingInsertCommentBox->WordWrap = GUI_YES;
    testingInsertCommentBox->ReadOnly = GUI_NO;
    testingInsertCommentBox->ScrollBars = ScrollBars::Vertical;
    testingInsertCommentBox->BackColor = Color::White;
    testingInsertCommentBox->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestInsertCommentAreaMouseEntered);
    testingInsertCommentBox->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    testingInsertCommentGroupBox->Controls->Add(testingInsertCommentBox);
    //------------------------------------------------------------------------
    // Add Comment button
    //------------------------------------------------------------------------
    Button ^testingInsertCommentButton = gcnew Button;
    testingInsertCommentButton->Text = _T("Add");
    testingInsertCommentButton->Location = Point(
        testingInsertCommentBox->Right + 6,
        testingInsertCommentBox->Top + 5);
    testingInsertCommentButton->Size = Drawing::Size(
        32, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(testingInsertCommentButton);
    testingInsertCommentButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestInsertCommentButtonClicked);
    testingInsertCommentButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestInsertCommentButtonMouseEntered);
    testingInsertCommentButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    testingInsertCommentGroupBox->Controls->Add(testingInsertCommentButton);
    //------------------------------------------------------------------------
    // Clear Comment button
    //------------------------------------------------------------------------
    Button ^testingClearCommentButton = gcnew Button;
    testingClearCommentButton->Text = _T("Clear");
    testingClearCommentButton->Location = Point(
        testingInsertCommentButton->Right + 6,
        testingInsertCommentButton->Top);
    testingClearCommentButton->Size = Drawing::Size(
        40, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(testingClearCommentButton);
    testingClearCommentButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestClearCommentButtonClicked);
    testingClearCommentButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestClearCommentButtonMouseEntered);
    testingClearCommentButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    testingInsertCommentGroupBox->Controls->Add(testingClearCommentButton);
    //------------------------------------------------------------------------
    // Attach the components to the Tests Header group box
    //------------------------------------------------------------------------
    array <Button ^> ^testButtons =
    {
        testingStartStopAllButton,
        testingSaveAllResultsButton,
        testingPauseResumeButton,
        testingResetAllTestsButton,
        testingClearAllResultsButton
    };
    testingGeneralGroupBox->Controls->AddRange(testButtons);
    array <CheckBox ^> ^testingChecks =
    {
        testingLoopCheck,
        testingLoopForeverCheck,
        testingStopOnErrorsCheck,
        testingDetailAllCheck,
        testingDisplayTransducerTestsCheck,
        testingDisplayTestResultsCheck,
        testingAppendCheck,
        testingAutoSaveCheck,
        testingWrapCheck
    };
    testingGeneralGroupBox->Controls->AddRange(testingChecks);
    //------------------------------------------------------------------------
    // Epilogue
    //------------------------------------------------------------------------
    RecordDetailedEvent("    General Testing group box created");
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ConstructGeneralTestingGroupBox()
//----------------------------------------------------------------------------
// QCOM_ConstructGeneralUtilitiesGroupBox
//
// Displays the general Utilities info group box
//
// Called by:   QCOM_ConstructHomeTabPages
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConstructGeneralUtilitiesGroupBox(
    TabPage         ^tabPage)
{
    String          ^functionName = _T("QCOM_ConstructGeneralUtilitiesGroupBox");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Create the group box
    //------------------------------------------------------------------------
    GroupBox ^utilitiesGeneralGroupBox = gcnew GroupBox;
    utilitiesGeneralGroupBox->Text = _T("General Utilities");
    utilitiesGeneralGroupBox->Location = Point(25, 6);
    utilitiesGeneralGroupBox->Size = Drawing::Size(
        GUI_DEFAULT_GROUP_BOX_WIDTH,
        GUI_GENERAL_GROUP_BOX_HEIGHT);
    utilitiesGeneralGroupBox->ForeColor = Color::Black;
    utilitiesGeneralGroupBox->BackColor = Color::Transparent;
    tabPage->Controls->Add(utilitiesGeneralGroupBox);
    //------------------------------------------------------------------------
    // Display All Logs button
    //------------------------------------------------------------------------
    utilLogAllDisplayButton = gcnew Button;
    utilLogAllDisplayButton->Text = _T("Display All Data\nLogging Controls");
    utilLogAllDisplayButton->Location = Point(15, 20);
    utilLogAllDisplayButton->Size = Drawing::Size(108, GUI_DOUBLE_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(utilLogAllDisplayButton);
    utilLogAllDisplayButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllDisplayButtonClicked);
    utilLogAllDisplayButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilLogAllDisplayButtonMouseEntered);
    utilLogAllDisplayButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    utilitiesGeneralGroupBox->Controls->Add(utilLogAllDisplayButton);
    //------------------------------------------------------------------------
    // Retrieve Coefficient File Parameters button
    //------------------------------------------------------------------------
    Button ^utilRetrieveCoefficientFileParametersButton = gcnew Button;
    utilRetrieveCoefficientFileParametersButton->Text = _T("Display Coefficient\nFile Parameters");
    utilRetrieveCoefficientFileParametersButton->Location = Point(
        utilLogAllDisplayButton->Right + 13,
        utilLogAllDisplayButton->Top);
    utilRetrieveCoefficientFileParametersButton->Size = Drawing::Size(
        158, GUI_DOUBLE_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(utilRetrieveCoefficientFileParametersButton);
    utilRetrieveCoefficientFileParametersButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilRetrieveCoefficientFileParametersButtonClicked);
    utilRetrieveCoefficientFileParametersButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilRetrieveCoefficientFileParametersButtonMouseEntered);
    utilRetrieveCoefficientFileParametersButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    utilitiesGeneralGroupBox->Controls->Add(utilRetrieveCoefficientFileParametersButton);
    //------------------------------------------------------------------------
    // Convert a Native File button
    //------------------------------------------------------------------------
    Button ^utilConvertNativeCoefficientFileSetButton = gcnew Button;
    utilConvertNativeCoefficientFileSetButton->Text = _T("Convert a Native File Set");
    GUI_PositionBelow(
        utilConvertNativeCoefficientFileSetButton,
        utilRetrieveCoefficientFileParametersButton,
        10);
    utilConvertNativeCoefficientFileSetButton->Size = Drawing::Size(
        utilRetrieveCoefficientFileParametersButton->Width,
        GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(utilConvertNativeCoefficientFileSetButton);
    utilConvertNativeCoefficientFileSetButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilConvertNativeCoefficientFileSetButtonClicked);
    utilConvertNativeCoefficientFileSetButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilConvertNativeCoefficientFileSetButtonMouseEntered);
    utilConvertNativeCoefficientFileSetButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    utilitiesGeneralGroupBox->Controls->Add(utilConvertNativeCoefficientFileSetButton);
    //------------------------------------------------------------------------
    // Download Coefficient Files button
    //------------------------------------------------------------------------
    utilDownloadCoefficientFilesButton = gcnew Button;
    utilDownloadCoefficientFilesButton->Text = _T("Download Coefficient Files");
    GUI_PositionBelow(
        utilDownloadCoefficientFilesButton,
        utilConvertNativeCoefficientFileSetButton,
        10);
    utilDownloadCoefficientFilesButton->Size = Drawing::Size(
        utilConvertNativeCoefficientFileSetButton->Width,
        GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(utilDownloadCoefficientFilesButton);
    utilDownloadCoefficientFilesButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilDownloadCoefficientFilesButtonClicked);
    utilDownloadCoefficientFilesButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilDownloadCoefficientFilesButtonMouseEntered);
    utilDownloadCoefficientFilesButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    utilitiesGeneralGroupBox->Controls->Add(utilDownloadCoefficientFilesButton);
    //------------------------------------------------------------------------
    // Reset All Units button
    //------------------------------------------------------------------------
    utilResetAllUnitsButton = gcnew Button;
    utilResetAllUnitsButton->Text = _T("Reset All Units");
    utilResetAllUnitsButton->Location = Point(
        utilRetrieveCoefficientFileParametersButton->Right + 13,
        utilRetrieveCoefficientFileParametersButton->Top);
    utilResetAllUnitsButton->Size = Drawing::Size(110, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(utilResetAllUnitsButton);
    utilResetAllUnitsButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ResetAllButtonClicked);
    utilResetAllUnitsButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilResetAllButtonMouseEntered);
    utilResetAllUnitsButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    utilitiesGeneralGroupBox->Controls->Add(utilResetAllUnitsButton);
    //------------------------------------------------------------------------
    // Verify Hex File button
    //------------------------------------------------------------------------
    utilVerifyHexFileButton = gcnew Button;
    utilVerifyHexFileButton->Text = _T("Verify Hex File");
    utilVerifyHexFileButton->Location = Point(
        utilResetAllUnitsButton->Right + 13,
        utilResetAllUnitsButton->Top);
    utilVerifyHexFileButton->Size = utilResetAllUnitsButton->Size;
    GUI_SetButtonInterfaceProperties(utilVerifyHexFileButton);
    utilVerifyHexFileButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilVerifyHexFileButtonClicked);
    utilVerifyHexFileButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilVerifyHexFileButtonMouseEntered);
    utilVerifyHexFileButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    utilitiesGeneralGroupBox->Controls->Add(utilVerifyHexFileButton);
    //------------------------------------------------------------------------
    // Convert Data Log to CSV button
    //------------------------------------------------------------------------
    Button ^utilConvertDataLogToCSVButton = gcnew Button;
    utilConvertDataLogToCSVButton->Text = _T("Convert Data Log to CSV");
    utilConvertDataLogToCSVButton->Location = Point(
        utilVerifyHexFileButton->Right + 13,
        utilVerifyHexFileButton->Top);
    utilConvertDataLogToCSVButton->Size = Drawing::Size(
        utilRetrieveCoefficientFileParametersButton->Width,
        GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(utilConvertDataLogToCSVButton);
    utilConvertDataLogToCSVButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilConvertDataLogToCSVButtonClicked);
    utilConvertDataLogToCSVButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilConvertDataLogToCSVButtonMouseEntered);
    utilConvertDataLogToCSVButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    utilitiesGeneralGroupBox->Controls->Add(utilConvertDataLogToCSVButton);
    //------------------------------------------------------------------------
    // Convert CSV to Data Log button
    //------------------------------------------------------------------------
    Button ^utilConvertCSVToDataLogButton = gcnew Button;
    utilConvertCSVToDataLogButton->Text = _T("Convert CSV to Data Log");
    GUI_PositionBelow(utilConvertCSVToDataLogButton, utilConvertDataLogToCSVButton, 10);
    utilConvertCSVToDataLogButton->Size = Drawing::Size(
        utilRetrieveCoefficientFileParametersButton->Width,
        GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(utilConvertCSVToDataLogButton);
    utilConvertCSVToDataLogButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilConvertCSVToDataLogButtonClicked);
    utilConvertCSVToDataLogButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilConvertCSVToDataLogButtonMouseEntered);
    utilConvertCSVToDataLogButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    utilitiesGeneralGroupBox->Controls->Add(utilConvertCSVToDataLogButton);
    //------------------------------------------------------------------------
    // Convert Readings button
    //------------------------------------------------------------------------
    Button ^utilConvertReadingsButton = gcnew Button;
    utilConvertReadingsButton->Text = _T("Convert Readings");
    utilConvertReadingsButton->Location = Point(
        utilConvertDataLogToCSVButton->Right + 13,
        utilConvertDataLogToCSVButton->Top);
    utilConvertReadingsButton->Size = utilResetAllUnitsButton->Size;
    GUI_SetButtonInterfaceProperties(utilConvertReadingsButton);
    utilConvertReadingsButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilConvertReadingsButtonClicked);
    utilConvertReadingsButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilConvertReadingsButtonMouseEntered);
    utilConvertReadingsButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    utilitiesGeneralGroupBox->Controls->Add(utilConvertReadingsButton);
    //------------------------------------------------------------------------
    // Epilogue
    //------------------------------------------------------------------------
    RecordDetailedEvent("    General Utilities group box created");
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ConstructGeneralUtilitiesGroupBox()
//----------------------------------------------------------------------------
// QCOM_ConstructHomeTabPages
//
// Sets up the tab pages in the home window
//
// Called by:   QCOM_ConstructHomeWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConstructHomeTabPages(void)
{
    String          ^functionName = _T("QCOM_ConstructHomeTabPages");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    homeTabControl = gcnew TabControl;
    GUI_PositionBelow(homeTabControl, openingBannerLabel, 2);
    homeTabControl->Size = Drawing::Size(
        GUI_HOME_TAB_PAGE_WIDTH,
        GUI_HOME_TAB_PAGE_HEIGHT);
    homeTabControl->Appearance = TabAppearance::Normal;
    homeTabControl->Alignment = TabAlignment::Left;
    homeTabControl->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_HomeTabSelected);
    homeTabControl->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_HomeTabMouseEntered);
    homeTabControl->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    homeTabControl->ShowToolTips = GUI_YES;
    homeTabControl->SelectedIndex = GUI_TAB_PAGE_READOUT;
    //------------------------------------------------------------------------
    // Set up the controls for all possible individual tab pages
    //------------------------------------------------------------------------
    for (DWORD homeTabPageNumber = 0; homeTabPageNumber < GUI_MINIMUM_NUMBER_OF_HOME_TAB_PAGES; homeTabPageNumber++)
    {
        switch (homeTabPageNumber)
        {
            case GUI_TAB_PAGE_READOUT :                                         // 0
            {
                TabPage ^readoutHomeTabPage = gcnew TabPage;
                readoutHomeTabPage->Text = _T("Readout");
                readoutHomeTabPage->ToolTipText = _T("Displays the readout controls");
                QCOM_ConstructGeneralReadoutGroupBox(readoutHomeTabPage);
                //------------------------------------------------------------
                // Set up the Readout tab control
                //------------------------------------------------------------
                readoutTabControl = gcnew TabControl;
                readoutTabControl->Location = Point(
                    10, GUI_GENERAL_GROUP_BOX_HEIGHT + 20);
                readoutTabControl->Size = Drawing::Size(
                    GUI_UNIT_TAB_PAGE_WIDTH,
                    GUI_UNIT_TAB_PAGE_HEIGHT);
                readoutTabControl->Appearance = TabAppearance::Normal;
                readoutTabControl->Alignment = TabAlignment::Top;
                readoutHomeTabPage->Controls->Add(readoutTabControl);
                for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
                {
                    QCOM_ConstructUnitReadoutGroupBox(QCOM_UnitInfoArray[unitNumber]);
                }
                readoutHomeTabPage->TabIndex = homeTabPageNumber;
                readoutHomeTabPage->BackgroundImage = whiteMarbleBackground;
//                readoutHomeTabPage->UseVisualStyleBackColor = GUI_YES;
                homeTabControl->Controls->Add(readoutHomeTabPage);
                break;
            }
            case GUI_TAB_PAGE_UTILITIES :                                       // 1
            {
                TabPage ^utilitiesHomeTabPage = gcnew TabPage;
                utilitiesHomeTabPage->Text = _T("Utilities");
                utilitiesHomeTabPage->ToolTipText = _T("Displays the QCOM utilities");
                QCOM_ConstructGeneralUtilitiesGroupBox(utilitiesHomeTabPage);
                //------------------------------------------------------------
                // Set up the Utilities tab control
                //------------------------------------------------------------
                utilitiesTabControl = gcnew TabControl;
                utilitiesTabControl->Location = Point(
                    10, GUI_GENERAL_GROUP_BOX_HEIGHT + 20);
                utilitiesTabControl->Size = Drawing::Size(
                    GUI_UNIT_TAB_PAGE_WIDTH,
                    GUI_UNIT_TAB_PAGE_HEIGHT);
                utilitiesTabControl->Appearance = TabAppearance::Normal;
                utilitiesTabControl->Alignment = TabAlignment::Top;
                utilitiesHomeTabPage->Controls->Add(utilitiesTabControl);
                for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
                {
                    QCOM_ConstructUnitUtilitiesGroupBox(QCOM_UnitInfoArray[unitNumber]);
                }
                utilitiesHomeTabPage->TabIndex = homeTabPageNumber;
                utilitiesHomeTabPage->BackgroundImage = whiteMarbleBackground;
//                utilitiesHomeTabPage->UseVisualStyleBackColor = GUI_YES;
                homeTabControl->Controls->Add(utilitiesHomeTabPage);
                break;
            }
            case GUI_TAB_PAGE_TESTING :                                         // 2
            {
                TabPage ^testingHomeTabPage = gcnew TabPage;
                testingHomeTabPage->Text = _T("Testing");
                testingHomeTabPage->ToolTipText = _T("Displays the QCOM software test fixture");
                QCOM_ConstructGeneralTestingGroupBox(testingHomeTabPage);
                //------------------------------------------------------------
                // Set up the Testing tab control
                //------------------------------------------------------------
                testingTabControl = gcnew TabControl;
                testingTabControl->Location = Point(
                    10, GUI_GENERAL_GROUP_BOX_HEIGHT + 20);
                testingTabControl->Size = Drawing::Size(
                    GUI_UNIT_TAB_PAGE_WIDTH,
                    GUI_UNIT_TAB_PAGE_HEIGHT);
                testingTabControl->Appearance = TabAppearance::Normal;
                testingTabControl->Alignment = TabAlignment::Top;
                testingHomeTabPage->Controls->Add(testingTabControl);
                for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
                {
                    QCOM_ConstructUnitTestingGroupBox(QCOM_UnitInfoArray[unitNumber]);
                }
                testingHomeTabPage->TabIndex = homeTabPageNumber;
                testingHomeTabPage->BackgroundImage = whiteMarbleBackground;
//                testingHomeTabPage->UseVisualStyleBackColor = GUI_YES;
                homeTabControl->Controls->Add(testingHomeTabPage);
                break;
            }
            case GUI_TAB_PAGE_EXPERT :                                          // 3
            {
                expertHomeTabPage = gcnew TabPage;
                expertHomeTabPage->Text = _T("Expert");
                expertHomeTabPage->ToolTipText = _T("Displays the expert (advanced) functions, controls, and utilities");
                QCOM_ConstructGeneralExpertGroupBox(expertHomeTabPage);
                //------------------------------------------------------------
                // Set up the Expert tab control
                //------------------------------------------------------------
                expertTabControl = gcnew TabControl;
                expertTabControl->Location = Point(
                    10, GUI_GENERAL_GROUP_BOX_HEIGHT + 20);
                expertTabControl->Size = Drawing::Size(
                    GUI_UNIT_TAB_PAGE_WIDTH,
                    GUI_UNIT_TAB_PAGE_HEIGHT);
                expertTabControl->Appearance = TabAppearance::Normal;
                expertTabControl->Alignment = TabAlignment::Top;
                expertHomeTabPage->Controls->Add(expertTabControl);
                for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
                {
                    QCOM_ConstructUnitExpertGroupBox(QCOM_UnitInfoArray[unitNumber]);
                }
                expertHomeTabPage->TabIndex = homeTabPageNumber;
                expertHomeTabPage->BackgroundImage = whiteMarbleBackground;
//                expertHomeTabPage->UseVisualStyleBackColor = GUI_YES;
                if (QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE)
                {
                    homeTabControl->Controls->Add(expertHomeTabPage);
                }
                break;
            }
            default :
            {
                GUI_DisplaySimpleError(functionName,
                    "Undefined tab page {0:D} selected",
                    homeTabPageNumber);
                break;
            }
        }                               // end of switch (homeTabPageNumber)
    }                                   // end of for (homeTabPageNumber = 0; ...)
    //------------------------------------------------------------------------
    // Register the resulting tab control
    //------------------------------------------------------------------------
    Controls->Add(homeTabControl);
    QCOM_GeneralInfo->flags |= QCOM_GENERAL_GUI_READY_FOR_UPDATING;
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ConstructHomeTabPages()
//----------------------------------------------------------------------------
// QCOM_ConstructUnitExpertGroupBox
//
// Displays a Expert group box for one QCOM transducer in the primary tab
//
// Called by:   QCOM_ConstructHomeTabPages
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConstructUnitExpertGroupBox(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_ConstructUnitExpertGroupBox");
    //------------------------------------------------------------------------
    if (unit)
    {
        unitNumber = unit->unitNumber;
        RecordVerboseEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Create the tab page
        //--------------------------------------------------------------------
        TabPage ^expertUnitTabPage = gcnew TabPage;
        expertUnitTabPage->TabIndex = unitNumber;
        expertUnitTabPage->BackgroundImage = whiteMarbleBackground;
        expertUnitTabPageArray[unitNumber] = expertUnitTabPage;
//        expertTabControl->Controls->Add(expertUnitTabPage);
        //--------------------------------------------------------------------
        // Create the group box
        //--------------------------------------------------------------------
        GroupBox ^expertUnitGroupBox = gcnew GroupBox;
        expertUnitGroupBox->Location = Point(10, 6);
        expertUnitGroupBox->Size = Drawing::Size(
            GUI_DEFAULT_GROUP_BOX_WIDTH,
            GUI_UNIT_GROUP_BOX_HEIGHT);
        expertUnitGroupBox->ForeColor = Color::Black;
        expertUnitGroupBox->BackColor = Color::Transparent;
        expertGroupBoxArray[unitNumber] = expertUnitGroupBox;
        expertUnitTabPage->Controls->Add(expertUnitGroupBox);
        //--------------------------------------------------------------------
        // Erase Transducer Coefficient Data File button
        //--------------------------------------------------------------------
        Button ^expertUnitEraseCFButton = gcnew Button;
        expertUnitEraseCFButton->Location = Point(10, 20);
        expertUnitEraseCFButton->Size = Drawing::Size(180, GUI_REGULAR_BUTTON_HEIGHT);
        expertUnitEraseCFButton->Text = _T("Erase Coefficient Data");
        GUI_SetUnitButtonInterfaceProperties(
            expertUnitEraseCFButton,
            unitNumber);
        expertUnitEraseCFButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertEraseCoefficientDataButtonClicked);
        expertUnitEraseCFButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertEraseCoefficientDataButtonMouseEntered);
        expertUnitEraseCFButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        expertUnitGroupBox->Controls->Add(expertUnitEraseCFButton);
        //--------------------------------------------------------------------
        // Transducer Power button
        //--------------------------------------------------------------------
        Button ^expertUnitTransducerPowerButton = gcnew Button;
        GUI_PositionAndSizeBelow(expertUnitTransducerPowerButton, expertUnitEraseCFButton, 10);
        GUI_SetUnitObjectInterfaceProperties(
            expertUnitTransducerPowerButton,
            unitNumber);
        expertUnitTransducerPowerButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertUnitTransducerPowerButtonClicked);
        expertUnitTransducerPowerButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertUnitTransducerPowerButtonMouseEntered);
        expertUnitTransducerPowerButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        expertTransducerPowerButtonArray[unitNumber] = expertUnitTransducerPowerButton;
        expertUnitGroupBox->Controls->Add(expertUnitTransducerPowerButton);
        //--------------------------------------------------------------------
        // Display Coefficient Data button
        //--------------------------------------------------------------------
        Button ^expertDisplayCFButton = gcnew Button;
        expertDisplayCFButton->Text = _T("Display\nCoefficient\nData");
        expertDisplayCFButton->Location = Point(
            expertUnitEraseCFButton->Right + 15,
            expertUnitEraseCFButton->Top);
        expertDisplayCFButton->Size = Drawing::Size(70, 60);
        GUI_SetUnitButtonInterfaceProperties(
            expertDisplayCFButton,
            unitNumber);
        expertDisplayCFButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DisplayLoadedCoefficientDataButtonClicked);
        expertDisplayCFButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertDisplayCoefficientDataButtonMouseEntered);
        expertDisplayCFButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        expertUnitGroupBox->Controls->Add(expertDisplayCFButton);
        //--------------------------------------------------------------------
        // Send reading samples check box
        //--------------------------------------------------------------------
        CheckBox ^expertSendTransducerReadingsCheck = gcnew CheckBox;
        expertSendTransducerReadingsCheck->Text = _T("Send transducer reading samples");
        expertSendTransducerReadingsCheck->Location = Point(
            expertDisplayCFButton->Right + 15,
            expertDisplayCFButton->Top);
        expertSendTransducerReadingsCheck->Size = Drawing::Size(
            200, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            expertSendTransducerReadingsCheck,
            unitNumber);
        expertSendTransducerReadingsCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertUnitSendTransducerReadingsChecked);
        expertSendTransducerReadingsCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertUnitSendTransducerReadingsAreaMouseEntered);
        expertSendTransducerReadingsCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        expertSendTransducerReadingsCheckArray[unitNumber] = expertSendTransducerReadingsCheck;
        expertUnitGroupBox->Controls->Add(expertSendTransducerReadingsCheck);
        //--------------------------------------------------------------------
        // Send reading samples box label
        //--------------------------------------------------------------------
        Label ^expertSendEveryLabel = gcnew Label;
        expertSendEveryLabel->Text = _T("every");
        GUI_PositionBelow(expertSendEveryLabel, expertSendTransducerReadingsCheck, 4);
        expertSendEveryLabel->Size = Drawing::Size(
            32, GUI_REGULAR_LABEL_HEIGHT);
        expertSendEveryLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        expertSendEveryLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertUnitSendTransducerReadingsAreaMouseEntered);
        expertSendEveryLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        expertSendEveryLabelArray[unitNumber] = expertSendEveryLabel;
        expertSendEveryLabel->Visible =
            (unit->flags & QCOM_UNIT_SEND_XD_READINGS) ? GUI_YES : GUI_NO;
        expertUnitGroupBox->Controls->Add(expertSendEveryLabel);
        //--------------------------------------------------------------------
        // Send reading samples box
        //--------------------------------------------------------------------
        TextBox ^expertSendEveryBox = gcnew TextBox;
        expertSendEveryBox->Tag = unitNumber;
        expertSendEveryBox->Text = String::Concat(QCOM_CurrentSendEveryInterval[unitNumber]);
        expertSendEveryBox->Multiline = GUI_NO;
        expertSendEveryBox->AcceptsReturn = GUI_NO;
        expertSendEveryBox->AcceptsTab = GUI_NO;
        expertSendEveryBox->WordWrap = GUI_NO;
        expertSendEveryBox->ReadOnly = GUI_NO;
        expertSendEveryBox->TabStop = GUI_NO;
        expertSendEveryBox->Location = Point(
            expertSendEveryLabel->Right + 2,
            expertSendEveryLabel->Top - 2);
        expertSendEveryBox->Size = Drawing::Size(
            40, GUI_REGULAR_TEXT_BOX_HEIGHT);
        expertSendEveryBox->TextAlign = HorizontalAlignment::Right;
        expertSendEveryBox->Validating +=
            gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateSendEveryIntervalValue);
        expertSendEveryBox->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertUnitSendTransducerReadingsAreaMouseEntered);
        expertSendEveryBox->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        expertSendEveryBoxArray[unitNumber] = expertSendEveryBox;
        expertSendEveryBox->Visible =
            (unit->flags & QCOM_UNIT_SEND_XD_READINGS) ? GUI_YES : GUI_NO;
        expertUnitGroupBox->Controls->Add(expertSendEveryBox);
        //--------------------------------------------------------------------
        // Send reading samples label
        //--------------------------------------------------------------------
        Label ^expertSendEveryMinutesLabel = gcnew Label;
        expertSendEveryMinutesLabel->Text = String::Format(
            "minutes ({0:D} to {1:D})",
            GUI_MINIMUM_SEND_EVERY_INTERVAL,
            GUI_MAXIMUM_SEND_EVERY_INTERVAL);
        expertSendEveryMinutesLabel->Location = Point(
            expertSendEveryBox->Right + 2,
            expertSendEveryLabel->Top);
        expertSendEveryMinutesLabel->Size = Drawing::Size(
            124, GUI_REGULAR_LABEL_HEIGHT);
        expertSendEveryMinutesLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        expertSendEveryMinutesLabel->BackColor = Color::Transparent;
        expertSendEveryMinutesLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertUnitSendTransducerReadingsAreaMouseEntered);
        expertSendEveryMinutesLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        expertSendEveryMinutesLabelArray[unitNumber] = expertSendEveryMinutesLabel;
        expertSendEveryMinutesLabel->Visible =
            (unit->flags & QCOM_UNIT_SEND_XD_READINGS) ? GUI_YES : GUI_NO;
        expertUnitGroupBox->Controls->Add(expertSendEveryMinutesLabel);
        //--------------------------------------------------------------------
        // Send reading samples minutes remaining label
        //--------------------------------------------------------------------
        Label ^expertSendEveryMinutesRemainingLabel = gcnew Label;
        expertSendEveryMinutesRemainingLabel->Location = Point(
            expertSendEveryLabel->Left,
            expertSendEveryBox->Bottom + 2);
        expertSendEveryMinutesRemainingLabel->Size = Drawing::Size(
            expertSendTransducerReadingsCheck->Width,
            GUI_REGULAR_LABEL_HEIGHT);
        expertSendEveryMinutesRemainingLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        expertSendEveryMinutesRemainingLabel->BackColor = Color::Transparent;
        expertSendEveryMinutesRemainingLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertUnitSendTransducerReadingsAreaMouseEntered);
        expertSendEveryMinutesRemainingLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        expertSendEveryMinutesRemainingLabelArray[unitNumber] = expertSendEveryMinutesRemainingLabel;
        QCOM_UpdateSendEveryMinutesRemainingLabel(unitNumber);
        expertSendEveryMinutesRemainingLabel->Visible =
            (unit->flags & QCOM_UNIT_SEND_XD_READINGS) ? GUI_YES : GUI_NO;
        expertUnitGroupBox->Controls->Add(expertSendEveryMinutesRemainingLabel);
        //--------------------------------------------------------------------
        // Send Transducer Readings tool tip for all the associated objects
        //--------------------------------------------------------------------
        ToolTip ^expertSendEveryToolTip = gcnew ToolTip;
        expertSendEveryToolTip->ShowAlways = GUI_YES;
        expertSendEveryToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        expertSendEveryToolTip->ToolTipTitle = _T("Send Transducer Reading Samples");
        String ^expertSendEveryToolTipText = String::Concat(
            "Emails and/or texts the current transducer pressure and temperature", Environment::NewLine,
            "readings to the addresses and/or numbers entered above if the respective", Environment::NewLine,
            "To: box contains a valid entry. The readings will reflect the units selected", Environment::NewLine,
            "in the Pressure/Temperature group box of the Readout tab at the period", Environment::NewLine,
            "shown in this text box. If Counts is selected, the default units will be used.");
        expertSendEveryToolTip->SetToolTip(expertSendEveryBox, expertSendEveryToolTipText);
        expertSendEveryToolTip->SetToolTip(expertSendEveryLabel, expertSendEveryToolTipText);
        expertSendEveryToolTip->SetToolTip(expertSendEveryMinutesLabel, expertSendEveryToolTipText);
        expertSendEveryToolTip->SetToolTip(expertSendEveryMinutesRemainingLabel, expertSendEveryToolTipText);
        expertSendEveryToolTip->SetToolTip(expertSendTransducerReadingsCheck, expertSendEveryToolTipText);
        delete expertSendEveryToolTipText;
        //--------------------------------------------------------------------
        // Manage Multiple Coefficient Storage button
        //--------------------------------------------------------------------
        Button ^expertManageMultipleCFButton = gcnew Button;
        expertManageMultipleCFButton->Text = _T("Manage Multiple\nCoefficient Storage");
        expertManageMultipleCFButton->Location = Point(
            expertSendTransducerReadingsCheck->Right + 15,
            expertUnitEraseCFButton->Top);
        expertManageMultipleCFButton->Size = Drawing::Size(
            140, GUI_DOUBLE_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            expertManageMultipleCFButton,
            unitNumber);
        expertManageMultipleCFButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertManageMultipleCoefficientDataButtonClicked);
        expertManageMultipleCFButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExpertManageMultipleCoefficientDataButtonMouseEntered);
        expertManageMultipleCFButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        expertManageMultipleCFButtonArray[unitNumber] = expertManageMultipleCFButton;
        expertUnitGroupBox->Controls->Add(expertManageMultipleCFButton);
    }                                   // end of if (unit)
    //------------------------------------------------------------------------
    // Epilogue
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ConstructUnitExpertGroupBox()
//----------------------------------------------------------------------------
// QCOM_ConstructUnitReadoutGroupBox
//
// Displays a Readout group box for one QCOM transducer in the primary tab
//
// Called by:   QCOM_ConstructHomeTabPages
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConstructUnitReadoutGroupBox(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_ConstructUnitReadoutGroupBox");
    //------------------------------------------------------------------------
    if (unit)
    {
        unitNumber = unit->unitNumber;
        RecordVerboseEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Create the tab page
        //--------------------------------------------------------------------
        TabPage ^readoutUnitTabPage = gcnew TabPage;
        readoutUnitTabPage->TabIndex = unitNumber;
        readoutUnitTabPage->BackgroundImage = whiteMarbleBackground;
        readoutUnitTabPageArray[unitNumber] = readoutUnitTabPage;
//        readoutTabControl->Controls->Add(readoutUnitTabPage);
        //--------------------------------------------------------------------
        // Create the group box
        //--------------------------------------------------------------------
        GroupBox ^readoutUnitGroupBox = gcnew GroupBox;
        readoutUnitGroupBox->Location = Point(10, 6);
        readoutUnitGroupBox->Size = Drawing::Size(
            GUI_DEFAULT_GROUP_BOX_WIDTH,
            GUI_UNIT_GROUP_BOX_HEIGHT);
        readoutUnitGroupBox->ForeColor = Color::Black;
        readoutUnitGroupBox->BackColor = Color::Transparent;
        readoutUnitTabPage->Controls->Add(readoutUnitGroupBox);
        //--------------------------------------------------------------------
        // Pressure title label
        //--------------------------------------------------------------------
        Label ^readoutPressureTitleLabel = gcnew Label;
        readoutPressureTitleLabel->Text = _T("Pressure");
        readoutPressureTitleLabel->Location = Point(15, 24);
        readoutPressureTitleLabel->Size = Drawing::Size(
            GUI_READOUT_OBJECT_WIDTH,
            GUI_REGULAR_LABEL_HEIGHT);
        readoutPressureTitleLabel->BackColor = Color::Transparent;
        readoutPressureTitleLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        readoutPressureTitleLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutPressureAreaMouseEntered);
        readoutPressureTitleLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutPressureTitleLabelArray[unitNumber] = readoutPressureTitleLabel;
        //--------------------------------------------------------------------
        // Pressure value display box
        //--------------------------------------------------------------------
        TextBox ^readoutPressureBox = gcnew TextBox;
        readoutPressureBox->Multiline = GUI_NO;
        readoutPressureBox->AcceptsReturn = GUI_NO;
        readoutPressureBox->AcceptsTab = GUI_NO;
        readoutPressureBox->WordWrap = GUI_NO;
        readoutPressureBox->ReadOnly = GUI_YES;
        readoutPressureBox->TabStop = GUI_NO;
        readoutPressureBox->Location = Point(
            readoutPressureTitleLabel->Left,
            readoutPressureTitleLabel->Bottom + 4);
        readoutPressureBox->Size = Drawing::Size(
            readoutPressureTitleLabel->Width,
            GUI_REGULAR_TEXT_BOX_HEIGHT);
        readoutPressureBox->TextAlign = HorizontalAlignment::Center;
        readoutPressureBox->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutPressureAreaMouseEntered);
        readoutPressureBox->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutPressureBoxArray[unitNumber] = readoutPressureBox;
        //--------------------------------------------------------------------
        // Pressure units label
        //--------------------------------------------------------------------
        Label ^readoutPressureUnitsLabel = gcnew Label;
        GUI_PositionBelow(readoutPressureUnitsLabel, readoutPressureBox, 2);
        readoutPressureUnitsLabel->Size = Drawing::Size(
            readoutPressureBox->Width,
            GUI_REGULAR_LABEL_HEIGHT);
        readoutPressureUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        readoutPressureUnitsLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutPressureAreaMouseEntered);
        readoutPressureUnitsLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutPressureUnitsLabelArray[unitNumber] = readoutPressureUnitsLabel;
        //--------------------------------------------------------------------
        // Temperature title label
        //--------------------------------------------------------------------
        Label ^readoutTemperatureTitleLabel = gcnew Label;
        readoutTemperatureTitleLabel->Text = _T("Temperature");
        readoutTemperatureTitleLabel->Location = Point(
            readoutPressureTitleLabel->Right + 15,
            readoutPressureTitleLabel->Top);
        readoutTemperatureTitleLabel->Size = readoutPressureTitleLabel->Size;
        readoutTemperatureTitleLabel->BackColor = Color::Transparent;
        readoutTemperatureTitleLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        readoutTemperatureTitleLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutTemperatureAreaMouseEntered);
        readoutTemperatureTitleLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutTemperatureTitleLabelArray[unitNumber] = readoutTemperatureTitleLabel;
        //--------------------------------------------------------------------
        // Temperature value display box
        //--------------------------------------------------------------------
        TextBox ^readoutTemperatureBox = gcnew TextBox;
        readoutTemperatureBox->Multiline = GUI_NO;
        readoutTemperatureBox->AcceptsReturn = GUI_NO;
        readoutTemperatureBox->AcceptsTab = GUI_NO;
        readoutTemperatureBox->WordWrap = GUI_NO;
        readoutTemperatureBox->ReadOnly = GUI_YES;
        readoutTemperatureBox->TabStop = GUI_NO;
        readoutTemperatureBox->Location = Point(
            readoutTemperatureTitleLabel->Left,
            readoutPressureBox->Top);
        readoutTemperatureBox->Size = readoutPressureBox->Size;
        readoutTemperatureBox->TextAlign = HorizontalAlignment::Center;
        readoutTemperatureBox->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutTemperatureAreaMouseEntered);
        readoutTemperatureBox->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutTemperatureBoxArray[unitNumber] = readoutTemperatureBox;
        //--------------------------------------------------------------------
        // Temperature units label
        //--------------------------------------------------------------------
        Label ^readoutTemperatureUnitsLabel = gcnew Label;
        readoutTemperatureUnitsLabel->Location = Point(
            readoutTemperatureBox->Left,
            readoutPressureUnitsLabel->Top);
        readoutTemperatureUnitsLabel->Size = Drawing::Size(
            readoutTemperatureBox->Width,
            GUI_REGULAR_LABEL_HEIGHT);
        readoutTemperatureUnitsLabel->BackColor = Color::Transparent;
        readoutTemperatureUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        readoutTemperatureUnitsLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutTemperatureAreaMouseEntered);
        readoutTemperatureUnitsLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutTemperatureUnitsLabelArray[unitNumber] = readoutTemperatureUnitsLabel;
        //--------------------------------------------------------------------
        // Start / Stop Data Logging button
        //--------------------------------------------------------------------
        Button ^readoutStartStopLoggingButton = gcnew Button;
        readoutStartStopLoggingButton->Location = Point(
            readoutTemperatureBox->Right + 15,
            readoutTemperatureTitleLabel->Top);
        readoutStartStopLoggingButton->Size = Drawing::Size(
            GUI_READOUT_OBJECT_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            readoutStartStopLoggingButton,
            unitNumber);
        readoutStartStopLoggingButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitStartStopButtonClicked);
        readoutStartStopLoggingButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutLogUnitStartStopButtonMouseEntered);
        readoutStartStopLoggingButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutStartStopLoggingButtonArray[unitNumber] = readoutStartStopLoggingButton;
        //--------------------------------------------------------------------
        // Clear Data Log button
        //--------------------------------------------------------------------
        Button ^readoutClearLogButton = gcnew Button;
        readoutClearLogButton->Text = _T("Clear Data Log");
        GUI_PositionAndSizeBelow(readoutClearLogButton, readoutStartStopLoggingButton, 3);
        GUI_SetUnitButtonInterfaceProperties(
            readoutClearLogButton,
            unitNumber);
        readoutClearLogButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitClearDataButtonClicked);
        readoutClearLogButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutClearUnitLogButtonMouseEntered);
        readoutClearLogButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutClearLogButtonArray[unitNumber] = readoutClearLogButton;
        //--------------------------------------------------------------------
        // Start / Stop Sampling button
        //--------------------------------------------------------------------
        Button ^readoutUnitStartStopSamplingButton = gcnew Button;
        readoutUnitStartStopSamplingButton->Location = Point(
            readoutStartStopLoggingButton->Right + 15,
            readoutStartStopLoggingButton->Top);
        readoutUnitStartStopSamplingButton->Size = readoutStartStopLoggingButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            readoutUnitStartStopSamplingButton,
            unitNumber);
        readoutUnitStartStopSamplingButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutUnitStartStopSamplingButtonClicked);
        readoutUnitStartStopSamplingButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutUnitStartStopSamplingButtonMouseEntered);
        readoutUnitStartStopSamplingButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutStartStopSamplingButtonArray[unitNumber] = readoutUnitStartStopSamplingButton;
        //--------------------------------------------------------------------
        // Display Graph button
        //--------------------------------------------------------------------
        Button ^readoutDisplayDataGraphButton = gcnew Button;
        readoutDisplayDataGraphButton->Text = _T("Display Graph");
        readoutDisplayDataGraphButton->Location = Point(
            readoutUnitStartStopSamplingButton->Right + 15,
            readoutUnitStartStopSamplingButton->Top);
        readoutDisplayDataGraphButton->Size = readoutUnitStartStopSamplingButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            readoutDisplayDataGraphButton,
            unitNumber);
        readoutDisplayDataGraphButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutDisplayUnitGraphButtonClicked);
        readoutDisplayDataGraphButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutDisplayUnitGraphButtonMouseEntered);
        readoutDisplayDataGraphButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutDisplayDataGraphButtonArray[unitNumber] = readoutDisplayDataGraphButton;
        //--------------------------------------------------------------------
        // Pressure Frequency title label
        //--------------------------------------------------------------------
        Label ^readoutPressureFrequencyTitleLabel = gcnew Label;
        readoutPressureFrequencyTitleLabel->Text = _T("Pres Frequency");
        GUI_PositionBelow(readoutPressureFrequencyTitleLabel, readoutPressureUnitsLabel, 20);
        readoutPressureFrequencyTitleLabel->Size = Drawing::Size(
            readoutPressureTitleLabel->Width,
            GUI_REGULAR_LABEL_HEIGHT);
        readoutPressureFrequencyTitleLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        readoutPressureFrequencyTitleLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutPressureFrequencyMouseEntered);
        readoutPressureFrequencyTitleLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutPressureFrequencyTitleLabelArray[unitNumber] = readoutPressureFrequencyTitleLabel;
        //--------------------------------------------------------------------
        // Pressure Frequency display box
        //--------------------------------------------------------------------
        TextBox ^readoutPressureFrequencyBox = gcnew TextBox;
        readoutPressureFrequencyBox->Location = Point(
            readoutPressureFrequencyTitleLabel->Left,
            readoutPressureFrequencyTitleLabel->Bottom + 4);
        readoutPressureFrequencyBox->Size = readoutPressureBox->Size;
        readoutPressureFrequencyBox->Multiline = GUI_NO;
        readoutPressureFrequencyBox->AcceptsReturn = GUI_NO;
        readoutPressureFrequencyBox->AcceptsTab = GUI_NO;
        readoutPressureFrequencyBox->WordWrap = GUI_NO;
        readoutPressureFrequencyBox->ReadOnly = GUI_YES;
        readoutPressureFrequencyBox->TabStop = GUI_NO;
        readoutPressureFrequencyBox->TextAlign = HorizontalAlignment::Center;
        readoutPressureFrequencyBox->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutPressureFrequencyMouseEntered);
        readoutPressureFrequencyBox->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutPressureFrequencyBoxArray[unitNumber] = readoutPressureFrequencyBox;
        //--------------------------------------------------------------------
        // Pressure Frequency units label
        //--------------------------------------------------------------------
        Label ^readoutPressureFrequencyUnitsLabel = gcnew Label;
        readoutPressureFrequencyUnitsLabel->Text = _T("Hz");
        GUI_PositionBelow(readoutPressureFrequencyUnitsLabel, readoutPressureFrequencyBox, 2);
        readoutPressureFrequencyUnitsLabel->Size = Drawing::Size(
            readoutPressureFrequencyBox->Width,
            GUI_REGULAR_LABEL_HEIGHT);
        readoutPressureFrequencyUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        readoutPressureFrequencyUnitsLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutPressureFrequencyMouseEntered);
        readoutPressureFrequencyUnitsLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutPressureFrequencyUnitsLabelArray[unitNumber] = readoutPressureFrequencyUnitsLabel;
        //--------------------------------------------------------------------
        // Temperature Frequency title label
        //--------------------------------------------------------------------
        Label ^readoutTemperatureFrequencyTitleLabel = gcnew Label;
        readoutTemperatureFrequencyTitleLabel->Text = _T("Temp Frequency");
        readoutTemperatureFrequencyTitleLabel->Location = Point(
            readoutPressureFrequencyTitleLabel->Right + 15,
            readoutPressureFrequencyTitleLabel->Top);
        readoutTemperatureFrequencyTitleLabel->Size = readoutPressureFrequencyTitleLabel->Size;
        readoutTemperatureFrequencyTitleLabel->BackColor = Color::Transparent;
        readoutTemperatureFrequencyTitleLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        readoutTemperatureFrequencyTitleLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutTemperatureFrequencyMouseEntered);
        readoutTemperatureFrequencyTitleLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutTemperatureFrequencyTitleLabelArray[unitNumber] = readoutTemperatureFrequencyTitleLabel;
        //--------------------------------------------------------------------
        // Temperature Frequency display box
        //--------------------------------------------------------------------
        TextBox ^readoutTemperatureFrequencyBox = gcnew TextBox;
        readoutTemperatureFrequencyBox->Location = Point(
            readoutTemperatureFrequencyTitleLabel->Left,
            readoutPressureFrequencyBox->Top);
        readoutTemperatureFrequencyBox->Size = readoutPressureFrequencyBox->Size;
        readoutTemperatureFrequencyBox->Multiline = GUI_NO;
        readoutTemperatureFrequencyBox->AcceptsReturn = GUI_NO;
        readoutTemperatureFrequencyBox->AcceptsTab = GUI_NO;
        readoutTemperatureFrequencyBox->WordWrap = GUI_NO;
        readoutTemperatureFrequencyBox->ReadOnly = GUI_YES;
        readoutTemperatureFrequencyBox->TabStop = GUI_NO;
        readoutTemperatureFrequencyBox->TextAlign = HorizontalAlignment::Center;
        readoutTemperatureFrequencyBox->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutTemperatureFrequencyMouseEntered);
        readoutTemperatureFrequencyBox->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutTemperatureFrequencyBoxArray[unitNumber] = readoutTemperatureFrequencyBox;
        //--------------------------------------------------------------------
        // Temperature Frequency units label
        //--------------------------------------------------------------------
        Label ^readoutTemperatureFrequencyUnitsLabel = gcnew Label;
        readoutTemperatureFrequencyUnitsLabel->Text = readoutPressureFrequencyUnitsLabel->Text;
        GUI_PositionBelow(readoutTemperatureFrequencyUnitsLabel, readoutTemperatureFrequencyBox, 2);
        readoutTemperatureFrequencyUnitsLabel->Size = Drawing::Size(
            readoutTemperatureFrequencyBox->Width,
            GUI_REGULAR_LABEL_HEIGHT);
        readoutTemperatureFrequencyUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        readoutTemperatureFrequencyUnitsLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutTemperatureFrequencyMouseEntered);
        readoutTemperatureFrequencyUnitsLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutTemperatureFrequencyUnitsLabelArray[unitNumber] = readoutTemperatureFrequencyUnitsLabel;
        //--------------------------------------------------------------------
        // Voltage title label
        //--------------------------------------------------------------------
        Label ^readoutVoltageTitleLabel = gcnew Label;
        readoutVoltageTitleLabel->Text = _T("Voltage");
        readoutVoltageTitleLabel->Location = Point(
            readoutTemperatureFrequencyTitleLabel->Right + 15,
            readoutTemperatureFrequencyTitleLabel->Top);
        readoutVoltageTitleLabel->Size = Drawing::Size(50, GUI_REGULAR_LABEL_HEIGHT);
        readoutVoltageTitleLabel->BackColor = Color::Transparent;
        readoutVoltageTitleLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutTransducerVoltageAreaMouseEntered);
        readoutVoltageTitleLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutVoltageTitleLabelArray[unitNumber] = readoutVoltageTitleLabel;
        //--------------------------------------------------------------------
        // Voltage display box
        //--------------------------------------------------------------------
        TextBox ^readoutVoltageBox = gcnew TextBox;
        readoutVoltageBox->Location = Point(
            readoutVoltageTitleLabel->Left,
            readoutTemperatureFrequencyBox->Top);
        readoutVoltageBox->Size = Drawing::Size(40, GUI_REGULAR_TEXT_BOX_HEIGHT);
        readoutVoltageBox->BackColor = Color::Lavender;
        readoutVoltageBox->Multiline = GUI_NO;
        readoutVoltageBox->AcceptsReturn = GUI_NO;
        readoutVoltageBox->AcceptsTab = GUI_NO;
        readoutVoltageBox->WordWrap = GUI_NO;
        readoutVoltageBox->ReadOnly = GUI_YES;
        readoutVoltageBox->TabStop = GUI_NO;
        readoutVoltageBox->TextAlign = HorizontalAlignment::Center;
        readoutVoltageBox->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutTransducerVoltageAreaMouseEntered);
        readoutVoltageBox->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutVoltageBoxArray[unitNumber] = readoutVoltageBox;
        //--------------------------------------------------------------------
        // Voltage units label
        //--------------------------------------------------------------------
        Label ^readoutVoltageUnitsLabel = gcnew Label;
        readoutVoltageUnitsLabel->Text = _T("V");
        GUI_PositionBelow(readoutVoltageUnitsLabel, readoutVoltageBox, 2);
        readoutVoltageUnitsLabel->Size = Drawing::Size(
            readoutVoltageBox->Width,
            GUI_REGULAR_LABEL_HEIGHT);
        readoutVoltageUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        readoutVoltageUnitsLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutTransducerVoltageAreaMouseEntered);
        readoutVoltageUnitsLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutVoltageUnitsLabelArray[unitNumber] = readoutVoltageUnitsLabel;
        //--------------------------------------------------------------------
        // Amperage title label
        //--------------------------------------------------------------------
        Label ^readoutAmperageTitleLabel = gcnew Label;
        readoutAmperageTitleLabel->Text =_T("Current");
        readoutAmperageTitleLabel->Location = Point(
            readoutVoltageTitleLabel->Right + 15,
            readoutVoltageTitleLabel->Top);
        readoutAmperageTitleLabel->Size = readoutVoltageTitleLabel->Size;
        readoutAmperageTitleLabel->BackColor = Color::Transparent;
        readoutAmperageTitleLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutTransducerAmperageAreaMouseEntered);
        readoutAmperageTitleLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutAmperageTitleLabelArray[unitNumber] = readoutAmperageTitleLabel;
        //--------------------------------------------------------------------
        // Amperage display box
        //--------------------------------------------------------------------
        TextBox ^readoutAmperageBox = gcnew TextBox;
        readoutAmperageBox->Location = Point(
            readoutAmperageTitleLabel->Left,
            readoutVoltageBox->Top);
        readoutAmperageBox->Size = readoutVoltageBox->Size;
        readoutAmperageBox->BackColor = Color::Lavender;
        readoutAmperageBox->Multiline = GUI_NO;
        readoutAmperageBox->AcceptsReturn = GUI_NO;
        readoutAmperageBox->AcceptsTab = GUI_NO;
        readoutAmperageBox->WordWrap = GUI_NO;
        readoutAmperageBox->ReadOnly = GUI_YES;
        readoutAmperageBox->TabStop = GUI_NO;
        readoutAmperageBox->TextAlign = HorizontalAlignment::Center;
        readoutAmperageBox->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutTransducerAmperageAreaMouseEntered);
        readoutAmperageBox->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutAmperageBoxArray[unitNumber] = readoutAmperageBox;
        //--------------------------------------------------------------------
        // Amperage units label
        //--------------------------------------------------------------------
        Label ^readoutAmperageUnitsLabel = gcnew Label;
        readoutAmperageUnitsLabel->Text = QCOM_AmperageUnitsStringArray[QCOM_AMPERAGE_UNITS_DEFAULT];
        readoutAmperageUnitsLabel->Location = Point(
            readoutAmperageBox->Left,
            readoutAmperageBox->Bottom + 2);
        readoutAmperageUnitsLabel->Size = readoutVoltageUnitsLabel->Size;
        readoutAmperageUnitsLabel->BackColor = Color::Transparent;
        readoutAmperageUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        readoutAmperageUnitsLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutTransducerAmperageAreaMouseEntered);
        readoutAmperageUnitsLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutAmperageUnitsLabelArray[unitNumber] = readoutAmperageUnitsLabel;
        //--------------------------------------------------------------------
        // Firmware ID and version
        //--------------------------------------------------------------------
        Label ^readoutFirmwareInfoLabel = gcnew Label;
        readoutFirmwareInfoLabel->Tag = unitNumber;
        readoutFirmwareInfoLabel->Location = Point(
            readoutUnitGroupBox->Width - 290, 12);
        readoutFirmwareInfoLabel->Size = Drawing::Size(280, GUI_REGULAR_LABEL_HEIGHT);
        readoutFirmwareInfoLabel->BackColor = Color::Transparent;
        readoutFirmwareInfoLabel->TextAlign = Drawing::ContentAlignment::MiddleRight;
        readoutFirmwareInfoLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutFirmwareInfoLabelMouseEntered);
        readoutFirmwareInfoLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutFirmwareInfoLabelArray[unitNumber] = readoutFirmwareInfoLabel;
        //--------------------------------------------------------------------
        // Frequencies check box
        //--------------------------------------------------------------------
        CheckBox ^readoutDisplayFrequenciesCheck = gcnew CheckBox;
        readoutDisplayFrequenciesCheck->Text = _T("Display frequencies for this transducer");
        readoutDisplayFrequenciesCheck->Location = Point(
            readoutUnitGroupBox->Width - 230,
            readoutFirmwareInfoLabel->Bottom + 4);
        readoutDisplayFrequenciesCheck->Size = Drawing::Size(
            220, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            readoutDisplayFrequenciesCheck,
            unitNumber);
        readoutDisplayFrequenciesCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutDisplayUnitFrequenciesChecked);
        readoutDisplayFrequenciesCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutDisplayUnitFrequenciesCheckMouseEntered);
        readoutDisplayFrequenciesCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutDisplayFrequenciesCheckArray[unitNumber] = readoutDisplayFrequenciesCheck;
        //--------------------------------------------------------------------
        // V/I Values check box
        //--------------------------------------------------------------------
        CheckBox ^readoutDisplayVIValuesCheck = gcnew CheckBox;
        readoutDisplayVIValuesCheck->Text = _T("Display voltage and current values");
        GUI_PositionAndSizeBelow(readoutDisplayVIValuesCheck, readoutDisplayFrequenciesCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            readoutDisplayVIValuesCheck,
            unitNumber);
        readoutDisplayVIValuesCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutDisplayUnitVIValuesChecked);
        readoutDisplayVIValuesCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutDisplayUnitVIValuesCheckMouseEntered);
        readoutDisplayVIValuesCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutDisplayVIValuesCheckArray[unitNumber] = readoutDisplayVIValuesCheck;
        //--------------------------------------------------------------------
        // Include In Sampling check box
        //--------------------------------------------------------------------
        CheckBox ^readoutIncludeInSamplingCheck = gcnew CheckBox;
        readoutIncludeInSamplingCheck->Text = _T("Include this unit in sampling / logging");
        GUI_PositionAndSizeBelow(readoutIncludeInSamplingCheck, readoutDisplayVIValuesCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            readoutIncludeInSamplingCheck,
            unitNumber);
        readoutIncludeInSamplingCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutIncludeUnitInSamplingChecked);
        readoutIncludeInSamplingCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutIncludeUnitInSamplingCheckMouseEntered);
        readoutIncludeInSamplingCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        readoutIncludeInSamplingCheckArray[unitNumber] = readoutIncludeInSamplingCheck;
        //--------------------------------------------------------------------
        // Attach the components to the Unit Readout group box
        //--------------------------------------------------------------------
        array <Button ^> ^readoutButtons =
        {
            readoutStartStopLoggingButton,
            readoutClearLogButton,
            readoutUnitStartStopSamplingButton,
            readoutDisplayDataGraphButton
        };
        readoutUnitGroupBox->Controls->AddRange(readoutButtons);
        array <TextBox ^> ^readoutBoxes =
        {
            readoutPressureBox,
            readoutTemperatureBox,
            readoutPressureFrequencyBox,
            readoutTemperatureFrequencyBox,
            readoutVoltageBox,
            readoutAmperageBox
        };
        readoutUnitGroupBox->Controls->AddRange(readoutBoxes);
        array <Label ^> ^readoutLabels =
        {
            readoutPressureUnitsLabel,
            readoutTemperatureUnitsLabel,
            readoutPressureFrequencyUnitsLabel,
            readoutTemperatureFrequencyUnitsLabel,
            readoutPressureTitleLabel,
            readoutTemperatureTitleLabel,
            readoutPressureFrequencyTitleLabel,
            readoutTemperatureFrequencyTitleLabel,
            readoutFirmwareInfoLabel,
            readoutVoltageTitleLabel,
            readoutVoltageUnitsLabel,
            readoutAmperageTitleLabel,
            readoutAmperageUnitsLabel
        };
        readoutUnitGroupBox->Controls->AddRange(readoutLabels);
        array <CheckBox ^> ^readoutChecks =
        {
            readoutDisplayFrequenciesCheck,
            readoutDisplayVIValuesCheck,
            readoutIncludeInSamplingCheck
        };
        readoutUnitGroupBox->Controls->AddRange(readoutChecks);
        readoutGroupBoxArray[unitNumber] = readoutUnitGroupBox;
    }                                   // end of if (unit)
    //------------------------------------------------------------------------
    // Epilogue
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ConstructUnitReadoutGroupBox()
//----------------------------------------------------------------------------
// QCOM_ConstructUnitTestingGroupBox
//
// Displays a Testing group box for one QCOM transducer in the primary tab
//
// Called by:   QCOM_ConstructHomeTabPages
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConstructUnitTestingGroupBox(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_ConstructUnitTestingGroupBox");
    //------------------------------------------------------------------------
    if (unit)
    {
        unitNumber = unit->unitNumber;
        RecordVerboseEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Create the tab page
        //--------------------------------------------------------------------
        TabPage ^testingUnitTabPage = gcnew TabPage;
        testingUnitTabPage->TabIndex = unitNumber;
        testingUnitTabPage->BackgroundImage = whiteMarbleBackground;
        testingUnitTabPageArray[unitNumber] = testingUnitTabPage;
//        testingTabControl->Controls->Add(testingUnitTabPage);
        //--------------------------------------------------------------------
        // Create the group box
        //--------------------------------------------------------------------
        GroupBox ^testingUnitGroupBox = gcnew GroupBox;
        testingUnitGroupBox->Location = Point(10, 6);
        testingUnitGroupBox->Size = Drawing::Size(
            GUI_DEFAULT_GROUP_BOX_WIDTH,
            GUI_UNIT_GROUP_BOX_HEIGHT);
        testingUnitGroupBox->ForeColor = Color::Black;
        testingUnitGroupBox->BackColor = Color::Transparent;
        testingUnitTabPage->Controls->Add(testingUnitGroupBox);
        //--------------------------------------------------------------------
        // Start / stop button
        //--------------------------------------------------------------------
        Button ^testStartStopButton = gcnew Button;
        testStartStopButton->Location = Point(10, 20);
        testStartStopButton->Size = Drawing::Size(
            GUI_DEFAULT_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            testStartStopButton,
            unitNumber);
        testStartStopButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitStartStopButtonClicked);
        testStartStopButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitStartStopButtonMouseEntered);
        testStartStopButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingStartStopButtonArray[unitNumber] = testStartStopButton;
        //--------------------------------------------------------------------
        // Save Test Results button
        //--------------------------------------------------------------------
        Button ^testSaveResultsButton = gcnew Button;
        testSaveResultsButton->Text = _T("Save Test Results");
        testSaveResultsButton->Location = Point(
            testStartStopButton->Left,
            testStartStopButton->Bottom + 86);
        testSaveResultsButton->Size = testStartStopButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            testSaveResultsButton,
            unitNumber);
        testSaveResultsButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitSaveResultsButtonClicked);
        testSaveResultsButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitSaveResultsButtonMouseEntered);
        testSaveResultsButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingSaveResultsButtonArray[unitNumber] = testSaveResultsButton;
        //--------------------------------------------------------------------
        // Clear Test Results button
        //--------------------------------------------------------------------
        Button ^testClearResultsButton = gcnew Button;
        testClearResultsButton->Text = _T("Clear Test Results");
        testClearResultsButton->Location = Point(
            testSaveResultsButton->Right + 15,
            testSaveResultsButton->Top);
        testClearResultsButton->Size = testStartStopButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            testClearResultsButton,
            unitNumber);
        testClearResultsButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitClearResultsButtonClicked);
        testClearResultsButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitClearResultsButtonMouseEntered);
        testClearResultsButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingClearResultsButtonArray[unitNumber] = testClearResultsButton;
        //--------------------------------------------------------------------
        // Select Test Results File button
        //--------------------------------------------------------------------
        Button ^testSelectResultsFileButton = gcnew Button;
        testSelectResultsFileButton->Location = Point(
            testStartStopButton->Right + 15,
            testStartStopButton->Top);
        testSelectResultsFileButton->Size = testStartStopButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            testSelectResultsFileButton,
            unitNumber);
        testSelectResultsFileButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitSelectResultsFileButtonClicked);
        testSelectResultsFileButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitSelectResultsFileButtonMouseEntered);
        testSelectResultsFileButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingSelectResultsFileButtonArray[unitNumber] = testSelectResultsFileButton;
        //--------------------------------------------------------------------
        // Test Results File label
        //--------------------------------------------------------------------
        Label ^testResultsFileLabel = gcnew Label;
        testResultsFileLabel->Tag = unitNumber;
        testResultsFileLabel->Location = Point(
            testSelectResultsFileButton->Right + 5,
            testSelectResultsFileButton->Top);
        testResultsFileLabel->Size = Drawing::Size(460, GUI_INFO_LABEL_HEIGHT);
        testResultsFileLabel->BackColor = Color::Transparent;
        testResultsFileLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitResultsFileLabelMouseEntered);
        testResultsFileLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingResultsFileLabelArray[unitNumber] = testResultsFileLabel;
        //--------------------------------------------------------------------
        // Test Loop Count
        //--------------------------------------------------------------------
        Label ^testPassCountLabel = gcnew Label;
        testPassCountLabel->Tag = (0x100 | unitNumber);
        if (unit->testFlags & QCOM_UNIT_TEST_LOOP_FOREVER)
        {
            testPassCountLabel->Text = _T("Loop 1");
        }
        else
        {
            testPassCountLabel->Text = String::Format(
                "Loop 1 / {0:D}", QCOM_TestLoopCount);
        }
        testPassCountLabel->Location = Point(
            testResultsFileLabel->Right + 5,
            testResultsFileLabel->Top);
        testPassCountLabel->Size = Drawing::Size(
            100, testResultsFileLabel->Height);
        testPassCountLabel->ForeColor = Color::Purple;
        testPassCountLabel->BackColor = Color::Transparent;
        testPassCountLabel->TextAlign = Drawing::ContentAlignment::MiddleRight;
        testPassCountLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitPassCountLabelMouseEntered);
        testPassCountLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingPassCountLabelArray[unitNumber] = testPassCountLabel;
        //--------------------------------------------------------------------
        // Test State box
        //--------------------------------------------------------------------
        GroupBox ^testingStateGroupBox = gcnew GroupBox;
        testingStateGroupBox->Text = _T("QCOM Test State");
        testingStateGroupBox->Location = Point(
            testStartStopButton->Left,
            testStartStopButton->Bottom + 4);
        testingStateGroupBox->Size = Drawing::Size(
            134, testSaveResultsButton->Top - testStartStopButton->Bottom - 8);
        testingStateGroupBox->BackColor = Color::Transparent;
        testingStateGroupBox->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitStateAreaMouseEntered);
        testingStateGroupBox->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        Label ^testingResultLabel = gcnew Label;
        testingResultLabel->Tag = unitNumber;
        testingResultLabel->Text = GUI_TEST_UNTESTED_STRING;
        testingResultLabel->Size = Drawing::Size(
            testingStateGroupBox->Width - 4, 30);
        testingResultLabel->Location = Point(
            2, (testingStateGroupBox->Height / 2) - (testingResultLabel->Height / 2) + 2);
        testingResultLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            16.0F,
            FontStyle::Bold);
        testingResultLabel->ForeColor = Color::Green;
        testingResultLabel->BackColor = Color::Transparent;
        testingResultLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        testingResultLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitStateAreaMouseEntered);
        testingResultLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingStateLabelArray[unitNumber] = testingResultLabel;
        //--------------------------------------------------------------------
        // Running time label
        //--------------------------------------------------------------------
        Label ^testingRunningTimeLabel = gcnew Label;
        testingRunningTimeLabel->Tag = unitNumber;
        testingRunningTimeLabel->Location = Point(
            2, testingStateGroupBox->Height - 20);
        testingRunningTimeLabel->Size = Drawing::Size(
            testingStateGroupBox->Width - 4,
            GUI_INFO_LABEL_HEIGHT);
        testingRunningTimeLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            7.0F,
            FontStyle::Regular);
        testingRunningTimeLabel->BackColor = Color::Transparent;
        testingRunningTimeLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        testingRunningTimeLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitRunningTimeLabelMouseEntered);
        testingRunningTimeLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingRunningTimeLabelArray[unitNumber] = testingRunningTimeLabel;
        testingStateGroupBox->Controls->Add(testingRunningTimeLabel);
        testingStateGroupBox->Controls->Add(testingResultLabel);
        //--------------------------------------------------------------------
        // All QCOM Tests check box
        //--------------------------------------------------------------------
        CheckBox ^testingAllModuleCheck = gcnew CheckBox;
        testingAllModuleCheck->Text = _T("All QCOM Tests");
        testingAllModuleCheck->Location = Point(
            testSelectResultsFileButton->Left,
            testSelectResultsFileButton->Bottom + 8);
        testingAllModuleCheck->Size = Drawing::Size(
            115, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            testingAllModuleCheck,
            unitNumber);
        testingAllModuleCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitAllModuleChecked);
        testingAllModuleCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitAllModuleCheckMouseEntered);
        testingAllModuleCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingAllModuleCheckArray[unitNumber] = testingAllModuleCheck;
        //--------------------------------------------------------------------
        // Module Memory Test check box
        //--------------------------------------------------------------------
        CheckBox ^testingQMEMCheck = gcnew CheckBox;
        testingQMEMCheck->Text = _T("Memory Test");
        testingQMEMCheck->Location = Point(
            testingAllModuleCheck->Left,
            testingAllModuleCheck->Bottom + 4);
        testingQMEMCheck->Size = testingAllModuleCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            testingQMEMCheck,
            unitNumber);
        testingQMEMCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitQMEMChecked);
        testingQMEMCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitQMEMCheckMouseEntered);
        testingQMEMCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingQMEMCheckArray[unitNumber] = testingQMEMCheck;
        //--------------------------------------------------------------------
        // I�C Test check box
        //--------------------------------------------------------------------
        CheckBox ^testingI2CCheck = gcnew CheckBox;
        testingI2CCheck->Text = _T("I�C Test");
        testingI2CCheck->Location = Point(
            testingAllModuleCheck->Left,
            testingQMEMCheck->Bottom + 4);
        testingI2CCheck->Size = testingAllModuleCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            testingI2CCheck,
            unitNumber);
        testingI2CCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitI2CChecked);
        testingI2CCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitI2CCheckMouseEntered);
        testingI2CCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingI2CCheckArray[unitNumber] = testingI2CCheck;
        //--------------------------------------------------------------------
        // Readings Test check box
        //--------------------------------------------------------------------
        CheckBox ^testingReadingsCheck = gcnew CheckBox;
        testingReadingsCheck->Text = _T("Readings Test");
        testingReadingsCheck->Location = Point(
            testingAllModuleCheck->Left,
            testingI2CCheck->Bottom + 4);
        testingReadingsCheck->Size = testingAllModuleCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            testingReadingsCheck,
            unitNumber);
        testingReadingsCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitReadingsChecked);
        testingReadingsCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitReadingsCheckMouseEntered);
        testingReadingsCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingReadingsCheckArray[unitNumber] = testingReadingsCheck;
        //--------------------------------------------------------------------
        // Firmware Test check box
        //--------------------------------------------------------------------
        CheckBox ^testingFirmwareCheck = gcnew CheckBox;
        testingFirmwareCheck->Text = _T("Firmware Test");
        testingFirmwareCheck->Location = Point(
            testingAllModuleCheck->Right + 5,
            testingAllModuleCheck->Top);
        testingFirmwareCheck->Size = Drawing::Size(
            115, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            testingFirmwareCheck,
            unitNumber);
        testingFirmwareCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitFirmwareChecked);
        testingFirmwareCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitFirmwareCheckMouseEntered);
        testingFirmwareCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingFirmwareCheckArray[unitNumber] = testingFirmwareCheck;
        //--------------------------------------------------------------------
        // X2 Test check box
        //--------------------------------------------------------------------
        CheckBox ^testingX2Check = gcnew CheckBox;
        testingX2Check->Text = _T("X2 Test");
        testingX2Check->Location = Point(
            testingFirmwareCheck->Left,
            testingFirmwareCheck->Bottom + 4);
        testingX2Check->Size = testingFirmwareCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            testingX2Check,
            unitNumber);
        testingX2Check->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitX2Checked);
        testingX2Check->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitX2CheckMouseEntered);
        testingX2Check->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingX2CheckArray[unitNumber] = testingX2Check;
        //--------------------------------------------------------------------
        // X3 Test check box
        //--------------------------------------------------------------------
        CheckBox ^testingX3Check = gcnew CheckBox;
        testingX3Check->Text = _T("X3 Test");
        testingX3Check->Location = Point(
            testingFirmwareCheck->Left,
            testingX2Check->Bottom + 4);
        testingX3Check->Size = testingFirmwareCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            testingX3Check,
            unitNumber);
        testingX3Check->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitX3Checked);
        testingX3Check->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitX3CheckMouseEntered);
        testingX3Check->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingX3CheckArray[unitNumber] = testingX3Check;
        //--------------------------------------------------------------------
        // X4 Test check box
        //--------------------------------------------------------------------
        CheckBox ^testingX4Check = gcnew CheckBox;
        testingX4Check->Text = _T("X4 Test");
        testingX4Check->Location = Point(
            testingFirmwareCheck->Left,
            testingX3Check->Bottom + 4);
        testingX4Check->Size = testingFirmwareCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            testingX4Check,
            unitNumber);
        testingX4Check->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitX4Checked);
        testingX4Check->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitX4CheckMouseEntered);
        testingX4Check->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingX4CheckArray[unitNumber] = testingX4Check;
        //--------------------------------------------------------------------
        // All Transducer Tests check box
        //--------------------------------------------------------------------
        CheckBox ^testingAllTransducerCheck = gcnew CheckBox;
        testingAllTransducerCheck->Text = _T("All Transducer Tests");
        testingAllTransducerCheck->Location = Point(
            testingFirmwareCheck->Right + 5,
            testingAllModuleCheck->Top);
        testingAllTransducerCheck->Size = Drawing::Size(
            130, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            testingAllTransducerCheck,
            unitNumber);
        testingAllTransducerCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitAllTransducerChecked);
        testingAllTransducerCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitAllTransducerCheckMouseEntered);
        testingAllTransducerCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingAllTransducerCheckArray[unitNumber] = testingAllTransducerCheck;
        //--------------------------------------------------------------------
        // Transducer Communications Test check box
        //--------------------------------------------------------------------
        CheckBox ^testingXDCommCheck = gcnew CheckBox;
        testingXDCommCheck->Text = _T("Communication Test");
        testingXDCommCheck->Location = Point(
            testingAllTransducerCheck->Left,
            testingAllTransducerCheck->Bottom + 4);
        testingXDCommCheck->Size = testingAllTransducerCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            testingXDCommCheck,
            unitNumber);
        testingXDCommCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitXDCommChecked);
        testingXDCommCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitXDCommCheckMouseEntered);
        testingXDCommCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingXDCommCheckArray[unitNumber] = testingXDCommCheck;
        //--------------------------------------------------------------------
        // Transducer Integrity Test check box
        //--------------------------------------------------------------------
        CheckBox ^testingXDIntegrityCheck = gcnew CheckBox;
        testingXDIntegrityCheck->Location = Point(
            testingAllTransducerCheck->Left,
            testingXDCommCheck->Bottom + 4);
        testingXDIntegrityCheck->Size = testingAllTransducerCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            testingXDIntegrityCheck,
            unitNumber);
        testingXDIntegrityCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitXDIntegrityChecked);
        testingXDIntegrityCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitXDIntegrityCheckMouseEntered);
        testingXDIntegrityCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingXDIntegrityCheckArray[unitNumber] = testingXDIntegrityCheck;
        //--------------------------------------------------------------------
        // Transducer Memory Test check box
        //--------------------------------------------------------------------
        CheckBox ^testingXDMemoryCheck = gcnew CheckBox;
        testingXDMemoryCheck->Text =
            (unit->transducerChipID[1] == QD_TRANSDUCER_CHIP_ASIC) ?
                _T("ASIC Memory Test") : _T("FPGA Memory Test");
        testingXDMemoryCheck->Location = Point(
            testingAllTransducerCheck->Left,
            testingXDIntegrityCheck->Bottom + 4);
        testingXDMemoryCheck->Size = testingAllTransducerCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            testingXDMemoryCheck,
            unitNumber);
        testingXDMemoryCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitXDMemoryChecked);
        testingXDMemoryCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitXDMemoryCheckMouseEntered);
        testingXDMemoryCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingXDMemoryCheckArray[unitNumber] = testingXDMemoryCheck;
        //--------------------------------------------------------------------
        // Detailed Test Results check box
        //--------------------------------------------------------------------
        CheckBox ^testingDetailedCheck = gcnew CheckBox;
        testingDetailedCheck->Text = _T("Detailed test results");
        testingDetailedCheck->Location = Point(
            testClearResultsButton->Right + 10,
            testClearResultsButton->Top + 10);
        testingDetailedCheck->Size = Drawing::Size(
            124, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            testingDetailedCheck,
            unitNumber);
        testingDetailedCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitDetailedResultsChecked);
        testingDetailedCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitDetailedResultsCheckMouseEntered);
        testingDetailedCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingDetailedCheckArray[unitNumber] = testingDetailedCheck;
        //--------------------------------------------------------------------
        // Time Stamp Lines check box
        //--------------------------------------------------------------------
        CheckBox ^testingTimeStampCheck = gcnew CheckBox;
        testingTimeStampCheck->Text = _T("Time stamp lines");
        testingTimeStampCheck->Location = Point(
            testingDetailedCheck->Right + 10,
            testingDetailedCheck->Top);
        testingTimeStampCheck->Size = Drawing::Size(110, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            testingTimeStampCheck,
            unitNumber);
        testingTimeStampCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitTimeStampResultsChecked);
        testingTimeStampCheck->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitTimeStampResultsCheckMouseEntered);
        testingTimeStampCheck->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingTimeStampCheckArray[unitNumber] = testingTimeStampCheck;
//            QCOM_TestUnitUpdateChecks(unit);
        //--------------------------------------------------------------------
        // Summary Test results display box
        //--------------------------------------------------------------------
        int boxWidth = 310;
        int boxHeight = 100;
        int boxLeft = 530;
        int boxBottom = testResultsFileLabel->Bottom + 2 + boxHeight;
        RichTextBox ^testingSummaryResultsBox = gcnew RichTextBox;
        testingSummaryResultsBox->Tag = unitNumber;
        testingSummaryResultsBox->Location = Point(
            boxLeft, testResultsFileLabel->Bottom + 2);
        testingSummaryResultsBox->Size = Drawing::Size(boxWidth, boxHeight);
        testingSummaryResultsBox->Multiline = GUI_YES;
        testingSummaryResultsBox->ReadOnly = GUI_YES;
        testingSummaryResultsBox->ScrollBars = RichTextBoxScrollBars::Both;
        testingSummaryResultsBox->AcceptsTab = GUI_YES;
        testingSummaryResultsBox->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitResultsBoxMouseEntered);
        testingSummaryResultsBox->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingSummaryResultsBoxArray[unitNumber] = testingSummaryResultsBox;
        //--------------------------------------------------------------------
        // Detailed Test results display box
        //--------------------------------------------------------------------
        RichTextBox ^testingDetailedResultsBox = gcnew RichTextBox;
        testingDetailedResultsBox->Tag = unitNumber;
        testingDetailedResultsBox->Location = Point(
            boxLeft, testResultsFileLabel->Bottom + 2);
        testingDetailedResultsBox->Size = Drawing::Size(boxWidth, boxHeight);
        testingDetailedResultsBox->Multiline = GUI_YES;
        testingDetailedResultsBox->ReadOnly = GUI_YES;
        testingDetailedResultsBox->ScrollBars = RichTextBoxScrollBars::Both;
        testingDetailedResultsBox->AcceptsTab = GUI_YES;
        testingDetailedResultsBox->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitResultsBoxMouseEntered);
        testingDetailedResultsBox->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingDetailedResultsBoxArray[unitNumber] = testingDetailedResultsBox;
        //--------------------------------------------------------------------
        // Testing progress bar and label
        //--------------------------------------------------------------------
        Label ^testingProgressLabel = gcnew Label;
        testingProgressLabel->Text = _T("0% Complete");
        testingProgressLabel->Location = Point(
            boxLeft,
            boxBottom + 4);
        testingProgressLabel->Size = Drawing::Size(84, GUI_REGULAR_LABEL_HEIGHT);
        testingProgressLabel->BackColor = Color::Transparent;
        testingProgressLabel->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitProgressBarAreaMouseEntered);
        testingProgressLabel->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingPercentCompleteLabelArray[unitNumber] = testingProgressLabel;
        ProgressBar ^testingProgressBar = gcnew ProgressBar;
        testingProgressBar->Location = Point(
            testingProgressLabel->Right, testingProgressLabel->Top);
        testingProgressBar->Size = Drawing::Size(
            boxWidth - testingProgressLabel->Width,
            testingProgressLabel->Height);
        testingProgressBar->Minimum = 0;
        testingProgressBar->Maximum = 100;
        testingProgressBar->Value = 0;
        testingProgressBar->Style = ProgressBarStyle::Continuous;
        testingProgressBar->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_TestUnitProgressBarAreaMouseEntered);
        testingProgressBar->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        testingPercentCompleteProgressArray[unitNumber] = testingProgressBar;
        //--------------------------------------------------------------------
        // Attach the components to the Unit Test group box
        //--------------------------------------------------------------------
        array <Button ^> ^testingButtons =
        {
            testStartStopButton,
            testSaveResultsButton,
            testClearResultsButton,
            testSelectResultsFileButton
        };
        testingUnitGroupBox->Controls->AddRange(testingButtons);
        array <Label ^> ^testingLabels =
        {
            testResultsFileLabel,
            testPassCountLabel,
            testingProgressLabel
        };
        testingUnitGroupBox->Controls->AddRange(testingLabels);
        array <CheckBox ^> ^testingChecks =
        {
            testingAllModuleCheck,
            testingQMEMCheck,
            testingI2CCheck,
            testingReadingsCheck,
            testingFirmwareCheck,
            testingX2Check,
            testingX3Check,
            testingX4Check,
            testingAllTransducerCheck,
            testingXDCommCheck,
            testingXDIntegrityCheck,
            testingXDMemoryCheck,
            testingDetailedCheck,
            testingTimeStampCheck
        };
        testingUnitGroupBox->Controls->AddRange(testingChecks);
        testingUnitGroupBox->Controls->Add(testingSummaryResultsBox);
        testingUnitGroupBox->Controls->Add(testingDetailedResultsBox);
        testingUnitGroupBox->Controls->Add(testingStateGroupBox);
        testingUnitGroupBox->Controls->Add(testingProgressBar);
        //--------------------------------------------------------------------
        // Perform remaining setup tasks
        //--------------------------------------------------------------------
        if (QCOM_UnitValid(unit))
        {
//            QCOM_TestDetermineResultsFilePath(unit);
//            QCOM_TestDetermineDataFilePath(unit);
//            QCOM_TestDetermineFirmwareFilePath(unit);
        }
        testingGroupBoxArray[unitNumber] = testingUnitGroupBox;
    }                                   // end of if (unit)
    //------------------------------------------------------------------------
    // Epilogue
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ConstructUnitTestingGroupBox()
//----------------------------------------------------------------------------
// QCOM_ConstructUnitUtilitiesGroupBox
//
// Displays a Utilities group box for one QCOM transducer in the primary tab
//
// Called by:   QCOM_ConstructHomeTabPages
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConstructUnitUtilitiesGroupBox(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_ConstructUnitUtilitiesGroupBox");
    //------------------------------------------------------------------------
    if (unit)
    {
        unitNumber = unit->unitNumber;
        RecordVerboseEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Create the tab page
        //--------------------------------------------------------------------
        TabPage ^utilitiesUnitTabPage = gcnew TabPage;
        utilitiesUnitTabPage->TabIndex = unitNumber;
        utilitiesUnitTabPage->BackgroundImage = whiteMarbleBackground;
        utilitiesUnitTabPageArray[unitNumber] = utilitiesUnitTabPage;
//        utilitiesTabControl->Controls->Add(utilitiesUnitTabPage);
        //--------------------------------------------------------------------
        // Create the group box
        //--------------------------------------------------------------------
        GroupBox ^utilitiesUnitGroupBox = gcnew GroupBox;
        utilitiesUnitGroupBox->Location = Point(10, 6);
        utilitiesUnitGroupBox->Size = Drawing::Size(
            GUI_DEFAULT_GROUP_BOX_WIDTH,
            GUI_UNIT_GROUP_BOX_HEIGHT);
        utilitiesUnitGroupBox->ForeColor = Color::Black;
        utilitiesUnitGroupBox->BackColor = Color::Transparent;
        utilitiesUnitTabPage->Controls->Add(utilitiesUnitGroupBox);
        //--------------------------------------------------------------------
        // Display Data Log button
        //--------------------------------------------------------------------
        Button ^utilLogUnitDisplayButton = gcnew Button;
        utilLogUnitDisplayButton->Text = _T("Display Unit Data\nLogging Controls");
        utilLogUnitDisplayButton->Location = Point(15, 20);
        utilLogUnitDisplayButton->Size =  utilLogAllDisplayButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            utilLogUnitDisplayButton,
            unitNumber);
        utilLogUnitDisplayButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitDisplayButtonClicked);
        utilLogUnitDisplayButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilLogUnitDisplayButtonMouseEntered);
        utilLogUnitDisplayButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        utilitiesUnitGroupBox->Controls->Add(utilLogUnitDisplayButton);
        utilLogUnitDisplayButtonArray[unitNumber] = utilLogUnitDisplayButton;
        //--------------------------------------------------------------------
        // Import Coefficient Data File button
        //--------------------------------------------------------------------
        Button ^utilImportCoefficientDataFileButton = gcnew Button;
        utilImportCoefficientDataFileButton->Text =
            _T("Import Coefficient Data File");
        utilImportCoefficientDataFileButton->Location = Point(
            utilLogUnitDisplayButton->Right + 13,
            utilLogUnitDisplayButton->Top);
        utilImportCoefficientDataFileButton->Size = utilDownloadCoefficientFilesButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            utilImportCoefficientDataFileButton,
            unitNumber);
        utilImportCoefficientDataFileButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilImportCoefficientDataFileButtonClicked);
        utilImportCoefficientDataFileButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilImportCoefficientDataFileButtonMouseEntered);
        utilImportCoefficientDataFileButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        utilitiesUnitGroupBox->Controls->Add(utilImportCoefficientDataFileButton);
        utilImportCoefficientDataFileButtonArray[unitNumber] =
            utilImportCoefficientDataFileButton;
        //--------------------------------------------------------------------
        // Export Coefficient Data File button
        //--------------------------------------------------------------------
        Button ^utilExportCoefficientDataFileButton = gcnew Button;
        utilExportCoefficientDataFileButton->Text = _T("Export Coefficient Data File");
        utilExportCoefficientDataFileButton->Location = Point(
            utilImportCoefficientDataFileButton->Left,
            utilImportCoefficientDataFileButton->Bottom + 10);
        utilExportCoefficientDataFileButton->Size =
            utilImportCoefficientDataFileButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            utilExportCoefficientDataFileButton,
            unitNumber);
        utilExportCoefficientDataFileButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ExportCoefficientDataFileButtonClicked);
        utilExportCoefficientDataFileButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilExportCoefficientDataFileButtonMouseEntered);
        utilExportCoefficientDataFileButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        utilitiesUnitGroupBox->Controls->Add(utilExportCoefficientDataFileButton);
        utilExportCoefficientDataFileButtonArray[unitNumber] =
            utilExportCoefficientDataFileButton;
        //--------------------------------------------------------------------
        // Coefficient Check button
        //--------------------------------------------------------------------
        Button ^utilDisplayTCCheckButton = gcnew Button;
        utilDisplayTCCheckButton->Text = _T("Coefficient Check");
        utilDisplayTCCheckButton->Location = Point(
            utilExportCoefficientDataFileButton->Left,
            utilExportCoefficientDataFileButton->Bottom + 10);
        utilDisplayTCCheckButton->Size =
            utilImportCoefficientDataFileButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            utilDisplayTCCheckButton,
            unitNumber);
        utilDisplayTCCheckButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilDisplayTCCheckButtonClicked);
        utilDisplayTCCheckButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilDisplayTCCheckButtonMouseEntered);
        utilDisplayTCCheckButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        utilitiesUnitGroupBox->Controls->Add(utilDisplayTCCheckButton);
        utilDisplayTCCheckButtonArray[unitNumber] = utilDisplayTCCheckButton;
        //--------------------------------------------------------------------
        // Reset Module button
        //--------------------------------------------------------------------
        Button ^utilResetModuleButton = gcnew Button;
        utilResetModuleButton->Text = _T("Reset Module");
        utilResetModuleButton->Location = Point(
            utilImportCoefficientDataFileButton->Right + 13,
            utilImportCoefficientDataFileButton->Top);
        utilResetModuleButton->Size = utilResetAllUnitsButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            utilResetModuleButton,
            unitNumber);
        utilResetModuleButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilResetModuleButtonClicked);
        utilResetModuleButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilResetModuleButtonMouseEntered);
        utilResetModuleButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        utilitiesUnitGroupBox->Controls->Add(utilResetModuleButton);
        utilResetModuleButtonArray[unitNumber] = utilResetModuleButton;
        //--------------------------------------------------------------------
        // Reset Transducer button
        //--------------------------------------------------------------------
        Button ^utilUnitResetTransducerButton = gcnew Button;
        utilUnitResetTransducerButton->Text = _T("Reset Transducer");
        utilUnitResetTransducerButton->Location = Point(
            utilResetModuleButton->Left,
            utilResetModuleButton->Bottom + 10);
        utilUnitResetTransducerButton->Size = utilResetModuleButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            utilUnitResetTransducerButton,
            unitNumber);
        utilUnitResetTransducerButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilUnitResetTransducerButtonClicked);
        utilUnitResetTransducerButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilUnitResetTransducerButtonMouseEntered);
        utilUnitResetTransducerButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        utilitiesUnitGroupBox->Controls->Add(utilUnitResetTransducerButton);
        utilResetTransducerButtonArray[unitNumber] = utilUnitResetTransducerButton;
        //--------------------------------------------------------------------
        // Update Firmware Unit button
        //--------------------------------------------------------------------
        Button ^utilUnitUpdateFirmwareButton = gcnew Button;
        utilUnitUpdateFirmwareButton->Text = _T("Update Firmware");
        utilUnitUpdateFirmwareButton->Location = Point(
            utilResetModuleButton->Right + 13,
            utilResetModuleButton->Top);
        utilUnitUpdateFirmwareButton->Size = utilVerifyHexFileButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            utilUnitUpdateFirmwareButton,
            unitNumber);
        utilUnitUpdateFirmwareButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilUnitUpdateFirmwareButtonClicked);
        utilUnitUpdateFirmwareButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilUnitUpdateFirmwareButtonMouseEntered);
        utilUnitUpdateFirmwareButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        utilUpdateFirmwareButtonArray[unitNumber] = utilUnitUpdateFirmwareButton;
        utilitiesUnitGroupBox->Controls->Add(utilUnitUpdateFirmwareButton);
        utilitiesGroupBoxArray[unitNumber] = utilitiesUnitGroupBox;
    }                                   // end of if (unit)
    //------------------------------------------------------------------------
    // Epilogue
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ConstructUnitUtilitiesGroupBox()
//----------------------------------------------------------------------------
#endif      // HOMETABS_CPP
//============================================================================
// End of HomeTabs.cpp
//============================================================================
