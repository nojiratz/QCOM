//============================================================================
// LogEvents.cpp
//
// The event methods used by Logging.cpp for data log-related tasks
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     LOGEVENTS_CPP
#define     LOGEVENTS_CPP
#include    "LogEvents.h"
//----------------------------------------------------------------------------
// QCOM_ClearAllDataLogsButtonClicked
//
// Handles the click of the Clear All Logs button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//              QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ClearAllDataLogsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Clear All Data Logs button clicked");
    QCOM_ClearAllDataLogs();
}                                       // end of QCOM_ClearAllDataLogsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ClearDataLogDisplay
//
// Clears the data log display of the specified transducer
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//              QCOM_SetUpAllDataLoggingWindows
//              QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
/*
    void QCOM_GUIClass::
QCOM_ClearDataLogDisplay(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    //------------------------------------------------------------------------
    QCOM_LogUnitUpdateDataLog(QCOM_UnitInfoArray[unitNumber], GUI_LOG_ACTION_CLEAR_DISPLAY);
}                                       // end of QCOM_ClearDataLogDisplay()
*/
//----------------------------------------------------------------------------
// QCOM_DisplayCaptionInLogChecked
//
// Handles the check of the Display Caption In Log box
//
// Called by:   QCOM_ConstructUnitLogTabInAllWindow
//              QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayCaptionInLogChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DisplayCaptionInLogChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_LOG_ZERO_FLAG,
            QCOM_UNIT_LOG_DISPLAY_CAPTION_IN_LOG);
        RecordBasicEvent(
            "    Display Caption in Log {0} for module {1}",
            ((unit->dataLogFlags & QCOM_UNIT_LOG_DISPLAY_CAPTION_IN_LOG) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DisplayCaptionInLogChecked()
//----------------------------------------------------------------------------
// QCOM_DLAllChecked
//
// Handles the check of the All log points checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DLAllChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DLAllChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if ((unit->dataLogPoints & QCOM_UNIT_LOG_ALL_POINTS) == QCOM_UNIT_LOG_ALL_POINTS)
        {
            unit->dataLogPoints &= ~QCOM_UNIT_LOG_ALL_POINTS;
            unit->dataLogPoints |= QCOM_UNIT_LOG_DEFAULT_DATA_POINTS;
        }
        else
        {
            unit->dataLogPoints |= QCOM_UNIT_LOG_ALL_POINTS;
        }
        RecordBasicEvent(
            "    Log All Data Points {0} for module {1}",
            (((unit->dataLogPoints & QCOM_UNIT_LOG_ALL_POINTS) == QCOM_UNIT_LOG_ALL_POINTS) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DLAllChecked()
//----------------------------------------------------------------------------
// QCOM_DLCountsInHexChecked
//
// Handles the check of the Counts In Hex checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DLCountsInHexChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DLCountsInHexChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_LOG_ZERO_FLAG,
            QCOM_UNIT_LOG_DISPLAY_COUNTS_IN_HEX);
        RecordBasicEvent(
            "    Log Counts in Hex {0} for module {1}",
            ((unit->dataLogFlags & QCOM_UNIT_LOG_DISPLAY_COUNTS_IN_HEX) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DLCountsInHexChecked()
//----------------------------------------------------------------------------
// QCOM_DLDateStampChecked
//
// Handles the check of the Date Stamp Log Point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DLDateStampChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DLDateStampChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogDataPoint(unit, QCOM_UNIT_LOG_DATE_STAMP);
        RecordBasicEvent(
            "    Log Date Stamp {0} for module {1}",
            ((unit->dataLogPoints & QCOM_UNIT_LOG_DATE_STAMP) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DLDateStampChecked()
//----------------------------------------------------------------------------
// QCOM_DLDefaultsChecked
//
// Handles the check of the Defaults log point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DLDefaultsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DLDefaultsChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        if ((unit->dataLogPoints & QCOM_UNIT_LOG_ALL_POINTS) == QCOM_UNIT_LOG_DEFAULT_DATA_POINTS)
        {
            // Do nothing: settings at their defaults remain at their defaults
        }
        else
        {
            unit->dataLogPoints &= ~QCOM_UNIT_LOG_ALL_POINTS;
            unit->dataLogPoints |= QCOM_UNIT_LOG_DEFAULT_DATA_POINTS;
        }
        if (unit->dataLogFlags & QCOM_UNIT_LOG_TIME_MS)
            unit->dataLogFlags &= ~QCOM_UNIT_LOG_TIME_MS;
        RecordBasicEvent(
            "    Log Defaults {0} for module {1}",
            (((unit->dataLogPoints & QCOM_UNIT_LOG_ALL_POINTS) == QCOM_UNIT_LOG_DEFAULT_DATA_POINTS) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DLDefaultsChecked()
//----------------------------------------------------------------------------
// QCOM_DLMillisecondsChecked
//
// Handles the check of the Milliseconds Log Point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DLMillisecondsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DLMillisecondsChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_LOG_ZERO_FLAG,
            QCOM_UNIT_LOG_TIME_MS);
        RecordBasicEvent(
            "    Log Milliseconds {0} for module {1}",
            ((unit->dataLogFlags & QCOM_UNIT_LOG_TIME_MS) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DLMillisecondsChecked()
//----------------------------------------------------------------------------
// QCOM_DLPressureCountChecked
//
// Handles the check of the Pressure Count Log Point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DLPressureCountChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DLPressureCountChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogDataPoint(unit, QCOM_UNIT_LOG_PRESSURE_COUNT);
        RecordBasicEvent(
            "    Log Pressure Counts {0} for module {1}",
            ((unit->dataLogPoints & QCOM_UNIT_LOG_PRESSURE_COUNT) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DLPressureCountChecked()
//----------------------------------------------------------------------------
// QCOM_DLPressureFrequencyChecked
//
// Handles the check of the Pressure Frequency Log Point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DLPressureFrequencyChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DLPressureFrequencyChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogDataPoint(unit, QCOM_UNIT_LOG_PRESSURE_FREQUENCY);
        RecordBasicEvent(
            "    Log Pressure Frequency {0} for module {1}",
            ((unit->dataLogPoints & QCOM_UNIT_LOG_PRESSURE_FREQUENCY) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DLPressureFrequencyChecked()
//----------------------------------------------------------------------------
// QCOM_DLTemperatureCountChecked
//
// Handles the check of the Temperature Count Log Point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DLTemperatureCountChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DLTemperatureCountChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogDataPoint(unit, QCOM_UNIT_LOG_TEMP_COUNT);
        RecordBasicEvent(
            "    Log Temperature Counts {0} for module {1}",
            ((unit->dataLogPoints & QCOM_UNIT_LOG_TEMP_COUNT) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DLTemperatureCountChecked()
//----------------------------------------------------------------------------
// QCOM_DLTemperatureFrequencyChecked
//
// Handles the check of the Temperature Frequency Log Point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DLTemperatureFrequencyChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DLTemperatureFrequencyChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogDataPoint(unit, QCOM_UNIT_LOG_TEMP_FREQUENCY);
        RecordBasicEvent(
            "    Log Temperature Frequency {0} for module {1}",
            ((unit->dataLogPoints & QCOM_UNIT_LOG_TEMP_FREQUENCY) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DLTemperatureFrequencyChecked()
//----------------------------------------------------------------------------
// QCOM_DLTimeStampChecked
//
// Handles the check of the Date Stamp Log Point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DLTimeStampChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DLTimeStampChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogDataPoint(unit, QCOM_UNIT_LOG_TIME_STAMP);
        RecordBasicEvent(
            "    Log Time Stamp {0} for module {1}",
            ((unit->dataLogPoints & QCOM_UNIT_LOG_TIME_STAMP) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DLTimeStampChecked()
//----------------------------------------------------------------------------
// QCOM_DLTransducerAmperageChecked
//
// Handles the check of the Transducer Current Log Point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DLTransducerAmperageChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DLTransducerAmperageChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogDataPoint(unit, QCOM_UNIT_LOG_XD_AMPERAGE);
        RecordBasicEvent(
            "    Log Transducer Current {0} for module {1}",
            ((unit->dataLogPoints & QCOM_UNIT_LOG_XD_AMPERAGE) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DLTransducerAmperageChecked()
//----------------------------------------------------------------------------
// QCOM_DLTransducerVoltageChecked
//
// Handles the check of the Transducer Voltage Log Point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DLTransducerVoltageChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_DLTransducerVoltageChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogDataPoint(unit, QCOM_UNIT_LOG_XD_VOLTAGE);
        RecordBasicEvent(
            "    Log Transducer Voltage {0} for module {1}",
            ((unit->dataLogPoints & QCOM_UNIT_LOG_XD_VOLTAGE) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_DLTransducerVoltageChecked()
//----------------------------------------------------------------------------
// QCOM_EmbedCaptionInFileChecked
//
// Handles the check of the Embed Caption In File box
//
// Called by:   QCOM_ConstructUnitLogTabInAllWindow
//              QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_EmbedCaptionInFileChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_EmbedCaptionInFileChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_LOG_ZERO_FLAG,
            QCOM_UNIT_LOG_FILE_EMBED_CAPTION);
        RecordBasicEvent(
            "    Embed Caption in File {0} for module {1}",
            ((unit->dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_EmbedCaptionInFileChecked()
//----------------------------------------------------------------------------
// QCOM_LogAllBothFileFormatsChecked
//
// Handles the check of the Select Both File Formats box
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllBothFileFormatsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralLogFlagThenSetUnitFlags(
        QCOM_GENERAL_LOG_FILE_BOTH_FORMATS,
        QCOM_UNIT_LOG_FILE_BOTH_FORMATS);
    RecordBasicEvent(
        "Log All Selection for Both CSV and Text file formats {0}",
        ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_FILE_BOTH_FORMATS) ? "checked" : "un-checked"));
}                                       // end of QCOM_LogAllBothFileFormatsChecked()
//----------------------------------------------------------------------------
// QCOM_LogAllClearCommentButtonClicked
//
// Handles the click of the Log All Clear Comment button
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllClearCommentButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Log All Comment Clear button clicked");
    logAllInsertCommentBox->Clear();
}                                       // end of QCOM_LogAllClearCommentButtonClicked()
//----------------------------------------------------------------------------
// QCOM_LogAllCloseWindow
//
// Event that closes the Log All Data display window
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("All Data Logging Window closed");
    logAllDataWindow->Hide();
}                                       // end of QCOM_LogAllCloseWindow()
//----------------------------------------------------------------------------
// QCOM_LogAllClosingWindow
//
// Handles the closing of the Log All window by the red X or similar method
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    RecordBasicEvent("All Data Logging window closed by X");
    logAllDataWindow->Hide();
}                                       // end of QCOM_LogAllClosingWindow()
//----------------------------------------------------------------------------
// QCOM_LogAllCommentTimeStampChecked
//
// Handles the click of the Log All Time Stamp Comments button
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllCommentTimeStampChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralLogFlagThenSetUnitFlags(
        QCOM_GENERAL_LOG_COMMENTS_TIME_STAMP,
        QCOM_UNIT_LOG_ZERO_FLAG);
    RecordBasicEvent(
        "Log All Comment Time Stamp {0}",
        ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_COMMENTS_TIME_STAMP) ? "checked" : "un-checked"));
}                                       // end of QCOM_LogAllCommentTimeStampChecked()
//----------------------------------------------------------------------------
// QCOM_LogAllDisplayAllSummariesChecked
//
// Handles the check of the Display All Summaries check box
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllDisplayAllSummariesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralLogFlagThenSetUnitFlags(
        QCOM_GENERAL_LOG_DISPLAY_SUMMARIES,
        QCOM_UNIT_LOG_DISPLAY_SUMMARY);
    RecordBasicEvent(
        "Log All Display Summaries {0}",
        ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DISPLAY_SUMMARIES) ? "checked" : "un-checked"));
}                                       // end of QCOM_LogAllDisplayAllSummariesChecked()
//----------------------------------------------------------------------------
// QCOM_LogAllDisplayButtonClicked
//
// Displays a new window that presents the logging of data for all
// transducers
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllDisplayButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Log All Data button clicked");
    if (logAllDataWindow->WindowState == FormWindowState::Minimized)
        logAllDataWindow->WindowState = FormWindowState::Normal;
    else
        logAllDataWindow->Show();
    logAllDataWindow->BringToFront();
    if (logAllDataWindow->CanFocus)
        logAllDataWindow->Focus();
    if (logAllDataWindow->CanSelect)
        logAllDataWindow->Select();
}                                       // end of QCOM_LogAllDisplayButtonClicked()
//----------------------------------------------------------------------------
// QCOM_LogAllInsertCommentButtonClicked
//
// Handles the click of the Log All Add Comment button
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllInsertCommentButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = FunctionName();
    //------------------------------------------------------------------------
    RecordBasicEvent("Log All Insert Comment button clicked");
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            QCOM_LogAllInsertComment(QCOM_UnitInfoArray[unitNumber]);
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                functionName, unitNumber, QCOM_CurrentNumberOfUnits);
        }
    }
}                                       // end of QCOM_LogAllInsertCommentButtonClicked()
//----------------------------------------------------------------------------
// QCOM_LogAllPrependEntryNumbersChecked
//
// Handles the check of the Prepend All Entry Numbers check box
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllPrependEntryNumbersChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = FunctionName();
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralLogFlagThenSetUnitFlags(
        QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS,
        QCOM_UNIT_LOG_PREPEND_ENTRY_NUMBERS);
    RecordBasicEvent(
        "Log All Prepend Entry Numbers {0}",
        ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS) ? "checked" : "un-checked"));
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            QCOM_LogUnitUpdateCaptions(QCOM_UnitInfoArray[unitNumber]);
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                functionName, unitNumber, QCOM_CurrentNumberOfUnits);
        }
    }
}                                       // end of QCOM_LogAllPrependEntryNumbersChecked()
//----------------------------------------------------------------------------
// QCOM_LogAllSaveLoggedDataImmediatelyChecked
//
// Handles the check of the Save Logged Data Immediately check box
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllSaveLoggedDataImmediatelyChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralLogFlagThenSetUnitFlags(
        QCOM_GENERAL_LOG_DATA_SAVE_IMMEDIATELY,
        QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY);
    RecordBasicEvent(
        "Log All Selection for Save Logged Data Immediately {0}",
        ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DATA_SAVE_IMMEDIATELY) ? "checked" : "un-checked"));
}                                       // end of QCOM_LogAllSaveLoggedDataImmediatelyChecked()
//----------------------------------------------------------------------------
// QCOM_LogAllSnapshotDataButtonClicked
//
// Handles the click of the Snapshot All Data Logs button
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllSnapshotDataButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("QCOM_LogAllSnapshotDataButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    QCOM_LogAllSnapshotData();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_LogAllSnapshotDataButtonClicked()
//----------------------------------------------------------------------------
// QCOM_LogAllStartStopButtonClicked
//
// Handles the press of the Start/Stop Logging button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//              QCOM_InstallHomeWindowGraphics
//              QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllStartStopButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent(
        "{0} Data Logging All button clicked",
        ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING) ? "Stop" : "Start"));
    QCOM_StartStopDataLoggingAll();
}                                       // end of QCOM_LogAllStartStopButtonClicked()
//----------------------------------------------------------------------------
// QCOM_LogAllWrapDisplayChecked
//
// Handles the check of the Wrap Data Log box
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllWrapDisplayChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralLogFlagThenSetUnitFlags(
        QCOM_GENERAL_LOG_DISPLAY_WRAP,
        QCOM_UNIT_LOG_DISPLAY_WRAP);
    RecordBasicEvent(
        "Log All File Wrap Text {0}",
        ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DISPLAY_WRAP) ? "checked" : "un-checked"));
}                                       // end of QCOM_LogAllWrapDisplayChecked()
//----------------------------------------------------------------------------
// QCOM_LogFileAppendRadioSelected
//
// Handles the click of the Append radio button
//
// Called by:   QCOM_ConstructUnitLogTabInAllWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogFileAppendRadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <RadioButton ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogFileAppendRadioSelected");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Log File Append radio button selected for module {0}",
            unit->moduleSerialNumber);
        if (!(unit->dataLogFlags & QCOM_UNIT_LOG_FILE_APPEND))
            unit->dataLogFlags |= QCOM_UNIT_LOG_FILE_APPEND;
        QCOM_LogUnitUpdateChecks(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogFileAppendRadioSelected()
//----------------------------------------------------------------------------
// QCOM_LogFileAutoSaveRadioSelected
//
// Handles the click of the Auto-Save radio button
//
// Called by:   QCOM_ConstructUnitLogTabInAllWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogFileAutoSaveRadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            proceedToSelect;
    DWORD           unitNumber = (DWORD) (dynamic_cast <RadioButton ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogFileAutoSaveRadioSelected");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Log File Auto Save radio button selected for module {0}",
            unit->moduleSerialNumber);
        if (QCOM_LogFileKnown(unit))
        {
            unit->dataLogFlags |= QCOM_UNIT_LOG_FILE_AUTO_SAVE;
        }
        else
        {
            proceedToSelect = QCOM_QuerySelectDataLogFile(unit);
            if (proceedToSelect)
            {
                if (QCOM_LogFileKnown(unit))
                    unit->dataLogFlags |= QCOM_UNIT_LOG_FILE_AUTO_SAVE;
            }
        }
        QCOM_LogUnitUpdateChecks(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogFileAutoSaveRadioSelected()
//----------------------------------------------------------------------------
// QCOM_LogFileOverwriteRadioSelected
//
// Handles the click of the Overwrite radio button
//
// Called by:   QCOM_ConstructUnitLogTabInAllWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogFileOverwriteRadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            proceedToSetOverwrite = GUI_YES;
    DWORD           unitNumber = (DWORD) (dynamic_cast <RadioButton ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogFileOverwriteRadioSelected");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Log File Overwrite radio button selected for module {0}",
            unit->moduleSerialNumber);
        if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
        {
            proceedToSetOverwrite = QCOM_PromptModal(
                "Overwrite",
                "Data log file for transducer {0} is currently set as\n{1}\n"
                "Overwrite this file?",
                unit->transducerSerialNumber,
                unit->dataLogFilePath);
        }
        if (proceedToSetOverwrite)
        {
            if (unit->dataLogFlags & QCOM_UNIT_LOG_FILE_APPEND)
                unit->dataLogFlags &= ~QCOM_UNIT_LOG_FILE_APPEND;
        }
        QCOM_LogUnitUpdateChecks(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogFileOverwriteRadioSelected()
//----------------------------------------------------------------------------
// QCOM_LogFilePromptRadioSelected
//
// Handles the click of the Prompt radio button
//
// Called by:   QCOM_ConstructUnitLogTabInAllWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogFilePromptRadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <RadioButton ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogFilePromptRadioSelected");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Log File Prompt radio button selected for module {0}",
            unit->moduleSerialNumber);
        if (unit->dataLogFlags & QCOM_UNIT_LOG_FILE_AUTO_SAVE)
            unit->dataLogFlags &= ~QCOM_UNIT_LOG_FILE_AUTO_SAVE;
        QCOM_LogUnitUpdateChecks(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogFilePromptRadioSelected()
//----------------------------------------------------------------------------
// QCOM_LogUnitAltPressureChecked
//
// Handles the check of the Alternate Pressure Log Point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitAltPressureChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitAltPressureChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogDataPoint(unit, QCOM_UNIT_LOG_PRESSURE_ALT);
        RecordBasicEvent(
            "    Log {0} {1} for module {2}",
            QCOM_PressureUnitsStringArray[QCOM_AlternatePressureUnits],
            ((unit->dataLogPoints & QCOM_UNIT_LOG_PRESSURE_ALT) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitAltPressureChecked()
//----------------------------------------------------------------------------
// QCOM_LogUnitAltTemperatureChecked
//
// Handles the check of the Alternate Temperature Log Point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitAltTemperatureChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitAltTemperatureChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogDataPoint(unit, QCOM_UNIT_LOG_TEMP_ALT);
        RecordBasicEvent(
            "    Log {0} {1} for module {2}",
            QCOM_TemperatureUnitsStringArray[QCOM_AlternateTemperatureUnits],
            ((unit->dataLogPoints & QCOM_UNIT_LOG_TEMP_ALT) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitAltTemperatureChecked()
//----------------------------------------------------------------------------
// QCOM_LogUnitBothFileFormatsChecked
//
// Handles the check of the Select Both File Types checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitBothFileFormatsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitBothFileFormatsChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_LOG_FILE_BOTH_FORMATS,
            QCOM_UNIT_LOG_FILE_BOTH_FORMATS);
        RecordBasicEvent(
            "    Both CSV and Text file formats {0} for module {1}",
            ((unit->dataLogFlags & QCOM_UNIT_LOG_FILE_BOTH_FORMATS) ? "selected" : "de-selected"),
            unit->moduleSerialNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitBothFileFormatsChecked()
//----------------------------------------------------------------------------
// QCOM_LogUnitClearCommentButtonClicked
//
// Handles the click of the Clear Comment button
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitClearCommentButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitClearCommentButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        logUnitInsertCommentBoxArray[unitNumber]->Clear();
        RecordBasicEvent(
            "    Log Clear Comment button clicked for module {0}",
            unit->moduleSerialNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitClearCommentButtonClicked()
//----------------------------------------------------------------------------
// QCOM_LogUnitClearDataButtonClicked
//
// Handles the click of the Clear Data Log button
//
// Called by:   QCOM_ConstructUnitLogTabInAllWindow
//              QCOM_ConstructUnitReadoutGroupBox
//              QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitClearDataButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitClearDataButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Clear Data Log button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_ClearDataLog(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitClearDataButtonClicked()
//----------------------------------------------------------------------------
// QCOM_LogUnitCloseWindow
//
// Event that closes the Log Data display window by hiding it
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitCloseWindow");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Data Logging window closed for module {0}",
            unit->moduleSerialNumber);
        logUnitWindowArray[unitNumber]->Hide();
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitCloseWindow()
//----------------------------------------------------------------------------
// QCOM_LogUnitClosingWindow
//
// Handles the closing of the unit log window by the red X or similar method
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Form ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitClosingWindow");
    //------------------------------------------------------------------------
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Data Logging window button closed for module {0}",
            unit->moduleSerialNumber);
        logUnitWindowArray[unitNumber]->Hide();
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitClosingWindow()
//----------------------------------------------------------------------------
// QCOM_LogUnitCommentTimeStampChecked
//
// Handles the check of the Time Stamp Comment button
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitCommentTimeStampChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitCommentTimeStampChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_LOG_ZERO_FLAG,
            QCOM_UNIT_LOG_COMMENT_TIME_STAMP);
        RecordBasicEvent(
            "    Log Comment Time Stamp {0} for module {1}",
            ((unit->dataLogFlags & QCOM_UNIT_LOG_COMMENT_TIME_STAMP) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitCommentTimeStampChecked()
//----------------------------------------------------------------------------
// QCOM_LogUnitDefPressureChecked
//
// Handles the check of the Default Pressure Log Point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitDefPressureChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitDefPressureChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogDataPoint(unit, QCOM_UNIT_LOG_PRESSURE_DEF);
        RecordBasicEvent(
            "    Log {0} {1} for module {2}",
            QCOM_PressureUnitsStringArray[QCOM_DefaultPressureUnits],
            ((unit->dataLogPoints & QCOM_UNIT_LOG_PRESSURE_DEF) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitDefPressureChecked()
//----------------------------------------------------------------------------
// QCOM_LogUnitDefTemperatureChecked
//
// Handles the check of the Default Temperature Log Point checkbox
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitDefTemperatureChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitDefTemperatureChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogDataPoint(unit, QCOM_UNIT_LOG_TEMP_DEF);
        RecordBasicEvent(
            "    Log {0} {1} for module {2}",
            QCOM_TemperatureUnitsStringArray[QCOM_DefaultTemperatureUnits],
            ((unit->dataLogPoints & QCOM_UNIT_LOG_TEMP_DEF) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitDefTemperatureChecked()
//----------------------------------------------------------------------------
// QCOM_LogUnitDisplayButtonClicked
//
// Displays a new window that presents the logging of data for a single
// transducer
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitDisplayButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitDisplayButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Log Data button clicked for module {0}",
            unit->moduleSerialNumber);
        if (logUnitWindowArray[unitNumber]->WindowState == FormWindowState::Minimized)
            logUnitWindowArray[unitNumber]->WindowState = FormWindowState::Normal;
        else
            logUnitWindowArray[unitNumber]->Show();
        logUnitWindowArray[unitNumber]->BringToFront();
        if (logUnitWindowArray[unitNumber]->CanFocus)
            logUnitWindowArray[unitNumber]->Focus();
        if (logUnitWindowArray[unitNumber]->CanSelect)
            logUnitWindowArray[unitNumber]->Select();
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberValid(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitDisplayButtonClicked()
//----------------------------------------------------------------------------
// QCOM_LogUnitDisplaySummaryChecked
//
// Handles the check of the Display Statistics check box
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitDisplaySummaryChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitDisplaySummaryChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_LOG_DISPLAY_SUMMARIES,
            QCOM_UNIT_LOG_DISPLAY_SUMMARY);
        RecordBasicEvent(
            "    Display Summary {0} for module {1}",
            ((unit->dataLogFlags & QCOM_UNIT_LOG_DISPLAY_SUMMARY) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitDisplaySummaryChecked()
//----------------------------------------------------------------------------
// QCOM_LogUnitPrependEntryNumbersChecked
//
// Handles the check of the Prepend Entry Numbers check box
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitPrependEntryNumbersChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitPrependEntryNumbersChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS,
            QCOM_UNIT_LOG_PREPEND_ENTRY_NUMBERS);
        RecordBasicEvent(
            "    Prepend Entry Numbers {0} for module {1}",
            ((unit->dataLogFlags & QCOM_UNIT_LOG_PREPEND_ENTRY_NUMBERS) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_LogUnitUpdateCaptions(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitPrependEntryNumbersChecked()
//----------------------------------------------------------------------------
// QCOM_LogUnitInsertCommentButtonClicked
//
// Handles the click of the Add Comment button
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitInsertCommentButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitInsertCommentButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Log Insert Comment button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_LogUnitInsertComment(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitInsertCommentButtonClicked()
//----------------------------------------------------------------------------
// QCOM_LogUnitSaveLoggedDataImmediatelyChecked
//
// Handles the check of the Save Logged Data Immediately check box
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitSaveLoggedDataImmediatelyChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitSaveLoggedDataImmediatelyChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_LOG_DATA_SAVE_IMMEDIATELY,
            QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY);
        RecordBasicEvent(
            "    Save Logged Data Immediately {0} for module {1}",
            ((unit->dataLogFlags & QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitSaveLoggedDataImmediatelyChecked()
//----------------------------------------------------------------------------
// QCOM_LogUnitSelectDataLogFileButtonClicked
//
// Handles the click of the Select Data Log File button
//
// Called by:   QCOM_ConstructUnitLogTabInAllWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitSelectDataLogFileButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitSelectDataLogFileButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Select Data Log File button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_SelectDataLogFile(unit);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitSelectDataLogFileButtonClicked()
//----------------------------------------------------------------------------
// QCOM_LogUnitSnapshotDataButtonClicked
//
// Handles the click of the Snapshot Data Log button
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitSnapshotDataButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitSnapshotDataButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    Snapshot Data Log button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_LogUnitSnapshotData(QCOM_UnitInfoArray[unitNumber]);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitSnapshotDataButtonClicked()
//----------------------------------------------------------------------------
// QCOM_LogUnitStartStopButtonClicked
//
// Handles the press of the Start/Stop Logging button
//
// Called by:   QCOM_ConstructUnitLogTabInAllWindow
//              QCOM_ConstructUnitReadoutGroupBox
//              QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitStartStopButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitStartStopButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    {0} Data Logging button clicked for module {1}",
            ((unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING) ? "Stop" : "Start"),
            unit->moduleSerialNumber);
        QCOM_StartStopDataLoggingUnit(unit);
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitStartStopButtonClicked()
//----------------------------------------------------------------------------
// QCOM_LogUnitWrapDisplayChecked
//
// Handles the check of the Wrap Display check box
//
// Called by:   QCOM_SetUpUnitDataLoggingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitWrapDisplayChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_LogUnitWrapDisplayChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitLogFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_LOG_DISPLAY_WRAP,
            QCOM_UNIT_LOG_DISPLAY_WRAP);
        RecordBasicEvent(
            "    Wrap Display {0} for module {1}",
            ((unit->dataLogFlags & QCOM_UNIT_LOG_DISPLAY_WRAP) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_LogUnitWrapDisplayChecked()
//----------------------------------------------------------------------------
// QCOM_UtilConvertCSVToDataLogButtonClicked
//
// Handles the click of the Convert CSV to Data Log button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertCSVToDataLogButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Convert CSV to Data Log button clicked");
    QCOM_LogPromptAndConvertCSVToDataLogFormat();
}                                       // end of QCOM_UtilConvertCSVToDataLogButtonClicked()
//----------------------------------------------------------------------------
// QCOM_UtilConvertDataLogToCSVButtonClicked
//
// Handles the click of the Convert Data Log to CSV button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertDataLogToCSVButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Convert Data Log to CSV button clicked");
    QCOM_LogPromptAndConvertDataLogToCSVFormat();
}                                       // end of QCOM_UtilConvertDataLogToCSVButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ValidateLoggingIntervalValue
//
// Handles changes of the logging timer interval field; ensures that the
// integer value of the field falls within the appropriate limits
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateLoggingIntervalValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    bool            revertToOriginalValue = GUI_NO;
    DWORD           newInterval;
    String          ^functionName = _T("QCOM_ValidateLoggingIntervalValue");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING))
    {
        if (StringSet(logAllIntervalBox->Text))
        {
            bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
                logAllIntervalBox->Text,
                &newInterval);
            if (isCorrectFormat)
            {
                if ((newInterval < QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET]) ||
                    (newInterval > QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MAXIMUM_OFFSET]))
                {
                    QCOM_PromptOKModal(
                        "Invalid Logging Interval Value",
                        "Valid values are {0:D} through {1:D}, inclusive",
                        QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET],
                        QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MAXIMUM_OFFSET]);
                    RecordErrorEvent(
                        "    Attempted setting logging interval value to '{0:D}'",
                        newInterval);
                    revertToOriginalValue = GUI_YES;
                }
                else
                {
                    if (newInterval != QCOM_CurrentSamplingInterval)
                    {
                        RecordBasicEvent(
                            "    The Sampling Interval changed from {0:D} {1} to {2:D} {1}",
                            QCOM_CurrentSamplingInterval,
                            QCOM_IntervalUnitsStringArray[QCOM_CurrentIntervalUnitsOffset],
                            newInterval);
                        QCOM_CurrentSamplingInterval = newInterval;
                        QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_RECENT_OFFSET] = newInterval;
                        samplingTimer->Interval = QCOM_MapDisplayIntervalToActual(newInterval);
                        logAllIntervalBox->Text = String::Concat(QCOM_CurrentSamplingInterval);
                        readoutSamplingIntervalBox->Text = logAllIntervalBox->Text;
                    }
                    evt->Cancel = GUI_NO;
                    RecordBasicEvent("{0} concluded: Accept {1:D}",
                        functionName, QCOM_CurrentSamplingInterval);
                    return;
                }
            }                           // end of if (isCorrectFormat)
            else
            {
                QCOM_PromptOKModal(
                    "Invalid Characters",
                    "The entry contains invalid characters;\n"
                    "enter only decimal digits");
                RecordErrorEvent(
                    "    Attempted setting logging interval value to '{0}'",
                    logAllIntervalBox->Text);
                revertToOriginalValue = GUI_YES;
            }
        }                               // end of if (StringSet(logAllIntervalBox->Text))
        else
        {
            revertToOriginalValue = GUI_YES;
        }
        if (revertToOriginalValue)
        {
            logAllIntervalBox->Text = String::Concat(QCOM_CurrentSamplingInterval);
            readoutSamplingIntervalBox->Text = logAllIntervalBox->Text;
        }
    }                                   // end of if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING))
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_ValidateLoggingIntervalValue()
//----------------------------------------------------------------------------
// QCOM_ValidateLoggingLimitValue
//
// Validates the logging limit minutes text box
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateLoggingLimitValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    bool            revertToOriginalValue = GUI_NO;
    DWORD           newLimit;
    String          ^functionName = _T("QCOM_ValidateLoggingLimitValue");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(logAllLimitLoggingTimeBox->Text))
    {
        bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
            logAllLimitLoggingTimeBox->Text,
            &newLimit);
        if (isCorrectFormat)
        {
            if ((newLimit < GUI_MINIMUM_SAMPLING_RUN_TIME_MINUTES) ||
                (newLimit > GUI_MAXIMUM_SAMPLING_RUN_TIME_MINUTES))
            {
                QCOM_PromptOKModal(
                    "Invalid Time Limit Value",
                    "Valid values are {0:D} through {1:D} minutes, inclusive",
                    GUI_MINIMUM_SAMPLING_RUN_TIME_MINUTES, GUI_MAXIMUM_SAMPLING_RUN_TIME_MINUTES);
                RecordErrorEvent(
                    "    Attempted setting logging limit value to '{0:D}'",
                    newLimit);
                revertToOriginalValue = GUI_YES;
            }
            else
            {
                if (newLimit != QCOM_MaximumSamplingRunTimeMinutes)
                {
                    RecordBasicEvent(
                        "    The Logging Limit changed from {0:D} to {1:D} min",
                        QCOM_MaximumSamplingRunTimeMinutes,
                        newLimit);
                    QCOM_MaximumSamplingRunTimeMinutes = newLimit;
                    readoutLimitSamplingTimeBox->Text = String::Concat(QCOM_MaximumSamplingRunTimeMinutes);
                    logAllLimitLoggingTimeBox->Text = String::Concat(QCOM_MaximumSamplingRunTimeMinutes);
                }
                evt->Cancel = GUI_NO;
                RecordBasicEvent("{0} concluded: Accept {1:D}",
                    functionName, QCOM_MaximumSamplingRunTimeMinutes);
                return;
            }
        }                               // end of if (isCorrectFormat)
        else
        {
            QCOM_PromptOKModal(
                "Invalid Characters",
                "The entry contains invalid characters;\n"
                "enter only decimal digits");
            RecordErrorEvent(
                "    Attempted setting logging limit value to '{0}'",
                readoutLimitSamplingTimeBox->Text);
            revertToOriginalValue = GUI_YES;
        }
    }
    else
    {
        revertToOriginalValue = GUI_YES;
    }
    if (revertToOriginalValue)
    {
        readoutLimitSamplingTimeBox->Text = String::Concat(QCOM_MaximumSamplingRunTimeMinutes);
        logAllLimitLoggingTimeBox->Text = String::Concat(QCOM_MaximumSamplingRunTimeMinutes);
    }
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_ValidateLoggingLimitValue()
//----------------------------------------------------------------------------
#endif      // LOGEVENTS_CPP
//============================================================================
// End of LogEvents.cpp
//============================================================================
