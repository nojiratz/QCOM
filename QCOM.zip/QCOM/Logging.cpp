//============================================================================
// Logging.cpp
//
// The regular and event methods used by GUI.cpp for data logging
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     LOGGING_CPP
#define     LOGGING_CPP
#include    "Logging.h"
//----------------------------------------------------------------------------
// QCOM_ApplyGeneralLogFlagToUnitFlags
//
// Applies the specified general flag to all corresponding unit flags, or
// sets the general flag only if all corresponding unit flags are set
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ApplyGeneralLogFlagToUnitFlags(
    DWORD           generalLogFlag,
    DWORD           unitLogFlag)
{
    bool            allUnitFlagsAreSet = GUI_YES;
    bool            atLeastOneUnitIsValid = GUI_NO;
    //------------------------------------------------------------------------
    if (generalLogFlag && unitLogFlag)
    {
        if (QCOM_GeneralInfo->logFlags & generalLogFlag)
        {
            for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
            {
                if (QCOM_UnitNumberLegal(unitNumber))
                {
                    QCOM_UnitInfoArray[unitNumber]->dataLogFlags |= unitLogFlag;
                }
            }
        }
        else
        {
            for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
            {
                if (QCOM_UnitNumberLegal(unitNumber))
                {
                    atLeastOneUnitIsValid = GUI_YES;
                    if (!(QCOM_UnitInfoArray[unitNumber]->dataLogFlags & unitLogFlag))
                        allUnitFlagsAreSet = GUI_NO;
                }
            }
            if (atLeastOneUnitIsValid && allUnitFlagsAreSet)
                QCOM_GeneralInfo->logFlags |= generalLogFlag;
        }
    }
}                                       // end of QCOM_ApplyGeneralLogFlagToUnitFlags()
//----------------------------------------------------------------------------
// QCOM_BuildDoubleDisplayCaptionString
//
// Builds a formatted managed string for the display caption of a double entry
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_BuildDoubleDisplayCaptionString(
    String          ^captionToAdd,
    double          value,
    int             precision,
    int             prependSpaces,
    int             appendSpaces,
    StringBuilder   ^captionBuilder)
{
    int             captionWidth;
    int             dataWidth;
    String          ^newCaption = captionToAdd;
    String          ^valueString;
    //------------------------------------------------------------------------
    valueString = String::Format(String::Concat("{0:F", precision, "}"), value);
    if (precision == 0)
        prependSpaces = appendSpaces = 1;
    dataWidth = QCOM_StringWidth(valueString);
    captionWidth = QCOM_StringWidth(captionToAdd);
    while (dataWidth > captionWidth)
    {
        newCaption = String::Concat(QCOM_STRING_SPACE, newCaption, QCOM_STRING_SPACE);
        captionWidth = QCOM_StringWidth(newCaption);
    }
    captionBuilder->Append(' ', prependSpaces)->Append(newCaption)->Append(' ', appendSpaces);
}                                       // end of QCOM_BuildDoubleDisplayCaptionString()
//----------------------------------------------------------------------------
// QCOM_BuildIntegerDisplayCaptionString
//
// Builds a formatted managed string for the display caption of an integer entry
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_BuildIntegerDisplayCaptionString(
    String          ^captionToAdd,
    int             value,
    bool            displayInHex,
    int             prependSpaces,
    int             appendSpaces,
    StringBuilder   ^captionBuilder)
{
    int             captionWidth;
    int             dataWidth;
    String          ^newCaption = captionToAdd;
    String          ^valueString;
    //------------------------------------------------------------------------
    if (displayInHex)
        valueString = String::Format("0x{0:X}", value);
    else
        valueString = String::Format("{0:D}", value);
    captionWidth = QCOM_StringWidth(captionToAdd);
    dataWidth = QCOM_StringWidth(valueString);
    while (dataWidth > captionWidth)
    {
        newCaption = String::Concat(QCOM_STRING_SPACE, newCaption, QCOM_STRING_SPACE);
        captionWidth = QCOM_StringWidth(newCaption);
    }
    captionBuilder->Append(' ', prependSpaces)->Append(newCaption)->Append(' ', appendSpaces);
}                                       // end of QCOM_BuildIntegerDisplayCaptionString()
//----------------------------------------------------------------------------
// QCOM_ClearAllDataLogs
//
// Clears the data log and display of the specified transducer
//
// Called by:   QCOM_ClearAllDataLogsButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ClearAllDataLogs(void)
{
    String          ^functionName = _T("QCOM_ClearAllDataLogs");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            QCOM_ClearDataLog(QCOM_UnitInfoArray[unitNumber]);
        }
        else
        {
            RecordErrorEvent(
                "    Unit number {0:D} should be valid,\nbut is not (number of units = {1:D})",
                unitNumber, QCOM_CurrentNumberOfUnits);
        }
    }
    QCOM_GeneralInfo->logFlags &= ~QCOM_GENERAL_LOG_DATA_PRESENT;
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ClearAllDataLogs()
//----------------------------------------------------------------------------
// QCOM_ClearDataLog
//
// Clears the data log and display of the specified transducer
//
// Called by:   QCOM_LogUnitClearDataButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ClearDataLog(
    UnitInfo        ^unit)
{
    bool            proceedToClearLog = GUI_YES;
    String          ^functionName = _T("QCOM_ClearDataLog");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
        {
            if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
            {
                proceedToClearLog = QCOM_QueryStopLogging(unit,
                    "Data for transducer {0} is being logged",
                    unit->transducerSerialNumber);
            }
            if (proceedToClearLog && QCOM_LogDataPresent(unit))
            {
                QCOM_QuerySaveDataLog(unit);
            }
        }
        if (proceedToClearLog)
        {
            QCOM_LogUnitUpdateDataLog(
                unit,
                (GUI_LOG_ACTION_CLEAR_LOG | GUI_LOG_ACTION_CLEAR_DISPLAY));
            //----------------------------------------------------------------
            // If logging is running for this unit, re-stamp the new log
            //----------------------------------------------------------------
            if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
            {
                QCOM_StampDataLogStarted(unit);
            }
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_ClearDataLog()
//----------------------------------------------------------------------------
// QCOM_CollectDataSample
//
// Collects a sample of all of the most recent log data and stores it in the
// stats structure
//
// Called by:   QCOM_SamplingTimerElapsed
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_CollectDataSample(
    DWORD           unitNumber)
{
    int             lapsedDays;
    int             lapsedHours;
    int             lapsedMinutes;
    int             lapsedSeconds;
    int             lapsedMilliseconds;
    long            lowLong;
    long            highLong;
    long long       totalLong;
    DWORD           currentTime = GetTickCount();
    double          lowDouble;
    double          highDouble;
    double          totalDouble;
    LoggingStatsInfo
                    ^logStats;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_CollectDataSample");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if (QCOM_UnitLogReady(unit))
        {
            logStats = unit->loggingStats;
            logStats->numberOfSamples++;
            logStats->numberOfUnsavedSamples++;
            lowDouble = logStats->lowDefPres;
            highDouble = logStats->highDefPres;
            totalDouble = logStats->totalDefPres;
            QCOM_CalculateDoubleStatistics(
                QCOM_GetPressureValue(unit, QCOM_DefaultPressureUnits),
                &lowDouble,
                &highDouble,
                &totalDouble);
            logStats->lowDefPres = lowDouble;
            logStats->highDefPres = highDouble;
            logStats->totalDefPres = totalDouble;
            lowDouble = logStats->lowAltPres;
            highDouble = logStats->highAltPres;
            totalDouble = logStats->totalAltPres;
            QCOM_CalculateDoubleStatistics(
                QCOM_GetPressureValue(unit, QCOM_AlternatePressureUnits),
                &lowDouble,
                &highDouble,
                &totalDouble);
            logStats->lowAltPres = lowDouble;
            logStats->highAltPres = highDouble;
            logStats->totalAltPres = totalDouble;
            lowLong = logStats->lowPCount;
            highLong = logStats->highPCount;
            totalLong = logStats->totalPCount;
            QCOM_CalculateIntegerStatistics(
                unit->pressureCount,
                &lowLong,
                &highLong,
                &totalLong);
            logStats->lowPCount = lowLong;
            logStats->highPCount = highLong;
            logStats->totalPCount = totalLong;
            lowDouble = logStats->lowPFreq;
            highDouble = logStats->highPFreq;
            totalDouble = logStats->totalPFreq;
            QCOM_CalculateDoubleStatistics(
                (((double) unit->pressureCount) * QCOM_FREQUENCY_MULTIPLIER),
                &lowDouble,
                &highDouble,
                &totalDouble);
            logStats->lowPFreq = lowDouble;
            logStats->highPFreq = highDouble;
            logStats->totalPFreq = totalDouble;
            lowDouble = logStats->lowDefTemp;
            highDouble = logStats->highDefTemp;
            totalDouble = logStats->totalDefTemp;
            QCOM_CalculateDoubleStatistics(
                QCOM_GetTemperatureValue(unit, QCOM_DefaultTemperatureUnits),
                &lowDouble,
                &highDouble,
                &totalDouble);
            logStats->lowDefTemp = lowDouble;
            logStats->highDefTemp = highDouble;
            logStats->totalDefTemp = totalDouble;
            lowDouble = logStats->lowAltTemp;
            highDouble = logStats->highAltTemp;
            totalDouble = logStats->totalAltTemp;
            QCOM_CalculateDoubleStatistics(
                QCOM_GetTemperatureValue(unit, QCOM_AlternateTemperatureUnits),
                &lowDouble,
                &highDouble,
                &totalDouble);
            logStats->lowAltTemp = lowDouble;
            logStats->highAltTemp = highDouble;
            logStats->totalAltTemp = totalDouble;
            lowLong = logStats->lowTCount;
            highLong = logStats->highTCount;
            totalLong = logStats->totalTCount;
            QCOM_CalculateIntegerStatistics(
                unit->temperatureCount,
                &lowLong,
                &highLong,
                &totalLong);
            logStats->lowTCount = lowLong;
            logStats->highTCount = highLong;
            logStats->totalTCount = totalLong;
            lowDouble = logStats->lowTFreq;
            highDouble = logStats->highTFreq;
            totalDouble = logStats->totalTFreq;
            QCOM_CalculateDoubleStatistics(
                (((double) unit->temperatureCount) * QCOM_FREQUENCY_MULTIPLIER),
                &lowDouble,
                &highDouble,
                &totalDouble);
            logStats->lowTFreq = lowDouble;
            logStats->highTFreq = highDouble;
            logStats->totalTFreq = totalDouble;
            lowDouble = logStats->lowVoltage;
            highDouble = logStats->highVoltage;
            totalDouble = logStats->totalVoltage;
            QCOM_CalculateDoubleStatistics(
                unit->transducerVoltage,
                &lowDouble,
                &highDouble,
                &totalDouble);
            logStats->lowVoltage = lowDouble;
            logStats->highVoltage = highDouble;
            logStats->totalVoltage = totalDouble;
            lowDouble = logStats->lowAmperage;
            highDouble = logStats->highAmperage;
            totalDouble = logStats->totalAmperage;
            QCOM_CalculateDoubleStatistics(
                unit->transducerAmperage,
                &lowDouble,
                &highDouble,
                &totalDouble);
            logStats->lowAmperage = lowDouble;
            logStats->highAmperage = highDouble;
            logStats->totalAmperage = totalDouble;
            QCOM_LogUnitDataSample(unit);
            if (QCOM_ReadyToMarkLoggingTime[unitNumber])
            {
                logStats->cumulative += (currentTime - logStats->startTime);
                logStats->startTime = currentTime;
                QCOM_TimeElapsed(
                    logStats->cumulative,
                    &lapsedDays,
                    &lapsedHours,
                    &lapsedMinutes,
                    &lapsedSeconds,
                    &lapsedMilliseconds);
                logUnitTimeLabelArray[unitNumber]->Text = String::Format(
                    "Logging {0} continuously for {1:D} d {2:D} h {3:D} m {4:D} s",
                    unit->transducerSerialNumber,
                    lapsedDays,
                    lapsedHours,
                    lapsedMinutes,
                    lapsedSeconds);
                QCOM_ReadyToMarkLoggingTime[unitNumber] = GUI_NO;
            }
            delete logStats;
        }                               // end of if (QCOM_UnitLogReady(unit))
        delete unit;
    }                                   // emd of if (QCOM_UnitNumberValid(unitNumber))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_CollectDataSample()
//----------------------------------------------------------------------------
// QCOM_ConstructUnitLogTabInAllWindow
//
// Builds a unit data log group box for the All Data Log window
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConstructUnitLogTabInAllWindow(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_ConstructUnitLogTabInAllWindow");
    //------------------------------------------------------------------------
    if (unit)
    {
        unitNumber = unit->unitNumber;
        RecordVerboseEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Create the tab page
        //--------------------------------------------------------------------
        TabPage ^logAllUnitTabPage = gcnew TabPage;
        if (QCOM_ModuleSNValid(unit))
            logAllUnitTabPage->Text = unit->moduleSerialNumber;
        else
            logAllUnitTabPage->Text = String::Concat("Unit ", unitNumber);
        logAllUnitTabPage->TabIndex = unitNumber;
        logAllUnitTabPage->BackgroundImage = whiteSandBackground;
        logAllUnitTabPageArray[unitNumber] = logAllUnitTabPage;
        //--------------------------------------------------------------------
        // Create the group box
        //--------------------------------------------------------------------
        GroupBox ^logAllUnitGroupBox = gcnew GroupBox;
        logAllUnitGroupBox->Location = Point(10, 6);
        logAllUnitGroupBox->Size = Drawing::Size(
            GUI_LOG_ALL_GROUP_BOX_WIDTH,
            GUI_LOG_ALL_UNIT_GROUP_BOX_HEIGHT);
        logAllUnitGroupBox->ForeColor = Color::Black;
        logAllUnitGroupBox->BackColor = Color::Transparent;
        logAllUnitTabPage->Controls->Add(logAllUnitGroupBox);
        //--------------------------------------------------------------------
        // Start/Stop Logging button
        //--------------------------------------------------------------------
        Button ^logAllUnitStartStopButton = gcnew Button;
        logAllUnitStartStopButton->Location = Point(10, 20);
        logAllUnitStartStopButton->Size = logAllStartStopButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            logAllUnitStartStopButton,
            unitNumber);
        logAllUnitStartStopButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitStartStopButtonClicked);
        logAllStartStopButtonArray[unitNumber] = logAllUnitStartStopButton;
        //--------------------------------------------------------------------
        // Clear Data Log button
        //--------------------------------------------------------------------
        Button ^logAllUnitClearButton = gcnew Button;
        logAllUnitClearButton->Text = _T("Clear Data Log");
        GUI_PositionAndSizeBelow(logAllUnitClearButton, logAllUnitStartStopButton, 10);
        GUI_SetUnitButtonInterfaceProperties(
            logAllUnitClearButton,
            unitNumber);
        logAllUnitClearButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitClearDataButtonClicked);
        logAllClearButtonArray[unitNumber] = logAllUnitClearButton;
        //--------------------------------------------------------------------
        // Snapshot Data Log button
        //--------------------------------------------------------------------
        Button ^logAllUnitSnapshotDataButton = gcnew Button;
        logAllUnitSnapshotDataButton->Text = _T("Snapshot Data Log");
        logAllUnitSnapshotDataButton->Location = Point(
            logAllUnitStartStopButton->Right + 16,
            logAllUnitStartStopButton->Top);
        logAllUnitSnapshotDataButton->Size = logAllStartStopButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            logAllUnitSnapshotDataButton,
            unitNumber);
        logAllUnitSnapshotDataButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitSnapshotDataButtonClicked);
        logAllSnapshotDataButtonArray[unitNumber] = logAllUnitSnapshotDataButton;
        //--------------------------------------------------------------------
        // Select / Change Data Log File button and filename
        //--------------------------------------------------------------------
        Button ^logAllUnitSelectFileButton = gcnew Button;
        logAllUnitSelectFileButton->Location = Point(
            logAllUnitSnapshotDataButton->Left,
            logAllUnitClearButton->Top);
        logAllUnitSelectFileButton->Size = logAllStartStopButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            logAllUnitSelectFileButton,
            unitNumber);
        logAllUnitSelectFileButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitSelectDataLogFileButtonClicked);
        logAllSelectFileButtonArray[unitNumber] = logAllUnitSelectFileButton;
        //--------------------------------------------------------------------
        // Display the Data Log File label
        //--------------------------------------------------------------------
        Label ^logAllFileLabel = gcnew Label;
        logAllFileLabel->Location = Point(
            logAllUnitSelectFileButton->Right + 5,
            logAllUnitSelectFileButton->Top + 9);
        logAllFileLabel->Size = Drawing::Size(
            540, GUI_INFO_LABEL_HEIGHT);
        logAllFileLabel->BackColor = Color::Transparent;
        logAllFileLabelArray[unitNumber] = logAllFileLabel;
        //--------------------------------------------------------------------
        // Auto Save and Prompt radio buttons
        //--------------------------------------------------------------------
        GroupBox ^logAllAutoSavePromptGroupBox = gcnew GroupBox;
        logAllAutoSavePromptGroupBox->Location = Point(
            logAllUnitSnapshotDataButton->Right + 16,
            15);
        logAllAutoSavePromptGroupBox->Size = Drawing::Size(175, 44);
        logAllAutoSavePromptGroupBox->ForeColor = Color::Black;
        logAllAutoSavePromptGroupBox->BackColor = Color::Transparent;
        RadioButton ^logAllAutoSaveRadio = gcnew RadioButton;
        logAllAutoSaveRadio->Text = _T("Auto-save the data log");
        logAllAutoSaveRadio->Location = Point(2, 8);
        logAllAutoSaveRadio->Size = Drawing::Size(
            160, GUI_REGULAR_RADIO_BUTTON_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(logAllAutoSaveRadio, unitNumber);
        logAllAutoSaveRadio->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogFileAutoSaveRadioSelected);
        logAllAutoSaveAllRadioArray[unitNumber] = logAllAutoSaveRadio;
        RadioButton ^logAllPromptRadio = gcnew RadioButton;
        logAllPromptRadio->Text = _T("Prompt to save the data log");
        GUI_PositionAndSizeBelow(logAllPromptRadio, logAllAutoSaveRadio, 2);
        GUI_SetUnitObjectInterfaceProperties(
            logAllPromptRadio,
            unitNumber);
        logAllPromptRadio->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogFilePromptRadioSelected);
        logAllPromptRadioArray[unitNumber] = logAllPromptRadio;
        array <RadioButton ^> ^logAllAutoSaveRadios =
        {
            logAllAutoSaveRadio,
            logAllPromptRadio
        };
        logAllAutoSavePromptGroupBox->Controls->AddRange(logAllAutoSaveRadios);
        //--------------------------------------------------------------------
        // Append and Overwrite radio buttons
        //--------------------------------------------------------------------
        GroupBox ^logAllAppendOverwriteGroupBox = gcnew GroupBox;
        logAllAppendOverwriteGroupBox->Location = Point(
            logAllAutoSavePromptGroupBox->Right + 5,
            logAllAutoSavePromptGroupBox->Top);
        logAllAppendOverwriteGroupBox->Size = logAllAutoSavePromptGroupBox->Size;
        logAllAppendOverwriteGroupBox->ForeColor = Color::Black;
        logAllAppendOverwriteGroupBox->BackColor = Color::Transparent;
        RadioButton ^appendRadio = gcnew RadioButton;
        appendRadio->Text = _T("Append the data log");
        appendRadio->Location = Point(2, 8);
        appendRadio->Size = Drawing::Size(
            160, GUI_REGULAR_RADIO_BUTTON_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            appendRadio,
            unitNumber);
        appendRadio->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogFileAppendRadioSelected);
        logAllAppendRadioArray[unitNumber] = appendRadio;
        RadioButton ^overwriteRadio = gcnew RadioButton;
        overwriteRadio->Text = _T("Over-write the data log");
        overwriteRadio->Location = Point(
            appendRadio->Left,
            appendRadio->Bottom + 2);
        overwriteRadio->Size = appendRadio->Size;
        GUI_SetUnitObjectInterfaceProperties(
            overwriteRadio,
            unitNumber);
        overwriteRadio->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogFileOverwriteRadioSelected);
        logAllOverwriteRadioArray[unitNumber] = overwriteRadio;
        array <RadioButton ^> ^appendOverwriteRadios =
        {
            appendRadio,
            overwriteRadio
        };
        logAllAppendOverwriteGroupBox->Controls->AddRange(appendOverwriteRadios);
        logAllAppendOverwriteGroupBoxArray[unitNumber] = logAllAppendOverwriteGroupBox;
        //--------------------------------------------------------------------
        // Enable Caption In check boxes
        //--------------------------------------------------------------------
        GroupBox ^logAllEmbedCaptionGroupBox = gcnew GroupBox;
        logAllEmbedCaptionGroupBox->Location = Point(
            logAllAppendOverwriteGroupBox->Right + 5,
            logAllAutoSavePromptGroupBox->Top);
        logAllEmbedCaptionGroupBox->Size = logAllAutoSavePromptGroupBox->Size;
        logAllEmbedCaptionGroupBox->ForeColor = Color::Black;
        logAllEmbedCaptionGroupBox->BackColor = Color::Transparent;
        CheckBox ^displayCaptionInLogCheck = gcnew CheckBox;
        displayCaptionInLogCheck->Text = _T("Display caption in log");
        displayCaptionInLogCheck->Location = Point(2, 8);
        displayCaptionInLogCheck->Size = Drawing::Size(
            130, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            displayCaptionInLogCheck,
            unitNumber);
        displayCaptionInLogCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DisplayCaptionInLogChecked);
        logAllDisplayCaptionCheckArray[unitNumber] = displayCaptionInLogCheck;
        CheckBox ^embedCaptionInFileCheck = gcnew CheckBox;
        embedCaptionInFileCheck->Text = _T("Embed caption in file");
        embedCaptionInFileCheck->Location = Point(
            displayCaptionInLogCheck->Left,
            displayCaptionInLogCheck->Bottom + 2);
        embedCaptionInFileCheck->Size = displayCaptionInLogCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            embedCaptionInFileCheck,
            unitNumber);
        embedCaptionInFileCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_EmbedCaptionInFileChecked);
        logAllEmbedCaptionCheckArray[unitNumber] = embedCaptionInFileCheck;
        array <CheckBox ^> ^embedCaptionsChecks =
        {
            displayCaptionInLogCheck,
            embedCaptionInFileCheck
        };
        logAllEmbedCaptionGroupBox->Controls->AddRange(embedCaptionsChecks);
        //--------------------------------------------------------------------
        // Log text window caption
        //--------------------------------------------------------------------
        Label ^logAllCaptionLabel = gcnew Label;
        logAllCaptionLabel->Location = Point(
            logAllUnitStartStopButton->Left,
            logAllUnitSelectFileButton->Bottom + 4);
        logAllCaptionLabel->Size = Drawing::Size(
            810, GUI_REGULAR_LABEL_HEIGHT);
        logAllCaptionLabel->BackColor = Color::Transparent;
        logAllCaptionLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            8.0F,
            FontStyle::Regular);
        logAllCaptionLabelArray[unitNumber] = logAllCaptionLabel;
        //--------------------------------------------------------------------
        // Log text window
        //--------------------------------------------------------------------
        TextBox ^logAllTextBox = gcnew TextBox;
        logAllTextBox->Location = Point(
            logAllCaptionLabel->Left,
            logAllCaptionLabel->Bottom + 2);
        logAllTextBox->Size = Drawing::Size(logAllCaptionLabel->Width, 100);
        logAllTextBox->MaxLength = unit->dataLogSize;
        logAllTextBox->Multiline = GUI_YES;
        logAllTextBox->ReadOnly = GUI_YES;
        logAllTextBox->ScrollBars = ScrollBars::Vertical;
        logAllTextBox->AcceptsReturn = GUI_YES;
        logAllTextBox->AcceptsTab = GUI_YES;
        logAllBoxArray[unitNumber] = logAllTextBox;
        //--------------------------------------------------------------------
        // Progress bar and label if in Expert Mode
        //--------------------------------------------------------------------
        Label ^progressLabel = gcnew Label;
        progressLabel->Text = _T("0% Full");
        GUI_PositionBelow(progressLabel, logAllTextBox, 4);
        progressLabel->Size = Drawing::Size(48, GUI_REGULAR_LABEL_HEIGHT);
        logAllUnitGroupBox->Controls->Add(progressLabel);
        logAllPercentFullLabelArray[unitNumber] = progressLabel;
        ProgressBar ^progressBar = gcnew ProgressBar;
        progressBar->Location = Point(
            progressLabel->Right,
            progressLabel->Top);
        progressBar->Size = Drawing::Size(
            logAllTextBox->Width - progressLabel->Width,
            progressLabel->Height);
        progressBar->Minimum = 0;
        progressBar->Maximum = 100;
        progressBar->Value = 0;
        progressBar->Style = ProgressBarStyle::Continuous;
        logAllPercentFullProgressArray[unitNumber] = progressBar;
        //--------------------------------------------------------------------
        // Attach the components to the Log All unit group box
        //--------------------------------------------------------------------
        array <Button ^> ^dataLogButtons =
        {
            logAllUnitStartStopButton,
            logAllUnitClearButton,
            logAllUnitSnapshotDataButton,
            logAllUnitSelectFileButton
        };
        logAllUnitGroupBox->Controls->AddRange(dataLogButtons);
        array <GroupBox ^> ^logAllUnitGroupBoxes =
        {
            logAllAutoSavePromptGroupBox,
            logAllAppendOverwriteGroupBox,
            logAllEmbedCaptionGroupBox
        };
        logAllUnitGroupBox->Controls->AddRange(logAllUnitGroupBoxes);
        logAllUnitGroupBox->Controls->Add(logAllFileLabel);
        logAllUnitGroupBox->Controls->Add(logAllCaptionLabel);
        logAllUnitGroupBox->Controls->Add(logAllTextBox);
        logAllUnitGroupBox->Controls->Add(progressBar);
        //--------------------------------------------------------------------
        // Save the unit group box instance
        //--------------------------------------------------------------------
        logAllGroupBoxArray[unitNumber] = logAllUnitGroupBox;
        logAllUnitGroupBox->Hide();
        RecordVerboseEvent("{0} concluded", functionName);
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_ConstructUnitLogTabInAllWindow()
//----------------------------------------------------------------------------
// QCOM_ConvertCSVToLogData
//
// Converts the specified Microsoft Excel XLS-ready CSV (comma-separated
// values) text format string into QCOM log data text
//
// Returns the formatted data string
//----------------------------------------------------------------------------
    String ^ QCOM_GUIClass::
QCOM_ConvertCSVToLogData(
    String          ^preFormattedData)
{
    bool            atDateEntry = GUI_NO;
    bool            atTimeEntry = GUI_NO;
    String          ^dataLogCSV;
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("QCOM_ConvertCSVToLogData");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(preFormattedData))
    {
        array <Char> ^lineDelimiters = gcnew array <Char> {QCOM_CHAR_CR, QCOM_CHAR_LF};
        array <String ^> ^lines = preFormattedData->Split(
            lineDelimiters,
            StringSplitOptions::RemoveEmptyEntries);
        for (int lineNumber = 0; lineNumber < lines->Length; lineNumber++)
        {
            String ^line = lines[lineNumber];
            //----------------------------------------------------------------
            // Replace all the commas and hyphens with spaces, then trim the
            // line
            //----------------------------------------------------------------
            line = line->Replace(QCOM_STRING_COMMA, QCOM_STRING_SPACE)->Replace(QCOM_STRING_HYPHEN, QCOM_STRING_SPACE)->Trim();
            //----------------------------------------------------------------
            // Prepend the line with the line number
            //----------------------------------------------------------------
            lines[lineNumber] = String::Format("{0:D6}  {1}", (lineNumber + 1), line);
            delete line;
        }                               // end of for (int lineNumber = 0; ...)
        //--------------------------------------------------------------------
        // Recombine all the lines into the original string
        //
        // Caution: This line could easily run out of memory for large files
        //--------------------------------------------------------------------
        preFormattedData = String::Join(QCOM_STRING_CRLF, lines);
        //--------------------------------------------------------------------
        // Split up the string again, only this time omit the blanked lines
        //--------------------------------------------------------------------
        lines = preFormattedData->Split(lineDelimiters, StringSplitOptions::RemoveEmptyEntries);
        //--------------------------------------------------------------------
        // Combine the new set of lines into the new CSV string
        //--------------------------------------------------------------------
        dataLogCSV = String::Join(QCOM_STRING_CRLF, lines);
        delete [] lines;
        delete [] lineDelimiters;
    }                                   // end of if (StringSet(preFormattedData))
    else
    {
        dataLogCSV = preFormattedData;
    }
    RecordBasicEvent("{0} concluded", functionName);
    return dataLogCSV;
}                                       // end of QCOM_ConvertCSVToLogData()
//----------------------------------------------------------------------------
// QCOM_ConvertLogDataToCSV
//
// Converts the specified log data into Microsoft Excel XLS-ready CSV (comma-
// separated values) text format
//
// Returns the formatted data string
//----------------------------------------------------------------------------
    String ^ QCOM_GUIClass::
QCOM_ConvertLogDataToCSV(
    String          ^preFormattedData)
{
    bool            atDateEntry = GUI_NO;
    bool            atTimeEntry = GUI_NO;
    String          ^dataLogCSV = String::Empty;
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("QCOM_ConvertLogDataToCSV");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(preFormattedData))
    {
        array <Char> ^lineDelimiters = gcnew array <Char> {QCOM_CHAR_CR, QCOM_CHAR_LF};
        array <String ^> ^lines = preFormattedData->Split(
            lineDelimiters,
            StringSplitOptions::RemoveEmptyEntries);
        for (int lineNumber = 0; lineNumber < lines->Length; lineNumber++)
        {
            String ^line = lines[lineNumber];
            //----------------------------------------------------------------
            // Omit lines that begin with a pound sign, which indicates a
            // comment, and lines that contain the "Logging" string
            //----------------------------------------------------------------
            if (line->StartsWith("#") || line->Contains("Logging"))
            {
                //------------------------------------------------------------
                // Blank out this line
                //------------------------------------------------------------
                line = line->Remove(0);
            }
            else
            {
                //------------------------------------------------------------
                // Extract the substring that begins with the first space
                // character (which removes the line number, if present), then
                // trim the line
                //------------------------------------------------------------
                line = line->Substring(line->IndexOf(' '))->Trim();
                while (line->Contains("  "))
                    line = line->Replace(QCOM_STRING_DSPACE, QCOM_STRING_SPACE)->Trim();
                //------------------------------------------------------------
                // Determine whether the first fields are the date strings
                //------------------------------------------------------------
                for each (String ^monthName in QCOM_MonthStringArray)
                {
                    if (StringICompare(line->Substring(3, 3), monthName) == 0)
                    {
                        atDateEntry = GUI_YES;
                        break;
                    }
                }
                //------------------------------------------------------------
                // A comma and a subsequent space must follow the date, but
                // the spaces will get removed, so change the one needed space
                // into a tilde ('~') placeholder
                //------------------------------------------------------------
                if (atDateEntry)
                {
                    line = String::Concat(
                        line->Substring(0, 2), QCOM_STRING_HYPHEN,
                        line->Substring(3, 3), QCOM_STRING_HYPHEN,
                        line->Substring(7, 4), ",~",
                        line->Substring(12));
                }
                else
                {
                    //--------------------------------------------------------
                    // If the time stamp is missing, prepend it to the line
                    //--------------------------------------------------------
                    if (line[2] != ':')
                    {
//                        line = String::Format(
//                            "{0:D2}:{1:D2}:{2:D2},{3}",
//                            dateTime.Hour,
//                            dateTime.Minute,
//                            dateTime.Second,
//                            line);
                    }
                    //--------------------------------------------------------
                    // The CSV file format requires a date stamp, so prepend
                    // today's date, including the tilde placeholder
                    //--------------------------------------------------------
                    line = String::Format(
                        "{0:D2}-{1}-{2:D4},~{3}",
                        dateTime.Day,
                        QCOM_MonthStringArray[dateTime.Month],
                        dateTime.Year,
                        line);
                }
                //------------------------------------------------------------
                // Replace all remaining spaces with commas
                //------------------------------------------------------------
                line = line->Replace(' ', ',');
                //------------------------------------------------------------
                // Replace all tilde placeholders (should only be one at this
                // time) with spaces
                //------------------------------------------------------------
                line = line->Replace('~', ' ');
            }
            lines[lineNumber] = line;
            delete line;
        }                               // end of for (int lineNumber = 0; ...)
        //--------------------------------------------------------------------
        // Recombine all the lines into the original string
        //
        // Caution: This line could easily run out of memory for large files
        //--------------------------------------------------------------------
        preFormattedData = String::Join(QCOM_STRING_CRLF, lines);
        //--------------------------------------------------------------------
        // Split up the string again, only this time omit the blanked lines
        //--------------------------------------------------------------------
        lines = preFormattedData->Split(lineDelimiters, StringSplitOptions::RemoveEmptyEntries);
        //--------------------------------------------------------------------
        // Combine the new set of lines into the new CSV string
        //--------------------------------------------------------------------
        dataLogCSV = String::Join(QCOM_STRING_CRLF, lines);
        delete [] lines;
        delete [] lineDelimiters;
    }                                   // end of if (StringSet(preFormattedData))
    else
    {
        dataLogCSV = preFormattedData;
    }
    RecordBasicEvent("{0} concluded", functionName);
    return dataLogCSV;
}                                       // end of QCOM_ConvertLogDataToCSV()
//----------------------------------------------------------------------------
// QCOM_DisplayLoggingStatistics
//
// Updates the data log with logging statistics (summary)
//
// Called by:   QCOM_StartStopDataLoggingUnit
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayLoggingStatistics(
    UnitInfo        ^unit)
{
    int             lapsedDays;
    int             lapsedHours;
    int             lapsedMinutes;
    int             lapsedSeconds;
    int             lapsedMilliseconds;
    DWORD           currentTime = GetTickCount();
    DWORD           dataLogFlags;
    DWORD           dataLogPoints;
    DWORD           numberOfSamples;
    LoggingStatsInfo
                    ^logStats;
    String          ^dataLogLine;
    String          ^formatString;
    String          ^functionName = _T("QCOM_DisplayLoggingStatistics");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordVerboseEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        dataLogFlags = unit->dataLogFlags;
        dataLogPoints = unit->dataLogPoints;
        if (QCOM_UnitLogReady(unit) &&
            (dataLogPoints & QCOM_UNIT_LOG_ALL_POINTS) &&
            (dataLogFlags & QCOM_UNIT_LOG_DISPLAY_SUMMARY))
        {
            logStats = unit->loggingStats;
            if (logStats && logStats->numberOfSamples)
            {
                numberOfSamples = logStats->numberOfSamples;
                logStats->cumulative += (currentTime - logStats->startTime);
                logStats->startTime = currentTime;
                QCOM_TimeElapsed(
                    logStats->cumulative,
                    &lapsedDays,
                    &lapsedHours,
                    &lapsedMinutes,
                    &lapsedSeconds,
                    &lapsedMilliseconds);
                dataLogLine = String::Format(
                    "Logging Summary for {0:D} Sample{1} [ time elapsed: {2:D} day{3} {4:D} hour{5} {6:D} minute{7} {8:D}.{9:D3} second{10} ]",
                    numberOfSamples, ((numberOfSamples == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                    lapsedDays, ((lapsedDays == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                    lapsedHours, ((lapsedHours == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                    lapsedMinutes, ((lapsedMinutes == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                    lapsedSeconds, lapsedMilliseconds,
                    (((lapsedSeconds == 1) && (lapsedMilliseconds == 0)) ? QCOM_STRING_EMPTY : QCOM_STRING_S));
                GUI_StringToBuilder(
                    dataLogLine,
                    unit->dataLogLine);
                QCOM_LogUnitUpdateDataLog(
                    unit,
                    (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
                if (dataLogPoints & QCOM_UNIT_LOG_PRESSURE_DEF)
                {
                    formatString = String::Concat(
                        "    Pressure ({0}) : Low = {1:F",
                        QCOM_CurrentPrecision, "}    High = {2:F",
                        QCOM_CurrentPrecision, "}    Average = {3:F",
                        QCOM_CurrentPrecision, "}");
                    dataLogLine = String::Format(
                        formatString,
                        QCOM_PressureUnitsStringArray[QCOM_DefaultPressureUnits],
                        logStats->lowDefPres,
                        logStats->highDefPres,
                        (logStats->totalDefPres / (double) numberOfSamples));
                    GUI_StringToBuilder(
                        dataLogLine,
                        unit->dataLogLine);
                    QCOM_LogUnitUpdateDataLog(
                        unit,
                        (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
                }
                if (dataLogPoints & QCOM_UNIT_LOG_PRESSURE_ALT)
                {
                    formatString = String::Concat(
                        "    Pressure ({0}) : Low = {1:F",
                        QCOM_CurrentPrecision, "}    High = {2:F",
                        QCOM_CurrentPrecision, "}    Average = {3:F",
                        QCOM_CurrentPrecision, "}");
                    dataLogLine = String::Format(
                        formatString,
                        QCOM_PressureUnitsStringArray[QCOM_AlternatePressureUnits],
                        logStats->lowAltPres,
                        logStats->highAltPres,
                        (logStats->totalAltPres / (double) numberOfSamples));
                    GUI_StringToBuilder(
                        dataLogLine,
                        unit->dataLogLine);
                    QCOM_LogUnitUpdateDataLog(
                        unit,
                        (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
                }
                if (dataLogPoints & QCOM_UNIT_LOG_PRESSURE_COUNT)
                {
                    dataLogLine = String::Format(
                        "    Pressure (counts) : Low = {0:D}    High = {1:D}    Average = {2:D}",
                        logStats->lowPCount, logStats->highPCount,
                        ((DWORD) (logStats->totalPCount / numberOfSamples)));
                    GUI_StringToBuilder(
                        dataLogLine,
                        unit->dataLogLine);
                    QCOM_LogUnitUpdateDataLog(
                        unit,
                        (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
                }
                if (dataLogPoints & QCOM_UNIT_LOG_PRESSURE_FREQUENCY)
                {
                    dataLogLine = String::Format(
                        "    Pressure Frequency (Hz) : Low = {0:F3}    High = {1:F3}    Average = {2:F3}",
                        logStats->lowPFreq, logStats->highPFreq,
                        (logStats->totalPFreq / numberOfSamples));
                    GUI_StringToBuilder(
                        dataLogLine,
                        unit->dataLogLine);
                    QCOM_LogUnitUpdateDataLog(
                        unit,
                        (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
                }
                if (dataLogPoints & QCOM_UNIT_LOG_TEMP_DEF)
                {
                    formatString = String::Concat(
                        "    Temperature ({0}) : Low = {1:F",
                        QCOM_CurrentPrecision, "}    High = {2:F",
                        QCOM_CurrentPrecision, "}    Average = {3:F",
                        QCOM_CurrentPrecision, "}");
                    dataLogLine = String::Format(
                        formatString,
                        QCOM_TemperatureUnitsStringArray[QCOM_DefaultTemperatureUnits],
                        logStats->lowDefTemp,
                        logStats->highDefTemp,
                        (logStats->totalDefTemp / (double) numberOfSamples));
                    GUI_StringToBuilder(
                        dataLogLine,
                        unit->dataLogLine);
                    QCOM_LogUnitUpdateDataLog(
                        unit,
                        (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
                }
                if (dataLogPoints & QCOM_UNIT_LOG_TEMP_ALT)
                {
                    formatString = String::Concat(
                        "    Temperature ({0}) : Low = {1:F",
                        QCOM_CurrentPrecision, "}    High = {2:F",
                        QCOM_CurrentPrecision, "}    Average = {3:F",
                        QCOM_CurrentPrecision, "}");
                    dataLogLine = String::Format(
                        formatString,
                        QCOM_TemperatureUnitsStringArray[QCOM_AlternateTemperatureUnits],
                        logStats->lowAltTemp,
                        logStats->highAltTemp,
                        (logStats->totalAltTemp / (double) numberOfSamples));
                    GUI_StringToBuilder(
                        dataLogLine,
                        unit->dataLogLine);
                    QCOM_LogUnitUpdateDataLog(
                        unit,
                        (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
                }
                if (dataLogPoints & QCOM_UNIT_LOG_TEMP_COUNT)
                {
                    dataLogLine = String::Format(
                        "    Temperature (counts) : Low = {0:D}    High = {1:D}    Average = {2:D}",
                        logStats->lowTCount, logStats->highTCount,
                        ((DWORD) (logStats->totalTCount / numberOfSamples)));
                    GUI_StringToBuilder(
                        dataLogLine,
                        unit->dataLogLine);
                    QCOM_LogUnitUpdateDataLog(
                        unit,
                        (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
                }
                if (dataLogPoints & QCOM_UNIT_LOG_TEMP_FREQUENCY)
                {
                    dataLogLine = String::Format(
                        "    Temperature Frequency (Hz) : Low = {0:F3}    High = {1:F3}    Average = {2:F3}",
                        logStats->lowTFreq, logStats->highTFreq,
                        (logStats->totalTFreq / numberOfSamples));
                    GUI_StringToBuilder(
                        dataLogLine,
                        unit->dataLogLine);
                    QCOM_LogUnitUpdateDataLog(
                        unit,
                        (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
                }
                if (dataLogPoints & QCOM_UNIT_LOG_XD_VOLTAGE)
                {
                    dataLogLine = String::Format(
                        "    Transducer Voltage (V) : Low = {0:F2}    High = {1:F2}    Average = {2:F2}",
                        logStats->lowVoltage,
                        logStats->highVoltage,
                        (logStats->totalVoltage / (double) numberOfSamples));
                    GUI_StringToBuilder(
                        dataLogLine,
                        unit->dataLogLine);
                    QCOM_LogUnitUpdateDataLog(
                        unit,
                        (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
                }
                if (dataLogPoints & QCOM_UNIT_LOG_XD_AMPERAGE)
                {
                    dataLogLine = String::Format(
                        "    Transducer Current (mA) : Low = {0:F2}    High = {1:F2}    Average = {2:F2}",
                        logStats->lowAmperage,
                        logStats->highAmperage,
                        (logStats->totalAmperage / (double) numberOfSamples));
                    GUI_StringToBuilder(
                        dataLogLine,
                        unit->dataLogLine);
                    QCOM_LogUnitUpdateDataLog(
                        unit,
                        (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
                }
            }
            else
            {
                dataLogLine = _T("Not enough data points to produce a summary");
                GUI_StringToBuilder(
                    dataLogLine,
                    unit->dataLogLine);
                QCOM_LogUnitUpdateDataLog(
                    unit,
                    (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
            }
            delete formatString;
            delete dataLogLine;
        }
        RecordVerboseEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_DisplayLoggingStatistics()
//----------------------------------------------------------------------------
// QCOM_InstallDataLogging
//
// Installs data logging
//
// Called by:   QCOM_InstallUtilities
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InstallDataLogging(void)
{
    String          ^functionName = _T("QCOM_InstallDataLogging");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Set up the data logging windows
    //------------------------------------------------------------------------
    QCOM_SetUpAllDataLoggingWindows();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_InstallDataLogging()
//----------------------------------------------------------------------------
// QCOM_LogAllInsertComment
//
// Inserts a comment in the data log for the specified unit
//
// Called by:   QCOM_LogAllInsertCommentButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllInsertComment(
    UnitInfo        ^unit)
{
    DWORD           logAction = GUI_LOG_ACTION_COMMENT;
    String          ^functionName = _T("QCOM_LogAllInsertComment");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0} called", functionName);
        GUI_StringToBuilder(
            logAllInsertCommentBox->Text,
            unit->dataLogLine);
        logAction |=
            (GUI_LOG_ACTION_APPEND_NEWLINE |
            GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY);
        if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_COMMENTS_TIME_STAMP)
            logAction |= GUI_LOG_ACTION_PREPEND_TIME_STAMP;
        QCOM_LogUnitUpdateDataLog(unit, logAction);
        RecordBasicEvent("{0} concluded by adding\n'{1}'",
            functionName, logAllInsertCommentBox->Text);
    }
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_LogAllInsertComment()
//----------------------------------------------------------------------------
// QCOM_LogAllSnapshotData
//
// Saves a snapshot of the logged data currently in memory for all units
//
// Called by:   QCOM_LogAllSnapshotDataButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllSnapshotData(void)
{
    bool            transferResult;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_LogAllSnapshotDataButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberLegal(unitNumber))
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            bool spinLockAcquired = GUI_NO;
            try
            {
                QCOM_LogSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                transferResult = QCOM_TransferDataLogToFile(
                    unit,
                    GUI_SNAPSHOT_LOG);
            }                           // end of try
            finally
            {
                if (spinLockAcquired == GUI_YES)
                    QCOM_LogSpinLockArray[unitNumber]->Exit();
            }
            if (transferResult == GUI_ACCEPT)
            {
                QCOM_RecordAndModalEventByFlags(
                    QCOM_EventLogVerboseEnabled,
                    QCOM_VerboseMessagesEnabled,
                    String::Format("QCOM_TransferDataLogToFile({0:D})", unitNumber),
                    "Data log snapshot for transducer {0} saved to file\n{1}",
                    unit->transducerSerialNumber,
                    unit->dataLogSnapshotFilePath);
            }
        }
        else
        {
            RecordErrorEvent(
                "    Unit number {0:D} should be valid,\nbut is not (number of units = {1:D})",
                unitNumber, QCOM_CurrentNumberOfUnits);
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_LogAllSnapshotData()
//----------------------------------------------------------------------------
// QCOM_LogAllUpdateCaptions
//
// Updates the captions on the data logs for all units that are ready
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogAllUpdateCaptions(void)
{
    String          ^functionName = _T("QCOM_LogAllUpdateCaptions");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberReady(unitNumber))
        {
            QCOM_LogUnitUpdateCaptions(QCOM_UnitInfoArray[unitNumber]);
        }
    }
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_LogAllUpdateCaptions()
//----------------------------------------------------------------------------
// QCOM_LogFileMovePair
//
// Moves the specified log file and its companion to the specified destination
//
// Called by:   QCOM_SelectDataLogFile
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogFileMovePair(
    String          ^sourcePathString,
    String          ^destinationPathString)
{
    long            fileSize;
    String          ^formattedData;
    String          ^preformattedData;
    StreamReader    ^textReader;
    StreamWriter    ^textWriter;
    String          ^functionName = _T("QCOM_LogFileMovePair");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(sourcePathString) && StringSet(destinationPathString))
    {
        sourcePathString = sourcePathString->Trim();
        destinationPathString = destinationPathString->Trim();
        if (File::Exists(sourcePathString))
        {
            FileInfo ^filePathInfo = gcnew FileInfo(sourcePathString);
            fileSize = (long) filePathInfo->Length;
            delete filePathInfo;
            if (!fileSize)
            {
                File::Delete(sourcePathString);
                Thread::Sleep(100);
            }
            if (File::Exists(destinationPathString))
            {
                File::Delete(destinationPathString);
                Thread::Sleep(100);
            }
            if (StringICompare(Path::GetExtension(sourcePathString), Path::GetExtension(destinationPathString)))
            {
                if (File::Exists(sourcePathString))
                {
                    //--------------------------------------------------------
                    // The source and destination filenames have different
                    // extensions, so the source file must be converted
                    //--------------------------------------------------------
                    textReader = File::OpenText(sourcePathString);
                    if (textReader)
                    {
                        preformattedData = textReader->ReadToEnd();
                        textReader->Close();
                    }
                    if (sourcePathString->EndsWith(".log"))
                        formattedData = QCOM_ConvertLogDataToCSV(preformattedData);
                    else
                        formattedData = QCOM_ConvertCSVToLogData(preformattedData);
                    if (File::Exists(destinationPathString))
                    {
                        File::Delete(destinationPathString);
                        Thread::Sleep(100);
                    }
                    textWriter = File::CreateText(destinationPathString);
                    if (textWriter)
                    {
                        textWriter->WriteLine(formattedData);
                        textWriter->Close();
                    }
                }                       // end of if (File::Exists(sourcePathString))
            }                           // end of if (StringICompare(Path::GetExtension(sourcePathString), ...))
            else
            {
                //------------------------------------------------------------
                // The source and destination filenames have the same
                // extension, so just move the source file if it exists
                //------------------------------------------------------------
                if (File::Exists(sourcePathString))
                {
                    File::Move(sourcePathString, destinationPathString);
                }
            }
            RecordBasicEvent("    Moved\n    {0}\n    to\n    {1}",
                sourcePathString, destinationPathString);
        }                               // end of if (File::Exists(sourcePathString))
        //--------------------------------------------------------------------
        // Search for its companion file
        //--------------------------------------------------------------------
        if (sourcePathString->EndsWith(".log"))
        {
            sourcePathString = sourcePathString->Replace(Path::GetExtension(sourcePathString), ".csv");
        }
        else
        {
            sourcePathString = sourcePathString->Replace(Path::GetExtension(sourcePathString), ".log");
        }
        if (destinationPathString->EndsWith(".log"))
        {
            destinationPathString = destinationPathString->Replace(Path::GetExtension(destinationPathString), ".csv");
        }
        else
        {
            destinationPathString = destinationPathString->Replace(Path::GetExtension(destinationPathString), ".log");
        }
        if (File::Exists(sourcePathString))
        {
            FileInfo ^filePathInfo = gcnew FileInfo(sourcePathString);
            fileSize = (long) filePathInfo->Length;
            delete filePathInfo;
            if (!fileSize)
            {
                File::Delete(sourcePathString);
                Thread::Sleep(100);
            }
            if (File::Exists(destinationPathString))
            {
                File::Delete(destinationPathString);
                Thread::Sleep(100);
            }
            if (StringICompare(Path::GetExtension(sourcePathString), Path::GetExtension(destinationPathString)))
            {
                if (File::Exists(sourcePathString))
                {
                    //--------------------------------------------------------
                    // The source and destination filenames have different
                    // extensions, so the source file must be converted
                    //--------------------------------------------------------
                    textReader = File::OpenText(sourcePathString);
                    if (textReader)
                    {
                        preformattedData = textReader->ReadToEnd();
                        textReader->Close();
                    }
                    if (sourcePathString->EndsWith(".log"))
                        formattedData = QCOM_ConvertLogDataToCSV(preformattedData);
                    else
                        formattedData = QCOM_ConvertCSVToLogData(preformattedData);
                    if (File::Exists(destinationPathString))
                    {
                        File::Delete(destinationPathString);
                        Thread::Sleep(100);
                    }
                    textWriter = File::CreateText(destinationPathString);
                    if (textWriter)
                    {
                        textWriter->WriteLine(formattedData);
                        textWriter->Close();
                    }
                }                       // end of if (File::Exists(sourcePathString))
            }                           // end of if (StringICompare(Path::GetExtension(sourcePathString), ...))
            else
            {
                //------------------------------------------------------------
                // The source and destination filenames have the same
                // extension, so just move the source file if it exists
                //------------------------------------------------------------
                if (File::Exists(sourcePathString))
                {
                    File::Move(sourcePathString, destinationPathString);
                }
            }
            RecordBasicEvent("    Moved\n    {0}\n    to\n    {1}",
                sourcePathString, destinationPathString);
        }                               // end of if (File::Exists(sourcePathString))
    }                                   // end of if (StringSet(sourcePathString) && StringSet(destinationPathString))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_LogFileMovePair()
//----------------------------------------------------------------------------
// QCOM_LogPromptAndConvertCSVToDataLogFormat
//
// Prompts for a CSV-formatted text file to convert to QCOM Data Log format
//
// Called by:   QCOM_UtilConvertCSVToDataLogButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogPromptAndConvertCSVToDataLogFormat(void)
{
    bool            promptResult;
    String          ^filePathString;
    String          ^formattedData;
    String          ^logData;
    StreamReader    ^textReader;
    StreamWriter    ^textWriter;
    String          ^functionName = _T("QCOM_LogPromptAndConvertCSVToDataLogFormat");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_USE_PATH_SPECIFIED)
    {
        filePathString = QCOM_GeneralInfo->generalUsePath;
    }
    else
    {
        if (StringSet(QCOM_GeneralInfo->searchString))
        {
            filePathString = QCOM_GeneralInfo->searchString;
        }
        else
        {
            filePathString = Environment::GetFolderPath(Environment::SpecialFolder::Recent);
        }
    }
    StringBuilder ^filePathBuilder =
        gcnew StringBuilder(filePathString, QCOM_MAXIMUM_FILE_PATH_LENGTH);
    promptResult = QCOM_PromptForReadFile(
        "Convert CSV File to QCOM Data Log",
        filePathBuilder,
        filePathString,
        GUI_FILE_TYPE_CSV);
    filePathString = filePathBuilder->ToString();
    if (promptResult == GUI_ACCEPT)
    {
        QCOM_SetGeneralUsePath(filePathString);
        if (File::Exists(filePathString))
        {
            textReader = File::OpenText(filePathString);
            if (textReader)
            {
                logData = textReader->ReadToEnd();
                textReader->Close();
            }
            formattedData = QCOM_ConvertCSVToLogData(logData);
            filePathString = filePathString->Replace(Path::GetExtension(filePathString), ".log");
            GUI_StringToBuilder(filePathString, filePathBuilder);
            promptResult = QCOM_PromptForSaveFile(
                "Save Converted Data Log File",
                filePathBuilder,
                filePathString,
                GUI_FILE_TYPE_LOG);
            filePathString = filePathBuilder->ToString();
            if (promptResult == GUI_ACCEPT)
            {
                if (File::Exists(filePathString))
                {
                    File::Delete(filePathString);
                    Thread::Sleep(100);
                }
                textWriter = File::CreateText(filePathString);
                if (textWriter)
                {
                    textWriter->WriteLine(formattedData);
                    textWriter->Close();
                }
            }
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
    delete filePathBuilder;
}                                       // end of QCOM_LogPromptAndConvertCSVToDataLogFormat()
//----------------------------------------------------------------------------
// QCOM_LogPromptAndConvertDataLogToCSVFormat
//
// Prompts for a data log text file to convert to CSV format
//
// Called by:   QCOM_UtilConvertDataLogToCSVButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogPromptAndConvertDataLogToCSVFormat(void)
{
    bool            promptResult;
    String          ^filePathString;
    String          ^formattedData;
    String          ^logData;
    StreamReader    ^textReader;
    StreamWriter    ^textWriter;
    String          ^functionName = _T("QCOM_LogPromptAndConvertDataLogToCSVFormat");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_USE_PATH_SPECIFIED)
    {
        filePathString = QCOM_GeneralInfo->generalUsePath;
    }
    else
    {
        if (StringSet(QCOM_GeneralInfo->searchString))
        {
            filePathString = QCOM_GeneralInfo->searchString;
        }
        else
        {
            filePathString = Environment::GetFolderPath(Environment::SpecialFolder::Recent);
        }
    }
    StringBuilder ^filePathBuilder = gcnew StringBuilder(
        filePathString, QCOM_MAXIMUM_FILE_PATH_LENGTH);
    promptResult = QCOM_PromptForReadFile(
        "Convert Data Log File to CSV",
        filePathBuilder,
        filePathString,
        GUI_FILE_TYPE_LOG);
    filePathString = filePathBuilder->ToString();
    if (promptResult == GUI_ACCEPT)
    {
        QCOM_SetGeneralUsePath(filePathString);
        if (File::Exists(filePathString))
        {
            textReader = File::OpenText(filePathString);
            if (textReader)
            {
                logData = textReader->ReadToEnd();
                textReader->Close();
            }
            formattedData = QCOM_ConvertLogDataToCSV(logData);
            filePathString = filePathString->Replace(Path::GetExtension(filePathString), ".csv");
            GUI_StringToBuilder(filePathString, filePathBuilder);
            promptResult = QCOM_PromptForSaveFile(
                "Save Converted CSV File",
                filePathBuilder,
                filePathString,
                GUI_FILE_TYPE_CSV);
            filePathString = filePathBuilder->ToString();
            if (promptResult == GUI_ACCEPT)
            {
                if (File::Exists(filePathString))
                {
                    File::Delete(filePathString);
                    Thread::Sleep(100);
                }
                textWriter = File::CreateText(filePathString);
                if (textWriter)
                {
                    textWriter->WriteLine(formattedData);
                    textWriter->Close();
                }
            }
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
    delete filePathBuilder;
}                                       // end of QCOM_LogPromptAndConvertDataLogToCSVFormat()
//----------------------------------------------------------------------------
// QCOM_LogUnitDataSample
//
// Takes a sample of the indicated data points for the transducer at the
// specified unit and stores the data in the data log
//
// Called by:   QCOM_CollectDataSample
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitDataSample(
    UnitInfo        ^unit)
{
    bool            previousFieldPresent = GUI_NO;
    int             standardSpacing = 4;
    DWORD           dataLogFlags;
    DWORD           dataLogPoints;
    DateTime        dateTime = DateTime::Now;
    LoggingStatsInfo
                    ^logStats;
    String          ^functionName = _T("QCOM_LogUnitDataSample");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        dataLogFlags = unit->dataLogFlags;
        dataLogPoints = unit->dataLogPoints;
        if (dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
        {
            logStats = unit->loggingStats;
            //----------------------------------------------------------------
            // Initialize and prepare
            //----------------------------------------------------------------
            String ^pressureValueString = String::Format(
                QCOM_PrecisionFormatString,
                QCOM_GetPressureValue(unit, QCOM_DefaultPressureUnits));
            String ^temperatureValueString = String::Format(
                QCOM_PrecisionFormatString,
                QCOM_GetTemperatureValue(unit, QCOM_DefaultTemperatureUnits));
            String ^valueString;
            unit->dataLogLine->Clear();
            unit->dataLogDisplay->Clear();
            //----------------------------------------------------------------
            // Populate the display line
            //----------------------------------------------------------------
            if (dataLogFlags & QCOM_UNIT_LOG_PREPEND_ENTRY_NUMBERS)
            {
                if (logStats && logStats->numberOfSamples)
                {
                    valueString = String::Format(
                        "{0:D6}", logStats->numberOfSamples);
                    unit->dataLogLine->Append(valueString);
                    unit->dataLogDisplay->Append(valueString)->Append(' ', standardSpacing);
                    previousFieldPresent = GUI_YES;
                }
                //------------------------------------------------------------
                // Update the data log caption at magnitude-order boundaries
                //------------------------------------------------------------
                if ((logStats->numberOfSamples == 10000) || (logStats->numberOfSamples == 100000) ||
                    (logStats->numberOfSamples == 1000000) || (logStats->numberOfSamples == 10000000) ||
                    (logStats->numberOfSamples == 100000000))
                    QCOM_LogUnitUpdateCaptions(unit);
            }
            if (dataLogPoints & QCOM_UNIT_LOG_DATE_STAMP)
            {
                if (previousFieldPresent)
                {
                    unit->dataLogLine->Append(QCOM_STRING_DSPACE);
                    unit->dataLogDisplay->Append(QCOM_STRING_SPACE);
                }
                valueString = String::Format(
                    "{0:D2} {1} {2:D}",
                    dateTime.Day,
                    QCOM_MonthStringArray[dateTime.Month],
                    dateTime.Year);
                    unit->dataLogLine->Append(valueString);
                    unit->dataLogDisplay->Append(valueString)->Append(' ', standardSpacing);
                previousFieldPresent = GUI_YES;
            }
            if (dataLogPoints & QCOM_UNIT_LOG_TIME_STAMP)
            {
                if (previousFieldPresent)
                {
                    unit->dataLogLine->Append(QCOM_STRING_DSPACE);
                    unit->dataLogDisplay->Append(QCOM_STRING_SPACE);
                }
                valueString = String::Format(
                    "{0:D2}:{1:D2}:{2:D2}",
                    dateTime.Hour,
                    dateTime.Minute,
                    dateTime.Second);
                unit->dataLogLine->Append(valueString);
                unit->dataLogDisplay->Append(valueString);
                if (dataLogFlags & QCOM_UNIT_LOG_TIME_MS)
                {
                    valueString = String::Format(
                        "{0:D3}", dateTime.Millisecond);
                    unit->dataLogLine->Append(QCOM_STRING_DOT)->Append(valueString);
                    unit->dataLogDisplay->Append(QCOM_STRING_DOT)->Append(valueString);
                }
                unit->dataLogDisplay->Append(' ', standardSpacing);
                previousFieldPresent = GUI_YES;
            }
            if (dataLogPoints & QCOM_UNIT_LOG_PRESSURE_DEF)
            {
                if (previousFieldPresent)
                {
                    unit->dataLogLine->Append(QCOM_STRING_SPACE);
                }
                unit->dataLogLine->Append(pressureValueString);
                unit->dataLogDisplay->Append(pressureValueString)->Append(' ', standardSpacing);
                previousFieldPresent = GUI_YES;
            }
            if (dataLogPoints & QCOM_UNIT_LOG_PRESSURE_ALT)
            {
                if (previousFieldPresent)
                {
                    unit->dataLogLine->Append(QCOM_STRING_SPACE);
                }
                valueString = String::Format(
                    QCOM_PrecisionFormatString,
                    QCOM_GetPressureValue(unit, QCOM_AlternatePressureUnits));
                unit->dataLogLine->Append(valueString);
                unit->dataLogDisplay->Append(valueString)->Append(' ', standardSpacing);
                previousFieldPresent = GUI_YES;
            }
            if (dataLogPoints & QCOM_UNIT_LOG_TEMP_DEF)
            {
                if (previousFieldPresent)
                {
                    unit->dataLogLine->Append(QCOM_STRING_SPACE);
                }
                unit->dataLogLine->Append(temperatureValueString);
                unit->dataLogDisplay->Append(temperatureValueString)->Append(' ', standardSpacing);
                previousFieldPresent = GUI_YES;
            }
            if (dataLogPoints & QCOM_UNIT_LOG_TEMP_ALT)
            {
                if (previousFieldPresent)
                {
                    unit->dataLogLine->Append(QCOM_STRING_SPACE);
                }
                valueString = String::Format(
                    QCOM_PrecisionFormatString,
                    QCOM_GetTemperatureValue(unit, QCOM_AlternateTemperatureUnits));
                unit->dataLogLine->Append(valueString);
                unit->dataLogDisplay->Append(valueString)->Append(' ', standardSpacing);
                previousFieldPresent = GUI_YES;
            }
            if (dataLogPoints & QCOM_UNIT_LOG_PRESSURE_COUNT)
            {
                if (previousFieldPresent)
                {
                    unit->dataLogLine->Append(QCOM_STRING_SPACE);
                }
                if (unit->dataLogFlags & QCOM_UNIT_LOG_DISPLAY_COUNTS_IN_HEX)
                    valueString = String::Format("0x{0:X8}", unit->pressureCount);
                else
                    valueString = String::Format("{0:D}", unit->pressureCount);
                unit->dataLogLine->Append(valueString);
                unit->dataLogDisplay->Append(valueString)->Append(' ', standardSpacing);
                previousFieldPresent = GUI_YES;
            }
            if (dataLogPoints & QCOM_UNIT_LOG_TEMP_COUNT)
            {
                if (previousFieldPresent)
                {
                    unit->dataLogLine->Append(QCOM_STRING_SPACE);
                }
                if (unit->dataLogFlags & QCOM_UNIT_LOG_DISPLAY_COUNTS_IN_HEX)
                    valueString = String::Format("0x{0:X8}", unit->temperatureCount);
                else
                    valueString = String::Format("{0:D}", unit->temperatureCount);
                unit->dataLogLine->Append(valueString);
                unit->dataLogDisplay->Append(valueString)->Append(' ', standardSpacing);
                previousFieldPresent = GUI_YES;
            }
            if (dataLogPoints & QCOM_UNIT_LOG_PRESSURE_FREQUENCY)
            {
                if (previousFieldPresent)
                {
                    unit->dataLogLine->Append(QCOM_STRING_SPACE);
                }
                valueString = String::Format(
                    "{0:F3}",
                    (((double) unit->pressureCount) * QCOM_FREQUENCY_MULTIPLIER));
                unit->dataLogLine->Append(valueString);
                unit->dataLogDisplay->Append(valueString)->Append(' ', standardSpacing);
                previousFieldPresent = GUI_YES;
            }
            if (dataLogPoints & QCOM_UNIT_LOG_TEMP_FREQUENCY)
            {
                if (previousFieldPresent)
                {
                    unit->dataLogLine->Append(QCOM_STRING_SPACE);
                }
                valueString = String::Format(
                    "{0:F3}",
                    (((double) unit->temperatureCount) * QCOM_FREQUENCY_MULTIPLIER));
                unit->dataLogLine->Append(valueString);
                unit->dataLogDisplay->Append(valueString)->Append(' ', standardSpacing);
                previousFieldPresent = GUI_YES;
            }
            if (dataLogPoints & QCOM_UNIT_LOG_XD_VOLTAGE)
            {
                if (previousFieldPresent)
                {
                    unit->dataLogLine->Append(QCOM_STRING_SPACE);
                }
                valueString = String::Format("{0:F2}", unit->transducerVoltage);
                unit->dataLogLine->Append(valueString);
                unit->dataLogDisplay->Append(valueString)->Append(' ', standardSpacing);
                previousFieldPresent = GUI_YES;
            }
            if (dataLogPoints & QCOM_UNIT_LOG_XD_AMPERAGE)
            {
                if (previousFieldPresent)
                {
                    unit->dataLogLine->Append(QCOM_STRING_SPACE);
                }
                valueString = String::Format("{0:F2}", unit->transducerAmperage);
                unit->dataLogLine->Append(valueString);
                unit->dataLogDisplay->Append(valueString)->Append(' ', standardSpacing);
                previousFieldPresent = GUI_YES;
            }
            delete valueString;
            delete temperatureValueString;
            delete pressureValueString;
            QCOM_LogUnitUpdateDataLog(unit, GUI_LOG_ACTION_APPEND_NEWLINE);
        }                               // end of if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_LogUnitDataSample()
//----------------------------------------------------------------------------
// QCOM_LogUnitDetermineDataLogFilePaths
//
// Constructs or detemines the pathnames of the data log and snapshot log
// files for the specified unit
//
// Called by:   QCOM_InitializeUserInterface
//              QCOM_ReInitializeUserInterface
//              QCOM_SelectDataLogFile
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitDetermineDataLogFilePaths(
    UnitInfo        ^unit)
{
    bool            fileNameIdentified = GUI_NO;
    bool            keepLooking = GUI_YES;
    int             fileInstance = 1;
    DWORD           unitNumber;
    DateTime        dateTime = DateTime::Now;
    String          ^filePathString = QCOM_STRING_NONE;
    String          ^functionName = _T("QCOM_LogUnitDetermineDataLogFilePaths");
    //------------------------------------------------------------------------
    String ^pathCaptionString = _T("Data Log File: ");
    String ^pathAllString = filePathString;
    String ^pathUnitString = filePathString;
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (QCOM_LogFileKnown(unit) && StringSet(unit->dataLogFilePath))
        {
            filePathString = unit->dataLogFilePath;
            fileNameIdentified = GUI_YES;
        }
        else
        {
            while (keepLooking)
            {
                filePathString = String::Format(
                    "{0}\\QCOM-DataLog-{1}-{2}-{3:D2}{4:D2}{5:D2}-{6:D3}.log",
                    QCOM_GeneralInfo->logDirectory,
                    (QCOM_ModuleSNValid(unit) ?
                        unit->moduleSerialNumber : "Module"),
                    ((QCOM_XDPresent(unit) && QCOM_XDSNValid(unit)) ?
                        unit->transducerSerialNumber : "XD"),
                    (dateTime.Year % 100),
                    dateTime.Month,
                    dateTime.Day,
                    fileInstance);
                if (File::Exists(filePathString))
                {
                    fileInstance++;
                }
                else
                {
                    keepLooking = GUI_NO;
                    fileNameIdentified = GUI_YES;
                }
                if (fileInstance >= 1000)
                    keepLooking = fileNameIdentified = GUI_NO;
            }
        }                               // end of else of if (QCOM_LogFileKnown(unit) && ...)
        if (fileNameIdentified)
        {
            unit->dataLogFilePath = filePathString;
            unit->dataLogFlags |= QCOM_UNIT_LOG_FILE_SPECIFIED;
            pathAllString = QCOM_LimitFilePathStringWidth(
                filePathString,
                logAllFileLabelArray[unitNumber]->Width - QCOM_StringWidth(pathCaptionString));
            pathUnitString = QCOM_LimitFilePathStringWidth(
                filePathString,
                logUnitFileLabelArray[unitNumber]->Width - QCOM_StringWidth(pathCaptionString));
            logAllSelectFileButtonArray[unitNumber]->Text = GUI_CHANGE_DATA_LOG_FILE;
            logUnitSelectFileButtonArray[unitNumber]->Text = GUI_CHANGE_DATA_LOG_FILE;
            logAllAppendOverwriteGroupBoxArray[unitNumber]->Enabled = GUI_YES;
            logUnitAppendOverwriteGroupBoxArray[unitNumber]->Enabled = GUI_YES;
            logAllEmbedCaptionCheckArray[unitNumber]->Enabled = GUI_YES;
            logUnitEmbedCaptionCheckArray[unitNumber]->Enabled = GUI_YES;
        }
        else
        {
            pathAllString = QCOM_STRING_NONE;
            pathUnitString = QCOM_STRING_NONE;
            logAllSelectFileButtonArray[unitNumber]->Text = GUI_SELECT_DATA_LOG_FILE;
            logUnitSelectFileButtonArray[unitNumber]->Text = GUI_SELECT_DATA_LOG_FILE;
            logAllAppendOverwriteGroupBoxArray[unitNumber]->Enabled = GUI_NO;
            logUnitAppendOverwriteGroupBoxArray[unitNumber]->Enabled = GUI_NO;
            logAllEmbedCaptionCheckArray[unitNumber]->Enabled = GUI_NO;
            logUnitEmbedCaptionCheckArray[unitNumber]->Enabled = GUI_NO;
        }
        fileNameIdentified = GUI_NO;
        if (QCOM_LogSSFileKnown(unit) &&
            StringSet(unit->dataLogSnapshotFilePath))
        {
            filePathString = unit->dataLogSnapshotFilePath;
            fileNameIdentified = GUI_YES;
        }
        else
        {
            keepLooking = GUI_YES;
            fileInstance = 1;
            while (keepLooking)
            {
                filePathString = String::Format(
                    "{0}\\QCOM-SnapshotLog-{1}-{2}-{3:D2}{4:D2}{5:D2}-{6:D3}.log",
                    QCOM_GeneralInfo->logDirectory,
                    (QCOM_ModuleSNValid(unit) ?
                        unit->moduleSerialNumber : "Module"),
                    (QCOM_XDSNValid(unit) ?
                        unit->transducerSerialNumber : "XD"),
                    (dateTime.Year % 100),
                    dateTime.Month,
                    dateTime.Day,
                    fileInstance);
                if (File::Exists(filePathString))
                {
                    fileInstance++;
                }
                else
                {
                    keepLooking = GUI_NO;
                    fileNameIdentified = GUI_YES;
                }
                if (fileInstance >= 1000)
                    keepLooking = fileNameIdentified = GUI_NO;
            }
        }                               // end of else of if (QCOM_LogSSFileKnown(unit) && ...)
        if (fileNameIdentified)
        {
            unit->dataLogSnapshotFilePath = filePathString;
            unit->dataLogFlags |= QCOM_UNIT_LOG_SNAPSHOT_FILE_SPECIFIED;
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    logAllFileLabelArray[unit->unitNumber]->Text = String::Concat(
        pathCaptionString, pathAllString);
    logUnitFileLabelArray[unit->unitNumber]->Text = String::Concat(
        pathCaptionString, pathUnitString);
    delete pathUnitString;
    delete pathAllString;
    delete pathCaptionString;
}                                       // end of QCOM_LogUnitDetermineDataLogFilePaths()
//----------------------------------------------------------------------------
// QCOM_LogUnitInitializeStatistics
//
// Clears the structure of logging statistics and initializes it with starting
// values
//
// Note:    The QCOM_UNIT_LOG_DISPLAY_SUMMARY flag is not checked as a
//          condition for statistics initialization, so that correct values
//          will be available, should the summary be selected after the
//          logging has already started
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitInitializeStatistics(
    UnitInfo        ^unit)
{
    DWORD           currentTime = GetTickCount();
    String          ^functionName = _T("QCOM_LogUnitInitializeStatistics");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        unit->loggingStats->cumulative = 0;
        unit->loggingStats->numberOfSamples = 0;
        unit->loggingStats->numberOfUnsavedSamples = 0;
        unit->loggingStats->totalDefPres = 0.0;
        unit->loggingStats->totalAltPres = 0.0;
        unit->loggingStats->totalPCount = 0;
        unit->loggingStats->totalPFreq = 0.0;
        unit->loggingStats->totalDefTemp = 0.0;
        unit->loggingStats->totalAltTemp = 0.0;
        unit->loggingStats->totalTCount = 0;
        unit->loggingStats->totalTFreq = 0.0;
        unit->loggingStats->totalVoltage = 0.0;
        unit->loggingStats->totalAmperage = 0.0;
        unit->loggingStats->startTime = currentTime;
        //--------------------------------------------------------------------
        // Reset the cumulative time counter for all units each time logging
        // is started, to reflect a continuous time count
        //--------------------------------------------------------------------
        QCOM_LoggingElapsedTime = 0;
        QCOM_SamplingElapsedTime = 0;
        QCOM_LoggingStartTime = currentTime;
        QCOM_SamplingStartTime = currentTime;
    }
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_LogUnitInitializeStatistics()
//----------------------------------------------------------------------------
// QCOM_LogUnitInsertComment
//
// Inserts a comment in the data log for the specified unit
//
// Called by:   QCOM_LogAllInsertCommentButtonClicked
//              QCOM_LogUnitInsertCommentButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitInsertComment(
    UnitInfo        ^unit)
{
    DWORD           logAction = GUI_LOG_ACTION_COMMENT;
    String          ^functionName = _T("QCOM_LogUnitInsertComment");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called",
            functionName, unit->unitNumber);
        GUI_StringToBuilder(
            logUnitInsertCommentBoxArray[unit->unitNumber]->Text,
            unit->dataLogLine);
        logAction |=
            (GUI_LOG_ACTION_APPEND_NEWLINE |
            GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY);
        if (unit->dataLogFlags & QCOM_UNIT_LOG_COMMENT_TIME_STAMP)
            logAction |= GUI_LOG_ACTION_PREPEND_TIME_STAMP;
        QCOM_LogUnitUpdateDataLog(unit, logAction);
        RecordBasicEvent("{0} concluded by adding\n'{1}'",
            functionName,
            logUnitInsertCommentBoxArray[unit->unitNumber]->Text);
    }
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_LogUnitInsertComment()
//----------------------------------------------------------------------------
// QCOM_LogUnitReflectDataPresence
//
// Enable or disable data logging objects, depending on whether data is in
// the data log of the specified unit
//
// Called by:   QCOM_LogUnitUpdateDataLog
//              QCOM_UpdateGlobalObjects
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitReflectDataPresence(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_LogUnitReflectDataPresence");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // General log objects
        //--------------------------------------------------------------------
        if (QCOM_XDPresent(unit) &&
            QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DATA_PRESENT)
        {
            logAllClearButton->Enabled = GUI_YES;
            logAllSnapshotDataButton->Enabled = GUI_YES;
            readoutClearAllLogsButton->Enabled = GUI_YES;
        }
        else
        {
            logAllClearButton->Enabled = GUI_NO;
            logAllSnapshotDataButton->Enabled = GUI_NO;
            readoutClearAllLogsButton->Enabled = GUI_NO;
        }
        //--------------------------------------------------------------------
        // Unit log objects
        //--------------------------------------------------------------------
        if (QCOM_XDPresent(unit) && QCOM_LogDataPresent(unit))
        {
            logUnitClearButtonArray[unitNumber]->Enabled = GUI_YES;
            logUnitSnapshotDataButtonArray[unitNumber]->Enabled = GUI_YES;
            logAllClearButtonArray[unitNumber]->Enabled = GUI_YES;
            logAllSnapshotDataButtonArray[unitNumber]->Enabled = GUI_YES;
            readoutClearLogButtonArray[unitNumber]->Enabled = GUI_YES;
            graphingClearLogButtonArray[unitNumber]->Enabled = GUI_YES;
        }
        else
        {
            logUnitClearButtonArray[unitNumber]->Enabled = GUI_NO;
            logUnitSnapshotDataButtonArray[unitNumber]->Enabled = GUI_NO;
            logAllClearButtonArray[unitNumber]->Enabled = GUI_NO;
            logAllSnapshotDataButtonArray[unitNumber]->Enabled = GUI_NO;
            readoutClearLogButtonArray[unitNumber]->Enabled = GUI_NO;
            graphingClearLogButtonArray[unitNumber]->Enabled = GUI_NO;
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_LogUnitReflectDataPresence()
//----------------------------------------------------------------------------
// QCOM_LogUnitSaveDataLog
//
// Saves the data log of the specified unit to the specified file
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    This function only saves the data log to file if the
//          QCOM_UNIT_LOG_DATA_PRESENT flag is set, whether the
//          QCOM_UNIT_LOG_DATA_UNSAVED flag is set or not
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_LogUnitSaveDataLog(
    UnitInfo        ^unit,
    String          ^pathString)
{
    DWORD           status = QCOM_SUCCESS;
    StreamWriter    ^textWriter;
    String          ^dataLogContents;
    String          ^formattedContents;
    String          ^theOtherFile;
    String          ^functionName = _T("QCOM_LogUnitSaveDataLog");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordVerboseEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (String::IsNullOrEmpty(pathString))
            pathString = unit->dataLogFilePath;
        if (QCOM_LogDataPresent(unit))
        {
            dataLogContents = unit->dataLog->ToString();
            if ((unit->dataLogFlags & QCOM_UNIT_LOG_FILE_APPEND) &&
                !(unit->dataLogFlags & QCOM_UNIT_LOG_SNAPSHOT_APPEND_OVERRIDE))
                textWriter = File::AppendText(pathString);
            else
                textWriter = File::CreateText(pathString);
            if (textWriter)
            {
                if (pathString->ToLower()->EndsWith(".csv"))
                {
                    theOtherFile = pathString->Replace(Path::GetExtension(pathString), ".log");
                    formattedContents = QCOM_ConvertLogDataToCSV(dataLogContents);
                }
                else
                {
                    theOtherFile = pathString->Replace(Path::GetExtension(pathString), ".csv");
                    formattedContents = dataLogContents;
                    //--------------------------------------------------------
                    // Remove extraneous CR/LF at the end of the log
                    //--------------------------------------------------------
                    if ((formattedContents->Length >= 2) &&
                        formattedContents->EndsWith(QCOM_STRING_CRLF))
                    {
                        formattedContents = formattedContents->Substring(
                            0, formattedContents->LastIndexOf(QCOM_STRING_CRLF));
                    }
                }
                //------------------------------------------------------------
                // Write out the entire log in one transfer
                //------------------------------------------------------------
                textWriter->WriteLine(formattedContents);
                textWriter->Close();
                RecordVerboseEvent(
                    "    Plain text data log for transducer {0} saved successfully:\n{1}",
                    unit->transducerSerialNumber,
                    pathString);
                if ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_FILE_BOTH_FORMATS) &&
                    StringSet(theOtherFile))
                {
                    //--------------------------------------------------------
                    // Both CSV and Text file formats are selected
                    //--------------------------------------------------------
                    if ((unit->dataLogFlags & QCOM_UNIT_LOG_FILE_APPEND) &&
                        !(unit->dataLogFlags & QCOM_UNIT_LOG_SNAPSHOT_APPEND_OVERRIDE))
                        textWriter = File::AppendText(theOtherFile);
                    else
                        textWriter = File::CreateText(theOtherFile);
                    if (textWriter)
                    {
                        if (theOtherFile->ToLower()->EndsWith(".csv"))
                        {
                            formattedContents = QCOM_ConvertLogDataToCSV(dataLogContents);
                        }
                        else
                        {
                            if ((dataLogContents->Length >= 2) &&
                                dataLogContents->EndsWith(QCOM_STRING_CRLF))
                            {
                                dataLogContents = dataLogContents->Substring(0, dataLogContents->LastIndexOf(QCOM_STRING_CRLF));
                                formattedContents = unit->dataLog->ToString();
                            }
                            else
                            {
                                formattedContents = dataLogContents;
                            }
                        }
                        textWriter->WriteLine(formattedContents);
                        textWriter->Close();
                        QCOM_UpdateDeleteLogFilesDropDown();
                        RecordVerboseEvent(
                            "    CSV data log for transducer {0} saved successfully:\n{1}",
                            unit->transducerSerialNumber,
                            theOtherFile);
                        delete formattedContents;
                        delete theOtherFile;
                        delete textWriter;
                    }
                }                       // end of if ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_FILE_BOTH_FORMATS) && ...)
                unit->loggingStats->numberOfUnsavedSamples = 0;
            }
            else
            {
                RecordErrorEvent("    File cannot be opened for writing:\n{0}",
                    pathString);
                status = QD_ERROR_FILE_OPEN_FAILURE;                            // 0x0015
            }
            delete dataLogContents;
        }                               // end of if (QCOM_LogDataPresent(unit))
        else
        {
            RecordVerboseEvent("    No data present for transducer {0} to save",
                unit->transducerSerialNumber);
        }
        RecordVerboseEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return status;
}                                       // end of QCOM_LogUnitSaveDataLog()
//----------------------------------------------------------------------------
// QCOM_LogUnitSaveDataLogLine
//
// Saves the data log line of the specified unit to the main log file
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    This function only saves the data log to file if the
//          QCOM_UNIT_LOG_DATA_PRESENT flag is set, whether the
//          QCOM_UNIT_LOG_DATA_UNSAVED flag is set or not
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_LogUnitSaveDataLogLine(
    UnitInfo        ^unit)
{
    DWORD           status = QCOM_SUCCESS;
    StreamWriter    ^textWriter;
    String          ^dataLogContents;
    String          ^formattedContents;
    String          ^pathString;
    String          ^theOtherFile;
    String          ^functionName = _T("QCOM_LogUnitSaveDataLogLine");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        pathString = unit->dataLogFilePath;
        if (QCOM_LogDataPresent(unit))
        {
            dataLogContents = unit->dataLogLine->ToString();
            textWriter = File::AppendText(pathString);
            if (textWriter)
            {
                if (pathString->ToLower()->EndsWith(".csv"))
                {
                    theOtherFile = pathString->Replace(Path::GetExtension(pathString), ".log");
                    formattedContents = QCOM_ConvertLogDataToCSV(dataLogContents);
                }
                else
                {
                    theOtherFile = pathString->Replace(Path::GetExtension(pathString), ".csv");
                    formattedContents = dataLogContents;
                    //--------------------------------------------------------
                    // Remove extraneous CR/LF at the end of the log
                    //--------------------------------------------------------
                    if ((formattedContents->Length >= 2) &&
                        formattedContents->EndsWith(QCOM_STRING_CRLF))
                    {
                        formattedContents = formattedContents->Substring(
                            0, formattedContents->LastIndexOf(QCOM_STRING_CRLF));
                    }
                }
                //------------------------------------------------------------
                // Write out the entire log in one transfer
                //------------------------------------------------------------
                textWriter->WriteLine(formattedContents);
                textWriter->Close();
                if ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_FILE_BOTH_FORMATS) &&
                    StringSet(theOtherFile))
                {
                    //--------------------------------------------------------
                    // Both CSV and Text file formats are selected
                    //--------------------------------------------------------
                    textWriter = File::AppendText(theOtherFile);
                    if (textWriter)
                    {
                        if (theOtherFile->ToLower()->EndsWith(".csv"))
                        {
                            formattedContents = QCOM_ConvertLogDataToCSV(dataLogContents);
                        }
                        else
                        {
                            if ((dataLogContents->Length >= 2) &&
                                dataLogContents->EndsWith(QCOM_STRING_CRLF))
                            {
                                dataLogContents = dataLogContents->Substring(0, dataLogContents->LastIndexOf(QCOM_STRING_CRLF));
                                formattedContents = unit->dataLogLine->ToString();
                            }
                            else
                            {
                                formattedContents = dataLogContents;
                            }
                        }
                        textWriter->WriteLine(formattedContents);
                        textWriter->Close();
                        delete formattedContents;
                        delete theOtherFile;
                        delete textWriter;
                    }
                }                       // end of if ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_FILE_BOTH_FORMATS) && ...)
                unit->loggingStats->numberOfUnsavedSamples = 0;
            }
            else
            {
                RecordErrorEvent("{0} : File cannot be opened for writing:\n{1}",
                    functionName, pathString);
                status = QD_ERROR_FILE_OPEN_FAILURE;                            // 0x0015
            }
            delete dataLogContents;
        }                               // end of if (QCOM_LogDataPresent(unit))
        else
        {
            RecordVerboseEvent("{0} : No data present for transducer {1} to save",
                functionName, unit->transducerSerialNumber);
        }
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return status;
}                                       // end of QCOM_LogUnitSaveDataLogLine()
//----------------------------------------------------------------------------
// QCOM_LogUnitSnapshotData
//
// Saves a snapshot of the logged data currently in memory
//
// Called by:   QCOM_LogUnitSnapshotDataButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitSnapshotData(
    UnitInfo        ^unit)
{
    bool            transferResult;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_LogUnitSnapshotDataButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        if (unit->dataLogFlags & QCOM_UNIT_LOG_FILE_AUTO_SAVE)
        {
            bool spinLockAcquired = GUI_NO;
            try
            {
                QCOM_LogSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                transferResult = QCOM_TransferDataLogToFile(
                    unit,
                    GUI_SNAPSHOT_LOG);
            }                           // end of try
            finally
            {
                if (spinLockAcquired == GUI_YES)
                    QCOM_LogSpinLockArray[unitNumber]->Exit();
            }
            if (transferResult == GUI_ACCEPT)
            {
                RecordVerboseEvent(
                    "    Data log for transducer {0} saved to file\n{1}",
                    unit->transducerSerialNumber,
                    unit->dataLogSnapshotFilePath);
            }
        }
        else
        {
            QCOM_SelectDataLogFile(unit);
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_LogUnitSnapshotData()
//----------------------------------------------------------------------------
// QCOM_LogUnitUpdateCaptions
//
// Updates the caption to the data log text box, to reflect which fields are
// being displayed
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitUpdateCaptions(
    UnitInfo        ^unit)
{
    bool            displayInHex;
    int             appendSpaces = 0;
    int             prependSpaces = 1;
    DWORD           dataLogFlags;
    DWORD           dataLogPoints;
    StringBuilder   ^captionBuilder;
    String          ^caption;
    StringBuilder   ^fileCaptionBuilder;
    LoggingStatsInfo
                    ^logStats;
    String          ^functionName = _T("QCOM_LogUnitUpdateCaptions");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        dataLogFlags = unit->dataLogFlags;
        dataLogPoints = unit->dataLogPoints;
        logStats = unit->loggingStats;
        displayInHex = (dataLogFlags & QCOM_UNIT_LOG_DISPLAY_COUNTS_IN_HEX) ? GUI_YES : GUI_NO;
        captionBuilder = gcnew StringBuilder(GUI_MAXIMUM_LOG_CAPTION_SIZE);
        if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            fileCaptionBuilder = gcnew StringBuilder(GUI_MAXIMUM_LOG_CAPTION_SIZE);
        if (dataLogFlags & QCOM_UNIT_LOG_PREPEND_ENTRY_NUMBERS)
        {
            caption = _T("Entry");
            if (logStats->numberOfSamples < 1000000)
                captionBuilder->Append(' ', 3);
            else
                if (logStats->numberOfSamples < 10000000)
                    captionBuilder->Append(' ', 4);
                else
                    if (logStats->numberOfSamples < 100000000)
                        captionBuilder->Append(' ', 5);
                    else
                        captionBuilder->Append(' ', 6);
            captionBuilder->Append(caption)->Append(' ', 4);
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            {
                if (logStats->numberOfSamples < 10000)
                    fileCaptionBuilder->Append(' ', 0);
                else
                    if (logStats->numberOfSamples < 100000)
                        fileCaptionBuilder->Append(' ', 1);
                    else
                        if (logStats->numberOfSamples < 1000000)
                            fileCaptionBuilder->Append(' ', 2);
                        else
                            if (logStats->numberOfSamples < 10000000)
                                fileCaptionBuilder->Append(' ', 3);
                            else
                                if (logStats->numberOfSamples < 100000000)
                                    fileCaptionBuilder->Append(' ', 4);
                                else
                                    fileCaptionBuilder->Append(' ', 5);
                fileCaptionBuilder->Append(caption)->Append(' ', 4);
            }
        }
        if (dataLogPoints & QCOM_UNIT_LOG_DATE_STAMP)
        {
            caption = _T("Date");
            captionBuilder->Append(' ', 6)->Append(caption)->Append(' ', 9);
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            {
                fileCaptionBuilder->Append(' ', 3)->Append(caption)->Append(' ', 4);
            }
        }
        if (dataLogPoints & QCOM_UNIT_LOG_TIME_STAMP)
        {
            caption = _T("Time");
            if (dataLogFlags & QCOM_UNIT_LOG_TIME_MS)
                captionBuilder->Append(' ', 9)->Append(caption)->Append(' ', 10);
            else
                captionBuilder->Append(' ', 6)->Append(caption)->Append(' ', 6);
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            {
                if (dataLogFlags & QCOM_UNIT_LOG_TIME_MS)
                    fileCaptionBuilder->Append(' ', 6)->Append(caption)->Append(' ', 4);
                else
                    fileCaptionBuilder->Append(' ', 4)->Append(caption)->Append(' ', 2);
            }
        }
        if (dataLogPoints & QCOM_UNIT_LOG_PRESSURE_DEF)
        {
            caption = QCOM_PressureUnitsStringArray[QCOM_DefaultPressureUnits];
            QCOM_BuildDoubleDisplayCaptionString(
                caption,
                QCOM_GetPressureValue(unit, QCOM_DefaultPressureUnits),
                (int) QCOM_CurrentPrecision,
                1, 2,
                captionBuilder);
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            {
                QCOM_FormatFileCaptionText(
                    caption,
                    QCOM_GetPressureValue(unit, QCOM_DefaultPressureUnits),
                    (int) QCOM_CurrentPrecision,
                    fileCaptionBuilder);
            }
        }
        if (dataLogPoints & QCOM_UNIT_LOG_PRESSURE_ALT)
        {
            caption = QCOM_PressureUnitsStringArray[QCOM_AlternatePressureUnits];
            QCOM_BuildDoubleDisplayCaptionString(
                caption,
                QCOM_GetPressureValue(unit, QCOM_AlternatePressureUnits),
                (int) QCOM_CurrentPrecision,
                2, 2,
                captionBuilder);
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            {
                QCOM_FormatFileCaptionText(
                    caption,
                    QCOM_GetPressureValue(unit, QCOM_AlternatePressureUnits),
                    (int) QCOM_CurrentPrecision,
                    fileCaptionBuilder);
            }
        }
        if (dataLogPoints & QCOM_UNIT_LOG_TEMP_DEF)
        {
            caption = QCOM_TemperatureUnitsStringArray[QCOM_DefaultTemperatureUnits];
            QCOM_BuildDoubleDisplayCaptionString(
                caption,
                QCOM_GetTemperatureValue(unit, QCOM_DefaultTemperatureUnits),
                (int) QCOM_CurrentPrecision,
                1, 3,
                captionBuilder);
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            {
                QCOM_FormatFileCaptionText(
                    caption,
                    QCOM_GetTemperatureValue(unit, QCOM_DefaultTemperatureUnits),
                    (int) QCOM_CurrentPrecision,
                    fileCaptionBuilder);
            }
        }
        if (dataLogPoints & QCOM_UNIT_LOG_TEMP_ALT)
        {
            caption = QCOM_TemperatureUnitsStringArray[QCOM_AlternateTemperatureUnits];
            QCOM_BuildDoubleDisplayCaptionString(
                caption,
                QCOM_GetTemperatureValue(unit, QCOM_AlternateTemperatureUnits),
                (int) QCOM_CurrentPrecision,
                1, 2,
                captionBuilder);
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            {
                QCOM_FormatFileCaptionText(
                    caption,
                    QCOM_GetTemperatureValue(unit, QCOM_AlternateTemperatureUnits),
                    (int) QCOM_CurrentPrecision,
                    fileCaptionBuilder);
            }
        }
        if (dataLogPoints & QCOM_UNIT_LOG_PRESSURE_COUNT)
        {
            caption = _T("P-Count");
            QCOM_BuildIntegerDisplayCaptionString(
                caption,
                (int) unit->pressureCount,
                displayInHex,
                (displayInHex ? 4 : 2),
                2,
                captionBuilder);
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
                fileCaptionBuilder->Append(' ', 2)->Append(caption);
        }
        if (dataLogPoints & QCOM_UNIT_LOG_TEMP_COUNT)
        {
            caption = _T("T-Count");
            QCOM_BuildIntegerDisplayCaptionString(
                caption,
                (int) unit->temperatureCount,
                displayInHex,
                (displayInHex ? 4 : 2),
                2,
                captionBuilder);
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
                fileCaptionBuilder->Append(' ', 2)->Append(caption);
        }
        if (dataLogPoints & QCOM_UNIT_LOG_PRESSURE_FREQUENCY)
        {
            caption = _T("P-Freq");
            QCOM_BuildDoubleDisplayCaptionString(
                caption,
                (((double) unit->pressureCount) * QCOM_FREQUENCY_MULTIPLIER),
                GUI_DEFAULT_FREQUENCY_DECIMAL_POINTS,
                1, 1,
                captionBuilder);
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            {
                QCOM_FormatFileCaptionText(
                    caption,
                    (((double) unit->pressureCount) * QCOM_FREQUENCY_MULTIPLIER),
                    GUI_DEFAULT_FREQUENCY_DECIMAL_POINTS,
                    fileCaptionBuilder);
            }
        }
        if (dataLogPoints & QCOM_UNIT_LOG_TEMP_FREQUENCY)
        {
            caption = _T("T-Freq");
            QCOM_BuildDoubleDisplayCaptionString(
                caption,
                (((double) unit->temperatureCount) * QCOM_FREQUENCY_MULTIPLIER),
                GUI_DEFAULT_FREQUENCY_DECIMAL_POINTS,
                1, 1,
                captionBuilder);
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            {
                QCOM_FormatFileCaptionText(
                    caption,
                    (((double) unit->temperatureCount) * QCOM_FREQUENCY_MULTIPLIER),
                    GUI_DEFAULT_FREQUENCY_DECIMAL_POINTS,
                    fileCaptionBuilder);
            }
        }
        if (dataLogPoints & QCOM_UNIT_LOG_XD_VOLTAGE)
        {
            caption = _T("Volts");
            QCOM_BuildDoubleDisplayCaptionString(
                caption,
                unit->transducerVoltage,
                GUI_DEFAULT_VI_DECIMAL_POINTS,
                3, 1,
                captionBuilder);
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            {
                QCOM_FormatFileCaptionText(
                    caption,
                    unit->transducerVoltage,
                    GUI_DEFAULT_VI_DECIMAL_POINTS,
                    fileCaptionBuilder);
            }
        }
        if (dataLogPoints & QCOM_UNIT_LOG_XD_AMPERAGE)
        {
            caption = QCOM_AmperageUnitsStringArray[QCOM_AMPERAGE_UNITS_DEFAULT];
            QCOM_BuildDoubleDisplayCaptionString(
                caption,
                unit->transducerAmperage,
                GUI_DEFAULT_VI_DECIMAL_POINTS,
                2, 2,
                captionBuilder);
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            {
                QCOM_FormatFileCaptionText(
                    caption,
                    unit->transducerAmperage,
                    GUI_DEFAULT_VI_DECIMAL_POINTS,
                    fileCaptionBuilder);
            }
        }
        String ^formattedString = captionBuilder->ToString();
        logUnitCaptionLabelArray[unit->unitNumber]->Text = formattedString;
        logAllCaptionLabelArray[unit->unitNumber]->Text = formattedString;
        if (dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
        {
            if (dataLogFlags & QCOM_UNIT_LOG_DISPLAY_CAPTION_IN_LOG)
            {
                logUnitBoxArray[unit->unitNumber]->AppendText(String::Concat(
                    formattedString, Environment::NewLine));
                logAllBoxArray[unit->unitNumber]->AppendText(String::Concat(
                    formattedString, Environment::NewLine));
            }
            if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            {
                String ^dataLogLine = fileCaptionBuilder->ToString();
                GUI_StringToBuilder(dataLogLine, unit->dataLogLine);
                QCOM_LogUnitUpdateDataLog(
                    unit,
                    (GUI_LOG_ACTION_FILE_ONLY | GUI_LOG_ACTION_APPEND_NEWLINE));
                delete dataLogLine;
            }
        }
        delete formattedString;
        if (dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
            delete fileCaptionBuilder;
        delete captionBuilder;
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_LogUnitUpdateCaptions()
//----------------------------------------------------------------------------
// QCOM_LogUnitUpdateChecks
//
// Updates the check marks in the data log window
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitUpdateChecks(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_LogUnitUpdateChecks");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        //--------------------------------------------------------------------
        // Entry numbers
        //--------------------------------------------------------------------
        if (unit->dataLogFlags & QCOM_UNIT_LOG_PREPEND_ENTRY_NUMBERS)
            logUnitPrependEntryNumbersCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitPrependEntryNumbersCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Date Stamp
        //--------------------------------------------------------------------
        if (unit->dataLogPoints & QCOM_UNIT_LOG_DATE_STAMP)
            logUnitDateStampCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitDateStampCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Time Stamp
        //--------------------------------------------------------------------
        if (unit->dataLogPoints & QCOM_UNIT_LOG_TIME_STAMP)
            logUnitTimeStampLogCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitTimeStampLogCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Time Stamp Milliseconds
        //--------------------------------------------------------------------
        if (unit->dataLogFlags & QCOM_UNIT_LOG_TIME_MS)
            logUnitMillisecondsCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitMillisecondsCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Pressure in default units
        //--------------------------------------------------------------------
        if (unit->dataLogPoints & QCOM_UNIT_LOG_PRESSURE_DEF)
            logUnitDefPressureCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitDefPressureCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Pressure in alternate units
        //--------------------------------------------------------------------
        if (unit->dataLogPoints & QCOM_UNIT_LOG_PRESSURE_ALT)
            logUnitAltPressureCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitAltPressureCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Temperature in default units
        //--------------------------------------------------------------------
        if (unit->dataLogPoints & QCOM_UNIT_LOG_TEMP_DEF)
            logUnitDefTemperatureCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitDefTemperatureCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Temperature in alternate units
        //--------------------------------------------------------------------
        if (unit->dataLogPoints & QCOM_UNIT_LOG_TEMP_ALT)
            logUnitAltTemperatureCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitAltTemperatureCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Pressure Count
        //--------------------------------------------------------------------
        if (unit->dataLogPoints & QCOM_UNIT_LOG_PRESSURE_COUNT)
            logUnitPressureCountCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitPressureCountCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Temperature Count
        //--------------------------------------------------------------------
        if (unit->dataLogPoints & QCOM_UNIT_LOG_TEMP_COUNT)
            logUnitTemperatureCountCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitTemperatureCountCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Pressure Frequency
        //--------------------------------------------------------------------
        if (unit->dataLogPoints & QCOM_UNIT_LOG_PRESSURE_FREQUENCY)
            logUnitPressureFrequencyCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitPressureFrequencyCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Temperature Frequency
        //--------------------------------------------------------------------
        if (unit->dataLogPoints & QCOM_UNIT_LOG_TEMP_FREQUENCY)
            logUnitTemperatureFrequencyCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitTemperatureFrequencyCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Transducer Voltage
        //--------------------------------------------------------------------
        if (unit->dataLogPoints & QCOM_UNIT_LOG_XD_VOLTAGE)
            logUnitTransducerVoltageCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitTransducerVoltageCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Transducer Amperage
        //--------------------------------------------------------------------
        if (unit->dataLogPoints & QCOM_UNIT_LOG_XD_AMPERAGE)
            logUnitTransducerAmperageCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitTransducerAmperageCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // All possible data points
        //--------------------------------------------------------------------
        if ((unit->dataLogPoints & QCOM_UNIT_LOG_ALL_POINTS) == QCOM_UNIT_LOG_ALL_POINTS)
        {
            logUnitAllCheckArray[unitNumber]->Checked = GUI_YES;
            logUnitDefaultsCheckArray[unitNumber]->Checked = GUI_NO;
        }
        else
        {
            logUnitAllCheckArray[unitNumber]->Checked = GUI_NO;
            //----------------------------------------------------------------
            // Default data points
            //----------------------------------------------------------------
            if ((unit->dataLogPoints & QCOM_UNIT_LOG_ALL_POINTS) == QCOM_UNIT_LOG_DEFAULT_DATA_POINTS)
            {
                if (unit->dataLogFlags & QCOM_UNIT_LOG_TIME_MS)
                    logUnitDefaultsCheckArray[unitNumber]->Checked = GUI_NO;
                else
                    logUnitDefaultsCheckArray[unitNumber]->Checked = GUI_YES;
            }
            else
            {
                logUnitDefaultsCheckArray[unitNumber]->Checked = GUI_NO;
            }
        }
        //--------------------------------------------------------------------
        // Counts in hex
        //--------------------------------------------------------------------
        if (unit->dataLogFlags & QCOM_UNIT_LOG_DISPLAY_COUNTS_IN_HEX)
            logUnitCountsInHexCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitCountsInHexCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Display summary
        //--------------------------------------------------------------------
        if (unit->dataLogFlags & QCOM_UNIT_LOG_DISPLAY_SUMMARY)
            logUnitDisplaySummaryCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitDisplaySummaryCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Display wrap
        //--------------------------------------------------------------------
        if (unit->dataLogFlags & QCOM_UNIT_LOG_DISPLAY_WRAP)
            logUnitDisplayWrapCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitDisplayWrapCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Log using both file formats
        //--------------------------------------------------------------------
        if (unit->dataLogFlags & QCOM_UNIT_LOG_FILE_BOTH_FORMATS)
        {
            logUnitBothFileFormatsCheckArray[unitNumber]->Checked = GUI_YES;
            graphingBothFileFormatsCheckArray[unitNumber]->Checked = GUI_YES;
        }
        else
        {
            logUnitBothFileFormatsCheckArray[unitNumber]->Checked = GUI_NO;
            graphingBothFileFormatsCheckArray[unitNumber]->Checked = GUI_NO;
        }
        //--------------------------------------------------------------------
        // Save logged data immediately
        //--------------------------------------------------------------------
        if (unit->dataLogFlags & QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY)
            logUnitSaveLoggedDataImmediatelyCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitSaveLoggedDataImmediatelyCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Caption in Log
        //--------------------------------------------------------------------
        if (unit->dataLogFlags & QCOM_UNIT_LOG_DISPLAY_CAPTION_IN_LOG)
        {
            logUnitDisplayCaptionAllCheckArray[unitNumber]->Checked = GUI_YES;
            logAllDisplayCaptionCheckArray[unitNumber]->Checked = GUI_YES;
        }
        else
        {
            logUnitDisplayCaptionAllCheckArray[unitNumber]->Checked = GUI_NO;
            logAllDisplayCaptionCheckArray[unitNumber]->Checked = GUI_NO;
        }
        //--------------------------------------------------------------------
        // Caption in File
        //--------------------------------------------------------------------
        if (unit->dataLogFlags & QCOM_UNIT_LOG_FILE_EMBED_CAPTION)
        {
            logAllEmbedCaptionCheckArray[unitNumber]->Checked = GUI_YES;
            logUnitEmbedCaptionCheckArray[unitNumber]->Checked = GUI_YES;
        }
        else
        {
            logAllEmbedCaptionCheckArray[unitNumber]->Checked = GUI_NO;
            logUnitEmbedCaptionCheckArray[unitNumber]->Checked = GUI_NO;
        }
        //--------------------------------------------------------------------
        // Append / Overwrite
        //--------------------------------------------------------------------
        if (unit->dataLogFlags & QCOM_UNIT_LOG_FILE_APPEND)
        {
            logAllAppendRadioArray[unitNumber]->Checked = GUI_YES;
            logUnitAppendRadioArray[unitNumber]->Checked = GUI_YES;
            logAllOverwriteRadioArray[unitNumber]->Checked = GUI_NO;
            logUnitOverwriteRadioArray[unitNumber]->Checked = GUI_NO;
        }
        else
        {
            logAllAppendRadioArray[unitNumber]->Checked = GUI_NO;
            logUnitAppendRadioArray[unitNumber]->Checked = GUI_NO;
            logAllOverwriteRadioArray[unitNumber]->Checked = GUI_YES;
            logUnitOverwriteRadioArray[unitNumber]->Checked = GUI_YES;
        }
        //--------------------------------------------------------------------
        // Auto-save / Prompt
        //--------------------------------------------------------------------
        if (unit->dataLogFlags & QCOM_UNIT_LOG_FILE_AUTO_SAVE)
        {
            logAllAutoSaveAllRadioArray[unitNumber]->Checked = GUI_YES;
            logUnitAutoSaveRadioArray[unitNumber]->Checked = GUI_YES;
            logAllPromptRadioArray[unitNumber]->Checked = GUI_NO;
            logUnitPromptRadioArray[unitNumber]->Checked = GUI_NO;
        }
        else
        {
            logAllAutoSaveAllRadioArray[unitNumber]->Checked = GUI_NO;
            logUnitAutoSaveRadioArray[unitNumber]->Checked = GUI_NO;
            logAllPromptRadioArray[unitNumber]->Checked = GUI_YES;
            logUnitPromptRadioArray[unitNumber]->Checked = GUI_YES;
        }
        if (unit->dataLogFlags & QCOM_UNIT_LOG_COMMENT_TIME_STAMP)
            logUnitInsertCommentTimeStampCheckArray[unitNumber]->Checked = GUI_YES;
        else
            logUnitInsertCommentTimeStampCheckArray[unitNumber]->Checked = GUI_NO;
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
    //------------------------------------------------------------------------
    // General log checks
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_COMMENTS_TIME_STAMP)
        logAllInsertCommentTimeStampCheck->Checked = GUI_YES;
    else
        logAllInsertCommentTimeStampCheck->Checked = GUI_NO;
}                                       // end of QCOM_LogUnitUpdateChecks()
//----------------------------------------------------------------------------
// QCOM_LogUnitUpdateDataLog
//
// Updates the data log and displays for both the unit transducer data log
// window and the all data log window for the specified transducer
//
// Note:    Data logging does need to be running currently in order for this
//          method to work
//
// Note:    This function runs off the sampling timer thread
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitUpdateDataLog(
    UnitInfo        ^unit,
    DWORD           actionFlags)
{
    bool            choseToSaveLog = GUI_NO;
    bool            dataStateChanged = GUI_NO;
    bool            mustEmptyDataLog = GUI_NO;
    bool            someHaveData = GUI_NO;
    bool            transferResult;
    DWORD           newDataSize = 0;
    DWORD           unitNumber;
    String          ^dataLogLine;
    String          ^functionName = _T("QCOM_LogUnitUpdateDataLog");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        dataLogLine = unit->dataLogLine->ToString();
        if (unit->dataLogFlags & QCOM_UNIT_LOG_AVAILABLE)
        {
            if (actionFlags &
                (GUI_LOG_ACTION_CLEAR_LOG |
                 GUI_LOG_ACTION_CLEAR_DISPLAY |
                 GUI_LOG_ACTION_REPLACE_DISPLAY))
            {
                //------------------------------------------------------------
                // Clear the data log and/or display
                //------------------------------------------------------------
                if (actionFlags & GUI_LOG_ACTION_CLEAR_LOG)
                {
                    //--------------------------------------------------------
                    // Clear the data log
                    //--------------------------------------------------------
                    unit->dataLog->Clear();
                    unit->dataLogRemaining = unit->dataLogSize;
                    unit->dataLogFlags &=
                        ~(QCOM_UNIT_LOG_DATA_PRESENT | QCOM_UNIT_LOG_DATA_UNSAVED);
                }
                if (actionFlags & (GUI_LOG_ACTION_CLEAR_DISPLAY | GUI_LOG_ACTION_REPLACE_DISPLAY))
                {
                    //--------------------------------------------------------
                    // Clear the display
                    //--------------------------------------------------------
                    logUnitBoxArray[unitNumber]->Clear();
                    logAllBoxArray[unitNumber]->Clear();
                    //--------------------------------------------------------
                    // Force the Garbage Collector to reclaim unreferenced
                    // memory created by managed code
                    //--------------------------------------------------------
                    GC::Collect();
                    Thread::Sleep(100);
                    //--------------------------------------------------------
                    // Then update the display with the specified display line
                    // as required
                    //--------------------------------------------------------
                    if (actionFlags & GUI_LOG_ACTION_REPLACE_DISPLAY)
                    {
                        if (actionFlags & GUI_LOG_ACTION_APPEND_NEWLINE)
                        {
                            unit->dataLogDisplay->AppendLine();
                        }
                        if (unit->dataLogDisplay->Length)
                        {
                            logUnitBoxArray[unitNumber]->AppendText(unit->dataLogDisplay->ToString());
                            logAllBoxArray[unitNumber]->AppendText(unit->dataLogDisplay->ToString());
                        }
                    }
                }
                for (DWORD moduleNumber = 0; moduleNumber < QCOM_CurrentNumberOfUnits; moduleNumber++)
                {
                    if (QCOM_UnitNumberValid(moduleNumber))
                    {
                        if (QCOM_UnitInfoArray[moduleNumber]->dataLogFlags & QCOM_UNIT_LOG_DATA_PRESENT)
                            someHaveData = GUI_YES;
                    }
                }
                if (someHaveData)
                    QCOM_GeneralInfo->logFlags |= QCOM_GENERAL_LOG_DATA_PRESENT;
                else
                    QCOM_GeneralInfo->logFlags &=
                        ~(QCOM_GENERAL_LOG_DATA_PRESENT | QCOM_GENERAL_LOG_DATA_UNSAVED);
//                unit->dataLogFlags |= QCOM_UNIT_LOG_DATA_STATE_CHANGED;
                dataStateChanged = GUI_YES;
            }                           // end of if (actionFlags & (...))
            else
            {
                //------------------------------------------------------------
                // Process the line normally by updating both the log and the
                // display
                //------------------------------------------------------------
                if (QCOM_UnitLogReady(unit))
                {
                    if (!QCOM_LogDataPresent(unit))
                        dataStateChanged = GUI_YES;
//                        unit->dataLogFlags |= QCOM_UNIT_LOG_DATA_STATE_CHANGED;
                    //--------------------------------------------------------
                    // Pre-pend the test log with the date and time stamp
                    //
                    // Note:    The GUI_LOG_ACTION_PREVENT_TIME_STAMP flag has
                    //          precedence over the other time stamp flags
                    //--------------------------------------------------------
                    if ((actionFlags & GUI_LOG_ACTION_PREPEND_TIME_STAMP) &&
                         !(actionFlags & GUI_LOG_ACTION_PREVENT_TIME_STAMP))
                    {
                        DateTime dateTime = DateTime::Now;
                        dataLogLine = String::Concat(
                            String::Format(
                                "{0:D2} {1} {2:D4} {3:D2}:{4:D2}:{5:D2} : ",
                                dateTime.Day,
                                QCOM_MonthStringArray[dateTime.Month],
                                dateTime.Year,
                                dateTime.Hour,
                                dateTime.Minute,
                                dateTime.Second),
                            dataLogLine);
                        GUI_StringToBuilder(
                            dataLogLine,
                            unit->dataLogLine);
                    }
                    //--------------------------------------------------------
                    // Mark the line if it is a comment
                    //--------------------------------------------------------
                    if (actionFlags & GUI_LOG_ACTION_COMMENT)
                    {
                        unit->dataLogLine->Insert(0, "# ");
                        if (dataLogLine->Contains(QCOM_STRING_LF))
                        {
                            unit->dataLogLine->Replace(QCOM_STRING_LF,
                                ((actionFlags & GUI_LOG_ACTION_PREPEND_TIME_STAMP) ?
                                    _T("\n#                      : ") : _T("\n# ")));
                            dataLogLine = unit->dataLogLine->ToString();
                        }
                    }
                    if (actionFlags & GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY)
                    {
                        GUI_StringToBuilder(
                            unit->dataLogLine,
//                            unit->dataLogLine->ToString(),
                            unit->dataLogDisplay);
                    }
                    //--------------------------------------------------------
                    // Append the data log and display log with a CR/LF pair
                    //--------------------------------------------------------
                    if (actionFlags & GUI_LOG_ACTION_APPEND_NEWLINE)
                    {
                        unit->dataLogLine->AppendLine();
                        unit->dataLogDisplay->AppendLine();
                    }
                    //--------------------------------------------------------
                    // Append the data log with the updated line
                    //--------------------------------------------------------
                    if (!(actionFlags & GUI_LOG_ACTION_DISPLAY_ONLY))
                    {
                        unit->dataLog->Append(unit->dataLogLine->ToString());
                        //----------------------------------------------------
                        // Update the data log remaining calculation
                        //----------------------------------------------------
                        if (unit->dataLogSize > (DWORD) unit->dataLog->Length)
                            unit->dataLogRemaining = unit->dataLogSize - unit->dataLog->Length;
                        else
                            unit->dataLogRemaining = 0;
                        unit->dataLogFlags |=
                            (QCOM_UNIT_LOG_DATA_PRESENT | QCOM_UNIT_LOG_DATA_UNSAVED);
                        QCOM_GeneralInfo->logFlags |=
                            (QCOM_GENERAL_LOG_DATA_PRESENT | QCOM_GENERAL_LOG_DATA_UNSAVED);
                        if ((unit->dataLogRemaining < QCOM_MAXIMUM_DATA_LOG_LINE_SIZE) ||
                            (unit->dataLogFlags & QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY))
                        {
                            //------------------------------------------------
                            // Test whether the available drive space on the
                            // destination drive is less than 10 MB
                            //------------------------------------------------
                            DriveInfo ^driveInfo = gcnew DriveInfo(unit->dataLogFilePath);
                            if (driveInfo->AvailableFreeSpace < 10000000)
                            {
                                bool proceedToDelete = QCOM_PromptModal(
                                    "Out of Room",
                                    "Your destination drive for unit {0:D} is almost\n"
                                    "out of file space. Delete the current data log?",
                                    unitNumber);
                                if (proceedToDelete)
                                {
                                    File::Delete(unit->dataLogFilePath);
                                    choseToSaveLog = GUI_NO;
                                    String ^companionFilePath = unit->dataLogFilePath;
                                    if (companionFilePath->EndsWith(".log"))
                                    {
                                        companionFilePath =
                                            companionFilePath->Replace(
                                                Path::GetExtension(companionFilePath), ".csv");
                                        if (File::Exists(companionFilePath))
                                            File::Delete(companionFilePath);
                                    }
                                }
                            }           // end of if (driveInfo->AvailableFreeSpace < 10000000)
                            delete driveInfo;
                            if (unit->dataLogFlags & QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY)
                            {
                                QCOM_LogUnitSaveDataLogLine(unit);
                                if (unit->dataLogRemaining < QCOM_MAXIMUM_DATA_LOG_LINE_SIZE)
                                {
                                    mustEmptyDataLog = GUI_YES;
                                    choseToSaveLog = GUI_YES;
                                    unit->dataLog->Clear();
                                    unit->dataLogRemaining = unit->dataLogSize;
                                    unit->dataLogFlags &=
                                        ~(QCOM_UNIT_LOG_DATA_PRESENT | QCOM_UNIT_LOG_DATA_UNSAVED);
                                }
                            }
                            else
                            {
                                if (unit->dataLogRemaining < QCOM_MAXIMUM_DATA_LOG_LINE_SIZE)
                                {
                                    mustEmptyDataLog = GUI_YES;
                                    if (unit->dataLogFlags & QCOM_UNIT_LOG_FILE_AUTO_SAVE)
                                    {
                                        choseToSaveLog = GUI_YES;
                                        transferResult = GUI_ACCEPT;
                                    }
                                    else
                                    {
                                        choseToSaveLog = QCOM_PromptYesNoModal(
                                            "Data Log Full",
                                            "Save", "Delete",
                                            "The data log in memory for module {0} has reached its\n"
                                            "capacity. Save the data to a file or Delete the logged data?",
                                            unit->moduleSerialNumber);
                                    }
                                    if (choseToSaveLog)
                                    {
                                        //--------------------------------------------
                                        // Protect the access to the data file by
                                        // acquiring a spin lock
                                        //--------------------------------------------
                                        bool spinLockAcquired = GUI_NO;
                                        try
                                        {
                                            QCOM_LogSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                                            transferResult = QCOM_TransferDataLogToFile(unit, GUI_MAIN_LOG);
                                        }               // end of try
                                        finally
                                        {
                                            if (spinLockAcquired == GUI_YES)
                                                QCOM_LogSpinLockArray[unitNumber]->Exit();
                                        }
                                    }   // end of if (choseToSaveLog)
                                    unit->dataLog->Clear();
                                    unit->dataLogRemaining = unit->dataLogSize;
                                    unit->dataLogFlags &=
                                        ~(QCOM_UNIT_LOG_DATA_PRESENT | QCOM_UNIT_LOG_DATA_UNSAVED);
                                }       // end of if (unit->dataLogRemaining < QCOM_MAXIMUM_DATA_LOG_LINE_SIZE)
                            }           // end of else of if (unit->dataLogFlags & QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY)
                        }               // end of if ((unit->dataLogRemaining < QCOM_MAXIMUM_DATA_LOG_LINE_SIZE) || ...)
                    }                   // end of if (!(actionFlags & GUI_LOG_ACTION_DISPLAY_ONLY))
                }                       // end of if (QCOM_UnitLogReady(unit))
                if (mustEmptyDataLog)
                {
                    //--------------------------------------------------------
                    // QCOM_StampDataLogTruncated will call QCOM_LogUnitUpdateDataLog
                    // to clear the data log display, to reflect the fact that
                    // the actual data log itself has just been cleared
                    //--------------------------------------------------------
                    QCOM_StampDataLogTruncated(unit, choseToSaveLog);
                }
                else
                {
                    if (!(actionFlags & GUI_LOG_ACTION_FILE_ONLY))
                    {
                        //----------------------------------------------------
                        // Update the displays
                        //----------------------------------------------------
                        logUnitBoxArray[unitNumber]->AppendText(unit->dataLogDisplay->ToString());
                        logAllBoxArray[unitNumber]->AppendText(unit->dataLogDisplay->ToString());
                    }
                }
            }                           // end of else of if (actionFlags & (...))
            //----------------------------------------------------------------
            // Update affected properties
            //----------------------------------------------------------------
            if (dataStateChanged)
//            if (unit->dataLogFlags & QCOM_UNIT_LOG_DATA_STATE_CHANGED)
            {
//                QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
                QCOM_LogUnitReflectDataPresence(unit);
                dataStateChanged = GUI_NO;
//                unit->dataLogFlags &= ~QCOM_UNIT_LOG_DATA_STATE_CHANGED;
            }
            //----------------------------------------------------------------
            // If Expert Mode is enabled, also update the progress bars
            //----------------------------------------------------------------
            if (QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE)
            {
                QCOM_LogUnitUpdateFullProgressBars(unit);
            }
        }                               // end of if (unit->dataLogFlags & QCOM_UNIT_LOG_AVAILABLE)
        delete dataLogLine;
        unit->dataLogLine->Clear();
        unit->dataLogDisplay->Clear();
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_LogUnitUpdateDataLog()
//----------------------------------------------------------------------------
// QCOM_LogUnitUpdateFullProgressBars
//
// Updates the data log full progress bars with the whole number percentage,
// calculated from the amount of data log consumed out of the entire data log
// size
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_LogUnitUpdateFullProgressBars(
    UnitInfo        ^unit)
{
    int             percentFull = 0;
    DWORD           dataLogConsumed = 0;
    String          ^functionName = _T("QCOM_LogUnitUpdateFullProgressBars");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        dataLogConsumed = unit->dataLogSize - unit->dataLogRemaining;
        if (unit->dataLogSize)
        {
            percentFull = QCOM_CalculatePercentage(
                dataLogConsumed,
                unit->dataLogSize);
        }
        if ((percentFull <= 100) && (dataLogConsumed <= unit->dataLogSize))
        {
            logUnitPercentFullLabelArray[unit->unitNumber]->Text =
                String::Format("{0:D}% Full", percentFull);
            logUnitPercentFullProgressArray[unit->unitNumber]->Value = percentFull;
            logAllPercentFullLabelArray[unit->unitNumber]->Text =
                String::Format("{0:D}% Full", percentFull);
            logAllPercentFullProgressArray[unit->unitNumber]->Value = percentFull;
        }
        else
        {
            GUI_DisplaySimpleError(functionName,
                "Data log full progress percentage out of range:\n"
                "Filled = {0:D} / Size = {1:D} (Remain = {2:D} Percent = {3:D})",
                dataLogConsumed,
                unit->dataLogSize,
                unit->dataLogRemaining,
                percentFull);
        }
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_LogUnitUpdateFullProgressBars()
//----------------------------------------------------------------------------
// QCOM_PromptAndSaveDataLog
//
// Prompts the user for a filename used for saving the data log, then adjusts
// the specified data log flag accordingly
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//
// Called by:   QCOM_TransferDataLogToFile
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_PromptAndSaveDataLog(
    UnitInfo        ^unit,
    String          ^filePathString,
    DWORD           dataLogFlag)
{
    bool            promptResult = GUI_CANCEL;
    DWORD           originalFlags;
    DWORD           unitNumber;
//    String          ^fileNameString;
    String          ^functionName = _T("QCOM_PromptAndSaveDataLog");
    //------------------------------------------------------------------------
    if (unit)
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        originalFlags = unit->dataLogFlags;
//        QCOM_LogUnitDetermineDataLogFilePaths(unit);
//        filePathString = unit->dataLogFilePath;
        StringBuilder ^filePathBuilder = gcnew StringBuilder(
            filePathString, QCOM_MAXIMUM_FILE_PATH_LENGTH);
        promptResult = QCOM_PromptForSaveFile(
            String::Format(
                "Save Data Log for Transducer {0} Module {1}",
                (QCOM_XDSNValid(unit) ?
                    unit->transducerSerialNumber : "on"),
                unit->moduleSerialNumber),
            filePathBuilder,
            filePathString,
            GUI_FILE_TYPE_LOG_CSV);
        filePathString = filePathBuilder->ToString();
        delete filePathBuilder;
        unit->dataLogFilePath = filePathString;
        if (promptResult == GUI_ACCEPT)
        {
            if (StringSet(filePathString))
                unit->dataLogFlags |= dataLogFlag;
            bool spinLockAcquired = GUI_NO;
            try
            {
                QCOM_LogSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                promptResult = QCOM_TransferDataLogToFile(unit, GUI_MAIN_LOG);
            }                           // end of try
            finally
            {
                if (spinLockAcquired == GUI_YES)
                    QCOM_LogSpinLockArray[unitNumber]->Exit();
            }
            if (promptResult == GUI_ACCEPT)
            {
                RecordVerboseEvent(
                    "  Data log for transducer {0} saved to file\n{1}",
                    unit->transducerSerialNumber,
                    filePathString);
            }
        }
        else
        {
            unit->dataLogFlags = originalFlags;
        }
        RecordBasicEvent("{0} concluded, returning {1}",
            functionName, (promptResult ? "Yes" : "No"));
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return promptResult;
}                                       // end of QCOM_PromptAndSaveDataLog()
//----------------------------------------------------------------------------
// QCOM_QueryIncreaseSamplingTimeForLogging
//
// If the transducers are being sampled at a rate that is too fast for data
// logging, queries the user to change the sampling rate to the default
// sampling rate for logging
//
// Returns: GUI_YES     Transducers are being sampled, and the user does not
//                      want to stop the sampling
//          GUI_NO      Either the transducers are not being sampled, or if
//                      they are, the user has chosen to stop the sampling
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_QueryIncreaseSamplingTimeForLogging(void)
{
    bool            increaseInterval = GUI_YES;
    bool            proceedToLog = GUI_YES;
    String          ^functionName = _T("QCOM_QueryIncreaseSamplingTimeForLogging");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_CurrentSamplingInterval < QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET])
    {
        proceedToLog = GUI_NO;
        increaseInterval = QCOM_PromptModal(
            "Invalid Logging Interval",
            "The current sampling interval (gate time) of {0:D} {1} is too short for data logging.\n"
            "Increase this value to the logging minumum of {2:D} {1}?",
            QCOM_CurrentSamplingInterval,
            QCOM_IntervalUnitsStringArray[QCOM_CurrentIntervalUnitsOffset],
            QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET]);
        if (increaseInterval)
        {
            QCOM_CurrentSamplingInterval = QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET];
            samplingTimer->Interval = QCOM_MapDisplayIntervalToActual(QCOM_CurrentSamplingInterval);
            proceedToLog =
                (QCOM_CurrentSamplingInterval < QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET]) ?
                    GUI_NO : GUI_YES;
            QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
        }
    }
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (proceedToLog ? "Yes" : "No"));
    return proceedToLog;
}                                       // end of QCOM_QueryIncreaseSamplingTimeForLogging()
//----------------------------------------------------------------------------
// QCOM_QuerySaveDataLog
//
// If data logging is enabled, queries the user to save the data log for the
// specified transducer to a file
//
// Returns: GUI_YES     The data log has been saved
//          GUI_NO      The user has chosen not to save the data log
//
// Called by:   QCOM_ClearDataLog
//              QCOM_QuerySaveUnsavedLogData (QCOM_TerminateDataLogging)
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_QuerySaveDataLog(
    UnitInfo        ^unit)
{
    bool            proceedToSaveDataLog = GUI_YES;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_QuerySaveDataLog");
    //------------------------------------------------------------------------
    if (unit)
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        if (!(unit->dataLogFlags & QCOM_UNIT_LOG_FILE_AUTO_SAVE))
        {
            proceedToSaveDataLog = QCOM_PromptModal(
                "Save Data Log",
                "Save the data log for transducer {0} ?",
                unit->transducerSerialNumber);
        }
        if (proceedToSaveDataLog)
        {
            bool spinLockAcquired = GUI_NO;
            try
            {
                QCOM_LogSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                proceedToSaveDataLog = QCOM_TransferDataLogToFile(unit, GUI_MAIN_LOG);
            }                           // end of try
            finally
            {
                if (spinLockAcquired == GUI_YES)
                    QCOM_LogSpinLockArray[unitNumber]->Exit();
            }
            if (proceedToSaveDataLog == GUI_ACCEPT)
            {
                RecordVerboseEvent(
                    "    Data log for transducer {0} saved to file\n{1}",
                    unit->transducerSerialNumber,
                    unit->dataLogFilePath);
            }
        }
        RecordBasicEvent("{0} concluded, returning {1}",
            functionName, (proceedToSaveDataLog ? "Yes" : "No"));
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return proceedToSaveDataLog;
}                                       // end of QCOM_QuerySaveDataLog()
//----------------------------------------------------------------------------
// QCOM_QuerySaveUnsavedLogData
//
// Queries the user whether to save unsaved log data
//
// Called by:   QCOM_HaltAllUserActivity
//              QCOM_TerminateDataLogging
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_QuerySaveUnsavedLogData(void)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_QuerySaveUnsavedLogData");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    if ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DATA_PRESENT) &&
        (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DATA_UNSAVED) &&
        !(QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DONT_SAVE_ON_EXIT))
    {
        for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            if (unit)
            {
                if (QCOM_LogDataPresent(unit) &&
                    (unit->dataLogFlags & QCOM_UNIT_LOG_DATA_UNSAVED))
                {
                    QCOM_QuerySaveDataLog(unit);
                }
            }
        }
    }
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_QuerySaveUnsavedLogData()
//----------------------------------------------------------------------------
// QCOM_QuerySelectDataLogFile
//
// Queries the user to specify a data log file
//
// Returns: GUI_YES     A data log file has been selected
//          GUI_NO      The user has chosen not to select a data log file
//
// Called by:   QCOM_LogFileAutoSaveRadioSelected
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_QuerySelectDataLogFile(
    UnitInfo        ^unit)
{
    bool            proceedToSelectDataLog = GUI_NO;
    String          ^functionName = _T("QCOM_QuerySelectDataLogFile");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        proceedToSelectDataLog = QCOM_PromptModal(
            "Data Log File Missing",
            String::Format(
                "A data log file for transducer {0} has not been assigned. Select one now?",
                unit->transducerSerialNumber));
        if (proceedToSelectDataLog)
        {
            proceedToSelectDataLog = QCOM_SelectDataLogFile(unit);
        }
        RecordBasicEvent("{0} concluded, returning {1}",
            functionName, (proceedToSelectDataLog ? "Yes" : "No"));
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return proceedToSelectDataLog;
}                                       // end of QCOM_QuerySelectDataLogFile()
//----------------------------------------------------------------------------
// QCOM_QueryStopLogging
//
// If data is being logged, queries the user to stop logging for the specified
// unit
//
// Returns: GUI_YES     Data is being logged, adn the user does not want to
//                      stop the logging
//          GUI_NO      Either data is not being logged, or if it is, the user
//                      has chosen to stop the logging
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_QueryStopLogging(
    UnitInfo        ^unit,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    bool            currentlyLogging = GUI_NO;
    bool            stopLogging = GUI_YES;
    String          ^promptString;
    String          ^functionName = _T("QCOM_QueryStopLogging");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
        {
            currentlyLogging = GUI_YES;
            if (StringSet(formatString))
            {
                String ^promptHeader = String::Format(formatString, parameters);
                promptString = String::Format(
                    "{0}\nStop logging now?",
                    promptHeader);
                delete promptHeader;
            }
            else
            {
                promptString =
                    _T("This function could not be performed while data is being logged\n") \
                    _T("Stop logging now?");
            }
            stopLogging = QCOM_PromptModal(
                "Data Currently Logging",
                promptString);
            if (stopLogging)
            {
                QCOM_StartStopDataLoggingUnit(unit);
                currentlyLogging =
                    (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING) ?
                        GUI_YES : GUI_NO;
            }
        }
        RecordBasicEvent("{0} concluded, returning {1}",
            functionName, (currentlyLogging ? "Yes" : "No"));
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return currentlyLogging;
}                                       // end of QCOM_QueryStopLogging()
//----------------------------------------------------------------------------
// QCOM_SelectDataLogFile
//
// Prompts the user to set the main data log file name
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//
// Called by:   QCOM_QuerySelectDataLogFile
//              QCOM_LogUnitSelectDataLogFileButtonClicked
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_SelectDataLogFile(
    UnitInfo        ^unit)
{
    bool            promptResult;
    bool            suggestFilename = GUI_NO;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_SelectDataLogFile");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        String ^originalFilePathString = unit->dataLogFilePath;
        if (QCOM_LogFileKnown(unit) &&
            (unit->dataLogFlags & QCOM_UNIT_LOG_DATA_PRESENT) &&
            (unit->dataLogFlags & QCOM_UNIT_LOG_DATA_UNSAVED))
        {
            bool spinLockAcquired = GUI_NO;
            try
            {
                QCOM_LogSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                promptResult = QCOM_TransferDataLogToFile(unit, GUI_MAIN_LOG);
            }                           // end of try
            finally
            {
                if (spinLockAcquired == GUI_YES)
                    QCOM_LogSpinLockArray[unitNumber]->Exit();
            }
            if (promptResult == GUI_ACCEPT)
            {
                RecordVerboseEvent(
                    "    Data log for transducer {0} saved to file\n{1}",
                    unit->transducerSerialNumber,
                    originalFilePathString);
            }
            unit->dataLogFlags &= ~QCOM_UNIT_LOG_DATA_UNSAVED;
        }                               // end of if (QCOM_LogFileKnown(unit))
        StringBuilder ^filePathBuilder = gcnew StringBuilder(
            originalFilePathString, QCOM_MAXIMUM_FILE_PATH_LENGTH);
        promptResult = QCOM_PromptForSaveFile(
            String::Format(
                "{0} Data Log File for Transducer {1} Module {2}",
                (QCOM_LogFileKnown(unit) ?
                    _T("Change") : _T("Select")),
                (QCOM_XDSNValid(unit) ?
                    unit->transducerSerialNumber : _T("on")),
                unit->moduleSerialNumber),
            filePathBuilder,
            (suggestFilename ? originalFilePathString : nullptr),
            GUI_FILE_TYPE_LOG_CSV);
        String ^newFilePathString = filePathBuilder->ToString();
        delete filePathBuilder;
        if ((promptResult == GUI_ACCEPT) && StringSet(newFilePathString))
        {
            QCOM_LogFileMovePair(originalFilePathString, newFilePathString);
            unit->dataLogFilePath = newFilePathString;
            unit->dataLogFlags |= QCOM_UNIT_LOG_FILE_SPECIFIED;
        }
        QCOM_LogUnitDetermineDataLogFilePaths(unit);
        delete newFilePathString;
        delete originalFilePathString;
        RecordBasicEvent("{0} concluded, returning {1}",
            functionName, (promptResult ? "Yes" : "No"));
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return promptResult;
}                                       // end of QCOM_SelectDataLogFile()
//----------------------------------------------------------------------------
// QCOM_SetUpAllDataLoggingWindows
//
// Creates and populates the Log All and all the Log Unit data logging windows
//
// Called by:   QCOM_InstallDataLogging
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SetUpAllDataLoggingWindows(void)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_SetUpAllDataLoggingWindows");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Create a new window form
    //------------------------------------------------------------------------
    logAllDataWindow = gcnew Form;
    //------------------------------------------------------------------------
    // Set its appearance
    //------------------------------------------------------------------------
    logAllDataWindow->Size = Drawing::Size(
        GUI_LOG_ALL_WINDOW_WIDTH,
        GUI_LOG_ALL_WINDOW_HEIGHT);
    logAllDataWindow->MaximizeBox = GUI_NO;
    logAllDataWindow->HelpButton = GUI_NO;
    logAllDataWindow->Icon = QCOM_SoftwareIcon;
    logAllDataWindow->BackgroundImage = whiteSandBackground;
    logAllDataWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
    //------------------------------------------------------------------------
    // Header group box
    //------------------------------------------------------------------------
    logAllHeaderGroupBox = gcnew GroupBox;
    logAllHeaderGroupBox->Text = _T("Data Logging Controls for All Transducers");
    logAllHeaderGroupBox->Location = Point(25, 10);
    logAllHeaderGroupBox->Size = Drawing::Size(
        GUI_LOG_ALL_GROUP_BOX_WIDTH,
        GUI_LOG_ALL_HEADER_GROUP_BOX_HEIGHT);
    logAllHeaderGroupBox->ForeColor = Color::Black;
    logAllHeaderGroupBox->BackColor = Color::Transparent;
    logAllDataWindow->Controls->Add(logAllHeaderGroupBox);
    //------------------------------------------------------------------------
    // Start / Stop Logging button
    //------------------------------------------------------------------------
    logAllStartStopButton = gcnew Button;
    logAllStartStopButton->Location = Point(10, 20);
    logAllStartStopButton->Size = Drawing::Size(
        GUI_DEFAULT_BUTTON_WIDTH,
        GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(logAllStartStopButton);
    logAllStartStopButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllStartStopButtonClicked);
    //------------------------------------------------------------------------
    // Start / Stop Logging button tool tip
    //------------------------------------------------------------------------
    ToolTip ^logAllStartStopButtonToolTip = gcnew ToolTip;
    logAllStartStopButtonToolTip->ShowAlways = GUI_YES;
    logAllStartStopButtonToolTip->AutoPopDelay = 10000;    // let stand for ten seconds
    logAllStartStopButtonToolTip->ToolTipTitle =
        _T("Start / Stop Logging");
    String ^logAllStartStopButtonToolTipText = String::Concat(
        "Starts or stops logging (and therefore sampling)", Environment::NewLine,
        "for all attached units that are included in", Environment::NewLine,
        "sampling.  If any one unit is logging, this stops", Environment::NewLine,
        "them all.  If none of the units are logging, this", Environment::NewLine,
        "starts them all logging.");
    logAllStartStopButtonToolTip->SetToolTip(logAllStartStopButton, logAllStartStopButtonToolTipText);
    delete logAllStartStopButtonToolTipText;
    //------------------------------------------------------------------------
    // Clear All Logs button
    //------------------------------------------------------------------------
    logAllClearButton = gcnew Button;
    logAllClearButton->Text = GUI_CLEAR_ALL_DATA_LOGS_1;
    GUI_PositionAndSizeBelow(logAllClearButton, logAllStartStopButton, 10);
    GUI_SetButtonInterfaceProperties(logAllClearButton);
    logAllClearButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ClearAllDataLogsButtonClicked);
    //------------------------------------------------------------------------
    // Snapshot All Logs button
    //------------------------------------------------------------------------
    logAllSnapshotDataButton = gcnew Button;
    logAllSnapshotDataButton->Text = _T("Snapshot All Logs");
    logAllSnapshotDataButton->Location = Point(
        logAllStartStopButton->Right + 16,
        logAllStartStopButton->Top);
    logAllSnapshotDataButton->Size = logAllStartStopButton->Size;
    GUI_SetButtonInterfaceProperties(logAllSnapshotDataButton);
    logAllSnapshotDataButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllSnapshotDataButtonClicked);
    //------------------------------------------------------------------------
    // Precision numeric and label
    //------------------------------------------------------------------------
    Label ^logAllPrecisionLabel = gcnew Label;
    logAllPrecisionLabel->Text = _T("P/T decimal points:");
    logAllPrecisionLabel->BackColor = Color::Transparent;
    logAllPrecisionLabel->Location = Point(
        logAllSnapshotDataButton->Left,
        logAllClearButton->Top + 6);
    logAllPrecisionLabel->Size = Drawing::Size(100, GUI_REGULAR_LABEL_HEIGHT);
    logAllPrecisionNumeric = gcnew NumericUpDown;
    logAllPrecisionNumeric->Location = Point(
        logAllPrecisionLabel->Right + 2,
        logAllPrecisionLabel->Top - 2);
    logAllPrecisionNumeric->Width = 32;
    logAllPrecisionNumeric->Minimum = GUI_MINIMUM_READOUT_DECIMAL_POINTS;       // 0
    logAllPrecisionNumeric->Maximum = GUI_MAXIMUM_READOUT_DECIMAL_POINTS;       // 7
    logAllPrecisionNumeric->ReadOnly = GUI_YES;
    logAllPrecisionNumeric->Value = (int) QCOM_CurrentPrecision;
    logAllPrecisionNumeric->BackColor = Color::Lavender;
    GUI_DisplayHandCursorOnHover(logAllPrecisionNumeric);
    logAllPrecisionNumeric->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_PrecisionUpDownClicked);
    logAllPrecisionNumeric->MouseDoubleClick +=
        gcnew MouseEventHandler(this, &QCOM_GUIClass::QCOM_PrecisionUpDownDoubleClicked);
    //------------------------------------------------------------------------
    // Interval Units group box and associated components
    //------------------------------------------------------------------------
    GroupBox ^logAllIntervalUnitsGroupBox = gcnew GroupBox;
    logAllIntervalUnitsGroupBox->Text = _T("Time Between Samples");
    logAllIntervalUnitsGroupBox->Location = Point(
        logAllPrecisionNumeric->Right + 16, 8);
    logAllIntervalUnitsGroupBox->Size = Drawing::Size(156, 85);
    logAllIntervalUnitsGroupBox->ForeColor = Color::Black;
    logAllIntervalUnitsGroupBox->BackColor = Color::Transparent;
    //------------------------------------------------------------------------
    // Sampling Interval Timer settings and controls
    //------------------------------------------------------------------------
    Label ^logAllIntervalLabel = gcnew Label;
    logAllIntervalLabel->Text = _T("Interval:");
    logAllIntervalLabel->Location = Point(2, 22);
    logAllIntervalLabel->Size = Drawing::Size(43, GUI_REGULAR_LABEL_HEIGHT);
    logAllIntervalLabel->BackColor = Color::Transparent;
    logAllIntervalBox = gcnew TextBox;
    logAllIntervalBox->Multiline = GUI_NO;
    logAllIntervalBox->AcceptsReturn = GUI_NO;
    logAllIntervalBox->AcceptsTab = GUI_NO;
    logAllIntervalBox->WordWrap = GUI_NO;
    logAllIntervalBox->TextAlign = HorizontalAlignment::Right;
    logAllIntervalBox->Location = Point(
        logAllIntervalLabel->Right + 2,
        logAllIntervalLabel->Top - 2);
    logAllIntervalBox->Size = Drawing::Size(38, GUI_SMALL_TEXT_BOX_HEIGHT);
    logAllIntervalBox->BackColor = Color::White;
    logAllIntervalBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateLoggingIntervalValue);
    logAllIntervalUnitsLabel = gcnew Label;
    logAllIntervalUnitsLabel->Text = QCOM_IntervalUnitsStringArray[QCOM_CurrentIntervalUnitsOffset];
    logAllIntervalUnitsLabel->Location = Point(
        logAllIntervalBox->Right + 1,
        logAllIntervalLabel->Top);
    logAllIntervalUnitsLabel->Size = Drawing::Size(24, GUI_REGULAR_LABEL_HEIGHT);
    logAllIntervalUnitsLabel->BackColor = Color::Transparent;
    logAllIntervalRangeLabel = gcnew Label;
    logAllIntervalRangeLabel->Text = String::Format(
        "({0:D} to {1:D} {2})",
        QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET],
        QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MAXIMUM_OFFSET],
        QCOM_IntervalUnitsStringArray[QCOM_CurrentIntervalUnitsOffset]);
    logAllIntervalRangeLabel->Location = Point(
        logAllIntervalLabel->Left,
        logAllIntervalBox->Bottom + 4);
    logAllIntervalRangeLabel->Size = Drawing::Size(100, GUI_REGULAR_LABEL_HEIGHT);
    logAllIntervalRangeLabel->BackColor = Color::Transparent;
    logAllIntervalRangeLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    //------------------------------------------------------------------------
    // Sampling Interval Timer Units radio buttons
    //------------------------------------------------------------------------
    logAllMillisecondsRadio = gcnew RadioButton;
    logAllMillisecondsRadio->Text = QCOM_IntervalUnitsStringArray[GUI_INTERVAL_MS_OFFSET];
    logAllMillisecondsRadio->Location = Point(
        logAllIntervalUnitsLabel->Right + 2,
        logAllIntervalLabel->Top - 6);
    logAllMillisecondsRadio->Size = Drawing::Size(40, 12);
    GUI_SetObjectInterfaceProperties(logAllMillisecondsRadio);
    logAllMillisecondsRadio->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_SamplingMillisecondsRadioSelected);
    logAllSecondsRadio = gcnew RadioButton;
    logAllSecondsRadio->Text = QCOM_IntervalUnitsStringArray[GUI_INTERVAL_SEC_OFFSET];
    GUI_PositionAndSizeBelow(logAllSecondsRadio, logAllMillisecondsRadio, 4);
    GUI_SetObjectInterfaceProperties(logAllSecondsRadio);
    logAllSecondsRadio->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_SamplingSecondsRadioSelected);
    logAllMinutesRadio = gcnew RadioButton;
    logAllMinutesRadio->Text = QCOM_IntervalUnitsStringArray[GUI_INTERVAL_MIN_OFFSET];
    GUI_PositionAndSizeBelow(logAllMinutesRadio, logAllSecondsRadio, 4);
    GUI_SetObjectInterfaceProperties(logAllMinutesRadio);
    logAllMinutesRadio->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_SamplingMinutesRadioSelected);
    logAllHoursRadio = gcnew RadioButton;
    logAllHoursRadio->Text = QCOM_IntervalUnitsStringArray[GUI_INTERVAL_HR_OFFSET];
    GUI_PositionAndSizeBelow(logAllHoursRadio, logAllMinutesRadio, 4);
    GUI_SetObjectInterfaceProperties(logAllHoursRadio);
    logAllHoursRadio->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_SamplingHoursRadioSelected);
    array <Label ^> ^logAllIntervalLabels =
    {
        logAllIntervalLabel,
        logAllIntervalUnitsLabel,
        logAllIntervalRangeLabel
    };
    logAllIntervalUnitsGroupBox->Controls->AddRange(logAllIntervalLabels);
    array <RadioButton ^> ^intervalRadios =
    {
        logAllMillisecondsRadio,
        logAllSecondsRadio,
        logAllMinutesRadio,
        logAllHoursRadio
    };
    logAllIntervalUnitsGroupBox->Controls->AddRange(intervalRadios);
    logAllIntervalUnitsGroupBox->Controls->Add(logAllIntervalBox);
    //------------------------------------------------------------------------
    // Prepend Entry Numbers checkbox
    //------------------------------------------------------------------------
    logAllPrependEntryNumbersCheck = gcnew CheckBox;
    logAllPrependEntryNumbersCheck->Text = _T("Prepend all entry numbers");
    logAllPrependEntryNumbersCheck->Location = Point(
        logAllIntervalUnitsGroupBox->Right + 15,
        logAllIntervalUnitsGroupBox->Top + 4);
    logAllPrependEntryNumbersCheck->Size = Drawing::Size(
        160, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(logAllPrependEntryNumbersCheck);
    logAllPrependEntryNumbersCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllPrependEntryNumbersChecked);
    //------------------------------------------------------------------------
    // Display All Summaries checkbox
    //------------------------------------------------------------------------
    logAllDisplaySummariesCheck = gcnew CheckBox;
    logAllDisplaySummariesCheck->Text = _T("Display all summaries");
    GUI_PositionAndSizeBelow(logAllDisplaySummariesCheck, logAllPrependEntryNumbersCheck, 4);
    GUI_SetObjectInterfaceProperties(logAllDisplaySummariesCheck);
    logAllDisplaySummariesCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllDisplayAllSummariesChecked);
    //------------------------------------------------------------------------
    // Run For a Specified Time check box
    //------------------------------------------------------------------------
    logAllRunLoggingTimedCheck = gcnew CheckBox;
    logAllRunLoggingTimedCheck->Text = _T("Run for a specified time");
    GUI_PositionAndSizeBelow(logAllRunLoggingTimedCheck, logAllDisplaySummariesCheck, 4);
    GUI_SetObjectInterfaceProperties(logAllRunLoggingTimedCheck);
    logAllRunLoggingTimedCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ReadoutLimitSamplingTimeChecked);
    //------------------------------------------------------------------------
    // Run For Minutes objects
    //------------------------------------------------------------------------
    logAllLimitLoggingTimeLabel = gcnew Label;
    logAllLimitLoggingTimeLabel->Text = _T("Run for");
    GUI_PositionBelow(logAllLimitLoggingTimeLabel, logAllRunLoggingTimedCheck, 4);
    logAllLimitLoggingTimeLabel->Size = Drawing::Size(
        42, GUI_INFO_LABEL_HEIGHT);
    logAllLimitLoggingTimeLabel->BackColor = Color::Transparent;
    logAllLimitLoggingTimeLabel->Visible = GUI_NO;
    logAllLimitLoggingTimeBox = gcnew TextBox;
    logAllLimitLoggingTimeBox->Location = Point(
        logAllLimitLoggingTimeLabel->Right + 2,
        logAllLimitLoggingTimeLabel->Top - 2);
    logAllLimitLoggingTimeBox->Size = Drawing::Size(
        38, GUI_REGULAR_TEXT_BOX_HEIGHT);
    logAllLimitLoggingTimeBox->Multiline = GUI_NO;
    logAllLimitLoggingTimeBox->AcceptsReturn = GUI_NO;
    logAllLimitLoggingTimeBox->AcceptsTab = GUI_NO;
    logAllLimitLoggingTimeBox->WordWrap = GUI_NO;
    logAllLimitLoggingTimeBox->TextAlign = HorizontalAlignment::Right;
    logAllLimitLoggingTimeBox->BackColor = Color::White;
    logAllLimitLoggingTimeBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateLoggingLimitValue);
    logAllLimitLoggingTimeBox->Visible = GUI_NO;
    logAllLimitLoggingTimeMinutesLabel = gcnew Label;
    logAllLimitLoggingTimeMinutesLabel->Text = _T("minutes");
    logAllLimitLoggingTimeMinutesLabel->Location = Point(
        logAllLimitLoggingTimeBox->Right + 2,
        logAllLimitLoggingTimeLabel->Top);
    logAllLimitLoggingTimeMinutesLabel->Size = Drawing::Size(
        44, GUI_REGULAR_LABEL_HEIGHT);
    logAllLimitLoggingTimeMinutesLabel->BackColor = Color::Transparent;
    logAllLimitLoggingTimeMinutesLabel->Visible = GUI_NO;
    logAllLimitLoggingTimeMinutesRemainingLabel = gcnew Label;
    logAllLimitLoggingTimeMinutesRemainingLabel->Location = Point(
        logAllLimitLoggingTimeMinutesLabel->Right,
        logAllLimitLoggingTimeMinutesLabel->Top);
    logAllLimitLoggingTimeMinutesRemainingLabel->Size = Drawing::Size(
        100, GUI_REGULAR_LABEL_HEIGHT);
    logAllLimitLoggingTimeMinutesRemainingLabel->BackColor = Color::Transparent;
    logAllLimitLoggingTimeMinutesRemainingLabel->Visible = GUI_NO;
    //------------------------------------------------------------------------
    // Wrap Text in Display checkbox
    //------------------------------------------------------------------------
    logAllDisplayWrapCheck = gcnew CheckBox;
    logAllDisplayWrapCheck->Text = _T("Wrap text in all display boxes");
    logAllDisplayWrapCheck->Location = Point(
        logAllPrependEntryNumbersCheck->Right + 10,
        logAllPrependEntryNumbersCheck->Top);
    logAllDisplayWrapCheck->Size = Drawing::Size(
        184, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(logAllDisplayWrapCheck);
    logAllDisplayWrapCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllWrapDisplayChecked);
    //--------------------------------------------------------------------
    // Both Log File Formats checkbox
    //--------------------------------------------------------------------
    logAllBothFileFormatsCheck = gcnew CheckBox;
    logAllBothFileFormatsCheck->Text = _T("Log both CSV and Text formats");
    GUI_PositionAndSizeBelow(logAllBothFileFormatsCheck, logAllDisplayWrapCheck, 4);
    GUI_SetObjectInterfaceProperties(logAllBothFileFormatsCheck);
    logAllBothFileFormatsCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllBothFileFormatsChecked);
    //--------------------------------------------------------------------
    // Save Logged Data Immediately checkbox
    //--------------------------------------------------------------------
    logAllSaveLoggedDataImmediatelyCheck = gcnew CheckBox;
    logAllSaveLoggedDataImmediatelyCheck->Text = _T("Save logged data immediately");
    GUI_PositionAndSizeBelow(logAllSaveLoggedDataImmediatelyCheck, logAllBothFileFormatsCheck, 4);
    GUI_SetObjectInterfaceProperties(logAllSaveLoggedDataImmediatelyCheck);
    logAllSaveLoggedDataImmediatelyCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllSaveLoggedDataImmediatelyChecked);
    //------------------------------------------------------------------------
    // Continuous logging time label
    //------------------------------------------------------------------------
    logAllContinuousLoggingTimeLabel = gcnew Label;
    logAllContinuousLoggingTimeLabel->Location = Point(
        logAllHeaderGroupBox->Right - 320,
        logAllHeaderGroupBox->Bottom - 30);
    logAllContinuousLoggingTimeLabel->Size = Drawing::Size(
        290, GUI_INFO_LABEL_HEIGHT);
    logAllContinuousLoggingTimeLabel->BackColor = Color::Transparent;
    logAllContinuousLoggingTimeLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Regular);
    logAllContinuousLoggingTimeLabel->TextAlign = Drawing::ContentAlignment::MiddleRight;
    logAllContinuousLoggingTimeLabel->Visible = GUI_NO;
    //------------------------------------------------------------------------
    // Windows::Forms::Padding(left, top, right, bottom);
    //------------------------------------------------------------------------
    logAllContinuousLoggingTimeLabel->Padding = Windows::Forms::Padding(0, 0, 1, 0);
    //------------------------------------------------------------------------
    // Attach the components to the Log All Header group box
    //------------------------------------------------------------------------
    array <Button ^> ^logAllHeaderGroupBoxButtons =
    {
        logAllStartStopButton,
        logAllClearButton,
        logAllSnapshotDataButton
    };
    logAllHeaderGroupBox->Controls->AddRange(logAllHeaderGroupBoxButtons);
    array <Label ^> ^logAllHeaderGroupBoxLabels =
    {
        logAllPrecisionLabel,
        logAllLimitLoggingTimeLabel,
        logAllLimitLoggingTimeMinutesLabel,
        logAllLimitLoggingTimeMinutesRemainingLabel,
        logAllContinuousLoggingTimeLabel
    };
    logAllHeaderGroupBox->Controls->AddRange(logAllHeaderGroupBoxLabels);
    logAllHeaderGroupBox->Controls->Add(logAllIntervalUnitsGroupBox);
    logAllHeaderGroupBox->Controls->Add(logAllPrecisionNumeric);
    logAllHeaderGroupBox->Controls->Add(logAllLimitLoggingTimeBox);
    array <CheckBox ^> ^logAllCheckBoxes =
    {
        logAllRunLoggingTimedCheck,
        logAllPrependEntryNumbersCheck,
        logAllDisplaySummariesCheck,
        logAllDisplayWrapCheck,
        logAllBothFileFormatsCheck,
        logAllSaveLoggedDataImmediatelyCheck
    };
    logAllHeaderGroupBox->Controls->AddRange(logAllCheckBoxes);
    //------------------------------------------------------------------------
    // Display the tabs for all possible units
    //------------------------------------------------------------------------
    loggingTabControl = gcnew TabControl;
    loggingTabControl->Location = Point(
        10, GUI_LOG_ALL_HEADER_GROUP_BOX_HEIGHT + 20);
    loggingTabControl->Size = Drawing::Size(
        GUI_LOG_ALL_TAB_PAGE_WIDTH,
        GUI_LOG_ALL_TAB_PAGE_HEIGHT);
    loggingTabControl->Appearance = TabAppearance::Normal;
    loggingTabControl->Alignment = TabAlignment::Top;
    logAllDataWindow->Controls->Add(loggingTabControl);
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        //--------------------------------------------------------------------
        // Enclose the unit logs within group boxes
        //--------------------------------------------------------------------
        QCOM_ConstructUnitLogTabInAllWindow(unit);
        QCOM_SetUpUnitDataLoggingWindow(unit);
        QCOM_LogUnitUpdateCaptions(unit);
    }
    //------------------------------------------------------------------------
    // Pause / Resume button
    //------------------------------------------------------------------------
    logAllPauseResumeButton = gcnew Button;
    logAllPauseResumeButton->Text = GUI_PAUSE_ALL_STRING;
    logAllPauseResumeButton->Location = Point(
        logAllStartStopButton->Left,
        logAllDataWindow->Bottom - 70);
    logAllPauseResumeButton->Size = logAllStartStopButton->Size;
    GUI_SetButtonInterfaceProperties(logAllPauseResumeButton);
    logAllPauseResumeButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_PauseResumeButtonClicked);
    logAllPauseResumeButton->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_PauseResumeButtonMouseEntered);
    logAllPauseResumeButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    logAllDataWindow->Controls->Add(logAllPauseResumeButton);
    //------------------------------------------------------------------------
    // Insert Comment group box
    //------------------------------------------------------------------------
    logAllInsertCommentGroupBox = gcnew GroupBox;
    logAllInsertCommentGroupBox->Location = Point(
        170, GUI_LOG_ALL_WINDOW_HEIGHT - 94);
    logAllInsertCommentGroupBox->Size = Drawing::Size(
        GUI_COMMENT_GROUP_BOX_WIDTH,
        GUI_COMMENT_GROUP_BOX_HEIGHT);
    logAllInsertCommentGroupBox->ForeColor = Color::Black;
    logAllInsertCommentGroupBox->BackColor = Color::Transparent;
    logAllDataWindow->Controls->Add(logAllInsertCommentGroupBox);
    //------------------------------------------------------------------------
    // Insert Comment label
    //------------------------------------------------------------------------
    Label ^logAllInsertCommentLabel = gcnew Label;
    logAllInsertCommentLabel->Text = _T("Add a comment to all logs:");
    logAllInsertCommentLabel->Location = Point(4, 10);
    logAllInsertCommentLabel->Size = Drawing::Size(
        142, GUI_REGULAR_LABEL_HEIGHT);
    logAllInsertCommentLabel->BackColor = Color::Transparent;
    logAllInsertCommentLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    logAllInsertCommentGroupBox->Controls->Add(logAllInsertCommentLabel);
    //------------------------------------------------------------------------
    // Time Stamp Comments check box
    //------------------------------------------------------------------------
    logAllInsertCommentTimeStampCheck = gcnew CheckBox;
    logAllInsertCommentTimeStampCheck->Text = _T("Time stamp comments");
    logAllInsertCommentTimeStampCheck->Location = Point(
        logAllInsertCommentLabel->Left + 4,
        logAllInsertCommentLabel->Bottom + 4);
    logAllInsertCommentTimeStampCheck->Size = Drawing::Size(
        logAllInsertCommentLabel->Width - 4,
        GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(logAllInsertCommentTimeStampCheck);
    logAllInsertCommentTimeStampCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllCommentTimeStampChecked);
    logAllInsertCommentGroupBox->Controls->Add(logAllInsertCommentTimeStampCheck);
    //------------------------------------------------------------------------
    // Insert Comment text box
    //------------------------------------------------------------------------
    logAllInsertCommentBox = gcnew TextBox;
    logAllInsertCommentBox->Location = Point(
        logAllInsertCommentLabel->Right + 2, 10);
    logAllInsertCommentBox->Size = Drawing::Size(
        logAllInsertCommentGroupBox->Width - 242, 35);
    logAllInsertCommentBox->MaxLength = GUI_MAXIMUM_LOG_COMMENT_SIZE;
    logAllInsertCommentBox->Multiline = GUI_YES;
    logAllInsertCommentBox->AcceptsReturn = GUI_YES;
    logAllInsertCommentBox->AcceptsTab = GUI_YES;
    logAllInsertCommentBox->WordWrap = GUI_YES;
    logAllInsertCommentBox->ReadOnly = GUI_NO;
    logAllInsertCommentBox->ScrollBars = ScrollBars::Vertical;
    logAllInsertCommentBox->BackColor = Color::White;
    logAllInsertCommentGroupBox->Controls->Add(logAllInsertCommentBox);
    //------------------------------------------------------------------------
    // Add Comment button
    //------------------------------------------------------------------------
    Button ^logAllInsertCommentButton = gcnew Button;
    logAllInsertCommentButton->Text = _T("Add");
    logAllInsertCommentButton->Location = Point(
        logAllInsertCommentBox->Right + 6,
        logAllInsertCommentBox->Top + 5);
    logAllInsertCommentButton->Size = Drawing::Size(
        32, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(logAllInsertCommentButton);
    logAllInsertCommentButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllInsertCommentButtonClicked);
    logAllInsertCommentGroupBox->Controls->Add(logAllInsertCommentButton);
    //------------------------------------------------------------------------
    // Clear Comment button
    //------------------------------------------------------------------------
    Button ^logAllClearCommentButton = gcnew Button;
    logAllClearCommentButton->Text = _T("Clear");
    logAllClearCommentButton->Location = Point(
        logAllInsertCommentButton->Right + 6,
        logAllInsertCommentButton->Top);
    logAllClearCommentButton->Size = Drawing::Size(
        40, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(logAllClearCommentButton);
    logAllClearCommentButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllClearCommentButtonClicked);
    logAllInsertCommentGroupBox->Controls->Add(logAllClearCommentButton);
    //------------------------------------------------------------------------
    // Add a Close button for the All Data Logs window
    //------------------------------------------------------------------------
    logAllCloseButton = gcnew Button;
    logAllCloseButton->Text = _T("Close");
    logAllCloseButton->Location = Point(
        logAllDataWindow->Right - 100,
        logAllDataWindow->Bottom - 70);
    logAllCloseButton->Size = Drawing::Size(
        GUI_CLOSE_BUTTON_WIDTH,
        GUI_REGULAR_BUTTON_HEIGHT);
    logAllCloseButton->DialogResult = System::Windows::Forms::DialogResult::OK;
    GUI_SetButtonInterfaceProperties(logAllCloseButton);
    logAllCloseButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogAllCloseWindow);
    logAllCloseButton->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    logAllDataWindow->Controls->Add(logAllCloseButton);
    //------------------------------------------------------------------------
    // Close button tool tip
    //------------------------------------------------------------------------
    ToolTip ^logAllCloseButtonToolTip = gcnew ToolTip;
    logAllCloseButtonToolTip->ShowAlways = GUI_YES;
    logAllCloseButtonToolTip->AutoPopDelay = 10000;    // let stand for ten seconds
    logAllCloseButtonToolTip->ToolTipTitle =
        _T("Close Logging All Window");
    String ^logAllCloseButtonToolTipText = String::Concat(
        "Closes this (the Data Logging", Environment::NewLine,
        "for All Transducers) window.");
    logAllCloseButtonToolTip->SetToolTip(logAllCloseButton, logAllCloseButtonToolTipText);
    delete logAllCloseButtonToolTipText;
    //------------------------------------------------------------------------
    // Handle the closing of the window by any other way
    //------------------------------------------------------------------------
    logAllDataWindow->FormClosing +=
        gcnew FormClosingEventHandler(this, &QCOM_GUIClass::QCOM_LogAllClosingWindow);
    //------------------------------------------------------------------------
    // Set the remaining window properties
    //------------------------------------------------------------------------
    logAllDataWindow->AcceptButton = logAllCloseButton;
    logAllDataWindow->CancelButton = logAllCloseButton;
    logAllDataWindow->Hide();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_SetUpAllDataLoggingWindows()
//----------------------------------------------------------------------------
// QCOM_SetUpUnitDataLoggingWindow
//
// Creates and populates the unit data logging forms
//
// Called by:   QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SetUpUnitDataLoggingWindow(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_SetUpUnitDataLoggingWindow");
    //------------------------------------------------------------------------
    if (unit)
    {
        unitNumber = unit->unitNumber;
        RecordVerboseEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Create a new window form
        //--------------------------------------------------------------------
        Form ^logUnitWindow = gcnew Form;
        logUnitWindow->Tag = unitNumber;
        //--------------------------------------------------------------------
        // Set its appearance
        //--------------------------------------------------------------------
        logUnitWindow->MaximizeBox = GUI_NO;
//            logUnitWindow->MinimizeBox = GUI_NO;
        logUnitWindow->HelpButton = GUI_NO;
//        logUnitWindow->TopMost = GUI_YES;
        //--------------------------------------------------------------------
        // Set its icon
        //--------------------------------------------------------------------
        logUnitWindow->Icon = QCOM_SoftwareIcon;
        //--------------------------------------------------------------------
        // Set the background image
        //--------------------------------------------------------------------
        logUnitWindow->BackgroundImage = whiteSandBackground;
        logUnitWindow->Size = Drawing::Size(
            GUI_LOG_UNIT_WINDOW_WIDTH,
            GUI_LOG_UNIT_WINDOW_HEIGHT);
        logUnitWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
        //--------------------------------------------------------------------
        // Start/Stop Logging button
        //--------------------------------------------------------------------
        Button ^logUnitStartStopButton = gcnew Button;
        logUnitStartStopButton->Location = Point(10, 10);
        logUnitStartStopButton->Size = logAllStartStopButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            logUnitStartStopButton,
            unitNumber);
        logUnitStartStopButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitStartStopButtonClicked);
        logUnitStartStopButtonArray[unitNumber] = logUnitStartStopButton;
        //--------------------------------------------------------------------
        // Clear Data Log button
        //--------------------------------------------------------------------
        Button ^logUnitClearButton = gcnew Button;
        logUnitClearButton->Text = _T("Clear Data Log");
        logUnitClearButton->Location = Point(
            logUnitStartStopButton->Left,
            logUnitStartStopButton->Bottom + 10);
        logUnitClearButton->Size = logAllStartStopButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            logUnitClearButton,
            unitNumber);
        logUnitClearButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitClearDataButtonClicked);
        logUnitClearButtonArray[unitNumber] = logUnitClearButton;
        //--------------------------------------------------------------------
        // Snapshot Data Log button
        //--------------------------------------------------------------------
        Button ^logUnitSnapshotDataButton = gcnew Button;
        logUnitSnapshotDataButton->Text = _T("Snapshot Data Log");
        logUnitSnapshotDataButton->Location = Point(
            logUnitStartStopButton->Right + 16,
            logUnitStartStopButton->Top);
        logUnitSnapshotDataButton->Size = logAllStartStopButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            logUnitSnapshotDataButton,
            unitNumber);
        logUnitSnapshotDataButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitSnapshotDataButtonClicked);
        logUnitSnapshotDataButtonArray[unitNumber] = logUnitSnapshotDataButton;
        //--------------------------------------------------------------------
        // Select Data Log File button
        //--------------------------------------------------------------------
        Button ^logUnitSelectFileButton = gcnew Button;
        logUnitSelectFileButton->Location = Point(
            logUnitSnapshotDataButton->Left,
            logUnitClearButton->Top);
        logUnitSelectFileButton->Size = logAllStartStopButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            logUnitSelectFileButton,
            unitNumber);
        logUnitSelectFileButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitSelectDataLogFileButtonClicked);
        logUnitSelectFileButtonArray[unitNumber] = logUnitSelectFileButton;
        //--------------------------------------------------------------------
        // Data Log File label
        //--------------------------------------------------------------------
        Label ^logUnitFileLabel = gcnew Label;
        logUnitFileLabel->Location = Point(
            logUnitSelectFileButton->Right + 5,
            logUnitSelectFileButton->Top + 9);
        logUnitFileLabel->Size = Drawing::Size(550, GUI_INFO_LABEL_HEIGHT);
        logUnitFileLabel->BackColor = Color::Transparent;
        logUnitFileLabelArray[unitNumber] = logUnitFileLabel;
        //--------------------------------------------------------------------
        // Auto Save / Prompt group box
        //--------------------------------------------------------------------
        GroupBox ^logUnitAutoSavePromptGroupBox = gcnew GroupBox;
        logUnitAutoSavePromptGroupBox->Location = Point(
            logUnitSnapshotDataButton->Right + 16, 5);
        logUnitAutoSavePromptGroupBox->Size = Drawing::Size(180, 44);
        logUnitAutoSavePromptGroupBox->ForeColor = Color::Black;
        logUnitAutoSavePromptGroupBox->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Auto-save radio button
        //--------------------------------------------------------------------
        RadioButton ^logUnitAutoSaveRadio = gcnew RadioButton;
        logUnitAutoSaveRadio->Text = _T("Auto-save the data log");
        logUnitAutoSaveRadio->Location = Point(2, 8);
        logUnitAutoSaveRadio->Size = Drawing::Size(
            160, GUI_REGULAR_RADIO_BUTTON_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            logUnitAutoSaveRadio,
            unitNumber);
        logUnitAutoSaveRadio->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogFileAutoSaveRadioSelected);
        logUnitAutoSaveRadioArray[unitNumber] = logUnitAutoSaveRadio;
        //--------------------------------------------------------------------
        // Prompt radio button
        //--------------------------------------------------------------------
        RadioButton ^logUnitPromptRadio = gcnew RadioButton;
        logUnitPromptRadio->Text = _T("Prompt to save the data log");
        logUnitPromptRadio->Location = Point(
            logUnitAutoSaveRadio->Left,
            logUnitAutoSaveRadio->Bottom + 2);
        logUnitPromptRadio->Size = logUnitAutoSaveRadio->Size;
        GUI_SetUnitObjectInterfaceProperties(
            logUnitPromptRadio,
            unitNumber);
        logUnitPromptRadio->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogFilePromptRadioSelected);
        logUnitPromptRadioArray[unitNumber] = logUnitPromptRadio;
        array <RadioButton ^> ^logUnitAutoSaveRadios =
        {
            logUnitAutoSaveRadio,
            logUnitPromptRadio
        };
        logUnitAutoSavePromptGroupBox->Controls->AddRange(logUnitAutoSaveRadios);
        //--------------------------------------------------------------------
        // Append / Overwrite group box
        //--------------------------------------------------------------------
        GroupBox ^logUnitAppendOverwriteGroupBox = gcnew GroupBox;
        logUnitAppendOverwriteGroupBox->Location = Point(
            logUnitAutoSavePromptGroupBox->Right + 5,
            logUnitAutoSavePromptGroupBox->Top);
        logUnitAppendOverwriteGroupBox->Size = logUnitAutoSavePromptGroupBox->Size;
        logUnitAppendOverwriteGroupBox->ForeColor = Color::Black;
        logUnitAppendOverwriteGroupBox->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Append radio button
        //--------------------------------------------------------------------
        RadioButton ^appendRadio = gcnew RadioButton;
        appendRadio->Text = _T("Append the data log");
        appendRadio->Location = Point(2, 8);
        appendRadio->Size = Drawing::Size(
            160, GUI_REGULAR_RADIO_BUTTON_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            appendRadio,
            unitNumber);
        appendRadio->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogFileAppendRadioSelected);
        logUnitAppendRadioArray[unitNumber] = appendRadio;
        //--------------------------------------------------------------------
        // Overwrite radio button
        //--------------------------------------------------------------------
        RadioButton ^overwriteRadio = gcnew RadioButton;
        overwriteRadio->Text = _T("Over-write the data log");
        overwriteRadio->Location = Point(
            appendRadio->Left,
            appendRadio->Bottom + 2);
        overwriteRadio->Size = appendRadio->Size;
        GUI_SetUnitObjectInterfaceProperties(
            overwriteRadio,
            unitNumber);
        overwriteRadio->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogFileOverwriteRadioSelected);
        logUnitOverwriteRadioArray[unitNumber] = overwriteRadio;
        if (unit->dataLogFlags & QCOM_UNIT_LOG_FILE_APPEND)
        {
            appendRadio->Checked = GUI_YES;
            overwriteRadio->Checked = GUI_NO;
        }
        else
        {
            appendRadio->Checked = GUI_NO;
            overwriteRadio->Checked = GUI_YES;
        }
        array <RadioButton ^> ^appendOverwriteRadios =
        {
            appendRadio,
            overwriteRadio
        };
        logUnitAppendOverwriteGroupBox->Controls->AddRange(appendOverwriteRadios);
        logUnitAppendOverwriteGroupBoxArray[unitNumber] = logUnitAppendOverwriteGroupBox;
        //--------------------------------------------------------------------
        // Caption control group box
        //--------------------------------------------------------------------
        GroupBox ^logUnitEmbedCaptionGroupBox = gcnew GroupBox;
        logUnitEmbedCaptionGroupBox->Location = Point(
            logUnitAppendOverwriteGroupBox->Right + 5,
            logUnitAutoSavePromptGroupBox->Top);
        logUnitEmbedCaptionGroupBox->Size = logUnitAutoSavePromptGroupBox->Size;
        logUnitEmbedCaptionGroupBox->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Display Caption in Log check box
        //--------------------------------------------------------------------
        CheckBox ^displayCaptionInLogCheck = gcnew CheckBox;
        displayCaptionInLogCheck->Text = _T("Display caption in log");
        displayCaptionInLogCheck->Location = Point(2, 8);
        displayCaptionInLogCheck->Size = Drawing::Size(
            150, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            displayCaptionInLogCheck,
            unitNumber);
        displayCaptionInLogCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DisplayCaptionInLogChecked);
        logUnitDisplayCaptionAllCheckArray[unitNumber] = displayCaptionInLogCheck;
        //--------------------------------------------------------------------
        // Embed Caption in File check box
        //--------------------------------------------------------------------
        CheckBox ^embedCaptionInFileCheck = gcnew CheckBox;
        embedCaptionInFileCheck->Text = _T("Embed caption in file");
        GUI_PositionAndSizeBelow(embedCaptionInFileCheck, displayCaptionInLogCheck, 2);
        GUI_SetUnitObjectInterfaceProperties(
            embedCaptionInFileCheck,
            unitNumber);
        embedCaptionInFileCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_EmbedCaptionInFileChecked);
        logUnitEmbedCaptionCheckArray[unitNumber] = embedCaptionInFileCheck;
        array <CheckBox ^> ^embedCaptionsChecks =
        {
            displayCaptionInLogCheck,
            embedCaptionInFileCheck
        };
        logUnitEmbedCaptionGroupBox->Controls->AddRange(embedCaptionsChecks);
        //--------------------------------------------------------------------
        // Log text window caption
        //--------------------------------------------------------------------
        Label ^logUnitCaptionLabel = gcnew Label;
        logUnitCaptionLabel->Location = Point(
            logUnitStartStopButton->Left,
            logUnitSelectFileButton->Bottom + 4);
        logUnitCaptionLabel->Size = Drawing::Size(
            logUnitWindow->Width - 30,
            GUI_REGULAR_LABEL_HEIGHT);
        logUnitCaptionLabel->Font = gcnew
            Drawing::Font(
                FontFamily::GenericSansSerif,
                8.0F,
                FontStyle::Regular);
        logUnitCaptionLabel->BackColor = Color::Transparent;
        logUnitCaptionLabelArray[unitNumber] = logUnitCaptionLabel;
        //--------------------------------------------------------------------
        // Log text window
        //--------------------------------------------------------------------
        TextBox ^unitLogBox = gcnew TextBox;
        unitLogBox->Location = Point(
            logUnitStartStopButton->Left,
            logUnitCaptionLabel->Bottom + 2);
        unitLogBox->Size = Drawing::Size(
            logUnitCaptionLabel->Width,
            GUI_LOG_UNIT_BOX_HEIGHT);
        unitLogBox->MaxLength = unit->dataLogSize;
        unitLogBox->Multiline = GUI_YES;
        unitLogBox->ReadOnly = GUI_YES;
        unitLogBox->ScrollBars = ScrollBars::Vertical;
        unitLogBox->AcceptsReturn = GUI_YES;
        unitLogBox->AcceptsTab = GUI_YES;
        logUnitBoxArray[unitNumber] = unitLogBox;
        //--------------------------------------------------------------------
        // Progress bar and label if in Expert Mode
        //--------------------------------------------------------------------
        Label ^progressLabel = gcnew Label;
        progressLabel->Text = _T("0% Full"); // String::Format("{0:D}% Full", 0);
        GUI_PositionBelow(progressLabel, unitLogBox, 4);
        progressLabel->Size = Drawing::Size(48, GUI_REGULAR_LABEL_HEIGHT);
        logUnitPercentFullLabelArray[unitNumber] = progressLabel;
        ProgressBar ^percentFullProgress = gcnew ProgressBar;
        percentFullProgress->Location = Point(
            progressLabel->Right,
            progressLabel->Top);
        percentFullProgress->Size = Drawing::Size(
            unitLogBox->Width - progressLabel->Width,
            progressLabel->Height);
        percentFullProgress->Minimum = 0;
        percentFullProgress->Maximum = 100;
        percentFullProgress->Value = 0;
        percentFullProgress->Style = ProgressBarStyle::Continuous;
        logUnitPercentFullProgressArray[unitNumber] = percentFullProgress;
        //--------------------------------------------------------------------
        // Data points label and check boxes
        //--------------------------------------------------------------------
        Label ^selectDataPointsLabel = gcnew Label;
        selectDataPointsLabel->Text = _T("Logged data points and properties:");
        selectDataPointsLabel->Location = Point(
            logUnitStartStopButton->Left,
            progressLabel->Bottom + 10);
        selectDataPointsLabel->Size = Drawing::Size(
            260, GUI_INFO_LABEL_HEIGHT);
        selectDataPointsLabel->Font = gcnew
            Drawing::Font(
                FontFamily::GenericSansSerif,
                10.0F,
                FontStyle::Regular);
        selectDataPointsLabel->BackColor = Color::Transparent;
        Label ^logUnitTimeLabel = gcnew Label;
        logUnitTimeLabel->Location = Point(
            selectDataPointsLabel->Right + 210,
            selectDataPointsLabel->Top);
        logUnitTimeLabel->Size = Drawing::Size(
            340, GUI_INFO_LABEL_HEIGHT);
        logUnitTimeLabel->BackColor = Color::Transparent;
        logUnitTimeLabel->TextAlign = Drawing::ContentAlignment::MiddleRight;
        logUnitTimeLabel->Font = selectDataPointsLabel->Font;
        //--------------------------------------------------------------------
        // Windows::Forms::Padding(left, top, right, bottom);
        //--------------------------------------------------------------------
        logUnitTimeLabel->Padding = Windows::Forms::Padding(0, 0, 1, 0);
        logUnitTimeLabelArray[unitNumber] = logUnitTimeLabel;
        //--------------------------------------------------------------------
        // Select All check box
        //--------------------------------------------------------------------
        CheckBox ^allCheck = gcnew CheckBox;
        allCheck->Text = _T("Select all data points");
        GUI_PositionBelow(allCheck, selectDataPointsLabel, 4);
        allCheck->Size = Drawing::Size(150, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            allCheck,
            unitNumber);
        allCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DLAllChecked);
        logUnitAllCheckArray[unitNumber] = allCheck;
        //--------------------------------------------------------------------
        // Select Defaults check box
        //--------------------------------------------------------------------
        CheckBox ^defaultsCheck = gcnew CheckBox;
        defaultsCheck->Text = _T("Select only defaults");
        GUI_PositionAndSizeBelow(defaultsCheck, allCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            defaultsCheck,
            unitNumber);
        defaultsCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DLDefaultsChecked);
        logUnitDefaultsCheckArray[unitNumber] = defaultsCheck;
        //--------------------------------------------------------------------
        // Date Stamp check box
        //--------------------------------------------------------------------
        CheckBox ^dateStampCheck = gcnew CheckBox;
        dateStampCheck->Text = _T("Date stamp");
        GUI_PositionAndSizeBelow(dateStampCheck, defaultsCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            dateStampCheck,
            unitNumber);
        dateStampCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DLDateStampChecked);
        logUnitDateStampCheckArray[unitNumber] = dateStampCheck;
        //--------------------------------------------------------------------
        // Time Stamp check box
        //--------------------------------------------------------------------
        CheckBox ^timeStampCheck = gcnew CheckBox;
        timeStampCheck->Text = _T("Time stamp");
        GUI_PositionAndSizeBelow(timeStampCheck, dateStampCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            timeStampCheck,
            unitNumber);
        timeStampCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DLTimeStampChecked);
        logUnitTimeStampLogCheckArray[unitNumber] = timeStampCheck;
        //--------------------------------------------------------------------
        // Decimal Seconds check box
        //--------------------------------------------------------------------
        CheckBox ^msCheck = gcnew CheckBox;
        msCheck->Text = _T("Decimal seconds");
        GUI_PositionAndSizeBelow(msCheck, timeStampCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            msCheck,
            unitNumber);
        msCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DLMillisecondsChecked);
        logUnitMillisecondsCheckArray[unitNumber] = msCheck;
        //--------------------------------------------------------------------
        // Pressure default check box
        //--------------------------------------------------------------------
        CheckBox ^logUnitDefPressureCheck = gcnew CheckBox;
        logUnitDefPressureCheck->Text = String::Concat(
            _T("Pressure "), QCOM_PressureUnitsStringArray[QCOM_DefaultPressureUnits]);
        logUnitDefPressureCheck->Location = Point(
            allCheck->Right + 10,
            allCheck->Top);
        logUnitDefPressureCheck->Size = allCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            logUnitDefPressureCheck,
            unitNumber);
        logUnitDefPressureCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitDefPressureChecked);
        logUnitDefPressureCheckArray[unitNumber] = logUnitDefPressureCheck;
        //--------------------------------------------------------------------
        // Pressure alternate check box
        //--------------------------------------------------------------------
        CheckBox ^logUnitAltPressureCheck = gcnew CheckBox;
        logUnitAltPressureCheck->Text = String::Concat(
            _T("Pressure "), QCOM_PressureUnitsStringArray[QCOM_AlternatePressureUnits]);
        GUI_PositionAndSizeBelow(logUnitAltPressureCheck, logUnitDefPressureCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            logUnitAltPressureCheck,
            unitNumber);
        logUnitAltPressureCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitAltPressureChecked);
        logUnitAltPressureCheckArray[unitNumber] = logUnitAltPressureCheck;
        //--------------------------------------------------------------------
        // Pressure Count check box
        //--------------------------------------------------------------------
        CheckBox ^pressureCountCheck = gcnew CheckBox;
        pressureCountCheck->Text = _T("Pressure Count");
        GUI_PositionAndSizeBelow(pressureCountCheck, logUnitAltPressureCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            pressureCountCheck,
            unitNumber);
        pressureCountCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DLPressureCountChecked);
        logUnitPressureCountCheckArray[unitNumber] = pressureCountCheck;
        //--------------------------------------------------------------------
        // Pressure Frequency check box
        //--------------------------------------------------------------------
        CheckBox ^pressureFrequencyCheck = gcnew CheckBox;
        pressureFrequencyCheck->Text = _T("Pressure Frequency");
        GUI_PositionAndSizeBelow(pressureFrequencyCheck, pressureCountCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            pressureFrequencyCheck,
            unitNumber);
        pressureFrequencyCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DLPressureFrequencyChecked);
        logUnitPressureFrequencyCheckArray[unitNumber] = pressureFrequencyCheck;
        //--------------------------------------------------------------------
        // Temperature default check box
        //--------------------------------------------------------------------
        CheckBox ^logUnitDefTemperatureCheck = gcnew CheckBox;
        logUnitDefTemperatureCheck->Text = String::Concat(
            _T("Temperature "), QCOM_TemperatureUnitsStringArray[QCOM_DefaultTemperatureUnits]);
        logUnitDefTemperatureCheck->Location = Point(
            logUnitDefPressureCheck->Right + 10,
            allCheck->Top);
        logUnitDefTemperatureCheck->Size = allCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            logUnitDefTemperatureCheck,
            unitNumber);
        logUnitDefTemperatureCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitDefTemperatureChecked);
        logUnitDefTemperatureCheckArray[unitNumber] = logUnitDefTemperatureCheck;
        //--------------------------------------------------------------------
        // Alternate Temperature check box
        //--------------------------------------------------------------------
        CheckBox ^logUnitAltTemperatureCheck = gcnew CheckBox;
        logUnitAltTemperatureCheck->Text = String::Concat(
            _T("Temperature "), QCOM_TemperatureUnitsStringArray[QCOM_AlternateTemperatureUnits]);
        GUI_PositionAndSizeBelow(logUnitAltTemperatureCheck, logUnitDefTemperatureCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            logUnitAltTemperatureCheck,
            unitNumber);
        logUnitAltTemperatureCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitAltTemperatureChecked);
        logUnitAltTemperatureCheckArray[unitNumber] = logUnitAltTemperatureCheck;
        //--------------------------------------------------------------------
        // Temperature Count check box
        //--------------------------------------------------------------------
        CheckBox ^temperatureCountCheck = gcnew CheckBox;
        temperatureCountCheck->Text = _T("Temperature Count");
        GUI_PositionAndSizeBelow(temperatureCountCheck, logUnitAltTemperatureCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            temperatureCountCheck,
            unitNumber);
        temperatureCountCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DLTemperatureCountChecked);
        logUnitTemperatureCountCheckArray[unitNumber] = temperatureCountCheck;
        //--------------------------------------------------------------------
        // Temperature Frequency check box
        //--------------------------------------------------------------------
        CheckBox ^temperatureFrequencyCheck = gcnew CheckBox;
        temperatureFrequencyCheck->Text = _T("Temperature Frequency");
        GUI_PositionAndSizeBelow(temperatureFrequencyCheck, temperatureCountCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            temperatureFrequencyCheck,
            unitNumber);
        temperatureFrequencyCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DLTemperatureFrequencyChecked);
        logUnitTemperatureFrequencyCheckArray[unitNumber] = temperatureFrequencyCheck;
        //--------------------------------------------------------------------
        // Transducer Voltage check box
        //--------------------------------------------------------------------
        CheckBox ^transducerVoltageCheck = gcnew CheckBox;
        transducerVoltageCheck->Text = _T("Transducer Voltage");
        transducerVoltageCheck->Location = Point(
            logUnitDefTemperatureCheck->Right + 10,
            allCheck->Top);
        transducerVoltageCheck->Size = allCheck->Size;
        GUI_SetUnitObjectInterfaceProperties(
            transducerVoltageCheck,
            unitNumber);
        transducerVoltageCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DLTransducerVoltageChecked);
        logUnitTransducerVoltageCheckArray[unitNumber] = transducerVoltageCheck;
        //--------------------------------------------------------------------
        // Transducer Current check box
        //--------------------------------------------------------------------
        CheckBox ^transducerAmperageCheck = gcnew CheckBox;
        transducerAmperageCheck->Text = _T("Transducer Current");
        GUI_PositionAndSizeBelow(transducerAmperageCheck, transducerVoltageCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            transducerAmperageCheck,
            unitNumber);
        transducerAmperageCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DLTransducerAmperageChecked);
        logUnitTransducerAmperageCheckArray[unitNumber] = transducerAmperageCheck;
        //--------------------------------------------------------------------
        // Counts in Hex check box
        //--------------------------------------------------------------------
        CheckBox ^countsInHexCheck = gcnew CheckBox;
        countsInHexCheck->Text = _T("Counts in hex");
        GUI_PositionAndSizeBelow(countsInHexCheck, transducerAmperageCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(countsInHexCheck, unitNumber);
        countsInHexCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_DLCountsInHexChecked);
        logUnitCountsInHexCheckArray[unitNumber] = countsInHexCheck;
        //--------------------------------------------------------------------
        // Prepend Entry Numbers check box
        //--------------------------------------------------------------------
        CheckBox ^logUnitPrependEntryNumbersCheck = gcnew CheckBox;
        logUnitPrependEntryNumbersCheck->Text = _T("Prepend entry numbers");
        GUI_PositionAndSizeBelow(logUnitPrependEntryNumbersCheck, countsInHexCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            logUnitPrependEntryNumbersCheck,
            unitNumber);
        logUnitPrependEntryNumbersCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitPrependEntryNumbersChecked);
        logUnitPrependEntryNumbersCheckArray[unitNumber] = logUnitPrependEntryNumbersCheck;
        //--------------------------------------------------------------------
        // Display Summary check box
        //--------------------------------------------------------------------
        CheckBox ^logUnitDisplaySummaryCheck = gcnew CheckBox;
        logUnitDisplaySummaryCheck->Text = _T("Display summary when stopped");
        logUnitDisplaySummaryCheck->Location = Point(
            logUnitWindow->Width - 216,
            allCheck->Top);
        logUnitDisplaySummaryCheck->Size = Drawing::Size(
            184, GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            logUnitDisplaySummaryCheck,
            unitNumber);
        logUnitDisplaySummaryCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitDisplaySummaryChecked);
        logUnitDisplaySummaryCheckArray[unitNumber] = logUnitDisplaySummaryCheck;
        //--------------------------------------------------------------------
        // Wrap Text check box
        //--------------------------------------------------------------------
        CheckBox ^logUnitDisplayWrapCheck = gcnew CheckBox;
        logUnitDisplayWrapCheck->Text = _T("Wrap text in display box");
        GUI_PositionAndSizeBelow(logUnitDisplayWrapCheck, logUnitDisplaySummaryCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            logUnitDisplayWrapCheck,
            unitNumber);
        logUnitDisplayWrapCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitWrapDisplayChecked);
        logUnitDisplayWrapCheckArray[unitNumber] = logUnitDisplayWrapCheck;
        //--------------------------------------------------------------------
        // Both Log File Formats check box
        //--------------------------------------------------------------------
        CheckBox ^logUnitBothFileFormatsCheck = gcnew CheckBox;
        logUnitBothFileFormatsCheck->Text = _T("Log both CSV and Text formats");
        GUI_PositionAndSizeBelow(logUnitBothFileFormatsCheck, logUnitDisplayWrapCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            logUnitBothFileFormatsCheck,
            unitNumber);
        logUnitBothFileFormatsCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitBothFileFormatsChecked);
        logUnitBothFileFormatsCheckArray[unitNumber] = logUnitBothFileFormatsCheck;
        //--------------------------------------------------------------------
        // Save Logged Data Immediately check box
        //--------------------------------------------------------------------
        CheckBox ^logUnitSaveLoggedDataImmediatelyCheck = gcnew CheckBox;
        logUnitSaveLoggedDataImmediatelyCheck->Text = _T("Save logged data immediately");
        GUI_PositionAndSizeBelow(logUnitSaveLoggedDataImmediatelyCheck, logUnitBothFileFormatsCheck, 4);
        GUI_SetUnitObjectInterfaceProperties(
            logUnitSaveLoggedDataImmediatelyCheck,
            unitNumber);
        logUnitSaveLoggedDataImmediatelyCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitSaveLoggedDataImmediatelyChecked);
        logUnitSaveLoggedDataImmediatelyCheckArray[unitNumber] = logUnitSaveLoggedDataImmediatelyCheck;
        //--------------------------------------------------------------------
        // Pause / Resume button
        //--------------------------------------------------------------------
        Button ^logUnitPauseResumeButton = gcnew Button;
        logUnitPauseResumeButton->Text = GUI_PAUSE_ALL_STRING;
        logUnitPauseResumeButton->Location = Point(
            logUnitStartStopButton->Left,
            logUnitWindow->Bottom - 70);
        logUnitPauseResumeButton->Size = logAllStartStopButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            logUnitPauseResumeButton,
            unitNumber);
        logUnitPauseResumeButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_PauseResumeButtonClicked);
        logUnitPauseResumeButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_PauseResumeButtonMouseEntered);
        logUnitPauseResumeButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        logUnitPauseResumeButtonArray[unitNumber] = logUnitPauseResumeButton;
        //--------------------------------------------------------------------
        // Insert Comment group box
        //--------------------------------------------------------------------
        GroupBox ^logUnitInsertCommentGroupBox = gcnew GroupBox;
        logUnitInsertCommentGroupBox->Location = Point(
            170, pressureFrequencyCheck->Bottom + 2);
        logUnitInsertCommentGroupBox->Size = Drawing::Size(
            GUI_COMMENT_GROUP_BOX_WIDTH,
            GUI_COMMENT_GROUP_BOX_HEIGHT);
        logUnitInsertCommentGroupBox->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Insert Comment label
        //--------------------------------------------------------------------
        Label ^logUnitInsertCommentLabel = gcnew Label;
        logUnitInsertCommentLabel->Text = _T("Add a comment to the log:");
        logUnitInsertCommentLabel->Location = Point(4, 10);
        logUnitInsertCommentLabel->Size = Drawing::Size(
            142, GUI_REGULAR_LABEL_HEIGHT);
        logUnitInsertCommentLabel->BackColor = Color::Transparent;
        logUnitInsertCommentLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        //--------------------------------------------------------------------
        // Time Stamp Comments check box
        //--------------------------------------------------------------------
        CheckBox ^logUnitInsertCommentTimeStampCheck = gcnew CheckBox;
        logUnitInsertCommentTimeStampCheck->Text = _T("Time stamp comments");
        logUnitInsertCommentTimeStampCheck->Location = Point(
            logUnitInsertCommentLabel->Left + 4,
            logUnitInsertCommentLabel->Bottom + 4);
        logUnitInsertCommentTimeStampCheck->Size = Drawing::Size(
            logUnitInsertCommentLabel->Width - 4,
            GUI_REGULAR_CHECK_BOX_HEIGHT);
        GUI_SetUnitObjectInterfaceProperties(
            logUnitInsertCommentTimeStampCheck,
            unitNumber);
        logUnitInsertCommentTimeStampCheck->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitCommentTimeStampChecked);
        logUnitInsertCommentTimeStampCheckArray[unitNumber] = logUnitInsertCommentTimeStampCheck;
        //--------------------------------------------------------------------
        // Insert Comment text box
        //--------------------------------------------------------------------
        TextBox ^logUnitInsertCommentBox = gcnew TextBox;
        logUnitInsertCommentBox->Tag = unitNumber;
        logUnitInsertCommentBox->Location = Point(
            logUnitInsertCommentLabel->Right + 2, 10);
        logUnitInsertCommentBox->Size = Drawing::Size(
            logUnitInsertCommentGroupBox->Width - 242, 35);
        logUnitInsertCommentBox->MaxLength = GUI_MAXIMUM_LOG_COMMENT_SIZE;
        logUnitInsertCommentBox->Multiline = GUI_YES;
        logUnitInsertCommentBox->AcceptsReturn = GUI_YES;
        logUnitInsertCommentBox->AcceptsTab = GUI_YES;
        logUnitInsertCommentBox->WordWrap = GUI_YES;
        logUnitInsertCommentBox->ReadOnly = GUI_NO;
        logUnitInsertCommentBox->ScrollBars = ScrollBars::Vertical;
        logUnitInsertCommentBox->BackColor = Color::White;
        logUnitInsertCommentBoxArray[unitNumber] = logUnitInsertCommentBox;
        //--------------------------------------------------------------------
        // Add Comment button
        //--------------------------------------------------------------------
        Button ^logUnitInsertCommentButton = gcnew Button;
        logUnitInsertCommentButton->Text = _T("Add");
        logUnitInsertCommentButton->Location = Point(
            logUnitInsertCommentBox->Right + 6,
            logUnitInsertCommentBox->Top + 5);
        logUnitInsertCommentButton->Size = Drawing::Size(
            32, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            logUnitInsertCommentButton,
            unitNumber);
        logUnitInsertCommentButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitInsertCommentButtonClicked);
        //--------------------------------------------------------------------
        // Clear Comment button
        //--------------------------------------------------------------------
        Button ^logUnitClearCommentButton = gcnew Button;
        logUnitClearCommentButton->Text = _T("Clear");
        logUnitClearCommentButton->Location = Point(
            logUnitInsertCommentButton->Right + 6,
            logUnitInsertCommentButton->Top);
        logUnitClearCommentButton->Size = Drawing::Size(
            40, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            logUnitClearCommentButton,
            unitNumber);
        logUnitClearCommentButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitClearCommentButtonClicked);
        logUnitInsertCommentGroupBox->Controls->Add(logUnitClearCommentButton);
        logUnitInsertCommentGroupBox->Controls->Add(logUnitInsertCommentButton);
        logUnitInsertCommentGroupBox->Controls->Add(logUnitInsertCommentLabel);
        logUnitInsertCommentGroupBox->Controls->Add(logUnitInsertCommentTimeStampCheck);
        logUnitInsertCommentGroupBox->Controls->Add(logUnitInsertCommentBox);
        //--------------------------------------------------------------------
        // Close button
        //--------------------------------------------------------------------
        Button ^logUnitCloseButton = gcnew Button;
        logUnitCloseButton->Text = _T("Close");
        logUnitCloseButton->Location = Point(
            logUnitWindow->Right - 100,
            logUnitWindow->Bottom - 70);
        logUnitCloseButton->Size = Drawing::Size(
            GUI_CLOSE_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        logUnitCloseButton->DialogResult = System::Windows::Forms::DialogResult::OK;
        GUI_SetUnitButtonInterfaceProperties(
            logUnitCloseButton,
            unitNumber);
        logUnitCloseButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_LogUnitCloseWindow);
        //--------------------------------------------------------------------
        // Handle the closing of the window by any other way
        //--------------------------------------------------------------------
        logUnitWindow->FormClosing +=
            gcnew FormClosingEventHandler(this, &QCOM_GUIClass::QCOM_LogUnitClosingWindow);
        //--------------------------------------------------------------------
        // Attach the components to the Unit Data Logging window
        //--------------------------------------------------------------------
        array <Button ^> ^unitLogButtons =
        {
            logUnitStartStopButton,
            logUnitClearButton,
            logUnitSnapshotDataButton,
            logUnitSelectFileButton,
            logUnitPauseResumeButton,
            logUnitCloseButton
        };
        logUnitWindow->Controls->AddRange(unitLogButtons);
        array <Label ^> ^unitLogLabels =
        {
            logUnitFileLabel,
            logUnitCaptionLabel,
            progressLabel,
            selectDataPointsLabel,
            logUnitTimeLabel
        };
        logUnitWindow->Controls->AddRange(unitLogLabels);
        array <GroupBox ^> ^unitLogGroupBoxes =
        {
            logUnitAutoSavePromptGroupBox,
            logUnitAppendOverwriteGroupBox,
            logUnitEmbedCaptionGroupBox,
            logUnitInsertCommentGroupBox
        };
        logUnitWindow->Controls->AddRange(unitLogGroupBoxes);
        logUnitWindow->Controls->Add(unitLogBox);
        logUnitWindow->Controls->Add(percentFullProgress);
        array <CheckBox ^> ^unitLogChecks =
        {
            allCheck,                       defaultsCheck,                      dateStampCheck,
            timeStampCheck,                 msCheck,                            logUnitDefPressureCheck,
            logUnitAltPressureCheck,        logUnitDefTemperatureCheck,         logUnitAltTemperatureCheck,
            pressureCountCheck,             temperatureCountCheck,              pressureFrequencyCheck,
            temperatureFrequencyCheck,      transducerVoltageCheck,             transducerAmperageCheck,
            countsInHexCheck,               logUnitPrependEntryNumbersCheck,    logUnitDisplaySummaryCheck,
            logUnitDisplayWrapCheck,        logUnitBothFileFormatsCheck,        logUnitSaveLoggedDataImmediatelyCheck
        };
        logUnitWindow->Controls->AddRange(unitLogChecks);
        if (QCOM_UnitValid(unit))
        {
//            QCOM_LogUnitDetermineDataLogFilePaths(unit);
//            QCOM_LogUnitUpdateChecks(unit);
//            QCOM_LogUnitUpdateCaptions(unit);
        }
        //--------------------------------------------------------------------
        // Set the remaining window properties
        //--------------------------------------------------------------------
        logUnitWindow->AcceptButton = logUnitCloseButton;
        logUnitWindow->CancelButton = logUnitCloseButton;
        logUnitWindowArray[unitNumber] = logUnitWindow;
        logUnitWindow->Hide();
    }                                   // end of if (unit)
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_SetUpUnitDataLoggingWindow()
//----------------------------------------------------------------------------
// QCOM_StampDataLogStarted
//
// Updates the data log with an indication that the logging has started, with
// the date and time the logging started
//
// Note:    Data logging does not need to be running currently in order for
//          this method to work
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StampDataLogStarted(
    UnitInfo        ^unit)
{
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("QCOM_StampDataLogStarted");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (QCOM_UnitLogReady(unit))
        {
            String ^dataLogLine = String::Format(
                "{0:D2} {1} {2:D4} {3:D2}:{4:D2}:{5:D2} : "
                "Logging started at {6:D} {7} intervals for Transducer {8}{9} QCOM Module {10} (QCOM {11} Build {12:D})",
                dateTime.Day,
                QCOM_MonthStringArray[dateTime.Month],
                dateTime.Year,
                dateTime.Hour,
                dateTime.Minute,
                dateTime.Second,
                QCOM_CurrentSamplingInterval,
                QCOM_IntervalUnitsStringArray[QCOM_CurrentIntervalUnitsOffset],
                (QCOM_XDSNValid(unit) ?
                    unit->transducerSerialNumber : QCOM_STRING_EMPTY),
                (QCOM_XDSNValid(unit) ?
                    " on" : "on"),
                unit->moduleSerialNumber,
                QCOM_PROGRAM_VERSION_STRING,
                QCOM_BuildNumber);
            GUI_StringToBuilder(
                dataLogLine,
                unit->dataLogLine);
            QCOM_LogUnitUpdateDataLog(
                unit,
                (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
            QCOM_LogUnitUpdateCaptions(unit);
            delete dataLogLine;
        }                               // end of if (QCOM_UnitLogReady(unit))
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_StampDataLogStarted()
//----------------------------------------------------------------------------
// QCOM_StampDataLogStopped
//
// Updates the data log with an indication that the logging has stopped, with
// the date and time the logging stopped
//
// Called by:   QCOM_StartStopDataLoggingUnit
//
// Note:    Data logging does not need to be running currently in order for
//          this method to work
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StampDataLogStopped(
    UnitInfo        ^unit)
{
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("QCOM_StampDataLogStopped");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (QCOM_UnitLogReady(unit))
        {
            QCOM_LogUnitUpdateCaptions(unit);
            String ^dataLogLine = String::Format(
                "{0:D2} {1} {2:D4} {3:D2}:{4:D2}:{5:D2} : "
                "Logging stopped for Transducer {6}{7} QCOM Module {8}",
                dateTime.Day,
                QCOM_MonthStringArray[dateTime.Month],
                dateTime.Year,
                dateTime.Hour,
                dateTime.Minute,
                dateTime.Second,
                (QCOM_XDSNValid(unit) ?
                    unit->transducerSerialNumber : QCOM_STRING_EMPTY),
                (QCOM_XDSNValid(unit) ?
                    " on" : "on"),
                unit->moduleSerialNumber);
            GUI_StringToBuilder(
                dataLogLine,
                unit->dataLogLine);
            QCOM_LogUnitUpdateDataLog(
                unit,
                (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY));
            delete dataLogLine;
        }                               // end of if (QCOM_UnitLogReady(unit))
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_StampDataLogStopped()
//----------------------------------------------------------------------------
// QCOM_StampDataLogTruncated
//
// Updates the data log display with an indication that the display has been
// truncated, along with the name of the data log file that contains the
// lines that have been removed
//
// Called by:   QCOM_LogUnitUpdateDataLog
//
// Note:    Data logging does not need to be currently running in order for
//          this method to work
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StampDataLogTruncated(
    UnitInfo        ^unit,
    bool            logWasSaved)
{
    String          ^functionName = _T("QCOM_StampDataLogTruncated");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (QCOM_UnitLogReady(unit))
        {
            String ^dataLogDisplay;
            if (logWasSaved)
            {
                dataLogDisplay = String::Format(
                    "<Lines above for Transducer {0}{1} QCOM Module {2} have been moved to {3}>",
                    (QCOM_XDSNValid(unit) ?
                        unit->transducerSerialNumber : QCOM_STRING_EMPTY),
                    (QCOM_XDSNValid(unit) ?
                        " on" : "on"),
                    unit->moduleSerialNumber,
                    unit->dataLogFilePath);
            }
            else
            {
                dataLogDisplay = String::Format(
                    "<Lines above for Transducer {0}{1} QCOM Module {2} have been cleared>",
                    (QCOM_XDSNValid(unit) ?
                        unit->transducerSerialNumber : QCOM_STRING_EMPTY),
                    (QCOM_XDSNValid(unit) ?
                        " on" : "on"),
                    unit->moduleSerialNumber);
            }
            GUI_StringToBuilder(
                dataLogDisplay,
                unit->dataLogDisplay);
            //----------------------------------------------------------------
            // Replace the display with dataLogDisplay (clear the display,
            // then stamp the display with dataLogDisplay), but do nothing to
            // the data log itself
            //----------------------------------------------------------------
            QCOM_LogUnitUpdateDataLog(
                unit,
                (GUI_LOG_ACTION_APPEND_NEWLINE | GUI_LOG_ACTION_REPLACE_DISPLAY));
            delete dataLogDisplay;
        }                               // end of if (QCOM_UnitLogReady(unit))
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_StampDataLogTruncated()
//----------------------------------------------------------------------------
// QCOM_StartStopDataLoggingAll
//
// Toggle to start or stop data logging for all units
//
// Note:    If any units are currently logging, all of them will be stopped;
//          otherwise, they will all be started only if none of them are
//          currently logging
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StartStopDataLoggingAll(void)
{
    bool            atLeastOneLogging = GUI_NO;
    String          ^functionName = _T("QCOM_StartStopDataLoggingAll");
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING)
    {
        QCOM_GeneralInfo->logFlags &= ~QCOM_GENERAL_LOG_CURRENTLY_LOGGING;
        //--------------------------------------------------------------------
        // Stop logging
        //--------------------------------------------------------------------
//        QCOM_LoggingStartTime = 0;
        bool oneStillLogging = GUI_NO;
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
                {
                    atLeastOneLogging = GUI_YES;
                    QCOM_ConcludeDataLoggingUnit(unit);
                    if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
                        oneStillLogging = GUI_YES;
                }
            }
        }
        if (!atLeastOneLogging)
            RecordErrorEvent("    {0} : General logging flag was set but no units were logging",
                functionName);
        if (oneStillLogging)
            RecordErrorEvent("    {0} : At least one unit still logging after all were stopped",
                functionName);
//        QCOM_LoggingElapsedTime = 0;
        QCOM_StopPausedBlinker();
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED)
            QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_PROGRAM_PAUSED;
        readoutPauseResumeButton->Text = GUI_PAUSE_OPERATIONS_STRING;
        logAllPauseResumeButton->Text = GUI_PAUSE_ALL_STRING;
        testingPauseResumeButton->Text = GUI_PAUSE_ALL_STRING;
    }
    else
    {
        //--------------------------------------------------------------------
        // Start logging
        //--------------------------------------------------------------------
        QCOM_LoggingStartTime = GetTickCount();
        QCOM_LoggingElapsedTime = 0;
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
                {
                    atLeastOneLogging = GUI_YES;
                }
                else
                {
                    //--------------------------------------------------------
                    // Start sampling and logging on this unit
                    //--------------------------------------------------------
                    QCOM_StartSamplingUnit(unit);
                    QCOM_StartDataLoggingUnit(unit);
                }
            }
            else
            {
                QCOM_RecordAndModalErrorEvent(
                    "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                    functionName, unitNumber, QCOM_CurrentNumberOfUnits);
            }
        }
        if (atLeastOneLogging)
            RecordErrorEvent("    {0} General sampling flag not set while a unit was sampling",
                functionName);
    }                                   // end of else of if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING)
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
}                                       // end of QCOM_StartStopDataLoggingAll()
//----------------------------------------------------------------------------
// QCOM_StartStopDataLoggingUnit
//
// Toggle to start or stop data logging for the specified unit
//
// Called by:   QCOM_StartStopDataLoggingAll
//              QCOM_LogUnitStartStopButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StartStopDataLoggingUnit(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_StartStopDataLoggingUnit");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
        {
            //----------------------------------------------------------------
            // Stop logging and sampling on this unit
            //----------------------------------------------------------------
            QCOM_ConcludeDataLoggingUnit(unit);
        }
        else
        {
            //----------------------------------------------------------------
            // Start sampling and logging on this unit
            //----------------------------------------------------------------
            QCOM_StartSamplingUnit(unit);
            QCOM_StartDataLoggingUnit(unit);
        }                               // end of else of if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_StartStopDataLoggingUnit()
//----------------------------------------------------------------------------
// QCOM_ConcludeDataLoggingUnit
//
// Stops data logging on the specified unit, stops sampling, displays the
// statistics, transfers the data to a file, and sets the appropriate flags
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConcludeDataLoggingUnit(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_ConcludeDataLoggingUnit");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        QCOM_StopDataLoggingUnit(unit);
        QCOM_StopSamplingUnit(unit);
        QCOM_DisplayLoggingStatistics(unit);
        if (unit->dataLogFlags & QCOM_UNIT_LOG_FILE_AUTO_SAVE)
        {
            bool transferResult = GUI_ACCEPT;
            bool spinLockAcquired = GUI_NO;
            try
            {
                QCOM_LogSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                transferResult = QCOM_TransferDataLogToFile(unit, GUI_MAIN_LOG);
            }                           // end of try
            finally
            {
                if (spinLockAcquired == GUI_YES)
                    QCOM_LogSpinLockArray[unitNumber]->Exit();
            }
            if (transferResult == GUI_ACCEPT)
            {
                RecordVerboseEvent(
                    "    Data log for transducer {0} saved to file\n{1}",
                    unit->transducerSerialNumber,
                    unit->dataLogFilePath);
            }
            unit->dataLogFlags &= ~QCOM_UNIT_LOG_DATA_UNSAVED;
        }
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_ConcludeDataLoggingUnit()
//----------------------------------------------------------------------------
// QCOM_StartDataLoggingUnit
//
// Starts logging for the specified unit if permitted, then sets the general
// flag
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StartDataLoggingUnit(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_StartDataLoggingUnit");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (!(unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING) &&
            (unit->flags & QCOM_UNIT_INCLUDE_IN_SAMPLING))
        {
            bool proceedToLog = QCOM_QueryIncreaseSamplingTimeForLogging();
            if (!(unit->dataLogPoints & QCOM_UNIT_LOG_DATE_STAMP) &&
                !(unit->dataLogPoints & QCOM_UNIT_LOG_TIME_STAMP))
            {
                proceedToLog = QCOM_PromptModal(
                    "Missing Time and Date Stamping",
                    "Neither date stamping nor time stamping is selected.\n"
                    "Continue to log for transducer {0} anyway?",
                    unit->transducerSerialNumber);
            }
            if (proceedToLog)
            {
                QCOM_LogUnitInitializeStatistics(unit);
                if (!(QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING))
                    QCOM_GeneralInfo->logFlags |= QCOM_GENERAL_LOG_CURRENTLY_LOGGING;
                unit->dataLogFlags |= QCOM_UNIT_LOG_CURRENTLY_LOGGING;
                if (!QCOM_LoggingStartTime)
                {
                    QCOM_LoggingStartTime = GetTickCount();
                    QCOM_LoggingElapsedTime = 0;
                }
                QCOM_StampDataLogStarted(unit);
                //------------------------------------------------------------
                // Take the initial reading
                //------------------------------------------------------------
                QCOM_RetrieveTransducerReadings(unit);
                QCOM_UpdateReadout(unit);
                //------------------------------------------------------------
                // Display the initial reading and initiate the timer
                //------------------------------------------------------------
                QCOM_CollectDataSample(unit->unitNumber);
                Thread ^markSampleTimeThread =
                    gcnew Thread(gcnew ThreadStart(this, &QCOM_GUIClass::QCOM_MarkSampleTimeThread));
                markSampleTimeThread->Start();
            }                           // end of if (proceedToLog)
        }                               // end of if (!(unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING) && ...)
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_StartDataLoggingUnit()
//----------------------------------------------------------------------------
// QCOM_StopDataLoggingUnit
//
// Stops logging for the specified unit, then updates the general flag if all
// units have stopped logging
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StopDataLoggingUnit(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_StopDataLoggingUnit");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
        {
            //----------------------------------------------------------------
            // Stop logging this unit
            //----------------------------------------------------------------
            QCOM_StampDataLogStopped(unit);
            unit->dataLogFlags &= ~QCOM_UNIT_LOG_CURRENTLY_LOGGING;
            RecordVerboseEvent("    Logging stopped for unit {0:D}",
                unit->unitNumber);
            logUnitPauseResumeButtonArray[unit->unitNumber]->Text = GUI_PAUSE_ALL_STRING;
            graphingPauseResumeButtonArray[unit->unitNumber]->Text = GUI_PAUSE_ALL_STRING;
            //----------------------------------------------------------------
            // Reset the general flag if no other units are logging
            //----------------------------------------------------------------
            if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING)
            {
                bool atLeastOneLogging = GUI_NO;
                for (DWORD moduleNumber = 0; moduleNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; moduleNumber++)
                {
                    if (QCOM_UnitNumberValid(moduleNumber))
                    {
                        UnitInfo ^module = QCOM_UnitInfoArray[moduleNumber];
                        if (module->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
                            atLeastOneLogging = GUI_YES;
                    }
                }
                if (!atLeastOneLogging)
                {
                    QCOM_GeneralInfo->logFlags &= ~QCOM_GENERAL_LOG_CURRENTLY_LOGGING;
                    RecordVerboseEvent("    General logging flag reset when unit {0:D} logging stopped",
                        unit->unitNumber);
                }
            }                           // end of if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING)
            else
            {
                //------------------------------------------------------------
                // Invalid state: This unit was logging but the general flag
                // was not set
                //------------------------------------------------------------
                RecordErrorEvent("    General sampling flag not set while unit {0:D} was logging",
                    unit->unitNumber);
            }
        }                               // end of if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_StopDataLoggingUnit()
//----------------------------------------------------------------------------
// QCOM_TerminateDataLogging
//
// Stops data logging for the entire system, if it's running
//
// Called by:   QCOM_HomeClosingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TerminateDataLogging(void)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TerminateDataLogging");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING)
    {
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberLegal(unitNumber))
            {
                unit = QCOM_UnitInfoArray[unitNumber];
                if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
                {
                    unit->dataLogFlags &= ~QCOM_UNIT_LOG_CURRENTLY_LOGGING;
                    QCOM_StampDataLogStopped(unit);
                }
            }
        }
//        QCOM_GeneralInfo->logFlags &= ~QCOM_GENERAL_LOG_ALL_LOGGING;
//        QCOM_GeneralInfo->logFlags &= ~QCOM_GENERAL_LOG_CURRENTLY_LOGGING;
    }
//    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    QCOM_QuerySaveUnsavedLogData();
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_TerminateDataLogging()
//----------------------------------------------------------------------------
// QCOM_ToggleGeneralLogFlagThenSetUnitFlags
//
// Toggles the specified general log flag, then sets the corresponding log
// flag for all valid units
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToggleGeneralLogFlagThenSetUnitFlags(
    DWORD           generalLogFlag,
    DWORD           unitLogFlag)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_ToggleGeneralLogFlagThenSetUnitFlags");
    //------------------------------------------------------------------------
    if (generalLogFlag)
    {
        if (QCOM_GeneralInfo->logFlags & generalLogFlag)
            QCOM_GeneralInfo->logFlags &= ~generalLogFlag;
        else
            QCOM_GeneralInfo->logFlags |= generalLogFlag;
        if (unitLogFlag)
        {
            for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
            {
                if (QCOM_UnitNumberValid(unitNumber))
                {
                    unit = QCOM_UnitInfoArray[unitNumber];
                    if (QCOM_GeneralInfo->logFlags & generalLogFlag)
                        unit->dataLogFlags |= unitLogFlag;
                    else
                        unit->dataLogFlags &= ~unitLogFlag;
                }
                else
                {
                    RecordErrorEvent(
                        "    Unit number {0:D} should be valid,\nbut is not (number of units = {0:D})",
                        unitNumber, QCOM_CurrentNumberOfUnits);
                }
            }
        }
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    }
}                                       // end of QCOM_ToggleGeneralLogFlagThenSetUnitFlags()
//----------------------------------------------------------------------------
// QCOM_ToggleUnitLogFlagThenSetGeneralFlag
//
// Toggles the specified unit flag, then sets the corresponding general flag
// as needed
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToggleUnitLogFlagThenSetGeneralFlag(
    UnitInfo        ^unit,
    DWORD           generalLogFlag,
    DWORD           unitLogFlag)
{
    bool            allUnitsSet = GUI_YES;
    String          ^functionName = _T("QCOM_ToggleUnitLogFlagThenSetGeneralFlag");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        if (unitLogFlag)
        {
            if (unit->dataLogFlags & unitLogFlag)
            {
                unit->dataLogFlags &= ~unitLogFlag;
                if (generalLogFlag)
                {
                    if (QCOM_GeneralInfo->logFlags & generalLogFlag)
                        QCOM_GeneralInfo->logFlags &= ~generalLogFlag;
                }
            }
            else
            {
                unit->dataLogFlags |= unitLogFlag;
                if (generalLogFlag)
                {
                    if (!(QCOM_GeneralInfo->logFlags & generalLogFlag))
                    {
                        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
                        {
                            if (QCOM_UnitNumberValid(unitNumber))
                            {
                                if (!(QCOM_UnitInfoArray[unitNumber]->dataLogFlags & unitLogFlag))
                                    allUnitsSet = GUI_NO;
                            }
                            else
                            {
                                RecordErrorEvent(
                                    "    Unit number {0:D} should be valid,\nbut is not (number of units = {1:D})",
                                    unitNumber, QCOM_CurrentNumberOfUnits);
                            }
                        }
                        if (allUnitsSet)
                            QCOM_GeneralInfo->logFlags |= generalLogFlag;
                    }
                }
            }
            QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
        }
    }
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_ToggleUnitLogFlagThenSetGeneralFlag()
//----------------------------------------------------------------------------
// QCOM_TransferDataLogToFile
//
// Saves the data log of the specified unit to a file, prompting the user as
// needed
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//
// Note:    This method should be protected by a spin lock
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_TransferDataLogToFile(
    UnitInfo        ^unit,
    bool            targetMainLog)
{
    bool            promptResult = GUI_CANCEL;
    DWORD           status;
    String          ^dataLogFilePath;
    String          ^functionName = _T("QCOM_TransferDataLogToFile");
    //------------------------------------------------------------------------
    if (unit)
    {
        RecordVerboseEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (targetMainLog)
        {
            dataLogFilePath = unit->dataLogFilePath;
            if (QCOM_LogFileKnown(unit))
            {
//                if (unit->dataLogFlags & QCOM_UNIT_LOG_FILE_AUTO_SAVE)
//                {
                    status = QCOM_LogUnitSaveDataLog(unit, dataLogFilePath);
                    if (status == QCOM_SUCCESS)
                    {
                        promptResult = GUI_ACCEPT;
                        unit->dataLogFlags &= ~QCOM_UNIT_LOG_DATA_UNSAVED;
                        if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_EXITING) &&
                            !(unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING))
                        {
                            RecordVerboseEvent(
                                "    Data log for transducer {0} saved to file\n{1}",
                                unit->transducerSerialNumber,
                                dataLogFilePath);
                        }
                    }
                    else
                    {
                        RecordErrorEvent(
                            "    QCOM_LogUnitSaveDataLog returned 0x{0:X8}", status);
                    }
//                }
//                else
//                {
//                    //--------------------------------------------------------
//                    // A log file is specified, but Auto-Save is not enabled,
//                    // so prompt for a file to save the log data
//                    //--------------------------------------------------------
//                    promptResult =
//                        QCOM_PromptAndSaveDataLog(
//                            unit,
//                            dataLogFilePath,
//                            QCOM_UNIT_LOG_FILE_SPECIFIED);
//                    if (promptResult == GUI_ACCEPT)
//                        unit->dataLogFlags &= ~QCOM_UNIT_LOG_DATA_UNSAVED;
//                }
            }
            else
            {
                //------------------------------------------------------------
                // No file was specified, so prompt for one, then save the log
                // data to it
                //------------------------------------------------------------
                promptResult = QCOM_PromptAndSaveDataLog(
                    unit,
                    dataLogFilePath,
                    QCOM_UNIT_LOG_FILE_SPECIFIED);
                if (promptResult == GUI_ACCEPT)
                    unit->dataLogFlags &= ~QCOM_UNIT_LOG_DATA_UNSAVED;
            }
        }
        else
        {
            dataLogFilePath = unit->dataLogSnapshotFilePath;
            //----------------------------------------------------------------
            // This is a request to take a snapshot of the current data log,
            // so prompt for a file, then save the log data to it as a
            // snapshot of the current data log
            //
            // Note:    Saving the data to the snapshot file does not clear
            //          the QCOM_UNIT_LOG_DATA_UNSAVED flag, since the
            //          snapshot file is not the permanent data log file
            //
            // Note:    A snapshot always overwrites the target file,
            //          regardless of the Append/Overwrite setting, which
            //          applies only to the main data log file
            //----------------------------------------------------------------
            if (QCOM_LogSSFileKnown(unit))
            {
                status = QCOM_LogUnitSaveDataLog(unit, dataLogFilePath);
                if (status == QCOM_SUCCESS)
                {
                    promptResult = GUI_ACCEPT;
                    if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_EXITING))
                    {
                        RecordVerboseEvent(
                            "    Snapshot data log for transducer {0} saved to file\n{1}",
                            unit->transducerSerialNumber,
                            dataLogFilePath);
                    }
                }
                else
                {
                    RecordErrorEvent(
                        "    QCOM_LogUnitSaveDataLog returned 0x{0:X8}", status);
                }
            }
            else
            {
                //------------------------------------------------------------
                // The following 'append override' flag is a temporary kludge
                // >sigh<
                //------------------------------------------------------------
                unit->dataLogFlags |= QCOM_UNIT_LOG_SNAPSHOT_APPEND_OVERRIDE;
                promptResult = QCOM_PromptAndSaveDataLog(
                    unit,
                    dataLogFilePath,
                    QCOM_UNIT_LOG_SNAPSHOT_FILE_SPECIFIED);
                unit->dataLogFlags &= ~QCOM_UNIT_LOG_SNAPSHOT_APPEND_OVERRIDE;
            }
        }                               // end of if (targetMainLog)
        RecordVerboseEvent("{0} concluded, returning {1}",
            functionName, (promptResult ? "Save" : "Cancel"));
    }
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
    return promptResult;
}                                       // end of QCOM_TransferDataLogToFile()
//----------------------------------------------------------------------------
// QCOM_CalculateDoubleStatistics
//
// Calculates the high, low, and total values from a new double value
// compared with those specified
//----------------------------------------------------------------------------
    void
QCOM_CalculateDoubleStatistics(
    double          newValue,
    double          *lowValue,
    double          *highValue,
    double          *totalOfValues)
{
    //------------------------------------------------------------------------
    if (*highValue)
        *highValue = Max(newValue, *highValue);
    else
        *highValue = newValue;
    if (*lowValue)
        *lowValue = Min(newValue, *lowValue);
    else
        *lowValue = newValue;
    *totalOfValues += newValue;
}                                       // end of QCOM_CalculateDoubleStatistics()
//----------------------------------------------------------------------------
// QCOM_CalculateIntegerStatistics
//
// Calculates the high, low, and total values from a new integer value
// compared with those specified
//----------------------------------------------------------------------------
    void
QCOM_CalculateIntegerStatistics(
    long            newValue,
    long            *lowValue,
    long            *highValue,
    long long       *totalOfValues)
{
    //------------------------------------------------------------------------
    if (*highValue)
        *highValue = Max(newValue, *highValue);
    else
        *highValue = newValue;
    if (*lowValue)
        *lowValue = Min(newValue, *lowValue);
    else
        *lowValue = newValue;
    *totalOfValues += newValue;
}                                       // end of QCOM_CalculateIntegerStatistics()
//----------------------------------------------------------------------------
// QCOM_DoubleStringLength
//
// Returns the number of characters in the string equivalent of the specified
// floating point value, given the precision
//----------------------------------------------------------------------------
    int
QCOM_DoubleStringLength(
    double          value,
    int             precision)
{
    int             captionWidth = precision;
    //------------------------------------------------------------------------
    if (value < 0.0)
    {
        value = -value;
        captionWidth++;
    }
    if (value >= 10000.0)
        captionWidth++;
    if (value >= 1000.0)
        captionWidth++;
    if (value >= 100.0)
        captionWidth++;
    if (value >= 10.0)
        captionWidth++;
    if (value >= 0.0)
        captionWidth++;
    //------------------------------------------------------------------------
    // Add one for the decimal point if the precision is nonzero
    //------------------------------------------------------------------------
    if (precision)
        captionWidth++;
    return captionWidth;
}                                       // end of QCOM_DoubleStringLength()
//----------------------------------------------------------------------------
// QCOM_FormatFileCaptionText
//
// Formats the specified caption string with appropriate spacing, intended for
// the data log text file
//----------------------------------------------------------------------------
    void
QCOM_FormatFileCaptionText(
    String          ^captionToAdd,
    double          value,
    int             precision,
    StringBuilder   ^fileCaptionBuilder)
{
    int             appendSpaces = 0;
    int             prependSpaces = 1;
    int             captionLength;
    int             textLength;
    //------------------------------------------------------------------------
    if (StringSet(captionToAdd))
    {
        captionLength = captionToAdd->Length;
        textLength = QCOM_DoubleStringLength(value, precision);
        if (textLength)
        {
            if (textLength > captionLength)
            {
                prependSpaces = ((textLength - captionLength) / 2) + 1;
                appendSpaces = textLength + 1 - prependSpaces - captionLength;
            }
            fileCaptionBuilder->Append(' ', prependSpaces)->Append(captionToAdd)->Append(' ', appendSpaces);
        }
    }
}                                       // end of QCOM_FormatFileCaptionText()
//----------------------------------------------------------------------------
#endif      // LOGGING_CPP
//============================================================================
// End of Logging.cpp
//============================================================================
