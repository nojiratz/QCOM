//============================================================================
// Misc.cpp
//
// The methods used by GUI.cpp for miscellaneous expert tasks
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     MISC_CPP
#define     MISC_CPP
#include    "Misc.h"
//----------------------------------------------------------------------------
// QCOM_MiscConstructUnitControlTab
//
// Builds a unit Misc controls tab for the Misc Controls
// window
//
// Returns: The bottom line number of the currently created tab
//
// Called by:   QCOM_MiscSetUpControls
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscConstructUnitControlTab(
    UnitInfo        ^unit)
{
    bool            transducerIsAnalog = GUI_NO;
    bool            transducerWithNoMemory = GUI_NO;
    bool            unitIsValid = GUI_NO;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_MiscConstructUnitControlTab");
    //------------------------------------------------------------------------
    if (unit)
    {
        unitNumber = unit->unitNumber;
        RecordVerboseEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Create the tab page
        //--------------------------------------------------------------------
        TabPage ^miscTabPage = gcnew TabPage;
        miscTabPage->TabIndex = unitNumber;
        miscTabPage->BackgroundImage = whiteMarbleBackground;
        miscTabPageArray[unitNumber] = miscTabPage;
        GroupBox ^miscUnitGroupBox = gcnew GroupBox;
        if (QCOM_UnitNumberValid(unitNumber))
        {
            unitIsValid = GUI_YES;
            if (QCOM_XDIsFrequency(unit))
            {
                transducerIsAnalog = GUI_YES;
                transducerWithNoMemory = GUI_YES;
            }
            if (QCOM_XDIsDigitalNoMem(unit))
                transducerWithNoMemory = GUI_YES;
            miscUnitGroupBox->Text = unit->unitDescriptionString;
        }
        else
        {
            miscTabPage->Text = String::Concat("Unit ", unitNumber);
            //----------------------------------------------------------------
            // Set the tab's group box title
            //----------------------------------------------------------------
            miscUnitGroupBox->Text = String::Concat(
                "Miscellaneous Controls and Utilities for Unit ",
                unitNumber);
        }
        miscUnitGroupBox->Location = Point(10, 10);
        miscUnitGroupBox->Size = Drawing::Size(
            miscTabControl->Width - 30,
            miscTabControl->Height - 50);
        miscUnitGroupBox->BackColor = Color::Transparent;
        miscTabPage->Controls->Add(miscUnitGroupBox);
        miscUnitGroupBoxArray[unitNumber] = miscUnitGroupBox;
        //--------------------------------------------------------------------
        // Serial Number group box
        //--------------------------------------------------------------------
        GroupBox ^miscGetModuleSerialNumberGroupBox = gcnew GroupBox;
        miscGetModuleSerialNumberGroupBox->Text = _T("Module Serial Number");
        miscGetModuleSerialNumberGroupBox->Location = Point(10, 20);
        miscGetModuleSerialNumberGroupBox->Size = Drawing::Size(140, 50);
        //--------------------------------------------------------------------
        // Populate the Module Serial Number group box
        //--------------------------------------------------------------------
        Button ^miscGetModuleSerialNumberButton = gcnew Button;
        miscGetModuleSerialNumberButton->Text = _T("Get");
        miscGetModuleSerialNumberButton->Location = Point(6, 16);
        miscGetModuleSerialNumberButton->Size = Drawing::Size(30, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            miscGetModuleSerialNumberButton,
            unitNumber);
        miscGetModuleSerialNumberButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscReadModuleSerialNumberButtonClicked);
        TextBox ^miscGetModuleSerialNumberBox = gcnew TextBox;
        miscGetModuleSerialNumberBox->Tag = unitNumber;
        miscGetModuleSerialNumberBox->Location = Point(
            miscGetModuleSerialNumberButton->Right + 5,
            miscGetModuleSerialNumberButton->Top + 2);
        miscGetModuleSerialNumberBox->Size = Drawing::Size(90, GUI_REGULAR_TEXT_BOX_HEIGHT);
        miscGetModuleSerialNumberBox->Multiline = GUI_NO;
        miscGetModuleSerialNumberBox->AcceptsReturn = GUI_NO;
        miscGetModuleSerialNumberBox->AcceptsTab = GUI_NO;
        miscGetModuleSerialNumberBox->WordWrap = GUI_NO;
        miscGetModuleSerialNumberBox->ReadOnly = GUI_YES;
        miscGetModuleSerialNumberBox->TextAlign = HorizontalAlignment::Center;
        miscGetModuleSerialNumberBox->BackColor = Color::Lavender;
        miscGetModuleSerialNumberBoxArray[unitNumber] = miscGetModuleSerialNumberBox;
        miscGetModuleSerialNumberGroupBox->BackColor = Color::Transparent;
        miscGetModuleSerialNumberGroupBox->Controls->Add(miscGetModuleSerialNumberButton);
        miscGetModuleSerialNumberGroupBox->Controls->Add(miscGetModuleSerialNumberBox);
        //--------------------------------------------------------------------
        // Module Serial Number tool tip for the buttons and text box
        //--------------------------------------------------------------------
        ToolTip ^miscModuleSerialNumberToolTip = gcnew ToolTip;
        miscModuleSerialNumberToolTip->ShowAlways = GUI_YES;
        miscModuleSerialNumberToolTip->AutoPopDelay = 10000;    // let stand for ten seconds
        miscModuleSerialNumberToolTip->ToolTipTitle =
            _T("Module Serial Number");
        String ^miscModuleSerialNumberToolTipText = String::Concat(
            "Displays the serial number of the QCOM module", Environment::NewLine,
            "for unit ", unitNumber, ". If the module is in Boot Loader Mode,", Environment::NewLine,
            "a ~ symbol will be appended to the serial number.");
        miscModuleSerialNumberToolTip->SetToolTip(miscGetModuleSerialNumberButton, miscModuleSerialNumberToolTipText);
        miscModuleSerialNumberToolTip->SetToolTip(miscGetModuleSerialNumberBox, miscModuleSerialNumberToolTipText);
        miscModuleSerialNumberToolTip->SetToolTip(miscGetModuleSerialNumberGroupBox, miscModuleSerialNumberToolTipText);
        delete miscModuleSerialNumberToolTipText;
        miscGetModuleSerialNumberGroupBoxArray[unitNumber] = miscGetModuleSerialNumberGroupBox;
        //--------------------------------------------------------------------
        // I�C Data Rate group box
        //--------------------------------------------------------------------
        GroupBox ^miscI2CGetSetDataRateGroupBox = gcnew GroupBox;
        miscI2CGetSetDataRateGroupBox->Text = _T("I�C Data Rate");
        miscI2CGetSetDataRateGroupBox->Location = Point(
            miscGetModuleSerialNumberGroupBox->Right + 10,
            miscGetModuleSerialNumberGroupBox->Top);
        miscI2CGetSetDataRateGroupBox->Size = Drawing::Size(
            160, miscGetModuleSerialNumberGroupBox->Height);
        //--------------------------------------------------------------------
        // Populate the I�C Data Rate group box
        //--------------------------------------------------------------------
        Button ^miscI2GetDataRateButton = gcnew Button;
        miscI2GetDataRateButton->Text = _T("Get");
        miscI2GetDataRateButton->Location = Point(6, 16);
        miscI2GetDataRateButton->Size = Drawing::Size(30, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            miscI2GetDataRateButton,
            unitNumber);
        miscI2GetDataRateButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscGetI2CDataRateButtonClicked);
        miscI2CGetSetDataRateGroupBox->Controls->Add(miscI2GetDataRateButton);
        TextBox ^miscGetSetDataRateBox = gcnew TextBox;
        miscGetSetDataRateBox->Tag = unitNumber;
        miscGetSetDataRateBox->Location = Point(
            miscI2GetDataRateButton->Right + 5,
            miscI2GetDataRateButton->Top + 2);
        miscGetSetDataRateBox->Size = Drawing::Size(40, GUI_REGULAR_TEXT_BOX_HEIGHT);
        miscGetSetDataRateBox->Multiline = GUI_NO;
        miscGetSetDataRateBox->AcceptsReturn = GUI_NO;
        miscGetSetDataRateBox->AcceptsTab = GUI_NO;
        miscGetSetDataRateBox->WordWrap = GUI_NO;
        miscGetSetDataRateBox->TextAlign = HorizontalAlignment::Right;
        miscGetSetDataRateBox->BackColor = Color::White;
        miscGetSetDataRateBox->Validating +=
            gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_MiscValidateI2CDataRateBox);
        miscGetSetDataRateBox->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscGetSetI2CDataRateBoxClicked);
        miscI2CGetSetDataRateGroupBox->Controls->Add(miscGetSetDataRateBox);
        miscGetDataRateBoxArray[unitNumber] = miscGetSetDataRateBox;
        QCOM_MiscGetAndPostI2CDataRate(unit);
        Label ^miscGetSetDataRateLabel = gcnew Label;
        miscGetSetDataRateLabel->Text = _T("kHz");
        miscGetSetDataRateLabel->Location = Point(
            miscGetSetDataRateBox->Right + 2,
            miscGetSetDataRateBox->Top + 3);
        miscGetSetDataRateLabel->Size = Drawing::Size(24, GUI_REGULAR_LABEL_HEIGHT);
        miscGetSetDataRateLabel->BackColor = Color::Transparent;
        miscI2CGetSetDataRateGroupBox->Controls->Add(miscGetSetDataRateLabel);
        Button ^miscI2CSetDataRateButton = gcnew Button;
        miscI2CSetDataRateButton->Text = _T("Set");
        miscI2CSetDataRateButton->Location = Point(120, miscI2GetDataRateButton->Top);
        miscI2CSetDataRateButton->Size = miscI2GetDataRateButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            miscI2CSetDataRateButton,
            unitNumber);
        miscI2CSetDataRateButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscSetI2CDataRateButtonClicked);
        miscI2CGetSetDataRateGroupBox->BackColor = Color::Transparent;
        miscI2CGetSetDataRateGroupBox->Controls->Add(miscI2CSetDataRateButton);
        //--------------------------------------------------------------------
        // Get I�C Data Rate tool tip for all objects in the group box
        //--------------------------------------------------------------------
        ToolTip ^miscGetSetI2CDataRateToolTip = gcnew ToolTip;
        miscGetSetI2CDataRateToolTip->ShowAlways = GUI_YES;
        miscGetSetI2CDataRateToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        miscGetSetI2CDataRateToolTip->ToolTipTitle = _T("I�C Data Rate");
        String ^miscGetSetI2CDataRateToolTipText = String::Concat(
            "Displays or sets the rate at which data is", Environment::NewLine,
            "transferred between the QCOM module", Environment::NewLine,
            "and the transducer on the I�C bus.", Environment::NewLine,
            "Minimum rate = 33.3 kHz", Environment::NewLine,
            "Maximum rate = 100.0 kHz");
        miscGetSetI2CDataRateToolTip->SetToolTip(miscGetSetDataRateLabel, miscGetSetI2CDataRateToolTipText);
        miscGetSetI2CDataRateToolTip->SetToolTip(miscGetSetDataRateBox, miscGetSetI2CDataRateToolTipText);
        miscGetSetI2CDataRateToolTip->SetToolTip(miscI2GetDataRateButton, miscGetSetI2CDataRateToolTipText);
        miscGetSetI2CDataRateToolTip->SetToolTip(miscI2CSetDataRateButton, miscGetSetI2CDataRateToolTipText);
        miscGetSetI2CDataRateToolTip->SetToolTip(miscI2CGetSetDataRateGroupBox, miscGetSetI2CDataRateToolTipText);
        delete miscGetSetI2CDataRateToolTipText;
        miscGetSetI2CDataRateGroupBoxArray[unitNumber] = miscI2CGetSetDataRateGroupBox;
        //--------------------------------------------------------------------
        // Memory Type group box
        //--------------------------------------------------------------------
        GroupBox ^miscGetMemoryTypeGroupBox = gcnew GroupBox;
        miscGetMemoryTypeGroupBox->Text = _T("Memory Type");
        miscGetMemoryTypeGroupBox->Location = Point(
            miscI2CGetSetDataRateGroupBox->Right + 10,
            miscI2CGetSetDataRateGroupBox->Top);
        miscGetMemoryTypeGroupBox->Size = Drawing::Size(
            90, miscI2CGetSetDataRateGroupBox->Height);
        //--------------------------------------------------------------------
        // Populate the Memory Type group box
        //--------------------------------------------------------------------
        Button ^miscGetMemoryTypeButton = gcnew Button;
        miscGetMemoryTypeButton->Text = _T("Get");
        miscGetMemoryTypeButton->Location = Point(6, 16);
        miscGetMemoryTypeButton->Size = Drawing::Size(
            GUI_GET_SET_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            miscGetMemoryTypeButton,
            unitNumber);
        miscGetMemoryTypeButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscGetMemoryTypeButtonClicked);
        TextBox ^miscGetMemoryTypeBox = gcnew TextBox;
        miscGetMemoryTypeBox->Location = Point(
            miscGetMemoryTypeButton->Right + 5,
            miscGetMemoryTypeButton->Top + 2);
        miscGetMemoryTypeBox->Size = Drawing::Size(
            34, GUI_REGULAR_TEXT_BOX_HEIGHT);
        miscGetMemoryTypeBox->BackColor = Color::Lavender;
        miscGetMemoryTypeBox->Multiline = GUI_NO;
        miscGetMemoryTypeBox->AcceptsReturn = GUI_NO;
        miscGetMemoryTypeBox->AcceptsTab = GUI_NO;
        miscGetMemoryTypeBox->WordWrap = GUI_NO;
        miscGetMemoryTypeBox->ReadOnly = GUI_YES;
        miscGetMemoryTypeBox->TextAlign = HorizontalAlignment::Center;
        miscGetMemoryTypeBoxArray[unitNumber] = miscGetMemoryTypeBox;
        miscGetMemoryTypeGroupBox->Controls->Add(miscGetMemoryTypeButton);
        miscGetMemoryTypeGroupBox->Controls->Add(miscGetMemoryTypeBox);
        //--------------------------------------------------------------------
        // Get Memory Type tool tip for the button and text box
        //--------------------------------------------------------------------
        ToolTip ^miscGetMemoryTypeToolTip = gcnew ToolTip;
        miscGetMemoryTypeToolTip->ShowAlways = GUI_YES;
        miscGetMemoryTypeToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        miscGetMemoryTypeToolTip->ToolTipTitle = _T("Memory Type");
        String ^miscGetMemoryTypeToolTipText = String::Concat(
            "Displays the transducer memory type if a digital", Environment::NewLine,
            "transducer is attached to this module, or the QCOM", Environment::NewLine,
            "module memory type otherwise, as follows:", Environment::NewLine,
            "0x00 = No memory present", Environment::NewLine,
            "0x01 = FRAM type", Environment::NewLine,
            "0x02 = EEPROM type");
        miscGetMemoryTypeToolTip->SetToolTip(miscGetMemoryTypeBox, miscGetMemoryTypeToolTipText);
        miscGetMemoryTypeToolTip->SetToolTip(miscGetMemoryTypeButton, miscGetMemoryTypeToolTipText);
        miscGetMemoryTypeToolTip->SetToolTip(miscGetMemoryTypeGroupBox, miscGetMemoryTypeToolTipText);
        delete miscGetMemoryTypeToolTipText;
        miscGetMemoryTypeGroupBoxArray[unitNumber] = miscGetMemoryTypeGroupBox;
        //--------------------------------------------------------------------
        // I�C Commands group box
        //--------------------------------------------------------------------
        GroupBox ^miscI2CSendGroupBox = gcnew GroupBox;
        miscI2CSendGroupBox->Text = _T("Send I�C Command");
        miscI2CSendGroupBox->Location = Point(
            miscGetModuleSerialNumberGroupBox->Left,
            miscGetModuleSerialNumberGroupBox->Bottom + 10); // 80);
        miscI2CSendGroupBox->Size = Drawing::Size(410, 280);
        //--------------------------------------------------------------------
        // Populate the I�C Commands group box
        //--------------------------------------------------------------------
        Label ^miscI2CCommandLabel = gcnew Label;
        miscI2CCommandLabel->Text = _T("Command:");
        miscI2CCommandLabel->Location = Point(10, 22);
        miscI2CCommandLabel->Size = Drawing::Size(60, GUI_REGULAR_LABEL_HEIGHT);
        miscI2CCommandLabel->BackColor = Color::Transparent;
        ComboBox ^miscI2CCommandCombo = gcnew ComboBox;
        miscI2CCommandCombo->Tag = unitNumber;
        miscI2CCommandCombo->Location = Point(
            miscI2CCommandLabel->Right + 2,
            miscI2CCommandLabel->Top - 2);
        miscI2CCommandCombo->Size = Drawing::Size(
            miscI2CSendGroupBox->Width - 130,
            GUI_REGULAR_COMBO_BOX_HEIGHT);
        miscI2CCommandCombo->MaxDropDownItems = 8;
        miscI2CCommandCombo->FormattingEnabled = GUI_YES;
        miscI2CCommandCombo->BackColor = Color::White;
        GUI_DisplayHandCursorOnHover(miscI2CCommandCombo);
        miscI2CCommandCombo->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscClearI2CCommandBox);
        miscI2CCommandCombo->PreviewKeyDown +=
            gcnew PreviewKeyDownEventHandler(this, &QCOM_GUIClass::QCOM_ComboBoxAcceptEnterKey);
        miscI2CCommandCombo->KeyDown +=
            gcnew KeyEventHandler(this, &QCOM_GUIClass::QCOM_MiscProcessI2CCommandBoxEnterKey);
        if ((unit->transducerChipID[2] >= 4) && (unit->transducerChipID[3] >= 2))
        {
            //----------------------------------------------------------------
            // The ASIC is version 4.02 or later, so request checksums
            //----------------------------------------------------------------
            array <String ^> ^defaultI2CListWithChecksum =
            {
                (transducerIsAnalog ? _T("S99FFFFFFFFFFP [ Read Pres w/chk ]")         : _T("S9DFFFFFFFFFFP [ Read Pres w/chk ]")),
                (transducerIsAnalog ? _T("S9BFFFFFFFFFFP [ Read Temp w/chk ]")         : _T("S9FFFFFFFFFFFP [ Read Temp w/chk ]")),
                (transducerIsAnalog ? _T("S98R9BFFFFFFFFP [ Read XD status ]")         : _T("S9CR9FFFFFFFFFP [ Read XD status ]")),
                (transducerIsAnalog ? _T("S98R99FFFFFFFFFFP [ Get chip ID w/chk ]")    : _T("S9CR9DFFFFFFFFFFP [ Get chip ID w/chk ]")),
                (transducerIsAnalog ? _T("S99FFP [ Poll for ACK ]")                    : _T("S9DFFP [ Poll for ACK ]")),
                (transducerWithNoMemory ? _T("SA3FFFFFFP [ Read QCOM curr addr ]")     : _T("SADFFFFFFP [ Read ASIC curr addr ]")),
                (transducerWithNoMemory ? _T("SA20000RA3FFP [ Read QCOM mem ]")        : _T("SAC0000RADFFP [ Read XD mem ]")),
                (transducerWithNoMemory ? _T("S981FP [ Unlock QCOM mem ]")             : _T("S9C1FP [ Unlock XD mem ]")),
                (transducerWithNoMemory ? _T("S983FP [ Lock QCOM mem ]")               : _T("S9C3FP [ Lock XD mem ]")),
                (transducerWithNoMemory ? _T("SA20000XXP [ Write XX to QCOM mem ]")    : _T("SAC0000XXP [ Write XX to XD mem ]")),
                (transducerWithNoMemory ? _T("S983FC0P [ Change ref to 1 kHz ]")       : _T("S9C3FC0P [ Change ref to 1 kHz ]")),
                (transducerWithNoMemory ? _T("S983FC8P [ Change ref to 7.2 MHz ]")     : _T("S9C3FC8P [ Change ref to 7.2 MHz ]"))
            };
            miscI2CCommandCombo->Items->AddRange(defaultI2CListWithChecksum);
            miscI2CCommandCombo->Text = defaultI2CListWithChecksum[0];
        }
        else
        {
            array <String ^> ^defaultI2CList =
            {
                (transducerIsAnalog ? _T("S99FFFFFFFFP [ Read Pres w/o chk ]")         : _T("S9DFFFFFFFFP [ Read Pres w/o chk ]")),
                (transducerIsAnalog ? _T("S9BFFFFFFFFP [ Read Temp w/o chk ]")         : _T("S9FFFFFFFFFP [ Read Temp w/o chk ]")),
                (transducerIsAnalog ? _T("S98R9BFFFFP [ Read XD status ]")             : _T("S9CR9FFFFFP [ Read XD status ]")),
                (transducerIsAnalog ? _T("S98R99FFFFFFFFP [ Get chip ID w/o chk ]")    : _T("S9CR9DFFFFFFFFP [ Get chip ID w/o chk ]")),
                (transducerIsAnalog ? _T("S99FFP [ Poll for ACK ]")                    : _T("S9DFFP [ Poll for ACK ]")),
                (transducerWithNoMemory ? _T("SA3FFFFFFP [ Read QCOM curr addr ]")     : _T("SADFFFFFFP [ Read ASIC curr addr ]")),
                (transducerWithNoMemory ? _T("SA20000RA3FFP [ Read QCOM mem ]")        : _T("SAC0000RADFFP [ Read XD mem ]")),
                (transducerWithNoMemory ? _T("S981FP [ Unlock QCOM mem ]")             : _T("S9C1FP [ Unlock XD mem ]")),
                (transducerWithNoMemory ? _T("S983FP [ Lock QCOM mem ]")               : _T("S9C3FP [ Lock XD mem ]")),
                (transducerWithNoMemory ? _T("SA20000XXP [ Write XX to QCOM mem ]")    : _T("SAC0000XXP [ Write XX to XD mem ]")),
                (transducerWithNoMemory ? _T("S983FC0P [ Change ref to 1 kHz ]")       : _T("S9C3FC0P [ Change ref to 1 kHz ]")),
                (transducerWithNoMemory ? _T("S983FC8P [ Change ref to 7.2 MHz ]")     : _T("S9C3FC8P [ Change ref to 7.2 MHz ]"))
            };
            miscI2CCommandCombo->Items->AddRange(defaultI2CList);
            miscI2CCommandCombo->Text = defaultI2CList[0];
        }
        miscI2CCommandComboArray[unitNumber] = miscI2CCommandCombo;
        Button ^miscI2CCommandSendButton = gcnew Button;
        miscI2CCommandSendButton->Text = _T("Send");
        miscI2CCommandSendButton->Location = Point(
            miscI2CSendGroupBox->Width - 55,
            miscI2CCommandLabel->Top - 5);
        miscI2CCommandSendButton->Size = Drawing::Size(40, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            miscI2CCommandSendButton,
            unitNumber);
        miscI2CCommandSendButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscSendI2CCommandButtonClicked);
        miscI2CSendButtonArray[unitNumber] = miscI2CCommandSendButton;
        Label ^miscI2CResponseLabel = gcnew Label;
        miscI2CResponseLabel->Text = _T("Response:");
        miscI2CResponseLabel->Location = Point(
            miscI2CCommandLabel->Left,
            miscI2CCommandCombo->Bottom + 4);
        miscI2CResponseLabel->Size = Drawing::Size(60, GUI_REGULAR_LABEL_HEIGHT);
        miscI2CResponseLabel->BackColor = Color::Transparent;
        Label ^miscI2CReplyInterpLabel = gcnew Label;
        miscI2CReplyInterpLabel->Location = Point(
            miscI2CResponseLabel->Right + 10,
            miscI2CResponseLabel->Top);
        miscI2CReplyInterpLabel->Size = Drawing::Size(
            miscI2CSendGroupBox->Width - 90,
            miscI2CResponseLabel->Height);
        miscI2CReplyInterpLabel->BackColor = Color::Transparent;
        miscI2CReplyInterpLabel->Visible = GUI_NO;
        miscI2CReplyInterpLabelArray[unitNumber] = miscI2CReplyInterpLabel;
        TextBox ^miscI2CResponseBox = gcnew TextBox;
        miscI2CResponseBox->Location = Point(
            miscI2CCommandLabel->Left,
            miscI2CResponseLabel->Bottom + 2);
        miscI2CResponseBox->Size = Drawing::Size(
            miscI2CSendGroupBox->Width - 20,
            miscI2CSendGroupBox->Height - 70);
        miscI2CResponseBox->MaxLength = 600;
        miscI2CResponseBox->Multiline = GUI_YES;
        miscI2CResponseBox->ReadOnly = GUI_YES;
        miscI2CResponseBox->ScrollBars = ScrollBars::Vertical;
        miscI2CResponseBox->AcceptsReturn = GUI_YES;
        miscI2CResponseBox->AcceptsTab = GUI_YES;
        miscI2CResponseBox->WordWrap = GUI_YES;
        miscI2CResponseBox->BackColor = Color::Lavender;
        miscI2CResponseBox->Font = gcnew Drawing::Font(
            FontFamily::GenericMonospace,
            8.0F,
            FontStyle::Regular);
/*
miscI2CResponseBox->Text = String::Concat(
    "00 88 88 88 88 88 88 88 88 88 88 88 88 88 88 88X", Environment::NewLine,
    "10 11 88 88 88 88 88 88 88 88 88 88 88 88 88 88X", Environment::NewLine,
    "20 88 22 88 88 88 88 88 88 88 88 88 88 88 88 88X", Environment::NewLine,
    "30 88 88 33 88 88 88 88 88 88 88 88 88 88 88 88X", Environment::NewLine,
    "40 88 88 88 44 88 88 88 88 88 88 88 88 88 88 88X", Environment::NewLine,
    "50 88 88 88 88 55 88 88 88 88 88 88 88 88 88 88X", Environment::NewLine,
    "60 88 88 88 88 88 66 88 88 88 88 88 88 88 88 88X", Environment::NewLine,
    "70 88 88 88 88 88 88 77 88 88 88 88 88 88 88 88X", Environment::NewLine,
    "80 88 88 88 88 88 88 88 88 88 88 88 88 88 88 88X", Environment::NewLine,
    "90 88 88 88 88 88 88 88 88 99 88 88 88 88 88 88X", Environment::NewLine,
    "A0 88 88 88 88 88 88 88 88 88 AA 88 88 88 88 88X", Environment::NewLine,
    "B0 88 88 88 88 88 88 88 88 88 88 BB 88 88 88 88X", Environment::NewLine,
    "C0 88 88 88 88 88 88 88 88 88 88 88 CC 88 88 88X", Environment::NewLine,
    "D0 88 88 88 88 88 88 88 88 88 88 88 88 DD 88 88X", Environment::NewLine,
    "E0 88 88 88 88 88 88 88 88 88 88 88 88 88 EE 88X", Environment::NewLine,
    "F0 88 88 88 88 88 88 88 88 88 88 88 88 88 88 FFE"
    );
*/
        miscI2CResponseBoxArray[unitNumber] = miscI2CResponseBox;
        miscI2CSendGroupBox->BackColor = Color::Transparent;
        miscI2CSendGroupBox->Controls->Add(miscI2CCommandSendButton);
        miscI2CSendGroupBox->Controls->Add(miscI2CCommandCombo);
        miscI2CSendGroupBox->Controls->Add(miscI2CResponseBox);
        array <Label ^> ^sendI2CGBLabels =
        {
            miscI2CCommandLabel,
            miscI2CResponseLabel,
            miscI2CReplyInterpLabel
        };
        miscI2CSendGroupBox->Controls->AddRange(sendI2CGBLabels);
        //--------------------------------------------------------------------
        // I�C Commands tool tip for the buttons and text box
        //--------------------------------------------------------------------
        ToolTip ^miscI2CSendToolTip = gcnew ToolTip;
        miscI2CSendToolTip->ShowAlways = GUI_YES;
        miscI2CSendToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        miscI2CSendToolTip->ToolTipTitle =
            _T("Send I�C Command");
        String ^miscI2CSendToolTipText = String::Concat(
            "Allows you to send an I�C command to the QCOM", Environment::NewLine,
            "module or the transducer, then displays the response.", Environment::NewLine,
            "The ER= response indicates the error number returned", Environment::NewLine,
            "from the I�C processor in the case of an error.", Environment::NewLine,
            "Responses ending in NP indicate an unknown error.");
        miscI2CSendToolTip->SetToolTip(miscI2CCommandLabel, miscI2CSendToolTipText);
        miscI2CSendToolTip->SetToolTip(miscI2CCommandCombo, miscI2CSendToolTipText);
        miscI2CSendToolTip->SetToolTip(miscI2CCommandSendButton, miscI2CSendToolTipText);
        miscI2CSendToolTip->SetToolTip(miscI2CReplyInterpLabel, miscI2CSendToolTipText);
        miscI2CSendToolTip->SetToolTip(miscI2CResponseBox, miscI2CSendToolTipText);
        miscI2CSendToolTip->SetToolTip(miscI2CSendGroupBox, miscI2CSendToolTipText);
        delete miscI2CSendToolTipText;
        miscI2CSendCommandGroupBoxArray[unitNumber] = miscI2CSendGroupBox;
        //--------------------------------------------------------------------
        // Status Register group box
        //--------------------------------------------------------------------
        GroupBox ^miscGetStatusRegisterGroupBox = gcnew GroupBox;
        miscGetStatusRegisterGroupBox->Text = _T("Status Register");
        miscGetStatusRegisterGroupBox->Location = Point(
            miscI2CSendGroupBox->Right + 10,
            miscI2CGetSetDataRateGroupBox->Top);
        miscGetStatusRegisterGroupBox->Size =
            Drawing::Size(120, miscI2CGetSetDataRateGroupBox->Height);
        //--------------------------------------------------------------------
        // Populate the Status Register group box
        //--------------------------------------------------------------------
        Button ^miscGetStatusRegisterButton = gcnew Button;
        miscGetStatusRegisterButton->Text = _T("Get");
        miscGetStatusRegisterButton->Location = Point(6, 16);
        miscGetStatusRegisterButton->Size = miscGetMemoryTypeButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            miscGetStatusRegisterButton,
            unitNumber);
        miscGetStatusRegisterButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscGetStatusRegisterButtonClicked);
        TextBox ^miscGetStatusRegisterBox = gcnew TextBox;
        miscGetStatusRegisterBox->Location = Point(
            miscGetStatusRegisterButton->Right + 5,
            miscGetStatusRegisterButton->Top + 2);
        miscGetStatusRegisterBox->Size = miscGetMemoryTypeBox->Size;
        miscGetStatusRegisterBox->BackColor = Color::Lavender;
        miscGetStatusRegisterBox->Multiline = GUI_NO;
        miscGetStatusRegisterBox->AcceptsReturn = GUI_NO;
        miscGetStatusRegisterBox->AcceptsTab = GUI_NO;
        miscGetStatusRegisterBox->WordWrap = GUI_NO;
        miscGetStatusRegisterBox->ReadOnly = GUI_YES;
        miscGetStatusRegisterBox->TextAlign = HorizontalAlignment::Center;
        miscGetStatusRegisterBoxArray[unitNumber] = miscGetStatusRegisterBox;
        miscGetStatusRegisterGroupBox->Controls->Add(miscGetStatusRegisterButton);
        miscGetStatusRegisterGroupBox->Controls->Add(miscGetStatusRegisterBox);
        miscGetStatusRegisterGroupBox->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Status Register tool tip for the button and text box
        //--------------------------------------------------------------------
        ToolTip ^miscStatusRegisterToolTip = gcnew ToolTip;
        miscStatusRegisterToolTip->ShowAlways = GUI_YES;
        miscStatusRegisterToolTip->AutoPopDelay = 10000;    // let stand for ten seconds
        miscStatusRegisterToolTip->ToolTipTitle =
            _T("Module Status Register Value Bitmap");
        String ^miscStatusRegisterToolTipText = String::Concat(
            "Bit 7 : Module error detected", Environment::NewLine,
            "Bit 6 : High-side switch over-current or thermal shutdown detected", Environment::NewLine,
            "Bit 5 : Transducer power is enabled", Environment::NewLine,
            "Bit 4 : Transducer is in an over-current condition", Environment::NewLine,
            "Bit 3 : Transducer is present", Environment::NewLine,
            "Bits 2 - 0 : Transducer type, as follows:", Environment::NewLine,
            "        000 = Transducer is absent or has an unknown type", Environment::NewLine,
            "        001 = Frequency (analog) transducer", Environment::NewLine,
            "        010 = Pre-FireFly digital transducer, with memory", Environment::NewLine,
            "        011 = FireFly digital transducer, with Vref", Environment::NewLine,
            "        100 = FireFly digital transducer, without Vref", Environment::NewLine,
            "        101 = Digital transducer, without memory");
        miscStatusRegisterToolTip->SetToolTip(miscGetStatusRegisterBox, miscStatusRegisterToolTipText);
        miscStatusRegisterToolTip->SetToolTip(miscGetStatusRegisterButton, miscStatusRegisterToolTipText);
        miscStatusRegisterToolTip->SetToolTip(miscGetStatusRegisterGroupBox, miscStatusRegisterToolTipText);
        delete miscStatusRegisterToolTipText;
        miscGetStatusRegisterGroupBoxArray[unitNumber] = miscGetStatusRegisterGroupBox;
        //--------------------------------------------------------------------
        // Control Register group box
        //--------------------------------------------------------------------
        GroupBox ^miscGetControlRegisterGroupBox = gcnew GroupBox;
        miscGetControlRegisterGroupBox->Text = _T("Control Register");
        miscGetControlRegisterGroupBox->Location = Point(
            miscGetStatusRegisterGroupBox->Left,
            miscGetStatusRegisterGroupBox->Bottom + 10);
        miscGetControlRegisterGroupBox->Size = miscGetStatusRegisterGroupBox->Size;
        //--------------------------------------------------------------------
        // Populate the Control Register group box
        //--------------------------------------------------------------------
        Button ^miscGetControlRegisterButton = gcnew Button;
        miscGetControlRegisterButton->Text = _T("Get");
        miscGetControlRegisterButton->Location = Point(6, 16);
        miscGetControlRegisterButton->Size = miscGetStatusRegisterButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            miscGetControlRegisterButton,
            unitNumber);
        miscGetControlRegisterButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscGetControlRegisterButtonClicked);
        TextBox ^miscGetControlRegisterBox = gcnew TextBox;
        miscGetControlRegisterBox->Location = Point(
            miscGetControlRegisterButton->Right + 5,
            miscGetControlRegisterButton->Top + 2);
        miscGetControlRegisterBox->Size = miscGetStatusRegisterBox->Size;
        miscGetControlRegisterBox->Multiline = GUI_NO;
        miscGetControlRegisterBox->AcceptsReturn = GUI_NO;
        miscGetControlRegisterBox->AcceptsTab = GUI_NO;
        miscGetControlRegisterBox->WordWrap = GUI_NO;
        miscGetControlRegisterBox->TextAlign = HorizontalAlignment::Center;
        miscGetControlRegisterBox->BackColor = Color::White;
        miscGetControlRegisterBoxArray[unitNumber] = miscGetControlRegisterBox;
        Button ^miscSetControlRegisterButton = gcnew Button;
        miscSetControlRegisterButton->Text = _T("Set");
        miscSetControlRegisterButton->Location = Point(
            miscGetControlRegisterBox->Right + 7,
            miscGetControlRegisterButton->Top);
        miscSetControlRegisterButton->Size = miscGetControlRegisterButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            miscSetControlRegisterButton,
            unitNumber);
        miscSetControlRegisterButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscSetControlRegisterButtonClicked);
        miscGetControlRegisterGroupBox->BackColor = Color::Transparent;
        miscGetControlRegisterGroupBox->Controls->Add(miscGetControlRegisterButton);
        miscGetControlRegisterGroupBox->Controls->Add(miscGetControlRegisterBox);
        miscGetControlRegisterGroupBox->Controls->Add(miscSetControlRegisterButton);
        //--------------------------------------------------------------------
        // Control Register tool tip for the buttons and text box
        //--------------------------------------------------------------------
        ToolTip ^miscControlRegisterToolTip = gcnew ToolTip;
        miscControlRegisterToolTip->ShowAlways = GUI_YES;
        miscControlRegisterToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        miscControlRegisterToolTip->ToolTipTitle =
            _T("Module Control Register Value Bitmap");
        String ^miscControlRegisterToolTipText = String::Concat(
            "Bits 7 - 2 : Reserved", Environment::NewLine,
            "Bit 1 : Automatically copy the coefficient data of the newly", Environment::NewLine,
            "           attached digital transducer into QCOM module memory", Environment::NewLine,
            "Bit 0 : Reserved");
        miscControlRegisterToolTip->SetToolTip(miscGetControlRegisterBox, miscControlRegisterToolTipText);
        miscControlRegisterToolTip->SetToolTip(miscGetControlRegisterButton, miscControlRegisterToolTipText);
        miscControlRegisterToolTip->SetToolTip(miscSetControlRegisterButton, miscControlRegisterToolTipText);
        miscControlRegisterToolTip->SetToolTip(miscGetControlRegisterGroupBox, miscControlRegisterToolTipText);
        delete miscControlRegisterToolTipText;
        miscGetControlRegisterGroupBoxArray[unitNumber] = miscGetControlRegisterGroupBox;
        //--------------------------------------------------------------------
        // Internal Error Code group box
        //--------------------------------------------------------------------
        GroupBox ^miscGetErrorCodeGroupBox = gcnew GroupBox;
        miscGetErrorCodeGroupBox->Text = _T("Internal Error Code");
        miscGetErrorCodeGroupBox->Location = Point(
            miscGetStatusRegisterGroupBox->Right + 10,
            miscI2CGetSetDataRateGroupBox->Top);
        miscGetErrorCodeGroupBox->Size = Drawing::Size(
            150, miscI2CGetSetDataRateGroupBox->Height);
        //--------------------------------------------------------------------
        // Populate the Internal Error Code group box
        //--------------------------------------------------------------------
        Button ^miscGetErrorCodeButton = gcnew Button;
        miscGetErrorCodeButton->Text = _T("Read");
        miscGetErrorCodeButton->Location = Point(6, 16);
        miscGetErrorCodeButton->Size = Drawing::Size(
            40, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            miscGetErrorCodeButton,
            unitNumber);
        miscGetErrorCodeButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscReadErrorCodeButtonClicked);
        TextBox ^miscGetErrorCodeBox = gcnew TextBox;
        miscGetErrorCodeBox->Location = Point(
            miscGetErrorCodeButton->Right + 5,
            miscGetErrorCodeButton->Top + 2);
        miscGetErrorCodeBox->Size = Drawing::Size(
            42, GUI_REGULAR_TEXT_BOX_HEIGHT);
        miscGetErrorCodeBox->BackColor = Color::Lavender;
        miscGetErrorCodeBox->Multiline = GUI_NO;
        miscGetErrorCodeBox->AcceptsReturn = GUI_NO;
        miscGetErrorCodeBox->AcceptsTab = GUI_NO;
        miscGetErrorCodeBox->WordWrap = GUI_NO;
        miscGetErrorCodeBox->ReadOnly = GUI_YES;
        miscGetErrorCodeBox->TextAlign = HorizontalAlignment::Center;
        miscGetErrorCodeBoxArray[unitNumber] = miscGetErrorCodeBox;
        Button ^miscClearErrorCodeButton = gcnew Button;
        miscClearErrorCodeButton->Text = _T("Clear");
        miscClearErrorCodeButton->Location = Point(
            miscGetErrorCodeBox->Right + 7,
            miscGetErrorCodeButton->Top);
        miscClearErrorCodeButton->Size = Drawing::Size(
            40, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            miscClearErrorCodeButton,
            unitNumber);
        miscClearErrorCodeButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscClearErrorCodeButtonClicked);
        miscGetErrorCodeGroupBox->BackColor = Color::Transparent;
        miscGetErrorCodeGroupBox->Controls->Add(miscGetErrorCodeBox);
        miscGetErrorCodeGroupBox->Controls->Add(miscGetErrorCodeButton);
        miscGetErrorCodeGroupBox->Controls->Add(miscClearErrorCodeButton);
        //--------------------------------------------------------------------
        // Get Internal Error Code tool tip for all objects in the group box
        //--------------------------------------------------------------------
        ToolTip ^miscGetErrorCodeToolTip = gcnew ToolTip;
        miscGetErrorCodeToolTip->ShowAlways = GUI_YES;
        miscGetErrorCodeToolTip->AutoPopDelay = 10000;      // let stand for ten seconds
        miscGetErrorCodeToolTip->ToolTipTitle = _T("Module Internal Error Code");
        String ^miscGetErrorCodeToolTipText = String::Concat(
            "Displays or clears the error code", Environment::NewLine,
            "that is internal to the QCOM module.", Environment::NewLine,
            "0x0002 - 0xFFFF : Reserved", Environment::NewLine,
            "0x0001 : Transducer over-current has occurred");
        miscGetErrorCodeToolTip->SetToolTip(miscGetErrorCodeBox, miscGetErrorCodeToolTipText);
        miscGetErrorCodeToolTip->SetToolTip(miscGetErrorCodeButton, miscGetErrorCodeToolTipText);
        miscGetErrorCodeToolTip->SetToolTip(miscClearErrorCodeButton, miscGetErrorCodeToolTipText);
        miscGetErrorCodeToolTip->SetToolTip(miscGetErrorCodeGroupBox, miscGetErrorCodeToolTipText);
        delete miscGetErrorCodeToolTipText;
        miscGetErrorCodeGroupBoxArray[unitNumber] = miscGetErrorCodeGroupBox;
        //--------------------------------------------------------------------
        // Cadence Timer group box
        //--------------------------------------------------------------------
        GroupBox ^miscGetCadenceTimerGroupBox = gcnew GroupBox;
        miscGetCadenceTimerGroupBox->Text = _T("Cadence Timer");
        miscGetCadenceTimerGroupBox->Location = Point(
            miscGetControlRegisterGroupBox->Right + 10,
            miscGetControlRegisterGroupBox->Top);
        miscGetCadenceTimerGroupBox->Size = Drawing::Size(
            150, miscI2CGetSetDataRateGroupBox->Height);
        //--------------------------------------------------------------------
        // Populate the Cadence Timer group box
        //--------------------------------------------------------------------
        Button ^miscGetCadenceTimerButton = gcnew Button;
        miscGetCadenceTimerButton->Text = _T("Read");
        miscGetCadenceTimerButton->Location = Point(6, 16);
        miscGetCadenceTimerButton->Size = Drawing::Size(
            40, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(miscGetCadenceTimerButton, unitNumber);
        miscGetCadenceTimerButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscReadCadenceTimerButtonClicked);
        TextBox ^miscGetCadenceTimerBox = gcnew TextBox;
        miscGetCadenceTimerBox->Location = Point(
            miscGetCadenceTimerButton->Right + 5,
            miscGetCadenceTimerButton->Top + 2);
        miscGetCadenceTimerBox->Size = miscGetControlRegisterBox->Size;
        miscGetCadenceTimerBox->BackColor = Color::White;
        miscGetCadenceTimerBox->Multiline = GUI_NO;
        miscGetCadenceTimerBox->AcceptsReturn = GUI_NO;
        miscGetCadenceTimerBox->AcceptsTab = GUI_NO;
        miscGetCadenceTimerBox->WordWrap = GUI_NO;
        miscGetCadenceTimerBox->TextAlign = HorizontalAlignment::Right;
        miscGetCadenceTimerBoxArray[unitNumber] = miscGetCadenceTimerBox;
        Label ^miscGetCadenceTimerLabel = gcnew Label;
        miscGetCadenceTimerLabel->Text = _T("ms");
        miscGetCadenceTimerLabel->Location = Point(
            miscGetCadenceTimerBox->Right + 2,
            miscGetCadenceTimerBox->Top + 3);
        miscGetCadenceTimerLabel->Size = Drawing::Size(
            20, GUI_REGULAR_LABEL_HEIGHT);
        miscGetCadenceTimerLabel->BackColor = Color::Transparent;
        Button ^miscSetCadenceTimerButton = gcnew Button;
        miscSetCadenceTimerButton->Text = _T("Set");
        miscSetCadenceTimerButton->Location = Point(
            110, miscGetCadenceTimerButton->Top);
        miscSetCadenceTimerButton->Size = miscGetControlRegisterButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            miscSetCadenceTimerButton,
            unitNumber);
        miscSetCadenceTimerButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscSetCadenceTimerButtonClicked);
        miscGetCadenceTimerGroupBox->BackColor = Color::Transparent;
        miscGetCadenceTimerGroupBox->Controls->Add(miscGetCadenceTimerButton);
        miscGetCadenceTimerGroupBox->Controls->Add(miscSetCadenceTimerButton);
        miscGetCadenceTimerGroupBox->Controls->Add(miscGetCadenceTimerBox);
        miscGetCadenceTimerGroupBox->Controls->Add(miscGetCadenceTimerLabel);
        //--------------------------------------------------------------------
        // Cadence Timer tool tip for the buttons and text box
        //--------------------------------------------------------------------
        ToolTip ^miscCadenceTimerToolTip = gcnew ToolTip;
        miscCadenceTimerToolTip->ShowAlways = GUI_YES;
        miscCadenceTimerToolTip->AutoPopDelay = 10000;      // let stand for ten seconds
        miscCadenceTimerToolTip->ToolTipTitle =
            _T("Cadence Timer");
        String ^miscCadenceTimerToolTipText = String::Concat(
            "The cadence timer controls how often the", Environment::NewLine,
            "QCOM module queries the transducer to", Environment::NewLine,
            "keep the transducer's counts refreshed.", Environment::NewLine,
            "Minimum = ", QD_MINIMUM_CADENCE_TIMER_MS, " ms", Environment::NewLine,
            "Maximum = ", QD_MAXIMUM_CADENCE_TIMER_MS, " ms", Environment::NewLine,
            "Default = ", QD_MAXIMUM_CADENCE_TIMER_MS, " ms");
        miscCadenceTimerToolTip->SetToolTip(miscGetCadenceTimerBox, miscCadenceTimerToolTipText);
        miscCadenceTimerToolTip->SetToolTip(miscGetCadenceTimerButton, miscCadenceTimerToolTipText);
        miscCadenceTimerToolTip->SetToolTip(miscGetCadenceTimerLabel, miscCadenceTimerToolTipText);
        miscCadenceTimerToolTip->SetToolTip(miscSetCadenceTimerButton, miscCadenceTimerToolTipText);
        miscCadenceTimerToolTip->SetToolTip(miscGetCadenceTimerGroupBox, miscCadenceTimerToolTipText);
        delete miscCadenceTimerToolTipText;
        miscGetCadenceTimerGroupBoxArray[unitNumber] = miscGetCadenceTimerGroupBox;
        //--------------------------------------------------------------------
        // Transducer Type group box
        //--------------------------------------------------------------------
        GroupBox ^miscGetTransducerTypeGroupBox = gcnew GroupBox;
        miscGetTransducerTypeGroupBox->Text = _T("Transducer Type");
        miscGetTransducerTypeGroupBox->Location = Point(
            miscGetControlRegisterGroupBox->Left,
            miscGetControlRegisterGroupBox->Bottom + 10);
        miscGetTransducerTypeGroupBox->Size = miscGetControlRegisterGroupBox->Size;
        //--------------------------------------------------------------------
        // Populate the Transducer Type group box
        //--------------------------------------------------------------------
        Button ^miscGetTransducerTypeButton = gcnew Button;
        miscGetTransducerTypeButton->Text = _T("Get");
        miscGetTransducerTypeButton->Location = Point(6, 16);
        miscGetTransducerTypeButton->Size = miscGetControlRegisterButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            miscGetTransducerTypeButton,
            unitNumber);
        miscGetTransducerTypeButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscGetTransducerTypeButtonClicked);
        TextBox ^miscGetTransducerTypeBox = gcnew TextBox;
        miscGetTransducerTypeBox->Location = Point(
            miscGetTransducerTypeButton->Right + 5,
            miscGetTransducerTypeButton->Top + 2);
        miscGetTransducerTypeBox->Size = miscGetControlRegisterBox->Size;
        miscGetTransducerTypeBox->BackColor = Color::Lavender;
        miscGetTransducerTypeBox->Multiline = GUI_NO;
        miscGetTransducerTypeBox->AcceptsReturn = GUI_NO;
        miscGetTransducerTypeBox->AcceptsTab = GUI_NO;
        miscGetTransducerTypeBox->WordWrap = GUI_NO;
        miscGetTransducerTypeBox->ReadOnly = GUI_YES;
        miscGetTransducerTypeBox->TextAlign = HorizontalAlignment::Center;
        miscGetTransducerTypeBoxArray[unitNumber] = miscGetTransducerTypeBox;
        miscGetTransducerTypeGroupBox->Controls->Add(miscGetTransducerTypeButton);
        miscGetTransducerTypeGroupBox->Controls->Add(miscGetTransducerTypeBox);
        //--------------------------------------------------------------------
        // Transducer Type tool tip for the button and text box
        //--------------------------------------------------------------------
        ToolTip ^miscGetTransducerTypeToolTip = gcnew ToolTip;
        miscGetTransducerTypeToolTip->ShowAlways = GUI_YES;
        miscGetTransducerTypeToolTip->AutoPopDelay = 10000; // let stand for ten seconds
        miscGetTransducerTypeToolTip->ToolTipTitle =
            _T("Attached Transducer Type");
        String ^miscGetTransducerTypeToolTipText = String::Concat(
            "0x00 = Transducer is absent", Environment::NewLine,
            "0x01 = Frequency (analog) transducer", Environment::NewLine,
            "0x02 = Pre-FireFly digital transducer, with memory", Environment::NewLine,
            "0x03 = FireFly digital transducer, with Vref", Environment::NewLine,
            "0x04 = FireFly digital transducer, without Vref", Environment::NewLine,
            "0x05 = Digital transducer, with no memory");
        miscGetTransducerTypeToolTip->SetToolTip(miscGetTransducerTypeBox, miscGetTransducerTypeToolTipText);
        miscGetTransducerTypeToolTip->SetToolTip(miscGetTransducerTypeButton, miscGetTransducerTypeToolTipText);
        miscGetTransducerTypeToolTip->SetToolTip(miscGetTransducerTypeGroupBox, miscGetTransducerTypeToolTipText);
        delete miscGetTransducerTypeToolTipText;
        miscGetTransducerTypeGroupBoxArray[unitNumber] = miscGetTransducerTypeGroupBox;
        //--------------------------------------------------------------------
        // Module Firmware ID group box
        //--------------------------------------------------------------------
        GroupBox ^miscGetFirmwareIDGroupBox = gcnew GroupBox;
        miscGetFirmwareIDGroupBox->Text = _T("Module Firmware ID");
        miscGetFirmwareIDGroupBox->Location = Point(
            miscGetCadenceTimerGroupBox->Left,
            miscGetCadenceTimerGroupBox->Bottom + 10);
        miscGetFirmwareIDGroupBox->Size = miscGetCadenceTimerGroupBox->Size;
        //--------------------------------------------------------------------
        // Populate the Firmware ID group box
        //--------------------------------------------------------------------
        Button ^miscGetFirmwareIDButton = gcnew Button;
        miscGetFirmwareIDButton->Text = _T("Get");
        miscGetFirmwareIDButton->Location = Point(6, 16);
        miscGetFirmwareIDButton->Size = Drawing::Size(
            30, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            miscGetFirmwareIDButton,
            unitNumber);
        miscGetFirmwareIDButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscGetFirmwareIDButtonClicked);
        TextBox ^miscGetFirmwareIDBox = gcnew TextBox;
        miscGetFirmwareIDBox->Location = Point(
            miscGetFirmwareIDButton->Right + 5,
            miscGetFirmwareIDButton->Top + 2);
        miscGetFirmwareIDBox->Size = Drawing::Size(
            80, GUI_REGULAR_TEXT_BOX_HEIGHT);
        miscGetFirmwareIDBox->BackColor = Color::Lavender;
        miscGetFirmwareIDBox->Multiline = GUI_NO;
        miscGetFirmwareIDBox->AcceptsReturn = GUI_NO;
        miscGetFirmwareIDBox->AcceptsTab = GUI_NO;
        miscGetFirmwareIDBox->WordWrap = GUI_NO;
        miscGetFirmwareIDBox->ReadOnly = GUI_YES;
        miscGetFirmwareIDBox->TextAlign = HorizontalAlignment::Center;
        miscGetFirmwareIDBoxArray[unitNumber] = miscGetFirmwareIDBox;
        miscGetFirmwareIDGroupBox->Controls->Add(miscGetFirmwareIDButton);
        miscGetFirmwareIDGroupBox->Controls->Add(miscGetFirmwareIDBox);
        //--------------------------------------------------------------------
        // Firmware ID tool tip for the button and text box
        //--------------------------------------------------------------------
        ToolTip ^miscGetFirmwareIDToolTip = gcnew ToolTip;
        miscGetFirmwareIDToolTip->ShowAlways = GUI_YES;
        miscGetFirmwareIDToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
        miscGetFirmwareIDToolTip->ToolTipTitle =
            _T("Module Firmware ID Bytes");
        String ^miscGetFirmwareIDToolTipText = String::Concat(
            "0D = Produced by Quartzdyne", Environment::NewLine,
            "16 = QCOM firmware", Environment::NewLine,
            "01 = Major version number", Environment::NewLine,
            "02 = Minor version number");
        miscGetFirmwareIDToolTip->SetToolTip(miscGetFirmwareIDBox, miscGetFirmwareIDToolTipText);
        miscGetFirmwareIDToolTip->SetToolTip(miscGetFirmwareIDButton, miscGetFirmwareIDToolTipText);
        miscGetFirmwareIDToolTip->SetToolTip(miscGetFirmwareIDGroupBox, miscGetFirmwareIDToolTipText);
        delete miscGetFirmwareIDToolTipText;
        miscGetFirmwareIDGroupBoxArray[unitNumber] = miscGetFirmwareIDGroupBox;
        //--------------------------------------------------------------------
        // Transducer Chip ID group box
        //--------------------------------------------------------------------
        GroupBox ^miscGetTransducerChipIDGroupBox = gcnew GroupBox;
        miscGetTransducerChipIDGroupBox->Text = _T("Transducer Chip ID");
        miscGetTransducerChipIDGroupBox->Location = Point(
            miscGetFirmwareIDGroupBox->Left,
            miscGetFirmwareIDGroupBox->Bottom + 10);
        miscGetTransducerChipIDGroupBox->Size = miscGetFirmwareIDGroupBox->Size;
        //--------------------------------------------------------------------
        // Populate the Transducer Chip ID group box
        //--------------------------------------------------------------------
        Button ^miscGetTransdcuerChipIDButton = gcnew Button;
        miscGetTransdcuerChipIDButton->Text = _T("Get");
        miscGetTransdcuerChipIDButton->Location = Point(6, 16);
        miscGetTransdcuerChipIDButton->Size = Drawing::Size(
            30, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            miscGetTransdcuerChipIDButton,
            unitNumber);
        miscGetTransdcuerChipIDButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscGetTransducerChipIDButtonClicked);
        TextBox ^miscGetTransducerChipIDBox = gcnew TextBox;
        miscGetTransducerChipIDBox->Location = Point(
            miscGetTransdcuerChipIDButton->Right + 5,
            miscGetTransdcuerChipIDButton->Top + 2);
        miscGetTransducerChipIDBox->Size = Drawing::Size(
            80, GUI_REGULAR_TEXT_BOX_HEIGHT);
        miscGetTransducerChipIDBox->BackColor = Color::Lavender;
        miscGetTransducerChipIDBox->Multiline = GUI_NO;
        miscGetTransducerChipIDBox->AcceptsReturn = GUI_NO;
        miscGetTransducerChipIDBox->AcceptsTab = GUI_NO;
        miscGetTransducerChipIDBox->WordWrap = GUI_NO;
        miscGetTransducerChipIDBox->ReadOnly = GUI_YES;
        miscGetTransducerChipIDBox->TextAlign = HorizontalAlignment::Center;
        miscGetTransducerChipIDBoxArray[unitNumber] = miscGetTransducerChipIDBox;
        miscGetTransducerChipIDGroupBox->Controls->Add(miscGetTransdcuerChipIDButton);
        miscGetTransducerChipIDGroupBox->Controls->Add(miscGetTransducerChipIDBox);
        //--------------------------------------------------------------------
        // Transducer Chip ID tool tip for the button and text box
        //--------------------------------------------------------------------
        ToolTip ^miscGetTransducerChipIDToolTip = gcnew ToolTip;
        miscGetTransducerChipIDToolTip->ShowAlways = GUI_YES;
        miscGetTransducerChipIDToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        miscGetTransducerChipIDToolTip->ToolTipTitle =
            _T("Transducer Chip ID Bytes");
        String ^miscGetTransducerChipIDToolTipText = String::Concat(
            "0D = Produced by Quartzdyne", Environment::NewLine,
            "XX = Transducer chip type", Environment::NewLine,
            "        02 = SMT FPGA", Environment::NewLine,
            "        05 = Hybrid FPGA", Environment::NewLine,
            "        09 = ASIC", Environment::NewLine,
            "04 = Major version number", Environment::NewLine,
            "02 = Minor version number");
        miscGetTransducerChipIDToolTip->SetToolTip(miscGetTransducerChipIDBox, miscGetTransducerChipIDToolTipText);
        miscGetTransducerChipIDToolTip->SetToolTip(miscGetTransdcuerChipIDButton, miscGetTransducerChipIDToolTipText);
        miscGetTransducerChipIDToolTip->SetToolTip(miscGetTransducerChipIDGroupBox, miscGetTransducerChipIDToolTipText);
        delete miscGetTransducerChipIDToolTipText;
        miscGetTransducerChipIDGroupBoxArray[unitNumber] = miscGetTransducerChipIDGroupBox;
        //--------------------------------------------------------------------
        // Copy Transducer Memory to Module button, but only for digital
        // transducers
        //--------------------------------------------------------------------
        Button ^miscReadXDCoefficientsButton = gcnew Button;
        miscReadXDCoefficientsButton->Text = _T("Copy Transducer\nMemory To Module");
        miscReadXDCoefficientsButton->Location = Point(
            miscGetStatusRegisterGroupBox->Left,
            miscGetControlRegisterGroupBox->Bottom + 72);
        miscReadXDCoefficientsButton->Size = Drawing::Size(
            124, GUI_DOUBLE_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            miscReadXDCoefficientsButton,
            unitNumber);
        miscReadXDCoefficientsButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscReadXDMemoryButtonClicked);
        miscUnitGroupBox->Controls->Add(miscReadXDCoefficientsButton);
        miscReadXDMemoryButtonArray[unitNumber] = miscReadXDCoefficientsButton;
        //--------------------------------------------------------------------
        // Copy Transducer Memory to Module button tool tip
        //--------------------------------------------------------------------
        ToolTip ^miscReadXDCoefficientsButtonToolTip = gcnew ToolTip;
        miscReadXDCoefficientsButtonToolTip->ShowAlways = GUI_YES;
        miscReadXDCoefficientsButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        miscReadXDCoefficientsButtonToolTip->ToolTipTitle =
            _T("Copy Transducer Memory To Module");
        String ^miscReadXDCoefficientsButtonToolTipText = String::Concat(
            "Copies the contents of the first four", Environment::NewLine,
            "256-byte pages of transducer ", unit->transducerSerialNumber, Environment::NewLine,
            "memory to the corresponding pages", Environment::NewLine,
            "of QCOM module ", unit->moduleSerialNumber, " memory.");
        miscReadXDCoefficientsButtonToolTip->SetToolTip(miscReadXDCoefficientsButton, miscReadXDCoefficientsButtonToolTipText);
        delete miscReadXDCoefficientsButtonToolTipText;
        //--------------------------------------------------------------------
        // Copy Module Memory to Transducer button, but only for digital
        // transducers
        //--------------------------------------------------------------------
        Button ^miscWriteXDCoefficientsButton = gcnew Button;
        miscWriteXDCoefficientsButton->Text = _T("Copy Module Memory\nTo Transducer");
        miscWriteXDCoefficientsButton->Location = Point(
            miscReadXDCoefficientsButton->Left,
            miscReadXDCoefficientsButton->Bottom + 10);
        miscWriteXDCoefficientsButton->Size = miscReadXDCoefficientsButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            miscWriteXDCoefficientsButton,
            unitNumber);
        miscWriteXDCoefficientsButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscWriteXDMemoryButtonClicked);
        miscUnitGroupBox->Controls->Add(miscWriteXDCoefficientsButton);
        miscWriteXDMemoryButtonArray[unitNumber] = miscWriteXDCoefficientsButton;
        //--------------------------------------------------------------------
        // Copy Module Memory to Transducer button tool tip
        //--------------------------------------------------------------------
        ToolTip ^miscWriteXDCoefficientsButtonToolTip = gcnew ToolTip;
        miscWriteXDCoefficientsButtonToolTip->ShowAlways = GUI_YES;
        miscWriteXDCoefficientsButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        miscWriteXDCoefficientsButtonToolTip->ToolTipTitle =
            _T("Copy Module Memory To Transducer");
        String ^miscWriteXDCoefficientsButtonToolTipText = String::Concat(
            "Copies the contents of the first four", Environment::NewLine,
            "256-byte pages of QCOM module ", unit->moduleSerialNumber, Environment::NewLine,
            "memory to the corresponding pages", Environment::NewLine,
            "of transducer ", unit->transducerSerialNumber, " memory.");
        miscWriteXDCoefficientsButtonToolTip->SetToolTip(miscWriteXDCoefficientsButton, miscWriteXDCoefficientsButtonToolTipText);
        delete miscWriteXDCoefficientsButtonToolTipText;
        //--------------------------------------------------------------------
        // Display a button to display raw transducer coefficient data
        //--------------------------------------------------------------------
        Button ^miscDisplayRawXDCoeffButton = gcnew Button;
        miscDisplayRawXDCoeffButton->Text = _T("Display Transducer\nRaw Coefficient Data");
        miscDisplayRawXDCoeffButton->Location = Point(
            miscReadXDCoefficientsButton->Left,
            miscWriteXDCoefficientsButton->Bottom + 10);
        miscDisplayRawXDCoeffButton->Size = miscReadXDCoefficientsButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            miscDisplayRawXDCoeffButton,
            unitNumber);
        miscDisplayRawXDCoeffButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscDisplayRawXDCoeffButtonClicked);
        miscUnitGroupBox->Controls->Add(miscDisplayRawXDCoeffButton);
        miscDisplayRawXDCoeffButtonArray[unitNumber] = miscDisplayRawXDCoeffButton;
        //--------------------------------------------------------------------
        // Display Raw Transducer Coefficients button tool tip
        //--------------------------------------------------------------------
        ToolTip ^miscRawXDCoeffToolTip = gcnew ToolTip;
        miscRawXDCoeffToolTip->ShowAlways = GUI_YES;
        miscRawXDCoeffToolTip->AutoPopDelay = 10000;    // let stand for ten seconds
        miscRawXDCoeffToolTip->ToolTipTitle =
            _T("Display Transducer Raw Coefficient Data");
        String ^miscRawXDCoeffToolTipText = String::Concat(
            "Displays the contents of the four lowest-address", Environment::NewLine,
            "256-byte pages of transducer ", unit->transducerSerialNumber, " memory, and", Environment::NewLine,
            "indicates whether they all contain identical data.");
        miscRawXDCoeffToolTip->SetToolTip(miscDisplayRawXDCoeffButton, miscRawXDCoeffToolTipText);
        delete miscRawXDCoeffToolTipText;
        //--------------------------------------------------------------------
        // Display a button to display raw module coefficient data
        //--------------------------------------------------------------------
        Button ^miscDisplayRawModuleCoeffButton = gcnew Button;
        miscDisplayRawModuleCoeffButton->Text = _T("Display Module\nRaw Coefficient Data");
        miscDisplayRawModuleCoeffButton->Location = Point(
            miscReadXDCoefficientsButton->Left,
            miscDisplayRawXDCoeffButton->Bottom + 10);
        miscDisplayRawModuleCoeffButton->Size = miscReadXDCoefficientsButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            miscDisplayRawModuleCoeffButton,
            unitNumber);
        miscDisplayRawModuleCoeffButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscDisplayRawModuleCoeffButtonClicked);
        miscDisplayRawModuleCoeffButtonArray[unitNumber] = miscDisplayRawModuleCoeffButton;
        miscUnitGroupBox->Controls->Add(miscDisplayRawModuleCoeffButton);
        //--------------------------------------------------------------------
        // Display Raw Module Coefficients button tool tip
        //--------------------------------------------------------------------
        ToolTip ^miscRawModuleCoeffToolTip = gcnew ToolTip;
        miscRawModuleCoeffToolTip->ShowAlways = GUI_YES;
        miscRawModuleCoeffToolTip->AutoPopDelay = 10000;    // let stand for ten seconds
        miscRawModuleCoeffToolTip->ToolTipTitle =
            _T("Display Module Raw Coefficient Data");
        String ^miscRawModuleCoeffToolTipText = String::Concat(
            "Displays the contents of the four lowest-address", Environment::NewLine,
            "256-byte pages of module ", unit->moduleSerialNumber, " memory, and", Environment::NewLine,
            "indicates whether they all contain identical data.");
        miscRawModuleCoeffToolTip->SetToolTip(miscDisplayRawModuleCoeffButton, miscRawModuleCoeffToolTipText);
        delete miscRawModuleCoeffToolTipText;
        //--------------------------------------------------------------------
        // Toggle Transducer Type button
        //--------------------------------------------------------------------
        Button ^miscToggleTransducerTypeButton = gcnew Button;
        miscToggleTransducerTypeButton->Text =
            (unit->transducerType == QD_TRANSDUCER_TYPE_FREQUENCY) ?
                GUI_SWITCH_TO_DIGITAL_TRANSDUCER : GUI_SWITCH_TO_FREQUENCY_TRANSDUCER;
        miscToggleTransducerTypeButton->Location = Point(
            miscGetFirmwareIDGroupBox->Left,
            miscTabControl->Height - 155);
        miscToggleTransducerTypeButton->Size = Drawing::Size(
            miscGetFirmwareIDGroupBox->Width,
            GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            miscToggleTransducerTypeButton,
            unitNumber);
        miscToggleTransducerTypeButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscToggleTransducerTypeButtonClicked);
        miscToggleTransducerTypeButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        miscToggleTransducerTypeButtonArray[unitNumber] = miscToggleTransducerTypeButton;
        miscUnitGroupBox->Controls->Add(miscToggleTransducerTypeButton);
        //--------------------------------------------------------------------
        // Toggle Transducer Type button tool tip
        //--------------------------------------------------------------------
        ToolTip ^miscToggleTransducerTypeButtonToolTip = gcnew ToolTip;
        miscToggleTransducerTypeButtonToolTip->ShowAlways = GUI_YES;
        miscToggleTransducerTypeButtonToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        miscToggleTransducerTypeButtonToolTip->ToolTipTitle =
            _T("Toggle Transducer Type");
        String ^miscToggleTransducerTypeButtonToolTipText = String::Concat(
            "If the transducer is a digital type,", Environment::NewLine,
            "force the software to treat it as a", Environment::NewLine,
            "frequency (analog) type, and vice", Environment::NewLine,
            "versa. If the original transducer", Environment::NewLine,
            "type is unknown, type 2 will be used", Environment::NewLine,
            "for the digital type.");
        miscToggleTransducerTypeButtonToolTip->SetToolTip(miscToggleTransducerTypeButton, miscToggleTransducerTypeButtonToolTipText);
        delete miscToggleTransducerTypeButtonToolTipText;
        //--------------------------------------------------------------------
        // Demonstrate a snapshot of all DLL functions
        //--------------------------------------------------------------------
        Button ^miscDisplayDLLFunctionsButton = gcnew Button;
        miscDisplayDLLFunctionsButton->Text = _T("Display DLL Functions");
        GUI_PositionAndSizeBelow(
            miscDisplayDLLFunctionsButton,
            miscToggleTransducerTypeButton,
            10);
        GUI_SetUnitButtonInterfaceProperties(
            miscDisplayDLLFunctionsButton,
            unitNumber);
        miscDisplayDLLFunctionsButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscDisplayDLLFunctionsButtonClicked);
        miscDisplayDLLFunctionsButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        miscDisplayDLLFunctionsButtonArray[unitNumber] = miscDisplayDLLFunctionsButton;
        miscUnitGroupBox->Controls->Add(miscDisplayDLLFunctionsButton);
        //--------------------------------------------------------------------
        // Display DLL Functions button tool tip
        //--------------------------------------------------------------------
        ToolTip ^miscDisplayDLLFunctionsToolTip = gcnew ToolTip;
        miscDisplayDLLFunctionsToolTip->ShowAlways = GUI_YES;
        miscDisplayDLLFunctionsToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
        miscDisplayDLLFunctionsToolTip->ToolTipTitle =
            _T("Display DLL Functions");
        String ^miscDisplayDLLFunctionsToolTipText = String::Concat(
            "Displays a window that shows the results", Environment::NewLine,
            "of executing most of the functions in the", Environment::NewLine,
            "qdUSB DLL, both the general functions and", Environment::NewLine,
            "those that apply specifically to unit ", unitNumber, ".");
        miscDisplayDLLFunctionsToolTip->SetToolTip(miscDisplayDLLFunctionsButton, miscDisplayDLLFunctionsToolTipText);
        delete miscDisplayDLLFunctionsToolTipText;
        //--------------------------------------------------------------------
        // Display a button to toggle BootLoader mode
        //--------------------------------------------------------------------
        Button ^miscBootLoaderButton = gcnew Button;
        miscBootLoaderButton->Text =
            (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE) ?
                GUI_RESET_BOOT_LOADER_MODE : GUI_ENTER_BOOT_LOADER_MODE;
        GUI_PositionAndSizeBelow(
            miscBootLoaderButton,
            miscDisplayDLLFunctionsButton,
            10);
        GUI_SetUnitButtonInterfaceProperties(
            miscBootLoaderButton,
            unitNumber);
        miscBootLoaderButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscBootLoaderButtonClicked);
        miscBootLoaderButtonArray[unitNumber] = miscBootLoaderButton;
        miscUnitGroupBox->Controls->Add(miscBootLoaderButton);
        //--------------------------------------------------------------------
        // Boot Loader Mode button tool tip
        //--------------------------------------------------------------------
        ToolTip ^miscBootLoaderToolTip = gcnew ToolTip;
        miscBootLoaderToolTip->ShowAlways = GUI_YES;
        miscBootLoaderToolTip->AutoPopDelay = 10000;    // let stand for ten seconds
        miscBootLoaderToolTip->ToolTipTitle =
            _T("Boot Loader Mode");
        String ^miscBootLoaderToolTipText = String::Concat(
            "Forces the module into Boot Loader Mode,", Environment::NewLine,
            "which is used primarily for updating its", Environment::NewLine,
            "firmware, or back to Application Mode if", Environment::NewLine,
            "it is already in Boot Loader Mode.");
        miscBootLoaderToolTip->SetToolTip(miscBootLoaderButton, miscBootLoaderToolTipText);
        delete miscBootLoaderToolTipText;
        //--------------------------------------------------------------------
        // Attach the components to the Unit Miscellaneous Group Box
        //--------------------------------------------------------------------
        array <GroupBox ^> ^miscUnitGroupBoxes =
        {
            miscGetModuleSerialNumberGroupBox,
            miscGetMemoryTypeGroupBox,
            miscI2CGetSetDataRateGroupBox,
            miscI2CSendGroupBox,
            miscGetStatusRegisterGroupBox,
            miscGetErrorCodeGroupBox,
            miscGetControlRegisterGroupBox,
            miscGetCadenceTimerGroupBox,
            miscGetTransducerTypeGroupBox,
            miscGetFirmwareIDGroupBox,
            miscGetTransducerChipIDGroupBox
        };
        miscUnitGroupBox->Controls->AddRange(miscUnitGroupBoxes);
    }                                   // end of if (unit)
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_MiscConstructUnitControlTab()
//----------------------------------------------------------------------------
// QCOM_MiscCopyModuleMemoryToXD
//
// Writes the contents of module memory into the attached digital transducer
//
// Called by:   QCOM_MiscReadXDMemoryButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscCopyModuleMemoryToXD(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_MiscCopyModuleMemoryToXD");
    //------------------------------------------------------------------------
    if (QCOM_UnitOpen(unit))
    {
        BYTE *coefficientData = (BYTE *) malloc(QCOM_COEFFICIENT_DATA_SIZE);
        if (coefficientData)
        {
            for (BYTE pageNumber = 0; pageNumber < QD_NUMBER_OF_LOWER_QMEM_PAGES; pageNumber++)
            {
                ClearBuffer(coefficientData, QCOM_COEFFICIENT_DATA_SIZE);
                DWORD status = QD_ReadCoefficientDataFromSourcePage(
                    unit->unitHandle,
                    QD_DEVICE_MODULE,
                    pageNumber,
                    (LPBYTE) coefficientData);
                if (status == QD_SUCCESS)
                {
                    status = QD_WriteCoefficientDataToTargetPage(
                        unit->unitHandle,
                        QD_DEVICE_TRANSDUCER,
                        pageNumber,
                        (LPBYTE) coefficientData);
                    if (status == QD_SUCCESS)
                    {
                        if (pageNumber == 0)
                        {
//                            memcpy(
//                                unit->coefficientData,
//                                coefficientData,
//                                QCOM_COEFFICIENT_DATA_SIZE);
                        }
                    }
                    else
                    {
                        RecordErrorEvent(
                            "    QD_WriteCoefficientDataToTargetPage(transducer) returned status 0x{0:X8} for page {1:D}",
                            status, pageNumber);
                    }
                }
                else
                {
ModalX("Misc CFData({0:D}:{1:D}) just read: {2:X2} {3:X2} {4:X2} {5:X2} {6:X2} {7:X2}",
    QD_DEVICE_MODULE, pageNumber, coefficientData[0], coefficientData[1], coefficientData[2], coefficientData[3], coefficientData[4], coefficientData[5]);
                    RecordErrorEvent(
                        "    QD_ReadCoefficientDataFromSourcePage(module) returned status 0x{0:X8} for page {1:D}",
                        status, pageNumber);
                }
            }
            free((void *) coefficientData);
        }
    }                                   // end of if (QCOM_UnitOpen(unit))
    else
    {
        if (QCOM_UnitValid(unit))
        {
            QCOM_RecordAndModalErrorEvent(
                "{0} called with an invalid unit pointer", functionName);
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0} called with an invalid unit pointer", functionName);
        }
    }
}                                       // end of QCOM_MiscCopyModuleMemoryToXD()
//----------------------------------------------------------------------------
// QCOM_MiscCopyXDMemoryToModule
//
// Copies all four pages of the memory in the attached digital transducer into
// module memory
//
// Called by:   QCOM_MiscWriteXDMemoryButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscCopyXDMemoryToModule(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_MiscCopyXDMemoryToModule");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        BYTE *coefficientData = (BYTE *) malloc(QCOM_COEFFICIENT_DATA_SIZE);
        if (coefficientData)
        {
            for (BYTE pageNumber = 0; pageNumber < QD_NUMBER_OF_LOWER_QMEM_PAGES; pageNumber++)
            {
                ClearBuffer(coefficientData, QCOM_COEFFICIENT_DATA_SIZE);
                DWORD status = QD_ReadCoefficientDataFromSourcePage(
                    unit->unitHandle,
                    QD_DEVICE_TRANSDUCER,
                    pageNumber,
                    (LPBYTE) coefficientData);
                if (status == QD_SUCCESS)
                {
                    status = QD_WriteCoefficientDataToTargetPage(
                        unit->unitHandle,
                        QD_DEVICE_MODULE,
                        pageNumber,
                        (LPBYTE) coefficientData);
                    if (status == QD_SUCCESS)
                    {
                        if (pageNumber == 0)
                        {
                            memcpy(
                                unit->coefficientData,
                                coefficientData,
                                QCOM_COEFFICIENT_DATA_SIZE);
                        }
                    }
                    else
                    {
                        RecordErrorEvent(
                            "    QD_WriteCoefficientDataToTargetPage(module) returned status 0x{0:X8} for page {1:D}",
                            status, pageNumber);
                    }
                }
                else
                {
                    RecordErrorEvent(
                        "    QD_ReadCoefficientDataFromSourcePage(transducer) returned status 0x{0:X8} for page {1:D}",
                        status, pageNumber);
                }
            }
            free((void *) coefficientData);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_MiscCopyXDMemoryToModule()
//----------------------------------------------------------------------------
// QCOM_MiscDisplayDLLFunctions
//
// Displays all appropriate DLL functions in a single window
//
// Called by:   QCOM_MiscDisplayDLLFunctionsButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscDisplayDLLFunctions(
    UnitInfo        ^unit)
{
    bool            transducerIsPresent = GUI_NO;
    bool            valid;
    bool            validCoefficientData = GUI_NO;
    char            *displayString;
    char            *coefficientFilePath;
    char            *cwd;
    char            *lastPeriodLocation;
    char            *testFirmwareFilePath;
    long            bytesRead;
    long            fileSize;
    errno_t         result;
    BYTE            *coefficientData;
    BYTE            *firmwareData;
    BYTE            *hexFileData;
    BYTE            registerValue;
    BYTE            transducerType = 0xFF;
    DWORD           firmwareCRC;
    DWORD           lowerVersion;
    DWORD           pressureCount = 0;
    DWORD           status;
    DWORD           temperatureCount = 0;
    DWORD           unitNumber;
    DWORD           upperVersion;
    double          pressurePSI;
    double          temperatureCelsius;
    FILE            *filePointer;
    HANDLE          unitHandle;
    String          ^fileUnavailableString = _T("File unavailable");
    String          ^invalidCFDataString = _T("N/A (invalid coefficient data)");
    String          ^primaryPrefix;
    String          ^secondaryPrefix;
    String          ^functionName = _T("QCOM_MiscDisplayDLLFunctions");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        unitHandle = unit->unitHandle;
        if (QCOM_XDPresent(unit))
            transducerIsPresent = GUI_YES;
        displayString = (char *) malloc(GUI_MAXIMUM_DISPLAY_STRING_SIZE);       // 512
        cwd = (char *) malloc(QCOM_MAXIMUM_FILE_PATH_LENGTH);
        coefficientFilePath = (char *) malloc(QCOM_MAXIMUM_FILE_PATH_LENGTH);
        coefficientData = (BYTE *) malloc(QCOM_COEFFICIENT_DATA_SIZE);
        testFirmwareFilePath = (char *) malloc(QCOM_MAXIMUM_FILE_PATH_LENGTH);
        firmwareData = (BYTE *) malloc(QD_FIRMWARE_MAXIMUM_DATA_SIZE);
        if (displayString && cwd && coefficientFilePath && coefficientData &&
            testFirmwareFilePath && firmwareData)
        {
            //----------------------------------------------------------------
            // Prepare allocated buffers
            //----------------------------------------------------------------
            ClearBuffer(coefficientFilePath, QCOM_MAXIMUM_FILE_PATH_LENGTH);
            ClearBuffer(testFirmwareFilePath, QCOM_MAXIMUM_FILE_PATH_LENGTH);
            if (StringSet(unit->coefficientFilePath))
            {
                if (QCOM_CFKnown(unit))
                {
                    QCOM_ConvertString(
                        unit->coefficientFilePath,
                        coefficientFilePath,
                        QCOM_MAXIMUM_FILE_PATH_LENGTH);
                }
                if (!File::Exists(unit->coefficientFilePath))
                {
                    if (unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED)
                    {
                        QCOM_ConvertString(
                            unit->testDataFilePath,
                            coefficientFilePath,
                            QCOM_MAXIMUM_FILE_PATH_LENGTH);
                    }
                }
                if (!unit->coefficientFilePath->ToLower()->EndsWith(".hex"))
                {
                    lastPeriodLocation = strrchr(coefficientFilePath, '.');
                    if (lastPeriodLocation)
                        memcpy(lastPeriodLocation, ".hex", 5);
                }
                if (!File::Exists(unit->coefficientFilePath))
                {
                    sprintf_s(
                        coefficientFilePath,
                        QCOM_MAXIMUM_FILE_PATH_LENGTH,
                        "%s\\Test\\QCOM-MemoryTest-5.hex",
                        _getcwd(cwd, QCOM_MAXIMUM_FILE_PATH_LENGTH));
                }
            }
            if (!FileExists(coefficientFilePath))
            {
                lastPeriodLocation = strrchr(coefficientFilePath, '.');
                if (lastPeriodLocation)
                    memcpy(lastPeriodLocation, ".crf", 5);
            }
            if (FileExists(coefficientFilePath))
            {
                QCOM_ReadCoefficientDataFromFile(
                    gcnew String(coefficientFilePath),
                    (CoefficientFormatDef *) coefficientData);
            }
            else
            {
                QD_ReadCoefficientDataFromDevice(
                    unitHandle,
                    (LPBYTE) coefficientData);
            }
            validCoefficientData =
                QD_CoefficientDataIsValid((LPBYTE) coefficientData);
            if (lastPeriodLocation)
                memcpy(lastPeriodLocation, ".hex", 5);
            if (unit->testFlags & QCOM_UNIT_TEST_FW_FILE_SPECIFIED)
            {
                QCOM_ConvertString(
                    unit->testFirmwareFilePath,
                    testFirmwareFilePath,
                    QCOM_MAXIMUM_FILE_PATH_LENGTH);
            }
            if (!File::Exists(unit->testFirmwareFilePath))
            {
                sprintf_s(
                    testFirmwareFilePath,
                    QCOM_MAXIMUM_FILE_PATH_LENGTH,
                    "%s\\Test\\QCOM-FW-Test-97.hex",
                    _getcwd(cwd, QCOM_MAXIMUM_FILE_PATH_LENGTH));
            }
            if (FileExists(testFirmwareFilePath))
            {
                if (QCOM_FilenameContainsExtension(testFirmwareFilePath, "hex"))
                {
                    QD_ReadFirmwareDataFromFile(
                        (LPBYTE) testFirmwareFilePath,
                        (LPBYTE) firmwareData);
                }
            }
            //----------------------------------------------------------------
            // Create a new window form each time this is called, due to the
            // dynamic nature of the DLL function values
            //----------------------------------------------------------------
            Form ^miscDisplayDLLFunctionsWindow = gcnew Form;
            miscDisplayDLLFunctionsWindow->SuspendLayout();
            //----------------------------------------------------------------
            // Prevent changes to its appearance
            //----------------------------------------------------------------
            miscDisplayDLLFunctionsWindow->MaximizeBox = GUI_NO;
//            miscDisplayDLLFunctionsWindow->MinimizeBox = GUI_NO;
            miscDisplayDLLFunctionsWindow->HelpButton = GUI_NO;
//            miscDisplayDLLFunctionsWindow->TopMost = GUI_YES;
            //----------------------------------------------------------------
            // Set its icon
            //----------------------------------------------------------------
            miscDisplayDLLFunctionsWindow->Icon = QCOM_SoftwareIcon;
            //----------------------------------------------------------------
            // Set the background image
            //----------------------------------------------------------------
            miscDisplayDLLFunctionsWindow->BackgroundImage = whiteSandBackground;
            //----------------------------------------------------------------
            // Set the title and border style
            //----------------------------------------------------------------
            miscDisplayDLLFunctionsWindow->Text = String::Format(
                "Display DLL Functions for Unit {0:D}",
                unit->unitNumber);
            miscDisplayDLLFunctionsWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
            //----------------------------------------------------------------
            // Create the general group box
            //----------------------------------------------------------------
            GroupBox ^miscDisplayDLLFunctionsGeneralGroupBox = gcnew GroupBox;
            miscDisplayDLLFunctionsGeneralGroupBox->Text = String::Format(
                "General DLL Functions (QD_DLLStatus = 0x{0:X8})",
                QD_DLLStatus);
            miscDisplayDLLFunctionsGeneralGroupBox->Location = Point(10, 10);
            miscDisplayDLLFunctionsGeneralGroupBox->Size = Drawing::Size(
                GUI_MISC_DLL_FUNCTIONS_GROUP_BOX_WIDTH, 164);
            miscDisplayDLLFunctionsGeneralGroupBox->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // 3.1 : QD_GetNumberOfModules
            //----------------------------------------------------------------
            Label ^dllGetNumberOfModulesLabel = gcnew Label;
            dllGetNumberOfModulesLabel->Location = Point(10, 20);
            dllGetNumberOfModulesLabel->Size = Drawing::Size(
                400, GUI_INFO_LABEL_HEIGHT);
            DWORD   numberOfModules;
            primaryPrefix = _T("QD_GetNumberOfModules : ");
            numberOfModules = QD_GetNumberOfModules();
            dllGetNumberOfModulesLabel->Text = String::Concat(
                primaryPrefix,
                numberOfModules,
                " QCOM module",
                ((numberOfModules == 1) ? QCOM_STRING_SPACE : _T("s ")),
                "attached");
            dllGetNumberOfModulesLabel->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // 3.6 : QD_GetTimeouts
            //----------------------------------------------------------------
            Label ^dllGetTimeoutsLabel = gcnew Label;
            primaryPrefix = _T("QD_GetTimeouts : ");
            DWORD readTimeout = 0;
            DWORD writeTimeout = 0;
            status = QD_GetTimeouts(&readTimeout, &writeTimeout);
            if (status == QD_SUCCESS)
            {
                dllGetTimeoutsLabel->Text = String::Concat(
                    primaryPrefix,
                    "Read = ",
                    readTimeout,
                    " / Write = ",
                    writeTimeout);
            }
            else
            {
                dllGetTimeoutsLabel->Text = String::Concat(
                    primaryPrefix,
                    "Returned error ",
                    String::Format("0x{0:X8}", status));
            }
            GUI_PositionAndSizeBelow(dllGetTimeoutsLabel, dllGetNumberOfModulesLabel, 4);
            //----------------------------------------------------------------
            // 3.15 : QD_ReadCoefficientDataFromHexFile
            //----------------------------------------------------------------
            Label ^dllReadCoefficientDataFromHexFileLabel = gcnew Label;
            primaryPrefix = _T("QD_ReadCoefficientDataFromHexFile : ");
            if (FileExists(coefficientFilePath))
            {
                status = QD_ReadCoefficientDataFromHexFile(
                    (LPBYTE) coefficientFilePath,
                    (LPBYTE) coefficientData);
                if (status == QD_SUCCESS)
                {
                    dllReadCoefficientDataFromHexFileLabel->Text = String::Concat(
                        primaryPrefix,
                        "Company ID = ",
                        String::Format("0x{0:X2}", coefficientData[0]));
                }
                else
                {
                    dllReadCoefficientDataFromHexFileLabel->Text = String::Concat(
                        primaryPrefix,
                        "Returned error ",
                        String::Format("0x{0:X8}", status));
                }
            }
            else
            {
                dllReadCoefficientDataFromHexFileLabel->Text = String::Concat(
                    primaryPrefix, fileUnavailableString);
            }
            GUI_PositionAndSizeBelow(dllReadCoefficientDataFromHexFileLabel, dllGetTimeoutsLabel, 4);
            //----------------------------------------------------------------
            // 3.34 : QD_CalculateFirmwarePageCRC
            //----------------------------------------------------------------
            Label ^dllCalculateFirmwarePageCRCLabel = gcnew Label;
            primaryPrefix = _T("QD_CalculateFirmwarePageCRC : ");
            if (FileExists(testFirmwareFilePath))
            {
                status = QD_ReadFirmwareDataFromFile(
                    (LPBYTE) testFirmwareFilePath,
                    (LPBYTE) firmwareData);
                if (status == QD_SUCCESS)
                {
                    firmwareCRC = QD_CalculateFirmwarePageCRC(
                        (LPBYTE) firmwareData,
                        0x01);
                    dllCalculateFirmwarePageCRCLabel->Text =
                        String::Concat(
                            primaryPrefix,
                            "Page 1 CRC = ",
                            String::Format("0x{0:X8}", firmwareCRC));
                }
                else
                {
                    dllCalculateFirmwarePageCRCLabel->Text =
                        String::Concat(
                            "QD_ReadFirmwareDataFromFile : Returned error ",
                            String::Format("0x{0:X2}", status));
                }
            }
            else
            {
                dllCalculateFirmwarePageCRCLabel->Text =
                    String::Concat(primaryPrefix, fileUnavailableString);
            }
            GUI_PositionAndSizeBelow(dllCalculateFirmwarePageCRCLabel, dllReadCoefficientDataFromHexFileLabel, 4);
            //----------------------------------------------------------------
            // 3.36 : QD_CoefficientDataIsValid
            //----------------------------------------------------------------
            Label ^dllCoefficientDataIsValidLabel = gcnew Label;
            dllCoefficientDataIsValidLabel->Text = String::Concat(
                "QD_CoefficientDataIsValid : ",
                (validCoefficientData ? "Yes" : "No"));
            GUI_PositionAndSizeBelow(dllCoefficientDataIsValidLabel, dllCalculateFirmwarePageCRCLabel, 4);
            //----------------------------------------------------------------
            // 3.37 : QD_CoefficientHexFileDataIsValid
            // 3.38 : QD_DataIsInHexFileFormat
            //----------------------------------------------------------------
            Label ^dllCoefficientHexFileDataIsValidLabel = gcnew Label;
            Label ^dllDataIsInHexFileFormatLabel = gcnew Label;
            primaryPrefix = _T("QD_CoefficientHexFileDataIsValid : ");
            secondaryPrefix = _T("QD_DataIsInHexFileFormat : ");
            result = fopen_s(&filePointer, coefficientFilePath, "rb");
            if (filePointer && (result == 0))
            {
                fseek(filePointer, 0, SEEK_END);
                fileSize = ftell(filePointer);
                fseek(filePointer, 0, SEEK_SET);
                hexFileData = (LPBYTE) malloc(fileSize);
                bytesRead = fread((void *) hexFileData, 1, fileSize, filePointer);
                if (bytesRead == fileSize)
                {
                    valid = QD_CoefficientHexFileDataIsValid((LPBYTE) hexFileData);
                    dllCoefficientHexFileDataIsValidLabel->Text =
                        String::Concat(
                            primaryPrefix,
                            (valid ? "Yes" : "No"));
                    valid = QD_DataIsInHexFileFormat((LPBYTE) hexFileData);
                    dllDataIsInHexFileFormatLabel->Text =
                        String::Concat(secondaryPrefix, (valid ? "Yes" : "No"));
                }
                else
                {
                    dllCoefficientHexFileDataIsValidLabel->Text =
                        String::Concat(primaryPrefix, fileUnavailableString);
                    dllDataIsInHexFileFormatLabel->Text =
                        String::Concat(secondaryPrefix, fileUnavailableString);
                }
                free((void *) hexFileData);
                fclose(filePointer);
            }
            else
            {
                dllCoefficientHexFileDataIsValidLabel->Text =
                    String::Concat(primaryPrefix, fileUnavailableString);
                dllDataIsInHexFileFormatLabel->Text =
                    String::Concat(secondaryPrefix, fileUnavailableString);
            }
            GUI_PositionAndSizeBelow(dllCoefficientHexFileDataIsValidLabel, dllCoefficientDataIsValidLabel, 4);
            GUI_PositionAndSizeBelow(dllDataIsInHexFileFormatLabel, dllCoefficientHexFileDataIsValidLabel, 4);
            //----------------------------------------------------------------
            // 3.40 : QD_FirmwareHexFileDataIsValid
            // 3.47 : QD_HexFileFormatIsValid
            //----------------------------------------------------------------
            Label ^dllFirmwareHexFileDataIsValidLabel = gcnew Label;
            dllFirmwareHexFileDataIsValidLabel->Location = Point(440, 20);
            dllFirmwareHexFileDataIsValidLabel->Size =
                dllGetNumberOfModulesLabel->Size;
            Label ^dllHexFileFormatIsValidLabel = gcnew Label;
            primaryPrefix = _T("QD_FirmwareHexFileDataIsValid : ");
            secondaryPrefix = _T("QD_HexFileFormatIsValid : ");
            result = fopen_s(&filePointer, testFirmwareFilePath, "rb");
            if (filePointer && (result == 0))
            {
                fseek(filePointer, 0, SEEK_END);
                fileSize = ftell(filePointer);
                fseek(filePointer, 0, SEEK_SET);
                hexFileData = (LPBYTE) malloc(fileSize);
                bytesRead = fread((void *) hexFileData, 1, fileSize, filePointer);
                if (bytesRead == fileSize)
                {
                    valid = QD_FirmwareHexFileDataIsValid((LPBYTE) hexFileData);
                    dllFirmwareHexFileDataIsValidLabel->Text =
                        String::Concat(primaryPrefix, (valid ? "Yes" : "No"));
                    valid = QD_HexFileFormatIsValid((LPBYTE) hexFileData);
                    dllHexFileFormatIsValidLabel->Text =
                        String::Concat(secondaryPrefix, (valid ? "Yes" : "No"));
                }
                else
                {
                    dllFirmwareHexFileDataIsValidLabel->Text =
                        String::Concat(primaryPrefix, fileUnavailableString);
                    dllHexFileFormatIsValidLabel->Text =
                        String::Concat(secondaryPrefix, fileUnavailableString);
                }
                free((void *) hexFileData);
                fclose(filePointer);
            }
            else
            {
                dllFirmwareHexFileDataIsValidLabel->Text =
                    String::Concat(primaryPrefix, fileUnavailableString);
                dllHexFileFormatIsValidLabel->Text =
                    String::Concat(secondaryPrefix, fileUnavailableString);
            }
            dllFirmwareHexFileDataIsValidLabel->BackColor = Color::Transparent;
            GUI_PositionAndSizeBelow(dllHexFileFormatIsValidLabel, dllFirmwareHexFileDataIsValidLabel, 4);
            //----------------------------------------------------------------
            // 3.44 : QD_GetUSBDLLVersion
            //----------------------------------------------------------------
            Label ^dllGetUSBDLLVersionLabel = gcnew Label;
            primaryPrefix = _T("QD_GetUSBDLLVersion : ");
            lowerVersion = 0;
            upperVersion = 0;
            status = QD_GetUSBDLLVersion(
                (LPDWORD) &upperVersion,
                (LPDWORD) &lowerVersion);
            if (status == QD_SUCCESS)
            {
                dllGetUSBDLLVersionLabel->Text =
                    String::Concat(
                        primaryPrefix,
                        "Version = ",
                        String::Format("{0:X}.{1:X}.{2:X}.{3:X}",
                            ((upperVersion >> 16) & 0xFFFF), (upperVersion & 0xFFFF),
                            ((lowerVersion >> 16) & 0xFFFF), (lowerVersion & 0xFFFF)));
            }
            else
            {
                dllGetUSBDLLVersionLabel->Text =
                    String::Concat(
                        primaryPrefix,
                        "Returned error ",
                        String::Format("0x{0:X8}", status));
            }
            GUI_PositionAndSizeBelow(dllGetUSBDLLVersionLabel, dllHexFileFormatIsValidLabel, 4);
            //----------------------------------------------------------------
            // 3.45 : QD_GetUSBDriverVersion
            //----------------------------------------------------------------
            Label ^dllGetUSBDriverVersionLabel = gcnew Label;
            primaryPrefix = _T("QD_GetUSBDriverVersion : ");
            lowerVersion = 0;
            upperVersion = 0;
            status = QD_GetUSBDriverVersion(
                (LPDWORD) &upperVersion,
                (LPDWORD) &lowerVersion);
            if (status == QD_SUCCESS)
            {
                dllGetUSBDriverVersionLabel->Text = String::Concat(
                    primaryPrefix,
                    "Version = ",
                    String::Format("{0:X}.{1:X}.{2:X}.{3:X}",
                        ((upperVersion >> 16) & 0xFFFF), (upperVersion & 0xFFFF),
                        ((lowerVersion >> 16) & 0xFFFF), (lowerVersion & 0xFFFF)));
            }
            else
            {
                dllGetUSBDriverVersionLabel->Text = String::Concat(
                    primaryPrefix,
                    "Returned error ",
                    String::Format("0x{0:X8}", status));
            }
            GUI_PositionAndSizeBelow(dllGetUSBDriverVersionLabel, dllGetUSBDLLVersionLabel, 4);
            //----------------------------------------------------------------
            // 3.51 : QD_ReadFirmwareDataFromFile
            //----------------------------------------------------------------
            Label ^dllReadFirmwareDataFromFileLabel = gcnew Label;
            primaryPrefix = _T("QD_ReadFirmwareDataFromFile : ");
            if (FileExists(testFirmwareFilePath))
            {
                status = QD_ReadFirmwareDataFromFile(
                    (LPBYTE) testFirmwareFilePath,
                    (LPBYTE) firmwareData);
                if (status == QD_SUCCESS)
                {
                    dllReadFirmwareDataFromFileLabel->Text = String::Concat(
                        primaryPrefix,
                        "Device type = ",
                        String::Format("0x{0:X2}",
                            firmwareData[QD_FIRMWARE_TEST_OFFSET + 7]));
                }
                else
                {
                    dllReadFirmwareDataFromFileLabel->Text = String::Concat(
                        primaryPrefix,
                        "Returned error ",
                        String::Format("0x{0:X8}", status));
                }
            }
            else
            {
                dllReadFirmwareDataFromFileLabel->Text =
                    String::Concat(primaryPrefix, fileUnavailableString);
            }
            GUI_PositionAndSizeBelow(dllReadFirmwareDataFromFileLabel, dllGetUSBDriverVersionLabel, 4);
            //----------------------------------------------------------------
            // 3.63 : QD_GetQDDLLVersion
            //----------------------------------------------------------------
            Label ^dllGetQDDLLVersionLabel = gcnew Label;
            primaryPrefix = _T("QD_GetQDDLLVersion : ");
            BYTE majorVersion = 0;
            BYTE minorVersion = 0;
            BYTE buildVersion = 0;

            status = QD_GetQDDLLVersion(
                (LPBYTE) &majorVersion,
                (LPBYTE) &minorVersion,
                (LPBYTE) &buildVersion);
            if (status == QD_SUCCESS)
            {
                dllGetQDDLLVersionLabel->Text = String::Concat(
                    primaryPrefix,
                    "Version = ",
                    String::Format("{0:D}.{1:D}.{2:D}",
                        majorVersion, minorVersion, buildVersion));
            }
            else
            {
                dllGetQDDLLVersionLabel->Text = String::Concat(
                    primaryPrefix,
                    "Returned error ",
                    String::Format("0x{0:X8}", status));
            }
            GUI_PositionAndSizeBelow(dllGetQDDLLVersionLabel, dllReadFirmwareDataFromFileLabel, 4);
            //----------------------------------------------------------------
            // Add the components to the General Functions group box
            //----------------------------------------------------------------
            array <Label ^> ^miscGeneralDLLLabels =
            {
                dllGetNumberOfModulesLabel,
                dllGetTimeoutsLabel,
                dllReadCoefficientDataFromHexFileLabel,
                dllCalculateFirmwarePageCRCLabel,
                dllCoefficientDataIsValidLabel,
                dllCoefficientHexFileDataIsValidLabel,
                dllDataIsInHexFileFormatLabel,
                dllFirmwareHexFileDataIsValidLabel,
                dllHexFileFormatIsValidLabel,
                dllGetUSBDLLVersionLabel,
                dllGetUSBDriverVersionLabel,
                dllReadFirmwareDataFromFileLabel,
                dllGetQDDLLVersionLabel
            };
            miscDisplayDLLFunctionsGeneralGroupBox->Controls->AddRange(miscGeneralDLLLabels);
            //----------------------------------------------------------------
            // Create the unit group box
            //----------------------------------------------------------------
            GroupBox ^miscDisplayDLLFunctionsUnitGroupBox = gcnew GroupBox;
            miscDisplayDLLFunctionsUnitGroupBox->Text = String::Format(
                "DLL Functions specific to Unit {0:D} (handle 0x{1:X8})",
                unit->unitNumber,
                (DWORD) unitHandle);
            miscDisplayDLLFunctionsUnitGroupBox->Location = Point(
                10, miscDisplayDLLFunctionsGeneralGroupBox->Bottom + 20);
            miscDisplayDLLFunctionsUnitGroupBox->Size = Drawing::Size(
                GUI_MISC_DLL_FUNCTIONS_GROUP_BOX_WIDTH, 264);
            miscDisplayDLLFunctionsUnitGroupBox->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // 3.2 : QD_GetProductInfo
            //----------------------------------------------------------------
            Label ^dllGetProductInfoStringLabel = gcnew Label;
            dllGetProductInfoStringLabel->Location = Point(10, 20);
            dllGetProductInfoStringLabel->Size = Drawing::Size(
                400, GUI_INFO_LABEL_HEIGHT);
            primaryPrefix = _T("QD_GetProductInfo : ");
            char *productInfoString;

            productInfoString = (char *) malloc(QD_MAXIMUM_PRODUCT_STRING_SIZE);
            if (productInfoString)
            {
                status = QD_GetProductInfo(
                    unitNumber,
                    (LPBYTE) productInfoString,
                    QD_RETURN_DESCRIPTION);
                if (status == QD_SUCCESS)
                {
                    dllGetProductInfoStringLabel->Text = String::Concat(
                        primaryPrefix,
                        _T("Product description = "),
                        gcnew String(productInfoString));
                }
                else
                {
                    dllGetProductInfoStringLabel->Text = String::Concat(
                        primaryPrefix,
                        _T("Returned error "),
                        String::Format("0x{0:X8}", status));
                }
                free((void *) productInfoString);
            }
            else
            {
                dllGetProductInfoStringLabel->Text = String::Concat(
                    primaryPrefix, _T("Unable"));
            }
            dllGetProductInfoStringLabel->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // 3.7 : QD_CheckReceiveQueue
            //----------------------------------------------------------------
            Label ^dllCheckReceiveQueueLabel = gcnew Label;
            primaryPrefix = _T("QD_CheckReceiveQueue : ");
            DWORD numberOfBytes = 0;
            DWORD queueStatus = 0;

            status = QD_CheckReceiveQueue(
                unitHandle,
                &numberOfBytes,
                &queueStatus);
            if (status == QD_SUCCESS)
            {
                dllCheckReceiveQueueLabel->Text = String::Concat(
                    primaryPrefix,
                    numberOfBytes,
                    " byte",
                    ((numberOfBytes == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                    " in the queue, with status = ",
                    queueStatus);
            }
            else
            {
                dllCheckReceiveQueueLabel->Text =
                    String::Concat(
                        primaryPrefix,
                        "Returned error ",
                        String::Format("0x{0:X8}", status));
            }
            GUI_PositionAndSizeBelow(dllCheckReceiveQueueLabel, dllGetProductInfoStringLabel, 4);
            //----------------------------------------------------------------
            // 3.9 : QD_GetTransducerType
            //----------------------------------------------------------------
            Label ^dllGetTransducerTypeLabel = gcnew Label;
            primaryPrefix = _T("QD_GetTransducerType : ");
            if (transducerIsPresent)
            {
                status = QD_GetTransducerType(
                    unitHandle,
                    (LPBYTE) &transducerType);
                if (status == QD_SUCCESS)
                {
                    dllGetTransducerTypeLabel->Text = String::Concat(
                        primaryPrefix,
                        _T("Type "),
                        String::Format("{0:D}", transducerType));
                }
                else
                {
                    dllGetTransducerTypeLabel->Text = String::Concat(
                        primaryPrefix,
                        _T("Returned error "),
                        String::Format("0x{0:X8}", status));
                }
            }
            else
            {
                dllGetTransducerTypeLabel->Text = String::Concat(
                    primaryPrefix, QCOM_STRING_NA);
            }
            GUI_PositionAndSizeBelow(dllGetTransducerTypeLabel, dllCheckReceiveQueueLabel, 4);
            //----------------------------------------------------------------
            // 3.10 : QD_GetTransducerCounts
            //----------------------------------------------------------------
            Label ^dllGetTransducerCountsLabel = gcnew Label;
            primaryPrefix = _T("QD_GetTransducerCounts : ");
            if (transducerIsPresent)
            {
                status = QD_GetTransducerCounts(
                    unitHandle,
                    (LPDWORD) &pressureCount,
                    (LPDWORD) &temperatureCount);
                if (status == QD_SUCCESS)
                {
                    dllGetTransducerCountsLabel->Text = String::Concat(
                        primaryPrefix,
                        "P = ",
                        pressureCount,
                        " / T = ",
                        temperatureCount);
                }
                else
                {
                    dllGetTransducerCountsLabel->Text = String::Concat(
                        primaryPrefix,
                        "Returned error ",
                        String::Format("0x{0:X8}", status));
                }
            }
            else
            {
                dllGetTransducerCountsLabel->Text = String::Concat(
                    primaryPrefix, QCOM_STRING_NA);
            }
            GUI_PositionAndSizeBelow(dllGetTransducerCountsLabel, dllGetTransducerTypeLabel, 4);
            //----------------------------------------------------------------
            // 3.11 : QD_CalculatePressureOrTemperature
            //----------------------------------------------------------------
            Label ^dllCalculatePressureOrTemperatureLabel = gcnew Label;
            primaryPrefix = _T("QD_CalculatePressureOrTemperature : ");
            if (transducerIsPresent)
            {
                if (validCoefficientData)
                {
                    status = QD_CalculatePressureOrTemperature(
                        QD_CALCULATE_TEMPERATURE_CELSIUS,
                        (LPBYTE) unit->coefficientData,
                        pressureCount,
                        temperatureCount,
                        &temperatureCelsius);
                    if (status == QD_SUCCESS)
                    {
                        dllCalculatePressureOrTemperatureLabel->Text = String::Concat(
                            primaryPrefix,
                            "Temperature = ",
                            String::Format("{0:F2} �F",
                                FahrenheitFromCelsius(temperatureCelsius)));
                    }
                    else
                    {
                        dllCalculatePressureOrTemperatureLabel->Text = String::Concat(
                            primaryPrefix,
                            "Returned error ",
                            String::Format("0x{0:X8}", status));
                    }
                }
                else
                {
                    dllCalculatePressureOrTemperatureLabel->Text = String::Concat(
                        primaryPrefix, invalidCFDataString);
                }
            }
            else
            {
                dllCalculatePressureOrTemperatureLabel->Text = String::Concat(
                    primaryPrefix, QCOM_STRING_NA);
            }
            GUI_PositionAndSizeBelow(dllCalculatePressureOrTemperatureLabel, dllGetTransducerCountsLabel, 4);
            //----------------------------------------------------------------
            // 3.12 : QD_GetPressureAndTemperature
            //----------------------------------------------------------------
            Label ^dllGetPressureAndTemperatureLabel = gcnew Label;
            primaryPrefix = _T("QD_GetPressureAndTemperature : ");
            if (transducerIsPresent)
            {
                if (validCoefficientData)
                {
                    status = QD_GetPressureAndTemperature(
                        unitHandle,
                        (LPBYTE) unit->coefficientData,
                        &pressurePSI,
                        &temperatureCelsius);
                    if (status == QD_SUCCESS)
                    {
                        dllGetPressureAndTemperatureLabel->Text = String::Concat(
                            primaryPrefix,
                            String::Format("{0:F2} psi", pressurePSI),
                            " / ",
                            String::Format("{0:F2} �C", temperatureCelsius));
                    }
                    else
                    {
                        dllGetPressureAndTemperatureLabel->Text = String::Concat(
                            primaryPrefix,
                            "Returned error ",
                            String::Format("0x{0:X8}", status));
                    }
                }
                else
                {
                    dllGetPressureAndTemperatureLabel->Text = String::Concat(
                        primaryPrefix, invalidCFDataString);
                }
            }
            else
            {
                dllGetPressureAndTemperatureLabel->Text = String::Concat(
                    primaryPrefix, QCOM_STRING_NA);
            }
            GUI_PositionAndSizeBelow(dllGetPressureAndTemperatureLabel, dllCalculatePressureOrTemperatureLabel, 4);
            //----------------------------------------------------------------
            // 3.13 : QD_ReadCoefficientDataFromSourcePage
            //----------------------------------------------------------------
            Label ^dllReadCoefficientDataFromSourcePageLabel = gcnew Label;
            primaryPrefix = _T("QD_ReadCoefficientDataFromSourcePage(0) : ");
            status = QD_ReadCoefficientDataFromSourcePage(
                unitHandle,
                QD_DEVICE_MODULE,
                0,
                (LPBYTE) coefficientData);
            if (QD_CoefficientDataIsValid((LPBYTE) coefficientData))
            {
                if (status == QD_SUCCESS)
                {
                    dllReadCoefficientDataFromSourcePageLabel->Text = String::Concat(
                        primaryPrefix,
                        "Transducer S/N = ",
                        String::Format("{0:X2}{1:X2}{2:X2}",
                            coefficientData[5], coefficientData[6], coefficientData[7]));
                }
                else
                {
                    dllReadCoefficientDataFromSourcePageLabel->Text = String::Concat(
                        primaryPrefix,
                        "Returned error ",
                        String::Format("0x{0:X8}", status));
                }
            }
            else
            {
                dllReadCoefficientDataFromSourcePageLabel->Text = String::Concat(
                    primaryPrefix, invalidCFDataString);
            }
            GUI_PositionAndSizeBelow(dllReadCoefficientDataFromSourcePageLabel, dllGetPressureAndTemperatureLabel, 4);
            //----------------------------------------------------------------
            // 3.14 : QD_WriteCoefficientDataToTargetPage
            //----------------------------------------------------------------
            Label ^dllWriteCoefficientDataToTargetPageLabel = gcnew Label;
            primaryPrefix = _T("QD_WriteCoefficientDataToTargetPage : ");
            if (QD_CoefficientDataIsValid((LPBYTE) coefficientData))
            {
                status = QD_WriteCoefficientDataToTargetPage(
                    unitHandle,
                    QD_DEVICE_MODULE,
                    0,
                    (LPBYTE) coefficientData);
                if (status == QD_SUCCESS)
                {
                    dllWriteCoefficientDataToTargetPageLabel->Text = String::Concat(
                        primaryPrefix,
                        "Checksum = ",
                        String::Format("0x{0:X2}", coefficientData[255]));
                }
                else
                {
                    dllWriteCoefficientDataToTargetPageLabel->Text = String::Concat(
                        primaryPrefix,
                        "Returned error ",
                        String::Format("0x{0:X8}", status));
                }
            }
            else
            {
                dllWriteCoefficientDataToTargetPageLabel->Text = String::Concat(
                    primaryPrefix, invalidCFDataString);
            }
            GUI_PositionAndSizeBelow(dllWriteCoefficientDataToTargetPageLabel, dllReadCoefficientDataFromSourcePageLabel, 4);
            //----------------------------------------------------------------
            // 3.16 : QD_ExecuteI2CCommand
            //----------------------------------------------------------------
            Label ^dllExecuteI2CCommandLabel = gcnew Label;
            primaryPrefix = _T("QD_ExecuteI2CCommand : ");
            if (transducerIsPresent)
            {
                BYTE replyString[QD_MAXIMUM_TRANSFER_SIZE];

                status = QD_ExecuteI2CCommand(
                    unitHandle,
                    (LPBYTE) ((transducerType == QD_TRANSDUCER_TYPE_FREQUENCY) ?
                        "S99FFFFFFFFP" : "S9DFFFFFFFFP"),
                    (LPBYTE) replyString);
                if (status == QD_SUCCESS)
                {
                    if ((_memicmp((void *) replyString, "ER=", 3) == 0) || strstr((char *) replyString, "NP"))
                    {
                        sprintf_s(
                            displayString,
                            GUI_MAXIMUM_DISPLAY_STRING_SIZE,
                            "Returned error string %s",
                            replyString);
                    }
                    else
                    {
                        sprintf_s(
                            displayString,
                            GUI_MAXIMUM_DISPLAY_STRING_SIZE,
                            "Pressure count = 0x%c%c%c%c%c%c%c%c",
                            replyString[3], replyString[4], replyString[5], replyString[6],
                            replyString[7], replyString[8], replyString[9], replyString[10]);
                    }
                    dllExecuteI2CCommandLabel->Text = String::Concat(
                        primaryPrefix, gcnew String(displayString));
                }
                else
                {
                    dllExecuteI2CCommandLabel->Text = String::Concat(
                        primaryPrefix,
                        "Returned error ",
                        String::Format("0x{0:X8}", status));
                }
            }
            else
            {
                dllExecuteI2CCommandLabel->Text = String::Concat(
                    primaryPrefix, QCOM_STRING_NA);
            }
            GUI_PositionAndSizeBelow(dllExecuteI2CCommandLabel, dllWriteCoefficientDataToTargetPageLabel, 4);
            //----------------------------------------------------------------
            // 3.17 : QD_ReadUnitADC
            //----------------------------------------------------------------
            Label ^dllReadUnitADCLabel = gcnew Label;
            primaryPrefix = _T("QD_ReadUnitADC : ");
            DWORD currentCount = 0;

            status = QD_ReadUnitADC(
                unitHandle,
                QD_READ_ADC_CHANNEL_CURRENT,
                (LPDWORD) &currentCount);
            if (status == QD_SUCCESS)
            {
                dllReadUnitADCLabel->Text = String::Concat(
                    primaryPrefix,
                    "Current count = ",
                    currentCount);
            }
            else
            {
                dllReadUnitADCLabel->Text = String::Concat(
                    primaryPrefix,
                    "Returned error ",
                    String::Format("0x{0:X8}", status));
            }
            GUI_PositionAndSizeBelow(dllReadUnitADCLabel, dllExecuteI2CCommandLabel, 4);
            //----------------------------------------------------------------
            // 3.18 : QD_GetTransducerCurrent
            //----------------------------------------------------------------
            Label ^dllGetTransducerCurrentLabel = gcnew Label;
            primaryPrefix = _T("QD_GetTransducerCurrent : ");
            if (transducerIsPresent)
            {
                double transducerCurrent = 0.0;

                status = QD_GetTransducerCurrent(
                    unitHandle,
                    &transducerCurrent);
                if (status == QD_SUCCESS)
                {
                    dllGetTransducerCurrentLabel->Text = String::Concat(
                        primaryPrefix,
                        "Current = ",
                        String::Format("{0:F2} mA", transducerCurrent));
                }
                else
                {
                    dllGetTransducerCurrentLabel->Text = String::Concat(
                        primaryPrefix,
                        "Returned error ",
                        String::Format("0x{0:X8}", status));
                }
            }
            else
            {
                dllGetTransducerCurrentLabel->Text = String::Concat(
                    primaryPrefix, QCOM_STRING_NA);
            }
            GUI_PositionAndSizeBelow(dllGetTransducerCurrentLabel, dllReadUnitADCLabel, 4);
            //----------------------------------------------------------------
            // 3.19 : QD_GetTransducerVoltage
            //----------------------------------------------------------------
            Label ^dllGetTransducerVoltageLabel = gcnew Label;
            primaryPrefix = _T("QD_GetTransducerVoltage : ");
            if (transducerIsPresent)
            {
                double transducerVoltage = 0.0;

                status = QD_GetTransducerVoltage(
                    unitHandle,
                    &transducerVoltage);
                if (status == QD_SUCCESS)
                {
                    dllGetTransducerVoltageLabel->Text = String::Concat(
                        primaryPrefix,
                        "Voltage = ",
                        String::Format("{0:F2} V", transducerVoltage));
                }
                else
                {
                    dllGetTransducerVoltageLabel->Text = String::Concat(
                        primaryPrefix,
                        "Returned error ",
                        String::Format("0x{0:X8}", status));
                }
            }
            else
            {
                dllGetTransducerVoltageLabel->Text = String::Concat(
                    primaryPrefix, QCOM_STRING_NA);
            }
            GUI_PositionAndSizeBelow(dllGetTransducerVoltageLabel, dllGetTransducerCurrentLabel, 4);
            //----------------------------------------------------------------
            // 3.21 : QD_GetModuleControlRegister
            //----------------------------------------------------------------
            Label ^dllGetUnitControlRegisterLabel = gcnew Label;
            dllGetUnitControlRegisterLabel->Location = Point(440, 20);
            dllGetUnitControlRegisterLabel->Size =
                dllGetProductInfoStringLabel->Size;
            primaryPrefix = _T("QD_GetModuleControlRegister : ");
            registerValue = 0;

            status = QD_GetModuleControlRegister(
                unitHandle,
                (LPBYTE) &registerValue);
            if (status == QD_SUCCESS)
            {
                dllGetUnitControlRegisterLabel->Text =
                    String::Concat(
                        primaryPrefix,
                        "Control = ",
                        String::Format("0x{0:X2}", registerValue));
            }
            else
            {
                dllGetUnitControlRegisterLabel->Text =
                    String::Concat(
                        primaryPrefix,
                        "Returned error ",
                        String::Format("0x{0:X8}", status));
            }
            dllGetUnitControlRegisterLabel->BackColor = Color::Transparent;
            //----------------------------------------------------------------
            // 3.23 : QD_GetModuleStatusRegister
            //----------------------------------------------------------------
            Label ^dllGetUnitStatusRegisterLabel = gcnew Label;
            primaryPrefix = _T("QD_GetModuleStatusRegister : ");
            registerValue = 0;

            status = QD_GetModuleStatusRegister(
                unitHandle,
                (LPBYTE) &registerValue);
            if (status == QD_SUCCESS)
            {
                dllGetUnitStatusRegisterLabel->Text = String::Concat(
                    primaryPrefix,
                    "Status = ",
                    String::Format("0x{0:X2}", registerValue));
            }
            else
            {
                dllGetUnitStatusRegisterLabel->Text = String::Concat(
                    primaryPrefix,
                    "Returned error ",
                    String::Format("0x{0:X8}", status));
            }
            GUI_PositionAndSizeBelow(dllGetUnitStatusRegisterLabel, dllGetUnitControlRegisterLabel, 4);
            //----------------------------------------------------------------
            // 3.24 : QD_GetModuleFirmwareID
            //----------------------------------------------------------------
            Label ^dllGetUnitFirmwareIDLabel = gcnew Label;
            primaryPrefix = _T("QD_GetModuleFirmwareID : ");
            BYTE firmwareID[QD_FIRMWARE_ID_LENGTH];

            status = QD_GetModuleFirmwareID(
                unitHandle,
                (LPBYTE) firmwareID);
            if (status == QD_SUCCESS)
            {
                dllGetUnitFirmwareIDLabel->Text = String::Concat(
                    primaryPrefix,
                    "ID = ",
                    String::Format(
                        "{0:X2} {1:X2} {2:X2} {3:X2}",
                        firmwareID[0], firmwareID[1], firmwareID[2], firmwareID[3]));
            }
            else
            {
                dllGetUnitFirmwareIDLabel->Text = String::Concat(
                    primaryPrefix,
                    "Returned error ",
                    String::Format("0x{0:X8}", status));
            }
            GUI_PositionAndSizeBelow(dllGetUnitFirmwareIDLabel, dllGetUnitStatusRegisterLabel, 4);
            //----------------------------------------------------------------
            // 3.26 : QD_GetCadenceTimer
            //----------------------------------------------------------------
            Label ^dllGetCadenceTimerLabel = gcnew Label;
            primaryPrefix = _T("QD_GetCadenceTimer : ");
            DWORD timerValue = 0;

            status = QD_GetCadenceTimer(
                unitHandle,
                (LPDWORD) &timerValue);
            if (status == QD_SUCCESS)
            {
                dllGetCadenceTimerLabel->Text = String::Concat(
                    primaryPrefix,
                    "Value = ",
                    timerValue,
                    " ms");
            }
            else
            {
                dllGetCadenceTimerLabel->Text = String::Concat(
                    primaryPrefix,
                    "Returned error ",
                    String::Format("0x{0:X8}", status));
            }
            GUI_PositionAndSizeBelow(dllGetCadenceTimerLabel, dllGetUnitFirmwareIDLabel, 4);
            //----------------------------------------------------------------
            // 3.27 : QD_GetModuleModeSwitchSetting
            //----------------------------------------------------------------
            Label ^dllGetUnitModeSwitchSettingLabel = gcnew Label;
            primaryPrefix = _T("QD_GetModuleModeSwitchSetting : ");
            BYTE switchSetting = 0;

            status = QD_GetModuleModeSwitchSetting(
                unitHandle,
                (LPBYTE) &switchSetting);
            if (status == QD_SUCCESS)
            {
                dllGetUnitModeSwitchSettingLabel->Text = String::Concat(
                    primaryPrefix,
                    "Switch is ",
                    (switchSetting ? _T("not ") : QCOM_STRING_EMPTY),
                    "depressed");
            }
            else
            {
                dllGetUnitModeSwitchSettingLabel->Text = String::Concat(
                    primaryPrefix,
                    "Returned error ",
                    String::Format("0x{0:X8}", status));
            }
            GUI_PositionAndSizeBelow(dllGetUnitModeSwitchSettingLabel, dllGetCadenceTimerLabel, 4);
            //----------------------------------------------------------------
            // 3.30 : QD_GetInternalErrorCode
            //----------------------------------------------------------------
            Label ^dllGetErrorCodeLabel = gcnew Label;
            primaryPrefix = _T("QD_GetInternalErrorCode : ");
            WORD errorCode = 0;

            status = QD_GetInternalErrorCode(
                unitHandle,
                (LPWORD) &errorCode);
            if (status == QD_SUCCESS)
            {
                dllGetErrorCodeLabel->Text = String::Concat(
                    primaryPrefix,
                    "Code = ",
                    String::Format("0x{0:X4}", errorCode));
            }
            else
            {
                dllGetErrorCodeLabel->Text = String::Concat(
                    primaryPrefix,
                    "Returned error ",
                    String::Format("0x{0:X8}", status));
            }
            GUI_PositionAndSizeBelow(dllGetErrorCodeLabel, dllGetUnitModeSwitchSettingLabel, 4);
            //----------------------------------------------------------------
            // 3.33 : QD_GetI2CDataRate
            //----------------------------------------------------------------
            Label ^dllGetI2CDataRateLabel = gcnew Label;
            primaryPrefix = _T("QD_GetI2CDataRate : ");
            double dataRate = 0.0;

            status = QD_GetI2CDataRate(
                unitHandle,
                &dataRate);
            if (status == QD_SUCCESS)
            {
                dllGetI2CDataRateLabel->Text = String::Concat(
                    primaryPrefix,
                    "Rate = ",
                    String::Format("{0:F1}", dataRate),
                    " kHz");
            }
            else
            {
                dllGetI2CDataRateLabel->Text = String::Concat(
                    primaryPrefix,
                    "Returned error ",
                    String::Format("0x{0:X8}", status));
            }
            GUI_PositionAndSizeBelow(dllGetI2CDataRateLabel, dllGetErrorCodeLabel, 4);
            //----------------------------------------------------------------
            // 3.35 : QD_CalculatePressureAndTemperature
            //----------------------------------------------------------------
            Label ^dllCalculatePressureAndTemperatureLabel = gcnew Label;
            primaryPrefix = _T("QD_CalculatePressureAndTemperature : ");
            if (transducerIsPresent)
            {
                if (validCoefficientData)
                {
                    status = QD_CalculatePressureAndTemperature(
                        (LPBYTE) coefficientData,
                        pressureCount,
                        temperatureCount,
                        &pressurePSI,
                        &temperatureCelsius);
                    if (status == QD_SUCCESS)
                    {
                        dllCalculatePressureAndTemperatureLabel->Text = String::Concat(
                            primaryPrefix,
                            String::Format("{0:F2} psi", pressurePSI),
                            " / ",
                            String::Format("{0:F2} �C", temperatureCelsius));
                    }
                    else
                    {
                        dllCalculatePressureAndTemperatureLabel->Text = String::Concat(
                            primaryPrefix,
                            "Returned error ",
                            String::Format("0x{0:X8}", status));
                    }
                }
                else
                {
                    dllCalculatePressureAndTemperatureLabel->Text = String::Concat(
                        primaryPrefix, invalidCFDataString);
                }
            }
            else
            {
                dllCalculatePressureAndTemperatureLabel->Text = String::Concat(
                    primaryPrefix, QCOM_STRING_NA);
            }
            GUI_PositionAndSizeBelow(dllCalculatePressureAndTemperatureLabel, dllGetI2CDataRateLabel, 4);
            //----------------------------------------------------------------
            // 3.46 : QD_GetModuleSerialNumber
            //----------------------------------------------------------------
            Label ^dllGetModuleSerialNumberLabel = gcnew Label;
            primaryPrefix = _T("QD_GetModuleSerialNumber : ");
            char *serialNumber;

            serialNumber = (char *) malloc(QD_MAXIMUM_SERIAL_NUMBER_SIZE);
            if (serialNumber)
            {
                status = QD_GetModuleSerialNumber(
                    unitNumber,
                    (LPBYTE) serialNumber);
                if (status == QD_SUCCESS)
                {
                    dllGetModuleSerialNumberLabel->Text = String::Concat(
                        primaryPrefix,
                        _T("Module serial number = "),
                        gcnew String(serialNumber));
                }
                else
                {
                    dllGetModuleSerialNumberLabel->Text = String::Concat(
                        primaryPrefix,
                        _T("Returned error "),
                        String::Format("0x{0:X8}", status));
                }
                free((void *) serialNumber);
            }
            else
            {
                dllGetModuleSerialNumberLabel->Text = String::Concat(
                    primaryPrefix, _T("Unable"));
            }
            GUI_PositionAndSizeBelow(dllGetModuleSerialNumberLabel, dllCalculatePressureAndTemperatureLabel, 4);
            //----------------------------------------------------------------
            // 3.49 : QD_ReadCoefficientDataFromDevice
            //----------------------------------------------------------------
            Label ^dllReadCoefficientDataFromDeviceLabel = gcnew Label;
            primaryPrefix = _T("QD_ReadCoefficientDataFromDevice : ");
            status = QD_ReadCoefficientDataFromDevice(
                unitHandle,
                (LPBYTE) coefficientData);
            if (QD_CoefficientDataIsValid((LPBYTE) coefficientData))
            {
                if (status == QD_SUCCESS)
                {
                    int monthNumber = coefficientData[18];
                    if (monthNumber > 9)
                        monthNumber -= 6;
                    dllReadCoefficientDataFromDeviceLabel->Text = String::Concat(
                        primaryPrefix,
                        "Calibration date = ",
                        String::Format("{0:X2} {1} {2:X2}{3:X2}",
                            coefficientData[19],
                            QCOM_MonthStringArray[monthNumber],
                            coefficientData[16],
                            coefficientData[17]));
                }
                else
                {
                    dllReadCoefficientDataFromDeviceLabel->Text = String::Concat(
                        primaryPrefix,
                        "Returned error ",
                        String::Format("0x{0:X8}", status));
                }
            }
            else
            {
                dllReadCoefficientDataFromDeviceLabel->Text = String::Concat(
                    primaryPrefix, invalidCFDataString);
            }
            GUI_PositionAndSizeBelow(dllReadCoefficientDataFromDeviceLabel, dllGetModuleSerialNumberLabel, 4);
            //----------------------------------------------------------------
            // 3.50 : QD_ReadCoefficientDataFromModulePage
            //----------------------------------------------------------------
            Label ^dllReadCoefficientDataFromUnitPageLabel = gcnew Label;
            primaryPrefix = _T("QD_ReadCoefficientDataFromModulePage : ");
            status = QD_ReadCoefficientDataFromModulePage(
                unitHandle,
                0,
                (LPBYTE) coefficientData);
            if (QD_CoefficientDataIsValid((LPBYTE) coefficientData))
            {
                if (status == QD_SUCCESS)
                {
                    dllReadCoefficientDataFromUnitPageLabel->Text = String::Concat(
                        primaryPrefix,
                        "File version = ",
                        String::Format("{0:X}.{1:X2}",
                            coefficientData[2], coefficientData[3]));
                }
                else
                {
                    dllReadCoefficientDataFromUnitPageLabel->Text = String::Concat(
                        primaryPrefix,
                        "Returned error ",
                        String::Format("0x{0:X8}", status));
                }
            }
            else
            {
                dllReadCoefficientDataFromUnitPageLabel->Text = String::Concat(
                    primaryPrefix, invalidCFDataString);
            }
            GUI_PositionAndSizeBelow(dllReadCoefficientDataFromUnitPageLabel, dllReadCoefficientDataFromDeviceLabel, 4);
            //----------------------------------------------------------------
            // 3.62 : QD_GetMemoryType
            //----------------------------------------------------------------
            Label ^dllGetMemoryTypeLabel = gcnew Label;
            primaryPrefix = _T("QD_GetMemoryType : ");
            BYTE memoryType = QD_MEMORY_TYPE_ABSENT;                            // 0

            status = QD_GetMemoryType(
                unitHandle,
                transducerIsPresent ? QD_DEVICE_TRANSDUCER : QD_DEVICE_MODULE,
                (LPBYTE) &memoryType);
            if (status == QD_SUCCESS)
            {
                dllGetMemoryTypeLabel->Text = String::Concat(
                    primaryPrefix,
                    transducerIsPresent ? _T("Transducer memory") : _T("Module memory"),
                    _T(" type = "),
                    ((transducerIsPresent && (transducerType == QD_TRANSDUCER_TYPE_FREQUENCY)) ?
                        QCOM_STRING_NA :
                        String::Format("{0:D}", memoryType)));
            }
            else
            {
                dllGetMemoryTypeLabel->Text = String::Concat(
                    primaryPrefix,
                    "Returned error ",
                    String::Format("0x{0:X8}", status));
            }
            GUI_PositionAndSizeBelow(dllGetMemoryTypeLabel, dllReadCoefficientDataFromUnitPageLabel, 4);
            //----------------------------------------------------------------
            // Add the components to the Unit Functions group box
            //----------------------------------------------------------------
            array <Label ^> ^miscUnitDLLLabels =
            {
                dllGetProductInfoStringLabel,
                dllCheckReceiveQueueLabel,
                dllGetTransducerTypeLabel,
                dllGetTransducerCountsLabel,
                dllCalculatePressureOrTemperatureLabel,
                dllGetPressureAndTemperatureLabel,
                dllReadCoefficientDataFromSourcePageLabel,
                dllWriteCoefficientDataToTargetPageLabel,
                dllExecuteI2CCommandLabel,
                dllReadUnitADCLabel,
                dllGetTransducerCurrentLabel,
                dllGetTransducerVoltageLabel,
                dllGetUnitControlRegisterLabel,
                dllGetUnitStatusRegisterLabel,
                dllGetUnitFirmwareIDLabel,
                dllGetCadenceTimerLabel,
                dllGetUnitModeSwitchSettingLabel,
                dllGetErrorCodeLabel,
                dllGetI2CDataRateLabel,
                dllCalculatePressureAndTemperatureLabel,
                dllGetModuleSerialNumberLabel,
                dllReadCoefficientDataFromDeviceLabel,
                dllReadCoefficientDataFromUnitPageLabel,
                dllGetMemoryTypeLabel
            };
            miscDisplayDLLFunctionsUnitGroupBox->Controls->AddRange(miscUnitDLLLabels);
            miscDisplayDLLFunctionsWindow->Size = Drawing::Size(
                miscDisplayDLLFunctionsGeneralGroupBox->Width + 30,
                miscDisplayDLLFunctionsGeneralGroupBox->Height + 20 +
                miscDisplayDLLFunctionsUnitGroupBox->Height + 90);
            //----------------------------------------------------------------
            // Add a Close button
            //----------------------------------------------------------------
            Button ^miscDisplayDLLCloseButton = gcnew Button;
            miscDisplayDLLCloseButton->Text = _T("Close");
            miscDisplayDLLCloseButton->Location = Point(
                miscDisplayDLLFunctionsWindow->Right - 100,
                miscDisplayDLLFunctionsWindow->Bottom - 70);
            miscDisplayDLLCloseButton->Size = Drawing::Size(
                GUI_CLOSE_BUTTON_WIDTH,
                GUI_REGULAR_BUTTON_HEIGHT);
            miscDisplayDLLCloseButton->DialogResult = System::Windows::Forms::DialogResult::OK;
            GUI_SetUnitButtonInterfaceProperties(
                miscDisplayDLLCloseButton,
                unitNumber);
            miscDisplayDLLCloseButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscCloseDisplayDLLFunctionsWindow);
            miscDisplayDLLFunctionsWindow->AcceptButton = miscDisplayDLLCloseButton;
            miscDisplayDLLFunctionsWindow->CancelButton = miscDisplayDLLCloseButton;
            //----------------------------------------------------------------
            // Add the components to the Display DLL Functions window
            //----------------------------------------------------------------
            miscDisplayDLLFunctionsWindow->Controls->Add(miscDisplayDLLFunctionsGeneralGroupBox);
            miscDisplayDLLFunctionsWindow->Controls->Add(miscDisplayDLLFunctionsUnitGroupBox);
            miscDisplayDLLFunctionsWindow->Controls->Add(miscDisplayDLLCloseButton);
            miscDisplayDLLFunctionsWindowArray[unitNumber] = miscDisplayDLLFunctionsWindow;
            //----------------------------------------------------------------
            // Finally, display the new window
            //----------------------------------------------------------------
            miscDisplayDLLFunctionsWindow->ShowDialog();
            miscDisplayDLLFunctionsWindow->ResumeLayout();
            miscDisplayDLLFunctionsWindow->BringToFront();
            if (miscDisplayDLLFunctionsWindow->CanFocus)
                miscDisplayDLLFunctionsWindow->Focus();
            free((void *) firmwareData);
            free((void *) testFirmwareFilePath);
            free((void *) coefficientData);
            free((void *) coefficientFilePath);
            free((void *) cwd);
            free((void *) displayString);
        }                               // end of if (displayString && ...)
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_MiscDisplayDLLFunctions()
//----------------------------------------------------------------------------
// QCOM_MiscGetAndPostI2CDataRate
//
// Retrieves the current I�C data rate setting of the transducer at the
// specified unit
//
// Called by:   QCOM_MiscConstructUnitControlTab
//              QCOM_MiscGetI2CDataRateButtonClicked
//              QCOM_MiscValidateI2CDataRateBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscGetAndPostI2CDataRate(
    UnitInfo        ^unit)
{
    double          currentDataRate = 0.0;
    String          ^functionName = _T("QCOM_MiscGetAndPostI2CDataRate");
    //------------------------------------------------------------------------
    if (QCOM_UnitOpen(unit))
    {
        DWORD status = QD_GetI2CDataRate(
            unit->unitHandle,
            &currentDataRate);
        if (status == QD_SUCCESS)
        {
            miscGetDataRateBoxArray[unit->unitNumber]->BackColor = Color::White;
            miscGetDataRateBoxArray[unit->unitNumber]->Text = String::Format(
                "{0:F1}", currentDataRate);
            RecordVerboseEvent(
                "{0}({1:D}) :\nI�C Data Rate = {2:F2} kHz",
                functionName, unit->unitNumber,
                miscGetDataRateBoxArray[unit->unitNumber]->Text);
        }
        else
        {
            miscGetDataRateBoxArray[unit->unitNumber]->BackColor = Color::Orange;
            miscGetDataRateBoxArray[unit->unitNumber]->Text = String::Format(
                "0x{0:X2}", (status & 0xFF));
            RecordErrorEvent(
                "    QD_GetI2CDataRate returned status 0x{0:X8}", status);
        }
    }
    else
    {
        miscGetDataRateBoxArray[unit->unitNumber]->Text = _T("- - - - - -");
    }
}                                       // end of QCOM_MiscGetAndPostI2CDataRate()
//----------------------------------------------------------------------------
// QCOM_MiscPFSetUpControl
//
// Constructs a new window that presents the persistent flags control
//
// Called by:   QCOM_MiscSetUpControls
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFSetUpControl(void)
{
    //------------------------------------------------------------------------
    // Create a new window form
    //------------------------------------------------------------------------
    miscPFControlWindow = gcnew Form;
    miscPFControlWindow->SuspendLayout();
    //------------------------------------------------------------------------
    // Set its appearance
    //------------------------------------------------------------------------
    miscPFControlWindow->MaximizeBox = GUI_NO;
    miscPFControlWindow->HelpButton = GUI_NO;
//    miscPFControlWindow->TopMost = GUI_YES;
    //------------------------------------------------------------------------
    // Set its icon
    //------------------------------------------------------------------------
    miscPFControlWindow->Icon = QCOM_SoftwareIcon;
    //------------------------------------------------------------------------
    // Set the background image
    //------------------------------------------------------------------------
    miscPFControlWindow->BackgroundImage = greenMarbleBackground;
    //------------------------------------------------------------------------
    // Set the title, size, and border style
    //------------------------------------------------------------------------
    miscPFControlWindow->Text = _T("Persistent Flags Control");
    miscPFControlWindow->Size = Drawing::Size(
        GUI_PF_WINDOW_WIDTH,
        GUI_PF_WINDOW_HEIGHT);
    miscPFControlWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
    miscPFControlWindow->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Regular);
    //------------------------------------------------------------------------
    // Display the heading explanation and warning text
    //------------------------------------------------------------------------
    Label ^miscPFCExplain1 = gcnew Label;
    miscPFCExplain1->Text =
        _T("This window allows you to select the program flags that should ")
        _T("retain their settings after the program exits.  The General Flags");
    miscPFCExplain1->Location = Point(10, 10);
    miscPFCExplain1->Size = Drawing::Size(
        miscPFControlWindow->Width - 30,
        GUI_LARGE_LABEL_HEIGHT);
    miscPFCExplain1->BackColor = Color::Transparent;
    miscPFCExplain1->ForeColor = Color::Black;
    Label ^miscPFCExplain2 = gcnew Label;
    miscPFCExplain2->Text =
        _T("are those that control or affect the software as a whole, while ")
        _T("Unit Flags do so for individual instances of attached QCOM");
    miscPFCExplain2->Location = Point(
        miscPFCExplain1->Left,
        miscPFCExplain1->Bottom);
    miscPFCExplain2->Size = miscPFCExplain1->Size;
    miscPFCExplain2->BackColor = Color::Transparent;
    miscPFCExplain2->ForeColor = Color::Black;
    Label ^miscPFCExplain3 = gcnew Label;
    miscPFCExplain3->Text =
        _T("modules and/or transducers.  Understand that some flags by their ")
        _T("nature cannot be made persistent.");
    miscPFCExplain3->Location = Point(
        miscPFCExplain1->Left,
        miscPFCExplain2->Bottom);
    miscPFCExplain3->Size = miscPFCExplain1->Size;
    miscPFCExplain3->BackColor = Color::Transparent;
    miscPFCExplain3->ForeColor = Color::Black;
    Label ^miscPFCWarning1 = gcnew Label;
    miscPFCWarning1->Text =
        _T("Caution: The QCOM software uses these internal flags to ")
        _T("control program behavior, and their persistence allows the");
    miscPFCWarning1->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    miscPFCWarning1->Location = Point(
        miscPFCExplain1->Left,
        miscPFCExplain3->Bottom + 10);
    miscPFCWarning1->Size = miscPFCExplain1->Size;
    miscPFCWarning1->BackColor = Color::Transparent;
    miscPFCWarning1->ForeColor = Color::DarkBlue;
    Label ^miscPFCWarning2 = gcnew Label;
    miscPFCWarning2->Text =
        _T("software to retain their settings between one run of the ")
        _T("program and the next.  Indiscriminate setting of these");
    miscPFCWarning2->Font = gcnew
        Drawing::Font(
            FontFamily::GenericSansSerif,
            10.0F,
            FontStyle::Bold);
    miscPFCWarning2->Location = Point(
        miscPFCExplain1->Left + 60,
        miscPFCWarning1->Bottom);
    miscPFCWarning2->Size = Drawing::Size(
        miscPFCWarning1->Width - 60,
        GUI_LARGE_LABEL_HEIGHT);
    miscPFCWarning2->BackColor = Color::Transparent;
    miscPFCWarning2->ForeColor = Color::DarkBlue;
    Label ^miscPFCWarning3 = gcnew Label;
    miscPFCWarning3->Text =
        _T("flags can result in unexpected program behavior, and ")
        _T("retaining the settings in this case might require the");
    miscPFCWarning3->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    miscPFCWarning3->Location = Point(
        miscPFCWarning2->Left,
        miscPFCWarning2->Bottom);
    miscPFCWarning3->Size = miscPFCWarning2->Size;
    miscPFCWarning3->BackColor = Color::Transparent;
    miscPFCWarning3->ForeColor = Color::DarkBlue;
    Label ^miscPFCWarning4 = gcnew Label;
    miscPFCWarning4->Text =
        _T("deletion of the config file and a program restart to ")
        _T("restore proper software functionality.");
    miscPFCWarning4->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    miscPFCWarning4->Location = Point(
        miscPFCWarning2->Left,
        miscPFCWarning3->Bottom);
    miscPFCWarning4->Size = miscPFCWarning2->Size;
    miscPFCWarning4->BackColor = Color::Transparent;
    miscPFCWarning4->ForeColor = Color::DarkBlue;
    //------------------------------------------------------------------------
    // General group box
    //------------------------------------------------------------------------
    GroupBox ^miscPFCGeneralGroupBox = gcnew GroupBox;
    miscPFCGeneralGroupBox->Text = _T("Persistent General Flags");
    miscPFCGeneralGroupBox->Location = Point(
        miscPFCExplain1->Left,
        miscPFCWarning4->Bottom + 10);
    miscPFCGeneralGroupBox->BackColor = Color::Transparent;
    miscPFCGeneralGroupBox->Size = Drawing::Size(
        miscPFControlWindow->Width - 30, 160);
    //------------------------------------------------------------------------
    // Sounds enabled
    //------------------------------------------------------------------------
    miscPFGeneralSoundsEnabledCheck = gcnew CheckBox;
    miscPFGeneralSoundsEnabledCheck->Text = _T("Sounds enabled");
    miscPFGeneralSoundsEnabledCheck->Location = Point(10, 20);
    miscPFGeneralSoundsEnabledCheck->Size = Drawing::Size(
        250, GUI_LARGE_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(miscPFGeneralSoundsEnabledCheck);
    miscPFGeneralSoundsEnabledCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFGeneralSoundsEnabledChecked);
    //------------------------------------------------------------------------
    // Prepend data log entry numbers
    //------------------------------------------------------------------------
    miscPFGeneralLogPrependEntryNumbersCheck = gcnew CheckBox;
    miscPFGeneralLogPrependEntryNumbersCheck->Text = _T("Prepend all data log entries");
    miscPFGeneralLogPrependEntryNumbersCheck->Location = Point(
        miscPFGeneralSoundsEnabledCheck->Right + 10,
        miscPFGeneralSoundsEnabledCheck->Top);
    miscPFGeneralLogPrependEntryNumbersCheck->Size = miscPFGeneralSoundsEnabledCheck->Size;
    GUI_SetObjectInterfaceProperties(miscPFGeneralLogPrependEntryNumbersCheck);
    miscPFGeneralLogPrependEntryNumbersCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFGeneralLogPrependEntryNumbersChecked);
    //------------------------------------------------------------------------
    // Display all data log summaries
    //------------------------------------------------------------------------
    miscPFGeneralLogDisplayAllSummariesCheck = gcnew CheckBox;
    miscPFGeneralLogDisplayAllSummariesCheck->Text = _T("Display all data log summaries");
    GUI_PositionAndSizeBelow(miscPFGeneralLogDisplayAllSummariesCheck, miscPFGeneralLogPrependEntryNumbersCheck, 2);
    GUI_SetObjectInterfaceProperties(miscPFGeneralLogDisplayAllSummariesCheck);
    miscPFGeneralLogDisplayAllSummariesCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFGeneralLogDisplayAllSummariesChecked);
    //------------------------------------------------------------------------
    // Display all data log wrapped
    //------------------------------------------------------------------------
    miscPFGeneralLogDisplayAllWrappedCheck = gcnew CheckBox;
    miscPFGeneralLogDisplayAllWrappedCheck->Text = _T("Wrap text in all display boxes");
    GUI_PositionAndSizeBelow(miscPFGeneralLogDisplayAllWrappedCheck, miscPFGeneralLogPrependEntryNumbersCheck, 2);
    GUI_SetObjectInterfaceProperties(miscPFGeneralLogDisplayAllWrappedCheck);
    miscPFGeneralLogDisplayAllWrappedCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFGeneralLogDisplayAllWrappedChecked);
    //------------------------------------------------------------------------
    // Log both CSV and text formats
    //------------------------------------------------------------------------
    miscPFGeneralLogBothFileFormatsCheck = gcnew CheckBox;
    miscPFGeneralLogBothFileFormatsCheck->Text = _T("Log both CSV and Text formats");
    GUI_PositionAndSizeBelow(miscPFGeneralLogBothFileFormatsCheck, miscPFGeneralLogDisplayAllWrappedCheck, 2);
    GUI_SetObjectInterfaceProperties(miscPFGeneralLogBothFileFormatsCheck);
    miscPFGeneralLogBothFileFormatsCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFGeneralLogBothFileFormatsChecked);
    //------------------------------------------------------------------------
    // Save data log immediately
    //------------------------------------------------------------------------
    miscPFGeneralLogDataSaveImmediatelyCheck = gcnew CheckBox;
    miscPFGeneralLogDataSaveImmediatelyCheck->Text = _T("Save all logged data immediately");
    GUI_PositionAndSizeBelow(miscPFGeneralLogDataSaveImmediatelyCheck, miscPFGeneralLogBothFileFormatsCheck, 2);
    GUI_SetObjectInterfaceProperties(miscPFGeneralLogDataSaveImmediatelyCheck);
    miscPFGeneralLogDataSaveImmediatelyCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFGeneralLogDataSaveImmediatelyChecked);
    //------------------------------------------------------------------------
    // Display transducer tests
    //------------------------------------------------------------------------
    miscPFGeneralTestDisplayXDTestsCheck = gcnew CheckBox;
    miscPFGeneralTestDisplayXDTestsCheck->Text = _T("Display transducer tests");
    miscPFGeneralTestDisplayXDTestsCheck->Location = Point(
        miscPFGeneralLogPrependEntryNumbersCheck->Right + 10,
        miscPFGeneralLogPrependEntryNumbersCheck->Top);
    miscPFGeneralTestDisplayXDTestsCheck->Size = miscPFGeneralLogPrependEntryNumbersCheck->Size;
    GUI_SetObjectInterfaceProperties(miscPFGeneralTestDisplayXDTestsCheck);
    miscPFGeneralTestDisplayXDTestsCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFGeneralTestDisplayXDTestsChecked);
    //------------------------------------------------------------------------
    // Add all the general check boxes
    //------------------------------------------------------------------------
    array <CheckBox ^> ^miscPFGeneralChecks =
    {
        miscPFGeneralSoundsEnabledCheck,
        miscPFGeneralLogPrependEntryNumbersCheck,
        miscPFGeneralLogDisplayAllSummariesCheck,
        miscPFGeneralLogDisplayAllWrappedCheck,
        miscPFGeneralLogBothFileFormatsCheck,
        miscPFGeneralLogDataSaveImmediatelyCheck,
        miscPFGeneralTestDisplayXDTestsCheck
    };
    miscPFCGeneralGroupBox->Controls->AddRange(miscPFGeneralChecks);
    //------------------------------------------------------------------------
    // Unit group box
    //------------------------------------------------------------------------
    GroupBox ^miscPFCUnitGroupBox = gcnew GroupBox;
    miscPFCUnitGroupBox->Text = _T("Persistent Unit Flags");
    miscPFCUnitGroupBox->Location = Point(
        miscPFCGeneralGroupBox->Left,
        miscPFCGeneralGroupBox->Bottom + 15);
    miscPFCUnitGroupBox->BackColor = Color::Transparent;
    miscPFCUnitGroupBox->Size = Drawing::Size(
        miscPFCGeneralGroupBox->Width, 160);
    //------------------------------------------------------------------------
    // Display transducer counts in hex
    //------------------------------------------------------------------------
    miscPFUnitHexCountsCheck = gcnew CheckBox;
    miscPFUnitHexCountsCheck->Text = _T("Display counts in hex");
    miscPFUnitHexCountsCheck->Location = Point(10, 20);
    miscPFUnitHexCountsCheck->Size = Drawing::Size(
        250, GUI_LARGE_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(miscPFUnitHexCountsCheck);
    miscPFUnitHexCountsCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFUnitDisplayHexCountsChecked);
    //------------------------------------------------------------------------
    // Send transducer readings
    //------------------------------------------------------------------------
    miscPFUnitSendXDReadingsCheck = gcnew CheckBox;
    miscPFUnitSendXDReadingsCheck->Text = _T("Send transducer readings");
    GUI_PositionAndSizeBelow(miscPFUnitSendXDReadingsCheck, miscPFUnitHexCountsCheck, 2);
    GUI_SetObjectInterfaceProperties(miscPFUnitSendXDReadingsCheck);
    miscPFUnitSendXDReadingsCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFUnitSendXDReadingsChecked);
    //------------------------------------------------------------------------
    // Send transducer readings by text message
    //------------------------------------------------------------------------
    miscPFUnitTextXDReadingsCheck = gcnew CheckBox;
    miscPFUnitTextXDReadingsCheck->Text = _T("Text transducer readings");
    GUI_PositionAndSizeBelow(miscPFUnitTextXDReadingsCheck, miscPFUnitSendXDReadingsCheck, 2);
    GUI_SetObjectInterfaceProperties(miscPFUnitTextXDReadingsCheck);
    miscPFUnitTextXDReadingsCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFUnitTextXDReadingsChecked);
    //------------------------------------------------------------------------
    // Send transducer readings by email message
    //------------------------------------------------------------------------
    miscPFUnitEmailXDReadingsCheck = gcnew CheckBox;
    miscPFUnitEmailXDReadingsCheck->Text = _T("Email transducer readings");
    GUI_PositionAndSizeBelow(miscPFUnitEmailXDReadingsCheck, miscPFUnitTextXDReadingsCheck, 2);
    GUI_SetObjectInterfaceProperties(miscPFUnitEmailXDReadingsCheck);
    miscPFUnitEmailXDReadingsCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFUnitEmailXDReadingsChecked);
    //------------------------------------------------------------------------
    // Save data log immediately
    //------------------------------------------------------------------------
    miscPFUnitLogDataSaveImmediatelyCheck = gcnew CheckBox;
    miscPFUnitLogDataSaveImmediatelyCheck->Text = _T("Save logged data immediately");
    miscPFUnitLogDataSaveImmediatelyCheck->Location = Point(
        miscPFUnitHexCountsCheck->Right + 10,
        miscPFUnitHexCountsCheck->Top);
    miscPFUnitLogDataSaveImmediatelyCheck->Size = miscPFUnitHexCountsCheck->Size;
    GUI_SetObjectInterfaceProperties(miscPFUnitLogDataSaveImmediatelyCheck);
    miscPFUnitLogDataSaveImmediatelyCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFUnitLogDataSaveImmediatelyChecked);
    //------------------------------------------------------------------------
    // Display test results
    //------------------------------------------------------------------------
    miscPFUnitTestResultsDisplayCheck = gcnew CheckBox;
    miscPFUnitTestResultsDisplayCheck->Text = _T("Display test results");
    miscPFUnitTestResultsDisplayCheck->Location = Point(
        miscPFUnitLogDataSaveImmediatelyCheck->Right + 10,
        miscPFUnitLogDataSaveImmediatelyCheck->Top);
    miscPFUnitTestResultsDisplayCheck->Size = miscPFUnitLogDataSaveImmediatelyCheck->Size;
    GUI_SetObjectInterfaceProperties(miscPFUnitTestResultsDisplayCheck);
    miscPFUnitTestResultsDisplayCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFUnitTestResultsDisplayChecked);
    //------------------------------------------------------------------------
    // Add all the unit check boxes and reflect their settings
    //------------------------------------------------------------------------
    array <CheckBox ^> ^miscPFUnitChecks =
    {
        miscPFUnitHexCountsCheck,
        miscPFUnitTestResultsDisplayCheck,
        miscPFUnitLogDataSaveImmediatelyCheck,
        miscPFUnitSendXDReadingsCheck,
        miscPFUnitTextXDReadingsCheck,
        miscPFUnitEmailXDReadingsCheck
    };
    miscPFCUnitGroupBox->Controls->AddRange(miscPFUnitChecks);
    QCOM_MiscUpdatePersistentChecks();
    //------------------------------------------------------------------------
    // Add the Set All Defaults button
    //------------------------------------------------------------------------
    Button ^miscPFSetAllFlagDefaultsButton = gcnew Button;
    miscPFSetAllFlagDefaultsButton->Text = _T("Set All Flags To Defaults");
    miscPFSetAllFlagDefaultsButton->Location = Point(
        20, miscPFControlWindow->Bottom - 70);
    miscPFSetAllFlagDefaultsButton->Size = Drawing::Size(160, GUI_REGULAR_BUTTON_HEIGHT);
    miscPFSetAllFlagDefaultsButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        8.0F,
        FontStyle::Regular);
    GUI_SetButtonInterfaceProperties(miscPFSetAllFlagDefaultsButton);
    miscPFSetAllFlagDefaultsButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFSetAllDefaultsButtonClicked);
    //------------------------------------------------------------------------
    // Add the Set General Defaults button
    //------------------------------------------------------------------------
    Button ^miscPFSetGeneralFlagDefaultsButton = gcnew Button;
    miscPFSetGeneralFlagDefaultsButton->Text = _T("Set General Flags To Defaults");
    miscPFSetGeneralFlagDefaultsButton->Location = Point(
        miscPFSetAllFlagDefaultsButton->Right + 25,
        miscPFSetAllFlagDefaultsButton->Top);
    miscPFSetGeneralFlagDefaultsButton->Size = Drawing::Size(160, GUI_REGULAR_BUTTON_HEIGHT);
    miscPFSetGeneralFlagDefaultsButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        8.0F,
        FontStyle::Regular);
    GUI_SetButtonInterfaceProperties(miscPFSetGeneralFlagDefaultsButton);
    miscPFSetGeneralFlagDefaultsButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFSetGeneralDefaultsButtonClicked);
    //------------------------------------------------------------------------
    // Add the Set Unit Defaults button
    //------------------------------------------------------------------------
    Button ^miscPFSetUnitFlagDefaultsButton = gcnew Button;
    miscPFSetUnitFlagDefaultsButton->Text = _T("Set Unit Flags To Defaults");
    miscPFSetUnitFlagDefaultsButton->Location = Point(
        miscPFSetGeneralFlagDefaultsButton->Right + 25,
        miscPFSetGeneralFlagDefaultsButton->Top);
    miscPFSetUnitFlagDefaultsButton->Size = Drawing::Size(160, GUI_REGULAR_BUTTON_HEIGHT);
    miscPFSetUnitFlagDefaultsButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        8.0F,
        FontStyle::Regular);
    GUI_SetButtonInterfaceProperties(miscPFSetUnitFlagDefaultsButton);
    miscPFSetUnitFlagDefaultsButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFSetUnitDefaultsButtonClicked);
    //------------------------------------------------------------------------
    // Add a Close button
    //------------------------------------------------------------------------
    Button ^miscSetUpPersistentFlagsCloseButton = gcnew Button;
    miscSetUpPersistentFlagsCloseButton->Text = _T("Close");
    miscSetUpPersistentFlagsCloseButton->Location = Point(
        miscPFControlWindow->Right - 100,
        miscPFControlWindow->Bottom - 70);
    miscSetUpPersistentFlagsCloseButton->Size = Drawing::Size(
        GUI_CLOSE_BUTTON_WIDTH,
        GUI_REGULAR_BUTTON_HEIGHT);
    miscSetUpPersistentFlagsCloseButton->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        8.0F,
        FontStyle::Regular);
    miscSetUpPersistentFlagsCloseButton->DialogResult = System::Windows::Forms::DialogResult::OK;
    GUI_SetButtonInterfaceProperties(miscSetUpPersistentFlagsCloseButton);
    miscSetUpPersistentFlagsCloseButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFCloseWindow);
    //------------------------------------------------------------------------
    // Handle the closing of the window by any other way
    //------------------------------------------------------------------------
    miscPFControlWindow->FormClosing +=
        gcnew FormClosingEventHandler(this, &QCOM_GUIClass::QCOM_MiscClosingPFCWindow);
    //------------------------------------------------------------------------
    // Add the components to the Persistent Flags window
    //------------------------------------------------------------------------
    miscPFControlWindow->Controls->Add(miscPFCGeneralGroupBox);
    miscPFControlWindow->Controls->Add(miscPFCUnitGroupBox);
    array <Label ^> ^miscPFLabels =
    {
        miscPFCExplain1,
        miscPFCExplain2,
        miscPFCExplain3,
        miscPFCWarning1,
        miscPFCWarning2,
        miscPFCWarning3,
        miscPFCWarning4
    };
    miscPFControlWindow->Controls->AddRange(miscPFLabels);
    array <Button ^> ^miscPFButtons =
    {
        miscPFSetAllFlagDefaultsButton,
        miscPFSetGeneralFlagDefaultsButton,
        miscPFSetUnitFlagDefaultsButton,
        miscSetUpPersistentFlagsCloseButton
    };
    miscPFControlWindow->Controls->AddRange(miscPFButtons);
    //------------------------------------------------------------------------
    // Set the remaining window properties
    //------------------------------------------------------------------------
    miscPFControlWindow->AcceptButton = miscSetUpPersistentFlagsCloseButton;
    miscPFControlWindow->CancelButton = miscSetUpPersistentFlagsCloseButton;
    //------------------------------------------------------------------------
    // Finally, display the new window...later
    //------------------------------------------------------------------------
    miscPFControlWindow->ResumeLayout();
    miscPFControlWindow->Hide();
}                                       // end of QCOM_MiscPFSetUpControl()
//----------------------------------------------------------------------------
// QCOM_MiscSendI2CCommand
//
// Sends an I2C command to the transducer via the specified unit, and displays
// the response in the appropriate Misc window
//
// Called by:   QCOM_MiscProcessI2CCommandBoxEnterKey
//              QCOM_MiscSendI2CCommandButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscSendI2CCommand(
    UnitInfo        ^unit)
{
    char            *commandString;
    char            *interpretationString;
    char            *replyString;
    DWORD           status;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_MiscSendI2CCommand");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        miscI2CReplyInterpLabelArray[unitNumber]->Visible = GUI_NO;
        commandString = (char *) malloc(QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE);  // 768
        replyString = (char *) malloc(QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);      // 768
        interpretationString = (char *) malloc(QCOM_MAXIMUM_I2C_INTERP_STRING_SIZE);
        if (commandString && replyString && interpretationString)
        {
            ClearBuffer(commandString, QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE);
            QCOM_ConvertString(
                miscI2CCommandComboArray[unitNumber]->Text,
                commandString,
                QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE);
            ClearBuffer(replyString, QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
            status = QCOM_ProcessI2CCommand(
                unit,
                commandString,
                replyString,
                interpretationString);
            if (status == QCOM_SUCCESS)
            {
                miscI2CResponseBoxArray[unitNumber]->Text = gcnew String(replyString);
                miscI2CReplyInterpLabelArray[unitNumber]->Text = gcnew String(interpretationString);
                miscI2CReplyInterpLabelArray[unitNumber]->Visible = GUI_YES;
            }
            else
            {
                miscI2CResponseBoxArray[unitNumber]->Text = String::Format(
                    "<Error 0x{0:X8}>", status);
                miscI2CReplyInterpLabelArray[unitNumber]->Visible = GUI_NO;
                RecordErrorEvent(
                    "    Send I�C Command resulted in {0}",
                    miscI2CResponseBoxArray[unitNumber]->Text);
            }
            free((void *) interpretationString);
            free((void *) replyString);
            free((void *) commandString);
        }
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_MiscSendI2CCommand()
//----------------------------------------------------------------------------
// QCOM_MiscSetAndPostCadenceTimer
//
// Sets the Cadence Timer of the transducer at the specified unit to the value
// indicated in the Cadence Timer text box of the appropriate Misc window
//
// Called by:   QCOM_MiscSetCadenceTimerButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscSetAndPostCadenceTimer(
    UnitInfo        ^unit)
{
    DWORD           cadenceTimer;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_MiscSetAndPostCadenceTimer");
    //------------------------------------------------------------------------
    if (QCOM_UnitReady(unit))
    {
        unitNumber = unit->unitNumber;
        if (StringSet(miscGetCadenceTimerBoxArray[unitNumber]->Text))
        {
            bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
                miscGetCadenceTimerBoxArray[unitNumber]->Text,
                &cadenceTimer);
            if (isCorrectFormat)
            {
                DWORD status = QD_SetCadenceTimer(
                    unit->unitHandle,
                    cadenceTimer);
                if (status == QD_SUCCESS)
                {
                    cadenceTimer = 0;
                    QD_GetCadenceTimer(
                        unit->unitHandle,
                        &cadenceTimer);
                    miscGetCadenceTimerBoxArray[unitNumber]->BackColor = Color::Lavender;
                    miscGetCadenceTimerBoxArray[unitNumber]->Text = String::Concat(cadenceTimer);
                    RecordBasicEvent(
                        "{0}({1:D}) : Cadence Timer set to {2}",
                        functionName, unitNumber,
                        miscGetCadenceTimerBoxArray[unitNumber]->Text);
                }
                else
                {
                    miscGetCadenceTimerBoxArray[unitNumber]->BackColor = Color::Orange;
                    miscGetCadenceTimerBoxArray[unitNumber]->Text = String::Format(
                        "0x{0:X2}", (status & 0xFF));
                    RecordErrorEvent(
                        "    QD_SetCadenceTimer returned status 0x{0:X8}", status);
                }
            }                           // end of if (isCorrectFormat)
            else
            {
                QCOM_PromptOKModal(
                    "Invalid Characters",
                    "The entry contains invalid characters;\n"
                    "enter only decimal digits");
                RecordErrorEvent(
                    "    Attempted setting cadence timer value to '{0}'",
                    miscGetCadenceTimerBoxArray[unitNumber]->Text);
                miscGetCadenceTimerBoxArray[unitNumber]->BackColor = Color::Orange;
            }
        }                               // end of if (StringSet(miscGetCadenceTimerBoxArray[unitNumber]->Text))
    }
    else
    {
        miscGetCadenceTimerBoxArray[unit->unitNumber]->Clear();
    }
}                                       // end of QCOM_MiscSetAndPostCadenceTimer()
//----------------------------------------------------------------------------
// QCOM_MiscSetAndPostControlRegister
//
// Sets the Control Register of the transducer at the specified unit to
// the value indicated in the Control Register text box
//
// Called by:   QCOM_MiscSetControlRegisterButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscSetAndPostControlRegister(
    UnitInfo        ^unit)
{
    BYTE            controlRegisterValue;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_MiscSetAndPostControlRegister");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        if (StringSet(miscGetControlRegisterBoxArray[unitNumber]->Text))
        {
            String ^originalBoxString = miscGetControlRegisterBoxArray[unitNumber]->Text->ToLower();
            String ^newBoxString = originalBoxString;
            if (originalBoxString->StartsWith("0x"))
                newBoxString = originalBoxString->Substring(2);
            controlRegisterValue = Convert::ToByte(newBoxString);
            //----------------------------------------------------------------
            // Prevent the tester from changing any reserved bits
            //----------------------------------------------------------------
            if ((controlRegisterValue & 0xFD) == 0x00)
            {
                DWORD status = QD_SetModuleControlRegister(
                    unit->unitHandle,
                    controlRegisterValue);
                if (status == QD_SUCCESS)
                {
                    miscGetControlRegisterBoxArray[unitNumber]->BackColor = Color::Lavender;
                    miscGetControlRegisterBoxArray[unitNumber]->Text = String::Format(
                        "0x{0:X2}", controlRegisterValue);
                    RecordBasicEvent(
                        "{0}({1:D}) : Control Register set to {2}",
                        functionName, unitNumber,
                        miscGetControlRegisterBoxArray[unitNumber]->Text);
                }
                else
                {
                    miscGetControlRegisterBoxArray[unitNumber]->BackColor = Color::Orange;
                    miscGetControlRegisterBoxArray[unitNumber]->Text = String::Format(
                        "0x{0:X2}", (status & 0xFF));
                    RecordErrorEvent(
                        "    QD_SetModuleControlRegister returned status 0x{0:X8}", status);
                }
            }
            else
            {
                GUI_DisplayMandatoryError(functionName,
                    "Attempt at setting a reserved\ncontrol register bit");
                miscGetControlRegisterBoxArray[unitNumber]->Text = originalBoxString;
            }
            delete originalBoxString;
        }
    }
    else
    {
        miscGetControlRegisterBoxArray[unit->unitNumber]->Clear();
    }
}                                       // end of QCOM_MiscSetAndPostControlRegister()
//----------------------------------------------------------------------------
// QCOM_MiscSetAndPostI2CDataRate
//
// Sets the I�C Data Rate setting of the transducer at the specified unit to
// the value indicated in the I�C text box
//
// Called by:   QCOM_MiscSetI2CDataRateButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscSetAndPostI2CDataRate(
    UnitInfo        ^unit)
{
    double          newDataRate;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_MiscSetAndPostI2CDataRate");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        if (StringSet(miscGetDataRateBoxArray[unitNumber]->Text))
        {
            newDataRate = Convert::ToDouble(miscGetDataRateBoxArray[unitNumber]->Text);
            DWORD status = QD_SetI2CDataRate(
                unit->unitHandle,
                newDataRate);
            if (status == QD_SUCCESS)
            {
                miscGetDataRateBoxArray[unitNumber]->BackColor = Color::Lavender;
                miscGetDataRateBoxArray[unitNumber]->Text =
                    String::Format("{0:F1}", newDataRate);
                RecordBasicEvent(
                    "{0}({1:D}) : I�C Data Rate set to {2}",
                    functionName, unitNumber,
                    miscGetDataRateBoxArray[unitNumber]->Text);
            }
            else
            {
                miscGetDataRateBoxArray[unitNumber]->BackColor = Color::Orange;
                miscGetDataRateBoxArray[unitNumber]->Text = String::Format(
                    "0x{0:X2}", (status & 0xFF));
                RecordErrorEvent(
                    "    QD_SetI2CDataRate returned status 0x{0:X8}", status);
            }
        }
    }
    else
    {
        miscGetDataRateBoxArray[unit->unitNumber]->Text = _T("- - - - - -");
    }
}                                       // end of QCOM_MiscSetAndPostI2CDataRate()
//----------------------------------------------------------------------------
// QCOM_MiscSetAndPostTimeouts
//
// Sets the read and write timeouts to the values indicated in the Read and
// Write Timeout text boxes of the appropriate Misc window
//
// Called by:   QCOM_MiscSetTimeoutsButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscSetAndPostTimeouts(void)
{
    DWORD           readTimeout;
    DWORD           writeTimeout;
    String          ^functionName = _T("QCOM_MiscSetAndPostTimeouts");
    //------------------------------------------------------------------------
    if (StringSet(miscReadTimeoutBox->Text) || StringSet(miscWriteTimeoutBox->Text))
    {
        bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
            miscReadTimeoutBox->Text,
            &readTimeout);
        if (isCorrectFormat)
        {
            bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
                miscWriteTimeoutBox->Text,
                &writeTimeout);
            if (isCorrectFormat)
            {
                DWORD status = QD_SetTimeouts(
                    readTimeout,
                    writeTimeout);
                if (status == QD_SUCCESS)
                {
                    miscReadTimeoutBox->BackColor = Color::White;
                    miscReadTimeoutBox->Text = String::Concat(readTimeout);
                    miscWriteTimeoutBox->BackColor = Color::White;
                    miscWriteTimeoutBox->Text = String::Concat(writeTimeout);
                    RecordBasicEvent(
                        "{0} : Command timeouts set to read = {1:D}, write = {2:D}",
                        functionName, readTimeout, writeTimeout);
                }
                else
                {
                    miscReadTimeoutBox->BackColor = Color::Orange;
                    miscReadTimeoutBox->Text = String::Format(
                        "0x{0:X2}", (status & 0xFF));
                    miscWriteTimeoutBox->BackColor = Color::Orange;
                    miscWriteTimeoutBox->Text = String::Format(
                        "0x{0:X2}", (status & 0xFF));
                    RecordErrorEvent(
                        "    QD_SetTimeouts returned status 0x{0:X8}", status);
                }
            }                           // end of if (isCorrectFormat)
            else
            {
                QCOM_PromptOKModal(
                    "Invalid Characters",
                    "The entry contains invalid characters;\n"
                    "enter only decimal digits");
                RecordErrorEvent(
                    "    Attempted setting write timeout value to '{0}'",
                    miscWriteTimeoutBox->Text);
                miscWriteTimeoutBox->BackColor = Color::Orange;
            }
        }                               // end of if (isCorrectFormat)
        else
        {
            QCOM_PromptOKModal(
                "Invalid Characters",
                "The entry contains invalid characters;\n"
                "enter only decimal digits");
            RecordErrorEvent(
                "    Attempted setting read timeout value to '{0}'",
                miscReadTimeoutBox->Text);
            miscReadTimeoutBox->BackColor = Color::Orange;
        }
    }                                   // end of if (StringSet(miscReadTimeoutBox->Text) || StringSet(miscWriteTimeoutBox->Text))
}                                       // end of QCOM_MiscSetAndPostTimeouts()
//----------------------------------------------------------------------------
// QCOM_MiscSetUpControls
//
// Constructs a new window that presents a variety of controls and utilities
//
// Called by:   QCOM_InstallUtilities
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscSetUpControls(void)
{
    String          ^functionName = _T("QCOM_MiscSetUpControls");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Create a new window form
    //------------------------------------------------------------------------
    miscControlWindow = gcnew Form;
    miscControlWindow->SuspendLayout();
    //------------------------------------------------------------------------
    // Set its appearance
    //------------------------------------------------------------------------
    miscControlWindow->MaximizeBox = GUI_NO;
//        miscControlWindow->MinimizeBox = GUI_NO;
    miscControlWindow->HelpButton = GUI_NO;
//    miscControlWindow->TopMost = GUI_YES;
    //------------------------------------------------------------------------
    // Set its icon
    //------------------------------------------------------------------------
    miscControlWindow->Icon = QCOM_SoftwareIcon;
    //------------------------------------------------------------------------
    // Set the background image
    //------------------------------------------------------------------------
    miscControlWindow->BackgroundImage = violetStuccoBackground; // whiteSandBackground;
    //------------------------------------------------------------------------
    // Set the title, size, and border style
    //------------------------------------------------------------------------
    miscControlWindow->Text = _T("Miscellaneous Controls and Utilities");
    miscControlWindow->Size = Drawing::Size(
        GUI_MISC_WINDOW_WIDTH,
        GUI_MISC_WINDOW_HEIGHT);
    miscControlWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
    //------------------------------------------------------------------------
    // Create the general group box
    //------------------------------------------------------------------------
    GroupBox ^miscControlsGeneralGroupBox = gcnew GroupBox;
    miscControlsGeneralGroupBox->Text = _T("Controls That Affect All Units");
    miscControlsGeneralGroupBox->Location = Point(10, 10);
    miscControlsGeneralGroupBox->BackColor = Color::Transparent;
    miscControlsGeneralGroupBox->Size = Drawing::Size(
        miscControlWindow->Width - 30, 110);
    miscControlWindow->Controls->Add(miscControlsGeneralGroupBox);
    //------------------------------------------------------------------------
    // Number of Modules group box
    //------------------------------------------------------------------------
    GroupBox ^miscGetNumberOfModulesGroupBox = gcnew GroupBox;
    miscGetNumberOfModulesGroupBox->Text = _T("Number of Modules");
    miscGetNumberOfModulesGroupBox->Location = Point(10, 20);
    miscGetNumberOfModulesGroupBox->Size = Drawing::Size(120, 50);
    miscGetNumberOfModulesGroupBox->BackColor = Color::Transparent;
    miscControlsGeneralGroupBox->Controls->Add(miscGetNumberOfModulesGroupBox);
    //------------------------------------------------------------------------
    // Populate the Number of Modules group box
    //------------------------------------------------------------------------
    Button ^miscGetNumberOfModulesButton = gcnew Button;
    miscGetNumberOfModulesButton->Text = _T("Get");
    miscGetNumberOfModulesButton->Location = Point(6, 16);
    miscGetNumberOfModulesButton->Size = Drawing::Size(
        GUI_GET_SET_BUTTON_WIDTH,
        GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(miscGetNumberOfModulesButton);
    miscGetNumberOfModulesButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscGetNumberOfModulesButtonClicked);
    miscGetNumberOfModulesGroupBox->Controls->Add(miscGetNumberOfModulesButton);
    miscGetNumberOfModulesBox = gcnew TextBox;
    miscGetNumberOfModulesBox->Location = Point(
        miscGetNumberOfModulesButton->Right + 5,
        miscGetNumberOfModulesButton->Top + 2);
    miscGetNumberOfModulesBox->Size = Drawing::Size(
        34, GUI_REGULAR_TEXT_BOX_HEIGHT);
    miscGetNumberOfModulesBox->Multiline = GUI_NO;
    miscGetNumberOfModulesBox->AcceptsReturn = GUI_NO;
    miscGetNumberOfModulesBox->AcceptsTab = GUI_NO;
    miscGetNumberOfModulesBox->WordWrap = GUI_NO;
    miscGetNumberOfModulesBox->TextAlign = HorizontalAlignment::Center;
    miscGetNumberOfModulesBox->BackColor = Color::Lavender;
    miscGetNumberOfModulesGroupBox->Controls->Add(miscGetNumberOfModulesBox);
    //------------------------------------------------------------------------
    // Number of Modules tool tip
    //------------------------------------------------------------------------
    ToolTip ^miscGetNumberOfModulesToolTip = gcnew ToolTip;
    miscGetNumberOfModulesToolTip->ShowAlways = GUI_YES;
    miscGetNumberOfModulesToolTip->AutoPopDelay = 10000;    // let stand for ten seconds
    miscGetNumberOfModulesToolTip->ToolTipTitle =
        _T("Number of QCOM Modules");
    String ^miscGetNumberOfModulesToolTipText = String::Concat(
        "Returns the number of QCOM modules", Environment::NewLine,
        "detected in the system");
    miscGetNumberOfModulesToolTip->SetToolTip(miscGetNumberOfModulesBox, miscGetNumberOfModulesToolTipText);
    miscGetNumberOfModulesToolTip->SetToolTip(miscGetNumberOfModulesButton, miscGetNumberOfModulesToolTipText);
    miscGetNumberOfModulesToolTip->SetToolTip(miscGetNumberOfModulesGroupBox, miscGetNumberOfModulesToolTipText);
    delete miscGetNumberOfModulesToolTipText;
    //------------------------------------------------------------------------
    // QCOM DLL Version group box
    //------------------------------------------------------------------------
    GroupBox ^miscGetQCOMDLLVersionGroupBox = gcnew GroupBox;
    miscGetQCOMDLLVersionGroupBox->Text = _T("DLL Version");
    miscGetQCOMDLLVersionGroupBox->Location = Point(
        miscGetNumberOfModulesGroupBox->Right + 10,
        miscGetNumberOfModulesGroupBox->Top);
    miscGetQCOMDLLVersionGroupBox->Size = miscGetNumberOfModulesGroupBox->Size;
    miscGetQCOMDLLVersionGroupBox->BackColor = Color::Transparent;
    miscControlsGeneralGroupBox->Controls->Add(miscGetQCOMDLLVersionGroupBox);
    //------------------------------------------------------------------------
    // Populate the QCOM DLL Version group box
    //------------------------------------------------------------------------
    Button ^miscGetQCOMDLLVersionButton = gcnew Button;
    miscGetQCOMDLLVersionButton->Text = _T("Get");
    miscGetQCOMDLLVersionButton->Location = Point(6, 16);
    miscGetQCOMDLLVersionButton->Size = miscGetNumberOfModulesButton->Size;
    GUI_SetButtonInterfaceProperties(miscGetQCOMDLLVersionButton);
    miscGetQCOMDLLVersionButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscGetQCOMDLLVersionButtonClicked);
    miscGetQCOMDLLVersionGroupBox->Controls->Add(miscGetQCOMDLLVersionButton);
    miscGetQCOMDLLVersionBox = gcnew TextBox;
    miscGetQCOMDLLVersionBox->Location = Point(
        miscGetNumberOfModulesButton->Right + 5,
        miscGetNumberOfModulesButton->Top + 2);
    miscGetQCOMDLLVersionBox->Size = miscGetNumberOfModulesBox->Size;
    miscGetQCOMDLLVersionBox->Multiline = GUI_NO;
    miscGetQCOMDLLVersionBox->AcceptsReturn = GUI_NO;
    miscGetQCOMDLLVersionBox->AcceptsTab = GUI_NO;
    miscGetQCOMDLLVersionBox->WordWrap = GUI_NO;
    miscGetQCOMDLLVersionBox->TextAlign = HorizontalAlignment::Center;
    miscGetQCOMDLLVersionBox->BackColor = Color::Lavender;
    miscGetQCOMDLLVersionGroupBox->Controls->Add(miscGetQCOMDLLVersionBox);
    //------------------------------------------------------------------------
    // QCOM DLL Version tool tip
    //------------------------------------------------------------------------
    ToolTip ^miscGetQCOMDLLVersionToolTip = gcnew ToolTip;
    miscGetQCOMDLLVersionToolTip->ShowAlways = GUI_YES;
    miscGetQCOMDLLVersionToolTip->AutoPopDelay = 10000;     // let stand for ten seconds
    miscGetQCOMDLLVersionToolTip->ToolTipTitle =
        _T("QCOM DLL Version");
    String ^miscGetQCOMDLLVersionToolTipText = String::Concat(
        "Returns the version of", Environment::NewLine,
        "the QCOM DLL (qdUSB.dll)");
    miscGetQCOMDLLVersionToolTip->SetToolTip(miscGetQCOMDLLVersionButton, miscGetQCOMDLLVersionToolTipText);
    miscGetQCOMDLLVersionToolTip->SetToolTip(miscGetQCOMDLLVersionBox, miscGetQCOMDLLVersionToolTipText);
    miscGetQCOMDLLVersionToolTip->SetToolTip(miscGetQCOMDLLVersionGroupBox, miscGetQCOMDLLVersionToolTipText);
    delete miscGetQCOMDLLVersionToolTipText;
    //------------------------------------------------------------------------
    // Timeout Settings group box
    //------------------------------------------------------------------------
    GroupBox ^miscGetSetTimeoutsGroupBox = gcnew GroupBox;
    miscGetSetTimeoutsGroupBox->Text = _T("General Timeout Settings");
    miscGetSetTimeoutsGroupBox->Location = Point(
        miscGetQCOMDLLVersionGroupBox->Right + 10, 14);
    miscGetSetTimeoutsGroupBox->Size = Drawing::Size(233, 56);
    miscGetSetTimeoutsGroupBox->BackColor = Color::Transparent;
    miscControlsGeneralGroupBox->Controls->Add(miscGetSetTimeoutsGroupBox);
    //------------------------------------------------------------------------
    // Populate the Timeout Settings group box
    //------------------------------------------------------------------------
    Button ^getTimeoutButton = gcnew Button;
    getTimeoutButton->Text = _T("Get");
    getTimeoutButton->Location = Point(6, 24);
    getTimeoutButton->Size = Drawing::Size(
        GUI_GET_SET_BUTTON_WIDTH,
        GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(getTimeoutButton);
    getTimeoutButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscGetTimeoutsButtonClicked);
    miscGetSetTimeoutsGroupBox->Controls->Add(getTimeoutButton);
    Label ^readValueLabel = gcnew Label;
    readValueLabel->Text = _T("Read");
    readValueLabel->Location = Point(
        getTimeoutButton->Right + 14, 14);
    readValueLabel->Size = Drawing::Size(40, GUI_REGULAR_LABEL_HEIGHT);
    readValueLabel->BackColor = Color::Transparent;
    Label ^writeValueLabel = gcnew Label;
    writeValueLabel->Text = _T("Write");
    writeValueLabel->Location = Point(
        readValueLabel->Right + 38,
        readValueLabel->Top);
    writeValueLabel->Size = Drawing::Size(40, GUI_REGULAR_LABEL_HEIGHT);
    writeValueLabel->BackColor = Color::Transparent;
    miscReadTimeoutBox = gcnew TextBox;
    miscReadTimeoutBox->Location = Point(
        getTimeoutButton->Right + 5,
        readValueLabel->Bottom + 2);
    miscReadTimeoutBox->Size = Drawing::Size(50, GUI_REGULAR_TEXT_BOX_HEIGHT);
    miscReadTimeoutBox->BackColor = Color::White;
    miscReadTimeoutBox->Multiline = GUI_NO;
    miscReadTimeoutBox->AcceptsReturn = GUI_NO;
    miscReadTimeoutBox->AcceptsTab = GUI_NO;
    miscReadTimeoutBox->WordWrap = GUI_NO;
    miscReadTimeoutBox->TextAlign = HorizontalAlignment::Right;
    miscGetSetTimeoutsGroupBox->Controls->Add(miscReadTimeoutBox);
    Label ^readMSLabel = gcnew Label;
    readMSLabel->Text = _T("ms");
    readMSLabel->Location = Point(
        miscReadTimeoutBox->Right + 2,
        miscReadTimeoutBox->Top + 3);
    readMSLabel->Size = Drawing::Size(20, GUI_REGULAR_LABEL_HEIGHT);
    readMSLabel->BackColor = Color::Transparent;
    miscWriteTimeoutBox = gcnew TextBox;
    miscWriteTimeoutBox->Location = Point(
        readMSLabel->Right + 4,
        miscReadTimeoutBox->Top);
    miscWriteTimeoutBox->Size = miscReadTimeoutBox->Size;
    miscWriteTimeoutBox->BackColor = Color::White;
    miscWriteTimeoutBox->Multiline = GUI_NO;
    miscWriteTimeoutBox->AcceptsReturn = GUI_NO;
    miscWriteTimeoutBox->AcceptsTab = GUI_NO;
    miscWriteTimeoutBox->WordWrap = GUI_NO;
    miscWriteTimeoutBox->TextAlign = HorizontalAlignment::Right;
    miscGetSetTimeoutsGroupBox->Controls->Add(miscWriteTimeoutBox);
    Label ^writeMSLabel = gcnew Label;
    writeMSLabel->Text = _T("ms");
    writeMSLabel->Location = Point(
        miscWriteTimeoutBox->Right + 2,
        miscWriteTimeoutBox->Top + 3);
    writeMSLabel->Size = readMSLabel->Size;
    writeMSLabel->BackColor = Color::Transparent;
    Button ^setTimeoutButton = gcnew Button;
    setTimeoutButton->Text = _T("Set");
    setTimeoutButton->Location = Point(
        writeMSLabel->Right + 4,
        getTimeoutButton->Top);
    setTimeoutButton->Size = getTimeoutButton->Size;
    GUI_SetButtonInterfaceProperties(setTimeoutButton);
    setTimeoutButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscSetTimeoutsButtonClicked);
    miscGetSetTimeoutsGroupBox->Controls->Add(setTimeoutButton);
    array <Label ^> ^getSetTimeoutsLabels =
    {
        readValueLabel,
        writeValueLabel,
        readMSLabel,
        writeMSLabel
    };
    miscGetSetTimeoutsGroupBox->Controls->AddRange(getSetTimeoutsLabels);
    //------------------------------------------------------------------------
    // Timeout Settings tool tip
    //------------------------------------------------------------------------
    ToolTip ^miscGetSetTimeoutsToolTip = gcnew ToolTip;
    miscGetSetTimeoutsToolTip->ShowAlways = GUI_YES;
    miscGetSetTimeoutsToolTip->AutoPopDelay = 10000;    // let stand for ten seconds
    miscGetSetTimeoutsToolTip->ToolTipTitle =
        _T("General Timeout Settings");
    String ^miscGetSetTimeoutsToolTipText = String::Concat(
        "These timeouts affect only the QCOM module", Environment::NewLine,
        "and DLL read and write operations");
    miscGetSetTimeoutsToolTip->SetToolTip(getTimeoutButton, miscGetSetTimeoutsToolTipText);
    miscGetSetTimeoutsToolTip->SetToolTip(setTimeoutButton, miscGetSetTimeoutsToolTipText);
    miscGetSetTimeoutsToolTip->SetToolTip(miscReadTimeoutBox, miscGetSetTimeoutsToolTipText);
    miscGetSetTimeoutsToolTip->SetToolTip(miscWriteTimeoutBox, miscGetSetTimeoutsToolTipText);
    miscGetSetTimeoutsToolTip->SetToolTip(readValueLabel, miscGetSetTimeoutsToolTipText);
    miscGetSetTimeoutsToolTip->SetToolTip(writeValueLabel, miscGetSetTimeoutsToolTipText);
    miscGetSetTimeoutsToolTip->SetToolTip(readMSLabel, miscGetSetTimeoutsToolTipText);
    miscGetSetTimeoutsToolTip->SetToolTip(writeMSLabel, miscGetSetTimeoutsToolTipText);
    miscGetSetTimeoutsToolTip->SetToolTip(miscGetSetTimeoutsGroupBox, miscGetSetTimeoutsToolTipText);
    delete miscGetSetTimeoutsToolTipText;
    //------------------------------------------------------------------------
    // Don't Save Config File On Exit check
    //------------------------------------------------------------------------
    miscDontSaveConfigCheck = gcnew CheckBox;
    miscDontSaveConfigCheck->Text = _T("Don't save program config file upon exit");
    miscDontSaveConfigCheck->Location = Point(
        miscControlsGeneralGroupBox->Width - 230, 20);
    miscDontSaveConfigCheck->Size = Drawing::Size(
        222, GUI_REGULAR_CHECK_BOX_HEIGHT);
    GUI_SetObjectInterfaceProperties(miscDontSaveConfigCheck);
    miscDontSaveConfigCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ConfigFileSaveDontSaveAreaClicked);
    miscDontSaveConfigCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    miscControlsGeneralGroupBox->Controls->Add(miscDontSaveConfigCheck);
    //------------------------------------------------------------------------
    // Don't Save Config File On Exit tool tip
    //------------------------------------------------------------------------
    ToolTip ^miscDontSaveConfigToolTip = gcnew ToolTip;
    miscDontSaveConfigToolTip->ShowAlways = GUI_YES;
    miscDontSaveConfigToolTip->AutoPopDelay = 10000;    // let stand for ten seconds
    miscDontSaveConfigToolTip->ToolTipTitle =
        _T("Don't Save Config File on Exit");
    String ^miscDontSaveConfigToolTipText = String::Concat(
        "When checked, the software will not save the", Environment::NewLine,
        "config information when you exit the program");
    miscDontSaveConfigToolTip->SetToolTip(miscDontSaveConfigCheck, miscDontSaveConfigToolTipText);
    delete miscDontSaveConfigToolTipText;
    //------------------------------------------------------------------------
    // Delete Config File On Exit check
    //------------------------------------------------------------------------
    miscDeleteConfigCheck = gcnew CheckBox;
    miscDeleteConfigCheck->Text = _T("Delete program config file upon exit");
    GUI_PositionAndSizeBelow(miscDeleteConfigCheck, miscDontSaveConfigCheck, 4);
    GUI_SetObjectInterfaceProperties(miscDeleteConfigCheck);
    miscDeleteConfigCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscDeleteConfigChecked);
    miscDeleteConfigCheck->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    miscControlsGeneralGroupBox->Controls->Add(miscDeleteConfigCheck);
    //------------------------------------------------------------------------
    // Delete Config File On Exit tool tip
    //------------------------------------------------------------------------
    ToolTip ^miscDeleteConfigToolTip = gcnew ToolTip;
    miscDeleteConfigToolTip->ShowAlways = GUI_YES;
    miscDeleteConfigToolTip->AutoPopDelay = 10000;  // let stand for ten seconds
    miscDeleteConfigToolTip->ToolTipTitle =
        _T("Delete Config Files on Exit");
    String ^miscDeleteConfigToolTipText = String::Concat(
        "When checked, the software will delete the", Environment::NewLine,
        "config file when you exit the program");
    miscDeleteConfigToolTip->SetToolTip(miscDeleteConfigCheck, miscDeleteConfigToolTipText);
    delete miscDeleteConfigToolTipText;
    //------------------------------------------------------------------------
    // Enable Program Sounds check
    //------------------------------------------------------------------------
    miscEnableSoundsCheck = gcnew CheckBox;
    miscEnableSoundsCheck->Text = _T("Enable program sounds");
    GUI_PositionAndSizeBelow(miscEnableSoundsCheck, miscDeleteConfigCheck, 4);
    GUI_SetObjectInterfaceProperties(miscEnableSoundsCheck);
    miscEnableSoundsCheck->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscEnableSoundsChecked);
    miscControlsGeneralGroupBox->Controls->Add(miscEnableSoundsCheck);
    //------------------------------------------------------------------------
    // Enable Program Sounds tool tip
    //------------------------------------------------------------------------
    ToolTip ^miscEnableSoundsToolTip = gcnew ToolTip;
    miscEnableSoundsToolTip->ShowAlways = GUI_YES;
    miscEnableSoundsToolTip->AutoPopDelay = 10000;  // let stand for ten seconds
    miscEnableSoundsToolTip->ToolTipTitle =
        _T("Enable Program Sounds");
    String ^miscEnableSoundsToolTipText = String::Concat(
        "When checked, program", Environment::NewLine,
        "sounds are enabled");
    miscEnableSoundsToolTip->SetToolTip(miscEnableSoundsCheck, miscEnableSoundsToolTipText);
    delete miscEnableSoundsToolTipText;
    //------------------------------------------------------------------------
    // Set up the Persistent Flags control and display the associated button
    //------------------------------------------------------------------------
    QCOM_MiscPFSetUpControl();
    Button ^miscPersistentFlagsButton = gcnew Button;
    miscPersistentFlagsButton->Text = _T("Modify Persistent Flags");
    GUI_PositionBelow(miscPersistentFlagsButton, miscEnableSoundsCheck, 2);
    miscPersistentFlagsButton->Size = Drawing::Size(
        160, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(miscPersistentFlagsButton);
    miscPersistentFlagsButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscPFButtonClicked);
    miscControlsGeneralGroupBox->Controls->Add(miscPersistentFlagsButton);
    //------------------------------------------------------------------------
    // Persistent Flags button tool tip
    //------------------------------------------------------------------------
    ToolTip ^miscPersistentFlagsToolTip = gcnew ToolTip;
    miscPersistentFlagsToolTip->ShowAlways = GUI_YES;
    miscPersistentFlagsToolTip->AutoPopDelay = 10000;   // let stand for ten seconds
    miscPersistentFlagsToolTip->ToolTipTitle =
        _T("Persistent Flags");
    String ^miscPersistentFlagsToolTipText = String::Concat(
        "Displays a dialogue window for setting", Environment::NewLine,
        "or resetting persistent flags");
    miscPersistentFlagsToolTip->SetToolTip(miscPersistentFlagsButton, miscPersistentFlagsToolTipText);
    delete miscPersistentFlagsToolTipText;
    //------------------------------------------------------------------------
    // Display the misc information for all possible individual units
    //------------------------------------------------------------------------
    miscTabControl = gcnew TabControl;
    miscTabControl->Location = Point(
        miscControlsGeneralGroupBox->Left,
        miscControlsGeneralGroupBox->Bottom + 10);
    miscTabControl->Size = Drawing::Size(
        miscControlsGeneralGroupBox->Width,
        miscControlWindow->Height - miscControlsGeneralGroupBox->Height - 100);
    miscTabControl->Appearance = TabAppearance::Normal;
    miscTabControl->Alignment = TabAlignment::Top;
    miscControlWindow->Controls->Add(miscTabControl);
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        //--------------------------------------------------------------------
        // Enclose the unit info within tabs
        //--------------------------------------------------------------------
        QCOM_MiscConstructUnitControlTab(QCOM_UnitInfoArray[unitNumber]);
    }
    //------------------------------------------------------------------------
    // Add a Close button
    //------------------------------------------------------------------------
    Button ^miscSetUpControlsCloseButton = gcnew Button;
    miscSetUpControlsCloseButton->Text = _T("Close");
    miscSetUpControlsCloseButton->Location = Point(
        miscControlWindow->Right - 100,
        miscControlWindow->Bottom - 70);
    miscSetUpControlsCloseButton->Size = Drawing::Size(
        GUI_CLOSE_BUTTON_WIDTH,
        GUI_REGULAR_BUTTON_HEIGHT);
    miscSetUpControlsCloseButton->DialogResult = System::Windows::Forms::DialogResult::OK;
    GUI_SetButtonInterfaceProperties(miscSetUpControlsCloseButton);
    miscSetUpControlsCloseButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_MiscCloseWindow);
    miscControlWindow->Controls->Add(miscSetUpControlsCloseButton);
    //------------------------------------------------------------------------
    // Add an Unseen button
    //------------------------------------------------------------------------
    Button ^unseenButton = gcnew Button;
    unseenButton->Text = _T("Unseen");
    unseenButton->Location = Point(
        miscSetUpControlsCloseButton->Left - 100,
        miscSetUpControlsCloseButton->Top);
    unseenButton->DialogResult = System::Windows::Forms::DialogResult::OK;
    unseenButton->Visible = GUI_NO;
    miscControlWindow->Controls->Add(unseenButton);
    //------------------------------------------------------------------------
    // Handle the closing of the window by any other way
    //------------------------------------------------------------------------
    miscControlWindow->FormClosing +=
        gcnew FormClosingEventHandler(this, &QCOM_GUIClass::QCOM_MiscClosingWindow);
    //------------------------------------------------------------------------
    // Set the remaining window properties
    //------------------------------------------------------------------------
//        miscControlWindow->AcceptButton = miscSetUpControlsCloseButton;
    miscControlWindow->CancelButton = miscSetUpControlsCloseButton;
    //------------------------------------------------------------------------
    // Finally, display the new window...later
    //------------------------------------------------------------------------
    QCOM_MiscUpdateChecks();
    miscControlWindow->ResumeLayout();
    miscControlWindow->Hide();
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_MiscSetUpControls()
//----------------------------------------------------------------------------
// QCOM_MiscUpdateChecks
//
// Updates the check marks in the general Miscellaneous window
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscUpdateChecks(void)
{
    //------------------------------------------------------------------------
    // Program sounds
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_SOUNDS_ENABLED)
        miscEnableSoundsCheck->Checked = GUI_YES;
    else
        miscEnableSoundsCheck->Checked = GUI_NO;
    //------------------------------------------------------------------------
    // Don't save the config file upon exit
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DONT_SAVE)
        miscDontSaveConfigCheck->Checked = GUI_YES;
    else
        miscDontSaveConfigCheck->Checked = GUI_NO;
    //------------------------------------------------------------------------
    // Delete the config file upon exit
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DELETE_ON_EXIT)
        miscDeleteConfigCheck->Checked = GUI_YES;
    else
        miscDeleteConfigCheck->Checked = GUI_NO;
}                                       // end of QCOM_MiscUpdateChecks()
//----------------------------------------------------------------------------
// QCOM_MiscToggleTransducerType
//
// Toggles the transducer type recognized by the software for the specified
// unit between a frequency type and a digital type
//
// Called by:   QCOM_MiscToggleTransducerTypeButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscToggleTransducerType(
    UnitInfo        ^unit)
{
    bool            transducerIsAnalog = GUI_NO;
    String          ^functionName = _T("QCOM_MiscToggleTransducerType");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        DWORD unitNumber = unit->unitNumber;
        if (unit->transducerType == QD_TRANSDUCER_TYPE_FREQUENCY)
        {
            //----------------------------------------------------------------
            // Switch to digital type
            //----------------------------------------------------------------
            unit->transducerType =
                (QCOM_OriginalTransducerType[unitNumber] == QD_TRANSDUCER_TYPE_FREQUENCY) ?
                    2 : QCOM_OriginalTransducerType[unitNumber];
            miscToggleTransducerTypeButtonArray[unitNumber]->Text = GUI_SWITCH_TO_FREQUENCY_TRANSDUCER;
        }
        else
        {
            //----------------------------------------------------------------
            // Switch to frequency type
            //----------------------------------------------------------------
            transducerIsAnalog = GUI_YES;
            unit->transducerType = QD_TRANSDUCER_TYPE_FREQUENCY;
            miscToggleTransducerTypeButtonArray[unitNumber]->Text = GUI_SWITCH_TO_DIGITAL_TRANSDUCER;
        }
        if ((unit->transducerChipID[2] >= 4) && (unit->transducerChipID[3] >= 2))
        {
            //----------------------------------------------------------------
            // The ASIC is version 4.02 or later, so request checksums
            //----------------------------------------------------------------
            array <String ^> ^defaultI2CListWithChecksum =
            {
                (transducerIsAnalog ? _T("S99FFFFFFFFFFP [ Read Pres w/chk ]")          : _T("S9DFFFFFFFFFFP [ Read Pres w/chk ]")),
                (transducerIsAnalog ? _T("S9BFFFFFFFFFFP [ Read Temp w/chk ]")          : _T("S9FFFFFFFFFFFP [ Read Temp w/chk ]")),
                (transducerIsAnalog ? _T("S98R9BFFFFFFFFP [ Read XD status ]")          : _T("S9CR9FFFFFFFFFP [ Read XD status ]")),
                (transducerIsAnalog ? _T("S98R99FFFFFFFFFFP [ Get chip ID w/chk ]")     : _T("S9CR9DFFFFFFFFFFP [ Get chip ID w/chk ]")),
                (transducerIsAnalog ? _T("S99FFP [ Poll for ACK ]")                     : _T("S9DFFP [ Poll for ACK ]")),
                (transducerIsAnalog ? _T("SA3FFFFFFP [ Read QCOM curr addr ]")          : _T("SADFFFFFFP [ Read ASIC curr addr ]")),
                (transducerIsAnalog ? _T("SA20000RA3FFP [ Read QCOM mem ]")             : _T("SAC0000RADFFP [ Read XD mem ]")),
                (transducerIsAnalog ? _T("S981FP [ Unlock QCOM mem ]")                  : _T("S9C1FP [ Unlock XD mem ]")),
                (transducerIsAnalog ? _T("S983FP [ Lock QCOM mem ]")                    : _T("S9C3FP [ Lock XD mem ]")),
                (transducerIsAnalog ? _T("SA20000XXP [ Write XX to QCOM mem ]")         : _T("SAC0000XXP [ Write XX to XD mem ]")),
                (transducerIsAnalog ? _T("S983FC0P [ Change ref to 1 kHz ]")            : _T("S9C3FC0P [ Change ref to 1 kHz ]")),
                (transducerIsAnalog ? _T("S983FC8P [ Change ref to 7.2 MHz ]")          : _T("S9C3FC8P [ Change ref to 7.2 MHz ]"))
            };
            miscI2CCommandComboArray[unitNumber]->Items->AddRange(defaultI2CListWithChecksum);
            miscI2CCommandComboArray[unitNumber]->Text = defaultI2CListWithChecksum[0];
        }
        else
        {
            array <String ^> ^defaultI2CList =
            {
                (transducerIsAnalog ? _T("S99FFFFFFFFP [ Read Pres w/o chk ]")          : _T("S9DFFFFFFFFP [ Read Pres w/o chk ]")),
                (transducerIsAnalog ? _T("S9BFFFFFFFFP [ Read Temp w/o chk ]")          : _T("S9FFFFFFFFFP [ Read Temp w/o chk ]")),
                (transducerIsAnalog ? _T("S98R9BFFFFP [ Read XD status ]")              : _T("S9CR9FFFFFP [ Read XD status ]")),
                (transducerIsAnalog ? _T("S98R99FFFFFFFFP [ Get chip ID w/o chk ]")     : _T("S9CR9DFFFFFFFFP [ Get chip ID w/o chk ]")),
                (transducerIsAnalog ? _T("S99FFP [ Poll for ACK ]")                     : _T("S9DFFP [ Poll for ACK ]")),
                (transducerIsAnalog ? _T("SA3FFFFFFP [ Read QCOM curr addr ]")          : _T("SADFFFFFFP [ Read ASIC curr addr ]")),
                (transducerIsAnalog ? _T("SA20000RA3FFP [ Read QCOM mem ]")             : _T("SAC0000RADFFP [ Read XD mem ]")),
                (transducerIsAnalog ? _T("S981FP [ Unlock QCOM mem ]")                  : _T("S9C1FP [ Unlock XD mem ]")),
                (transducerIsAnalog ? _T("S983FP [ Lock QCOM mem ]")                    : _T("S9C3FP [ Lock XD mem ]")),
                (transducerIsAnalog ? _T("SA20000XXP [ Write XX to QCOM mem ]")         : _T("SAC0000XXP [ Write XX to XD mem ]")),
                (transducerIsAnalog ? _T("S983FC0P [ Change ref to 1 kHz ]")            : _T("S9C3FC0P [ Change ref to 1 kHz ]")),
                (transducerIsAnalog ? _T("S983FC8P [ Change ref to 7.2 MHz ]")          : _T("S9C3FC8P [ Change ref to 7.2 MHz ]"))
            };
            miscI2CCommandComboArray[unitNumber]->Items->AddRange(defaultI2CList);
            miscI2CCommandComboArray[unitNumber]->Text = defaultI2CList[0];
        }
        QCOM_ConstructUnitDescriptionString(unit);
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_MiscToggleTransducerType()
//----------------------------------------------------------------------------
// QCOM_MiscUpdatePersistentChecks
//
// Updates the check marks in the Persistent Flags window
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscUpdatePersistentChecks(void)
{
    //------------------------------------------------------------------------
    // General persistent checks
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentFlags & QCOM_GENERAL_SOUNDS_ENABLED)
        miscPFGeneralSoundsEnabledCheck->Checked = GUI_YES;
    else
        miscPFGeneralSoundsEnabledCheck->Checked = GUI_NO;
    if (QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_FILE_BOTH_FORMATS)
        miscPFGeneralLogBothFileFormatsCheck->Checked = GUI_YES;
    else
        miscPFGeneralLogBothFileFormatsCheck->Checked = GUI_NO;
    if (QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_DISPLAY_SUMMARIES)
        miscPFGeneralLogDisplayAllSummariesCheck->Checked = GUI_YES;
    else
        miscPFGeneralLogDisplayAllSummariesCheck->Checked = GUI_NO;
    if (QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_DISPLAY_WRAP)
        miscPFGeneralLogDisplayAllWrappedCheck->Checked = GUI_YES;
    else
        miscPFGeneralLogDisplayAllWrappedCheck->Checked = GUI_NO;
    if (QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS)
        miscPFGeneralLogPrependEntryNumbersCheck->Checked = GUI_YES;
    else
        miscPFGeneralLogPrependEntryNumbersCheck->Checked = GUI_NO;
    if (QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_DATA_SAVE_IMMEDIATELY)
        miscPFGeneralLogDataSaveImmediatelyCheck->Checked = GUI_YES;
    else
        miscPFGeneralLogDataSaveImmediatelyCheck->Checked = GUI_NO;
    if (QCOM_GeneralInfo->persistentTestFlags & QCOM_GENERAL_TEST_DISPLAY_XD_TESTS)
        miscPFGeneralTestDisplayXDTestsCheck->Checked = GUI_YES;
    else
        miscPFGeneralTestDisplayXDTestsCheck->Checked = GUI_NO;
    //------------------------------------------------------------------------
    // Unit persistent checks
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentUnitFlags & QCOM_UNIT_DISPLAY_COUNTS_IN_HEX)
        miscPFUnitHexCountsCheck->Checked = GUI_YES;
    else
        miscPFUnitHexCountsCheck->Checked = GUI_NO;
    if (QCOM_GeneralInfo->persistentUnitLogFlags & QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY)
        miscPFUnitLogDataSaveImmediatelyCheck->Checked = GUI_YES;
    else
        miscPFUnitLogDataSaveImmediatelyCheck->Checked = GUI_NO;
    if (QCOM_GeneralInfo->persistentUnitTestFlags & QCOM_UNIT_TEST_RESULTS_DISPLAYED)
        miscPFUnitTestResultsDisplayCheck->Checked = GUI_YES;
    else
        miscPFUnitTestResultsDisplayCheck->Checked = GUI_NO;
    if (QCOM_GeneralInfo->persistentUnitFlags & QCOM_UNIT_SEND_EMAIL_XD_READINGS)
        miscPFUnitEmailXDReadingsCheck->Checked = GUI_YES;
    else
        miscPFUnitEmailXDReadingsCheck->Checked = GUI_NO;
    if (QCOM_GeneralInfo->persistentUnitFlags & QCOM_UNIT_SEND_TEXT_XD_READINGS)
        miscPFUnitTextXDReadingsCheck->Checked = GUI_YES;
    else
        miscPFUnitTextXDReadingsCheck->Checked = GUI_NO;
    if (QCOM_GeneralInfo->persistentUnitFlags & QCOM_UNIT_SEND_XD_READINGS)
        miscPFUnitSendXDReadingsCheck->Checked = GUI_YES;
    else
        miscPFUnitSendXDReadingsCheck->Checked = GUI_NO;
}                                       // end of QCOM_MiscUpdatePersistentChecks()
//----------------------------------------------------------------------------
// QCOM_ProgramInformationDisplayTab
//
// Displays an unit program info tab for the Program Information window
//
// Called by:   QCOM_ProgramInformationDisplayWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ProgramInformationDisplayTab(
    UnitInfo        ^unit)
{
    bool            transducerIsPresent = GUI_NO;
    BYTE            memoryType = QD_MEMORY_TYPE_ABSENT;                         // 0
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_ProgramInformationDisplayTab");
    //------------------------------------------------------------------------
    if (unit)
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        if (QCOM_XDPresent(unit))
            transducerIsPresent = GUI_YES;
        QCOM_ConstructUnitDescriptionString(unit);
        //--------------------------------------------------------------------
        // Create the unit tab page
        //--------------------------------------------------------------------
        TabPage ^pInfoUnitTabPage = gcnew TabPage;
        if (QCOM_ModuleSNValid(unit))
            pInfoUnitTabPage->Text = unit->moduleSerialNumber;
        else
            pInfoUnitTabPage->Text = String::Concat("Unit ", unitNumber);
        pInfoUnitTabPage->TabIndex = unitNumber;
        pInfoUnitTabPage->BackgroundImage = whiteMarbleBackground; // whiteSandBackground;
        pInfoTabPageArray[unitNumber] = pInfoUnitTabPage;
        pInfoTabControl->Controls->Add(pInfoUnitTabPage);
        //--------------------------------------------------------------------
        // Create the unit group box
        //--------------------------------------------------------------------
        GroupBox ^pInfoUnitGroupBox = gcnew GroupBox;
        pInfoUnitGroupBox->Text = unit->unitDescriptionString;
        pInfoUnitGroupBox->Location = Point(10, 10);
        pInfoUnitGroupBox->Size = Drawing::Size(
            pInfoTabControl->Width - 30,
            pInfoTabControl->Height - 50);
        pInfoUnitGroupBox->BackColor = Color::Transparent;
        pInfoUnitTabPage->Controls->Add(pInfoUnitGroupBox);
        //--------------------------------------------------------------------
        // Physical unit number
        //--------------------------------------------------------------------
        Label ^pInfoPhysicalUnitNumberLabel = gcnew Label;
        pInfoPhysicalUnitNumberLabel->Text = String::Format(
            "Physical Unit Number: {0:D}",
            unit->physicalUnitNumber);
        pInfoPhysicalUnitNumberLabel->Location = Point(10, 20);
        pInfoPhysicalUnitNumberLabel->Size = Drawing::Size(
            160, GUI_INFO_LABEL_HEIGHT);
        pInfoPhysicalUnitNumberLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Logical unit number
        //--------------------------------------------------------------------
        Label ^pInfoLogicalUnitNumberLabel = gcnew Label;
        pInfoLogicalUnitNumberLabel->Text = String::Format(
            "Logical Unit Number: {0:D}",
            unit->unitNumber);
        pInfoLogicalUnitNumberLabel->Location = Point(
            pInfoPhysicalUnitNumberLabel->Right + 10,
            pInfoPhysicalUnitNumberLabel->Top);
        pInfoLogicalUnitNumberLabel->Size = pInfoPhysicalUnitNumberLabel->Size;
        pInfoLogicalUnitNumberLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Firmware ID
        //--------------------------------------------------------------------
        Label ^pInfoFirmwareIDLabel = gcnew Label;
        String ^FWID;
        if (unit->flags & QCOM_UNIT_FIRMWARE_ID_PRESENT)
        {
            FWID = String::Format(
                "{0:X2}  {1:X2}  {2:X2}  {3:X2}  (v{2:D}.{3:D})",
                unit->firmwareID[0], unit->firmwareID[1],
                unit->firmwareID[2], unit->firmwareID[3]);
        }
        else
        {
            FWID = QCOM_STRING_INVALID;
        }
        pInfoFirmwareIDLabel->Text = String::Concat("Firmware ID Bytes: ", FWID);
        delete FWID;
        pInfoFirmwareIDLabel->Location = Point(
            pInfoLogicalUnitNumberLabel->Right + 10,
            pInfoPhysicalUnitNumberLabel->Top);
        pInfoFirmwareIDLabel->Size = Drawing::Size(240, GUI_INFO_LABEL_HEIGHT);
        pInfoFirmwareIDLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Transducer part number
        //--------------------------------------------------------------------
        Label ^pInfoXDPartNumberLabel = gcnew Label;
        GUI_PositionBelow(pInfoXDPartNumberLabel, pInfoPhysicalUnitNumberLabel, 4);
        pInfoXDPartNumberLabel->Size = Drawing::Size(
            280, GUI_INFO_LABEL_HEIGHT);
        pInfoXDPartNumberLabel->Text = String::Concat(
            "Transducer Part Number: ",
            (transducerIsPresent ?
                unit->transducerPartNumber : QCOM_STRING_NA));
        //--------------------------------------------------------------------
        // Transducer type
        //--------------------------------------------------------------------
        Label ^pInfoXDTypeLabel = gcnew Label;
        pInfoXDTypeLabel->Location = Point(
            pInfoXDPartNumberLabel->Right + 10,
            pInfoXDPartNumberLabel->Top);
        pInfoXDTypeLabel->Size = Drawing::Size(
            130, GUI_INFO_LABEL_HEIGHT);
        pInfoXDTypeLabel->Text = String::Concat(
            "Transducer Type: ",
            (transducerIsPresent ?
                (unit->transducerType ? String::Concat(unit->transducerType) : _T("?")) : QCOM_STRING_NA));
        pInfoXDTypeLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Transducer memory type
        //--------------------------------------------------------------------
        Label ^pInfoMemoryTypeLabel = gcnew Label;
        pInfoMemoryTypeLabel->Location = Point(
            pInfoXDTypeLabel->Right + 10,
            pInfoXDTypeLabel->Top);
        pInfoMemoryTypeLabel->Size = Drawing::Size(
            180, GUI_INFO_LABEL_HEIGHT);
        QD_GetMemoryType(
            unit->unitHandle,
            QD_DEVICE_TRANSDUCER,
            (LPBYTE) &memoryType);
        pInfoMemoryTypeLabel->Text = _T("Memory Type: ");
        if (transducerIsPresent && memoryType)
        {
            pInfoMemoryTypeLabel->Text = String::Concat(
                pInfoMemoryTypeLabel->Text,
                String::Format("{0:D} ({1:D})",
                    memoryType,
                    unit->transducerMemorySize));
        }
        else
        {
            pInfoMemoryTypeLabel->Text = String::Concat(
                pInfoMemoryTypeLabel->Text, QCOM_STRING_NA);
        }
        pInfoMemoryTypeLabel->Visible =
            QCOM_XDIsFrequency(unit) ? GUI_NO : GUI_YES;
        pInfoMemoryTypeLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Coefficient file pathname
        //--------------------------------------------------------------------
        Label ^pInfoCoefficientFilePathLabel = gcnew Label;
        GUI_PositionBelow(pInfoCoefficientFilePathLabel, pInfoXDPartNumberLabel, 4);
        pInfoCoefficientFilePathLabel->Size = Drawing::Size(
            600, GUI_INFO_LABEL_HEIGHT);
        String ^coeffPathCaption = _T("Coefficient File: ");
        String ^coeffPath;
        if (QCOM_CFKnown(unit))
        {
            coeffPath = QCOM_LimitFilePathStringWidth(
                unit->coefficientFilePath,
                pInfoCoefficientFilePathLabel->Width - QCOM_StringWidth(coeffPathCaption));
        }
        else
        {
            coeffPath = QCOM_STRING_NONE;
        }
        pInfoCoefficientFilePathLabel->Text = String::Concat(
            coeffPathCaption, coeffPath);
        delete coeffPath;
        delete coeffPathCaption;
        //--------------------------------------------------------------------
        // Data log pathname
        //--------------------------------------------------------------------
        Label ^pInfoDataLogFilePathLabel = gcnew Label;
        GUI_PositionAndSizeBelow(pInfoDataLogFilePathLabel, pInfoCoefficientFilePathLabel, 4);
        String ^dataLogCaption = _T("Data Log File: ");
        String ^dataLog;
        if (QCOM_LogFileKnown(unit))
        {
            dataLog = QCOM_LimitFilePathStringWidth(
                unit->dataLogFilePath,
                pInfoDataLogFilePathLabel->Width - QCOM_StringWidth(dataLogCaption));
        }
        else
        {
            dataLog = QCOM_STRING_NONE;
        }
        pInfoDataLogFilePathLabel->Text = String::Concat(
            dataLogCaption, dataLog);
        delete dataLog;
        delete dataLogCaption;
        //--------------------------------------------------------------------
        // Data log snapshot pathname
        //--------------------------------------------------------------------
        Label ^pInfoDataLogSnapshotFilePathLabel = gcnew Label;
        pInfoDataLogSnapshotFilePathLabel->Location = Point(
            pInfoDataLogFilePathLabel->Left,
            pInfoDataLogFilePathLabel->Bottom + 4);
        pInfoDataLogSnapshotFilePathLabel->Size = pInfoCoefficientFilePathLabel->Size;
        String ^dataLogSnapCaption = _T("Data Log Snapshot File: ");
        String ^dataLogSnap;
        if (QCOM_LogSSFileKnown(unit))
        {
            dataLogSnap = QCOM_LimitFilePathStringWidth(
                unit->dataLogSnapshotFilePath,
                pInfoDataLogSnapshotFilePathLabel->Width - QCOM_StringWidth(dataLogSnapCaption));
        }
        else
        {
            dataLogSnap = QCOM_STRING_NONE;
        }
        pInfoDataLogSnapshotFilePathLabel->Text = String::Concat(
            dataLogSnapCaption, dataLogSnap);
        delete dataLogSnap;
        delete dataLogSnapCaption;
        pInfoDataLogSnapshotFilePathLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Test results file pathname
        //--------------------------------------------------------------------
        Label ^pInfoTestResultsFilePathLabel = gcnew Label;
        pInfoTestResultsFilePathLabel->Location = Point(
            pInfoDataLogSnapshotFilePathLabel->Left,
            pInfoDataLogSnapshotFilePathLabel->Bottom + 4);
        pInfoTestResultsFilePathLabel->Size = pInfoCoefficientFilePathLabel->Size;
        String ^testResultsPathCaption = _T("Test Results File: ");
        String ^testResultsPath;
        if (QCOM_TRFileKnown(unit))
        {
            testResultsPath = QCOM_LimitFilePathStringWidth(
                unit->testResultsFilePath,
                pInfoTestResultsFilePathLabel->Width - QCOM_StringWidth(testResultsPathCaption));
        }
        else
        {
            testResultsPath = QCOM_STRING_NONE;
        }
        pInfoTestResultsFilePathLabel->Text = String::Concat(
            testResultsPathCaption, testResultsPath);
        delete testResultsPath;
        delete testResultsPathCaption;
        pInfoTestResultsFilePathLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Test data file pathname
        //--------------------------------------------------------------------
        Label ^pInfoTestDataFilePathLabel = gcnew Label;
        pInfoTestDataFilePathLabel->Location = Point(
            pInfoTestResultsFilePathLabel->Left,
            pInfoTestResultsFilePathLabel->Bottom + 4);
        pInfoTestDataFilePathLabel->Size = pInfoCoefficientFilePathLabel->Size;
        String ^testDataPathCaption = _T("Test Data File: ");
        String ^testDataPath;
        if (unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED)
        {
            testDataPath = QCOM_LimitFilePathStringWidth(
                unit->testDataFilePath,
                pInfoTestDataFilePathLabel->Width - QCOM_StringWidth(testDataPathCaption));
        }
        else
        {
            testDataPath = QCOM_STRING_NONE;
        }
        pInfoTestDataFilePathLabel->Text = String::Concat(
            testDataPathCaption, testDataPath);
        delete testDataPath;
        delete testDataPathCaption;
        pInfoTestDataFilePathLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Test firmware file pathname
        //--------------------------------------------------------------------
        Label ^pInfoTestFirmwareFilePathLabel = gcnew Label;
        pInfoTestFirmwareFilePathLabel->Location = Point(
            pInfoTestDataFilePathLabel->Left,
            pInfoTestDataFilePathLabel->Bottom + 4);
        pInfoTestFirmwareFilePathLabel->Size = pInfoCoefficientFilePathLabel->Size;
        String ^testFirmwarePathCaption = _T("Test Firmware File: ");
        String ^testFirmwarePath;
        if (unit->testFlags & QCOM_UNIT_TEST_FW_FILE_SPECIFIED)
        {
            testFirmwarePath = QCOM_LimitFilePathStringWidth(
                unit->testFirmwareFilePath,
                pInfoTestFirmwareFilePathLabel->Width - QCOM_StringWidth(testFirmwarePathCaption));
        }
        else
        {
            testFirmwarePath = QCOM_STRING_NONE;
        }
        pInfoTestFirmwareFilePathLabel->Text = String::Concat(
            testFirmwarePathCaption, testFirmwarePath);
        delete testFirmwarePath;
        delete testFirmwarePathCaption;
        pInfoTestFirmwareFilePathLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // I�C Data Rate
        //--------------------------------------------------------------------
        Label ^pInfoDataRateLabel = gcnew Label;
        if (QCOM_UnitValid(unit))
        {
            pInfoDataRateLabel->Text = String::Format(
                "I�C Data Rate: {0:F1} kHz",
                unit->dataRate);
        }
        else
        {
            pInfoDataRateLabel->Text = _T("I�C Data Rate: Unavailable");
        }
        pInfoDataRateLabel->Location = Point(
            pInfoDataLogFilePathLabel->Right + 10,
            pInfoPhysicalUnitNumberLabel->Top);
        pInfoDataRateLabel->Size = Drawing::Size(220, GUI_INFO_LABEL_HEIGHT);
        pInfoDataRateLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Transducer Chip ID
        //--------------------------------------------------------------------
        Label ^pInfoXDChipIDLabel = gcnew Label;
        String ^XDID;
        if (transducerIsPresent)
        {
            if (unit->transducerChipID[0] == QD_QUARTZDYNE_ID)
            {
                XDID = String::Format(
                    "{0:X2}  {1:X2}  {2:X2}  {3:X2}",
                    unit->transducerChipID[0], unit->transducerChipID[1],
                    unit->transducerChipID[2], unit->transducerChipID[3]);
            }
            else
            {
                XDID = QCOM_STRING_INVALID;
            }
        }
        else
        {
            XDID = QCOM_STRING_NA;
        }
        pInfoXDChipIDLabel->Text = String::Concat("Transducer Chip ID Bytes: ", XDID);
        delete XDID;
        pInfoXDChipIDLabel->Location = Point(
            pInfoDataRateLabel->Left,
            pInfoDataRateLabel->Bottom + 4);
        pInfoXDChipIDLabel->Size = pInfoDataRateLabel->Size;
        pInfoXDChipIDLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Unit flags
        //--------------------------------------------------------------------
        Label ^pInfoUnitFlagsLabel = gcnew Label;
        pInfoUnitFlagsLabel->Text = String::Format(
            "Unit Flags: {0:X8}    Gr: {1:X8}",
            unit->flags, unit->graphingFlags);
        pInfoUnitFlagsLabel->Location = Point(
            pInfoXDChipIDLabel->Left,
            pInfoXDChipIDLabel->Bottom + 4);
        pInfoUnitFlagsLabel->Size = pInfoDataRateLabel->Size;
        pInfoUnitFlagsLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Data log flags
        //--------------------------------------------------------------------
        Label ^pInfoDataLogFlagsLabel = gcnew Label;
        pInfoDataLogFlagsLabel->Text = String::Format(
            "Data Log Flags: {0:X8}    P: {1:X8}",
            unit->dataLogFlags, unit->dataLogPoints);
        pInfoDataLogFlagsLabel->Location = Point(
            pInfoUnitFlagsLabel->Left,
            pInfoUnitFlagsLabel->Bottom + 4);
        pInfoDataLogFlagsLabel->Size = pInfoDataRateLabel->Size;
        pInfoDataLogFlagsLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Data log buffer sizes
        //--------------------------------------------------------------------
        Label ^pInfoDataLogRemainingLabel = gcnew Label;
        pInfoDataLogRemainingLabel->Text = String::Format(
            "Data Log: {0:D} of {1:D}",
            unit->dataLogRemaining,
            unit->dataLogSize);
        pInfoDataLogRemainingLabel->Location = Point(
            pInfoDataLogFlagsLabel->Left,
            pInfoDataLogFlagsLabel->Bottom + 4);
        pInfoDataLogRemainingLabel->Size = pInfoDataRateLabel->Size;
        pInfoDataLogRemainingLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Test log buffer sizes
        //--------------------------------------------------------------------
        Label ^pInfoTestFlagsLabel = gcnew Label;
        pInfoTestFlagsLabel->Text = String::Format(
            "Test Flags: {0:X8}",
            unit->testFlags);
        pInfoTestFlagsLabel->Location = Point(
            pInfoDataLogRemainingLabel->Left,
            pInfoDataLogRemainingLabel->Bottom + 4);
        pInfoTestFlagsLabel->Size = pInfoXDChipIDLabel->Size;
        pInfoTestFlagsLabel->BackColor = Color::Transparent;
        Label ^pInfoTestSummaryResultsLogRemainingLabel = gcnew Label;
        pInfoTestSummaryResultsLogRemainingLabel->Text = String::Format(
            "Test Summary Log: {0:D} of {1:D}",
            unit->testSummaryResultsLogRemaining,
            unit->testSummaryResultsLogSize);
        pInfoTestSummaryResultsLogRemainingLabel->Location = Point(
            pInfoXDChipIDLabel->Left,
            pInfoTestFlagsLabel->Bottom + 4);
        pInfoTestSummaryResultsLogRemainingLabel->Size = pInfoDataRateLabel->Size;
        pInfoTestSummaryResultsLogRemainingLabel->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // Test detailed results log buffer sizes
        //--------------------------------------------------------------------
        Label ^pInfoTestDetailedResultsLogRemainingLabel = gcnew Label;
        pInfoTestDetailedResultsLogRemainingLabel->Text = String::Format(
            "Test Detailed Log: {0:D} of {1:D}",
            unit->testDetailedResultsLogRemaining,
            unit->testDetailedResultsLogSize);
        pInfoTestDetailedResultsLogRemainingLabel->Location = Point(
            pInfoTestFlagsLabel->Left,
            pInfoTestSummaryResultsLogRemainingLabel->Bottom + 4);
        pInfoTestDetailedResultsLogRemainingLabel->Size = pInfoDataRateLabel->Size;
        pInfoTestDetailedResultsLogRemainingLabel->BackColor = Color::Transparent;
        array <Label ^> ^unitProgInfoLabels =
        {
            pInfoPhysicalUnitNumberLabel,
            pInfoLogicalUnitNumberLabel,
            pInfoFirmwareIDLabel,
            pInfoXDPartNumberLabel,
            pInfoXDTypeLabel,
            pInfoMemoryTypeLabel,
            pInfoCoefficientFilePathLabel,
            pInfoDataLogFilePathLabel,
            pInfoDataLogSnapshotFilePathLabel,
            pInfoTestResultsFilePathLabel,
            pInfoTestDataFilePathLabel,
            pInfoTestFirmwareFilePathLabel,
            pInfoDataRateLabel,
            pInfoXDChipIDLabel,
            pInfoUnitFlagsLabel,
            pInfoDataLogFlagsLabel,
            pInfoDataLogRemainingLabel,
            pInfoTestFlagsLabel,
            pInfoTestSummaryResultsLogRemainingLabel,
            pInfoTestDetailedResultsLogRemainingLabel
        };
        pInfoUnitGroupBox->Controls->AddRange(unitProgInfoLabels);
    }                                   // end of if (unit)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ProgramInformationDisplayTab()
//----------------------------------------------------------------------------
// QCOM_ProgramInformationDisplayWindow
//
// Displays program information for expert users in a new window
//
// Called by:   QCOM_ExpertProgramInfoButtonClicked
//                  (QCOM_ConstructGeneralExpertGroupBox)
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ProgramInformationDisplayWindow(void)
{
    int             lapsedDays;
    int             lapsedHours;
    int             lapsedMinutes;
    int             lapsedSeconds;
    int             lapsedMilliseconds;
    BYTE            buildVersion;
    BYTE            majorVersion;
    BYTE            minorVersion;
    DWORD           lowerVersion;
    DWORD           messageFlags = 0;
    DWORD           numberOfUnits = QCOM_GeneralInfo->numberOfUnits;
    DWORD           stateFlags = 0;
    DWORD           unitBitMap;
    DWORD           upperVersion;
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("QCOM_ProgramInformationDisplayWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Create a new window form each time this is called, due to the
    // dynamic nature of the program values it displays
    //------------------------------------------------------------------------
    programInfoWindow = gcnew Form;
    //------------------------------------------------------------------------
    // Set its appearance
    //------------------------------------------------------------------------
    programInfoWindow->SuspendLayout();
    programInfoWindow->Size = Drawing::Size(
        GUI_PROG_INFO_WINDOW_WIDTH,
        GUI_PROG_INFO_WINDOW_HEIGHT);
    programInfoWindow->MaximizeBox = GUI_NO;
    programInfoWindow->HelpButton = GUI_NO;
    //------------------------------------------------------------------------
    // Set its icon
    //------------------------------------------------------------------------
    programInfoWindow->Icon = QCOM_SoftwareIcon;
    //------------------------------------------------------------------------
    // Set the background image
    //------------------------------------------------------------------------
    programInfoWindow->BackgroundImage = whiteSandBackground;
    //------------------------------------------------------------------------
    // Set the title and border style
    //------------------------------------------------------------------------
    programInfoWindow->Text = _T("QCOM Program Information");
    programInfoWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
    //------------------------------------------------------------------------
    // Create the general group box
    //------------------------------------------------------------------------
    GroupBox ^pInfoGeneralGroupBox = gcnew GroupBox;
    pInfoGeneralGroupBox->Text = _T("General Program Information");
    pInfoGeneralGroupBox->Location = Point(10, 10);
    pInfoGeneralGroupBox->Size = Drawing::Size(
        programInfoWindow->Width - 30,
        GUI_PROG_INFO_GENERAL_GROUP_BOX_HEIGHT);
    pInfoGeneralGroupBox->BackColor = Color::Transparent;
    programInfoWindow->Controls->Add(pInfoGeneralGroupBox);
    //------------------------------------------------------------------------
    // Program name
    //------------------------------------------------------------------------
    Label ^pInfoProgramNameLabel = gcnew Label;
    pInfoProgramNameLabel->Text = String::Concat(_T("Name: "), GUI_HOME_WINDOW_TITLE);
    pInfoProgramNameLabel->Location = Point(10, 20);
    pInfoProgramNameLabel->Size = Drawing::Size(300, GUI_INFO_LABEL_HEIGHT);
    pInfoProgramNameLabel->BackColor = Color::Transparent;
    //------------------------------------------------------------------------
    // Program version
    //------------------------------------------------------------------------
    Label ^pInfoProgramVersionAndBuild = gcnew Label;
    pInfoProgramVersionAndBuild->Text = String::Format(
        "Version: {0}    Build {1:D} = {1:X8}",
        QCOM_PROGRAM_VERSION_STRING, QCOM_BuildNumber);
    GUI_PositionAndSizeBelow(pInfoProgramVersionAndBuild, pInfoProgramNameLabel, 2);
    //------------------------------------------------------------------------
    // Current date and time
    //------------------------------------------------------------------------
    Label ^pInfoThisMoment = gcnew Label;
    QCOM_TimeElapsed(
        GetTickCount() - QCOM_StartTime,
        &lapsedDays,
        &lapsedHours,
        &lapsedMinutes,
        &lapsedSeconds,
        &lapsedMilliseconds);
    pInfoThisMoment->Text = String::Format(
        "Now: {0:D2} {1} {2:D4} {3:D2}:{4:D2}:{5:D2}   "
        "[ up {6:D} d {7:D} h {8:D} m {9:D} s ]",
        dateTime.Day,
        QCOM_MonthStringArray[dateTime.Month],
        dateTime.Year,
        dateTime.Hour,
        dateTime.Minute,
        dateTime.Second,
        lapsedDays,
        lapsedHours,
        lapsedMinutes,
        lapsedSeconds);
    GUI_PositionAndSizeBelow(pInfoThisMoment, pInfoProgramVersionAndBuild, 2);
    //------------------------------------------------------------------------
    // Program author
    //------------------------------------------------------------------------
    Label ^pInfoProgramAuthor = gcnew Label;
    pInfoProgramAuthor->Text = String::Concat(
        "Author: ", QCOM_PROGRAM_AUTHOR);
    GUI_PositionAndSizeBelow(pInfoProgramAuthor, pInfoThisMoment, 2);
    //------------------------------------------------------------------------
    // The program startup path
    //------------------------------------------------------------------------
    Label ^pInfoStartupPathLabel = gcnew Label;
    GUI_PositionBelow(pInfoStartupPathLabel, pInfoProgramAuthor, 2);
    pInfoStartupPathLabel->Size = Drawing::Size(
        600, GUI_INFO_LABEL_HEIGHT);
    String ^startupPathCaption = _T("Startup Path: ");
    String ^startupPath = QCOM_LimitFilePathStringWidth(
        Application::ExecutablePath,
        pInfoStartupPathLabel->Width - QCOM_StringWidth(startupPathCaption));
    pInfoStartupPathLabel->Text = String::Concat(
        startupPathCaption, startupPath);
    delete startupPath;
    delete startupPathCaption;
    //------------------------------------------------------------------------
    // Program command-line parameters
    //------------------------------------------------------------------------
    Label ^pInfoCommandLineParametersLabel = gcnew Label;
    GUI_PositionAndSizeBelow(pInfoCommandLineParametersLabel, pInfoStartupPathLabel, 2);
    String ^clpPathCaption = _T("Command-line Parameters: ");
    String ^clpPath;
    if (StringSet(QCOM_GeneralInfo->commandLine))
    {
        clpPath = QCOM_LimitFilePathStringWidth(
            QCOM_GeneralInfo->commandLine,
            pInfoCommandLineParametersLabel->Width - QCOM_StringWidth(clpPathCaption));
    }
    else
    {
        clpPath = QCOM_STRING_NONE;
    }
    pInfoCommandLineParametersLabel->Text = String::Concat(
        clpPathCaption, clpPath);
    delete clpPath;
    delete clpPathCaption;
    //------------------------------------------------------------------------
    // The general use path
    //------------------------------------------------------------------------
    Label ^pInfoGeneralUsePathLabel = gcnew Label;
    GUI_PositionAndSizeBelow(pInfoGeneralUsePathLabel, pInfoCommandLineParametersLabel, 2);
    String ^usePathCaption = _T("General Use Path: ");
    String ^usePath;
    if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_USE_PATH_SPECIFIED) &&
        StringSet(QCOM_GeneralInfo->generalUsePath))
    {
        usePath = QCOM_LimitFilePathStringWidth(
            QCOM_GeneralInfo->generalUsePath,
            pInfoGeneralUsePathLabel->Width - QCOM_StringWidth(usePathCaption));
    }
    else
    {
        usePath = QCOM_STRING_NONE;
    }
    pInfoGeneralUsePathLabel->Text = String::Concat(usePathCaption, usePath);
    delete usePath;
    delete usePathCaption;
    //------------------------------------------------------------------------
    // The config file path
    //------------------------------------------------------------------------
    Label ^pInfoConfigFilePathLabel = gcnew Label;
    GUI_PositionAndSizeBelow(pInfoConfigFilePathLabel, pInfoGeneralUsePathLabel, 2);
    String ^cfgPathPrefix = _T("Config File Path: ");
    String ^cfgPath;
    if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_FILE_SPECIFIED) &&
        StringSet(QCOM_GeneralInfo->configFilePath))
    {
        cfgPath = QCOM_LimitFilePathStringWidth(
            QCOM_GeneralInfo->configFilePath,
            pInfoConfigFilePathLabel->Width - QCOM_StringWidth(cfgPathPrefix));
    }
    else
    {
        cfgPath = QCOM_STRING_NONE;
    }
    pInfoConfigFilePathLabel->Text = String::Concat(cfgPathPrefix, cfgPath);
    delete cfgPath;
    delete cfgPathPrefix;
    //------------------------------------------------------------------------
    // The error log file path
    //------------------------------------------------------------------------
    Label ^pInfoErrorLogFilePathLabel = gcnew Label;
    GUI_PositionAndSizeBelow(pInfoErrorLogFilePathLabel, pInfoConfigFilePathLabel, 2);
    String ^errPathCaption = _T("Error Log File Path: ");
    String ^errPath;
    if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_ERROR_LOG_SPECIFIED) &&
        StringSet(QCOM_GeneralInfo->errorLogPath))
    {
        errPath = QCOM_LimitFilePathStringWidth(
            QCOM_GeneralInfo->errorLogPath,
            pInfoErrorLogFilePathLabel->Width - QCOM_StringWidth(errPathCaption));
    }
    else
    {
        errPath = QCOM_STRING_NONE;
    }
    pInfoErrorLogFilePathLabel->Text = String::Concat(errPathCaption, errPath);
    delete errPath;
    delete errPathCaption;
    //------------------------------------------------------------------------
    // The event log file path
    //------------------------------------------------------------------------
    Label ^pInfoEventLogFilePathLabel = gcnew Label;
    GUI_PositionAndSizeBelow(pInfoEventLogFilePathLabel, pInfoErrorLogFilePathLabel, 2);
    String ^evtPathCaption = _T("Event Log File Path: ");
    String ^evtPath;
    if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_EVENT_LOG_SPECIFIED) &&
        StringSet(QCOM_GeneralInfo->eventLogPath))
    {
        evtPath = QCOM_LimitFilePathStringWidth(
            QCOM_GeneralInfo->eventLogPath,
            pInfoEventLogFilePathLabel->Width - QCOM_StringWidth(evtPathCaption));
    }
    else
    {
        evtPath = QCOM_STRING_NONE;
    }
    pInfoEventLogFilePathLabel->Text = String::Concat(evtPathCaption, evtPath);
    delete evtPath;
    delete evtPathCaption;
    //------------------------------------------------------------------------
    // From email address
    //------------------------------------------------------------------------
    Label ^pInfoEmailFromAddressLabel = gcnew Label;
    pInfoEmailFromAddressLabel->Text = String::Concat(
        _T("Email From Address: "),
        StringSet(QCOM_GeneralInfo->emailAddress) ?
            QCOM_GeneralInfo->emailAddress : QCOM_STRING_NONE);
    GUI_PositionBelow(pInfoEmailFromAddressLabel, pInfoEventLogFilePathLabel, 2);
    pInfoEmailFromAddressLabel->Size = pInfoProgramNameLabel->Size;
    //------------------------------------------------------------------------
    // Text message To number
    //------------------------------------------------------------------------
    Label ^pInfoTextMessageToNumberLabel = gcnew Label;
    pInfoTextMessageToNumberLabel->Text = String::Concat(
        _T("Text Number: "),
        StringSet(QCOM_GeneralInfo->textMessageToNumber) ?
            QCOM_GeneralInfo->textMessageToNumber : QCOM_STRING_NONE);
    GUI_PositionBelow(pInfoTextMessageToNumberLabel, pInfoEmailFromAddressLabel, 2);
    pInfoTextMessageToNumberLabel->Size = Drawing::Size(
        230, GUI_INFO_LABEL_HEIGHT);
    //------------------------------------------------------------------------
    // Email message To address
    //------------------------------------------------------------------------
    Label ^pInfoEmailMessageToAddressLabel = gcnew Label;
    pInfoEmailMessageToAddressLabel->Text = String::Concat(
        _T("Email Address: "),
        StringSet(QCOM_GeneralInfo->emailMessageToAddress) ?
            QCOM_GeneralInfo->emailMessageToAddress : QCOM_STRING_NONE);
    pInfoEmailMessageToAddressLabel->Location = Point(
        pInfoTextMessageToNumberLabel->Right + 10,
        pInfoTextMessageToNumberLabel->Top);
    pInfoEmailMessageToAddressLabel->Size = Drawing::Size(
        360, GUI_INFO_LABEL_HEIGHT);
    pInfoEmailMessageToAddressLabel->BackColor = Color::Transparent;
    //------------------------------------------------------------------------
    // Text message CC number
    //------------------------------------------------------------------------
    Label ^pInfoTextMessageCCNumberLabel = gcnew Label;
    pInfoTextMessageCCNumberLabel->Text = String::Concat(
        _T("Text CC: "),
        StringSet(QCOM_GeneralInfo->textMessageCCNumber) ?
            QCOM_GeneralInfo->textMessageCCNumber : QCOM_STRING_NONE);
    GUI_PositionAndSizeBelow(pInfoTextMessageCCNumberLabel, pInfoTextMessageToNumberLabel, 2);
    //------------------------------------------------------------------------
    // Email message CC address
    //------------------------------------------------------------------------
    Label ^pInfoEmailMessageCCAddressLabel = gcnew Label;
    pInfoEmailMessageCCAddressLabel->Text = String::Concat(
        _T("Email CC: "),
        StringSet(QCOM_GeneralInfo->emailMessageCCAddress) ?
            QCOM_GeneralInfo->emailMessageCCAddress : QCOM_STRING_NONE);
    pInfoEmailMessageCCAddressLabel->Location = Point(
        pInfoEmailMessageToAddressLabel->Left,
        pInfoTextMessageCCNumberLabel->Top);
    pInfoEmailMessageCCAddressLabel->Size = pInfoEmailMessageToAddressLabel->Size;
    pInfoEmailMessageCCAddressLabel->BackColor = Color::Transparent;
    //------------------------------------------------------------------------
    // The general flags
    //------------------------------------------------------------------------
    Label ^pInfoGeneralFlags = gcnew Label;
    pInfoGeneralFlags->Text = String::Format(
        "Flags: {0:X8}", QCOM_GeneralInfo->flags);
    GUI_PositionBelow(pInfoGeneralFlags, pInfoTextMessageCCNumberLabel, 2);
    pInfoGeneralFlags->Size = Drawing::Size(130, GUI_INFO_LABEL_HEIGHT);
    //------------------------------------------------------------------------
    // The general log flags
    //------------------------------------------------------------------------
    Label ^pInfoGeneralLogFlags = gcnew Label;
    pInfoGeneralLogFlags->Text = String::Format(
        "Log Flags: {0:X8}", QCOM_GeneralInfo->logFlags);
    GUI_PositionAndSizeBelow(pInfoGeneralLogFlags, pInfoGeneralFlags, 2);
    //------------------------------------------------------------------------
    // The general test flags
    //------------------------------------------------------------------------
    Label ^pInfoGeneralTestFlags = gcnew Label;
    pInfoGeneralTestFlags->Text = String::Format(
        "Test Flags: {0:X8}", QCOM_GeneralInfo->testFlags);
    GUI_PositionAndSizeBelow(pInfoGeneralTestFlags, pInfoGeneralLogFlags, 2);
    //------------------------------------------------------------------------
    // The general current persistent flags
    //------------------------------------------------------------------------
    Label ^pInfoGeneralPersistentFlags = gcnew Label;
    pInfoGeneralPersistentFlags->Text = String::Format(
        "Persist: {0:X8}", QCOM_GeneralInfo->persistentFlags);
    pInfoGeneralPersistentFlags->Location = Point(
        pInfoGeneralFlags->Right,
        pInfoGeneralFlags->Top);
    pInfoGeneralPersistentFlags->Size = Drawing::Size(
        120, GUI_INFO_LABEL_HEIGHT);
    pInfoGeneralPersistentFlags->BackColor = Color::Transparent;
    //------------------------------------------------------------------------
    // The general current persistent log flags
    //------------------------------------------------------------------------
    Label ^pInfoGeneralPersistentLogFlags = gcnew Label;
    pInfoGeneralPersistentLogFlags->Text = String::Format(
        "Persist: {0:X8}", QCOM_GeneralInfo->persistentLogFlags);
    GUI_PositionAndSizeBelow(pInfoGeneralPersistentLogFlags, pInfoGeneralPersistentFlags, 2);
    //------------------------------------------------------------------------
    // The general current persistent test flags
    //------------------------------------------------------------------------
    Label ^pInfoGeneralPersistentTestFlags = gcnew Label;
    pInfoGeneralPersistentTestFlags->Text = String::Format(
        "Persist: {0:X8}", QCOM_GeneralInfo->persistentTestFlags);
    GUI_PositionAndSizeBelow(pInfoGeneralPersistentTestFlags, pInfoGeneralPersistentLogFlags, 2);
    //------------------------------------------------------------------------
    // The unit current persistent flags
    //------------------------------------------------------------------------
    Label ^pInfoUnitPersistentFlags = gcnew Label;
    pInfoUnitPersistentFlags->Text = String::Format(
        "Unit Persist: {0:X8}", QCOM_GeneralInfo->persistentUnitFlags);
    pInfoUnitPersistentFlags->Location = Point(
        pInfoGeneralPersistentFlags->Right,
        pInfoGeneralFlags->Top);
    pInfoUnitPersistentFlags->Size = Drawing::Size(
        140, GUI_INFO_LABEL_HEIGHT);
    pInfoUnitPersistentFlags->BackColor = Color::Transparent;
    //------------------------------------------------------------------------
    // The unit current persistent log flags
    //------------------------------------------------------------------------
    Label ^pInfoUnitPersistentLogFlags = gcnew Label;
    pInfoUnitPersistentLogFlags->Text = String::Format(
        "Unit Persist: {0:X8}", QCOM_GeneralInfo->persistentUnitLogFlags);
    GUI_PositionAndSizeBelow(pInfoUnitPersistentLogFlags, pInfoUnitPersistentFlags, 2);
    //------------------------------------------------------------------------
    // The unit current persistent test flags
    //------------------------------------------------------------------------
    Label ^pInfoUnitPersistentTestFlags = gcnew Label;
    pInfoUnitPersistentTestFlags->Text = String::Format(
        "Unit Persist: {0:X8}", QCOM_GeneralInfo->persistentUnitTestFlags);
    GUI_PositionAndSizeBelow(pInfoUnitPersistentTestFlags, pInfoUnitPersistentLogFlags, 2);
    //------------------------------------------------------------------------
    // The general default persistent flags
    //------------------------------------------------------------------------
    Label ^pInfoGeneralDefaultPersistentFlags = gcnew Label;
    pInfoGeneralDefaultPersistentFlags->Text = String::Format(
        "Gen Def: {0:X8}", QCOM_GENERAL_DEFAULT_PERSISTENT_FLAGS);
    pInfoGeneralDefaultPersistentFlags->Location = Point(
        pInfoUnitPersistentFlags->Right,
        pInfoGeneralFlags->Top);
    pInfoGeneralDefaultPersistentFlags->Size = Drawing::Size(
        130, GUI_INFO_LABEL_HEIGHT);
    pInfoGeneralDefaultPersistentFlags->BackColor = Color::Transparent;
    //------------------------------------------------------------------------
    // The general default persistent log flags
    //------------------------------------------------------------------------
    Label ^pInfoGeneralDefaultPersistentLogFlags = gcnew Label;
    pInfoGeneralDefaultPersistentLogFlags->Text = String::Format(
        "Gen Def: {0:X8}", QCOM_GENERAL_LOG_DEFAULT_PERSISTENT_FLAGS);
    GUI_PositionAndSizeBelow(pInfoGeneralDefaultPersistentLogFlags, pInfoGeneralDefaultPersistentFlags, 2);
    //------------------------------------------------------------------------
    // The general default persistent test flags
    //------------------------------------------------------------------------
    Label ^pInfoGeneralDefaultPersistentTestFlags = gcnew Label;
    pInfoGeneralDefaultPersistentTestFlags->Text = String::Format(
        "Gen Def: {0:X8}", QCOM_GENERAL_TEST_DEFAULT_PERSISTENT_FLAGS);
    GUI_PositionAndSizeBelow(pInfoGeneralDefaultPersistentTestFlags, pInfoGeneralDefaultPersistentLogFlags, 2);
    //------------------------------------------------------------------------
    // The unit default persistent flags
    //------------------------------------------------------------------------
    Label ^pInfoUnitDefaultPersistentFlags = gcnew Label;
    pInfoUnitDefaultPersistentFlags->Text = String::Format(
        "Unit Def: {0:X8}", QCOM_UNIT_DEFAULT_PERSISTENT_FLAGS);
    pInfoUnitDefaultPersistentFlags->Location = Point(
        pInfoGeneralDefaultPersistentFlags->Right,
        pInfoGeneralFlags->Top);
    pInfoUnitDefaultPersistentFlags->Size = Drawing::Size(130, GUI_INFO_LABEL_HEIGHT);
    pInfoUnitDefaultPersistentFlags->BackColor = Color::Transparent;
    //------------------------------------------------------------------------
    // The unit default persistent log flags
    //------------------------------------------------------------------------
    Label ^pInfoUnitDefaultPersistentLogFlags = gcnew Label;
    pInfoUnitDefaultPersistentLogFlags->Text = String::Format(
        "Unit Def: {0:X8}", QCOM_UNIT_LOG_DEFAULT_PERSISTENT_FLAGS);
    GUI_PositionAndSizeBelow(pInfoUnitDefaultPersistentLogFlags, pInfoUnitDefaultPersistentFlags, 2);
    //------------------------------------------------------------------------
    // The unit default persistent test flags
    //------------------------------------------------------------------------
    Label ^pInfoUnitDefaultPersistentTestFlags = gcnew Label;
    pInfoUnitDefaultPersistentTestFlags->Text = String::Format(
        "Unit Def: {0:X8}", QCOM_UNIT_TEST_DEFAULT_PERSISTENT_FLAGS);
    GUI_PositionAndSizeBelow(pInfoUnitDefaultPersistentTestFlags, pInfoUnitDefaultPersistentLogFlags, 2);
    //------------------------------------------------------------------------
    // The program timer state
    //------------------------------------------------------------------------
    Label ^pInfoProgramTimerStateLabel = gcnew Label;
    pInfoProgramTimerStateLabel->Text = String::Format(
        "Program Timer set at {0:F0} ms and is {1}",
        programTimer->Interval,
        ((QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_TIMER_RUNNING) ? "running" : "stopped"));
    pInfoProgramTimerStateLabel->Location = Point(
        pInfoProgramNameLabel->Right + 10,
        pInfoProgramNameLabel->Top);
    pInfoProgramTimerStateLabel->Size = Drawing::Size(
        290, GUI_INFO_LABEL_HEIGHT);
    pInfoProgramTimerStateLabel->BackColor = Color::Transparent;
    //------------------------------------------------------------------------
    // The sampling timer state
    //------------------------------------------------------------------------
    Label ^pInfoSamplingTimerStateLabel = gcnew Label;
    pInfoSamplingTimerStateLabel->Text = String::Format(
        "Sampling Timer set at {0:D} ms and is {1}",
        QCOM_CurrentSamplingInterval,
        ((QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING) ? "running" : "stopped"));
    GUI_PositionAndSizeBelow(pInfoSamplingTimerStateLabel, pInfoProgramTimerStateLabel, 2);
    //------------------------------------------------------------------------
    // The sampling limit
    //------------------------------------------------------------------------
    Label ^pInfoSamplingTimerLimitLabel = gcnew Label;
    pInfoSamplingTimerLimitLabel->Text = String::Format(
        "Sampling Limit set to {0:D} min and is {1}",
        QCOM_MaximumSamplingRunTimeMinutes,
        ((QCOM_GeneralInfo->flags & QCOM_GENERAL_SAMPLING_TIME_LIMITED) ?
            _T("running") : _T("stopped")));
    GUI_PositionAndSizeBelow(pInfoSamplingTimerLimitLabel, pInfoSamplingTimerStateLabel, 2);
    //------------------------------------------------------------------------
    // The last string searched
    //------------------------------------------------------------------------
    Label ^pInfoLastStringSearchedLabel = gcnew Label;
    GUI_PositionAndSizeBelow(pInfoLastStringSearchedLabel, pInfoSamplingTimerLimitLabel, 2);
    String ^searchStringCaption = _T("Most recent search string: ");
    String ^searchString;
    if (StringSet(QCOM_GeneralInfo->searchString))
    {
        searchString = QCOM_LimitFilePathStringWidth(
            QCOM_GeneralInfo->searchString,
            pInfoLastStringSearchedLabel->Width - QCOM_StringWidth(searchStringCaption));
    }
    else
    {
        searchString = QCOM_STRING_NONE;
    }
    pInfoLastStringSearchedLabel->Text = String::Concat(
        searchStringCaption, searchString);
    delete searchString;
    delete searchStringCaption;
    //------------------------------------------------------------------------
    // The Windows version
    //------------------------------------------------------------------------
    Label ^pInfoWindowsVersionLabel = gcnew Label;
    pInfoWindowsVersionLabel->Text = String::Concat(
        _T("OS: "),
        QCOM_GeneralInfo->windowsVersion);
    pInfoWindowsVersionLabel->Location = Point(
        pInfoGeneralUsePathLabel->Right + 10,
        pInfoProgramNameLabel->Top);
    pInfoWindowsVersionLabel->Size = Drawing::Size(220, GUI_INFO_LABEL_HEIGHT);
    pInfoWindowsVersionLabel->BackColor = Color::Transparent;
    //------------------------------------------------------------------------
    // Memory information
    //------------------------------------------------------------------------
    Label ^pInfoClientMemoryLabel = gcnew Label;
    MEMORYSTATUSEX memory;
    memory.dwLength = sizeof(MEMORYSTATUSEX);
    GlobalMemoryStatusEx(&memory);
    pInfoClientMemoryLabel->Text = String::Format(
        "Avail Memory: {0:D} MB / {1:D} MB",
            (memory.ullAvailPhys / 1000000),
            (memory.ullTotalPhys / 1000000));
    GUI_PositionAndSizeBelow(pInfoClientMemoryLabel, pInfoWindowsVersionLabel, 2);
    //------------------------------------------------------------------------
    // Disk space information
    //------------------------------------------------------------------------
    Label ^pInfoDiskSpaceLabel = gcnew Label;
    DriveInfo ^driveInfo = gcnew DriveInfo(Environment::CurrentDirectory);
    pInfoDiskSpaceLabel->Text = String::Format(
        "Avail Storage: {0:D} MB / {1:D} MB",
            (driveInfo->AvailableFreeSpace / 1000000),
            (driveInfo->TotalSize / 1000000));
    GUI_PositionAndSizeBelow(pInfoDiskSpaceLabel, pInfoClientMemoryLabel, 2);
    delete driveInfo;
    //------------------------------------------------------------------------
    // The Silicon Labs driver version
    //------------------------------------------------------------------------
    Label ^pInfoDriverVersionLabel = gcnew Label;
    QD_GetUSBDriverVersion(&upperVersion, &lowerVersion);
    pInfoDriverVersionLabel->Text = String::Format(
        "Silicon Labs USB Driver Version: {0:X}.{1:X}.{2:X}.{3:X}",
        ((upperVersion >> 16) & 0xFFFF), (upperVersion & 0xFFFF),
        ((lowerVersion >> 16) & 0xFFFF), (lowerVersion & 0xFFFF));
    GUI_PositionAndSizeBelow(pInfoDriverVersionLabel, pInfoDiskSpaceLabel, 2);
    //------------------------------------------------------------------------
    // The Silicon Labs DLL version
    //------------------------------------------------------------------------
    Label ^pInfoUSBDLLVersionLabel = gcnew Label;
    QD_GetUSBDLLVersion(&upperVersion, &lowerVersion);
    pInfoUSBDLLVersionLabel->Text = String::Format(
        "Silicon Labs DLL Version: {0:X}.{1:X}.{2:X}.{3:X}",
        ((upperVersion >> 16) & 0xFFFF), (upperVersion & 0xFFFF),
        ((lowerVersion >> 16) & 0xFFFF), (lowerVersion & 0xFFFF));
    GUI_PositionAndSizeBelow(pInfoUSBDLLVersionLabel, pInfoDriverVersionLabel, 2);
    //------------------------------------------------------------------------
    // The qdUSB.dll version
    //------------------------------------------------------------------------
    Label ^pInfoQDDLLVersionLabel = gcnew Label;
    QD_GetQDDLLVersion((LPBYTE) &majorVersion, (LPBYTE) &minorVersion, (LPBYTE) &buildVersion);
    pInfoQDDLLVersionLabel->Text = String::Format(
        "QCOM DLL Version: {0:D}.{1:D}.{2:D}",
        majorVersion, minorVersion, buildVersion);
    GUI_PositionAndSizeBelow(pInfoQDDLLVersionLabel, pInfoUSBDLLVersionLabel, 2);
    //------------------------------------------------------------------------
    // The number of units allocated and the current number of units
    //------------------------------------------------------------------------
    Label ^pInfoUnitsMaximumAndCurrentLabel = gcnew Label;
    pInfoUnitsMaximumAndCurrentLabel->Text = String::Format(
        "Units allocated: {0:D}    Current units: {1:D}",
        QCOM_GeneralInfo->maximumNumberOfUnits,
        QCOM_CurrentNumberOfUnits);
    GUI_PositionAndSizeBelow(pInfoUnitsMaximumAndCurrentLabel, pInfoQDDLLVersionLabel, 2);
    //------------------------------------------------------------------------
    // The valid unit and the ready unit bitmaps
    //------------------------------------------------------------------------
    Label ^pInfoValidAndReadyUnitBitMaps = gcnew Label;
    pInfoValidAndReadyUnitBitMaps->Text = String::Format(
        "Valid: {0:X8}    Ready: {1:X8}",
        QCOM_GeneralInfo->validUnitBitMap,
        QCOM_GeneralInfo->readyUnitBitMap);
    GUI_PositionAndSizeBelow(pInfoValidAndReadyUnitBitMaps, pInfoUnitsMaximumAndCurrentLabel, 2);
    //------------------------------------------------------------------------
    // The memory consumed by one unit
    //------------------------------------------------------------------------
    Label ^pInfoUnitMemory = gcnew Label;
    pInfoUnitMemory->Text = String::Format(
        "Unit Size: {0:D}", QCOM_UnitInfoArray[0]->unitSize);
    GUI_PositionAndSizeBelow(pInfoUnitMemory, pInfoValidAndReadyUnitBitMaps, 2);
    //------------------------------------------------------------------------
    // Pressure Units
    //------------------------------------------------------------------------
    Label ^pInfoPressureUnits = gcnew Label;
    pInfoPressureUnits->Text = String::Format(
        "Pres Units:    Curr = {0:D}    Def = {1:D}    Alt = {2:D}",
        QCOM_CurrentPressureUnits, QCOM_DefaultPressureUnits, QCOM_AlternatePressureUnits);
    GUI_PositionAndSizeBelow(pInfoPressureUnits, pInfoUnitMemory, 2);
    //------------------------------------------------------------------------
    // Temperature Units
    //------------------------------------------------------------------------
    Label ^pInfoTemperatureUnits = gcnew Label;
    pInfoTemperatureUnits->Text = String::Format(
        "Temp Units:    Curr = {0:D}    Def = {1:D}    Alt = {2:D}",
        QCOM_CurrentTemperatureUnits, QCOM_DefaultTemperatureUnits, QCOM_AlternateTemperatureUnits);
    GUI_PositionAndSizeBelow(pInfoTemperatureUnits, pInfoPressureUnits, 2);
    //------------------------------------------------------------------------
    // The state flag settings in a single bitmapped flag
    //------------------------------------------------------------------------
    Label ^pInfoStateFlagsLabel = gcnew Label;
    if (QCOM_ProgramIntervalEnabled)
        stateFlags |= GUI_INTERVAL_ENABLED;
    if (QCOM_ExperimentsEnabled)
        stateFlags |= GUI_EXPERIMENTS_BASIC;
    if (QCOM_HaltOperationsOnErrors)
        stateFlags |= GUI_HALT_ON_ERRORS;
    if (QCOM_SoftwareUpdateInProgress)
        stateFlags |= GUI_SOFTWARE_UPDATE;
    pInfoStateFlagsLabel->Text = String::Format(
        "State Flags: {0:X8}", stateFlags);
    GUI_PositionAndSizeBelow(pInfoStateFlagsLabel, pInfoTemperatureUnits, 2);
    //------------------------------------------------------------------------
    // The message flag settings in a single bitmapped flag
    //------------------------------------------------------------------------
    Label ^pInfoMessageFlagsLabel = gcnew Label;
    if (QCOM_BasicMessagesEnabled)
        messageFlags |= GUI_MODAL_BASIC;
    if (QCOM_ErrorMessagesEnabled)
        messageFlags |= GUI_MODAL_ERROR;
    if (QCOM_VerboseMessagesEnabled)
        messageFlags |= GUI_MODAL_VERBOSE;
    if (QCOM_DetailedMessagesEnabled)
        messageFlags |= GUI_MODAL_DETAILED;
    if (QCOM_ExpMessagesEnabled)
        messageFlags |= GUI_MODAL_EXP;
    if (QCOM_StackTracesEnabled)
        messageFlags |= GUI_MODAL_STACK;
    if (QCOM_SendTextErrorMessagesEnabled)
        messageFlags |= GUI_MODAL_TEXT;
    if (QCOM_SendEmailErrorMessagesEnabled)
        messageFlags |= GUI_MODAL_EMAIL;
    if (QD_DLLMessagesEnabled)
        messageFlags |= GUI_MODAL_DLL;
    if (QCOM_EventLogBasicEnabled)
        messageFlags |= GUI_ELOG_BASIC;
    if (QCOM_EventLogVerboseEnabled)
        messageFlags |= GUI_ELOG_VERBOSE;
    if (QCOM_EventLogDetailedEnabled)
        messageFlags |= GUI_ELOG_DETAILED;
    if (QCOM_EventLogTestEnabled)
        messageFlags |= GUI_ELOG_TEST;
    pInfoMessageFlagsLabel->Text = String::Format(
        "Message Flags: {0:X8}", messageFlags);
    GUI_PositionAndSizeBelow(pInfoMessageFlagsLabel, pInfoStateFlagsLabel, 2);
    //------------------------------------------------------------------------
    // Set up the tab controls
    //------------------------------------------------------------------------
    pInfoTabControl = gcnew TabControl;
    pInfoTabControl->Size = Drawing::Size(
        pInfoGeneralGroupBox->Width,
        programInfoWindow->Height - pInfoGeneralGroupBox->Height - 102);
    GUI_PositionBelow(pInfoTabControl, pInfoGeneralGroupBox, 10);
    pInfoTabControl->Appearance = TabAppearance::Normal;
    pInfoTabControl->Alignment = TabAlignment::Top;
    programInfoWindow->Controls->Add(pInfoTabControl);
    //------------------------------------------------------------------------
    // Display the program information for valid individual units
    //------------------------------------------------------------------------
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        unitBitMap = (1 << unitNumber);
        if ((unitNumber < QCOM_CurrentNumberOfUnits) ||
            (unitBitMap & QCOM_GeneralInfo->validUnitBitMap))
        {
            //----------------------------------------------------------------
            // Enclose the unit info within group boxes
            //----------------------------------------------------------------
            QCOM_ProgramInformationDisplayTab(QCOM_UnitInfoArray[unitNumber]);
        }
    }
    //------------------------------------------------------------------------
    // Add the components to the general Program Info group box
    //------------------------------------------------------------------------
    array <Label ^> ^pInfoLabels =
    {
        pInfoProgramNameLabel,                  pInfoProgramTimerStateLabel,            pInfoWindowsVersionLabel,
        pInfoProgramVersionAndBuild,            pInfoSamplingTimerStateLabel,           pInfoClientMemoryLabel,
        pInfoThisMoment,                        pInfoSamplingTimerLimitLabel,           pInfoDiskSpaceLabel,
        pInfoProgramAuthor,                     pInfoLastStringSearchedLabel,           pInfoDriverVersionLabel,
        pInfoStartupPathLabel,                                                          pInfoUSBDLLVersionLabel,
        pInfoCommandLineParametersLabel,                                                pInfoQDDLLVersionLabel,
        pInfoGeneralUsePathLabel,                                                       pInfoUnitsMaximumAndCurrentLabel,
        pInfoConfigFilePathLabel,                                                       pInfoValidAndReadyUnitBitMaps,
        pInfoErrorLogFilePathLabel,                                                     pInfoUnitMemory,
        pInfoEventLogFilePathLabel,                                                     pInfoTemperatureUnits,
        pInfoEmailFromAddressLabel,                                                     pInfoPressureUnits,
        pInfoTextMessageToNumberLabel,          pInfoEmailMessageToAddressLabel,        pInfoStateFlagsLabel,
        pInfoTextMessageCCNumberLabel,          pInfoEmailMessageCCAddressLabel,        pInfoMessageFlagsLabel,
        pInfoGeneralFlags,                          pInfoGeneralPersistentFlags,            pInfoUnitPersistentFlags,
        pInfoGeneralLogFlags,                       pInfoGeneralPersistentLogFlags,         pInfoUnitPersistentLogFlags,
        pInfoGeneralTestFlags,                      pInfoGeneralPersistentTestFlags,        pInfoUnitPersistentTestFlags,
        pInfoGeneralDefaultPersistentFlags,         pInfoUnitDefaultPersistentFlags,
        pInfoGeneralDefaultPersistentLogFlags,      pInfoUnitDefaultPersistentLogFlags,
        pInfoGeneralDefaultPersistentTestFlags,     pInfoUnitDefaultPersistentTestFlags
    };
    pInfoGeneralGroupBox->Controls->AddRange(pInfoLabels);
    //------------------------------------------------------------------------
    // Add a Close button
    //------------------------------------------------------------------------
    Button ^pInfoCloseButton = gcnew Button;
    pInfoCloseButton->Text = _T("Close");
    pInfoCloseButton->Location = Point(
        programInfoWindow->Right - 100,
        programInfoWindow->Bottom - 70);
    pInfoCloseButton->Size = Drawing::Size(
        GUI_CLOSE_BUTTON_WIDTH,
        GUI_REGULAR_BUTTON_HEIGHT);
    pInfoCloseButton->DialogResult = System::Windows::Forms::DialogResult::OK;
    GUI_SetButtonInterfaceProperties(pInfoCloseButton);
    pInfoCloseButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ProgramInformationCloseWindow);
    programInfoWindow->Controls->Add(pInfoCloseButton);
    //------------------------------------------------------------------------
    // Set the remaining window properties
    //------------------------------------------------------------------------
    programInfoWindow->AcceptButton = pInfoCloseButton;
    programInfoWindow->CancelButton = pInfoCloseButton;
    //------------------------------------------------------------------------
    // Finally, display the new window
    //------------------------------------------------------------------------
    programInfoWindow->ResumeLayout();
    programInfoWindow->ShowDialog();
    programInfoWindow->BringToFront();
    if (programInfoWindow->CanFocus)
        programInfoWindow->Focus();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ProgramInformationDisplayWindow()
//----------------------------------------------------------------------------
#endif      // MISC_CPP
//============================================================================
// End of Misc.cpp
//============================================================================
