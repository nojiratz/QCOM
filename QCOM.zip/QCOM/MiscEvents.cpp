//============================================================================
// MiscEvents.cpp
//
// The event methods used by Misc.cpp for miscellaneous expert tasks
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     MISCEVENTS_CPP
#define     MISCEVENTS_CPP
#include    "MiscEvents.h"
//----------------------------------------------------------------------------
// QCOM_ExpertProgramInfoButtonClicked
//
// Handles the click of the Program Info button
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertProgramInfoButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Misc Program Info button clicked");
    QCOM_ProgramInformationDisplayWindow();
}                                       // end of QCOM_ExpertProgramInfoButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscBootLoaderButtonClicked
//
// Handles the click of the BootLoader button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscBootLoaderButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscBootLoaderButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc BootLoader button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_ToggleBootLoaderMode(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscBootLoaderButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscClearErrorCodeButtonClicked
//
// Handles the click of the Clear Error Code button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscClearErrorCodeButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscClearErrorCodeButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Clear Error Code button clicked for module {0}",
            unit->moduleSerialNumber);
        QD_ClearInternalError(unit->unitHandle);
        miscGetErrorCodeBoxArray[unitNumber]->Clear();
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscClearErrorCodeButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscClearI2CCommandBox
//
// Handles the editing (validation) of the I2C command combo box by clearing
// its command label and hiding the response interpretation label text
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscClearI2CCommandBox(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <ComboBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_MiscClearI2CCommandBox");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        miscI2CReplyInterpLabelArray[unitNumber]->Visible = GUI_NO;
        miscI2CResponseBoxArray[unitNumber]->Clear();
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscClearI2CCommandBox()
//----------------------------------------------------------------------------
// QCOM_MiscCloseDisplayDLLFunctionsWindow
//
// Event that closes the Display DLL Functions window
//
// Called by:   QCOM_MiscDisplayDLLFunctions
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscCloseDisplayDLLFunctionsWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscCloseDisplayDLLFunctionsWindow");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc DLL Functions window closed for module {0}",
            unit->moduleSerialNumber);
        miscDisplayDLLFunctionsWindowArray[unitNumber]->Close();
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscCloseDisplayDLLFunctionsWindow()
//----------------------------------------------------------------------------
// QCOM_MiscCloseWindow
//
// Event that hides the Misc Controls window
//
// Called by:   QCOM_MiscSetUpControls
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Misc Control window closed");
    miscControlWindow->Hide();
}                                       // end of QCOM_MiscCloseWindow()
//----------------------------------------------------------------------------
// QCOM_MiscClosingPFCWindow
//
// Handles the closing of the Misc Persistent Flags Control window by the red
// X or similar method
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscClosingPFCWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Misc Persistent Flags window closed");
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    miscPFControlWindow->Hide();
}                                       // end of QCOM_MiscClosingPFCWindow()
//----------------------------------------------------------------------------
// QCOM_MiscClosingWindow
//
// Handles the closing of the Misc Controls window by the red X or similar
// method
//
// Called by:   QCOM_MiscSetUpControls
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Misc Control window closed");
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    miscControlWindow->Hide();
}                                       // end of QCOM_MiscClosingWindow()
//----------------------------------------------------------------------------
// QCOM_MiscControlsButtonClicked
//
// Handles the click of the Misc Controls button by displaying the
// window
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscControlsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //--------------------------------------------------------------------
    RecordBasicEvent("Misc Controls button clicked");
    if (miscControlWindow->WindowState == FormWindowState::Minimized)
        miscControlWindow->WindowState = FormWindowState::Normal;
    else
        miscControlWindow->Show();
    miscControlWindow->BringToFront();
    if (miscControlWindow->CanFocus)
        miscControlWindow->Focus();
    if (miscControlWindow->CanSelect)
        miscControlWindow->Select();
}                                       // end of QCOM_MiscControlsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscDeleteConfigChecked
//
// Handles the check of the Miscellaneous Delete Config File On Exit checkbox
//
// Called by:   QCOM_MiscSetUpControls
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscDeleteConfigChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DELETE_ON_EXIT)
        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_CONFIG_DELETE_ON_EXIT;
    else
        QCOM_GeneralInfo->flags |= QCOM_GENERAL_CONFIG_DELETE_ON_EXIT;
    RecordBasicEvent(
        "Misc Delete Config File on Exit {0}",
        ((QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DELETE_ON_EXIT) ? "checked" : "un-checked"));
    QCOM_MiscUpdateChecks();
}                                       // end of QCOM_MiscDeleteConfigChecked()
//----------------------------------------------------------------------------
// QCOM_MiscDisplayRawModuleCoeffButtonClicked
//
// Handles the click of the Display Raw Module Coefficient Data button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscDisplayRawModuleCoeffButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscDisplayRawModuleCoeffButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Display Raw Module Coefficient Data button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_DisplayRawCoefficientData(unit, QD_DEVICE_MODULE);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscDisplayRawModuleCoeffButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscDisplayRawXDCoeffButtonClicked
//
// Handles the click of the Display Raw Transducer Coefficient Data button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscDisplayRawXDCoeffButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscDisplayRawXDCoeffButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Display Raw Transducer Coefficient Data button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_DisplayRawCoefficientData(unit, QD_DEVICE_TRANSDUCER);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscDisplayRawXDCoeffButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscDisplayDLLFunctionsButtonClicked
//
// Handles the click of the Display All DLL Functions button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscDisplayDLLFunctionsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscDisplayDLLFunctionsButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Display DLL Functions button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_MiscDisplayDLLFunctions(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscDisplayDLLFunctionsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscEnableSoundsChecked
//
// Handles the check of the Miscellaneous Enable Program Sounds checkbox
//
// Called by:   QCOM_MiscSetUpControls
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscEnableSoundsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_SOUNDS_ENABLED)
        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_SOUNDS_ENABLED;
    else
        QCOM_GeneralInfo->flags |= QCOM_GENERAL_SOUNDS_ENABLED;
    RecordBasicEvent(
        "Misc Enable Sounds {0}",
        ((QCOM_GeneralInfo->flags & QCOM_GENERAL_SOUNDS_ENABLED) ? "checked" : "un-checked"));
    QCOM_MiscUpdateChecks();
}                                       // end of QCOM_MiscEnableSoundsChecked()
//----------------------------------------------------------------------------
// QCOM_MiscGetControlRegisterButtonClicked
//
// Handles the click of the Get Control Register button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscGetControlRegisterButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    BYTE            controlRegister = 0;
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscGetControlRegisterButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Get Control Register button clicked for module {0}",
            unit->moduleSerialNumber);
        DWORD status = QD_GetModuleControlRegister(
            unit->unitHandle,
            (LPBYTE) &controlRegister);
        if (status == QD_SUCCESS)
        {
            miscGetControlRegisterBoxArray[unitNumber]->BackColor = Color::Lavender;
            miscGetControlRegisterBoxArray[unitNumber]->Text = String::Format(
                "0x{0:X2}", controlRegister);
            RecordVerboseEvent(
                "    Control Register = {0}",
                miscGetControlRegisterBoxArray[unitNumber]->Text);
        }
        else
        {
            miscGetControlRegisterBoxArray[unitNumber]->BackColor = Color::Orange;
            miscGetControlRegisterBoxArray[unitNumber]->Text = String::Format(
                "0x{0:X2}", (status & 0xFF));
            RecordErrorEvent(
                "    QD_GetModuleControlRegister returned status 0x{0:X8}", status);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscGetControlRegisterButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscGetFirmwareIDButtonClicked
//
// Handles the click of the Get Firmware ID button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscGetFirmwareIDButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    char            firmwareIDString[QCOM_MAXIMUM_FIRMWARE_STRING_SIZE];        // 40
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscGetFirmwareIDButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Get Firmware ID button clicked for module {0}",
            unit->moduleSerialNumber);
        DWORD status = QD_GetModuleFirmwareID(
            unit->unitHandle,
            (LPBYTE) firmwareIDString);
        if (status == QD_SUCCESS)
        {
            miscGetFirmwareIDBoxArray[unitNumber]->BackColor = Color::Lavender;
            miscGetFirmwareIDBoxArray[unitNumber]->Text = String::Format(
                "{0:X2} {1:X2} {2:X2} {3:X2}",
                firmwareIDString[0], firmwareIDString[1],
                firmwareIDString[2], firmwareIDString[3]);
            RecordVerboseEvent(
                "    Firmware ID = {0}",
                miscGetFirmwareIDBoxArray[unitNumber]->Text);
        }
        else
        {
            miscGetFirmwareIDBoxArray[unitNumber]->BackColor = Color::Orange;
            miscGetFirmwareIDBoxArray[unitNumber]->Text = String::Format(
                "0x{0:X8}", status);
            RecordErrorEvent(
                "    QD_GetModuleFirmwareID returned status 0x{0:X8}", status);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscGetFirmwareIDButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscGetI2CDataRateButtonClicked
//
// Handles the click of the Get Data Rate button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscGetI2CDataRateButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscGetI2CDataRateButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Get I2C Data Rate button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_MiscGetAndPostI2CDataRate(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscGetI2CDataRateButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscGetMemoryTypeButtonClicked
//
// Handles the click of the Get Memory Type button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscGetMemoryTypeButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    BYTE            device = QD_DEVICE_TRANSDUCER;                              // 0
    BYTE            memoryType = 0;
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscGetMemoryTypeButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if ((unit->transducerType == QD_TRANSDUCER_TYPE_ABSENT) ||
            QCOM_XDIsFrequency(unit))
            device = QD_DEVICE_MODULE;                                          // 1
        if ((device == QD_DEVICE_TRANSDUCER) &&
            QCOM_XDSNValid(unit))
        {
            RecordBasicEvent(
                "Misc Get Memory Type button clicked for module {0} transducer {1}",
                unit->moduleSerialNumber,
                unit->transducerSerialNumber);
        }
        else
        {
            RecordBasicEvent(
                "Misc Get Memory Type button clicked for module {0}",
                unit->moduleSerialNumber);
        }
        DWORD status = QD_GetMemoryType(
            unit->unitHandle,
            device,
            (LPBYTE) &memoryType);
        if (status == QD_SUCCESS)
        {
            miscGetMemoryTypeBoxArray[unitNumber]->BackColor = Color::Lavender;
            miscGetMemoryTypeBoxArray[unitNumber]->Text = String::Format(
                "0x{0:X2}", memoryType);
            RecordVerboseEvent(
                "    {0} memory type = {1}",
                ((device == QD_DEVICE_MODULE) ? "QCOM module" : "Transducer"),
                miscGetMemoryTypeBoxArray[unitNumber]->Text);
        }
        else
        {
            miscGetMemoryTypeBoxArray[unitNumber]->BackColor = Color::Orange;
            miscGetMemoryTypeBoxArray[unitNumber]->Text = String::Format(
                "0x{0:X2}", (status & 0xFF));
            RecordErrorEvent(
                "    QD_GetMemoryType returned status 0x{0:X8} for device {1:D}",
                status, device);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscGetMemoryTypeButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscGetNumberOfModulesButtonClicked
//
// Handles the click of the Get Number of Modules button
//
// Called by:   QCOM_MiscSetUpControls
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscGetNumberOfModulesButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("QCOM_MiscGetNumberOfModulesButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DWORD numberOfUnits = QD_GetNumberOfModules();
    miscGetNumberOfModulesBox->Text = String::Concat(numberOfUnits);
    RecordBasicEvent(
        "    {0} QCOM / CalMux module{1} detected",
        miscGetNumberOfModulesBox->Text,
        ((numberOfUnits == 1) ? "" : "s"));
}                                       // end of QCOM_MiscGetNumberOfModulesButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscGetQCOMDLLVersionButtonClicked
//
// Handles the click of the Get QCOM DLL Version button
//
// Called by:   QCOM_MiscSetUpControls
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscGetQCOMDLLVersionButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    BYTE            currentMajorVersion = 0;
    BYTE            currentMinorVersion = 0;
    BYTE            currentBuildVersion = 0;
    String          ^functionName = _T("QCOM_MiscGetQCOMDLLVersionButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DWORD status = QD_GetQDDLLVersion(
        (LPBYTE) &currentMajorVersion,
        (LPBYTE) &currentMinorVersion,
        (LPBYTE) &currentBuildVersion);
    if (status == QD_SUCCESS)
    {
        miscGetQCOMDLLVersionBox->BackColor = Color::Lavender;
        miscGetQCOMDLLVersionBox->Text = String::Format(
            "{0:D}.{1:D}.{2:D}",
            currentMajorVersion,
            currentMinorVersion,
            currentBuildVersion);
        RecordBasicEvent(
            "    QCOM qdUSB.dll version {0:D}.{1:D}.{2:D} is installed",
            currentMajorVersion,
            currentMinorVersion,
            currentBuildVersion);
    }
    else
    {
        miscGetQCOMDLLVersionBox->BackColor = Color::Orange;
        miscGetQCOMDLLVersionBox->Text = String::Format(
            "0x{0:X2}", (status & 0xFF));
        RecordErrorEvent(
            "    QD_GetQDDLLVersion returned status 0x{0:X8}", status);
    }
}                                       // end of QCOM_MiscGetQCOMDLLVersionButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscGetSetI2CDataRateBoxClicked
//
// Handles the click of the I2C Data Rate text box by clearing the contents
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscGetSetI2CDataRateBoxClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <TextBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscGetSetI2CDataRateBoxClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc I2C Data Rate box clicked (and cleared) for module {0}",
            unit->moduleSerialNumber);
        miscGetDataRateBoxArray[unitNumber]->Clear();
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscGetSetI2CDataRateBoxClicked()
//----------------------------------------------------------------------------
// QCOM_MiscGetStatusRegisterButtonClicked
//
// Handles the click of the Support Log button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscGetStatusRegisterButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    BYTE            statusRegister = 0;
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscGetStatusRegisterButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Get Status Register button clicked for module {0}",
            unit->moduleSerialNumber);
        DWORD status = QD_GetModuleStatusRegister(
            unit->unitHandle,
            (LPBYTE) &statusRegister);
        if (status == QD_SUCCESS)
        {
            miscGetStatusRegisterBoxArray[unitNumber]->BackColor = Color::Lavender;
            miscGetStatusRegisterBoxArray[unitNumber]->Text = String::Format(
                "0x{0:X2}", statusRegister);
            RecordBasicEvent(
                "    Status Register = {0}",
                miscGetStatusRegisterBoxArray[unitNumber]->Text);
        }
        else
        {
            miscGetStatusRegisterBoxArray[unitNumber]->BackColor = Color::Orange;
            miscGetStatusRegisterBoxArray[unitNumber]->Text = String::Format(
                "0x{0:X2}", (status & 0xFF));
            RecordErrorEvent(
                "    QD_GetModuleStatusRegister returned status 0x{0:X8}", status);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscGetStatusRegisterButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscGetTimeoutsButtonClicked
//
// Handles the click of the Get Timeouts button
//
// Called by:   QCOM_MiscSetUpControls
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscGetTimeoutsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           readTimeout;
    DWORD           writeTimeout;
    String          ^functionName = _T("QCOM_MiscGetTimeoutsButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    DWORD status = QD_GetTimeouts(
        (LPDWORD) &readTimeout,
        (LPDWORD) &writeTimeout);
    if (status == QD_SUCCESS)
    {
        miscReadTimeoutBox->BackColor = Color::White;
        miscReadTimeoutBox->Text = String::Concat(readTimeout);
        miscWriteTimeoutBox->BackColor = Color::White;
        miscWriteTimeoutBox->Text = String::Concat(writeTimeout);
        RecordBasicEvent(
            "    Read Timeout = {0} ms and Write Timeout = {1} ms",
            miscReadTimeoutBox->Text,
            miscWriteTimeoutBox->Text);
    }
    else
    {
        miscReadTimeoutBox->BackColor = Color::Orange;
        miscReadTimeoutBox->Text = String::Format(
            "0x{0:X2}", (status & 0xFF));
        miscWriteTimeoutBox->BackColor = Color::Orange;
        miscWriteTimeoutBox->Text = String::Format(
            "0x{0:X2}", (status & 0xFF));
        RecordErrorEvent(
            "    QD_GetTimeouts returned status 0x{0:X8}", status);
    }
}                                       // end of QCOM_MiscGetTimeoutsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscGetTransducerChipIDButtonClicked
//
// Handles the click of the Get Transducer Chip ID button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscGetTransducerChipIDButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            validID = GUI_NO;
    char            *commandString;
    char            *replyString;
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    array <int>     ^transducerChipID = gcnew array <int> (QD_TRANSDUCER_CHIP_ID_LENGTH);
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscGetTransducerChipIDButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Get Transducer Chip ID button clicked for transducer {0}",
            unit->transducerSerialNumber);
        commandString = (char *) malloc(QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE);
        replyString = (char *) malloc(QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
        if (commandString && replyString)
        {
            ClearBuffer(replyString, QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
            strcpy_s(
                commandString,
                QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                ((QCOM_XDIsFrequency(unit) || QCOM_XDIsDigitalNoMem(unit)) ?
                    "S98R99FFFFFFFFP"  :
                    "S9CR9DFFFFFFFFP"));
            DWORD status = QD_ExecuteI2CCommand(
                unit->unitHandle,
                (LPBYTE) commandString,
                (LPBYTE) replyString);
            if (status == QD_SUCCESS)
            {
                if (strlen(replyString) >= 8)
                {
                    for (int index = 0; index < QD_TRANSDUCER_CHIP_ID_LENGTH; index++)
                    {
                        transducerChipID[index] =
                            (AtoX(replyString[6 + index * 2]) << 4) | AtoX(replyString[7 + index * 2]);
                    }
                    if (transducerChipID[0] == QD_QUARTZDYNE_ID)
                        validID = GUI_YES;
                }                       // end of if (strlen(replyString) >= 8)
                else
                {
                    QCOM_RecordAndModalErrorEvent(
                        "{0}({1:D}) :\nQD_ExecuteI2CCommand returned reply string '{2}'",
                        functionName, unit->unitNumber, gcnew String(replyString));
                }
            }
            else
            {
                miscGetTransducerChipIDBoxArray[unitNumber]->Text = String::Format(
                    "0x{0:X8}", status);
                QCOM_RecordAndModalErrorEvent(
                    "{0}({1:D}) :\nQD_ExecuteI2CCommand returned status 0x{2:X8}",
                    functionName, unit->unitNumber, status);
            }
            free((void *) replyString);
            free((void *) commandString);
        }                               // end of if (commandString && replyString)
        if (validID)
        {
            miscGetTransducerChipIDBoxArray[unitNumber]->BackColor = Color::Lavender;
            miscGetTransducerChipIDBoxArray[unitNumber]->Text = String::Format(
                "{0:X2} {1:X2} {2:X2} {3:X2}",
                transducerChipID[0], transducerChipID[1],
                transducerChipID[2], transducerChipID[3]);
            RecordVerboseEvent(
                "    Transducer chip ID = {0}",
                miscGetTransducerChipIDBoxArray[unitNumber]->Text);
        }
        else
        {
            miscGetTransducerChipIDBoxArray[unitNumber]->BackColor = Color::Orange;
            miscGetTransducerChipIDBoxArray[unitNumber]->Text = gcnew String(replyString);
        }
    }                                   // end of if (QCOM_UnitNumberValid(unitNumber))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscGetTransducerChipIDButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscGetTransducerTypeButtonClicked
//
// Handles the click of the Get Transducer Type button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscGetTransducerTypeButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    BYTE            transducerType;
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscGetTransducerTypeButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if (QCOM_XDSNValid(unit))
        {
            RecordBasicEvent(
                "Misc Get Transducer Type button clicked for transducer {0}",
                unit->transducerSerialNumber);
        }
        else
        {
            RecordBasicEvent(
                "Misc Get Transducer Type button clicked for module {0}",
                unit->moduleSerialNumber);
        }
        DWORD status = QD_GetTransducerType(
            unit->unitHandle,
            (LPBYTE) &transducerType);
        if (status == QD_SUCCESS)
        {
            miscGetTransducerTypeBoxArray[unitNumber]->BackColor = Color::Lavender;
            miscGetTransducerTypeBoxArray[unitNumber]->Text = String::Format(
                "0x{0:X2}", transducerType);
            RecordVerboseEvent(
                "    Transducer type = {0}",
                miscGetTransducerTypeBoxArray[unitNumber]->Text);
        }
        else
        {
            miscGetTransducerTypeBoxArray[unitNumber]->BackColor = Color::Orange;
            miscGetTransducerTypeBoxArray[unitNumber]->Text = String::Format(
                "0x{0:X2}", (status & 0xFF));
            RecordErrorEvent(
                "    QD_GetTransducerType returned status 0x{0:X8}", status);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscGetTransducerTypeButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscPFButtonClicked
//
// Handles the click of the Misc Persistent Flags Control button by displaying
// the window
//
// Called by:   QCOM_MiscSetUpControls
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Misc Persistent Flags button clicked");
    if (miscPFControlWindow->WindowState == FormWindowState::Minimized)
        miscPFControlWindow->WindowState = FormWindowState::Normal;
    else
        miscPFControlWindow->Show();
    if (miscPFControlWindow->CanSelect)
        miscPFControlWindow->Select();
}                                       // end of QCOM_MiscPFButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscPFCloseWindow
//
// Event that hides the Misc Persistent Flags Control window
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Misc Persistent Flags window closed");
    miscPFControlWindow->Hide();
}                                       // end of QCOM_MiscPFCloseWindow()
//----------------------------------------------------------------------------
// QCOM_MiscPFGeneralLogBothFileFormatsChecked
//
// Handles the check of the Log Both File Formats checkbox
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFGeneralLogBothFileFormatsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_FILE_BOTH_FORMATS)
        QCOM_GeneralInfo->persistentLogFlags &= ~QCOM_GENERAL_LOG_FILE_BOTH_FORMATS;
    else
        QCOM_GeneralInfo->persistentLogFlags |= QCOM_GENERAL_LOG_FILE_BOTH_FORMATS;
    RecordBasicEvent(
        "Misc Persistent General Log Both File Formats flag {0}",
        ((QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_FILE_BOTH_FORMATS) ? "checked" : "un-checked"));
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFGeneralLogBothFileFormatsChecked()
//----------------------------------------------------------------------------
// QCOM_MiscPFGeneralLogDataSaveImmediatelyChecked
//
// Handles the check of the Persistent Save All Log Data box
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFGeneralLogDataSaveImmediatelyChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_DATA_SAVE_IMMEDIATELY)
        QCOM_GeneralInfo->persistentLogFlags &= ~QCOM_GENERAL_LOG_DATA_SAVE_IMMEDIATELY;
    else
        QCOM_GeneralInfo->persistentLogFlags |= QCOM_GENERAL_LOG_DATA_SAVE_IMMEDIATELY;
    RecordBasicEvent(
        "Misc Persistent Unit Save Log Immediately flag {0}",
        ((QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_DATA_SAVE_IMMEDIATELY) ? "checked" : "un-checked"));
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFGeneralLogDataSaveImmediatelyChecked()
//----------------------------------------------------------------------------
// QCOM_MiscPFGeneralLogDisplayAllSummariesChecked
//
// Handles the check of the Persistent Display All Summaries checkbox
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFGeneralLogDisplayAllSummariesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_DISPLAY_SUMMARIES)
        QCOM_GeneralInfo->persistentLogFlags &= ~QCOM_GENERAL_LOG_DISPLAY_SUMMARIES;
    else
        QCOM_GeneralInfo->persistentLogFlags |= QCOM_GENERAL_LOG_DISPLAY_SUMMARIES;
    RecordBasicEvent(
        "Misc Persistent General Log Display All Summaries flag {0}",
        ((QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_DISPLAY_SUMMARIES) ? "checked" : "un-checked"));
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFGeneralLogDisplayAllSummariesChecked()
//----------------------------------------------------------------------------
// QCOM_MiscPFGeneralLogDisplayAllWrappedChecked
//
// Handles the check of the Display All Log Wrapped checkbox
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFGeneralLogDisplayAllWrappedChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_DISPLAY_WRAP)
        QCOM_GeneralInfo->persistentLogFlags &= ~QCOM_GENERAL_LOG_DISPLAY_WRAP;
    else
        QCOM_GeneralInfo->persistentLogFlags |= QCOM_GENERAL_LOG_DISPLAY_WRAP;
    RecordBasicEvent(
        "Misc Persistent General Log Wrap Text In All flag {0}",
        ((QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_DISPLAY_WRAP) ? "checked" : "un-checked"));
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFGeneralLogDisplayAllWrappedChecked()
//----------------------------------------------------------------------------
// QCOM_MiscPFGeneralLogPrependEntryNumbersChecked
//
// Handles the check of the Prepend Entry Numbers checkbox
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFGeneralLogPrependEntryNumbersChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS)
        QCOM_GeneralInfo->persistentLogFlags &= ~QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS;
    else
        QCOM_GeneralInfo->persistentLogFlags |= QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS;
    RecordBasicEvent(
        "Misc Persistent General Log Prepend Entry Numbers flag {0}",
        ((QCOM_GeneralInfo->persistentLogFlags & QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS) ? "checked" : "un-checked"));
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFGeneralLogPrependEntryNumbersChecked()
//----------------------------------------------------------------------------
// QCOM_MiscPFGeneralSoundsEnabledChecked
//
// Handles the check of the Persistent Sounds Enabled checkbox
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFGeneralSoundsEnabledChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentFlags & QCOM_GENERAL_SOUNDS_ENABLED)
        QCOM_GeneralInfo->persistentFlags &= ~QCOM_GENERAL_SOUNDS_ENABLED;
    else
        QCOM_GeneralInfo->persistentFlags |= QCOM_GENERAL_SOUNDS_ENABLED;
    RecordBasicEvent(
        "Misc Persistent General Enable Sounds flag {0}",
        ((QCOM_GeneralInfo->persistentFlags & QCOM_GENERAL_SOUNDS_ENABLED) ? "checked" : "un-checked"));
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFGeneralSoundsEnabledChecked()
//----------------------------------------------------------------------------
// QCOM_MiscPFGeneralTestDisplayXDTestsChecked
//
// Handles the check of the Persistent Display Transducer Tests checkbox
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFGeneralTestDisplayXDTestsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentTestFlags & QCOM_GENERAL_TEST_DISPLAY_XD_TESTS)
        QCOM_GeneralInfo->persistentTestFlags &= ~QCOM_GENERAL_TEST_DISPLAY_XD_TESTS;
    else
        QCOM_GeneralInfo->persistentTestFlags |= QCOM_GENERAL_TEST_DISPLAY_XD_TESTS;
    RecordBasicEvent(
        "Misc Persistent General Display Transducer Tests flag {0}",
        ((QCOM_GeneralInfo->persistentTestFlags & QCOM_GENERAL_TEST_DISPLAY_XD_TESTS) ? "checked" : "un-checked"));
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFGeneralTestDisplayXDTestsChecked()
//----------------------------------------------------------------------------
// QCOM_MiscPFSetAllDefaultsButtonClicked
//
// Handles the click of the Set All Persistent Flags to Defaults button
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFSetAllDefaultsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Misc Persistent Flags Set All Defaults button clicked");
    QCOM_GeneralInfo->persistentFlags = QCOM_GENERAL_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentLogFlags = QCOM_GENERAL_LOG_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentTestFlags = QCOM_GENERAL_TEST_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentUnitFlags = QCOM_UNIT_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentUnitLogFlags = QCOM_UNIT_LOG_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentUnitLogDataPoints = QCOM_UNIT_LOG_DEFAULT_PERSISTENT_POINTS;
    QCOM_GeneralInfo->persistentUnitTestFlags = QCOM_UNIT_TEST_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentUnitGraphingFlags = QCOM_UNIT_GRAPH_DEFAULT_PERSISTENT_FLAGS;
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFSetAllDefaultsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscPFSetGeneralDefaultsButtonClicked
//
// Handles the click of the Set General Persistent Flags to Defaults button
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFSetGeneralDefaultsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Misc Persistent Flags Set General Defaults button clicked");
    QCOM_GeneralInfo->persistentFlags = QCOM_GENERAL_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentLogFlags = QCOM_GENERAL_LOG_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentTestFlags = QCOM_GENERAL_TEST_DEFAULT_PERSISTENT_FLAGS;
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFSetGeneralDefaultsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscPFSetUnitDefaultsButtonClicked
//
// Handles the click of the Set Unit Persistent Flags to Defaults button
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFSetUnitDefaultsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Misc Persistent Flags Set Unit Defaults button clicked");
    QCOM_GeneralInfo->persistentUnitFlags = QCOM_UNIT_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentUnitLogFlags = QCOM_UNIT_LOG_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentUnitLogDataPoints = QCOM_UNIT_LOG_DEFAULT_PERSISTENT_POINTS;
    QCOM_GeneralInfo->persistentUnitTestFlags = QCOM_UNIT_TEST_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentUnitGraphingFlags = QCOM_UNIT_GRAPH_DEFAULT_PERSISTENT_FLAGS;
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFSetUnitDefaultsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscPFUnitDisplayHexCountsChecked
//
// Handles the check of the Persistent Unit Hex Counts checkbox
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFUnitDisplayHexCountsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentUnitFlags & QCOM_UNIT_DISPLAY_COUNTS_IN_HEX)
        QCOM_GeneralInfo->persistentUnitFlags &= ~QCOM_UNIT_DISPLAY_COUNTS_IN_HEX;
    else
        QCOM_GeneralInfo->persistentUnitFlags |= QCOM_UNIT_DISPLAY_COUNTS_IN_HEX;
    RecordBasicEvent(
        "Misc Persistent Unit Display Counts in Hex flag {0}",
        ((QCOM_GeneralInfo->persistentUnitFlags & QCOM_UNIT_DISPLAY_COUNTS_IN_HEX) ? "checked" : "un-checked"));
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFUnitDisplayHexCountsChecked()
//----------------------------------------------------------------------------
// QCOM_MiscPFUnitEmailXDReadingsChecked
//
// Handles the check of the Persistent Unit Email Transducer Readings box
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFUnitEmailXDReadingsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentUnitFlags & QCOM_UNIT_SEND_EMAIL_XD_READINGS)
        QCOM_GeneralInfo->persistentUnitFlags &= ~QCOM_UNIT_SEND_EMAIL_XD_READINGS;
    else
        QCOM_GeneralInfo->persistentUnitFlags |= QCOM_UNIT_SEND_EMAIL_XD_READINGS;
    RecordBasicEvent(
        "Misc Persistent Unit Email Transducer Readings flag {0}",
        ((QCOM_GeneralInfo->persistentUnitFlags & QCOM_UNIT_SEND_EMAIL_XD_READINGS) ? "checked" : "un-checked"));
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFUnitEmailXDReadingsChecked()
//----------------------------------------------------------------------------
// QCOM_MiscPFUnitLogDataSaveImmediatelyChecked
//
// Handles the check of the Persistent Unit Save Log Immediately box
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFUnitLogDataSaveImmediatelyChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentUnitLogFlags & QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY)
        QCOM_GeneralInfo->persistentUnitLogFlags &= ~QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY;
    else
        QCOM_GeneralInfo->persistentUnitLogFlags |= QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY;
    RecordBasicEvent(
        "Misc Persistent Unit Save Log Immediately flag {0}",
        ((QCOM_GeneralInfo->persistentUnitLogFlags & QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY) ? "checked" : "un-checked"));
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFUnitLogDataSaveImmediatelyChecked()
//----------------------------------------------------------------------------
// QCOM_MiscPFUnitSendXDReadingsChecked
//
// Handles the check of the Persistent Unit Send Transducer Readings box
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFUnitSendXDReadingsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentUnitFlags & QCOM_UNIT_SEND_XD_READINGS)
        QCOM_GeneralInfo->persistentUnitFlags &= ~QCOM_UNIT_SEND_XD_READINGS;
    else
        QCOM_GeneralInfo->persistentUnitFlags |= QCOM_UNIT_SEND_XD_READINGS;
    RecordBasicEvent(
        "Misc Persistent Unit Send Transducer Readings flag {0}",
        ((QCOM_GeneralInfo->persistentUnitFlags & QCOM_UNIT_SEND_XD_READINGS) ? "checked" : "un-checked"));
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFUnitSendXDReadingsChecked()
//----------------------------------------------------------------------------
// QCOM_MiscPFUnitTestResultsDisplayChecked
//
// Handles the check of the Persistent Unit Test Results Display checkbox
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFUnitTestResultsDisplayChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentUnitTestFlags & QCOM_UNIT_TEST_RESULTS_DISPLAYED)
        QCOM_GeneralInfo->persistentUnitTestFlags &= ~QCOM_UNIT_TEST_RESULTS_DISPLAYED;
    else
        QCOM_GeneralInfo->persistentUnitTestFlags |= QCOM_UNIT_TEST_RESULTS_DISPLAYED;
    RecordBasicEvent(
        "Misc Persistent Unit Display Test Results flag {0}",
        ((QCOM_GeneralInfo->persistentUnitFlags & QCOM_UNIT_TEST_RESULTS_DISPLAYED) ? "checked" : "un-checked"));
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFUnitTestResultsDisplayChecked()
//----------------------------------------------------------------------------
// QCOM_MiscPFUnitTextXDReadingsChecked
//
// Handles the check of the Persistent Unit Text Transducer Readings box
//
// Called by:   QCOM_MiscPFSetUpControl
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscPFUnitTextXDReadingsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->persistentUnitFlags & QCOM_UNIT_SEND_TEXT_XD_READINGS)
        QCOM_GeneralInfo->persistentUnitFlags &= ~QCOM_UNIT_SEND_TEXT_XD_READINGS;
    else
        QCOM_GeneralInfo->persistentUnitFlags |= QCOM_UNIT_SEND_TEXT_XD_READINGS;
    RecordBasicEvent(
        "Misc Persistent Unit Text Transducer Readings flag {0}",
        ((QCOM_GeneralInfo->persistentUnitFlags & QCOM_UNIT_SEND_TEXT_XD_READINGS) ? "checked" : "un-checked"));
    QCOM_MiscUpdatePersistentChecks();
}                                       // end of QCOM_MiscPFUnitTextXDReadingsChecked()
//----------------------------------------------------------------------------
// QCOM_MiscProcessI2CCommandBoxEnterKey
//
// Processes the result of accepting the Enter key in the I2C command combo box
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscProcessI2CCommandBoxEnterKey(
    Object          ^sender,
    KeyEventArgs    ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <ComboBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscProcessI2CCommandBoxEnterKey");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if (evt->KeyCode == Keys::Enter)
        {
            RecordBasicEvent(
                "Misc I2C Command box Enter Key pressed for module {0}",
                unit->moduleSerialNumber);
            QCOM_MiscSendI2CCommand(unit);
            //----------------------------------------------------------------
            // The following line prevents the handler from reacting to this
            // key press as though it was done in error (ding!)
            //----------------------------------------------------------------
            evt->SuppressKeyPress = GUI_YES;
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscProcessI2CCommandBoxEnterKey()
//----------------------------------------------------------------------------
// QCOM_MiscReadCadenceTimerButtonClicked
//
// Handles the click of the Get Cadence Timer button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscReadCadenceTimerButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           cadenceTimer = 0;
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscReadCadenceTimerButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Read Cadence Timer button clicked for module {0}",
            unit->moduleSerialNumber);
        DWORD status = QD_GetCadenceTimer(
            unit->unitHandle,
            (LPDWORD) &cadenceTimer);
        if (status == QD_SUCCESS)
        {
            miscGetCadenceTimerBoxArray[unitNumber]->BackColor = Color::Lavender;
            miscGetCadenceTimerBoxArray[unitNumber]->Text = String::Concat(cadenceTimer);
            RecordVerboseEvent(
                "    Cadence Timer = {0} ms",
                miscGetCadenceTimerBoxArray[unitNumber]->Text);
        }
        else
        {
            miscGetCadenceTimerBoxArray[unitNumber]->BackColor = Color::Orange;
            miscGetCadenceTimerBoxArray[unitNumber]->Text = String::Format(
                "0x{0:X2}", (status & 0xFF));
            RecordErrorEvent(
                "    QD_GetCadenceTimer returned status 0x{0:X8}", status);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscReadCadenceTimerButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscReadErrorCodeButtonClicked
//
// Handles the click of the Read Error Code button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscReadErrorCodeButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    WORD            errorCode = 0;
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscReadErrorCodeButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Read Error Code button clicked for module {0}",
            unit->moduleSerialNumber);
        DWORD status = QD_GetInternalErrorCode(
            unit->unitHandle,
            (LPWORD) &errorCode);
        if (status == QD_SUCCESS)
        {
            miscGetErrorCodeBoxArray[unitNumber]->BackColor = Color::Lavender;
            miscGetErrorCodeBoxArray[unitNumber]->Text = String::Format(
                "0x{0:X4}", errorCode);
            RecordVerboseEvent(
                "    Error code = {0}",
                miscGetErrorCodeBoxArray[unitNumber]->Text);
        }
        else
        {
            miscGetErrorCodeBoxArray[unitNumber]->BackColor = Color::Orange;
            miscGetErrorCodeBoxArray[unitNumber]->Text = String::Format(
                "0x{0:X2}", (status & 0xFF));
            RecordErrorEvent(
                "    QD_GetInternalErrorCode returned status 0x{0:X8}", status);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscReadErrorCodeButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscReadModuleSerialNumberButtonClicked
//
// Handles the click of the Read Module Serial Number button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscReadModuleSerialNumberButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    char            *moduleSerialNumber;
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscReadModuleSerialNumberButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Read Unit Serial Number button clicked for module {0}",
            unit->moduleSerialNumber);
        moduleSerialNumber = (char *) malloc(QCOM_MAXIMUM_FILE_PATH_LENGTH);
        if (moduleSerialNumber)
        {
            QCOM_ConvertString(
                unit->moduleSerialNumber,
                moduleSerialNumber,
                QCOM_MAXIMUM_FILE_PATH_LENGTH);
            DWORD status = QD_GetModuleSerialNumber(
                unit->physicalUnitNumber,
                (LPBYTE) moduleSerialNumber);
            if (status == QD_SUCCESS)
            {
                miscGetModuleSerialNumberBoxArray[unitNumber]->BackColor = Color::Lavender;
                miscGetModuleSerialNumberBoxArray[unitNumber]->Text =
                    unit->moduleSerialNumber;
                RecordVerboseEvent(
                    "    Unit Serial Number = {0}",
                    miscGetModuleSerialNumberBoxArray[unitNumber]->Text);
            }
            else
            {
                miscGetModuleSerialNumberBoxArray[unitNumber]->BackColor = Color::Orange;
                miscGetModuleSerialNumberBoxArray[unitNumber]->Text = String::Format(
                    "0x{0:X8}", status);
                RecordErrorEvent(
                    "    QD_GetModuleSerialNumber returned status 0x{0:X8}", status);
            }
            free((void *) moduleSerialNumber);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscReadModuleSerialNumberButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscReadXDMemoryButtonClicked
//
// Handles the click of the Read Transducer Coefficients button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscReadXDMemoryButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscReadXDMemoryButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Read Unit Serial Number button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_MiscCopyXDMemoryToModule(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscReadXDMemoryButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscSendI2CCommandButtonClicked
//
// Handles the click of the Send I2C Command button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscSendI2CCommandButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscSendI2CCommandButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Send I2C Command button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_MiscSendI2CCommand(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscSendI2CCommandButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscSetCadenceTimerButtonClicked
//
// Handles the click of the Set Cadence Timer button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscSetCadenceTimerButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscSetCadenceTimerButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Set Cadence Timer button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_MiscSetAndPostCadenceTimer(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscSetCadenceTimerButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscSetControlRegisterButtonClicked
//
// Handles the click of the Set Control Register button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscSetControlRegisterButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscSetControlRegisterButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Set Control Register button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_MiscSetAndPostControlRegister(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscSetControlRegisterButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscSetI2CDataRateButtonClicked
//
// Handles the click of the Set Data Rate button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscSetI2CDataRateButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscSetI2CDataRateButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Set I2C Data Rate button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_MiscSetAndPostI2CDataRate(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscSetI2CDataRateButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscSetTimeoutsButtonClicked
//
// Handles the click of the Set Timeouts button
//
// Called by:   QCOM_MiscSetUpControls
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscSetTimeoutsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Misc Set Timeouts button clicked");
    QCOM_MiscSetAndPostTimeouts();
}                                       // end of QCOM_MiscSetTimeoutsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscToggleTransducerTypeButtonClicked
//
// Handles the click of the Toggle Transducer Type button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscToggleTransducerTypeButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscToggleTransducerTypeButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Toggle Transducer Type button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_MiscToggleTransducerType(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscToggleTransducerTypeButtonClicked()
//----------------------------------------------------------------------------
// QCOM_MiscValidateI2CDataRateBox
//
// Validates the value of the I2C Data Rate text box entry
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscValidateI2CDataRateBox(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    double          newDataRate;
    DWORD           unitNumber = (DWORD) (dynamic_cast <TextBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscValidateI2CDataRateBox");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if (StringSet(miscGetDataRateBoxArray[unitNumber]->Text))
        {
            // TODO: must test for numeric value, or this will crash
            newDataRate = Convert::ToDouble(miscGetDataRateBoxArray[unitNumber]->Text);
            if (newDataRate != unit->dataRate)
            {
                if ((newDataRate < QD_MINIMUM_I2C_DATA_RATE) ||
                    (newDataRate > QD_MAXIMUM_I2C_DATA_RATE))
                {
                    GUI_DisplayMandatoryError(functionName,
                        "Valid values are {0:F2} through {1:F2}, inclusive",
                        QD_MINIMUM_I2C_DATA_RATE,
                        QD_MAXIMUM_I2C_DATA_RATE);
                    QCOM_MiscGetAndPostI2CDataRate(unit);
                }
                else
                {
                    QCOM_MiscSetAndPostI2CDataRate(unit);
                    evt->Cancel = GUI_NO;
                    return;
                }
            }
            else
            {
                evt->Cancel = GUI_NO;
                return;
            }
        }
        else
        {
            QCOM_MiscGetAndPostI2CDataRate(unit);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
    evt->Cancel = GUI_YES;
}                                       // end of QCOM_MiscValidateI2CDataRateBox()
//----------------------------------------------------------------------------
// QCOM_MiscWriteXDMemoryButtonClicked
//
// Handles the click of the Write Transducer Coefficients button
//
// Called by:   QCOM_MiscConstructUnitControlTab
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MiscWriteXDMemoryButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MiscWriteXDMemoryButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Misc Write Transducer Coefficients button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_MiscCopyModuleMemoryToXD(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_MiscWriteXDMemoryButtonClicked()
//----------------------------------------------------------------------------
// QCOM_ProgramInformationCloseWindow
//
// Event that closes the program infomation display window
//
// Called by:   QCOM_ProgramInformationDisplayWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ProgramInformationCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Program Info window closed");
    programInfoWindow->Close();
}                                       // end of QCOM_ProgramInformationCloseWindow()
//----------------------------------------------------------------------------
#endif      // MISCEVENTS_CPP
//============================================================================
// End of MiscEvents.cpp
//============================================================================
