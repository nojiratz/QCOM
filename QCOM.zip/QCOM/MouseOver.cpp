//============================================================================
// MouseOver.cpp
//
// The registered mouse-over and mouse-exit event methods
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     MOUSEOVER_CPP
#define     MOUSEOVER_CPP
#include    "MouseOver.h"
//----------------------------------------------------------------------------
// QCOM_AnyObjectMouseExited
//
// Handles mousing away from any object
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_AnyObjectMouseExited(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("QCOM Ready");
}                                       // end of QCOM_AnyObjectMouseExited()
//----------------------------------------------------------------------------
// QCOM_EmailMessageCloseButtonMouseEntered
//
// Handles the mouse entering the Close Email button
//
// Called by:   QCOM_GenerateSupportLog
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_EmailMessageCloseButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Closes the email dialogue");
}                                       // end of QCOM_EmailMessageCloseButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_EmailMessageSendButtonMouseEntered
//
// Handles the mouse entering the Send Email button
//
// Called by:   QCOM_GenerateSupportLog
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_EmailMessageSendButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Sends an email message to Quartzdyne Support with the Support Log attached");
}                                       // end of QCOM_EmailMessageSendButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertBasicMessagesCheckMouseEntered
//
// Handles the mouse entering the expert Basic Messages check
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertBasicMessagesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Enables basic (normal and usual) modal messages");
}                                       // end of QCOM_ExpertBasicMessagesCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertDetailedMessagesCheckMouseEntered
//
// Handles the mouse entering the expert Detailed Messages check
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertDetailedMessagesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Enables all types of modal messages");
}                                       // end of QCOM_ExpertDetailedMessagesCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertDisplayCoefficientDataButtonMouseEntered
//
// Handles the mouse entering the Display Coefficient button
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertDisplayCoefficientDataButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^unitString;
    String          ^functionName = _T("QCOM_ExpertDisplayCoefficientDataButtonMouseEntered");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if (QCOM_XDSNValid(unit))
            unitString = String::Concat("transducer ", unit->transducerSerialNumber);
        else
            unitString = String::Concat("module ", unit->moduleSerialNumber);
        QCOM_DisplayStatusLine(
            "Displays the currently loaded coefficient data for {0} in a human-readable format",
            unitString);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
    delete unitString;
}                                       // end of QCOM_ExpertDisplayCoefficientDataButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertDLLMessagesCheckMouseEntered
//
// Handles the mouse entering the expert DLL Messages check
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertDLLMessagesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Enables modal error messages that originate from the DLL (a popup displays the message when an error occurs)");
}                                       // end of QCOM_ExpertDLLMessagesCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertEmailMessageCCAddressBoxMouseEntered
//
// Handles the mouse entering the expert Send Text CC Number text box
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertEmailMessageCCAddressBoxMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Email address to CC a message when an event requires it");
}                                       // end of QCOM_ExpertEmailMessageCCAddressBoxMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertEmailMessageToAddressBoxMouseEntered
//
// Handles the mouse entering the expert Send Text To Address text box
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertEmailMessageToAddressBoxMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Email address to send a message when an event requires it");
}                                       // end of QCOM_ExpertEmailMessageToAddressBoxMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertEraseCoefficientDataButtonMouseEntered
//
// Handles the mouse entering the Erase Coefficient button
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertEraseCoefficientDataButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Erases all four copies of the coefficient data stored in ", MSN));
    delete MSN;
}                                       // end of QCOM_ExpertEraseCoefficientDataButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertErrorMessagesCheckMouseEntered
//
// Handles the mouse entering the expert Error Messages check
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertErrorMessagesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Enables error modal messages (a popup displays the message when an error occurs)");
}                                       // end of QCOM_ExpertErrorMessagesCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertExperimentalButtonMouseEntered
//
// Handles the mouse entering the expert Experimental button
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertExperimentalButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Runs an experimental exercise");
}                                       // end of QCOM_ExpertExperimentalButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertExperimentsAreaMouseEntered
//
// Handles the mouse entering the expert Experiments area
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertExperimentsAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays the button to run custom experiments and the text entry for the experiment number");
}                                       // end of QCOM_ExpertExperimentsAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertExpMessagesCheckMouseEntered
//
// Handles the mouse entering the expert Experimental Messages check
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertExpMessagesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Enables experimental modal messages");
}                                       // end of QCOM_ExpertExpMessagesCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertHaltOperationsOnErrorsCheckMouseEntered
//
// Handles the mouse entering the expert Halt Operations on Errors check
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertHaltOperationsOnErrorsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Stops all sampling, logging, and testing if an error is encountered");
}                                       // end of QCOM_ExpertHaltOperationsOnErrorsCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertManageMultipleCoefficientDataButtonMouseEntered
//
// Handles the mouse entering the expert Manage Multiple Coefficient Storage
// button
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertManageMultipleCoefficientDataButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        String ^SNs = String::Concat("module ", unit->moduleSerialNumber);
        if (QCOM_XDPresent(unit) && QCOM_XDSNValid(unit) &&
            !QCOM_XDIsFrequency(unit) && !QCOM_XDIsDigitalNoMem(unit))
        {
            SNs = String::Concat(SNs, " and transducer ", unit->transducerSerialNumber);
        }
        QCOM_UpdateStatusLine(String::Concat("Manages multiple coefficient data storage on ", SNs));
        delete SNs;
    }
}                                       // end of QCOM_ExpertManageMultipleCoefficientDataButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertMiscButtonMouseEntered
//
// Handles the mouse entering the expert Misc Controls button
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertMiscButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays a new window that presents a variety of technical information and advanced controls");
}                                       // end of QCOM_ExpertMiscButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertPerformExperimentsButtonMouseEntered
//
// Handles the mouse entering the expert Experiments button
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertPerformExperimentsButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Runs custom experiments");
}                                       // end of QCOM_ExpertPerformExperimentsButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertProgramInfoButtonMouseEntered
//
// Handles the mouse entering the expert Program Info button
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertProgramInfoButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays a new window that presents current conditions, settings, and a variety of other technical program information");
}                                       // end of QCOM_ExpertProgramInfoButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertProgramIntervalCheckMouseEntered
//
// Handles the mouse entering the expert Enable Program Poller checkbox
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertProgramIntervalCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Enables the program poller for hardware change detection");
}                                       // end of QCOM_ExpertProgramIntervalCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertProgramIntervalMouseEntered
//
// Handles the mouse entering the expert Program Interval area
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertProgramIntervalMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Specifies the number of milliseconds between times when the program poller can perform hardware change detection");
}                                       // end of QCOM_ExpertProgramIntervalMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertRealTimeWeightDemoButtonMouseEntered
//
// Handles the mouse entering the expert Weight Demo button
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertRealTimeWeightDemoButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays a new window that presents weight display controls");
}                                       // end of QCOM_ExpertRealTimeWeightDemoButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertResetAllMessagesButtonMouseEntered
//
// Handles the mouse entering the expert Reset All Messages button
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertResetAllMessagesButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Resets (disables) all modal messages");
}                                       // end of QCOM_ExpertResetAllMessagesButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertSendAllTransducerReadingsAreaMouseEntered
//
// Handles the mouse entering the Send Transducer Readings area
//
// Called by:   QCOM_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertSendAllTransducerReadingsAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_UpdateStatusLine(
        "Emails / texts readings (only pressure and temperature) for all "
        "transducers at their specified intervals");
}                                       // end of QCOM_ExpertSendAllTransducerReadingsAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertSendEmailErrorMessageCheckMouseEntered
//
// Handles the mouse entering the expert Send Email Message on Errors button
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertSendEmailErrorMessageCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Sends email messages when the program encounters an error");
}                                       // end of QCOM_ExpertSendEmailErrorMessageCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertSendTextErrorMessageCheckMouseEntered
//
// Handles the mouse entering the expert Send Text Message on Errors button
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertSendTextErrorMessageCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Sends text messages when the program encounters an error");
}                                       // end of QCOM_ExpertSendTextErrorMessageCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertStackTraceCheckMouseEntered
//
// Handles the mouse entering the expert Display Stack Trace on Error checkbox
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertStackTraceCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays a stack trace along with the error message when an error is encountered");
}                                       // end of QCOM_ExpertStackTraceCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertTextMessageCCNumberBoxMouseEntered
//
// Handles the mouse entering the expert Send Text CC Number text box
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertTextMessageCCNumberBoxMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Ten-digit phone number to CC a text message when an event requires it");
}                                       // end of QCOM_ExpertTextMessageCCNumberBoxMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertTextMessageToNumberBoxMouseEntered
//
// Handles the mouse entering the expert Send Text To Number text box
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertTextMessageToNumberBoxMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Ten-digit phone number to send a text message when an event requires it");
}                                       // end of QCOM_ExpertTextMessageToNumberBoxMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertUnitSendTransducerReadingsAreaMouseEntered
//
// Handles the mouse entering the unit Send Transducer Readings check
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertUnitSendTransducerReadingsAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_UpdateStatusLine(
        "Emails / texts readings (only pressure and temperature) for this "
        "transducer at the specified interval");
}                                       // end of QCOM_ExpertUnitSendTransducerReadingsAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertUnitTransducerPowerButtonMouseEntered
//
// Handles the mouse entering the unit Transducer Power button
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertUnitTransducerPowerButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^TSN = _T("this transducer");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if (QCOM_XDSNValid(unit))
            TSN = String::Concat("transducer ", unit->transducerSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Enables / disables power supplied to ", TSN));
    delete TSN;
}                                       // end of QCOM_ExpertUnitTransducerPowerButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ExpertVerboseMessagesCheckMouseEntered
//
// Handles the mouse entering the expert Verbose Messages check
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ExpertVerboseMessagesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Enables verbose modal messages");
}                                       // end of QCOM_ExpertVerboseMessagesCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_HelpAboutQuartzdyneLogoMouseEntered
//
// Handles the mouse entering the Quartzdyne Logo image
//
// Called by:   QCOM_DisplayHelpLink (QCOM_AboutHelp)
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_HelpAboutQuartzdyneLogoMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Opens the browser to the Quartzdyne home page");
}                                       // end of QCOM_HelpAboutQuartzdyneLogoMouseEntered()
//----------------------------------------------------------------------------
// QCOM_HelpAboutSoftwareLogoMouseEntered
//
// Handles the mouse entering the Software Logo image
//
// Called by:   QCOM_AboutHelp
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_HelpAboutSoftwareLogoMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Opens the browser to the QCOM Help page");
}                                       // end of QCOM_HelpAboutSoftwareLogoMouseEntered()
//----------------------------------------------------------------------------
// QCOM_HomeExitButtonMouseEntered
//
// Handles the mouse entering the home Exit button
//
// Called by:   QCOM_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_HomeExitButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Exits the program, with an option to save unsaved logged data and test results if they are present");
}                                       // end of QCOM_HomeExitButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_HomeOpeningBannerMouseEntered
//
// Handles the mouse entering the home opening banner
//
// Called by:   QCOM_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_HomeOpeningBannerMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("The number of physical QCOM modules and Quartzdyne transducers detected");
}                                       // end of QCOM_HomeOpeningBannerMouseEntered()
//----------------------------------------------------------------------------
// QCOM_HomeTabMouseEntered
//
// Handles the mouse entering one of the home tabs
//
// Called by:   QCOM_ConstructHomeTabPages
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_HomeTabMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Select a tab for your desired set of functions");
}                                       // end of QCOM_HomeTabMouseEntered()
//----------------------------------------------------------------------------
// QCOM_HomeWindowEntered
//
// Handles mousing over the home window
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_HomeWindowEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           oneValue = 1;
    //------------------------------------------------------------------------
    this->Tag = oneValue;
}                                       // end of QCOM_HomeWindowEntered()
//----------------------------------------------------------------------------
// QCOM_HomeWindowExited
//
// Handles mousing away from the home window
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_HomeWindowExited(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           zeroValue = 0;
    //------------------------------------------------------------------------
    this->Tag = zeroValue;
}                                       // end of QCOM_HomeWindowExited()
//----------------------------------------------------------------------------
// QCOM_PauseResumeButtonMouseEntered
//
// Handles the mouse entering the Pause / Resume button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//              QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PauseResumeButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine(String::Concat(
        ((QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED) ? "Resumes" : "Pauses"),
        " active sampling, logging, testing, and graphing for all units"));
}                                       // end of QCOM_PauseResumeButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutAlternatePressureTemperatureRadioMouseEntered
//
// Handles the mouse entering the readout Alternate Pressure and Temperature
// radio button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutAlternatePressureTemperatureRadioMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine(String::Format("Selects the pressure to display in {0} and the temperature to display in {1}",
        QCOM_PressureUnitsStringArray[QCOM_AlternatePressureUnits],
        QCOM_TemperatureUnitsStringArray[QCOM_AlternateTemperatureUnits]));
}                                       // end of QCOM_ReadoutAlternatePressureTemperatureRadioMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutAlternatePressureUnitsAreaMouseEntered
//
// Handles the mouse entering the readout Alternate Pressure Units area
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutAlternatePressureUnitsAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Changes the alternate units of displayed pressure");
}                                       // end of QCOM_ReadoutAlternatePressureUnitsAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutAlternateTemperatureUnitsAreaMouseEntered
//
// Handles the mouse entering the readout Alternate Temperature Units area
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutAlternateTemperatureUnitsAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Changes the alternate units of displayed temperature");
}                                       // end of QCOM_ReadoutAlternateTemperatureUnitsAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutClearAllLogsButtonMouseEntered
//
// Handles the mouse entering the readout Clear All Data Logs button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutClearAllLogsButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Clears (erases) the data logs of all units");
}                                       // end of QCOM_ReadoutClearAllLogsButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutClearUnitLogButtonMouseEntered
//
// Handles the mouse entering the readout Clear Data Log button
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutClearUnitLogButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^TSN = _T("this transducer");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if (QCOM_XDSNValid(unit))
            TSN = String::Concat("transducer ", unit->transducerSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Clears (erases) the data log of ", TSN));
    delete TSN;
}                                       // end of QCOM_ReadoutClearUnitLogButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutContinuousSamplingTimeLabelMouseEntered
//
// Handles the mouse entering the Continuous Sampling Time label
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutContinuousSamplingTimeLabelMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("The amount of time the software has been continuously sampling the transducers");
}                                       // end of QCOM_ReadoutContinuousSamplingTimeLabelMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutCountsRadioMouseEntered
//
// Handles the mouse entering the readout Counts radio button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutCountsRadioMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Selects counts to be displayed for the pressure and temperature values");
}                                       // end of QCOM_ReadoutCountsRadioMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutDefaultPressureTemperatureRadioMouseEntered
//
// Handles the mouse entering the readout Default Pressure and Temperature
// radio button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDefaultPressureTemperatureRadioMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine(
        String::Format("Selects the pressure to display in {0} and the temperature to display in {1}",
            QCOM_PressureUnitsStringArray[QCOM_DefaultPressureUnits],
            QCOM_TemperatureUnitsStringArray[QCOM_DefaultTemperatureUnits]));
}                                       // end of QCOM_ReadoutDefaultPressureTemperatureRadioMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutDisplayAllFrequenciesCheckMouseEntered
//
// Handles the mouse entering the readout Display All Frequencies check
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDisplayAllFrequenciesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays the pressure and temperature frequency measurements for all transducers");
}                                       // end of QCOM_ReadoutDisplayAllFrequenciesCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutDisplayAllVIValuesCheckMouseEntered
//
// Handles the mouse entering the readout Display All V/I Values check
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDisplayAllVIValuesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays the voltage and current measurements for all transducers");
}                                       // end of QCOM_ReadoutDisplayAllVIValuesCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutDisplayUnitFrequenciesCheckMouseEntered
//
// Handles the mouse entering the readout Display Frequencies check
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDisplayUnitFrequenciesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^TSN = _T("this transducer");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if (QCOM_XDSNValid(unit))
            TSN = String::Concat("transducer ", unit->transducerSerialNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat(
            "Displays the pressure and temperature frequency measurements for ",
            TSN));
    delete TSN;
}                                       // end of QCOM_ReadoutDisplayUnitFrequenciesCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutDisplayUnitGraphButtonMouseEntered
//
// Handles the mouse entering the readout Display Graph button
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDisplayUnitGraphButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_UpdateStatusLine(
            String::Concat(
                "Displays the data graphing window for transducer ",
                unit->transducerSerialNumber,
                " on module ",
                unit->moduleSerialNumber));
    }
}                                       // end of QCOM_ReadoutDisplayUnitGraphButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutDisplayUnitVIValuesCheckMouseEntered
//
// Handles the mouse entering the readout Display V/I Values check
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDisplayUnitVIValuesCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^TSN = _T("this transducer");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if (QCOM_XDSNValid(unit))
            TSN = String::Concat("transducer ", unit->transducerSerialNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat(
            "Displays the voltage and current measurements for ", TSN));
    delete TSN;
}                                       // end of QCOM_ReadoutDisplayUnitVIValuesCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutFirmwareInfoLabelMouseEntered
//
// Handles the mouse entering the readout Firmware ID label
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutFirmwareInfoLabelMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Label ^> (sender))->Tag;
    String          ^MSN = _T("this module");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Firmware ID of ", MSN));
    delete MSN;
}                                       // end of QCOM_ReadoutFirmwareInfoLabelMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutHexCheckMouseEntered
//
// Handles the mouse entering the readout Counts Hex check
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutHexCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine(
        "Check to display the pressure and temperature counts in hexadecimal; uncheck for decimal");
}                                       // end of QCOM_ReadoutHexCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutIncludeAllInSamplingCheckMouseEntered
//
// Handles the mouse entering the readout Include All In Sampling check
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutIncludeAllInSamplingCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Includes all units when sampling and logging are started");
}                                       // end of QCOM_ReadoutIncludeAllInSamplingCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutIncludeUnitInSamplingCheckMouseEntered
//
// Handles the mouse entering the readout Include In Sampling check
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutIncludeUnitInSamplingCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this unit");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("unit ", unitNumber);
        if (QCOM_ModuleSNValid(unit) || QCOM_XDSNValid(unit))
        {
            MSN = String::Concat(
                MSN,
                " (",
                (QCOM_ModuleSNValid(unit) ? "module " : ""),
                (QCOM_ModuleSNValid(unit) ? unit->moduleSerialNumber : ""),
                ((QCOM_ModuleSNValid(unit) && QCOM_XDSNValid(unit)) ? " and " : ""),
                (QCOM_XDSNValid(unit) ? "S/N " : ""),
                (QCOM_XDSNValid(unit) ? unit->transducerSerialNumber : ""),
                ")");
        }
    }
    QCOM_UpdateStatusLine(
        String::Concat(
            "Includes ",
            MSN,
            " when sampling and logging are started"));
    delete MSN;
}                                       // end of QCOM_ReadoutIncludeUnitInSamplingCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutLimitSamplingTimeAreaMouseEntered
//
// Handles the mouse entering the readout Run Sampling Time ares
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutLimitSamplingTimeAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_DisplayStatusLine(
        "Specify the number of minutes ({0:D} to {1:D}) to run the sampling",
        GUI_MINIMUM_SAMPLING_RUN_TIME_MINUTES,
        GUI_MAXIMUM_SAMPLING_RUN_TIME_MINUTES);
}                                       // end of QCOM_ReadoutLimitSamplingTimeAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutLimitSamplingTimeCheckMouseEntered
//
// Handles the mouse entering the readout Run Sampling Time check
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutLimitSamplingTimeCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine(
        "Check to specify the number of minutes you want to run the sampling; uncheck to hide the minutes and run the sampling indefinitely");
}                                       // end of QCOM_ReadoutLimitSamplingTimeCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutLogUnitStartStopButtonMouseEntered
//
// Handles the mouse entering the readout Start Stop Data Logging button
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutLogUnitStartStopButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_DisplayStatusLine(
            "{0} data logging and sampling on {1}{2}",
            ((unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING) ?
                "Stops" :
                "Starts"),
            (QCOM_XDSNValid(unit) ?
                String::Concat("transducer ", unit->transducerSerialNumber) :
                String::Concat("unit ", unit->moduleSerialNumber)),
            ((unit->flags & QCOM_UNIT_INCLUDE_IN_SAMPLING) ?
                String::Empty :
                _T(" if it was included in sampling")));
    }
}                                       // end of QCOM_ReadoutLogUnitStartStopButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutPrecisionNumericMouseEntered
//
// Handles the mouse entering the Decimal Points objects
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutPrecisionNumericMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Selects the number of decimal points (0 through 7) to display for the pressure and temperature");
}                                       // end of QCOM_ReadoutPrecisionNumericMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutPressureAreaMouseEntered
//
// Handles the mouse entering the readout Pressure area
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutPressureAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Pressure measurement of this transducer");
}                                       // end of QCOM_ReadoutPressureAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutPressureFrequencyMouseEntered
//
// Handles the mouse entering the readout Pressure Frequency area
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutPressureFrequencyMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Pressure frequency measurement of this transducer");
}                                       // end of QCOM_ReadoutPressureFrequencyMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutSamplingIntervalMouseEntered
//
// Handles the mouse entering the readout Sampling Interval objects
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutSamplingIntervalMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    String ^units;
    switch (QCOM_CurrentIntervalUnitsOffset)
    {
        case GUI_INTERVAL_MS_OFFSET : units = _T("milliseconds");
            break;
        case GUI_INTERVAL_SEC_OFFSET : units = _T("seconds");
            break;
        case GUI_INTERVAL_MIN_OFFSET : units = _T("minutes");
            break;
        case GUI_INTERVAL_HR_OFFSET : units = _T("hours");
            break;
        default :
            units = _T("time increments");
            break;
    }
    QCOM_UpdateStatusLine(
        String::Concat(
            "Specifies the number of ",
            units,
            " between transducer samples"));
    delete units;
}                                       // end of QCOM_ReadoutSamplingIntervalMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutStartStopLoggingAllButtonMouseEntered
//
// Handles the mouse entering the readout Start Stop Data Logging button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutStartStopLoggingAllButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine(
        String::Concat(
            ((QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING) ? "Stops" : "Starts"),
            " logging and sampling of all units included in sampling"));
}                                       // end of QCOM_ReadoutStartStopLoggingAllButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutStartStopSamplingButtonMouseEntered
//
// Handles the mouse entering the readout Start Stop Sampling button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutStartStopSamplingButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine(
        String::Concat(
            ((QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING) ?
                "Stops both sampling and logging" :
                "Starts only sampling"),
            " of all units included in sampling"));
}                                       // end of QCOM_ReadoutStartStopSamplingButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutTemperatureAreaMouseEntered
//
// Handles the mouse entering the readout Temperature area
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutTemperatureAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Temperature measurement of this transducer");
}                                       // end of QCOM_ReadoutTemperatureAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutTemperatureFrequencyMouseEntered
//
// Handles the mouse entering the readout Temperature Frequency area
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutTemperatureFrequencyMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Temperature frequency measurement of this transducer");
}                                       // end of QCOM_ReadoutTemperatureFrequencyMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutTransducerAmperageAreaMouseEntered
//
// Handles the mouse entering the readout Transducer Current area
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutTransducerAmperageAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("The transducer current draw");
}                                       // end of QCOM_ReadoutTransducerAmperageAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutTransducerVoltageAreaMouseEntered
//
// Handles the mouse entering the readout Transducer Voltage area
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutTransducerVoltageAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("The transducer voltage drop");
}                                       // end of QCOM_ReadoutTransducerVoltageAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ReadoutUnitStartStopSamplingButtonMouseEntered
//
// Handles the mouse entering the readout unit Start / Stop Sampling button
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutUnitStartStopSamplingButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_DisplayStatusLine(
            "{0} on {1}{2}",
            ((unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING) ?
                "Stops both sampling and logging" :
                "Starts only sampling"),
            (QCOM_XDSNValid(unit) ?
                String::Concat("transducer ", unit->transducerSerialNumber) :
                String::Concat("unit ", unit->moduleSerialNumber)),
            ((unit->flags & QCOM_UNIT_INCLUDE_IN_SAMPLING) ?
                String::Empty :
                _T(" if it was included in sampling")));
    }
}                                       // end of QCOM_ReadoutUnitStartStopSamplingButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestAllAppendResultsCheckMouseEntered
//
// Handles the mouse entering the test Append Test Results button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllAppendResultsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Check to append the current test results onto past results for all units; uncheck to over-write");
}                                       // end of QCOM_TestAllAppendResultsCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestAllAutoSaveResultsCheckMouseEntered
//
// Handles the mouse entering the test Auto-save Test Results button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllAutoSaveResultsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Check to have the software automatically save the test results for all units to respective files; uncheck to have it prompt you");
}                                       // end of QCOM_TestAllAutoSaveResultsCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestAllClearResultsButtonMouseEntered
//
// Handles the mouse entering the test Clear All Results button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllClearResultsButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Clears (erases) the test results for all units");
}                                       // end of QCOM_TestAllClearResultsButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestAllDetailedResultsCheckMouseEntered
//
// Handles the mouse entering the test Detail All Results button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllDetailedResultsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Check to display detailed test results for all units; uncheck to display the results summary");
}                                       // end of QCOM_TestAllDetailedResultsCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestAllDisplayResultsCheckMouseEntered
//
// Handles the mouse entering the test Display Test Results button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllDisplayResultsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays the test results for all units");
}                                       // end of QCOM_TestAllDisplayResultsCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestAllDisplayTransducerTestsCheckMouseEntered
//
// Handles the mouse entering the test Display Transducer Tests button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllDisplayTransducerTestsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays the transducer tests for all units");
}                                       // end of QCOM_TestAllDisplayTransducerTestsCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestAllLoopAreaMouseEntered
//
// Handles the mouse entering the test Loop Tests area
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllLoopAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Check to run the selected tests in a loop; uncheck to run them once");
}                                       // end of QCOM_TestAllLoopAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestAllResetTestsButtonMouseEntered
//
// Handles the mouse entering the test Reset All Tests button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllResetTestsButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Resets the tests on all units");
}                                       // end of QCOM_TestAllResetTestsButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestAllSaveResultsButtonMouseEntered
//
// Handles the mouse entering the test Save All Results button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllSaveResultsButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Saves the test results for all units");
}                                       // end of QCOM_TestAllSaveResultsButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestAllStartStopTestingButtonMouseEntered
//
// Handles the mouse entering the Start All Tests button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//              QCOM_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllStartStopTestingButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine(
        String::Concat(
            ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING) ? "Stops" : "Starts"),
            " testing on all units"));
}                                       // end of QCOM_TestAllStartStopTestingButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestAllStopOnErrorsCheckMouseEntered
//
// Handles the mouse entering the Stop On Errors button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllStopOnErrorsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Stops all testing upon encountering an error on any unit");
}                                       // end of QCOM_TestAllStopOnErrorsCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestAllWrapResultsCheckMouseEntered
//
// Handles the mouse entering the Wrap Test Results button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllWrapResultsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Check to wrap the test results text lines for all units; uncheck to allow them to scroll off the right out of sight");
}                                       // end of QCOM_TestAllWrapResultsCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestClearCommentButtonMouseEntered
//
// Handles the mouse entering the test Clear Comment button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestClearCommentButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Clears (erases) the comment box");
}                                       // end of QCOM_TestClearCommentButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestCommentTimeStampCheckMouseEntered
//
// Handles the mouse entering the test Comment Time Stamp button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestCommentTimeStampCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Prepends the comment with the current date-and-time stamp");
}                                       // end of QCOM_TestCommentTimeStampCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestInsertCommentAreaMouseEntered
//
// Handles the mouse entering the test Insert Comment area
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestInsertCommentAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Inserts a comment into all the test results logs");
}                                       // end of QCOM_TestInsertCommentAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestInsertCommentButtonMouseEntered
//
// Handles the mouse entering the test Add Comment button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestInsertCommentButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Inserts the specified comment into all the test results logs");
}                                       // end of QCOM_TestInsertCommentButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitAllModuleCheckMouseEntered
//
// Handles the mouse entering the unit Test All checkbox
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitAllModuleCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat(
            "Check to select all module (not transducer) tests for ",
            MSN,
            "; uncheck to de-select them all"));
    delete MSN;
}                                       // end of QCOM_TestUnitAllModuleCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitAllTransducerCheckMouseEntered
//
// Handles the mouse entering the unit Test All Transducers checkbox
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitAllTransducerCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^TSN = _T("this transducer");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if (QCOM_XDSNValid(unit))
            TSN = String::Concat("transducer ", unit->transducerSerialNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat(
            "Check to select all transducer tests for ",
            TSN,
            "; uncheck to de-select them all"));
    delete TSN;
}                                       // end of QCOM_TestUnitAllTransducerCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitClearResultsButtonMouseEntered
//
// Handles the mouse entering the unit Clear Test Results button
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitClearResultsButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^unitString = _T("this unit");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        unitString = String::Concat("unit ", unit->unitNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat("Clears (erases) the test results for ", unitString));
    delete unitString;
}                                       // end of QCOM_TestUnitClearResultsButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitDetailedResultsCheckMouseEntered
//
// Handles the mouse entering the unit Detailed Results checkbox
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitDetailedResultsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^unitString = _T("this unit");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        unitString = String::Concat("unit ", unit->unitNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat(
            "Check to display detailed test results for ",
            unitString,
            "; uncheck to display the results summary"));
    delete unitString;
}                                       // end of QCOM_TestUnitDetailedResultsCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitFirmwareCheckMouseEntered
//
// Handles the mouse entering the unit Firmware Test checkbox
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitFirmwareCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Selects the Firmware Test for ", MSN));
    delete MSN;
}                                       // end of QCOM_TestUnitFirmwareCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitI2CCheckMouseEntered
//
// Handles the mouse entering the unit I2C Test checkbox
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitI2CCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Selects the I�C Test for ", MSN));
    delete MSN;
}                                       // end of QCOM_TestUnitI2CCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitPassCountLabelMouseEntered
//
// Handles the mouse entering the unit Pass Count label
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitPassCountLabelMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Label ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^unitString = _T("this unit");
    //------------------------------------------------------------------------
    unitNumber &= 0x0000000F;
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        unitString = String::Concat("unit ", unit->unitNumber);
    }
    QCOM_UpdateStatusLine(String::Format("The current loop number {0} is testing", unitString));
    delete unitString;
}                                       // end of QCOM_TestUnitPassCountLabelMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitProgressBarAreaMouseEntered
//
// Handles the mouse entering the unit Progress Bar area
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitProgressBarAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("The progress percent completion of all selected tests for this unit");
}                                       // end of QCOM_TestUnitProgressBarAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitQMEMCheckMouseEntered
//
// Handles the mouse entering the unit Test QMEM label
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitQMEMCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Selects the Memory Test for ", MSN));
    delete MSN;
}                                       // end of QCOM_TestUnitQMEMCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitReadingsCheckMouseEntered
//
// Handles the mouse entering the unit Readings Test checkbox
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitReadingsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Selects the Readings Test for ", MSN));
    delete MSN;
}                                       // end of QCOM_TestUnitReadingsCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitResultsBoxMouseEntered
//
// Handles the mouse entering the unit Test Results text box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitResultsBoxMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <RichTextBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^unitString = _T("this unit");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        unitString = String::Concat("unit ", unit->unitNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("The logged test results for ", unitString));
    delete unitString;
}                                       // end of QCOM_TestUnitResultsBoxMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitResultsFileLabelMouseEntered
//
// Handles the mouse entering the unit test results file label
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitResultsFileLabelMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Label ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^unitString = _T("this unit");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        unitString = String::Concat("unit ", unit->unitNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat(
            "The name of the file in which to store the test results for ",
            unitString));
    delete unitString;
}                                       // end of QCOM_TestUnitResultsFileLabelMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitRunningTimeLabelMouseEntered
//
// Handles the mouse entering the unit Running Time label
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitRunningTimeLabelMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Label ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^unitString = _T("this unit");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        unitString = String::Concat("unit ", unit->unitNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat(
            "The amount of time ", unitString, " has been continuously testing"));
    delete unitString;
}                                       // end of QCOM_TestUnitRunningTimeLabelMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitSaveResultsButtonMouseEntered
//
// Handles the mouse entering the unit Save Test Results button
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitSaveResultsButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^unitString = _T("this unit");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        unitString = String::Concat("unit ", unit->unitNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat(
            "Saves the test results for ", unitString, " in the results file"));
    delete unitString;
}                                       // end of QCOM_TestUnitSaveResultsButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitSelectResultsFileButtonMouseEntered
//
// Handles the mouse entering the unit Select Data File button
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitSelectResultsFileButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^unitString = _T("this unit");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        unitString = String::Concat("unit ", unit->unitNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat(
            "Allows you to select or change the name of the file in which to store the test results for ",
            unitString));
    delete unitString;
}                                       // end of QCOM_TestUnitSelectResultsFileButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitStartStopButtonMouseEntered
//
// Handles the mouse entering the unit Start / Stop Tests button
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitStartStopButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^unitString = _T("this unit");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        unitString = String::Concat("unit ", unit->unitNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat(
            ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING) ? "Stops" : "Starts"),
            " testing with the selected tests on ",
            unitString));
    delete unitString;
}                                       // end of QCOM_TestUnitStartStopButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitStateAreaMouseEntered
//
// Handles the mouse entering the unit Test State area
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitStateAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("The current or final test state or result of running the selected tests on this unit");
}                                       // end of QCOM_TestUnitStateAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitTimeStampResultsCheckMouseEntered
//
// Handles the mouse entering the unit Time Stamp Results checkbox
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitTimeStampResultsCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
//    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    //------------------------------------------------------------------------
    QCOM_UpdateStatusLine(_T("Prepends each line of the test results with a date-and-time stamp"));
}                                       // end of QCOM_TestUnitTimeStampResultsCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitX2CheckMouseEntered
//
// Handles the mouse entering the unit X2 Test checkbox
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitX2CheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Selects the X2 Test for ", MSN));
    delete MSN;
}                                       // end of QCOM_TestUnitX2CheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitX3CheckMouseEntered
//
// Handles the mouse entering the unit X3 Test checkbox
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitX3CheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Selects the X3 Test for ", MSN));
    delete MSN;
}                                       // end of QCOM_TestUnitX3CheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitX4CheckMouseEntered
//
// Handles the mouse entering the unit X4 Test checkbox
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitX4CheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Selects the X4 Test for ", MSN));
    delete MSN;
}                                       // end of QCOM_TestUnitX4CheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitXDCommCheckMouseEntered
//
// Handles the mouse entering the unit Transducer Communications Test checkbox
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitXDCommCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^TSN = _T("this transducer");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        TSN = String::Concat("transducer ", unit->transducerSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Selects the Transducer Communication Test for ", TSN));
    delete TSN;
}                                       // end of QCOM_TestUnitXDCommCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitXDIntegrityCheckMouseEntered
//
// Handles the mouse entering the unit Transducer Integrity Test checkbox
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitXDIntegrityCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^TSN = _T("this transducer");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        TSN = String::Concat("transducer ", unit->transducerSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Selects the Transducer Integrity Test for ", TSN));
    delete TSN;
}                                       // end of QCOM_TestUnitXDIntegrityCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_TestUnitXDMemoryCheckMouseEntered
//
// Handles the mouse entering the unit Transducer Memory Test checkbox
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitXDMemoryCheckMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^TSN = _T("this transducer");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        TSN = String::Concat("transducer ", unit->transducerSerialNumber);
    }
    QCOM_UpdateStatusLine(String::Concat("Selects the Transducer Memory Test for ", TSN));
    delete TSN;
}                                       // end of QCOM_TestUnitXDMemoryCheckMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripAboutDropDownMouseEntered
//
// Handles the mouse entering the About drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripAboutDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays a small popup window that briefly describes the software, its version, and its manufacturer, including links");
}                                       // end of QCOM_ToolStripAboutDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripAdvancedButtonMouseEntered
//
// Handles the mouse entering the area over the Advanced button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripAdvancedButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Presents advanced (expert) functions such as the Program Information window and Miscellaneous Controls window");
    advancedTSDDButton->ShowDropDown();
}                                       // end of QCOM_ToolStripAdvancedButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripAdvancedButtonMouseMoved
//
// Handles the mouse moving over the Advanced button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripAdvancedButtonMouseMoved(
    Object          ^sender,
    MouseEventArgs  ^evt)
{
    int             previousVerticalPosition;
    //------------------------------------------------------------------------
    previousVerticalPosition = (((int) advancedTSDDButton->Tag) & GUI_DROP_DOWN_VERTICAL_POSITION_MASK);
    advancedTSDDButton->Tag = (GUI_DROP_DOWN_CLOSED | evt->Y);
    if ((evt->Y > previousVerticalPosition) && (evt->X < (advancedTSDDButton->Width - 4)))
        advancedTSDDButton->Tag = (GUI_DROP_DOWN_OPENED | evt->Y);
}                                       // end of QCOM_ToolStripAdvancedButtonMouseMoved()
//----------------------------------------------------------------------------
// QCOM_ToolStripButtonsMouseExited
//
// Handles mousing away from any of the tool strip drop down buttons
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripButtonsMouseExited(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_UpdateStatusLine("QCOM Ready");
    if (GUI_DROP_DOWN_CLOSED == (((int) fileTSDDButton->Tag) & GUI_DROP_DOWN_DISPLAY_MASK))
        fileTSDDButton->HideDropDown();
    if (GUI_DROP_DOWN_CLOSED == (((int) functionsTSDDButton->Tag) & GUI_DROP_DOWN_DISPLAY_MASK))
        functionsTSDDButton->HideDropDown();
    if (GUI_DROP_DOWN_CLOSED == (((int) helpTSDDButton->Tag) & GUI_DROP_DOWN_DISPLAY_MASK))
        helpTSDDButton->HideDropDown();
    if (GUI_DROP_DOWN_CLOSED == (((int) advancedTSDDButton->Tag) & GUI_DROP_DOWN_DISPLAY_MASK))
        advancedTSDDButton->HideDropDown();
}                                       // end of QCOM_ToolStripButtonsMouseExited()
//----------------------------------------------------------------------------
// QCOM_ToolStripCheckForUpdateDropDownMouseEntered
//
// Handles the mouse entering the Check for Update drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripCheckForUpdateDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Checks online whether an update to the QCOM software, firmware, and DLL are available, then performs the update if they are");
}                                       // end of QCOM_ToolStripCheckForUpdateDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripConfigFileSaveDontSaveAreaMouseEntered
//
// Handles the mouse entering the Save Config File area
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripConfigFileSaveDontSaveAreaMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DONT_SAVE)
        QCOM_UpdateStatusLine("Allows the software to save the config file when you exit the program");
    else
        QCOM_UpdateStatusLine("Prevents saving the config file when you exit the program");
}                                       // end of QCOM_ToolStripConfigFileSaveDontSaveAreaMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteAllDataCSVFilesDropDownMouseEntered
//
// Handles mousing over the Delete All Data CSV Files drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteAllDataCSVFilesDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Delete all data .csv files in the QLog folder created by sampling and logging");
}                                       // end of QCOM_ToolStripDeleteAllDataCSVFilesDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteAllDataLogFilesDropDownMouseEntered
//
// Handles mousing over the Delete All Data Log Files drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteAllDataLogFilesDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Delete all data log files in the QLog folder created by sampling and logging");
}                                       // end of QCOM_ToolStripDeleteAllDataLogFilesDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteAllErrorLogFilesDropDownMouseEntered
//
// Handles mousing over the Delete All Error Log Files drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteAllErrorLogFilesDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Delete all error log files in the QLog folder except the current file");
}                                       // end of QCOM_ToolStripDeleteAllErrorLogFilesDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteAllEventLogFilesDropDownMouseEntered
//
// Handles mousing over the Delete All Event Log Files drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteAllEventLogFilesDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Delete all event log files in the QLog folder");
}                                       // end of QCOM_ToolStripDeleteAllEventLogFilesDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteAllLogFilesDropDownMouseEntered
//
// Handles mousing over the Delete All Log Files drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteAllLogFilesDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Delete all data, test, error, and event log files in the QLog folder except the current error log file");
}                                       // end of QCOM_ToolStripDeleteAllLogFilesDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteAllTestResultsFilesDropDownMouseEntered
//
// Handles mousing over the Delete All Test Log Files drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteAllTestResultsFilesDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Delete all test results files in the QLog folder created during testing");
}                                       // end of QCOM_ToolStripDeleteAllTestResultsFilesDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteDropDownMouseEntered
//
// Handles mousing over the Delete Log Files sub-button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Presents the list of Delete Log File functions");
    deleteTSDDButton->ShowDropDown();
}                                       // end of QCOM_ToolStripDeleteDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripDeleteLogFilesMouseExited
//
// Handles mousing away from the Delete Log Files Toolstrip drop-down menus
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDeleteLogFilesMouseExited(
    Object          ^sender,
    EventArgs       ^evt)
{
    deleteTSDDButton->HideDropDown();
    fileTSDDButton->HideDropDown();
    fileTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
}                                       // end of QCOM_ToolStripDeleteLogFilesMouseExited()
//----------------------------------------------------------------------------
// QCOM_ToolStripDisplayEventLogDropDownMouseEntered
//
// Handles the mouse entering the Display Event Log drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDisplayEventLogDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays the most recent event log, if any are present");
}                                       // end of QCOM_ToolStripDisplayEventLogDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripDownloadTheLatestDropDownMouseEntered
//
// Handles the mouse entering the Download the Latest drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDownloadTheLatestDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Downloads the latest version of QCOM software without actually installing the software");
}                                       // end of QCOM_ToolStripDownloadTheLatestDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripDropDownsMouseExited
//
// Handles the event of mousing away from the Toolstrip drop-down menus
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDropDownsMouseExited(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (!deleteTSDDButton->Pressed)
    {
        fileTSDDButton->HideDropDown();
        fileTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    }
    if (!resetTSDDButton->Pressed)
    {
        functionsTSDDButton->HideDropDown();
        functionsTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    }
    helpTSDDButton->HideDropDown();
    helpTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    if (!eventLogRecordingTSDDButton->Pressed)
    {
        advancedTSDDButton->HideDropDown();
        advancedTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
    }
}                                       // end of QCOM_ToolStripDropDownsMouseExited()
//----------------------------------------------------------------------------
// QCOM_ToolStripEventLogAllDropDownMouseEntered
//
// Handles mousing over the Log All Events drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripEventLogAllDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_EventLogBasicEnabled)
        QCOM_UpdateStatusLine("Stops all event log recording");
    else
        QCOM_UpdateStatusLine("Starts logging of all non-test events");
}                                       // end of QCOM_ToolStripEventLogAllDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripEventLogBasicDropDownMouseEntered
//
// Handles mousing over the Log Basic Events drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripEventLogBasicDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_EventLogBasicEnabled)
        QCOM_UpdateStatusLine("Stops all basic event log recording");
    else
        QCOM_UpdateStatusLine("Starts logging of basic events (records the clicks and some responses of software controls and displays)");
}                                       // end of QCOM_ToolStripEventLogBasicDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripEventLogDetailedDropDownMouseEntered
//
// Handles mousing over the Log Detailed Events drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripEventLogDetailedDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_EventLogDetailedEnabled)
        QCOM_UpdateStatusLine("Stops all detailed event log recording");
    else
        QCOM_UpdateStatusLine("Starts logging of detailed events (all events, even ones not necessarily user-controlled)");
}                                       // end of QCOM_ToolStripEventLogDetailedDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripEventLogDropDownMouseEntered
//
// Handles the mouse entering the Event Log drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripEventLogDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Allows you to log mouse clicks and other software events to a file");
    eventLogRecordingTSDDButton->ShowDropDown();
}                                       // end of QCOM_ToolStripEventLogDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripEventLogDropDownMouseExited
//
// Handles mousing away from the Event Log Toolstrip drop-down menus
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripEventLogDropDownMouseExited(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    eventLogRecordingTSDDButton->HideDropDown();
    advancedTSDDButton->HideDropDown();
    advancedTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
}                                       // end of QCOM_ToolStripEventLogDropDownMouseExited()
//----------------------------------------------------------------------------
// QCOM_ToolStripEventLogTestDropDownMouseEntered
//
// Handles mousing over the Log Test Events drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripEventLogTestDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_EventLogTestEnabled)
        QCOM_UpdateStatusLine("Stops all test event log recording");
    else
        QCOM_UpdateStatusLine("Starts logging of events that occur during testing, while the tests are running");
}                                       // end of QCOM_ToolStripEventLogTestDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripEventLogVerboseDropDownMouseEntered
//
// Handles mousing over the Log Verbose Events drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripEventLogVerboseDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_EventLogVerboseEnabled)
        QCOM_UpdateStatusLine("Stops all verbose event log recording");
    else
        QCOM_UpdateStatusLine("Starts logging of most non-test (and not necessarily user-controlled) events");
}                                       // end of QCOM_ToolStripEventLogVerboseDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripExpertModeDropDownMouseEntered
//
// Handles the mouse entering the Expert Mode drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripExpertModeDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE)
        QCOM_UpdateStatusLine("Changes the software back to Normal Mode, and hides the Expert functions");
    else
        QCOM_UpdateStatusLine("Changes the software to Expert Mode, and makes the Expert functions available");
}                                       // end of QCOM_ToolStripExpertModeDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripFileButtonMouseEntered
//
// Handles the mouse entering the area over the File button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripFileButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Presents file-related operations, plus an exit function");
    fileTSDDButton->ShowDropDown();
}                                       // end of QCOM_ToolStripFileButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripFileButtonMouseMoved
//
// Handles the mouse moving over the File button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripFileButtonMouseMoved(
    Object          ^sender,
    MouseEventArgs  ^evt)
{
    int             previousVerticalPosition;
    //------------------------------------------------------------------------
    previousVerticalPosition = (((int) fileTSDDButton->Tag) & GUI_DROP_DOWN_VERTICAL_POSITION_MASK);
    fileTSDDButton->Tag = (GUI_DROP_DOWN_CLOSED | evt->Y);
    if ((evt->Y > previousVerticalPosition) && (evt->X < (fileTSDDButton->Width - 4)))
        fileTSDDButton->Tag = (GUI_DROP_DOWN_OPENED | evt->Y);
}                                       // end of QCOM_ToolStripFileButtonMouseMoved()
//----------------------------------------------------------------------------
// QCOM_ToolStripFunctionsButtonMouseEntered
//
// Handles the mouse entering the area over the Functions button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripFunctionsButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Presents a variety of general control functions, including various reset operations");
    functionsTSDDButton->ShowDropDown();
}                                       // end of QCOM_ToolStripFunctionsButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripFunctionsButtonMouseMoved
//
// Handles the mouse moving over the Functions button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripFunctionsButtonMouseMoved(
    Object          ^sender,
    MouseEventArgs  ^evt)
{
    int             previousVerticalPosition;
    //------------------------------------------------------------------------
    previousVerticalPosition = (((int) functionsTSDDButton->Tag) & GUI_DROP_DOWN_VERTICAL_POSITION_MASK);
    functionsTSDDButton->Tag = (GUI_DROP_DOWN_CLOSED | evt->Y);
    if ((evt->Y > previousVerticalPosition) && (evt->X < (functionsTSDDButton->Width - 4)))
        functionsTSDDButton->Tag = (GUI_DROP_DOWN_OPENED | evt->Y);
}                                       // end of QCOM_ToolStripFunctionsButtonMouseMoved()
//----------------------------------------------------------------------------
// QCOM_ToolStripHelpButtonMouseEntered
//
// Handles the mouse entering the area over the Help button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripHelpButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Presents help functions such as the online user guide and a submittable support log");
    helpTSDDButton->ShowDropDown();
}                                       // end of QCOM_ToolStripHelpButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripHelpButtonMouseMoved
//
// Handles the mouse moving over the Help button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripHelpButtonMouseMoved(
    Object          ^sender,
    MouseEventArgs  ^evt)
{
    int             previousVerticalPosition;
    //------------------------------------------------------------------------
    previousVerticalPosition = (((int) helpTSDDButton->Tag) & GUI_DROP_DOWN_VERTICAL_POSITION_MASK);
    helpTSDDButton->Tag = (GUI_DROP_DOWN_CLOSED | evt->Y);
    if ((evt->Y > previousVerticalPosition) && (evt->X < (helpTSDDButton->Width - 4)))
        helpTSDDButton->Tag = (GUI_DROP_DOWN_OPENED | evt->Y);
}                                       // end of QCOM_ToolStripHelpButtonMouseMoved()
//----------------------------------------------------------------------------
// QCOM_ToolStripLogFilesSaveDropDownMouseEntered
//
// Handles the mouse entering the Save Log Files drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripLogFilesSaveDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DONT_SAVE_ON_EXIT)
        QCOM_UpdateStatusLine("Alllows the software to save unsaved data log and test results files when you exit the program");
    else
        QCOM_UpdateStatusLine("Prevents saving unsaved data log and test results files when you exit the program");
}                                       // end of QCOM_ToolStripLogFilesSaveDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripMiscControlsDropDownMouseEntered
//
// Handles the mouse entering the Misc Controls drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripMiscControlsDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays a new window that presents a variety of technical information and advanced controls");
}                                       // end of QCOM_ToolStripMiscControlsDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripOnlineHelpDropDownMouseEntered
//
// Handles the mouse entering the Online Help drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripOnlineHelpDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Opens the default browser to display the QCOM online help website");
}                                       // end of QCOM_ToolStripOnlineHelpDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripProgInfoDropDownMouseEntered
//
// Handles the mouse entering the Program Info drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripProgInfoDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays a new window that presents current conditions, settings, and a variety of other technical program information");
}                                       // end of QCOM_ToolStripProgInfoDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripRefreshDropDownMouseEntered
//
// Handles the mouse entering the Refresh Displays drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripRefreshDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Refreshes (updates) software displays affected by hardware changes");
}                                       // end of QCOM_ToolStripRefreshDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripReScanDropDownMouseEntered
//
// Handles the mouse entering the ReScan System drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripReScanDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Re-scans the hardware to collect and process changes in configuration");
}                                       // end of QCOM_ToolStripReScanDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripResetAllDropDownMouseEntered
//
// Handles mousing over the Reset All function drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripResetAllDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Resets all the software and hardware to their pre-setting states");
}                                       // end of QCOM_ToolStripResetAllDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripResetAllModulesDropDownMouseEntered
//
// Handles mousing over the Reset All Modules function drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripResetAllModulesDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Resets all attached QCOM modules to their starting states");
}                                       // end of QCOM_ToolStripResetAllModulesDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripResetAllSoftwareDropDownMouseEntered
//
// Handles mousing over the Reset All Software function drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripResetAllSoftwareDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Resets all the software to its pre-setting states");
}                                       // end of QCOM_ToolStripResetAllSoftwareDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripResetAllTransducersDropDownMouseEntered
//
// Handles mousing over the Reset All Transducers function drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripResetAllTransducersDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Resets the FPGSa / EEPROMS (if present) on all attached transducers to their starting states");
}                                       // end of QCOM_ToolStripResetAllTransducersDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripResetDropDownMouseEntered
//
// Handles mousing over the Reset sub-button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripResetDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Presents the list of Reset functions");
    resetTSDDButton->ShowDropDown();
}                                       // end of QCOM_ToolStripResetDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_ToolStripResetFunctionMouseExited
//
// Handles mousing away from the Reset Toolstrip drop-down menus
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripResetFunctionMouseExited(
    Object          ^sender,
    EventArgs       ^evt)
{
    resetTSDDButton->HideDropDown();
    functionsTSDDButton->HideDropDown();
    functionsTSDDButton->Tag = GUI_DROP_DOWN_CLOSED;
}                                       // end of QCOM_ToolStripResetFunctionMouseExited()
//----------------------------------------------------------------------------
// QCOM_ToolStripSupportLogDropDownMouseEntered
//
// Handles the mouse entering the support log drop-down button
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripSupportLogDropDownMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Creates a support log of system, hardware, and program information, including all data logs and test results");
}                                       // end of QCOM_ToolStripSupportLogDropDownMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilConvertNativeCoefficientFileSetButtonMouseEntered
//
// Handles the mouse entering the utilities Convert Native Coefficient File button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertNativeCoefficientFileSetButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Converts a set of native (.crf / .crt) coefficient data files into a hex file");
}                                       // end of QCOM_UtilConvertNativeCoefficientFileSetButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilConvertCSVToDataLogButtonMouseEntered
//
// Handles the mouse entering the utilities Convert CSV to Data Log button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertCSVToDataLogButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Converts a CSV-formatted text file into a new file with a QCOM Data Log format");
}                                       // end of QCOM_UtilConvertCSVToDataLogButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilConvertDataLogToCSVButtonMouseEntered
//
// Handles the mouse entering the utilities Convert Data Log to CSV button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertDataLogToCSVButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Converts a data log text file into a new file with a CSV format");
}                                       // end of QCOM_UtilConvertDataLogToCSVButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilConvertReadingsButtonMouseEntered
//
// Handles the mouse entering the utilities Convert Readings button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertReadingsButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Converts a set of pressure and temperature counts into actual values by way of transducer coefficients");
}                                       // end of QCOM_UtilConvertReadingsButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilDisplayTCCheckButtonMouseEntered
//
// Handles the mouse entering the utilities Transducer Coefficient Check button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilDisplayTCCheckButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    String          ^TSN = _T("the transducer");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
        if (QCOM_XDSNValid(unit))
            TSN = String::Concat("transducer ", unit->transducerSerialNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat(
            "Displays the Transducer Coefficient Check page for ",
            TSN,
            " attached to ",
            MSN));
    delete TSN;
    delete MSN;
}                                       // end of QCOM_UtilDisplayTCCheckButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilDownloadCoefficientFilesButtonMouseEntered
//
// Handles the mouse entering the utilities Download Coefficient Files button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilDownloadCoefficientFilesButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Downloads all available coefficient files for a particular transducer serial number from Quartzdyne's repository");
}                                       // end of QCOM_UtilDownloadCoefficientFilesButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilExportCoefficientDataFileButtonMouseEntered
//
// Handles the mouse entering the utilities Export Coefficient Data File button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilExportCoefficientDataFileButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^TSN = _T("this transducer");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        TSN = String::Concat("transducer ", unit->transducerSerialNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat("Saves the coefficient data for ", TSN, " to a hex file"));
    delete TSN;
}                                       // end of QCOM_UtilExportCoefficientDataFileButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilImportCoefficientDataFileButtonMouseEntered
//
// Handles the mouse entering the utilities Import Coefficient Data File button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilImportCoefficientDataFileButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat("Imports the coefficient data for ", MSN, " from a file"));
    delete MSN;
}                                       // end of QCOM_UtilImportCoefficientDataFileButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilLogAllDisplayButtonMouseEntered
//
// Handles the mouse entering the utilities Log All Units button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilLogAllDisplayButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Presents general data logging controls for all units");
}                                       // end of QCOM_UtilLogAllDisplayButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilLogUnitDisplayButtonMouseEntered
//
// Handles the mouse entering the utilities Log Data button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilLogUnitDisplayButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^TSN = _T("this transducer");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        TSN = String::Concat("transducer ", unit->transducerSerialNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat("Presents detailed data logging controls for ", TSN));
    delete TSN;
}                                       // end of QCOM_UtilLogUnitDisplayButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilResetAllButtonMouseEntered
//
// Handles the mouse entering the utilities Reset All Units button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilResetAllButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Resets all attached modules and transducers");
}                                       // end of QCOM_UtilResetAllButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilResetModuleButtonMouseEntered
//
// Handles the mouse entering the utilities Reset Module button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilResetModuleButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat("Resets ", MSN));
    delete MSN;
}                                       // end of QCOM_UtilResetModuleButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilUnitResetTransducerButtonMouseEntered
//
// Handles the mouse entering the utilities unit Reset Transducer button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilUnitResetTransducerButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    String          ^TSN = _T("the transducer");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
        if (QCOM_XDSNValid(unit))
            TSN = String::Concat("transducer ", unit->transducerSerialNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat("Resets ", TSN, " attached to ", MSN));
    delete TSN;
    delete MSN;
}                                       // end of QCOM_UtilUnitResetTransducerButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilRetrieveCoefficientFileParametersButtonMouseEntered
//
// Handles the mouse entering the utilities Retrieve Coefficient Parameter button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilRetrieveCoefficientFileParametersButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Displays all the parameters in a particular coefficient data file");
}                                       // end of QCOM_UtilRetrieveCoefficientFileParametersButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilUnitUpdateFirmwareButtonMouseEntered
//
// Handles the mouse entering the utilities unit Update Firmware button
//
// Called by:   QCOM_ConstructUnitUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilUnitUpdateFirmwareButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^MSN = _T("this module");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        MSN = String::Concat("module ", unit->moduleSerialNumber);
    }
    QCOM_UpdateStatusLine(
        String::Concat("Updates the firmware of ", MSN));
    delete MSN;
}                                       // end of QCOM_UtilUnitUpdateFirmwareButtonMouseEntered()
//----------------------------------------------------------------------------
// QCOM_UtilVerifyHexFileButtonMouseEntered
//
// Handles the mouse entering the utilities Test Hex File button
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilVerifyHexFileButtonMouseEntered(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_UpdateStatusLine("Tests a hex file for validity and provides an option to correct some errors and save the corrected file");
}                                       // end of QCOM_UtilVerifyHexFileButtonMouseEntered()
//----------------------------------------------------------------------------
#endif      // MOUSEOVER_CPP
//============================================================================
// End of MouseOver.cpp
//============================================================================
