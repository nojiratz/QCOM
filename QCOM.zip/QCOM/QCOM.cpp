//============================================================================
// QCOM.cpp
//
// QCOM transducer communication software
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     QCOM_CPP
#define     QCOM_CPP
#include    "QCOM.h"
//----------------------------------------------------------------------------
// QCOM_Main
//
// Main program entry point (this is the WinMain function)
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    [STAThread] indicates that the program (Windows Forms, in general)
//          uses the single-threaded apartment (STA) model, which is required
//          for several necessary features, including the ShowDialog() method
//          for several classes.
//----------------------------------------------------------------------------
[STAThread]
    int APIENTRY
QCOM_Main(
    HINSTANCE       instanceHandle,
    HINSTANCE       previousInstance,
    LPTSTR          commandLine,
    int             displayMode)        // maximize, minimize, or normal
{
    DWORD           mainStatus = QCOM_SUCCESS;
    HANDLE          mutexHandle;
    //------------------------------------------------------------------------
    UNREFERENCED_PARAMETER(instanceHandle);
    UNREFERENCED_PARAMETER(previousInstance);
    UNREFERENCED_PARAMETER(displayMode);
    QCOM_SetCommandLineFlags(commandLine);
    if (OpenMutex(SYNCHRONIZE, QCOM_YES, QCOM_MUTEX_STRING))
    {
        QCOM_ModalMessage(
            QCOM_YES,
            GUI_MODAL_ICON_CRITICAL,
            "QCOM_Main",
            "QCOM is already running");
    }
    else
    {
        mutexHandle = CreateMutex(NULL, QCOM_YES, QCOM_MUTEX_STRING);
        if (mainStatus == QCOM_SUCCESS)
        {
            //----------------------------------------------------------------
            // Run the entire program from a single Form class
            //----------------------------------------------------------------
            Application::Run(gcnew QCOM_GUIClass);
        }
        ReleaseMutex(mutexHandle);
    }
    return (int) mainStatus;
}                                       // end of QCOM_Main()
//----------------------------------------------------------------------------
// QCOM_CaptureCommandLine
//
// Retrieves the command line, if present
//
// Called by:   QCOM_InitializeQCOM
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_CaptureCommandLine(void)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_ALLOCATED)
    {
        array <String ^> ^parameters = Environment::GetCommandLineArgs();
        if (parameters->Length > 1)
            QCOM_GeneralInfo->commandLine = String::Join(
                QCOM_STRING_SPACE, parameters, 1, (parameters->Length - 1));
        else
            QCOM_GeneralInfo->commandLine = String::Empty;
    }
    else
    {
        QCOM_DisplayModalMessage(
            QCOM_YES,
            GUI_MODAL_ICON_ERROR,
            "QCOM_CaptureCommandLine",
            "Serious: General info not allocated");
    }
}                                       // end of QCOM_CaptureCommandLine()
//----------------------------------------------------------------------------
// QCOM_DriverInstalled
//
// Determines whether the QCOM driver has been installed on the current machine
//
// Returns: true    = The QCOM driver is installed
//          false   = The QCOM driver can't be found or is not installed
//
// Called by:   QCOM_InitializeSoftwareBase
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_DriverInstalled(void)
{
    bool            driverInstalled = QCOM_NO;
    String          ^lineString;
    String          ^pathString;
    StreamReader    ^textReader;
    //------------------------------------------------------------------------
    ModalD("Loc 2.7.1 : Start of QCOM_DriverInstalled");
    for (int infNumber = 0; infNumber < 256; infNumber++)
    {
        pathString = String::Format(
            "C:\\Windows\\inf\\oem{0:D}.inf",
            infNumber);
        if (File::Exists(pathString))
        {
            textReader = File::OpenText(pathString);
            if (textReader)
            {
                lineString = textReader->ReadLine();
                lineString = textReader->ReadLine();
                if (lineString && (lineString->Length >= 10))
                {
                    if (StringICompare(lineString->Substring(2, 8), _T("QCOM.inf")) == 0)
                    {
                        driverInstalled = QCOM_YES;
                    }
                }
                textReader->Close();
            }
        }
        delete pathString;
        if (driverInstalled)
            break;
    }
//    if ((QCOM_WindowsVersion & QCOM_WIN_VER_SERVER_2003) && !driverInstalled)
//        driverInstalled = QCOM_YES;
    ModalD("Loc 2.7.2 : End of QCOM_DriverInstalled and the driver {0} installed",
        (driverInstalled ? "is" : "is not"));
    return driverInstalled;
}                                       // end of QCOM_DriverInstalled()
//----------------------------------------------------------------------------
// QCOM_EnsureMinimumEnvironment
//
// Determines whether the client environment meets the minimum requirements
// necessary for the software to continue
//
// Returns: 0           Success
//          nonzero     Failure
//
// Called by:   QCOM_InitializeSoftwareBase
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_EnsureMinimumEnvironment(void)
{
    DWORD           lowerVersion;
    DWORD           upperVersion;
    DWORD           status = QCOM_SUCCESS;
    String          ^functionName = _T("QCOM_EnsureMinimumEnvironment");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    QCOM_GetOperatingEnvironment();
    //------------------------------------------------------------------------
    // Test for proper coefficient data structure size
    //------------------------------------------------------------------------
    if (sizeof(CoefficientFormatDef) != QD_COEFFICIENT_DATA_SIZE)
    {
        QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
        QCOM_RecordAndModalEventByFlags(
            QCOM_EventLogBasicEnabled,
            QCOM_YES,
            functionName,
            "Data size mismatch...program must exit");
        return QCOM_FAILURE;
    }
    //------------------------------------------------------------------------
    // Test for sufficient client memory (check total memory) [2 GB]
    //------------------------------------------------------------------------
    MEMORYSTATUSEX memory;
    memory.dwLength = sizeof(MEMORYSTATUSEX);
    GlobalMemoryStatusEx(&memory);
    if ((memory.ullTotalPhys / 1000000) < 2000)
    {
        QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
        QCOM_RecordAndModalEventByFlags(
            QCOM_EventLogBasicEnabled,
            QCOM_YES,
            functionName,
            "Insufficient workstation memory (2 GB required)\n\nThe program must exit");
        return QCOM_FAILURE;
    }
    //------------------------------------------------------------------------
    // Test for sufficient client disk drive space (check available disk
    // space) on the current drive [2 GB]
    //------------------------------------------------------------------------
    DriveInfo ^driveInfo = gcnew DriveInfo(Environment::CurrentDirectory);
    if ((driveInfo->AvailableFreeSpace / 1000000) < 2000)
    {
        QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
        QCOM_RecordAndModalEventByFlags(
            QCOM_EventLogBasicEnabled,
            QCOM_YES,
            functionName,
            "Insufficient workstation disk space (2 GB required)\n\nThe program must exit");
        return QCOM_FAILURE;
    }
    //------------------------------------------------------------------------
    // Test the qdUSB.dll version for the minimum
    //------------------------------------------------------------------------
    BYTE currentMajorVersion;
    BYTE currentMinorVersion;
    BYTE currentBuildVersion;
    BYTE minimumMajorVersion = QCOM_MINIMUM_QDUSB_DLL_MAJOR_VERSION;
    BYTE minimumMinorVersion = QCOM_MINIMUM_QDUSB_DLL_MINOR_VERSION;
    BYTE minimumBuildVersion = QCOM_MINIMUM_QDUSB_DLL_BUILD_VERSION;
    status = QD_GetQDDLLVersion(
        (LPBYTE) &currentMajorVersion,
        (LPBYTE) &currentMinorVersion,
        (LPBYTE) &currentBuildVersion);
    if (status == QD_SUCCESS)
    {
        if (((currentMajorVersion << 16) | (currentMinorVersion << 8) | currentBuildVersion) <
            ((minimumMajorVersion << 16) | (minimumMinorVersion << 8) | minimumBuildVersion))
        {
            QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
            QCOM_RecordAndModalEventByFlags(
                QCOM_EventLogBasicEnabled,
                QCOM_YES,
                functionName,
                "The qdUSB.dll version is {0:D}.{1:D}.{2:D} but must be at least {3:D}.{4:D}.{5:D}",
                currentMajorVersion,
                currentMinorVersion,
                currentBuildVersion,
                minimumMajorVersion,
                minimumMinorVersion,
                minimumBuildVersion);
            return QCOM_FAILURE;
        }
        else
        {
            RecordVerboseEvent(
                "    QCOM qdUSB.dll version {0:D}.{1:D}.{2:D} is installed",
                currentMajorVersion,
                currentMinorVersion,
                currentBuildVersion);
        }
    }
    //------------------------------------------------------------------------
    // Check whether the USB driver has been installed
    //------------------------------------------------------------------------
    if (QD_GetUSBDriverVersion(&upperVersion, &lowerVersion) == QCOM_SUCCESS)
    {
        QCOM_GeneralInfo->flags |= QCOM_GENERAL_USB_DRIVER_AVAILABLE;
        RecordVerboseEvent(
            "    QCOM USB driver version {0:X}.{1:X}.{2:X}.{3:X} is installed",
            ((upperVersion >> 16) & 0xFFFF), (upperVersion & 0xFFFF),
            ((lowerVersion >> 16) & 0xFFFF), (lowerVersion & 0xFFFF));
    }
    else
    {
        if (!QCOM_DriverInstalled())
        {
            RecordErrorEvent("QCOM USB driver is not properly installed on this workstation");
        }
    }
    if (QD_GetUSBDLLVersion(&upperVersion, &lowerVersion) == QCOM_SUCCESS)
    {
        QCOM_GeneralInfo->flags |= QCOM_GENERAL_USB_DLL_AVAILABLE;
        RecordVerboseEvent(
            "    QCOM USB software version {0:X}.{1:X}.{2:X}.{3:X} is installed",
            ((upperVersion >> 16) & 0xFFFF), (upperVersion & 0xFFFF),
            ((lowerVersion >> 16) & 0xFFFF), (lowerVersion & 0xFFFF));
    }
    else
    {
        RecordErrorEvent("QCOM USB software is not properly installed on this workstation");
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of QCOM_EnsureMinimumEnvironment()
//----------------------------------------------------------------------------
// QCOM_Finalize
//
// Saves the config data, concludes the running logs, and releases resources
//
// Called by:   QCOM_CheckForCurrentSoftwareVersion
//              QCOM_ShutDownSoftware
//              QCOM_Start
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_Finalize(
    String          ^finalEventEntry)
{
    String          ^functionName = _T("QCOM_Finalize");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    QCOM_SaveConfigData();
    RecordBasicEvent("{0} concluded", functionName);
    QCOM_ConcludeGeneralLogs(finalEventEntry);
    QCOM_FreeGeneralElements();
}                                       // end of QCOM_Finalize()
//----------------------------------------------------------------------------
// QCOM_FreeGeneralElements
//
// Frees the memory previously allocated for all units, and closes all open
// device handles
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_FreeGeneralElements(void)
{
    //------------------------------------------------------------------------
    for each (UnitInfo ^unit in QCOM_UnitInfoArray)
    {
        if (unit->flags & QCOM_UNIT_OPEN)
        {
            QCOM_CloseUnit(unit);
        }
        unit->flags = 0;
        unit->dataLogFlags = 0;
        unit->dataLogPoints = 0;
        unit->testFlags = 0;
    }
    if (QCOM_GeneralInfo)
    {
        delete QCOM_GeneralInfo;
    }
}                                       // end of QCOM_FreeGeneralElements()
//----------------------------------------------------------------------------
// QCOM_InitializeGeneralFields
//
// Initializes the fields of the QCOM_GeneralInfo structure
//
// Called by:   QCOM_InitializeProgramComponents
//              QCOM_ReScanForDevices
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InitializeGeneralFields(void)
{
    String          ^functionName = _T("QCOM_InitializeGeneralFields");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_GeneralInfo)
    {
        QCOM_GeneralInfo->numberOfUnits = 0;
        QCOM_GeneralInfo->numberOfTransducers = 0;
        QCOM_GeneralInfo->validUnitBitMap = 0;
        QCOM_GeneralInfo->readyUnitBitMap = 0;
    }                                   // end of if (QCOM_GeneralInfo)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_InitializeGeneralFields()
//----------------------------------------------------------------------------
// QCOM_InitializeProgramComponents
//
// Initializes fundamental program components
//
// Called by:   QCOM_InitializeQCOM
//
// Note:    This method must be called only once
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InitializeProgramComponents(void)
{
    bool            zeroPointerOnly = QCOM_NO;
    DWORD           maximumNumberOfUnits = 0;
    //------------------------------------------------------------------------
    // Define and populate the GeneralInfo structure
    //------------------------------------------------------------------------
    QCOM_GeneralInfo = gcnew GeneralInfo;
    QCOM_InitializeGeneralFields();
    QCOM_GeneralInfo->flags = QCOM_GENERAL_ALLOCATED | QCOM_GENERAL_INITIAL_SETTINGS;
    QCOM_GeneralInfo->logFlags = QCOM_GENERAL_LOG_INITIAL_SETTINGS;
    QCOM_GeneralInfo->testFlags = QCOM_GENERAL_TEST_INITIAL_SETTINGS;
    QCOM_GeneralInfo->persistentFlags = QCOM_GENERAL_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentLogFlags = QCOM_GENERAL_LOG_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentTestFlags = QCOM_GENERAL_TEST_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentUnitFlags = QCOM_UNIT_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentUnitLogFlags = QCOM_UNIT_LOG_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentUnitLogDataPoints = QCOM_UNIT_LOG_DEFAULT_PERSISTENT_POINTS;
    QCOM_GeneralInfo->persistentUnitTestFlags = QCOM_UNIT_TEST_DEFAULT_PERSISTENT_FLAGS;
    QCOM_GeneralInfo->persistentUnitGraphingFlags = QCOM_UNIT_GRAPH_DEFAULT_PERSISTENT_FLAGS;
    //------------------------------------------------------------------------
    // Initialize general strings
    //------------------------------------------------------------------------
    QCOM_GeneralInfo->commandLine = String::Empty;
    QCOM_GeneralInfo->configFilePath = String::Empty;
    QCOM_GeneralInfo->generalUsePath = String::Empty;
    QCOM_GeneralInfo->logDirectory = String::Empty;
    QCOM_GeneralInfo->errorLogPath = String::Empty;
    QCOM_GeneralInfo->eventLogPath = String::Empty;
    QCOM_GeneralInfo->mostRecentEventLogPath = String::Empty;
    QCOM_GeneralInfo->windowsVersion = String::Empty;
    QCOM_GeneralInfo->emailAddress = String::Empty;
    QCOM_GeneralInfo->textMessageToNumber = String::Empty;
    QCOM_GeneralInfo->textMessageCCNumber = String::Empty;
    QCOM_GeneralInfo->emailMessageToAddress = String::Empty;
    QCOM_GeneralInfo->emailMessageCCAddress = String::Empty;
    QCOM_GeneralInfo->searchString = String::Empty;
    QCOM_GeneralInfo->convertReadingsFilePath = String::Empty;
    //------------------------------------------------------------------------
    // Retrieve the background images and sounds needed for the program
    //------------------------------------------------------------------------
    QCOM_LoadImagesAndSounds();
    //------------------------------------------------------------------------
    // Create, initialize, and display the "Please Wait . . ." window
    //------------------------------------------------------------------------
    QCOM_PleaseWait(GUI_PLEASE_WAIT_INSTALL, nullptr);
    QCOM_PleaseWait(
        GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
        "Searching For Devices");
    //------------------------------------------------------------------------
    // Initialize unit components
    //------------------------------------------------------------------------
    QCOM_UnitInfoArray = gcnew array <UnitInfo ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS + 1);
    QCOM_ModuleTransducerPairArray = gcnew array <ModuleTransducerPair ^> (QCOM_MAXIMUM_NUMBER_OF_UNITS);
    for (DWORD unitNumber = 0; unitNumber <= QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (zeroPointerOnly)
        {
            QCOM_UnitInfoArray[unitNumber] = nullptr;
        }
        else
        {
            UnitInfo ^unit = gcnew UnitInfo;
            QCOM_UnitInfoArray[unitNumber] = unit;
            if (unit)
            {
                //------------------------------------------------------------
                // Unit-related fields
                //------------------------------------------------------------
                unit->unitNumber = unitNumber;
                QCOM_InitializeUnitFields(unit);
                unit->unitSize += QD_FIRMWARE_ID_LENGTH;
                unit->dataLog = gcnew StringBuilder(QCOM_MAXIMUM_DATA_LOG_SIZE);
                unit->dataLogLine = gcnew StringBuilder(QCOM_MAXIMUM_DATA_LOG_LINE_SIZE);
                unit->dataLogDisplay = gcnew StringBuilder(QCOM_MAXIMUM_DATA_LOG_LINE_SIZE);
                unit->dataLogSize = QCOM_MAXIMUM_DATA_LOG_SIZE;
                unit->dataLogRemaining = QCOM_MAXIMUM_DATA_LOG_SIZE;
                unit->dataLogFlags = QCOM_UNIT_LOG_AVAILABLE;
                unit->unitSize += (2 * sizeof(CoefficientFormatDef));
                unit->testSummaryResultsLog = gcnew StringBuilder(QCOM_SUMMARY_TEST_LOG_SIZE);
                unit->testDetailedResultsLog = gcnew StringBuilder(QCOM_DETAILED_TEST_LOG_SIZE);
                unit->testResultsLine = String::Empty;
                unit->testResultsLogHeader = String::Empty;
                unit->testSummaryResultsLogSize = QCOM_SUMMARY_TEST_LOG_SIZE;
                unit->testSummaryResultsLogRemaining = QCOM_SUMMARY_TEST_LOG_SIZE;
                unit->testDetailedResultsLogSize = QCOM_DETAILED_TEST_LOG_SIZE;
                unit->testDetailedResultsLogRemaining = QCOM_DETAILED_TEST_LOG_SIZE;
                unit->testFlags = QCOM_UNIT_TEST_AVAILABLE;
                unit->testFlags |= QCOM_UNIT_TEST_DETAILED_LOG_AVAILABLE;
                unit->graphingFlags = QCOM_UNIT_GRAPH_AVAILABLE;
//        unit->graphingThickLineWidth = QCOM_NO;
//        unit->graphingMilitaryTimeFormat = QCOM_NO;
//        unit->graphingDisplayAmperageDraw = QCOM_NO;
//        unit->graphingPressureTemperatureSuperimposed = QCOM_NO;
                QCOM_ModuleShouldApplyTransducerPower[unitNumber] = GUI_YES;
                maximumNumberOfUnits++;
            }
            else
            {
                //------------------------------------------------------------
                // Omit the break at this point, to proceed and zero out all
                // the remaining unit pointers
                //------------------------------------------------------------
                zeroPointerOnly = QCOM_YES;
            }
        }                               // end of else of if (zeroPointerOnly)
        if (unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS)
        {
            //----------------------------------------------------------------
            // Initialize the module-transducer pair structures
            //----------------------------------------------------------------
            ModuleTransducerPair ^unitPair = gcnew ModuleTransducerPair;
            QCOM_ModuleTransducerPairArray[unitNumber] = unitPair;
            if (unitPair)
            {
                unitPair->currentUnitPair = String::Empty;
                unitPair->currentModuleSerialNumber = String::Empty;
                unitPair->currentTransducerSerialNumber = String::Empty;
                unitPair->newModuleSerialNumber = String::Empty;
                unitPair->newTransducerSerialNumber = String::Empty;
            }
            //----------------------------------------------------------------
            // Initialize the Send Every interval arrays
            //----------------------------------------------------------------
            QCOM_CurrentSendEveryInterval[unitNumber] = GUI_DEFAULT_SEND_EVERY_INTERVAL;
            QCOM_CurrentSendEveryIntervalRemaining[unitNumber] =
                QCOM_CurrentSendEveryInterval[unitNumber];
        }
    }                                   // end of for (DWORD unitNumber = 0; ...)
    QCOM_GeneralInfo->maximumNumberOfUnits = maximumNumberOfUnits;
    //------------------------------------------------------------------------
    // Initialize other components
    //------------------------------------------------------------------------
    QD_DLLStatus = QCOM_SUCCESS;
    QCOM_MonthStringArray = gcnew array <String ^>
        {
            QCOM_STRING_UNKNOWN, _T("Jan"), _T("Feb"), _T("Mar"), _T("Apr"), _T("May"),
            _T("Jun"), _T("Jul"), _T("Aug"), _T("Sep"), _T("Oct"), _T("Nov"), _T("Dec")
        };
}                                       // end of QCOM_InitializeProgramComponents()
//----------------------------------------------------------------------------
// QCOM_InitializeQCOM
//
// Initializes the software and all visible QCOM hardware, and prepares them
// for communication with the host
//
// Returns: 0           Success
//          nonzero     Failure
//
// Called by:   QCOM_Start
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_InitializeQCOM(void)
{
    DWORD           status;
    String          ^functionName = _T("QCOM_InitializeQCOM");
    //------------------------------------------------------------------------
    QCOM_InitializeProgramComponents();
    QCOM_CaptureCommandLine();
    QCOM_StartTime = GetTickCount();
    QCOM_SetBuildNumber();
    ModalD("Loc 2 : Before QCOM_InitializeSoftwareBase");
    //------------------------------------------------------------------------
    // Unable to do much with the hardware until the software is in a
    // known-good state
    //------------------------------------------------------------------------
    status = QCOM_InitializeSoftwareBase();
    ModalD("Loc 3 : QCOM_InitializeSoftwareBase returned status 0x{0:X8}", status);
    if (status == QCOM_SUCCESS)
    {
        //--------------------------------------------------------------------
        // Set the initial QCOM communication timeouts to 1/2 second per Read
        // and Write (D11813 section 3.5)
        //--------------------------------------------------------------------
        QD_SetTimeouts(QCOM_TIMEOUT_500MS, QCOM_TIMEOUT_500MS);
        //--------------------------------------------------------------------
        // The software is fully operational, so check whether the hardware
        // is present
        //--------------------------------------------------------------------
        ModalD("Loc 4 : Between QD_SetTimeouts and QCOM_ScanForDevices");
        QCOM_ScanForDevices();
        ModalD("Loc 5 : Between QCOM_ScanForDevices and QCOM_RetrieveConfigData");
        //--------------------------------------------------------------------
        // Populate the program with configuration information from the
        // the config file, if it is present
        //--------------------------------------------------------------------
        QCOM_RetrieveConfigData();
        ModalD("Loc 6 : After QCOM_RetrieveConfigData");
        if (status == QCOM_SUCCESS)
        {
            RecordBasicEvent("Pre-GUI initialization completed successfully");
        }
        else
        {
            RecordErrorEvent(
                "Pre-GUI initialization completed with status = 0x{0:X8}", status);
        }
        //--------------------------------------------------------------------
        // At this point, the entire QCOM hardware system is considered
        // operational
        //--------------------------------------------------------------------
    }                                   // end of if (status == QCOM_SUCCESS)
    ModalD("Loc 8 : End of {0}, and status = 0x{1:X8}", functionName, status);
    return status;
}                                       // end of QCOM_InitializeQCOM()
//----------------------------------------------------------------------------
// QCOM_InitializeSoftwareBase
//
// Initializes the QCOM foundational software components, and ensures it has
// reached a operating condition sufficient to start the GUI
//
// Returns: 0           Success
//          nonzero     Failure
//
// Called by:   QCOM_InitializeQCOM
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_InitializeSoftwareBase(void)
{
    DWORD           status;
    String          ^functionName = _T("QCOM_InitializeSoftwareBase");
    //------------------------------------------------------------------------
    ModalD("Loc 2.3 : Before QCOM_EstablishErrorLog");
    QCOM_EstablishErrorLog();
    ModalD("Loc 2.4 : Between QCOM_EstablishErrorLog and QCOM_EstablishEventLog");
    QCOM_EstablishEventLog(String::Concat(functionName, " called"));
    ModalD("Loc 2.5 : Between QCOM_EstablishEventLog and QCOM_ProcessCommandLineParameters");
    status = QCOM_ProcessCommandLineParameters();
    ModalD("Loc 2.6 : QCOM_ProcessCommandLineParameters returned status 0x{0:X8}", status);
    if (status == QCOM_SUCCESS)
    {
        //--------------------------------------------------------------------
        // Allow command-line parameters to modify program behavior before
        // testing for conditions that might cause the program to terminate
        //--------------------------------------------------------------------
        if (QCOM_DetailedMessagesEnabled)
        {
            QCOM_VerboseMessagesEnabled = QCOM_YES;
        }
        if (QCOM_VerboseMessagesEnabled)
        {
            QCOM_BasicMessagesEnabled = QCOM_YES;
            QCOM_ErrorMessagesEnabled = QCOM_YES;
        }
        if (QCOM_StackTracesEnabled)
            QCOM_ErrorMessagesEnabled = QCOM_YES;
        //--------------------------------------------------------------------
        // Determine whether the operating environment is suitable for proper
        // software operation by retrieving and recording the qdUSB.dll
        // version, the USB driver version, the Windows version, and other
        // operating environment information
        //--------------------------------------------------------------------
        status = QCOM_EnsureMinimumEnvironment();
        ModalD("Loc 2.7 : QCOM_EnsureMinimumEnvironment returned status 0x{0:X8}", status);
        if (status == QCOM_SUCCESS)
        {
            ModalD("Loc 2.8 : After QCOM_EnsureMinimumEnvironment proved successful");
            //----------------------------------------------------------------
            // At this point, the software is considered fully operational,
            // although no QCOM hardware has been accessed yet
            //----------------------------------------------------------------
            status = QCOM_SUCCESS;
        }                               // end of if (status == QCOM_SUCCESS)
    }
    ModalD("Loc 2.9 : End of {0}, and status = 0x{1:X8}", functionName, status);
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of QCOM_InitializeSoftwareBase()
//----------------------------------------------------------------------------
// QCOM_InitializeUnitFields
//
// Initializes the fields of the QCOM_UnitInfoArray[] structure
//
// Called by:   QCOM_InitializeProgramComponents
//              QCOM_ReScanForDevices
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InitializeUnitFields(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_InitializeUnitFields");
    //------------------------------------------------------------------------
    if (unit)
    {
        DWORD unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Unit-related fields
        //--------------------------------------------------------------------
        unit->stateFlags = QCOM_UNIT_ZERO_FLAG;
        if (QCOM_UnitOpen(unit))
        {
            QCOM_CloseUnit(unit);
        }
        else
        {
            unit->unitHandle = INVALID_HANDLE_VALUE;
        }
        unit->flags = QCOM_UNIT_ALLOCATED;
        if (unitNumber == QCOM_MAXIMUM_NUMBER_OF_UNITS)
        {
            unit->flags |= QCOM_UNIT_VALID;
            unit->moduleSerialNumber = String::Format(
                "QCOM-{0:D}", unit->unitNumber);
            unit->unitDescriptionString = String::Concat(
                _T("Unit "), unit->moduleSerialNumber);
        }
        else
        {
            unit->moduleSerialNumber = String::Empty;
            unit->unitDescriptionString = String::Empty;
        }
        unit->firmwareID = gcnew array <int> (QD_FIRMWARE_ID_LENGTH);
        for (int index = 0; index < QD_FIRMWARE_ID_LENGTH; index++)
        {
            unit->firmwareID[index] = 0;
        }
        unit->firmwareString = String::Empty;
        unit->moduleMemorySize = 0;
        unit->numberOfModuleMemoryPages = 0;
        unit->dataRate = 0.0;
        unit->pressureCount = 0;
        unit->temperatureCount = 0;
        unit->pressureValuePSI = 0.0;
        unit->temperatureValueCelsius = 0.0;
        unit->transducerVoltage = 0.0;
        unit->transducerAmperage = 0.0;
        //--------------------------------------------------------------------
        // Transducer-related fields
        //--------------------------------------------------------------------
        unit->transducerType = QD_TRANSDUCER_TYPE_ABSENT;
        unit->transducerSerialNumber = String::Empty;
        unit->transducerPartNumber = String::Empty;
        unit->transducerChipID = gcnew array <int> (QD_TRANSDUCER_CHIP_ID_LENGTH);
        for (int index = 0; index < QD_TRANSDUCER_CHIP_ID_LENGTH; index++)
        {
            unit->transducerChipID[index] = 0;
        }
        unit->transducerMemorySize = 0;
        unit->numberOfTransducerMemoryPages = 0;
        unit->coefficientFilePath = String::Empty;
        if (!unit->coefficientData)
            unit->coefficientData = (CoefficientFormatDef *) malloc(2 * sizeof(CoefficientFormatDef));
        ClearBuffer(unit->coefficientData, (2 * sizeof(CoefficientFormatDef)));
        //--------------------------------------------------------------------
        // Logging-related fields
        //--------------------------------------------------------------------
        unit->dataLogFilePath = String::Empty;
        unit->dataLogSnapshotFilePath = String::Empty;
        unit->loggingStats = gcnew LoggingStatsInfo;
        //--------------------------------------------------------------------
        // Graphing-related fields
        //--------------------------------------------------------------------
        unit->graphingLeft = GUI_UNIT_GRAPH_BOX_LEFT_MARGIN;
        unit->graphingTimelineTop = GUI_UNIT_GRAPH_TIMELINE_TOP;
        unit->graphingTimelineDrawDot = QCOM_NO;
        unit->graphingGraphChanged = QCOM_YES;
        unit->graphingPointsDisplayed = 0;
        unit->graphingSamplesSinceDisplayedTime = 0;
        unit->graphingPreviousTimeStampMinute = 0;
        unit->graphingPressureKReciprocalDeltaBoundary = 0.0;
        unit->graphingPressureLowBoundaryPSI = QCOM_GRAPH_DEFAULT_PRESSURE_LOW_BOUNDARY_PSI;
        unit->graphingPressureHighBoundaryPSI = QCOM_GRAPH_DEFAULT_PRESSURE_HIGH_BOUNDARY_PSI;
        unit->graphingPressureGraphSize = 0;
        unit->graphingTemperatureKReciprocalDeltaBoundary = 0.0;
        unit->graphingTemperatureLowBoundaryCelsius = QCOM_GRAPH_DEFAULT_TEMPERATURE_LOW_BOUNDARY_C;
        unit->graphingTemperatureHighBoundaryCelsius = QCOM_GRAPH_DEFAULT_TEMPERATURE_HIGH_BOUNDARY_C;
        unit->graphingTemperatureGraphSize = 0;
        unit->graphingAmperageKReciprocalDeltaBoundary = 0.0;
        unit->graphingAmperageLowBoundarymA = QCOM_GRAPH_DEFAULT_AMPERAGE_LOW_BOUNDARY_MA;
        unit->graphingAmperageHighBoundarymA = QCOM_GRAPH_DEFAULT_AMPERAGE_HIGH_BOUNDARY_MA;
        unit->graphingAmperageGraphSize = 0;
        //--------------------------------------------------------------------
        // Testing-related fields
        //--------------------------------------------------------------------
        unit->testResultsFilePath = String::Empty;
        unit->testDataFilePath = String::Empty;
        unit->testFirmwareFilePath = String::Empty;
        unit->testsCompleted = 0;
        unit->testsToComplete = 0;
        unit->testingStats = gcnew TestingStatsInfo;
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (unit)
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_InitializeUnitFields()
//----------------------------------------------------------------------------
// QCOM_PerformCommandLineTasks
//
// Performs non-GUI tasks directed by the command-line parameters not already
// completed during command-line parsing
//
// Called by:   QCOM_Start
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PerformCommandLineTasks(void)
{
    String          ^functionName = _T("QCOM_PerformCommandLineTasks");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_PerformCommandLineTasks()
//----------------------------------------------------------------------------
// QCOM_ProcessCommandLineParameters
//
// Parses the command line for basic acceptability
//
// The following command-line parameters are recognized:
//
//      /h or /help         Brings up the Help page in the default browser
//      /cfg                Loads configuration information on startup (/cfg- prevents)
//      /gui                Presents the graphical user interface (/gui- for command-line only)
//      /evta               Logs all non-test events on startup
//      /evtb               Logs basic events on startup
//      /evtv               Logs verbose events on startup
//      /evtd               Logs detailed events on startup
//      /mb                 Enables 'basic' modal messages on startup (/mb- disables)
//      /me                 Enables 'error' modal messages on startup (/me- disables)
//      /mv                 Enables 'verbose' modal messages on startup (/mv- disables)
//      /md                 Enables 'detailed' modal messages on startup (/md- disables)
//      /ml                 Enables DLL modal messages on startup (/ml- disables)
//      /ms                 Enables error modal stack traces (/ms- disables)
//      /mx                 Enables 'experimental' modal messages on startup (/mx- disables)
//      /m0                 Disables all modal messages on startup
//      /x                  Starts the software in Expert Mode (/x- disables)
//      /?                  Displays the usage window only
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    This function is called at the start of the program, right after
//          the creation of the error and event log files
//
// Called by:   QCOM_InitializeSoftwareBase
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_ProcessCommandLineParameters(void)
{
    bool            displayUsage = QCOM_NO;
    DWORD           status = QCOM_SUCCESS;
    String          ^functionName = _T("QCOM_ProcessCommandLineParameters");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(QCOM_GeneralInfo->commandLine))
    {
        ModalV("Processing command line\n{0}", QCOM_GeneralInfo->commandLine);
        array <Char> ^lineDelimiters = gcnew array <Char> {' '};
        array <String ^> ^parameters = QCOM_GeneralInfo->commandLine->ToLower()->Split(
            lineDelimiters,
            StringSplitOptions::RemoveEmptyEntries);
        //--------------------------------------------------------------------
        // All these parameters are assumed converted to lowercase
        //--------------------------------------------------------------------
        for each (String ^parameter in parameters)
        {
            int index = Array::IndexOf(parameters, parameter);
            if (StringSet(parameter))
            {
                ModalV("Checking parameter {0:D} = {1}", index, parameter);
                //------------------------------------------------------------
                // These are the acceptable command-line parameter prefixes
                //------------------------------------------------------------
                if ((parameter[0] == '/') || (parameter[0] == '-'))
                {
                    String ^optionString = parameter->Substring(1);
                    //--------------------------------------------------------
                    // Handle the multiple-hyphen or multiple-slash
                    // command-line parameter styles
                    //--------------------------------------------------------
                    while ((optionString->Length > 1) &&
                        ((optionString[0] == '/') || (optionString[0] == '-')))
                    {
                        optionString = optionString->Substring(1);
                    }
                    switch (optionString[0])
                    {
                        case 'c' :
                            {
                                if (optionString->Contains("cfg"))
                                {
                                    //----------------------------------------
                                    // Load / don't load the config file
                                    //----------------------------------------
                                    if (StringICompare(optionString, "cfg-"))
                                        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_CONFIG_DONT_LOAD;
                                    else
                                        QCOM_GeneralInfo->flags |= QCOM_GENERAL_CONFIG_DONT_LOAD;
                                }
                                else
                                {
                                    status = QCOM_ERROR_INVALID_PARAMETER;
                                }
                            }
                            break;
                        case 'e' :
                            {
                                if (optionString->Contains("evt"))
                                {
                                    //----------------------------------------
                                    // The corresponding flags have already
                                    // been set by QCOM_SetCommandLineFlags,
                                    // so no need to set them here
                                    //----------------------------------------
                                    if (optionString->Length > 3)
                                    {
                                        switch (optionString[3])
                                        {
                                            case 'a' :
                                                RecordDetailedEvent(
                                                    "    Program command line: {0}",
                                                    QCOM_GeneralInfo->commandLine);
                                                break;
                                            case 'b' :
                                                RecordBasicEvent(
                                                    "    Program command line: {0}",
                                                    QCOM_GeneralInfo->commandLine);
                                                break;
                                            case 'd' :
                                                RecordDetailedEvent(
                                                    "    Program command line: {0}",
                                                    QCOM_GeneralInfo->commandLine);
                                                break;
                                            case 'v' :
                                                RecordVerboseEvent(
                                                    "    Program command line: {0}",
                                                    QCOM_GeneralInfo->commandLine);
                                                break;
                                            default :
                                                status = QCOM_ERROR_INVALID_PARAMETER;
                                                break;
                                        }
                                    }
                                    else
                                    {
                                        RecordBasicEvent(
                                            "    Program command line: {0}",
                                            QCOM_GeneralInfo->commandLine);
                                    }
                                }
                                else
                                {
                                    status = QCOM_ERROR_INVALID_PARAMETER;
                                }
                            }           // end of case 'e'
                            break;
                        case 'g' :
                            {
                                if (optionString->Contains("gui"))
                                {
                                    //----------------------------------------
                                    // Run / don't run the GUI
                                    //----------------------------------------
                                    if (StringICompare(optionString, "gui-"))
                                        QCOM_CommandLineOnly = QCOM_NO;
                                    else
                                        QCOM_CommandLineOnly = QCOM_YES;
                                }
                                else
                                {
                                    status = QCOM_ERROR_INVALID_PARAMETER;
                                }
                            }           // end of case 'g'
                            break;
                        case 'm' :
                            {
                                if (optionString->Length > 1)
                                {
                                    //----------------------------------------
                                    // The corresponding flags have already
                                    // been set by QCOM_SetCommandLineFlags,
                                    // so no need to set them here
                                    //----------------------------------------
                                    switch (optionString[1])
                                    {
                                        case '0' :
                                        case 'b' :
                                        case 'd' :
                                        case 'e' :
                                        case 'l' :
                                        case 's' :
                                        case 'v' :
                                        case 'x' :
                                            break;
                                        default :
                                            status = QCOM_ERROR_INVALID_PARAMETER;
                                            break;
                                    }   // end of switch (optionString[1])
                                }
                                else
                                {
                                    status = QCOM_ERROR_INVALID_PARAMETER;
                                }
                            }           // end of case 'm'
                            break;
                        case 'x' :
                            {
                                //--------------------------------------------
                                // Invoke / revoke Expert Mode
                                //--------------------------------------------
                                if (optionString->Length > 1)
                                {
                                    if (StringICompare(optionString, "x-") == 0)
                                        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_EXPERT_MODE;
                                    else
                                        status = QCOM_ERROR_INVALID_PARAMETER;
                                }
                                else
                                {
                                    QCOM_GeneralInfo->flags |= QCOM_GENERAL_EXPERT_MODE;
                                }
                            }
                            break;
                        case 'h' :
                            {
                                if (optionString->Length > 1)
                                {
                                    if (StringICompare(optionString, "help"))
                                        status = QCOM_ERROR_INVALID_PARAMETER;
                                }
                                if (status == QCOM_SUCCESS)
                                {
                                    System::Diagnostics::Process::Start(QCOM_HELP_URL);
                                }
                            }
                            break;
                        case '?' :
                            displayUsage = QCOM_YES;
                            break;
                        default :
                            status = QCOM_ERROR_INVALID_PARAMETER;
                            break;
                    }                   // end of switch (optionString[0])
                }                       // end of if ((parameter[0] == '/') || (parameter[0] == '-'))
                else
                {
                    if (parameter[0] == '?')
                    {
                        displayUsage = QCOM_YES;
                    }
                    else
                    {
                        status = QCOM_ERROR_INVALID_PARAMETER;
                    }
                }
            }                           // end of if (optionPtr && strlen(optionPtr))
            if (status == QCOM_ERROR_INVALID_PARAMETER)
            {
                Modal("Invalid Command-line Parameter:\n{0}", parameter);
                //------------------------------------------------------------
                // An invalid parameter is not fatal to program function, so
                // clear the error and allow the program to continue, but
                // display the Usage
                //------------------------------------------------------------
                status = QCOM_SUCCESS;
                displayUsage = QCOM_YES;
            }
        }                               // end of for each (String ^parameter in parameters)
        if (displayUsage)
        {
            ModalT("QCOM Command-line Usage",
                "Acceptable command-line parameters for QCOM are\n\n"
                "    /m0    Turn off all modal messages\n"
                "    /mb    Enable basic modal messages (/mb- disables)\n"
                "    /md    Enable detailed modal messages (/md- disables)\n"
                "    /me    Enable error modal messages (/me- disables)\n"
                "    /ml    Enable DLL modal messages (/ml- disables)\n"
                "    /ms    Enable modal stack traces for errors (/ms- disables)\n"
                "    /mv    Enable verbose modal messages (/mv- disables)\n"
                "    /mx    Enable experimental modal messages (/mx- disables)\n"
                "    /evta  Start logging all non-test events\n"
                "    /evtb  Start logging basic events (also /evt)\n"
                "    /evtv  Start logging verbose events\n"
                "    /evtd  Start logging detailed events\n"
                "    /cfg   Load config information on startup (/cfg- prevents)\n"
                "    /gui   Display the graphical interface (/gui- for command-line only)\n"
                "    /x     Start up in Expert Mode (/x- disables)\n"
                "    /h     Display this usage, along with the online Help\n"
                "    /?     Display this usage window only");
        }
        delete [] parameters;
        delete [] lineDelimiters;
    }                                   // end of if (StringSet(QCOM_GeneralInfo->commandLine))
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of QCOM_ProcessCommandLineParameters()
//----------------------------------------------------------------------------
// QCOM_SetBuildNumber
//
// Set the build number, using the following decimal military time format:
//      YYMMDDHHMM
//
// Called by:   QCOM_InitializeQCOM
//
// Note:    This function must reside in a file, or be called by a function
//          that resides in a file, that is guaranteed to be recompiled with
//          every build attempt
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SetBuildNumber(void)
{
    int             dayValue;
    int             hourValue;
    int             minuteValue;
    int             monthValue;
    int             yearValue;
    String          ^dateString = __DATE__; // Nov 22 2011
    String          ^timeString = __TIME__; // 08:05:07 / 13:48:27
    //------------------------------------------------------------------------
    if (dateString[4] == ' ')
        dateString = String::Concat(
            dateString->Substring(0, 4),
            "0",
            dateString->Substring(5));
    hourValue = Convert::ToInt32(timeString->Substring(0, 2));
    minuteValue = Convert::ToInt32(timeString->Substring(3, 2));
    dayValue = Convert::ToInt32(dateString->Substring(4, 2));
    yearValue = Convert::ToInt32(dateString->Substring(9, 2));
    for each (String ^monthString in QCOM_MonthStringArray)
    {
        if (StringICompare(dateString->Substring(0, 3), monthString) == 0)
        {
            monthValue = Array::IndexOf(QCOM_MonthStringArray, monthString);
            break;
        }
    }
    QCOM_BuildNumber = (DWORD)
        (yearValue * 100000000L) +
        (monthValue * 1000000L) +
        (dayValue * 10000L) +
        (hourValue * 100L) +
        minuteValue;
}                                       // end of QCOM_SetBuildNumber()
//----------------------------------------------------------------------------
// QCOM_SetCommandLineFlags
//
// Sets the most fundamental program flags according to the command line
//
// Called by:   QCOM_Main
//----------------------------------------------------------------------------
    void
QCOM_SetCommandLineFlags(
    LPTSTR          commandLine)
{
    //------------------------------------------------------------------------
    if (commandLine)
    {
        String ^commandLineString = gcnew String(commandLine);
        if (StringSet(commandLineString))
        {
            //----------------------------------------------------------------
            // Split up and parse the command line only for the purposes of
            // this function, which can include a software update
            //----------------------------------------------------------------
            array <String ^> ^parameters = Environment::GetCommandLineArgs();
            for each (String ^optionString in parameters)
            {
                optionString = optionString->ToLower();
                if (!optionString->EndsWith(".exe"))
                {
                    if (optionString->Contains("/evt"))
                    {
                        if ((StringICompare(optionString, "/evta") == 0) ||
                            (StringICompare(optionString, "/evtd") == 0))
                        {
                            QCOM_EventLogBasicEnabled =
                                QCOM_EventLogVerboseEnabled =
                                QCOM_EventLogDetailedEnabled = GUI_YES;
                        }
                        else
                        {
                            if (StringICompare(optionString, "/evtv") == 0)
                            {
                                QCOM_EventLogBasicEnabled =
                                    QCOM_EventLogVerboseEnabled = GUI_YES;
                            }
                            else
                            {
                                if ((StringICompare(optionString, "/evt") == 0) ||
                                    (StringICompare(optionString, "/evtb") == 0))
                                {
                                    QCOM_EventLogBasicEnabled = GUI_YES;
                                }
                            }
                        }
                    }                   // end of if (optionString->Contains("/evt"))
                    if (optionString->Contains("/gui"))
                    {
                        if (StringICompare(optionString, "/gui-") == 0)
                            QCOM_CommandLineOnly = GUI_YES;
                    }                   // end of if (optionString->Contains("/gui"))
                    if (optionString->Contains("/m"))
                    {
                        if (StringICompare(optionString, "/m0") == 0)
                        {
                            QCOM_BasicMessagesEnabled = GUI_NO;
                            QCOM_ErrorMessagesEnabled = GUI_NO;
                            QCOM_VerboseMessagesEnabled = GUI_NO;
                            QCOM_DetailedMessagesEnabled = GUI_NO;
                            QCOM_StackTracesEnabled = GUI_NO;
                            QCOM_ExpMessagesEnabled = GUI_NO;
                            QD_DLLMessagesEnabled = GUI_NO;
                        }
                        else
                        {
                            if (optionString->Contains("/mb"))
                            {
                                QCOM_BasicMessagesEnabled =
                                    StringICompare(optionString, "/mb-") ? GUI_YES : GUI_NO;
                            }
                            if (optionString->Contains("/md"))
                            {
                                QCOM_DetailedMessagesEnabled =
                                    StringICompare(optionString, "/md-") ? GUI_YES : GUI_NO;
                            }
                            if (optionString->Contains("/me"))
                            {
                                QCOM_ErrorMessagesEnabled =
                                    StringICompare(optionString, "/me-") ? GUI_YES : GUI_NO;
                            }
                            if (optionString->Contains("/ml"))
                            {
                                QD_DLLMessagesEnabled =
                                    StringICompare(optionString, "/ml-") ? GUI_YES : GUI_NO;
                            }
                            if (optionString->Contains("/ms"))
                            {
                                QCOM_StackTracesEnabled =
                                    StringICompare(optionString, "/ms-") ? GUI_YES : GUI_NO;
                            }
                            if (optionString->Contains("/mv"))
                            {
                                QCOM_VerboseMessagesEnabled =
                                    StringICompare(optionString, "/mv-") ? GUI_YES : GUI_NO;
                            }
                            if (optionString->Contains("/mx"))
                            {
                                QCOM_ExpMessagesEnabled =
                                    StringICompare(optionString, "/mx-") ? GUI_YES : GUI_NO;
                            }
                        }               // end of else of if (StringICompare(optionString, "/m0") == 0)
                    }                   // end of if (optionString->Contains("/m"))
                    if (optionString->Contains("/u"))
                    {
                        Thread::Sleep(1000);
                        //----------------------------------------------------
                        // Software update is in progress
                        //----------------------------------------------------
                        String ^updateFile = String::Concat(
                            Application::StartupPath, "\\", QCOM_SW_UPDATE_FILENAME);
                        if (File::Exists(updateFile))
                        {
                            StreamReader ^textReader = File::OpenText(updateFile);
                            String ^oldProgram = textReader->ReadLine();
                            String ^newProgram = textReader->ReadLine();
                            String ^originalCommandLine = textReader->ReadLine();
                            textReader->Close();
                            if (StringICompare(Application::ExecutablePath, oldProgram))
                            {
                                //--------------------------------------------
                                // This is a program not named QCOM.exe
                                //
                                // At this point, newProgram == Application::ExecutablePath
                                //--------------------------------------------
                                QCOM_SoftwareUpdateInProgress = GUI_YES;
                                if (File::Exists(oldProgram))
                                    File::Delete(oldProgram);
                                Thread::Sleep(1000);
                                File::Copy(Application::ExecutablePath, oldProgram);
                                //--------------------------------------------
                                // Delete all the old config files present
                                //--------------------------------------------
                                String ^logDir = String::Concat(Application::StartupPath, "\\", QCOM_LOG_DIRECTORY);
                                if (Directory::Exists(logDir))
                                {
                                    logDir = String::Concat(logDir, "\\");
                                    array <String ^> ^configFiles = Directory::GetFiles(logDir, "QCOM-*.config");
                                    if (StringSet(configFiles))
                                    {
                                        for each (String ^oldConfigPath in configFiles)
                                        {
                                            if (File::Exists(oldConfigPath))
                                                File::Delete(oldConfigPath);
                                        }
                                    }
                                    delete [] configFiles;
                                }
                                delete logDir;
                                //--------------------------------------------
                                // Start the new program running
                                //--------------------------------------------
                                ProcessStartInfo ^startNewAppCommand = gcnew ProcessStartInfo(oldProgram);
                                startNewAppCommand->WindowStyle = ProcessWindowStyle::Hidden;
                                startNewAppCommand->Arguments = _T("/u");
                                startNewAppCommand->CreateNoWindow = GUI_YES;
                                startNewAppCommand->UseShellExecute = GUI_NO;
                                System::Diagnostics::Process::Start(startNewAppCommand);
                                //--------------------------------------------
                                // Exit this program
                                //--------------------------------------------
                                Environment::Exit(QCOM_SUCCESS);
                            }           // end of if (StringICompare(Application::ExecutablePath, oldProgram))
                            else
                            {
                                //--------------------------------------------
                                // This program name is QCOM.exe
                                //--------------------------------------------
                                ClearBuffer(commandLine, commandLineString->Length);
                                if (File::Exists(updateFile))
                                    File::Delete(updateFile);
                                if (File::Exists(newProgram))
                                    File::Delete(newProgram);
                                if (StringSet(originalCommandLine))
                                {
                                    pin_ptr <const wchar_t> widePtr = PtrToStringChars(originalCommandLine);
                                    wcscpy_s(
                                        commandLine,
                                        QCOM_MAXIMUM_VERSION_STRING_SIZE,
                                        widePtr);
                                }
                                QCOM_SetCommandLineFlags(commandLine);
                                QCOM_SoftwareUpdateInProgress = GUI_NO;
                            }           // end of else of if (StringICompare(Application::ExecutablePath, oldProgram))
                            delete originalCommandLine;
                            delete newProgram;
                            delete oldProgram;
                        }               // end of if (File::Exists(updateFile))
                        delete updateFile;
                    }                   // end of if (optionString->Contains("/u"))
                    if (optionString->Contains("?"))
                    {
                        QCOM_CommandLineOnly = GUI_YES;
                    }
                }                       // end of if (!optionString->ToLower()->EndsWith(".exe"))
            }                           // end of for each (String ^optionString in parameters)
            //----------------------------------------------------------------
            // Set some global flags according to the settings of others
            //----------------------------------------------------------------
            if (QCOM_DetailedMessagesEnabled)
            {
                QCOM_VerboseMessagesEnabled = GUI_YES;
            }
            if (QCOM_VerboseMessagesEnabled)
            {
                QCOM_BasicMessagesEnabled = GUI_YES;
                QCOM_ErrorMessagesEnabled = GUI_YES;
            }
            if (QCOM_StackTracesEnabled)
                QCOM_ErrorMessagesEnabled = GUI_YES;
            if (QCOM_DetailedMessagesEnabled)
                QModalD("Loc 1 : Command line = '{0}'", commandLineString);
            else
                if (QCOM_VerboseMessagesEnabled)
                    QModalV("Loc 1 : Command line = '{0}'", commandLineString);
                else
                    if (QCOM_ExpMessagesEnabled)
                        QModalX("Loc 1 : Command line = '{0}'", commandLineString);
            delete [] parameters;
        }                               // end of if (StringSet(commandLineString))
    }                                   // end of if (commandLine)
}                                       // end of QCOM_SetCommandLineFlags()
//----------------------------------------------------------------------------
// QCOM_SetUnitFlagsToInitialValues
//
// Sets the flags of the specified unit to initial values
//
// Called by:   QCOM_ScanForDevices
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SetUnitFlagsToInitialValues(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_SetUnitFlagsToInitialValues");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        if (!(unit->flags & QCOM_UNIT_INITIAL_SETTINGS_SET))
        {
            unit->dataLogFlags |= QCOM_UNIT_LOG_DEFAULT_SETTINGS;
            unit->dataLogPoints |= QCOM_UNIT_LOG_DEFAULT_DATA_POINTS;
            unit->testFlags |= QCOM_UNIT_TEST_INITIAL_SETTINGS;
            unit->flags |=
                (QCOM_UNIT_INITIAL_SETTINGS | QCOM_UNIT_INITIAL_SETTINGS_SET);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_SetUnitFlagsToInitialValues()
//----------------------------------------------------------------------------
#endif      // QCOM_CPP
//============================================================================
// End of QCOM.cpp
//============================================================================
