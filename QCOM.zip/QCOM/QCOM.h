//============================================================================
// QCOM.h
//
// Header for QCOM.cpp, which defines functions for transducer communication
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#pragma once
#ifndef     QCOM_H
#define     QCOM_H
//----------------------------------------------------------------------------
// Include appropriate headers
//----------------------------------------------------------------------------
#include    "GUI.h"
//----------------------------------------------------------------------------
// The following lines are only seen by QCOM.cpp
//----------------------------------------------------------------------------
#ifdef      QCOM_CPP
//----------------------------------------------------------------------------
// Substitutions
//----------------------------------------------------------------------------
#define     QCOM_Main       wWinMain
#define     QCOM_YES        GUI_YES
#define     QCOM_NO         GUI_NO
//----------------------------------------------------------------------------
// Global variables
//----------------------------------------------------------------------------
bool            QCOM_BasicMessagesEnabled = QCOM_NO;                            // 0x00000001
bool            QCOM_ErrorMessagesEnabled = QCOM_NO;                            // 0x00000002
bool            QCOM_VerboseMessagesEnabled = QCOM_NO;                          // 0x00000004
bool            QCOM_DetailedMessagesEnabled = QCOM_NO;                         // 0x00000008
bool            QCOM_ExpMessagesEnabled = QCOM_NO;                              // 0x00000010
bool            QCOM_StackTracesEnabled = QCOM_NO;                              // 0x00000020
bool            QCOM_SendTextErrorMessagesEnabled = QCOM_NO;                    // 0x00000040
bool            QCOM_SendEmailErrorMessagesEnabled = QCOM_NO;                   // 0x00000080
bool            QCOM_EventLogBasicEnabled = QCOM_NO;                            // 0x00001000
bool            QCOM_EventLogVerboseEnabled = QCOM_NO;                          // 0x00002000
bool            QCOM_EventLogDetailedEnabled = QCOM_NO;                         // 0x00004000
bool            QCOM_EventLogTestEnabled = QCOM_NO;                             // 0x00008000
bool            QCOM_ProgramIntervalEnabled = QCOM_YES;                         // 0x01000000
bool            QCOM_ExperimentsEnabled = QCOM_NO;                              // 0x02000000
bool            QCOM_HaltOperationsOnErrors = QCOM_NO;                          // 0x04000000
bool            QCOM_CommandLineOnly = QCOM_NO;                                 // 0x40000000
bool            QCOM_SoftwareUpdateInProgress = QCOM_NO;                        // 0x80000000
DWORD           QCOM_BuildNumber = 0;
DWORD           QCOM_CurrentNumberOfUnits;
DWORD           QCOM_StartTime;
DWORD           QCOM_WindowsVersion = QCOM_WIN_VER_UNKNOWN;
//----------------------------------------------------------------------------
// External global variables
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// Function prototypes
//----------------------------------------------------------------------------
DWORD           Div10(
                    DWORD           value);
int             QCOM_CalculatePercentage(
                    DWORD           dividend,
                    DWORD           divisor);
char            *QCOM_ConvertString(
                    String          ^managedString,
                    char            *unmanagedString,
                    size_t          unmanagedBufferSize);
char            *QCOM_FilenameContainsExtension(
                    char            *pathName,
                    char            *extension);
char            *QCOM_ItoA(
                    DWORD           value,
                    char            *valueString);
char            *QCOM_ItoX(
                    DWORD           value,
                    char            *valueString);
void            QCOM_SetCommandLineFlags(
                    LPTSTR          commandLineString);
void            QCOM_WaitMS(
                    DWORD           ms);
//----------------------------------------------------------------------------
// String definitions
//----------------------------------------------------------------------------
#define     QCOM_MUTEX_STRING                   _T("QCOMRunning")
//----------------------------------------------------------------------------
// Macros
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// End of the lines that are only seen by QCOM.cpp
//----------------------------------------------------------------------------
#endif      // QCOM_CPP
#endif      // QCOM_H
//============================================================================
// End of QCOM.h
//============================================================================
