//============================================================================
// QCOMDefs.h
//
// Header for type definitions not defined elsewhere
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#pragma once
#ifndef     QCOMDEFS_H  // provided for legacy compilers, but unnecessary for
#define     QCOMDEFS_H  // recent compilers, due to the preceding pragma
//----------------------------------------------------------------------------
// Functions to be generated as inline code
//----------------------------------------------------------------------------
//#pragma intrinsic(strlen, strcpy, memset, memcpy)
//----------------------------------------------------------------------------
// Headers to include
//----------------------------------------------------------------------------
#include    "qdUSB.h"
#include    "FakeDLL.h"
//----------------------------------------------------------------------------
// QCOM type definitions
//----------------------------------------------------------------------------
//typedef
//    struct _LoggingStats
//        LoggingStatsDef;
//typedef
//    struct _TestingStats
//        TestingStatsDef;
//typedef
//    struct _UnitInfo
//        UnitDef;
//----------------------------------------------------------------------------
// Version strings
//
// Note:    Be sure to edit Resource.h and AssemblyInfo.cs to propogate
//          changes in the QCOM software version to the file system
//----------------------------------------------------------------------------
#define     QCOM_PROGRAM_VERSION_MAJOR                          "1"
#define     QCOM_PROGRAM_VERSION_MINOR                          "1"
#define     QCOM_PROGRAM_VERSION_BUILD                          "0"
#define     QCOM_PROGRAM_VERSION_REV                            "0"
#define     QCOM_PROGRAM_VERSION_STRING                         QCOM_PROGRAM_VERSION_MAJOR "." QCOM_PROGRAM_VERSION_MINOR "." QCOM_PROGRAM_VERSION_BUILD "." QCOM_PROGRAM_VERSION_REV
#define     QCOM_PROGRAM_VER_STRING                             QCOM_PROGRAM_VERSION_MAJOR "." QCOM_PROGRAM_VERSION_MINOR "." QCOM_PROGRAM_VERSION_BUILD
//----------------------------------------------------------------------------
// Vendor and Product IDs
//----------------------------------------------------------------------------
#define     QCOM_VENDOR_ID                                      0x10C4
#define     QCOM_PRODUCT_ID                                     0x85D1
#define     CMUX_PRODUCT_ID                                     0xEA61
#define     QCOM_VENDOR_ID_STRING                               _T("10C4")
#define     QCOM_PRODUCT_ID_STRING                              _T("85D1")
#define     CMUX_PRODUCT_ID_STRING                              _T("8865")
#define     CMUX_OLD_PRODUCT_ID_STRING                          _T("EA61")
//----------------------------------------------------------------------------
// Windows version
//
//                23 20     19 16     15 12     11  8     7       0
// |....|....|     ....|     ....|     ....|     ....    |.... ....|
//                  SP        Rel       Maj       Min      OS Base
//
// Bits 7 through 0 define the base operating system version, the lower 4 bits
//      for client versions and the upper 4 bits for server versions
// Bits 11 through 8 define the OS minor version
// Bits 15 through 12 define the OS major version
// Bits 19 through 16 define the OS release number
// Bits 23 through 20 define the OS Service Pack number
// The remainder is a bitmap of features, as follows:
// Bit 30 defines 128-bit OS version
// Bit 31 defines 64-bit OS version
//----------------------------------------------------------------------------
#define     QCOM_WIN_VER_UNKNOWN                                0x00000000
#define     QCOM_WIN_VER_PRE_XP                                 0x00000001
#define     QCOM_WIN_VER_XP                                     0x00000002
#define     QCOM_WIN_VER_VISTA                                  0x00000003
#define     QCOM_WIN_VER_7                                      0x00000004
#define     QCOM_WIN_VER_8                                      0x00000005
#define     QCOM_WIN_VER_10                                  0x00000006
#define     QCOM_WIN_VER_SERVER_2003                         0x00000010
#define     QCOM_WIN_VER_SERVER_2008                         0x00000020
#define     QCOM_WIN_VER_SERVER_8                            0x00000030
#define     QCOM_WIN_VER_SERVER_2012                         0x00000040
#define     QCOM_WIN_VER_SERVER_2016                         0x00000050
#define     QCOM_WIN_VER_R1                                     0x00010000
#define     QCOM_WIN_VER_R2                                     0x00020000
#define     QCOM_WIN_VER_R3                                     0x00030000
#define     QCOM_WIN_VER_SP1                                    0x00100000
#define     QCOM_WIN_VER_SP2                                    0x00200000
#define     QCOM_WIN_VER_SP3                                    0x00300000
#define     QCOM_WIN_VER_SP4                                    0x00400000
#define     QCOM_WIN_VER_128_BIT                                0x40000000
#define     QCOM_WIN_VER_64_BIT                                 0x80000000
//----------------------------------------------------------------------------
// Integer definitions
//----------------------------------------------------------------------------
#define     QCOM_MAXIMUM_OPEN_ATTEMPTS                          100
#define     QCOM_COEFFICIENT_DATA_SIZE                          QD_COEFFICIENT_DATA_SIZE
#define     QCOM_MAXIMUM_TEXT_FILE_LINE_SIZE                    1024
#define     QCOM_MINIMAL_TEXT_FILE_LINE_SIZE                    128
#define     QCOM_MAXIMUM_COEFFICIENT_FILE_LINE_SIZE             32
#define     QCOM_MAXIMUM_NATIVE_COEFFICIENT_FILE_LINES          44
#define     QCOM_MAXIMUM_HEX_COEFFICIENT_FILE_LINES             70
#define     QCOM_MAXIMUM_FILE_PATH_LENGTH                       512
#define     QCOM_MAXIMUM_FILE_NAME_LENGTH                       90
#define     QCOM_MAXIMUM_NUMBER_OF_UNITS                        20
#define     QCOM_MAXIMUM_NUMBER_OF_DISPLAY_UNITS                QCOM_MAXIMUM_NUMBER_OF_UNITS
#define     QCOM_MAXIMUM_CONFIG_LINE_SIZE                       QCOM_MAXIMUM_TEXT_FILE_LINE_SIZE
#define     QCOM_MAXIMUM_ERROR_LOG_LINE_SIZE                    QCOM_MAXIMUM_TEXT_FILE_LINE_SIZE
#define     QCOM_MAXIMUM_ERROR_LOG_ENTRY_SIZE                   1280
#define     QCOM_MAXIMUM_EVENT_LOG_LINE_SIZE                    QCOM_MAXIMUM_TEXT_FILE_LINE_SIZE
#define     QCOM_MAXIMUM_EVENT_LOG_ENTRY_SIZE                   QCOM_MAXIMUM_ERROR_LOG_ENTRY_SIZE
#define     QCOM_SMALL_DATE_STRING_SIZE                         16
#define     QCOM_MAXIMUM_PART_NUMBER_SIZE                       32
// The maximum serial number size must be 256, because that
// is dictated by Silicon Labs in their call to SI_GetProductString
#define     QCOM_MAXIMUM_SERIAL_NUMBER_SIZE                     256
#define     QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH                6
#define     QCOM_MAXIMUM_REGISTRY_KEY_SIZE                      288
#define     QCOM_MAXIMUM_DESCRIPTION_STRING_SIZE                128
#define     QCOM_TIMEOUT_500MS                                  500
#define     QCOM_TIMEOUT_5S                                     5000
#define     QCOM_TIMEOUT_10S                                    10000
#define     QCOM_VALUE_STRING_SIZE                              40
#define     QCOM_FORMAT_ERROR_STRING_SIZE                       80
#define     QCOM_MAXIMUM_EMAIL_ADDRESS_SIZE                     256
#define     QCOM_MAXIMUM_SEARCH_STRING_SIZE                     128
#define     QCOM_MAXIMUM_DATA_LOG_LINE_SIZE                     QCOM_MAXIMUM_TEXT_FILE_LINE_SIZE
#define     QCOM_MAXIMUM_DATA_LOG_SIZE                          4194304
#define     QCOM_SUMMARY_TEST_LOG_SIZE                          65536
#define     QCOM_DETAILED_TEST_LOG_SIZE                         1048576
#define     QCOM_MAXIMUM_TEST_LOG_LINE_SIZE                     QCOM_MAXIMUM_TEXT_FILE_LINE_SIZE
#define     QCOM_MAXIMUM_SUPPORT_LOG_ENTRY_SIZE                 2048
#define     QCOM_MAXIMUM_VERSION_STRING_SIZE                    64
#define     QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE                QD_MAXIMUM_TRANSFER_SIZE
#define     QCOM_MAXIMUM_I2C_RESPONSE_STRING_SIZE               96
#define     QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE                  QD_MAXIMUM_TRANSFER_SIZE
#define     QCOM_MAXIMUM_I2C_INTERP_STRING_SIZE                 1024
#define     QCOM_MAXIMUM_I2C_ADDRESS_BUFFER_SIZE                32
#define     QCOM_MAXIMUM_TRANSDUCER_ID_STRING_SIZE              32
#define     QCOM_MAXIMUM_FIRMWARE_STRING_SIZE                   40
#define     QCOM_MINIMUM_FIRMWARE_MAJOR_VERSION                 1
#define     QCOM_MINIMUM_FIRMWARE_MINOR_VERSION                 2
#define     QCOM_MINIMUM_QDUSB_DLL_MAJOR_VERSION                1
#define     QCOM_MINIMUM_QDUSB_DLL_MINOR_VERSION                0
#define     QCOM_MINIMUM_QDUSB_DLL_BUILD_VERSION                7
#define     QUARTZDYNE_MAIL_SERVER_PORT_NUMBER                  25
#define     GMAIL_MAIL_SERVER_PORT_NUMBER                       587
#define     QCOM_MAXIMUM_NUMBER_OF_MEMORY_SLOTS                 4
#define     QCOM_DEFAULT_PAGES_PER_MEMORY_SLOT                  4
//----------------------------------------------------------------------------
// Pressure units
//----------------------------------------------------------------------------
#define     QCOM_PRESSURE_UNITS_PSI                             0
#define     QCOM_PRESSURE_UNITS_BAR                             1
#define     QCOM_PRESSURE_UNITS_MBAR                            2
#define     QCOM_PRESSURE_UNITS_PA                              3
#define     QCOM_PRESSURE_UNITS_KPA                             4
#define     QCOM_PRESSURE_UNITS_MPA                             5
#define     QCOM_PRESSURE_UNITS_HPA                             6
#define     QCOM_PRESSURE_UNITS_MMHG                            7
#define     QCOM_PRESSURE_UNITS_INHG                            8
#define     QCOM_PRESSURE_UNITS_MH2O                            9
#define     QCOM_PRESSURE_UNITS_INH2O                           10
#define     QCOM_PRESSURE_UNITS_ATM                             11
#define     QCOM_PRESSURE_UNITS_TORR                            12
#define     QCOM_PRESSURE_UNITS_DCM2                            13
#define     QCOM_PRESSURE_UNITS_MSW                             14
#define     QCOM_MAXIMUM_NUMBER_OF_PRESSURE_UNITS               15
#define     QCOM_PRESSURE_UNITS_DEFAULT                         QCOM_PRESSURE_UNITS_PSI
#define     QCOM_PRESSURE_UNITS_ALT_DEFAULT                     QCOM_PRESSURE_UNITS_BAR
//----------------------------------------------------------------------------
// Temperature units
//----------------------------------------------------------------------------
#define     QCOM_TEMPERATURE_UNITS_CELSIUS                      0
#define     QCOM_TEMPERATURE_UNITS_FAHRENHEIT                   1
#define     QCOM_TEMPERATURE_UNITS_KELVIN                       2
#define     QCOM_TEMPERATURE_UNITS_RANKINE                      3
#define     QCOM_MAXIMUM_NUMBER_OF_TEMPERATURE_UNITS            4
#define     QCOM_TEMPERATURE_UNITS_DEFAULT                      QCOM_TEMPERATURE_UNITS_CELSIUS
#define     QCOM_TEMPERATURE_UNITS_ALT_DEFAULT                  QCOM_TEMPERATURE_UNITS_FAHRENHEIT
//----------------------------------------------------------------------------
// Amperage units
//----------------------------------------------------------------------------
#define     QCOM_AMPERAGE_UNITS_MA                              0
#define     QCOM_AMPERAGE_UNITS_AMPS                            1
#define     QCOM_MAXIMUM_NUMBER_OF_AMPERAGE_UNITS               2
#define     QCOM_AMPERAGE_UNITS_DEFAULT                         QCOM_AMPERAGE_UNITS_MA
//----------------------------------------------------------------------------
// Non-integer definitions (conversion factors)
//----------------------------------------------------------------------------
#define     QCOM_ATM_PER_PSI                                    0.06804596399087771     // verified
#define     QCOM_BAR_PER_PSI                                    0.0689475729316836      // verified
#define     QCOM_CELSIUS_TO_KELVIN                              273.15
#define     QCOM_DCM2_PER_PSI                                   68947.5729316836
#define     QCOM_HPA_PER_PSI                                    68.9475729316836
#define     QCOM_KPA_PER_PSI                                    6.89475729316836
#define     QCOM_MBAR_PER_PSI                                   QCOM_HPA_PER_PSI
#define     QCOM_MH2O_PER_PSI                                   0.7030695796391592      // verified
#define     QCOM_INH2O_PER_PSI                                  27.679904710203118      // verified
#define     QCOM_MMHG_PER_PSI                                   51.714925203871920      // verified
#define     QCOM_INHG_PER_PSI                                   2.0360206773177921      // verified
#define     QCOM_MPA_PER_PSI                                    0.00689475729316836
#define     QCOM_PA_PER_PSI                                     6894.75729316836        // verified
#define     QCOM_FAHRENHEIT_TO_RANKINE                          459.67
#define     QCOM_TORR_PER_PSI                                   51.71493257150692
#define     QCOM_MSW_PER_PSI                                    0.6847301114174418
//----------------------------------------------------------------------------
// The frequency multiplier is 7.2 MHz / 4 GB
//----------------------------------------------------------------------------
#define     QCOM_FREQUENCY_MULTIPLIER                           0.001676380634307861328125
#define     QUARTZDYNE_WVC_GRAVITY                              9.797930
//----------------------------------------------------------------------------
// Graphing boundary default values in default units
//----------------------------------------------------------------------------
#define     QCOM_GRAPH_DEFAULT_AMPERAGE_LOW_BOUNDARY_MA         0.0
#define     QCOM_GRAPH_DEFAULT_AMPERAGE_HIGH_BOUNDARY_MA        20.0
#define     QCOM_GRAPH_DEFAULT_PRESSURE_LOW_BOUNDARY_PSI        6.0
#define     QCOM_GRAPH_DEFAULT_PRESSURE_HIGH_BOUNDARY_PSI       20.0
#define     QCOM_GRAPH_DEFAULT_TEMPERATURE_LOW_BOUNDARY_C       10.0
#define     QCOM_GRAPH_DEFAULT_TEMPERATURE_HIGH_BOUNDARY_C      30.0
//----------------------------------------------------------------------------
// Special characters
//----------------------------------------------------------------------------
#define     QCOM_CHAR_NULL                                      '\0'
#define     QCOM_CHAR_CR                                        '\r'
#define     QCOM_CHAR_LF                                        '\n'
#define     QCOM_CHAR_SPACE                                     ' '
#define     QCOM_CHAR_COMMA                                     ','
//----------------------------------------------------------------------------
// Special strings
//----------------------------------------------------------------------------
#define     QCOM_STRING_EMPTY                                   _T("")
#define     QCOM_STRING_SPACE                                   _T(" ")
#define     QCOM_STRING_S                                       _T("s")
#define     QCOM_STRING_DOT                                     _T(".")
#define     QCOM_STRING_HYPHEN                                  _T("-")
#define     QCOM_STRING_PERIOD                                  _T(".")
#define     QCOM_STRING_COMMA                                   _T(",")
#define     QCOM_STRING_AT                                      _T("@")
#define     QCOM_STRING_LF                                      _T("\n")
#define     QCOM_STRING_CRLF                                    _T("\r\n")
#define     QCOM_STRING_POUND                                   _T("#")
#define     QCOM_STRING_COLON                                   _T(":")
#define     QCOM_STRING_SEMICOLON                               _T(";")
#define     QCOM_STRING_APOSTROPHE                              _T("'")
#define     QCOM_STRING_SLASH                                   _T("/")
#define     QCOM_STRING_BACKSLASH                               _T("\\")
#define     QCOM_STRING_DOLLAR                                  _T("$")
#define     QCOM_STRING_TILDE                                   _T("~")
#define     QCOM_STRING_0                                       _T("0")
#define     QCOM_STRING_1                                       _T("1")
//----------------------------------------------------------------------------
// Shortcut strings
//----------------------------------------------------------------------------
#define     QCOM_STRING_DSPACE                                  _T("  ")
#define     QCOM_STRING_NA                                      _T("N/A")
#define     QCOM_STRING_NONE                                    _T("None")
#define     QCOM_STRING_ERROR                                   _T("Error")
#define     QCOM_STRING_CLEARED                                 _T("Cleared")
#define     QCOM_STRING_INVALID                                 _T("Invalid")
#define     QCOM_STRING_UNKNOWN                                 _T("Unknown")
//----------------------------------------------------------------------------
// Status and results
//----------------------------------------------------------------------------
#define     QCOM_SUCCESS                                        0x00000000
#define     QCOM_FAILURE                                        -1
#define     QCOM_ERROR_NO_ERROR                                 QCOM_SUCCESS
#define     QCOM_ERROR_INVALID_PARAMETER                        0x00000006
#define     QCOM_ERROR_MEMORY_ALLOCATION_FAILED                 0x00000014
#define     QCOM_ERROR_FILE_OPEN_FAILURE                        0x00000015
#define     QCOM_ERROR_UNIT_NOT_READY                           0x0000001B
#define     QCOM_ERROR_NULL_POINTER_PARAMETER                   0x0000002A
#define     QCOM_ERROR_ZERO_LENGTH_STRING_PARAMETER             0x0000002B
#define     QCOM_ERROR_INVALID_STRING_PARAMETER                 0x0000002C
//--------- Code -------------------------------------------------------------
#define     QCOM_ERROR_GENERAL_STRUCTURE_INVALID                0x00000060
//--------- Files ------------------------------------------------------------
#define     QCOM_ERROR_FILE_NOT_FOUND                           0x00000070
#define     QCOM_ERROR_INVALID_FILE_NAME                        0x00000071
#define     QCOM_ERROR_INVALID_FILE_FOUND                       0x00000072
#define     QCOM_ERROR_UNABLE_TO_CREATE_FILE                    0x00000073
#define     QCOM_ERROR_UNABLE_TO_READ_FILE                      0x00000074
#define     QCOM_ERROR_UNRECOGNIZED_FILE_TYPE                   0x00000077
//--------- Directories and Folders ------------------------------------------
#define     QCOM_ERROR_BASE_DIRECTORY_NOT_FOUND                 0x00000080
#define     QCOM_ERROR_UNABLE_TO_CREATE_DIRECTORY               0x00000081
//--------- Emails and Texts -------------------------------------------------
#define     QCOM_ERROR_EMAIL_FAILED_TO_SEND                     0x00000090
#define     QCOM_ERROR_INVALID_EMAIL_ADDRESS                    0x00000091
#define     QCOM_ERROR_EMAIL_MISSING_COMPONENT                  0x00000092
#define     QCOM_ERROR_EMAIL_MISSING_SUBJECT                    0x00000093
#define     QCOM_ERROR_EMAIL_MISSING_MESSAGE                    0x00000094
#define     QCOM_ERROR_EMAIL_MISSING_ATTACHMENT                 0x00000095
#define     QCOM_ERROR_INVALID_TEXT_NUMBER                      0x00000098
#define     QCOM_ERROR_TEXT_MISSING_COMPONENT                   0x00000099
#define     QCOM_ERROR_TEXT_MISSING_SUBJECT                     0x0000009A
#define     QCOM_ERROR_TEXT_MISSING_MESSAGE                     0x0000009B
//--------- Custom -----------------------------------------------------------
#define     QCOM_ERROR_UNIT_OPEN_FAILURE                        0x000000B0
#define     QCOM_ERROR_INVALID_UNIT_NUMBER                      0x000000B1
#define     QCOM_ERROR_INVALID_MODULE_SN                        0x000000B2
#define     QCOM_ERROR_INVALID_TRANSDUCER_SN                    0x000000B3
//--------- Others -----------------------------------------------------------
#define     QCOM_ERROR_NETWORK_UNAVAILABLE                      0x000000F0
#define     QCOM_ERROR_NO_DEVICE_FOUND                          0x000000FF
//----------------------------------------------------------------------------
// Hot plug levels
//----------------------------------------------------------------------------
#define     QCOM_HOT_PLUG_LEVEL_NO_CHANGE                       0x00000000
#define     QCOM_HOT_PLUG_LEVEL_MODULE_ADDED                    0x00000001
#define     QCOM_HOT_PLUG_LEVEL_MODULE_REMOVED                  0x00000002
#define     QCOM_HOT_PLUG_LEVEL_TRANSDUCER_ADDED                0x00000003
#define     QCOM_HOT_PLUG_LEVEL_TRANSDUCER_REMOVED              0x00000004
//----------------------------------------------------------------------------
// String definitions
//----------------------------------------------------------------------------
#define     QCOM_PROGRAM_FILENAME                               _T("QCOM.exe")
#define     QCOM_PROGRAM_AUTHOR                                 _T("Noji Ratzlaff (noji@quartzdyne.com)")
#define     QCOM_SW_UPDATE_FILENAME                             _T("QCOM.update")
#define     QCOM_DLL_UPDATE_FILENAME                            _T("qdUSB.update")
#define     QCOM_LOG_DIRECTORY                                  _T("QLog")
#define     QUARTZDYNE_URL                                      _T("http://www.quartzdyne.com/")
#define     QUARTZDYNE_QD_URL_DIR                               _T("http://qd.quartzdyne.com/")
#define     QUARTZDYNE_HOST                                     _T("quartzdyne.com")
#define     QUARTZDYNE_EXCHANGE_SERVER                          _T("QDExchange1.quartzdyne.local")
#define     QUARTZDYNE_MAIL_SERVER                              _T("mail.quartzdyne.com")
#define     QUARTZDYNE_SUPPORT_EMAIL_ADDRESS                    _T("Quartzdyne Support <support@quartzdyne.com>")
#define     QUARTZDYNE_CONFIDENTIAL_ROOT                        _T("\\\\QDCluster\\Confidential\\")
#define     QUARTZDYNE_PUBLIC_ROOT                              _T("\\\\QDCluster\\Public\\")
#define     QUARTZDYNE_PROG_SUBFOLDER                           _T("Software-Eng\\Prog\\")
#define     QUARTZDYNE_PROG_FOLDER                              QUARTZDYNE_CONFIDENTIAL_ROOT QUARTZDYNE_PROG_SUBFOLDER
#define     QUARTZDYNE_CAL_DATA_SUBFOLDER                       _T("Ops\\Cal_Data\\")
#define     QUARTZDYNE_CAL_DATA_FOLDER                          QUARTZDYNE_PUBLIC_ROOT QUARTZDYNE_CAL_DATA_SUBFOLDER
#define     QUARTZDYNE_CALSUM_DB_FILE_PATH                      QUARTZDYNE_PROG_SUBFOLDER _T("CALSUM\\CALSUM.MDB")
#define     QUARTZDYNE_TEMP_FOLDER                              QUARTZDYNE_CONFIDENTIAL_ROOT _T("Software-Eng\\Prog\\WWW\\Temp\\")
#define     QCOM_URL_DIR                                        QUARTZDYNE_QD_URL_DIR _T("QCOM/")
#define     QCOM_HELP_URL                                       QCOM_URL_DIR _T("QCOM-Help.php")
#define     QCOM_DOWNLOAD_URL                                   QCOM_URL_DIR _T("QCOM-Download.php")
#define     QCOM_COEFFICIENT_FILE_DOWNLOAD_URL                  QCOM_URL_DIR _T("CoefficientFilesDownload.php")
#define     QCOM_TC_CHECK_URL                                   QCOM_URL_DIR _T("QCOM-TC-Check.php")
#define     QCOM_VERSION_URL                                    QCOM_URL_DIR _T("CurrentVersion.QCOM")
#define     QCOM_PKG_URL_DIR                                    QCOM_URL_DIR _T("pkg/")
#define     QCOM_TEXT_MESSAGE_SOURCE                            _T("QCOM Notify <qcom.notify@gmail.com>")
#define     QCOM_EMAIL_MESSAGE_SOURCE                           QCOM_TEXT_MESSAGE_SOURCE
#define     QCOM_CREDENTIAL_PRIMARY                             _T("RERQ\x13TV\\RPd")
#define     QCOM_CREDENTIAL_SECONDARY                           _T("rfttB<>H")
#define     GMAIL_MAIL_SERVER                                   _T("smtp.gmail.com")
//----------------------------------------------------------------------------
// Utility macros
//----------------------------------------------------------------------------
#define     AtoX(C)                             (isdigit(((BYTE) (C))) ? ((C) - '0') : (toupper(((BYTE) (C))) - 'A' + 10))
#define     ClearArray(A)                       (Array::Clear((A), 0, (A)->Length)
#define     ClearBuffer(P,A)                    memset((void *) (P), 0, (size_t) (A))
#define     FahrenheitFromCelsius(C)            ((((C) * 9.0) / 5.0) + 32.0)
#define     FileExists(P)                       (!(_access((P), 0)))
#define     FunctionName()                      (String::Concat(__FUNCTION__)->Contains("::") ? \
                                                    String::Concat(__FUNCTION__)->Substring(String::Concat(__FUNCTION__)->IndexOf("::") + 2) : \
                                                    __FUNCTION__)
#define     HandleIsValid(H)                    ((H) && ((H) != INVALID_HANDLE_VALUE))
#define     Max(A,B)                            (((A) > (B)) ? (A) : (B))
#define     Min(A,B)                            (((A) < (B)) ? (A) : (B))
#define     Mult10(X)                           ((((X) << 2) + (X)) << 1)
#define     ReadBinary(P)                       gcnew BinaryReader(File::Open((P), FileMode::Open, FileAccess::Read))
#define     StringAfter(A,B)                    (A)->Substring((A)->IndexOf(B) + (B)->Length)
#define     StringICompare(A,B)                 String::Compare((A), (B), true)
#define     StringSet(S)                        ((S) && (S)->Length)
#define     WriteBinary(P)                      gcnew BinaryWriter(File::Open((P), FileMode::Create))
#define     XtoA(H)                             ((char) ((((H) & 0x0F) > 9) ? (((H) & 0x0F) + 'A' - 10) : (((H) & 0x0F) + '0')))
//----------------------------------------------------------------------------
// Modal macros
//----------------------------------------------------------------------------
#define     AnyMessageEnabled                   (QCOM_BasicMessagesEnabled || QCOM_ErrorMessagesEnabled || QCOM_VerboseMessagesEnabled || QCOM_DetailedMessagesEnabled)
#define     AnyNonErrorMessageEnabled           (QCOM_BasicMessagesEnabled || QCOM_VerboseMessagesEnabled || QCOM_DetailedMessagesEnabled)
#define     QModal(M,...)                       QCOM_ModalMessage(true, GUI_MODAL_ICON_INFORMATION, FunctionName(), (M), __VA_ARGS__)
#define     QModalB(M,...)                      QCOM_ModalMessage(QCOM_BasicMessagesEnabled, GUI_MODAL_ICON_WARNING, FunctionName(), (M), __VA_ARGS__)
#define     QModalD(M,...)                      QCOM_ModalMessage(QCOM_DetailedMessagesEnabled, GUI_MODAL_ICON_INFORMATION, FunctionName(), (M), __VA_ARGS__)
#define     QModalE(M,...)                      QCOM_ModalMessage(QCOM_ErrorMessagesEnabled, GUI_MODAL_ICON_ERROR, FunctionName(), (M), __VA_ARGS__)
#define     QModalT(T,M,...)                    QCOM_ModalMessage(true, GUI_MODAL_ICON_INFORMATION, (T), (M), __VA_ARGS__)
#define     QModalV(M,...)                      QCOM_ModalMessage(QCOM_VerboseMessagesEnabled, GUI_MODAL_ICON_INFORMATION, FunctionName(), (M), __VA_ARGS__)
#define     QModalX(M,...)                      QCOM_ModalMessage(QCOM_ExpMessagesEnabled, GUI_MODAL_ICON_INFORMATION, FunctionName(), (M), __VA_ARGS__)
//----------------------------------------------------------------------------
// Event recording macros
//----------------------------------------------------------------------------
#define     AnyEventLogEnabled                  (QCOM_EventLogBasicEnabled || QCOM_EventLogVerboseEnabled || QCOM_EventLogDetailedEnabled || QCOM_EventLogTestEnabled)
#define     RecordBasicEvent(S,...)             QCOM_RecordEvent(AnyEventLogEnabled, (S), __VA_ARGS__)
#define     RecordDetailedEvent(S,...)          QCOM_RecordEvent(QCOM_EventLogDetailedEnabled, (S), __VA_ARGS__)
#define     RecordErrorEvent(S,...)             QCOM_RecordEvent(AnyEventLogEnabled, String::Concat("!!! ", (S)), __VA_ARGS__)
#define     RecordTestEvent(S,...)              QCOM_RecordEvent(QCOM_EventLogTestEnabled, (S), __VA_ARGS__)
#define     RecordVerboseEvent(S,...)           QCOM_RecordEvent((QCOM_EventLogVerboseEnabled || QCOM_EventLogDetailedEnabled), (S), __VA_ARGS__)
#define     RecordEventUnconditional(S,...)     QCOM_RecordEvent(GUI_YES, (S), __VA_ARGS__)
//----------------------------------------------------------------------------
// Unit flags
//----------------------------------------------------------------------------
#define     QCOM_UNIT_ZERO_FLAG                                 0x00000000
#define     QCOM_UNIT_VALID                                     0x00000001
#define     QCOM_UNIT_ALLOCATED                                 0x00000002
#define     QCOM_UNIT_MODULE_SN_VALID                           0x00000004
#define     QCOM_UNIT_OPEN                                      0x00000008
#define     QCOM_UNIT_CONFIG_INFO_LOADED                        0x00000010
#define     QCOM_UNIT_REGISTRY_CHECKED                          0x00000020
#define     QCOM_UNIT_FIRMWARE_ID_PRESENT                       0x00000040
#define     QCOM_UNIT_CAN_COMMUNICATE                           0x00000080
#define     QCOM_UNIT_INITIAL_SETTINGS_SET                      0x00000100
#define     QCOM_UNIT_TRANSDUCER_PRESENT                        0x00000200
#define     QCOM_UNIT_TRANSDUCER_SN_VALID                       0x00000400
#define     QCOM_UNIT_INCLUDE_IN_SAMPLING                       0x00000800
#define     QCOM_UNIT_COEFFICIENT_FILE_SPECIFIED                0x00001000
#define     QCOM_UNIT_COEFFICIENTS_VERIFIED                     0x00002000
#define     QCOM_UNIT_INITIAL_READINGS                          0x00004000
#define     QCOM_UNIT_OK_TO_SAMPLE                              0x00008000
#define     QCOM_UNIT_DISPLAY_COUNTS                            0x00010000
#define     QCOM_UNIT_DISPLAY_COUNTS_IN_HEX                     0x00020000
#define     QCOM_UNIT_DISPLAY_ALT_UNITS                         0x00040000
#define     QCOM_UNIT_DISPLAY_FREQUENCIES                       0x00080000
#define     QCOM_UNIT_DISPLAY_VI_VALUES                         0x00100000
#define     QCOM_UNIT_BOOT_LOADER_MODE                          0x00200000
#define     QCOM_UNIT_FIRMWARE_UPDATING                         0x00400000
#define     QCOM_UNIT_FIRMWARE_UPDATED                          0x00800000
#define     QCOM_UNIT_SEND_TEXT_XD_READINGS                     0x01000000
#define     QCOM_UNIT_SEND_EMAIL_XD_READINGS                    0x02000000
#define     QCOM_UNIT_SEND_TEXT_ERROR_MESSAGES                  0x04000000
#define     QCOM_UNIT_SEND_EMAIL_ERROR_MESSAGES                 0x08000000
#define     QCOM_UNIT_CURRENTLY_SAMPLING                        0x10000000
#define     QCOM_UNIT_SEND_XD_READINGS                          0x20000000
#define     QCOM_UNIT_CMUX_BOX                                  0x40000000
#define     QCOM_UNIT_TRANSDUCER_POWER_ENABLED                  0x80000000
#define     QCOM_UNIT_DEFAULT_SETTINGS                          (QCOM_UNIT_ZERO_FLAG |                      \
                                                                    QCOM_UNIT_INCLUDE_IN_SAMPLING |         \
                                                                    QCOM_UNIT_ZERO_FLAG)
#define     QCOM_UNIT_INITIAL_SETTINGS                          (QCOM_UNIT_ZERO_FLAG |                      \
                                                                    QCOM_UNIT_DEFAULT_SETTINGS |            \
                                                                    QCOM_UNIT_ZERO_FLAG)
#define     QCOM_UNIT_DEFAULT_PERSISTENT_FLAGS                  (QCOM_UNIT_ZERO_FLAG |                      \
                                                                    QCOM_UNIT_DISPLAY_ALT_UNITS |           \
                                                                    QCOM_UNIT_DISPLAY_COUNTS |              \
                                                                    QCOM_UNIT_DISPLAY_COUNTS_IN_HEX |       \
                                                                    QCOM_UNIT_DISPLAY_FREQUENCIES |         \
                                                                    QCOM_UNIT_DISPLAY_VI_VALUES |           \
                                                                    QCOM_UNIT_ZERO_FLAG)
#define     QCOM_UNIT_HOT_PLUG_FLAGS                            (QCOM_UNIT_ZERO_FLAG |                      \
                                                                    QCOM_UNIT_ALLOCATED |                   \
                                                                    QCOM_UNIT_COEFFICIENT_FILE_SPECIFIED |  \
                                                                    QCOM_UNIT_CONFIG_INFO_LOADED |          \
                                                                    QCOM_UNIT_DISPLAY_ALT_UNITS |           \
                                                                    QCOM_UNIT_DISPLAY_COUNTS |              \
                                                                    QCOM_UNIT_DISPLAY_COUNTS_IN_HEX |       \
                                                                    QCOM_UNIT_DISPLAY_FREQUENCIES |         \
                                                                    QCOM_UNIT_DISPLAY_VI_VALUES |           \
                                                                    QCOM_UNIT_INCLUDE_IN_SAMPLING |         \
                                                                    QCOM_UNIT_INITIAL_SETTINGS_SET |        \
                                                                    QCOM_UNIT_SEND_EMAIL_ERROR_MESSAGES |   \
                                                                    QCOM_UNIT_SEND_EMAIL_XD_READINGS |      \
                                                                    QCOM_UNIT_SEND_TEXT_ERROR_MESSAGES |    \
                                                                    QCOM_UNIT_SEND_TEXT_XD_READINGS |       \
                                                                    QCOM_UNIT_SEND_XD_READINGS |            \
                                                                    QCOM_UNIT_ZERO_FLAG)
#define     QCOM_UNIT_READY                                     (QCOM_UNIT_VALID |                          \
                                                                    QCOM_UNIT_OK_TO_SAMPLE |                \
                                                                    QCOM_UNIT_OPEN |                        \
                                                                    QCOM_UNIT_TRANSDUCER_POWER_ENABLED)
//----------------------------------------------------------------------------
// Unit state flags
//----------------------------------------------------------------------------
#define     QCOM_UNIT_STATE_LOG_DATA_TRANSFER                   0x00000001
#define     QCOM_UNIT_STATE_TEST_DATA_TRANSFER                  0x00000002
//----------------------------------------------------------------------------
// Unit data log flags
//
// Available : Memory has been allocated for the data log
// Has Data : Memory contains log data, whether saved or not
// Data Unsaved : Memory contains log data not yet saved to file
//----------------------------------------------------------------------------
#define     QCOM_UNIT_LOG_ZERO_FLAG                             0x00000000
#define     QCOM_UNIT_LOG_AVAILABLE                             0x00000001
#define     QCOM_UNIT_LOG_CURRENTLY_LOGGING                     0x00000002
#define     QCOM_UNIT_LOG_DATA_PRESENT                          0x00000004
#define     QCOM_UNIT_LOG_DATA_UNSAVED                          0x00000008
#define     QCOM_UNIT_LOG_FILE_SPECIFIED                        0x00000010
#define     QCOM_UNIT_LOG_FILE_AUTO_SAVE                        0x00000020
#define     QCOM_UNIT_LOG_FILE_APPEND                           0x00000040
#define     QCOM_UNIT_LOG_FILE_PROMPT_OVERWRITE                 0x00000080
#define     QCOM_UNIT_LOG_FILE_BOTH_FORMATS                     0x00000100
#define     QCOM_UNIT_LOG_FILE_EMBED_CAPTION                    0x00000200
#define     QCOM_UNIT_LOG_SNAPSHOT_FILE_SPECIFIED               0x00000400
#define     QCOM_UNIT_LOG_SNAPSHOT_APPEND_OVERRIDE              0x00000800
#define     QCOM_UNIT_LOG_PREPEND_ENTRY_NUMBERS                 0x00001000
#define     QCOM_UNIT_LOG_DISPLAY_CAPTION_IN_LOG                0x00002000
#define     QCOM_UNIT_LOG_DISPLAY_WRAP                          0x00004000
#define     QCOM_UNIT_LOG_DISPLAY_SUMMARY                       0x00008000
#define     QCOM_UNIT_LOG_DISPLAY_COUNTS_IN_HEX                 0x00010000
#define     QCOM_UNIT_LOG_TIME_MS                               0x00040000
#define     QCOM_UNIT_LOG_COMMENT_TIME_STAMP                    0x00080000
#define     QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY                 0x00100000
//#define     QCOM_UNIT_LOG_DATA_STATE_CHANGED                    0x80000000
#define     QCOM_UNIT_LOG_RESERVED                              0x10200000
#define     QCOM_UNIT_LOG_DEFAULT_SETTINGS                      (QCOM_UNIT_LOG_ZERO_FLAG |                  \
                                                                    QCOM_UNIT_LOG_FILE_APPEND |             \
                                                                    QCOM_UNIT_LOG_FILE_AUTO_SAVE |          \
                                                                    QCOM_UNIT_LOG_PREPEND_ENTRY_NUMBERS |   \
                                                                    QCOM_UNIT_LOG_ZERO_FLAG)
#define     QCOM_UNIT_LOG_DEFAULT_PERSISTENT_FLAGS              (QCOM_UNIT_LOG_ZERO_FLAG |                  \
                                                                    QCOM_UNIT_LOG_COMMENT_TIME_STAMP |      \
                                                                    QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY |   \
                                                                    QCOM_UNIT_LOG_DISPLAY_CAPTION_IN_LOG |  \
                                                                    QCOM_UNIT_LOG_DISPLAY_COUNTS_IN_HEX |   \
                                                                    QCOM_UNIT_LOG_DISPLAY_SUMMARY |         \
                                                                    QCOM_UNIT_LOG_FILE_APPEND |             \
                                                                    QCOM_UNIT_LOG_FILE_AUTO_SAVE |          \
                                                                    QCOM_UNIT_LOG_FILE_BOTH_FORMATS |       \
                                                                    QCOM_UNIT_LOG_FILE_EMBED_CAPTION |      \
                                                                    QCOM_UNIT_LOG_PREPEND_ENTRY_NUMBERS |   \
                                                                    QCOM_UNIT_LOG_TIME_MS |                 \
                                                                    QCOM_UNIT_LOG_ZERO_FLAG)
#define     QCOM_UNIT_LOG_HOT_PLUG_FLAGS                        (QCOM_UNIT_LOG_ZERO_FLAG |                  \
                                                                    QCOM_UNIT_LOG_AVAILABLE |               \
                                                                    QCOM_UNIT_LOG_COMMENT_TIME_STAMP |      \
                                                                    QCOM_UNIT_LOG_DATA_PRESENT |            \
                                                                    QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY |   \
                                                                    QCOM_UNIT_LOG_DATA_UNSAVED |            \
                                                                    QCOM_UNIT_LOG_DISPLAY_CAPTION_IN_LOG |  \
                                                                    QCOM_UNIT_LOG_DISPLAY_COUNTS_IN_HEX |   \
                                                                    QCOM_UNIT_LOG_DISPLAY_SUMMARY |         \
                                                                    QCOM_UNIT_LOG_DISPLAY_WRAP |            \
                                                                    QCOM_UNIT_LOG_FILE_APPEND |             \
                                                                    QCOM_UNIT_LOG_FILE_AUTO_SAVE |          \
                                                                    QCOM_UNIT_LOG_FILE_BOTH_FORMATS |       \
                                                                    QCOM_UNIT_LOG_FILE_EMBED_CAPTION |      \
                                                                    QCOM_UNIT_LOG_FILE_PROMPT_OVERWRITE |   \
                                                                    QCOM_UNIT_LOG_PREPEND_ENTRY_NUMBERS |   \
                                                                    QCOM_UNIT_LOG_SNAPSHOT_APPEND_OVERRIDE |\
                                                                    QCOM_UNIT_LOG_TIME_MS |                 \
                                                                    QCOM_UNIT_LOG_ZERO_FLAG)
//                                                                    QCOM_UNIT_LOG_FILE_SPECIFIED |          \
//                                                                    QCOM_UNIT_LOG_SNAPSHOT_FILE_SPECIFIED | \
//----------------------------------------------------------------------------
// Unit data log points
//----------------------------------------------------------------------------
#define     QCOM_UNIT_LOG_PRESSURE_COUNT                        0x00000001
#define     QCOM_UNIT_LOG_PRESSURE_DEF                          0x00000002
#define     QCOM_UNIT_LOG_PRESSURE_ALT                          0x00000004
#define     QCOM_UNIT_LOG_PRESSURE_FREQUENCY                    0x00000008
#define     QCOM_UNIT_LOG_TEMP_COUNT                            0x00000010
#define     QCOM_UNIT_LOG_TEMP_DEF                              0x00000020
#define     QCOM_UNIT_LOG_TEMP_ALT                              0x00000040
#define     QCOM_UNIT_LOG_TEMP_FREQUENCY                        0x00000080
#define     QCOM_UNIT_LOG_DATE_STAMP                            0x00000100
#define     QCOM_UNIT_LOG_TIME_STAMP                            0x00000200
#define     QCOM_UNIT_LOG_XD_VOLTAGE                            0x00001000
#define     QCOM_UNIT_LOG_XD_AMPERAGE                           0x00002000
#define     QCOM_UNIT_LOG_ALL_POINTS                            (QCOM_UNIT_LOG_ZERO_FLAG |                  \
                                                                    QCOM_UNIT_LOG_DATE_STAMP |              \
                                                                    QCOM_UNIT_LOG_PRESSURE_ALT |            \
                                                                    QCOM_UNIT_LOG_PRESSURE_COUNT |          \
                                                                    QCOM_UNIT_LOG_PRESSURE_DEF |            \
                                                                    QCOM_UNIT_LOG_PRESSURE_FREQUENCY |      \
                                                                    QCOM_UNIT_LOG_TEMP_ALT |                \
                                                                    QCOM_UNIT_LOG_TEMP_COUNT |              \
                                                                    QCOM_UNIT_LOG_TEMP_DEF |                \
                                                                    QCOM_UNIT_LOG_TEMP_FREQUENCY |          \
                                                                    QCOM_UNIT_LOG_TIME_STAMP |              \
                                                                    QCOM_UNIT_LOG_XD_AMPERAGE |             \
                                                                    QCOM_UNIT_LOG_XD_VOLTAGE |              \
                                                                    QCOM_UNIT_LOG_ZERO_FLAG)
#define     QCOM_UNIT_LOG_DEFAULT_DATA_POINTS                   (QCOM_UNIT_LOG_ZERO_FLAG |                  \
                                                                    QCOM_UNIT_LOG_DATE_STAMP |              \
                                                                    QCOM_UNIT_LOG_PRESSURE_DEF |            \
                                                                    QCOM_UNIT_LOG_PRESSURE_FREQUENCY |      \
                                                                    QCOM_UNIT_LOG_TEMP_DEF |                \
                                                                    QCOM_UNIT_LOG_TEMP_FREQUENCY |          \
                                                                    QCOM_UNIT_LOG_TIME_STAMP |              \
                                                                    QCOM_UNIT_LOG_ZERO_FLAG)
#define     QCOM_UNIT_LOG_DEFAULT_PERSISTENT_POINTS             (QCOM_UNIT_LOG_ZERO_FLAG |                  \
                                                                    QCOM_UNIT_LOG_ALL_POINTS |              \
                                                                    QCOM_UNIT_LOG_ZERO_FLAG)
#define     QCOM_UNIT_LOG_HOT_PLUG_POINTS                       (QCOM_UNIT_LOG_ZERO_FLAG |                  \
                                                                    QCOM_UNIT_LOG_ALL_POINTS |              \
                                                                    QCOM_UNIT_LOG_ZERO_FLAG)
//----------------------------------------------------------------------------
// Unit test flags
//----------------------------------------------------------------------------
#define     QCOM_UNIT_TEST_ZERO_FLAG                            0x00000000
#define     QCOM_UNIT_TEST_AVAILABLE                            0x00000001
#define     QCOM_UNIT_TEST_CURRENTLY_TESTING                    0x00000002
#define     QCOM_UNIT_TEST_RESULTS_PRESENT                      0x00000004
#define     QCOM_UNIT_TEST_RESULTS_UNSAVED                      0x00000008
#define     QCOM_UNIT_TEST_RESULTS_FILE_SPECIFIED               0x00000010
#define     QCOM_UNIT_TEST_DATA_FILE_SPECIFIED                  0x00000020
#define     QCOM_UNIT_TEST_FW_FILE_SPECIFIED                    0x00000040
#define     QCOM_UNIT_TEST_DETAILED_LOG_AVAILABLE               0x00000080
#define     QCOM_UNIT_TEST_RESULTS_DISPLAYED                    0x00000100
#define     QCOM_UNIT_TEST_RESULTS_WRAP                         0x00000200
#define     QCOM_UNIT_TEST_RESULTS_APPEND                       0x00000400
#define     QCOM_UNIT_TEST_RESULTS_AUTO_SAVE                    0x00000800
#define     QCOM_UNIT_TEST_RESULTS_DETAILED                     0x00001000
#define     QCOM_UNIT_TEST_RESULTS_TIME_STAMP                   0x00002000
#define     QCOM_UNIT_TEST_RESULTS_STATE_CHANGED                0x00004000
#define     QCOM_UNIT_TEST_LOOPING_ENABLED                      0x00010000
#define     QCOM_UNIT_TEST_LOOP_FOREVER                         0x00020000
#define     QCOM_UNIT_TEST_STOP_ON_ERRORS                       0x00040000
#define     QCOM_UNIT_TEST_QMEM_TEST                            0x00100000
#define     QCOM_UNIT_TEST_I2C_TEST                             0x00200000
#define     QCOM_UNIT_TEST_READINGS_TEST                        0x00400000
#define     QCOM_UNIT_TEST_FIRMWARE_TEST                        0x00800000
#define     QCOM_UNIT_TEST_X2_TEST                              0x01000000
#define     QCOM_UNIT_TEST_X3_TEST                              0x02000000
#define     QCOM_UNIT_TEST_X4_TEST                              0x04000000
#define     QCOM_UNIT_TEST_XD_COMM_TEST                         0x10000000
#define     QCOM_UNIT_TEST_XD_INTEGRITY_TEST                    0x20000000
#define     QCOM_UNIT_TEST_XD_MEMORY_TEST                       0x40000000
#define     QCOM_UNIT_TEST_ALL_MODULE                           (QCOM_UNIT_TEST_ZERO_FLAG |                 \
                                                                    QCOM_UNIT_TEST_FIRMWARE_TEST |          \
                                                                    QCOM_UNIT_TEST_I2C_TEST |               \
                                                                    QCOM_UNIT_TEST_QMEM_TEST |              \
                                                                    QCOM_UNIT_TEST_READINGS_TEST |          \
                                                                    QCOM_UNIT_TEST_X2_TEST |                \
                                                                    QCOM_UNIT_TEST_X3_TEST |                \
                                                                    QCOM_UNIT_TEST_X4_TEST |                \
                                                                    QCOM_UNIT_TEST_ZERO_FLAG)
#define     QCOM_UNIT_TEST_ALL_TRANSDUCER                       (QCOM_UNIT_TEST_ZERO_FLAG |                 \
                                                                    QCOM_UNIT_TEST_XD_COMM_TEST |           \
                                                                    QCOM_UNIT_TEST_XD_INTEGRITY_TEST |      \
                                                                    QCOM_UNIT_TEST_XD_MEMORY_TEST |         \
                                                                    QCOM_UNIT_TEST_ZERO_FLAG)
#define     QCOM_UNIT_TEST_ALL                                  (QCOM_UNIT_TEST_ZERO_FLAG |                 \
                                                                    QCOM_UNIT_TEST_ALL_MODULE |             \
                                                                    QCOM_UNIT_TEST_ALL_TRANSDUCER |         \
                                                                    QCOM_UNIT_TEST_ZERO_FLAG)
#define     QCOM_UNIT_TEST_DEFAULT_SETTINGS                     (QCOM_UNIT_TEST_ZERO_FLAG |                 \
                                                                    QCOM_UNIT_TEST_RESULTS_AUTO_SAVE |      \
                                                                    QCOM_UNIT_TEST_RESULTS_DISPLAYED |      \
                                                                    QCOM_UNIT_TEST_ZERO_FLAG)
#define     QCOM_UNIT_TEST_INITIAL_SETTINGS                     (QCOM_UNIT_TEST_ZERO_FLAG |                 \
                                                                    QCOM_UNIT_TEST_DEFAULT_SETTINGS |       \
                                                                    QCOM_UNIT_TEST_ZERO_FLAG)
#define     QCOM_UNIT_TEST_DEFAULT_PERSISTENT_FLAGS             (QCOM_UNIT_TEST_ZERO_FLAG |                 \
                                                                    QCOM_UNIT_TEST_DEFAULT_SETTINGS |       \
                                                                    QCOM_UNIT_TEST_ALL_MODULE |             \
                                                                    QCOM_UNIT_TEST_RESULTS_APPEND |         \
                                                                    QCOM_UNIT_TEST_RESULTS_AUTO_SAVE |      \
                                                                    QCOM_UNIT_TEST_RESULTS_DETAILED |       \
                                                                    QCOM_UNIT_TEST_RESULTS_TIME_STAMP |     \
                                                                    QCOM_UNIT_TEST_RESULTS_WRAP |           \
                                                                    QCOM_UNIT_TEST_STOP_ON_ERRORS |         \
                                                                    QCOM_UNIT_TEST_ZERO_FLAG)
#define     QCOM_UNIT_TEST_HOT_PLUG_FLAGS                       (QCOM_UNIT_TEST_ZERO_FLAG |                 \
                                                                    QCOM_UNIT_TEST_ALL |                    \
                                                                    QCOM_UNIT_TEST_AVAILABLE |              \
                                                                    QCOM_UNIT_TEST_DETAILED_LOG_AVAILABLE | \
                                                                    QCOM_UNIT_TEST_LOOP_FOREVER |           \
                                                                    QCOM_UNIT_TEST_LOOPING_ENABLED |        \
                                                                    QCOM_UNIT_TEST_RESULTS_APPEND |         \
                                                                    QCOM_UNIT_TEST_RESULTS_AUTO_SAVE |      \
                                                                    QCOM_UNIT_TEST_RESULTS_DETAILED |       \
                                                                    QCOM_UNIT_TEST_RESULTS_DISPLAYED |      \
                                                                    QCOM_UNIT_TEST_RESULTS_FILE_SPECIFIED | \
                                                                    QCOM_UNIT_TEST_RESULTS_PRESENT |        \
                                                                    QCOM_UNIT_TEST_RESULTS_TIME_STAMP |     \
                                                                    QCOM_UNIT_TEST_RESULTS_UNSAVED |        \
                                                                    QCOM_UNIT_TEST_RESULTS_WRAP |           \
                                                                    QCOM_UNIT_TEST_STOP_ON_ERRORS |         \
                                                                    QCOM_UNIT_TEST_ZERO_FLAG)
//                                                                    QCOM_UNIT_TEST_DATA_FILE_SPECIFIED |    \
//                                                                    QCOM_UNIT_TEST_FW_FILE_SPECIFIED |      \
//----------------------------------------------------------------------------
// Unit test suites
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// Unit graphing flags
//----------------------------------------------------------------------------
#define     QCOM_UNIT_GRAPH_ZERO_FLAG                           0x00000000
#define     QCOM_UNIT_GRAPH_AVAILABLE                           0x00000001
#define     QCOM_UNIT_GRAPH_MILITARY_TIME_FORMAT                0x00000010
#define     QCOM_UNIT_GRAPH_THICK_LINES                         0x00000020
#define     QCOM_UNIT_GRAPH_SUPERIMPOSE_PT                      0x00000040
#define     QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW               0x00000080
#define     QCOM_UNIT_GRAPH_DEFAULT_SETTINGS                    (QCOM_UNIT_GRAPH_ZERO_FLAG |                \
                                                                    QCOM_UNIT_GRAPH_ZERO_FLAG)
#define     QCOM_UNIT_GRAPH_DEFAULT_PERSISTENT_FLAGS            (QCOM_UNIT_GRAPH_ZERO_FLAG |                \
                                                                    QCOM_UNIT_GRAPH_MILITARY_TIME_FORMAT |  \
                                                                    QCOM_UNIT_GRAPH_THICK_LINES |           \
                                                                    QCOM_UNIT_GRAPH_SUPERIMPOSE_PT |        \
                                                                    QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW |  \
                                                                    QCOM_UNIT_GRAPH_ZERO_FLAG)
#define     QCOM_UNIT_GRAPH_HOT_PLUG_FLAGS                      (QCOM_UNIT_GRAPH_ZERO_FLAG |                \
                                                                    QCOM_UNIT_GRAPH_MILITARY_TIME_FORMAT |  \
                                                                    QCOM_UNIT_GRAPH_THICK_LINES |           \
                                                                    QCOM_UNIT_GRAPH_SUPERIMPOSE_PT |        \
                                                                    QCOM_UNIT_GRAPH_DISPLAY_AMPERAGE_DRAW |  \
                                                                    QCOM_UNIT_GRAPH_ZERO_FLAG)
//----------------------------------------------------------------------------
// General Information flags
//----------------------------------------------------------------------------
#define     QCOM_GENERAL_ZERO_FLAG                              0x00000000
#define     QCOM_GENERAL_ALLOCATED                              0x00000001
#define     QCOM_GENERAL_USB_DRIVER_AVAILABLE                   0x00000002
#define     QCOM_GENERAL_USB_DLL_AVAILABLE                      0x00000004
#define     QCOM_GENERAL_USE_PATH_SPECIFIED                     0x00000008
#define     QCOM_GENERAL_STATUS_LINE_AVAILABLE                  0x00000010
#define     QCOM_GENERAL_EVENT_LOG_SPECIFIED                    0x00000020
#define     QCOM_GENERAL_CURRENTLY_SAMPLING                     0x00000040
#define     QCOM_GENERAL_SAMPLING_TIME_LIMITED                  0x00000080
#define     QCOM_GENERAL_GUI_READY_FOR_UPDATING                 0x00000100
#define     QCOM_GENERAL_GUI_UP_AND_RUNNING                     0x00000200
#define     QCOM_GENERAL_PROGRAM_TIMER_RUNNING                  0x00000400
//#define     QCOM_GENERAL_COMMAND_LINE_ONLY                      0x00000800
#define     QCOM_GENERAL_SOUNDS_ENABLED                         0x00001000
#define     QCOM_GENERAL_INCLUDE_ALL_IN_SAMPLING                0x00002000
#define     QCOM_GENERAL_ERROR_LOG_SPECIFIED                    0x00004000
#define     QCOM_GENERAL_PROCEED_TO_SAMPLE                      0x00008000
#define     QCOM_GENERAL_INTERNET_AVAILABLE                     0x00010000
#define     QCOM_GENERAL_DISPLAY_COUNTS                         0x00020000
#define     QCOM_GENERAL_DISPLAY_COUNTS_IN_HEX                  0x00040000
#define     QCOM_GENERAL_DISPLAY_ALT_UNITS                      0x00080000
#define     QCOM_GENERAL_DISPLAY_ALL_FREQUENCIES                0x00100000
#define     QCOM_GENERAL_DISPLAY_ALL_VI_VALUES                  0x00200000
#define     QCOM_GENERAL_FIRMWARE_UPDATING                      0x00400000
#define     QCOM_GENERAL_CONFIG_DONT_LOAD                       0x00800000
#define     QCOM_GENERAL_CONFIG_FILE_SPECIFIED                  0x01000000
#define     QCOM_GENERAL_CONFIG_INFO_LOADED                     0x02000000
#define     QCOM_GENERAL_CONFIG_DONT_SAVE                       0x04000000
#define     QCOM_GENERAL_CONFIG_DELETE_ON_EXIT                  0x08000000
#define     QCOM_GENERAL_PROGRAM_PAUSED                         0x10000000
#define     QCOM_GENERAL_PROGRAM_REDRAWING                      0x20000000
#define     QCOM_GENERAL_PROGRAM_EXITING                        0x40000000
#define     QCOM_GENERAL_EXPERT_MODE                            0x80000000
#define     QCOM_GENERAL_DEFAULT_SETTINGS                       (QCOM_GENERAL_ZERO_FLAG |                   \
                                                                    QCOM_GENERAL_SOUNDS_ENABLED |           \
                                                                    QCOM_GENERAL_ZERO_FLAG)
#define     QCOM_GENERAL_INITIAL_SETTINGS                       (QCOM_GENERAL_ZERO_FLAG |                   \
                                                                    QCOM_GENERAL_DEFAULT_SETTINGS |         \
                                                                    QCOM_GENERAL_ZERO_FLAG)
#define     QCOM_GENERAL_DEFAULT_PERSISTENT_FLAGS               (QCOM_GENERAL_ZERO_FLAG |                   \
                                                                    QCOM_GENERAL_DISPLAY_ALL_FREQUENCIES |  \
                                                                    QCOM_GENERAL_DISPLAY_ALL_VI_VALUES |    \
                                                                    QCOM_GENERAL_DISPLAY_ALT_UNITS |        \
                                                                    QCOM_GENERAL_DISPLAY_COUNTS |           \
                                                                    QCOM_GENERAL_DISPLAY_COUNTS_IN_HEX |    \
                                                                    QCOM_GENERAL_EXPERT_MODE |              \
                                                                    QCOM_GENERAL_SOUNDS_ENABLED |           \
                                                                    QCOM_GENERAL_ZERO_FLAG)
#define     QCOM_GENERAL_HOT_PLUG_FLAGS                         (QCOM_GENERAL_ZERO_FLAG |                   \
                                                                    QCOM_GENERAL_ALLOCATED |                \
                                                                    QCOM_GENERAL_CONFIG_FILE_SPECIFIED |    \
                                                                    QCOM_GENERAL_CONFIG_DELETE_ON_EXIT |    \
                                                                    QCOM_GENERAL_CONFIG_DONT_SAVE |         \
                                                                    QCOM_GENERAL_CONFIG_INFO_LOADED |       \
                                                                    QCOM_GENERAL_DISPLAY_ALL_FREQUENCIES |  \
                                                                    QCOM_GENERAL_DISPLAY_ALL_VI_VALUES |    \
                                                                    QCOM_GENERAL_DISPLAY_ALT_UNITS |        \
                                                                    QCOM_GENERAL_DISPLAY_COUNTS |           \
                                                                    QCOM_GENERAL_DISPLAY_COUNTS_IN_HEX |    \
                                                                    QCOM_GENERAL_ERROR_LOG_SPECIFIED |      \
                                                                    QCOM_GENERAL_EVENT_LOG_SPECIFIED |      \
                                                                    QCOM_GENERAL_EXPERT_MODE |              \
                                                                    QCOM_GENERAL_GUI_READY_FOR_UPDATING |   \
                                                                    QCOM_GENERAL_GUI_UP_AND_RUNNING |       \
                                                                    QCOM_GENERAL_INCLUDE_ALL_IN_SAMPLING |  \
                                                                    QCOM_GENERAL_PROGRAM_REDRAWING |        \
                                                                    QCOM_GENERAL_PROGRAM_TIMER_RUNNING |    \
                                                                    QCOM_GENERAL_SAMPLING_TIME_LIMITED |    \
                                                                    QCOM_GENERAL_SOUNDS_ENABLED |           \
                                                                    QCOM_GENERAL_STATUS_LINE_AVAILABLE |    \
                                                                    QCOM_GENERAL_USB_DLL_AVAILABLE |        \
                                                                    QCOM_GENERAL_USB_DRIVER_AVAILABLE |     \
                                                                    QCOM_GENERAL_USE_PATH_SPECIFIED |       \
                                                                    QCOM_GENERAL_ZERO_FLAG)
//----------------------------------------------------------------------------
// General state flags
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// General data log flags
//----------------------------------------------------------------------------
#define     QCOM_GENERAL_LOG_ZERO_FLAG                          0x00000000
#define     QCOM_GENERAL_LOG_LOGGING_AVAILABLE                  0x00000001
#define     QCOM_GENERAL_LOG_CURRENTLY_LOGGING                  0x00000002
#define     QCOM_GENERAL_LOG_DATA_PRESENT                       0x00000004
#define     QCOM_GENERAL_LOG_DATA_UNSAVED                       0x00000008
#define     QCOM_GENERAL_LOG_FILE_BOTH_FORMATS                  0x00000100
#define     QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS              0x00001000
#define     QCOM_GENERAL_LOG_DISPLAY_WRAP                       0x00004000
#define     QCOM_GENERAL_LOG_DISPLAY_SUMMARIES                  0x00008000
#define     QCOM_GENERAL_LOG_COMMENTS_TIME_STAMP                0x00080000
#define     QCOM_GENERAL_LOG_DATA_SAVE_IMMEDIATELY              0x00100000
#define     QCOM_GENERAL_LOG_ALL_LOGGING                        0x00200000
#define     QCOM_GENERAL_LOG_DONT_SAVE_ON_EXIT                  0x10000000
#define     QCOM_GENERAL_LOG_RESERVED                           0x80052EF0
#define     QCOM_GENERAL_LOG_DEFAULT_SETTINGS                   (QCOM_GENERAL_LOG_ZERO_FLAG |                   \
                                                                    QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS |    \
                                                                    QCOM_GENERAL_LOG_ZERO_FLAG)
#define     QCOM_GENERAL_LOG_INITIAL_SETTINGS                   (QCOM_GENERAL_LOG_ZERO_FLAG |                   \
                                                                    QCOM_GENERAL_LOG_DEFAULT_SETTINGS |         \
                                                                    QCOM_GENERAL_LOG_ZERO_FLAG)
#define     QCOM_GENERAL_LOG_DEFAULT_PERSISTENT_FLAGS           (QCOM_GENERAL_LOG_ZERO_FLAG |                   \
                                                                    QCOM_GENERAL_LOG_COMMENTS_TIME_STAMP |      \
                                                                    QCOM_GENERAL_LOG_DATA_SAVE_IMMEDIATELY |    \
                                                                    QCOM_GENERAL_LOG_DISPLAY_SUMMARIES |        \
                                                                    QCOM_GENERAL_LOG_DISPLAY_WRAP |             \
                                                                    QCOM_GENERAL_LOG_DONT_SAVE_ON_EXIT |        \
                                                                    QCOM_GENERAL_LOG_FILE_BOTH_FORMATS |        \
                                                                    QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS |    \
                                                                    QCOM_GENERAL_LOG_ZERO_FLAG)
#define     QCOM_GENERAL_LOG_HOT_PLUG_FLAGS                     (QCOM_GENERAL_LOG_ZERO_FLAG |                   \
                                                                    QCOM_GENERAL_LOG_COMMENTS_TIME_STAMP |      \
                                                                    QCOM_GENERAL_LOG_DATA_PRESENT |             \
                                                                    QCOM_GENERAL_LOG_DATA_SAVE_IMMEDIATELY |    \
                                                                    QCOM_GENERAL_LOG_DATA_UNSAVED |             \
                                                                    QCOM_GENERAL_LOG_DISPLAY_SUMMARIES |        \
                                                                    QCOM_GENERAL_LOG_DISPLAY_WRAP |             \
                                                                    QCOM_GENERAL_LOG_DONT_SAVE_ON_EXIT |        \
                                                                    QCOM_GENERAL_LOG_FILE_BOTH_FORMATS |        \
                                                                    QCOM_GENERAL_LOG_LOGGING_AVAILABLE |        \
                                                                    QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS |    \
                                                                    QCOM_GENERAL_LOG_ZERO_FLAG)
//----------------------------------------------------------------------------
// General data log points
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// General test flags
//----------------------------------------------------------------------------
#define     QCOM_GENERAL_TEST_ZERO_FLAG                         0x00000000
#define     QCOM_GENERAL_TEST_TESTING_AVAILABLE                 0x00000001
#define     QCOM_GENERAL_TEST_DISPLAY_XD_TESTS                  0x00000010
#define     QCOM_GENERAL_TEST_CURRENTLY_TESTING                 0x00000100
#define     QCOM_GENERAL_TEST_RESULTS_PRESENT                   0x00000200
#define     QCOM_GENERAL_TEST_RESULTS_UNSAVED                   0x00000400
#define     QCOM_GENERAL_TEST_TESTS_SELECTED                    0x00000800
#define     QCOM_GENERAL_TEST_RESULTS_DISPLAYED                 0x00001000
#define     QCOM_GENERAL_TEST_RESULTS_WRAP                      0x00002000
#define     QCOM_GENERAL_TEST_RESULTS_APPEND                    0x00004000
#define     QCOM_GENERAL_TEST_RESULTS_AUTO_SAVE                 0x00008000
#define     QCOM_GENERAL_TEST_RESULTS_DETAILED                  0x00010000
#define     QCOM_GENERAL_TEST_RESULTS_TIME_STAMP                0x00020000
#define     QCOM_GENERAL_TEST_LOOPING_ENABLED                   0x00100000
#define     QCOM_GENERAL_TEST_LOOP_FOREVER                      0x00200000
#define     QCOM_GENERAL_TEST_STOP_ON_ERRORS                    0x00400000
#define     QCOM_GENERAL_TEST_TIME_STAMP_COMMENTS               0x00800000
#define     QCOM_GENERAL_TEST_DONT_SAVE_ON_EXIT                 0x01000000
#define     QCOM_GENERAL_TEST_FIRMWARE_TEST_RUNNING             0x10000000
#define     QCOM_GENERAL_TEST_DEFAULT_SETTINGS                  (QCOM_GENERAL_TEST_ZERO_FLAG |              \
                                                                    QCOM_GENERAL_TEST_RESULTS_AUTO_SAVE |   \
                                                                    QCOM_GENERAL_TEST_RESULTS_DISPLAYED |   \
                                                                    QCOM_GENERAL_TEST_ZERO_FLAG)
#define     QCOM_GENERAL_TEST_INITIAL_SETTINGS                  (QCOM_GENERAL_TEST_ZERO_FLAG |              \
                                                                    QCOM_GENERAL_TEST_DEFAULT_SETTINGS |    \
                                                                    QCOM_GENERAL_TEST_ZERO_FLAG)
#define     QCOM_GENERAL_TEST_DEFAULT_PERSISTENT_FLAGS          (QCOM_GENERAL_TEST_ZERO_FLAG |              \
                                                                    QCOM_GENERAL_TEST_DONT_SAVE_ON_EXIT |   \
                                                                    QCOM_GENERAL_TEST_RESULTS_APPEND |      \
                                                                    QCOM_GENERAL_TEST_RESULTS_AUTO_SAVE |   \
                                                                    QCOM_GENERAL_TEST_RESULTS_DETAILED |    \
                                                                    QCOM_GENERAL_TEST_RESULTS_DISPLAYED |   \
                                                                    QCOM_GENERAL_TEST_RESULTS_WRAP |        \
                                                                    QCOM_GENERAL_TEST_STOP_ON_ERRORS |      \
                                                                    QCOM_GENERAL_TEST_TIME_STAMP_COMMENTS | \
                                                                    QCOM_GENERAL_TEST_ZERO_FLAG)
#define     QCOM_GENERAL_TEST_HOT_PLUG_FLAGS                    (QCOM_GENERAL_TEST_ZERO_FLAG |              \
                                                                    QCOM_GENERAL_TEST_DISPLAY_XD_TESTS |    \
                                                                    QCOM_GENERAL_TEST_DONT_SAVE_ON_EXIT |   \
                                                                    QCOM_GENERAL_TEST_LOOP_FOREVER |        \
                                                                    QCOM_GENERAL_TEST_LOOPING_ENABLED |     \
                                                                    QCOM_GENERAL_TEST_RESULTS_APPEND |      \
                                                                    QCOM_GENERAL_TEST_RESULTS_AUTO_SAVE |   \
                                                                    QCOM_GENERAL_TEST_RESULTS_DETAILED |    \
                                                                    QCOM_GENERAL_TEST_RESULTS_DISPLAYED |   \
                                                                    QCOM_GENERAL_TEST_RESULTS_PRESENT |     \
                                                                    QCOM_GENERAL_TEST_RESULTS_UNSAVED |     \
                                                                    QCOM_GENERAL_TEST_RESULTS_TIME_STAMP |  \
                                                                    QCOM_GENERAL_TEST_RESULTS_WRAP |        \
                                                                    QCOM_GENERAL_TEST_STOP_ON_ERRORS |      \
                                                                    QCOM_GENERAL_TEST_TESTING_AVAILABLE |   \
                                                                    QCOM_GENERAL_TEST_TIME_STAMP_COMMENTS | \
                                                                    QCOM_GENERAL_TEST_ZERO_FLAG)
//----------------------------------------------------------------------------
// General test suites
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// Unit pointer macros
//----------------------------------------------------------------------------
#define     QCOM_UnitLegal(U)                   ((U) && QCOM_UnitNumberLegal((U)->unitNumber))
#define     QCOM_UnitOpen(U)                    ((U) && (((U)->flags & \
                                                    (QCOM_UNIT_VALID | QCOM_UNIT_OPEN)) == \
                                                    (QCOM_UNIT_VALID | QCOM_UNIT_OPEN)))
#define     QCOM_UnitReady(U)                   ((U) && (((U)->flags & \
                                                    QCOM_UNIT_READY) == \
                                                    QCOM_UNIT_READY))
#define     QCOM_UnitValid(U)                   ((U) && (((U)->flags & \
                                                    QCOM_UNIT_VALID) == \
                                                    QCOM_UNIT_VALID))
#define     QCOM_UnitLogReady(U)                ((U) && (((U)->dataLogFlags & \
                                                    QCOM_UNIT_LOG_AVAILABLE) == \
                                                    QCOM_UNIT_LOG_AVAILABLE))
//----------------------------------------------------------------------------
// Unit number macros
//----------------------------------------------------------------------------
#define     QCOM_UnitNumberLegal(UN)            (((UN) <= QCOM_MAXIMUM_NUMBER_OF_UNITS) && QCOM_UnitInfoArray[UN])
#define     QCOM_UnitNumberOpen(UN)             (QCOM_UnitNumberLegal(UN) && ((QCOM_UnitInfoArray[UN]->flags & \
                                                    (QCOM_UNIT_VALID | QCOM_UNIT_OPEN)) == \
                                                    (QCOM_UNIT_VALID | QCOM_UNIT_OPEN)))
#define     QCOM_UnitNumberReady(UN)            (QCOM_UnitNumberLegal(UN) && ((QCOM_UnitInfoArray[UN]->flags & \
                                                    QCOM_UNIT_READY) == \
                                                    QCOM_UNIT_READY))
#define     QCOM_UnitNumberValid(UN)            (QCOM_UnitNumberLegal(UN) && ((QCOM_UnitInfoArray[UN]->flags & \
                                                    QCOM_UNIT_VALID) == \
                                                    QCOM_UNIT_VALID))
//----------------------------------------------------------------------------
// Other unit macros
//----------------------------------------------------------------------------
#define     QCOM_CFKnown(U)                     ((U) && ((U)->flags & QCOM_UNIT_COEFFICIENT_FILE_SPECIFIED))
#define     QCOM_ModuleIsCalMux(U)              ((U) && ((U)->flags & QCOM_UNIT_CMUX_BOX))
#define     QCOM_ModuleSNValid(U)               ((U) && ((U)->flags & QCOM_UNIT_MODULE_SN_VALID))
#define     QCOM_XDPresent(U)                   ((U) && ((U)->flags & QCOM_UNIT_TRANSDUCER_PRESENT))
#define     QCOM_XDSNValid(U)                   ((U) && ((U)->flags & QCOM_UNIT_TRANSDUCER_SN_VALID))
#define     QCOM_LogDataPresent(U)              ((U) && ((U)->dataLogFlags & QCOM_UNIT_LOG_DATA_PRESENT))
#define     QCOM_LogFileKnown(U)                ((U) && ((U)->dataLogFlags & QCOM_UNIT_LOG_FILE_SPECIFIED))
#define     QCOM_LogSSFileKnown(U)              ((U) && ((U)->dataLogFlags & QCOM_UNIT_LOG_SNAPSHOT_FILE_SPECIFIED))
#define     QCOM_TestResultsDetailed(U)         ((U) && ((U)->testFlags & QCOM_UNIT_TEST_RESULTS_DETAILED))
#define     QCOM_TestResultsDisplayed(U)        ((U) && ((U)->testFlags & QCOM_UNIT_TEST_RESULTS_DISPLAYED))
#define     QCOM_TestResultsPresent(U)          ((U) && ((U)->testFlags & QCOM_UNIT_TEST_RESULTS_PRESENT))
#define     QCOM_TRFileKnown(U)                 ((U) && ((U)->testFlags & QCOM_UNIT_TEST_RESULTS_FILE_SPECIFIED))
#define     QCOM_XDIsFrequency(U)               ((U) && ((U)->transducerType == QD_TRANSDUCER_TYPE_FREQUENCY))
#define     QCOM_XDIsDigitalNoMem(U)            ((U) && ((U)->transducerType == QD_TRANSDUCER_TYPE_DIGITAL_NOMEM))
//----------------------------------------------------------------------------
// General shortcut macros
//----------------------------------------------------------------------------
#define     QCOM_SafeToRun()                    (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING) &&            \
                                                    !(QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING) && \
                                                    !(QCOM_GeneralInfo->flags & QCOM_GENERAL_FIRMWARE_UPDATING) &&          \
                                                    !(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_REDRAWING))
//----------------------------------------------------------------------------
// Compound macros
//----------------------------------------------------------------------------
#define     QCOM_SetErrorLogPath(P)                                                     \
                {                                                                       \
                    if (QCOM_GeneralInfo && StringSet(P))                               \
                    {                                                                   \
                        QCOM_GeneralInfo->errorLogPath = (P);                           \
                        QCOM_GeneralInfo->flags |= QCOM_GENERAL_ERROR_LOG_SPECIFIED;    \
                    }                                                                   \
                }
#define     QCOM_SetEventLogPath(P)                                                     \
                {                                                                       \
                    if (QCOM_GeneralInfo && StringSet(P))                               \
                    {                                                                   \
                        QCOM_GeneralInfo->eventLogPath = (P);                           \
                        QCOM_GeneralInfo->mostRecentEventLogPath = (P);                 \
                        QCOM_GeneralInfo->flags |= QCOM_GENERAL_EVENT_LOG_SPECIFIED;    \
                    }                                                                   \
                }
#define     QCOM_SetGeneralUsePath(P)                                                   \
                {                                                                       \
                    if (QCOM_GeneralInfo && StringSet(P))                               \
                    {                                                                   \
                        QCOM_GeneralInfo->generalUsePath = (P);                         \
                        QCOM_GeneralInfo->flags |= QCOM_GENERAL_USE_PATH_SPECIFIED;     \
                    }                                                                   \
                }
#define     QCOM_SetCoefficientFilePath(U,P)                                            \
                {                                                                       \
                    if ((U) && StringSet(P))                                            \
                    {                                                                   \
                        (U)->coefficientFilePath = (P);                                 \
                        (U)->flags |= QCOM_UNIT_COEFFICIENT_FILE_SPECIFIED;             \
                    }                                                                   \
                }
#define     QCOM_SetTestDataFilePath(U,P)                                               \
                {                                                                       \
                    if ((U) && StringSet(P))                                            \
                    {                                                                   \
                        (U)->testDataFilePath = (P);                                    \
                        (U)->flags |= QCOM_UNIT_TEST_DATA_FILE_SPECIFIED;               \
                    }                                                                   \
                }
#define     QCOM_SetTestFirmwareFilePath(U,P)                                           \
                {                                                                       \
                    if ((U) && StringSet(P))                                            \
                    {                                                                   \
                        (U)->testFirmwareFilePath = (P);                                \
                        (U)->flags |= QCOM_UNIT_TEST_FW_FILE_SPECIFIED;                 \
                    }                                                                   \
                }
//----------------------------------------------------------------------------
#endif      // QCOMDEFS_H
//============================================================================
// End of QCOMDefs.h
//============================================================================
