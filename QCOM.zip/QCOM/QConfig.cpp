//============================================================================
// QConfig.cpp
//
// Functions for handling program configuration, error log, and event log tasks
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     QCONFIG_CPP
#define     QCONFIG_CPP
#include    "QConfig.h"
//----------------------------------------------------------------------------
// QCOM_ConcludeErrorLog
//
// Finishes the error log by adding a footer to the file
//
// Called by:   QCOM_ConcludeGeneralLogs
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConcludeErrorLog(
    String          ^finalErrorEntry)
{
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^lineString;
    DateTime        dateTime = DateTime::Now;
    StreamWriter    ^textWriter;
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_ERROR_LOG_SPECIFIED)
    {
        RecordEventUnconditional(finalErrorEntry);
        textWriter = File::AppendText(QCOM_GeneralInfo->errorLogPath);
        if (textWriter)
        {
            textWriter->WriteLine(border);
            lineString = String::Format(
                "# {0} concluded on {1:D2} {2} {3:D4} at {4:D2}:{5:D2}:{6:D2}",
                Path::GetFileName(QCOM_GeneralInfo->errorLogPath),
                dateTime.Day,
                QCOM_MonthStringArray[dateTime.Month],
                dateTime.Year,
                dateTime.Hour,
                dateTime.Minute,
                dateTime.Second);
            textWriter->WriteLine(lineString);
            textWriter->WriteLine(border);
            textWriter->Close();
        }
        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_ERROR_LOG_SPECIFIED;
    }
}                                       // end of QCOM_ConcludeErrorLog()
//----------------------------------------------------------------------------
// QCOM_ConcludeEventLog
//
// Finishes the event log by adding a footer to the file
//
// Called by:   QCOM_ConcludeGeneralLogs
//              QCOM_ToolStripEventLogBasicDropDownClicked
//              QCOM_ToolStripEventLogDetailedDropDownClicked
//              QCOM_ToolStripEventLogTestDropDownClicked
//              QCOM_ToolStripEventLogVerboseDropDownClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConcludeEventLog(
    String          ^finalEventEntry)
{
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^lineString;
    DateTime        dateTime = DateTime::Now;
    StreamWriter    ^textWriter;
    //------------------------------------------------------------------------
    if (QCOM_CurrentlyEventLogging && (QCOM_GeneralInfo->flags & QCOM_GENERAL_EVENT_LOG_SPECIFIED))
    {
        RecordEventUnconditional("    All event logging stopped");
        RecordEventUnconditional(finalEventEntry);
        textWriter = File::AppendText(QCOM_GeneralInfo->eventLogPath);
        if (textWriter)
        {
            textWriter->WriteLine(border);
            lineString = String::Format(
                "# {0} concluded on {1:D2} {2} {3:D4} at {4:D2}:{5:D2}:{6:D2}",
                Path::GetFileName(QCOM_GeneralInfo->eventLogPath),
                dateTime.Day,
                QCOM_MonthStringArray[dateTime.Month],
                dateTime.Year,
                dateTime.Hour,
                dateTime.Minute,
                dateTime.Second);
            textWriter->WriteLine(lineString);
            textWriter->WriteLine(border);
            textWriter->Close();
        }
        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_EVENT_LOG_SPECIFIED;
        QCOM_CurrentlyEventLogging = GUI_NO;
        QCOM_UpdateDeleteLogFilesDropDown();
    }
}                                       // end of QCOM_ConcludeEventLog()
//----------------------------------------------------------------------------
// QCOM_ConcludeGeneralLogs
//
// Finishes the error and event log files
//
// Called by:   QCOM_Finalize
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConcludeGeneralLogs(
    String          ^finalEventEntry)
{
    //------------------------------------------------------------------------
    QCOM_ConcludeErrorLog(String::Empty);
    QCOM_ConcludeEventLog(finalEventEntry);
}                                       // end of QCOM_ConcludeGeneralLogs()
//----------------------------------------------------------------------------
// QCOM_EstablishErrorLog
//
// Creates a new error log file
//
// Called by:   QCOM_InitializeSoftwareBase
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_EstablishErrorLog(void)
{
    bool            logHasEntries;
    int             fileInstance = 1;
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^fileString;
    String          ^lineString;
    String          ^pathString;
    StreamReader    ^textReader;
    StreamWriter    ^textWriter;
    DateTime        dateTime = DateTime::Now;
    //------------------------------------------------------------------------
    ModalD("Loc 2.3.1 : QCOM_GeneralInfo is {0}",
        (QCOM_GeneralInfo ? "valid" : "invalid"));
    if (QCOM_GeneralInfo)
    {
        ModalD("Loc 2.3.2 : Just before calling QCOM_EstablishLogDirectory");
        QCOM_EstablishLogDirectory();
        ModalD("Loc 2.3.3 : Just after calling QCOM_EstablishLogDirectory");
        if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_ERROR_LOG_SPECIFIED))
        {
            do
            {
                fileString = String::Format(
                    "QCOM-ErrorLog-{0:D2}{1:D2}{2:D2}-{3:D3}.log",
                    (dateTime.Year % 100),
                    dateTime.Month,
                    dateTime.Day,
                    fileInstance);
                pathString = String::Concat(
                    QCOM_GeneralInfo->logDirectory,
                    QCOM_STRING_BACKSLASH,
                    fileString);
                logHasEntries = GUI_NO;
                if (File::Exists(pathString))
                {
                    textReader = File::OpenText(pathString);
                    if (textReader)
                    {
                        while (lineString = textReader->ReadLine())
                        {
                            lineString = lineString->Trim();
                            if (!lineString->StartsWith("#"))
                            {
                                logHasEntries = GUI_YES;
                                fileInstance++;
                                break;
                            }
                        }
                        textReader->Close();
                    }
                }
                if (fileInstance >= 1000)
                {
                    Modal("The error log could not be created");
                }
            }
            while (File::Exists(pathString) && logHasEntries);
            if (File::Exists(pathString))
            {
                ModalD("Loc 2.3.4 : The file will be deleted:\n{0}", pathString);
                File::Delete(pathString);
                Thread::Sleep(100);
                ModalD("Loc 2.3.5 : The file {0} deleted:\n{1}",
                    (File::Exists(pathString) ? "failed to be" : "was"),
                    pathString);
            }
            textWriter = File::CreateText(pathString);
            ModalD("Loc 2.3.6 : The file {0} created:\n{1}",
                (textWriter ? "was" : "failed to be"),
                pathString);
            if (textWriter)
            {
                //------------------------------------------------------------
                // Write out the header, including the program name and the
                // current date and time
                //------------------------------------------------------------
                textWriter->WriteLine(border);
                lineString = String::Format(
                    "# {0}\n#\n"
                    "# QCOM Error Log File (QCOM v{1} build {2})\n#\n"
                    "# Created on {3:D2} {4} {5:D4} at {6:D2}:{7:D2}:{8:D2}",
                    fileString,
                    QCOM_PROGRAM_VERSION_STRING,
                    QCOM_BuildNumber,
                    dateTime.Day,
                    QCOM_MonthStringArray[dateTime.Month],
                    dateTime.Year,
                    dateTime.Hour,
                    dateTime.Minute,
                    dateTime.Second);
                textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
                textWriter->WriteLine(border);
                QCOM_SetErrorLogPath(pathString);
                textWriter->Close();
                RecordBasicEvent("Error Log created as\n{0}", QCOM_GeneralInfo->errorLogPath);
            }
        }                               // end of if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_ERROR_LOG_SPECIFIED))
    }                                   // end of if (QCOM_GeneralInfo)
    ModalD("Loc 2.3.7 : End of QCOM_EstablishErrorLog");
}                                       // end of QCOM_EstablishErrorLog()
//----------------------------------------------------------------------------
// QCOM_EstablishEventLog
//
// Creates a new event log file if an event is enabled
//
// Called by:   QCOM_InitializeSoftwareBase
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_EstablishEventLog(
    String          ^initialEventEntry)
{
    bool            eventLogLocated = GUI_NO;
    int             fileInstance = 1;
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^fileString;
    String          ^lineString;
    String          ^pathString;
    StreamWriter    ^textWriter;
    DateTime        dateTime = DateTime::Now;
    //------------------------------------------------------------------------
    ModalD("Loc 2.4.1 : QCOM_GeneralInfo is {0}",
        (QCOM_GeneralInfo ? "valid" : "invalid"));
    if (QCOM_GeneralInfo)
    {
        ModalD("Loc 2.4.2 : Just before calling QCOM_EstablishLogDirectory");
        QCOM_EstablishLogDirectory();
        ModalD("Loc 2.4.3 : Just after calling QCOM_EstablishLogDirectory");
        //--------------------------------------------------------------------
        // Stop event logging if it is already going
        //--------------------------------------------------------------------
        QCOM_ConcludeEventLog(String::Empty);
        if (AnyEventLogEnabled && !(QCOM_GeneralInfo->flags & QCOM_GENERAL_EVENT_LOG_SPECIFIED))
        {
            do
            {
                fileString = String::Format(
                    "QCOM-EventLog-{0:D2}{1:D2}{2:D2}-{3:D3}.log",
                    (dateTime.Year % 100),
                    dateTime.Month,
                    dateTime.Day,
                    fileInstance);
                pathString = String::Concat(
                    QCOM_GeneralInfo->logDirectory,
                    QCOM_STRING_BACKSLASH,
                    fileString);
                if (File::Exists(pathString))
                    fileInstance++;
                if (fileInstance >= 1000)
                {
                    Modal("The event log could not be created");
                }
            }
            while (File::Exists(pathString));
            QCOM_CurrentlyEventLogging = GUI_YES;
            textWriter = File::CreateText(pathString);
            ModalD("Loc 2.4.4 : The file {0} created:\n{1}",
                (textWriter ? "was" : "failed to be"),
                pathString);
            if (textWriter)
            {
                //------------------------------------------------------------
                // Write out the header, including the program name and the
                // current date and time
                //------------------------------------------------------------
                textWriter->WriteLine(border);
                lineString = String::Format(
                    "# {0}\n#\n"
                    "# QCOM Event Log File (QCOM v{1} build {2})\n#\n"
                    "# Created on {3:D2} {4} {5:D4} at {6:D2}:{7:D2}:{8:D2}",
                    fileString,
                    QCOM_PROGRAM_VERSION_STRING,
                    QCOM_BuildNumber,
                    dateTime.Day,
                    QCOM_MonthStringArray[dateTime.Month],
                    dateTime.Year,
                    dateTime.Hour,
                    dateTime.Minute,
                    dateTime.Second);
                textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
                textWriter->WriteLine(border);
                textWriter->Close();
                //------------------------------------------------------------
                // Store the newly created path and set the
                // QCOM_GENERAL_EVENT_LOG_SPECIFIED flag
                //------------------------------------------------------------
                QCOM_SetEventLogPath(pathString);
                eventLogLocated = GUI_YES;
                RecordBasicEvent(initialEventEntry);
                RecordBasicEvent("Event Log created as\n{0}\n{1} Event Log started",
                    pathString,
                    (QCOM_EventLogDetailedEnabled ? "Detailed" : (QCOM_EventLogVerboseEnabled ? "Verbose" : "Basic")));
            }                           // end of if (textWriter)
        }                               // end of if (AnyEventLogEnabled && ...)
        ModalD("Loc 2.4.5 : Just before searching for the most recent event log");
        //--------------------------------------------------------------------
        // Search for the most recent event log, if any exists
        //--------------------------------------------------------------------
        if (!eventLogLocated)
        {
            String ^latestPath = String::Empty;
            String ^logDir = String::Concat(
                QCOM_GeneralInfo->logDirectory,
                QCOM_STRING_BACKSLASH);
            array <String ^> ^eventLogFiles = Directory::GetFiles(logDir, "QCOM-EventLog-*.log");
            if (StringSet(eventLogFiles))
            {
                for each (String ^pathString in eventLogFiles)
                {
                    if (StringSet(latestPath))
                    {
                        if (StringICompare(pathString, latestPath) > 0)
                            latestPath = pathString;
                    }
                    else
                        latestPath = pathString;
                }
                if (StringSet(latestPath) && File::Exists(latestPath))
                {
                    QCOM_GeneralInfo->mostRecentEventLogPath = latestPath;
                    eventLogLocated = GUI_YES;
                }
            }
            delete [] eventLogFiles;
        }                               // end of if (!eventLogLocated)
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_GUI_UP_AND_RUNNING)
            QCOM_UpdateDeleteLogFilesDropDown();
    }                                   // end of if (QCOM_GeneralInfo)
    ModalD("Loc 2.4.6 : End of QCOM_EstablishEventLog");
}                                       // end of QCOM_EstablishEventLog()
//----------------------------------------------------------------------------
// QCOM_EstablishLogDirectory
//
// Ensures the QLog directory exists in the current working directory, and
// stores the directory path string
//
// Called by:   QCOM_InitializeSoftwareBase
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_EstablishLogDirectory(void)
{
    //------------------------------------------------------------------------
    ModalD("Loc 2.3.2.1 : QCOM_General is {0}",
        (QCOM_GeneralInfo ? "valid" : "invalid"));
    if (QCOM_GeneralInfo)
    {
        if (String::IsNullOrEmpty(QCOM_GeneralInfo->logDirectory))
        {
            String ^pathString = String::Concat(
                Application::StartupPath,
                QCOM_STRING_BACKSLASH,
                QCOM_LOG_DIRECTORY);
            QCOM_GeneralInfo->logDirectory = pathString;
            try
            {
                if (!Directory::Exists(pathString))
                {
                    ModalD("Loc 2.3.2.2 : The directory will be created:\n{0}", pathString);
                    Directory::CreateDirectory(pathString);
                    Thread::Sleep(100);
                    ModalD("Loc 2.3.2.3 : The directory {0} created:\n{1}",
                        (Directory::Exists(pathString) ? "was" : "failed to be"),
                        pathString);
                }
                if (!Directory::Exists(pathString))
                {
                    QCOM_GeneralInfo->logDirectory = String::Empty;
                }
            }
            catch (Exception ^ex)
            {
                RecordErrorEvent("Problem creating the log directory\n{0} :\n{1}",
                    pathString, ex->Message);
                Modal("The log folder could not be created:\n{0}\n\n"
                    "Create the folder manually, then allow all users\n"
                    "on this computer rights to modify this folder\n\n"
                    "The program will now exit",
                    pathString);
                Environment::Exit(QCOM_SUCCESS);
            }
            delete pathString;
        }
    }
    ModalD("Loc 2.3.2.4 : End of QCOM_EstablishLogDirectory");
}                                       // end of QCOM_EstablishLogDirectory()
//----------------------------------------------------------------------------
// QCOM_ReadFilePathFromLine
//
// Returns the file path string identified by parameter in the specified line
//
// Returns the file path string
//----------------------------------------------------------------------------
    String ^ QCOM_GUIClass::
QCOM_ReadFilePathFromLine(
    String          ^lineString,
    String          ^parameter)
{
    //------------------------------------------------------------------------
    if (StringSet(lineString) && StringSet(parameter))
    {
        if (lineString->Contains(parameter))
        {
            String ^data = StringAfter(lineString, parameter);
            if (StringSet(data) && StringICompare(data, QCOM_STRING_NONE))
            {
                if (File::Exists(data))
                {
                    return data;
                }
            }
        }
    }
    return String::Empty;
}                                       // end of QCOM_ReadFilePathFromLine()
//----------------------------------------------------------------------------
// QCOM_ReadFPValueFromLine
//
// Returns the value stored in the specified line as floating point text and
// identified by parameter
//----------------------------------------------------------------------------
    double
QCOM_ReadFPValueFromLine(
    String          ^lineString,
    String          ^parameter)
{
    double          inputValue = 0.0;
    //------------------------------------------------------------------------
    if (StringSet(lineString) && StringSet(parameter))
    {
        if (lineString->Contains(parameter))
        {
            String ^data = StringAfter(lineString, parameter);
            if (data->Length >= 1)
            {
                inputValue = Convert::ToDouble(data);
            }
        }
    }
    return inputValue;
}                                       // end of QCOM_ReadFPValueFromLine()
//----------------------------------------------------------------------------
// QCOM_ReadHexValueFromLine
//
// Returns the value stored in the specified line as hex text and identified
// by parameter
//
// Note:    This function assumes that the hex characters that represent the
//          value are located beginning with the first character following the
//          parameter string
//----------------------------------------------------------------------------
    DWORD
QCOM_ReadHexValueFromLine(
    String          ^lineString,
    String          ^parameter)
{
    DWORD           inputValue = 0;
    //------------------------------------------------------------------------
    if (StringSet(lineString) && StringSet(parameter))
    {
        if (lineString->Contains(parameter))
        {
            String ^data = StringAfter(lineString, parameter);
            if ((data->Length == 8) && StringICompare(data, "00000000"))
            {
                inputValue = Convert::ToInt32(data, 16);
            }
        }
    }
    return inputValue;
}                                       // end of QCOM_ReadHexValueFromLine()
//----------------------------------------------------------------------------
// QCOM_RecordEvent
//
// Records the formatted string in the Event Log, using variable arguments
//
// Note:    Because this function uses the String::Format method to format the
//          arguments into a single managed string, the calling convention
//          should look similar to
//
//          char    *unmanagedString = "Testing";
//          DWORD   status = QCOM_SUCCESS;
//          . . .
//          QCOM_RecordEvent(
//              true,
//              "The {0} function was clicked and returned 0x{1:X8}",
//              gcnew String(unmanagedString),
//              status);
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_RecordEvent(
    bool            allow,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    //------------------------------------------------------------------------
    if (allow && StringSet(formatString))
    {
        String ^formattedString = String::Format(formatString, parameters);
        QCOM_UpdateEventLog(formattedString);
        delete formattedString;
    }
}                                       // end of QCOM_RecordEvent()
//----------------------------------------------------------------------------
// QCOM_RetrieveConfigData
//
// Retrieves the information stored in the configuration file, if present
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_RetrieveConfigData(void)
{
    bool            proceedToReadConfigFile = GUI_NO;
    bool            processingGeneralSection = GUI_YES;
    bool            transducerMatch[QCOM_MAXIMUM_NUMBER_OF_UNITS];
    bool            unitMatch[QCOM_MAXIMUM_NUMBER_OF_UNITS];
    bool            usingOutdatedConfigFile = GUI_NO;
    DWORD           generalFlags = QCOM_GENERAL_ZERO_FLAG;
    DWORD           inputValue;
    DWORD           logFlags = QCOM_GENERAL_LOG_ZERO_FLAG;
    DWORD           logDataPoints = QCOM_GENERAL_LOG_ZERO_FLAG;
    DWORD           testFlags = QCOM_GENERAL_TEST_ZERO_FLAG;
    DWORD           unitGeneralFlags[QCOM_MAXIMUM_NUMBER_OF_UNITS];
    DWORD           unitLogDataPoints[QCOM_MAXIMUM_NUMBER_OF_UNITS];
    DWORD           unitLogFlags[QCOM_MAXIMUM_NUMBER_OF_UNITS];
    DWORD           unitTestFlags[QCOM_MAXIMUM_NUMBER_OF_UNITS];
    DWORD           unitGraphingFlags[QCOM_MAXIMUM_NUMBER_OF_UNITS];
    String          ^data;
    String          ^parameter;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_RetrieveConfigData");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DONT_LOAD))
    {
        for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
        {
            transducerMatch[unitNumber] = GUI_NO;
            unitMatch[unitNumber] = GUI_NO;
            unitGeneralFlags[unitNumber] = QCOM_UNIT_ZERO_FLAG;
            unitLogFlags[unitNumber] = QCOM_UNIT_LOG_ZERO_FLAG;
            unitLogDataPoints[unitNumber] = QCOM_UNIT_LOG_ZERO_FLAG;
            unitTestFlags[unitNumber] = QCOM_UNIT_TEST_ZERO_FLAG;
            unitGraphingFlags[unitNumber] = QCOM_UNIT_GRAPH_ZERO_FLAG;
        }
        String ^pathString = String::Concat(
            QCOM_GeneralInfo->logDirectory,
            QCOM_STRING_BACKSLASH,
            _T("QCOM-"),
            QCOM_PROGRAM_VER_STRING,
            _T(".config"));
        if (File::Exists(pathString))
        {
            proceedToReadConfigFile = GUI_YES;
            QCOM_GeneralInfo->configFilePath = pathString;
            QCOM_GeneralInfo->flags |= QCOM_GENERAL_CONFIG_FILE_SPECIFIED;
        }
        else
        {
            //----------------------------------------------------------------
            // The version-appropriate config file is not found, so search for
            // one from an older version
            //----------------------------------------------------------------
            String ^latestConfigPath = String::Empty;
            if (Directory::Exists(QCOM_GeneralInfo->logDirectory))
            {
                String ^logDir = String::Concat(
                    QCOM_GeneralInfo->logDirectory,
                    QCOM_STRING_BACKSLASH);
                array <String ^> ^configFiles = Directory::GetFiles(logDir, "QCOM-*.config");
                if (StringSet(configFiles))
                {
                    for each (String ^oldConfigPath in configFiles)
                    {
                        if (StringSet(latestConfigPath))
                        {
                            if (StringICompare(oldConfigPath, latestConfigPath) > 0)
                                latestConfigPath = oldConfigPath;
                        }
                        else
                            latestConfigPath = oldConfigPath;
                    }
                    if (StringSet(latestConfigPath) && File::Exists(latestConfigPath))
                    {
                        //----------------------------------------------------
                        // A config file from an older software version is
                        // found, so load as many parameters as possible from
                        // the old one
                        //----------------------------------------------------
                        proceedToReadConfigFile = GUI_YES;
                        usingOutdatedConfigFile = GUI_YES;
                        pathString = latestConfigPath;
                    }                   // end of if (StringSet(latestConfigPath) && File::Exists(latestConfigPath))
                }                       // end of if (StringSet(configFiles))
                delete [] configFiles;
                delete logDir;
            }                           // end of if (Directory::Exists(QCOM_GeneralInfo->logDirectory))
        }                               // end of else of if (File::Exists(pathString))
        if (proceedToReadConfigFile)
        {
            StreamReader ^textReader = File::OpenText(pathString);
            if (textReader)
            {
                String ^lineString;
                //------------------------------------------------------------
                // Read a line
                //------------------------------------------------------------
                while (lineString = textReader->ReadLine())
                {
                    lineString = lineString->Trim();
                    //--------------------------------------------------------
                    // Locate any comments and zero out the line from that
                    // point to the end of the line
                    //--------------------------------------------------------
                    if (lineString->Contains("#"))
                    {
                        lineString = lineString->Substring(
                            0, lineString->IndexOf("#"));
                    }
                    //--------------------------------------------------------
                    // Begin parsing non-comment lines
                    //--------------------------------------------------------
                    if (StringSet(lineString))
                    {
                        if (processingGeneralSection)
                        {
                            //------------------------------------------------
                            // Import the general search string, if present
                            //------------------------------------------------
                            parameter = _T("SearchString=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, QCOM_STRING_NONE))
                                    {
                                        QCOM_GeneralInfo->searchString = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the email address, if present
                            //------------------------------------------------
                            parameter = _T("EmailAddress=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, QCOM_STRING_NONE))
                                    {
                                        QCOM_GeneralInfo->emailAddress = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the text message To number, if present
                            //------------------------------------------------
                            parameter = _T("TextMessageToNumber=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, QCOM_STRING_NONE))
                                    {
                                        QCOM_GeneralInfo->textMessageToNumber = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the text message CC number, if present
                            //------------------------------------------------
                            parameter = _T("TextMessageCCNumber=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, QCOM_STRING_NONE))
                                    {
                                        QCOM_GeneralInfo->textMessageCCNumber = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the email message To address, if present
                            //------------------------------------------------
                            parameter = _T("EmailMessageToAddress=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, QCOM_STRING_NONE))
                                    {
                                        QCOM_GeneralInfo->emailMessageToAddress = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the email message CC address, if present
                            //------------------------------------------------
                            parameter = _T("EmailMessageCCAddress=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    if (StringICompare(data, QCOM_STRING_NONE))
                                    {
                                        QCOM_GeneralInfo->emailMessageCCAddress = data;
                                    }
                                }
                                continue;
                            }
                            //------------------------------------------------
                            // Import the general use path, if present
                            //------------------------------------------------
                            parameter = _T("GeneralUsePath=");
                            if (lineString->Contains(parameter))
                            {
                                data = QCOM_ReadFilePathFromLine(
                                    lineString,
                                    parameter);
                                QCOM_SetGeneralUsePath(data);
                                continue;
                            }
                            //------------------------------------------------
                            // Import the convert readings path, if present
                            //------------------------------------------------
                            parameter = _T("ConvertReadingsPath=");
                            if (lineString->Contains(parameter))
                            {
                                data = QCOM_ReadFilePathFromLine(
                                    lineString,
                                    parameter);
                                QCOM_GeneralInfo->convertReadingsFilePath = data;
                                continue;
                            }
                            if (!usingOutdatedConfigFile)
                            {
                                //--------------------------------------------
                                // Import the general, persistent, and message
                                // flags, if present, but only if using the
                                // current config file, since flags can change
                                // between versions of the config file
                                //--------------------------------------------
                                parameter = _T("GeneralFlags=");
                                if (lineString->Contains(parameter))
                                {
                                    generalFlags =
                                        QCOM_ReadHexValueFromLine(lineString, parameter);
                                    continue;
                                }
                                parameter = _T("GeneralLogFlags=");
                                if (lineString->Contains(parameter))
                                {
                                    logFlags =
                                        QCOM_ReadHexValueFromLine(lineString, parameter);
                                    continue;
                                }
                                parameter = _T("GeneralTestFlags=");
                                if (lineString->Contains(parameter))
                                {
                                    testFlags =
                                        QCOM_ReadHexValueFromLine(lineString, parameter);
                                    continue;
                                }
                                parameter = _T("GeneralPersistentFlags=");
                                if (lineString->Contains(parameter))
                                {
                                    QCOM_GeneralInfo->persistentFlags =
                                        QCOM_ReadHexValueFromLine(lineString, parameter);
                                    continue;
                                }
                                parameter = _T("GeneralPersistentLogFlags=");
                                if (lineString->Contains(parameter))
                                {
                                    QCOM_GeneralInfo->persistentLogFlags =
                                        QCOM_ReadHexValueFromLine(lineString, parameter);
                                    continue;
                                }
                                parameter = _T("GeneralPersistentTestFlags=");
                                if (lineString->Contains(parameter))
                                {
                                    QCOM_GeneralInfo->persistentTestFlags =
                                        QCOM_ReadHexValueFromLine(lineString, parameter);
                                    continue;
                                }
                                parameter = _T("UnitPersistentFlags=");
                                if (lineString->Contains(parameter))
                                {
                                    QCOM_GeneralInfo->persistentUnitFlags =
                                        QCOM_ReadHexValueFromLine(lineString, parameter);
                                    continue;
                                }
                                parameter = _T("UnitPersistentLogFlags=");
                                if (lineString->Contains(parameter))
                                {
                                    QCOM_GeneralInfo->persistentUnitLogFlags =
                                        QCOM_ReadHexValueFromLine(lineString, parameter);
                                    continue;
                                }
                                parameter = _T("UnitPersistentLogDataPoints=");
                                if (lineString->Contains(parameter))
                                {
                                    QCOM_GeneralInfo->persistentUnitLogDataPoints =
                                        QCOM_ReadHexValueFromLine(lineString, parameter);
                                    continue;
                                }
                                parameter = _T("UnitPersistentTestFlags=");
                                if (lineString->Contains(parameter))
                                {
                                    QCOM_GeneralInfo->persistentUnitTestFlags =
                                        QCOM_ReadHexValueFromLine(lineString, parameter);
                                    continue;
                                }
                                parameter = _T("UnitPersistentGraphingFlags=");
                                if (lineString->Contains(parameter))
                                {
                                    QCOM_GeneralInfo->persistentUnitGraphingFlags =
                                        QCOM_ReadHexValueFromLine(lineString, parameter);
                                    continue;
                                }
                                //--------------------------------------------
                                // The idea here is to read in the state and
                                // message flags from the config file only if
                                // the software is in Expert Mode and if the
                                // program was not invoked at the command line
                                //--------------------------------------------
                                generalFlags |= (QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE);
                                if ((generalFlags & QCOM_GENERAL_EXPERT_MODE) &&
                                    !StringSet(QCOM_GeneralInfo->commandLine))
                                {
                                    parameter = _T("StateFlags=");
                                    if (lineString->Contains(parameter))
                                    {
                                        inputValue = QCOM_ReadHexValueFromLine(lineString, parameter);
                                        if (inputValue)
                                        {
                                            QCOM_ProgramIntervalEnabled = (inputValue & GUI_INTERVAL_ENABLED) ? GUI_YES : GUI_NO;
                                            QCOM_ExperimentsEnabled = (inputValue & GUI_EXPERIMENTS_BASIC) ? GUI_YES : GUI_NO;
                                            QCOM_HaltOperationsOnErrors = (inputValue & GUI_HALT_ON_ERRORS) ? GUI_YES : GUI_NO;
                                            QCOM_SoftwareUpdateInProgress = (inputValue & GUI_SOFTWARE_UPDATE) ? GUI_YES : GUI_NO;
                                        }
                                        continue;
                                    }
                                    parameter = _T("MessageFlags=");
                                    if (lineString->Contains(parameter))
                                    {
                                        inputValue = QCOM_ReadHexValueFromLine(lineString, parameter);
                                        if (inputValue)
                                        {
                                            QCOM_BasicMessagesEnabled = (inputValue & GUI_MODAL_BASIC) ? GUI_YES : QCOM_BasicMessagesEnabled;
                                            QCOM_ErrorMessagesEnabled = (inputValue & GUI_MODAL_ERROR) ? GUI_YES : QCOM_ErrorMessagesEnabled;
                                            QCOM_VerboseMessagesEnabled = (inputValue & GUI_MODAL_VERBOSE) ? GUI_YES : QCOM_VerboseMessagesEnabled;
                                            QCOM_DetailedMessagesEnabled = (inputValue & GUI_MODAL_DETAILED) ? GUI_YES : QCOM_DetailedMessagesEnabled;
                                            QCOM_ExpMessagesEnabled = (inputValue & GUI_MODAL_EXP) ? GUI_YES : QCOM_ExpMessagesEnabled;
                                            QCOM_StackTracesEnabled = (inputValue & GUI_MODAL_STACK) ? GUI_YES : QCOM_StackTracesEnabled;
                                            QCOM_SendTextErrorMessagesEnabled = (inputValue & GUI_MODAL_TEXT) ? GUI_YES : GUI_NO;
                                            QCOM_SendEmailErrorMessagesEnabled = (inputValue & GUI_MODAL_EMAIL) ? GUI_YES : GUI_NO;
                                            QD_DLLMessagesEnabled = (inputValue & GUI_MODAL_DLL) ? GUI_YES : QD_DLLMessagesEnabled;
                                        }
                                        continue;
                                    }
                                }
                            }           // end of if (!usingOutdatedConfigFile)
                            parameter = _T("DefaultPressureUnits=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if (inputValue < QCOM_MAXIMUM_NUMBER_OF_PRESSURE_UNITS)
                                    {
                                        QCOM_DefaultPressureUnits = (int) inputValue;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("DefaultTemperatureUnits=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if (inputValue < QCOM_MAXIMUM_NUMBER_OF_TEMPERATURE_UNITS)
                                    {
                                        QCOM_DefaultTemperatureUnits = (int) inputValue;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("CurrentPressureUnits=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if (inputValue < QCOM_MAXIMUM_NUMBER_OF_PRESSURE_UNITS)
                                    {
                                        QCOM_CurrentPressureUnits = (int) inputValue;
                                        QCOM_FormerPressureUnits = QCOM_CurrentPressureUnits;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("CurrentTemperatureUnits=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if (inputValue < QCOM_MAXIMUM_NUMBER_OF_TEMPERATURE_UNITS)
                                    {
                                        QCOM_CurrentTemperatureUnits = (int) inputValue;
                                        QCOM_FormerTemperatureUnits = QCOM_CurrentTemperatureUnits;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("AlternatePressureUnits=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if (inputValue < QCOM_MAXIMUM_NUMBER_OF_PRESSURE_UNITS)
                                    {
                                        QCOM_AlternatePressureUnits = (int) inputValue;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("AlternateTemperatureUnits=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if (inputValue < QCOM_MAXIMUM_NUMBER_OF_TEMPERATURE_UNITS)
                                    {
                                        QCOM_AlternateTemperatureUnits = (int) inputValue;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("CurrentPrecision=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if ((inputValue >= GUI_MINIMUM_READOUT_DECIMAL_POINTS) &&
                                        (inputValue <= GUI_MAXIMUM_READOUT_DECIMAL_POINTS))
                                    {
                                        QCOM_CurrentPrecision = inputValue;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("ProgramInterval=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if ((inputValue >= GUI_MINIMUM_PROGRAM_INTERVAL) &&
                                        (inputValue <= GUI_MAXIMUM_PROGRAM_INTERVAL))
                                    {
                                        QCOM_CurrentProgramInterval = inputValue;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("ExperimentNumber=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if ((inputValue >= GUI_MINIMUM_EXPERIMENT_NUMBER) &&
                                        (inputValue <= GUI_MAXIMUM_EXPERIMENT_NUMBER))
                                    {
                                        QCOM_CurrentExperimentNumber = inputValue;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("IntervalUnitsOffset=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    QCOM_CurrentIntervalUnitsOffset = Convert::ToInt32(data);
                                }
                                continue;
                            }
                            parameter = _T("SamplingInterval(ms)=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if ((inputValue >= GUI_INTERVAL_MS_MINIMUM) &&
                                        (inputValue <= GUI_INTERVAL_MS_MAXIMUM))
                                    {
                                        QCOM_CurrentIntervalUnitsArray[GUI_INTERVAL_MS_OFFSET][GUI_INTERVAL_RECENT_OFFSET] = inputValue;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("SamplingInterval(sec)=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if ((inputValue >= GUI_INTERVAL_SEC_MINIMUM) &&
                                        (inputValue <= GUI_INTERVAL_SEC_MAXIMUM))
                                    {
                                        QCOM_CurrentIntervalUnitsArray[GUI_INTERVAL_SEC_OFFSET][GUI_INTERVAL_RECENT_OFFSET] = inputValue;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("SamplingInterval(min)=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if ((inputValue >= GUI_INTERVAL_MIN_MINIMUM) &&
                                        (inputValue <= GUI_INTERVAL_MIN_MAXIMUM))
                                    {
                                        QCOM_CurrentIntervalUnitsArray[GUI_INTERVAL_MIN_OFFSET][GUI_INTERVAL_RECENT_OFFSET] = inputValue;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("SamplingInterval(hr)=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if ((inputValue >= GUI_INTERVAL_HR_MINIMUM) &&
                                        (inputValue <= GUI_INTERVAL_HR_MAXIMUM))
                                    {
                                        QCOM_CurrentIntervalUnitsArray[GUI_INTERVAL_HR_OFFSET][GUI_INTERVAL_RECENT_OFFSET] = inputValue;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("SamplingTimeLimit=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if (inputValue >= GUI_MINIMUM_SAMPLING_RUN_TIME_MINUTES)
                                    {
                                        QCOM_MaximumSamplingRunTimeMinutes = inputValue;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("TestLoopCount=");
                            if (lineString->Contains(parameter))
                            {
                                data = StringAfter(lineString, parameter);
                                if (StringSet(data))
                                {
                                    inputValue = Convert::ToInt32(data);
                                    if ((inputValue >= GUI_MINIMUM_TEST_LOOP_COUNT) &&
                                        (inputValue <= GUI_MAXIMUM_TEST_LOOP_COUNT))
                                    {
                                        QCOM_TestLoopCount = inputValue;
                                    }
                                }
                                continue;
                            }
                            parameter = _T("[Unit_Information]");
                            if (lineString->Contains(parameter))
                            {
                                processingGeneralSection = GUI_NO;
                                continue;
                            }
                        }               // end of if (processingGeneralSection)
                        else
                        {
                            //--------------------------------------------
                            // Import the per-unit information
                            //--------------------------------------------
                            if ((StringICompare(lineString->Substring(0, 4), "Unit") == 0) &&
                                (lineString->IndexOf(" : ") == 7))
                            {
                                DWORD unitNumber = Convert::ToInt32(lineString->Substring(lineString->IndexOf("Unit ") + 5, 2));
                                if ((unitNumber < 0) || (unitNumber >= QCOM_MAXIMUM_NUMBER_OF_UNITS))
                                    continue;
                                unit = QCOM_UnitInfoArray[unitNumber];
                                if (!unit)
                                    continue;
                                parameter = _T("ModuleSerialNumber=");
                                if (lineString->Contains(parameter))
                                {
                                    data = StringAfter(lineString, parameter);
                                    if (StringSet(data))
                                    {
                                        if (StringICompare(data, QCOM_STRING_NONE))
                                        {
                                            if (StringICompare(data, unit->moduleSerialNumber) == 0)
                                                unitMatch[unitNumber] = GUI_YES;
                                        }
                                    }
                                    continue;
                                }
                                parameter = _T("TransducerSerialNumber=");
                                if (lineString->Contains(parameter))
                                {
                                    data = StringAfter(lineString, parameter);
                                    if (StringSet(data))
                                    {
                                        if (StringICompare(data, QCOM_STRING_NONE))
                                        {
                                            if (StringICompare(data, unit->transducerSerialNumber) == 0)
                                                transducerMatch[unitNumber] = GUI_YES;
                                        }
                                    }
                                    continue;
                                }
                                if (unitMatch[unitNumber] && transducerMatch[unitNumber])
                                {
                                    parameter = _T("CoefficientFilePath=");
                                    if (lineString->Contains(parameter))
                                    {
                                        data = QCOM_ReadFilePathFromLine(
                                            lineString,
                                            parameter);
                                        QCOM_SetCoefficientFilePath(unit, data);
                                        continue;
                                    }
//                                    data = QCOM_ReadFilePathFromLine(
//                                        lineString,
//                                        "DataLogFilePath=");
//                                    if (StringSet(data))
//                                    {
//                                        unit->dataLogFilePath = data;
//                                        unit->dataLogFlags |= QCOM_UNIT_LOG_FILE_SPECIFIED;
//                                    }
//                                    data = QCOM_ReadFilePathFromLine(
//                                        lineString,
//                                        "DataLogSnapshotPath=");
//                                    if (StringSet(data))
//                                    {
//                                        unit->dataLogSnapshotFilePath = data;
//                                        unit->dataLogFlags |= QCOM_UNIT_LOG_SNAPSHOT_FILE_SPECIFIED;
//                                    }
//                                    data = QCOM_ReadFilePathFromLine(
//                                        lineString,
//                                        "TestResultsFilePath=");
//                                    if (StringSet(data))
//                                    {
//                                        unit->testResultsFilePath = data;
//                                        unit->dataLogFlags |= QCOM_UNIT_TEST_RESULTS_FILE_SPECIFIED;
//                                    }
                                    parameter = _T("TestDataFilePath=");
                                    if (lineString->Contains(parameter))
                                    {
                                        data = QCOM_ReadFilePathFromLine(
                                            lineString,
                                            parameter);
                                        QCOM_SetTestDataFilePath(unit, data);
                                        continue;
                                    }
                                    parameter = _T("TestFirmwareFilePath=");
                                    if (lineString->Contains(parameter))
                                    {
                                        data = QCOM_ReadFilePathFromLine(
                                            lineString,
                                            parameter);
                                        QCOM_SetTestFirmwareFilePath(unit, data);
                                        continue;
                                    }
                                    if (!usingOutdatedConfigFile)
                                    {
                                        parameter = _T("UnitFlags=");
                                        if (lineString->Contains(parameter))
                                        {
                                            unitGeneralFlags[unitNumber] = QCOM_ReadHexValueFromLine(
                                                lineString,
                                                parameter);
                                            continue;
                                        }
                                        parameter = _T("UnitLogFlags=");
                                        if (lineString->Contains(parameter))
                                        {
                                            unitLogFlags[unitNumber] = QCOM_ReadHexValueFromLine(
                                                lineString,
                                                parameter);
                                            continue;
                                        }
                                        parameter = _T("UnitLogDataPoints=");
                                        if (lineString->Contains(parameter))
                                        {
                                            unitLogDataPoints[unitNumber] = QCOM_ReadHexValueFromLine(
                                                lineString,
                                                parameter);
                                            continue;
                                        }
                                        parameter = _T("UnitTestFlags=");
                                        if (lineString->Contains(parameter))
                                        {
                                            unitTestFlags[unitNumber] = QCOM_ReadHexValueFromLine(
                                                lineString,
                                                parameter);
                                            continue;
                                        }
                                        parameter = _T("GraphingFlags=");
                                        if (lineString->Contains(parameter))
                                        {
                                            unitGraphingFlags[unitNumber] = QCOM_ReadHexValueFromLine(
                                                lineString,
                                                parameter);
                                            continue;
                                        }
                                    }   // end of if (!usingOutdatedConfigFile)
                                    parameter = _T("SendEveryInterval=");
                                    if (lineString->Contains(parameter))
                                    {
                                        data = StringAfter(lineString, parameter);
                                        if (StringSet(data))
                                        {
                                            inputValue = Convert::ToInt32(data);
                                            if ((inputValue >= GUI_MINIMUM_SEND_EVERY_INTERVAL) &&
                                                (inputValue <= GUI_MAXIMUM_SEND_EVERY_INTERVAL))
                                            {
                                                QCOM_CurrentSendEveryInterval[unitNumber] = inputValue;
                                                QCOM_CurrentSendEveryIntervalRemaining[unitNumber] =
                                                    QCOM_CurrentSendEveryInterval[unitNumber];
                                            }
                                        }
                                        continue;
                                    }
                                    //----------------------------------------
                                    // Graphing boundary values
                                    //----------------------------------------
                                    if (lineString->Contains("Graphing"))
                                    {
                                        parameter = _T("GraphingPressureLowBoundaryPSI=");
                                        if (lineString->Contains(parameter))
                                        {
                                            unit->graphingPressureLowBoundaryPSI = QCOM_ReadFPValueFromLine(
                                                lineString,
                                                parameter);
                                            continue;
                                        }
                                        parameter = _T("GraphingPressureHighBoundaryPSI=");
                                        if (lineString->Contains(parameter))
                                        {
                                            unit->graphingPressureHighBoundaryPSI = QCOM_ReadFPValueFromLine(
                                                lineString,
                                                parameter);
                                            continue;
                                        }
                                        parameter = _T("GraphingTemperatureLowBoundaryCelsius=");
                                        if (lineString->Contains(parameter))
                                        {
                                            unit->graphingTemperatureLowBoundaryCelsius = QCOM_ReadFPValueFromLine(
                                                lineString,
                                                parameter);
                                            continue;
                                        }
                                        parameter = _T("GraphingTemperatureHighBoundaryCelsius=");
                                        if (lineString->Contains(parameter))
                                        {
                                            unit->graphingTemperatureHighBoundaryCelsius = QCOM_ReadFPValueFromLine(
                                                lineString,
                                                parameter);
                                            continue;
                                        }
                                        parameter = _T("GraphingAmperageLowBoundarymA=");
                                        if (lineString->Contains(parameter))
                                        {
                                            unit->graphingAmperageLowBoundarymA = QCOM_ReadFPValueFromLine(
                                                lineString,
                                                parameter);
                                            continue;
                                        }
                                        parameter = _T("GraphingAmperageHighBoundarymA=");
                                        if (lineString->Contains(parameter))
                                        {
                                            unit->graphingAmperageHighBoundarymA = QCOM_ReadFPValueFromLine(
                                                lineString,
                                                parameter);
                                            continue;
                                        }
                                    }   // end of if (lineString->Contains("Graphing"))
                                }       // end of if (unitMatch[unitNumber] && transducerMatch[unitNumber])
                                unit->flags |= QCOM_UNIT_CONFIG_INFO_LOADED;
                            }           // end of if ((StringICompare(lineString->Substring(...))))
                        }               // end of else of if (processGeneralSection)
                    }                   // end of if (StringSet(lineString))
                }                       // end of while (lineString = textReader->ReadLine())
                textReader->Close();
                QCOM_GeneralInfo->flags |= QCOM_GENERAL_CONFIG_INFO_LOADED;
            }                           // end of if (textReader)
            RecordVerboseEvent("    Config information read from file\n    {0}",
                pathString);
        }                               // end of if (proceedToReadConfigFile)
        else
        {
            QCOM_GeneralInfo->configFilePath = String::Empty;
            QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_CONFIG_FILE_SPECIFIED;
            QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_CONFIG_INFO_LOADED;
        }
        //--------------------------------------------------------------------
        // Reconcile unit-relative elements
        //--------------------------------------------------------------------
        for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            if (unit)
            {
                //------------------------------------------------------------
                // Clear invalid pathnames, if their flags are set
                //------------------------------------------------------------
                if (QCOM_CFKnown(unit))
                {
                    if (!StringSet(unit->coefficientFilePath) || !File::Exists(unit->coefficientFilePath))
                    {
                        unit->flags &= ~QCOM_UNIT_COEFFICIENT_FILE_SPECIFIED;
                        unit->coefficientFilePath = String::Empty;
                    }
                }
                else
                    unit->coefficientFilePath = String::Empty;
                if (QCOM_LogFileKnown(unit))
                {
                    if (!StringSet(unit->dataLogFilePath) || !File::Exists(unit->dataLogFilePath))
                    {
                        unit->dataLogFlags &= ~QCOM_UNIT_LOG_FILE_SPECIFIED;
                        unit->dataLogFilePath = String::Empty;
                    }
                }
                if (QCOM_LogSSFileKnown(unit))
                {
                    if (!StringSet(unit->dataLogSnapshotFilePath) || !File::Exists(unit->dataLogSnapshotFilePath))
                    {
                        unit->dataLogFlags &= ~QCOM_UNIT_LOG_SNAPSHOT_FILE_SPECIFIED;
                        unit->dataLogSnapshotFilePath = String::Empty;
                    }
                }
                else
                    unit->dataLogSnapshotFilePath = String::Empty;
                if (QCOM_TRFileKnown(unit))
                {
                    if (!StringSet(unit->testResultsFilePath) || !File::Exists(unit->testResultsFilePath))
                    {
                        unit->testFlags &= ~QCOM_UNIT_TEST_RESULTS_FILE_SPECIFIED;
                        unit->testResultsFilePath = String::Empty;
                    }
                }
                else
                    unit->testResultsFilePath = String::Empty;
                if (unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED)
                {
                    if (!StringSet(unit->testDataFilePath) || !File::Exists(unit->testDataFilePath))
                    {
                        unit->testFlags &= ~QCOM_UNIT_TEST_DATA_FILE_SPECIFIED;
                        unit->testDataFilePath = String::Empty;
                    }
                }
                else
                    unit->testDataFilePath = String::Empty;
                if (unit->testFlags & QCOM_UNIT_TEST_FW_FILE_SPECIFIED)
                {
                    if (!StringSet(unit->testFirmwareFilePath) || !File::Exists(unit->testFirmwareFilePath))
                    {
                        unit->testFlags &= ~QCOM_UNIT_TEST_FW_FILE_SPECIFIED;
                        unit->testFirmwareFilePath = String::Empty;
                    }
                }
                else
                    unit->testFirmwareFilePath = String::Empty;
                //------------------------------------------------------------
                // Resolve invalid graphics boundaries
                //------------------------------------------------------------
                if (unit->graphingPressureLowBoundaryPSI == unit->graphingPressureHighBoundaryPSI)
                {
                    unit->graphingPressureLowBoundaryPSI = QCOM_GRAPH_DEFAULT_PRESSURE_LOW_BOUNDARY_PSI;
                    unit->graphingPressureHighBoundaryPSI = QCOM_GRAPH_DEFAULT_PRESSURE_HIGH_BOUNDARY_PSI;
                }
                else
                {
                    if (unit->graphingPressureLowBoundaryPSI >= unit->graphingPressureHighBoundaryPSI)
                    {
                        double swapValue = unit->graphingPressureHighBoundaryPSI;
                        unit->graphingPressureHighBoundaryPSI = unit->graphingPressureLowBoundaryPSI;
                        unit->graphingPressureLowBoundaryPSI = swapValue;
                    }
                }
                if (unit->graphingTemperatureLowBoundaryCelsius == unit->graphingTemperatureHighBoundaryCelsius)
                {
                    unit->graphingTemperatureLowBoundaryCelsius = QCOM_GRAPH_DEFAULT_TEMPERATURE_LOW_BOUNDARY_C;
                    unit->graphingTemperatureHighBoundaryCelsius = QCOM_GRAPH_DEFAULT_TEMPERATURE_HIGH_BOUNDARY_C;
                }
                else
                {
                    if (unit->graphingTemperatureLowBoundaryCelsius >= unit->graphingTemperatureHighBoundaryCelsius)
                    {
                        double swapValue = unit->graphingTemperatureHighBoundaryCelsius;
                        unit->graphingTemperatureHighBoundaryCelsius = unit->graphingTemperatureLowBoundaryCelsius;
                        unit->graphingTemperatureLowBoundaryCelsius = swapValue;
                    }
                }
                if (unit->graphingAmperageLowBoundarymA == unit->graphingAmperageHighBoundarymA)
                {
                    unit->graphingAmperageLowBoundarymA = QCOM_GRAPH_DEFAULT_AMPERAGE_LOW_BOUNDARY_MA;
                    unit->graphingAmperageHighBoundarymA = QCOM_GRAPH_DEFAULT_AMPERAGE_HIGH_BOUNDARY_MA;
                }
                else
                {
                    if (unit->graphingAmperageLowBoundarymA >= unit->graphingAmperageHighBoundarymA)
                    {
                        double swapValue = unit->graphingAmperageHighBoundarymA;
                        unit->graphingAmperageHighBoundarymA = unit->graphingAmperageLowBoundarymA;
                        unit->graphingAmperageLowBoundarymA = swapValue;
                    }
                }
            }                           // end of if (unit)
        }                               // end of for (DWORD unitNumber = 0; ...)
        //--------------------------------------------------------------------
        // Set the persistent flags if they are not set
        //--------------------------------------------------------------------
        if (!QCOM_GeneralInfo->persistentFlags)
            QCOM_GeneralInfo->persistentFlags = QCOM_GENERAL_DEFAULT_PERSISTENT_FLAGS;
        if (!QCOM_GeneralInfo->persistentLogFlags)
            QCOM_GeneralInfo->persistentLogFlags = QCOM_GENERAL_LOG_DEFAULT_PERSISTENT_FLAGS;
        if (!QCOM_GeneralInfo->persistentTestFlags)
            QCOM_GeneralInfo->persistentTestFlags = QCOM_GENERAL_TEST_DEFAULT_PERSISTENT_FLAGS;
        if (!QCOM_GeneralInfo->persistentUnitFlags)
            QCOM_GeneralInfo->persistentUnitFlags = QCOM_UNIT_DEFAULT_PERSISTENT_FLAGS;
        if (!QCOM_GeneralInfo->persistentUnitLogFlags)
            QCOM_GeneralInfo->persistentUnitLogFlags = QCOM_UNIT_LOG_DEFAULT_PERSISTENT_FLAGS;
        if (!QCOM_GeneralInfo->persistentUnitLogDataPoints)
            QCOM_GeneralInfo->persistentUnitLogDataPoints = QCOM_UNIT_LOG_DEFAULT_PERSISTENT_POINTS;
        if (!QCOM_GeneralInfo->persistentUnitTestFlags)
            QCOM_GeneralInfo->persistentUnitTestFlags = QCOM_UNIT_TEST_DEFAULT_PERSISTENT_FLAGS;
        if (!QCOM_GeneralInfo->persistentUnitGraphingFlags)
            QCOM_GeneralInfo->persistentUnitGraphingFlags = QCOM_UNIT_GRAPH_DEFAULT_PERSISTENT_FLAGS;
        //--------------------------------------------------------------------
        // Apply the effects of the persistent flags
        //--------------------------------------------------------------------
        QCOM_GeneralInfo->flags |= (generalFlags & QCOM_GeneralInfo->persistentFlags);
        QCOM_GeneralInfo->logFlags |= (logFlags & QCOM_GeneralInfo->persistentLogFlags);
        QCOM_GeneralInfo->testFlags |= (testFlags & QCOM_GeneralInfo->persistentTestFlags);
        for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            if (unit)
            {
                unit->flags |= (unitGeneralFlags[unitNumber] & QCOM_GeneralInfo->persistentUnitFlags);
                unit->dataLogFlags |= (unitLogFlags[unitNumber] & QCOM_GeneralInfo->persistentUnitLogFlags);
                unit->dataLogPoints |= (unitLogDataPoints[unitNumber] & QCOM_GeneralInfo->persistentUnitLogDataPoints);
                unit->testFlags |= (unitTestFlags[unitNumber] & QCOM_GeneralInfo->persistentUnitTestFlags);
                unit->graphingFlags |= (unitGraphingFlags[unitNumber] & QCOM_GeneralInfo->persistentUnitGraphingFlags);
            }
        }
        if (usingOutdatedConfigFile)
        {
            QCOM_FormerPressureUnits = QCOM_CurrentPressureUnits = QCOM_DefaultPressureUnits;
            QCOM_FormerTemperatureUnits = QCOM_CurrentTemperatureUnits = QCOM_DefaultTemperatureUnits;
        }
    }                                   // end of if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DONT_LOAD))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_RetrieveConfigData()
//----------------------------------------------------------------------------
// QCOM_SaveConfigData
//
// Saves program information in the configuration file
//
// Note:    If the config file exists, it is overwritten
//
// Note:    The config file is created in the executable directory, by default
//
// Note:    This function reports no errors, by design
//
// Called by:   QCOM_ShutDownSoftware
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SaveConfigData(void)
{
    BYTE            buildVersion;
    BYTE            majorVersion;
    BYTE            minorVersion;
    DWORD           lowerVersion;
    DWORD           messageFlags = 0;
    DWORD           stateFlags = 0;
    DWORD           upperVersion;
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^configFileName;
    String          ^halfBorder = GUI_TEXT_FILE_HALF_BORDER;
    String          ^pathString;
    DateTime        dateTime = DateTime::Now;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_SaveConfigData");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_FILE_SPECIFIED)
    {
        pathString = QCOM_GeneralInfo->configFilePath;
        configFileName = Path::GetFileName(pathString);
    }
    else
    {
        configFileName = String::Concat(
            _T("QCOM-"),
            QCOM_PROGRAM_VER_STRING,
            _T(".config"));
        pathString = String::Concat(
            QCOM_GeneralInfo->logDirectory,
            QCOM_STRING_BACKSLASH,
            configFileName);
    }
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DELETE_ON_EXIT)
    {
        if (File::Exists(pathString))
        {
            File::Delete(pathString);
        }
    }
    if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DONT_SAVE))
    {
        StreamWriter ^textWriter = File::CreateText(pathString);
        if (textWriter)
        {
            textWriter->WriteLine(border);
            //----------------------------------------------------------------
            // Write out the header, including the program name and the
            // current date and time
            //----------------------------------------------------------------
            String ^lineString = String::Format(
                "# {0}\n#\n"
                "# QCOM Configuration Data File\n#\n"
                "# Created on {1:D2} {2} {3:D4} at {4:D2}:{5:D2}:{6:D2}",
                configFileName,
                dateTime.Day,
                QCOM_MonthStringArray[dateTime.Month],
                dateTime.Year,
                dateTime.Hour,
                dateTime.Minute,
                dateTime.Second);
            textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
            textWriter->WriteLine(border);
            //----------------------------------------------------------------
            // Save general program information
            //----------------------------------------------------------------
            QD_GetQDDLLVersion(
                (LPBYTE) &majorVersion,
                (LPBYTE) &minorVersion,
                (LPBYTE) &buildVersion);
            QD_GetUSBDriverVersion(&upperVersion, &lowerVersion);
            lineString = String::Format(
                "[QCOM_Start]\n"
                "    ProgramVersion={0}\n"
                "    ProgramBuild={1:D}\n"
                "    QCOMDLL={2:D}.{3:D}.{4:D}\n"
                "    SiUSBDriver={5:X}.{6:X}.{7:X}.{8:X}\n"
                "    OS={9}",
                QCOM_PROGRAM_VERSION_STRING,
                QCOM_BuildNumber,
                majorVersion, minorVersion, buildVersion,
                ((upperVersion >> 16) & 0xFFFF), (upperVersion & 0xFFFF),
                ((lowerVersion >> 16) & 0xFFFF), (lowerVersion & 0xFFFF),
                QCOM_GeneralInfo->windowsVersion);
            textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
            //----------------------------------------------------------------
            // Save general parameters
            //----------------------------------------------------------------
            lineString = String::Format(
                "[QCOM_Parameters]\n"
                "    CommandLine={0}\n"
                "    ConfigFilePath={1}\n"
                "    GeneralUsePath={2}\n"
                "    SearchString={3}\n"
                "    EmailAddress={4}\n"
                "    ErrorLogPath={5}\n"
                "    EventLogPath={6}\n"
                "    ConvertReadingsPath={7}\n"
                "    TextMessageToNumber={8}\n"
                "    TextMessageCCNumber={9}\n"
                "    EmailMessageToAddress={10}\n"
                "    EmailMessageCCAddress={11}",
                (StringSet(QCOM_GeneralInfo->commandLine) ?
                    QCOM_GeneralInfo->commandLine : QCOM_STRING_NONE),
                (((QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_FILE_SPECIFIED) && StringSet(QCOM_GeneralInfo->configFilePath)) ?
                    QCOM_GeneralInfo->configFilePath : QCOM_STRING_NONE),
                (((QCOM_GeneralInfo->flags & QCOM_GENERAL_USE_PATH_SPECIFIED) && StringSet(QCOM_GeneralInfo->generalUsePath)) ?
                    QCOM_GeneralInfo->generalUsePath : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->searchString) ?
                    QCOM_GeneralInfo->searchString : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->emailAddress) ?
                    QCOM_GeneralInfo->emailAddress : QCOM_STRING_NONE),
                (((QCOM_GeneralInfo->flags & QCOM_GENERAL_ERROR_LOG_SPECIFIED) && StringSet(QCOM_GeneralInfo->errorLogPath)) ?
                    QCOM_GeneralInfo->errorLogPath : QCOM_STRING_NONE),
                (((QCOM_GeneralInfo->flags & QCOM_GENERAL_EVENT_LOG_SPECIFIED) && StringSet(QCOM_GeneralInfo->eventLogPath)) ?
                    QCOM_GeneralInfo->eventLogPath : QCOM_STRING_NONE),
                ((StringSet(utilConvertReadingsUnit->convertReadingsFilePath)) ?
                    utilConvertReadingsUnit->convertReadingsFilePath : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->textMessageToNumber) ?
                    QCOM_GeneralInfo->textMessageToNumber : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->textMessageCCNumber) ?
                    QCOM_GeneralInfo->textMessageCCNumber : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->emailMessageToAddress) ?
                    QCOM_GeneralInfo->emailMessageToAddress : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->emailMessageCCAddress) ?
                    QCOM_GeneralInfo->emailMessageCCAddress : QCOM_STRING_NONE));
            textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
            //----------------------------------------------------------------
            // Save global flags
            //----------------------------------------------------------------
            lineString = String::Format(
                "    GeneralFlags={0:X8}\n"
                "    GeneralLogFlags={1:X8}\n"
                "    GeneralTestFlags={2:X8}\n"
                "    GeneralPersistentFlags={3:X8}\n"
                "    GeneralPersistentLogFlags={4:X8}\n"
                "    GeneralPersistentTestFlags={5:X8}\n"
                "    UnitPersistentFlags={6:X8}\n"
                "    UnitPersistentLogFlags={7:X8}\n"
                "    UnitPersistentLogDataPoints={8:X8}\n"
                "    UnitPersistentTestFlags={9:X8}\n"
                "    UnitPersistentGraphingFlags={10:X8}",
                QCOM_GeneralInfo->flags,
                QCOM_GeneralInfo->logFlags,
                QCOM_GeneralInfo->testFlags,
                QCOM_GeneralInfo->persistentFlags,
                QCOM_GeneralInfo->persistentLogFlags,
                QCOM_GeneralInfo->persistentTestFlags,
                QCOM_GeneralInfo->persistentUnitFlags,
                QCOM_GeneralInfo->persistentUnitLogFlags,
                QCOM_GeneralInfo->persistentUnitLogDataPoints,
                QCOM_GeneralInfo->persistentUnitTestFlags,
                QCOM_GeneralInfo->persistentUnitGraphingFlags);
            textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
            if (QCOM_ProgramIntervalEnabled)
                stateFlags |= GUI_INTERVAL_ENABLED;
            if (QCOM_ExperimentsEnabled)
                stateFlags |= GUI_EXPERIMENTS_BASIC;
            if (QCOM_HaltOperationsOnErrors)
                stateFlags |= GUI_HALT_ON_ERRORS;
            if (QCOM_CommandLineOnly)
                stateFlags |= GUI_COMMAND_LINE_ONLY;
            if (QCOM_SoftwareUpdateInProgress)
                stateFlags |= GUI_SOFTWARE_UPDATE;
            textWriter->WriteLine(String::Format(
                "    StateFlags={0:X8}",
                stateFlags));
            if (QCOM_BasicMessagesEnabled)
                messageFlags |= GUI_MODAL_BASIC;
            if (QCOM_ErrorMessagesEnabled)
                messageFlags |= GUI_MODAL_ERROR;
            if (QCOM_VerboseMessagesEnabled)
                messageFlags |= GUI_MODAL_VERBOSE;
            if (QCOM_DetailedMessagesEnabled)
                messageFlags |= GUI_MODAL_DETAILED;
            if (QCOM_ExpMessagesEnabled)
                messageFlags |= GUI_MODAL_EXP;
            if (QCOM_StackTracesEnabled)
                messageFlags |= GUI_MODAL_STACK;
            if (QCOM_SendTextErrorMessagesEnabled)
                messageFlags |= GUI_MODAL_TEXT;
            if (QCOM_SendEmailErrorMessagesEnabled)
                messageFlags |= GUI_MODAL_EMAIL;
            if (QD_DLLMessagesEnabled)
                messageFlags |= GUI_MODAL_DLL;
            if (QCOM_EventLogBasicEnabled)
                messageFlags |= GUI_ELOG_BASIC;
            if (QCOM_EventLogVerboseEnabled)
                messageFlags |= GUI_ELOG_VERBOSE;
            if (QCOM_EventLogDetailedEnabled)
                messageFlags |= GUI_ELOG_DETAILED;
            if (QCOM_EventLogTestEnabled)
                messageFlags |= GUI_ELOG_TEST;
            textWriter->WriteLine(
                String::Format(
                    "    MessageFlags={0:X8}",
                    messageFlags));
            //----------------------------------------------------------------
            // Save global integer values
            //----------------------------------------------------------------
            lineString = String::Format(
                "    DefaultPressureUnits={0:D}\n"
                "    DefaultTemperatureUnits={1:D}\n"
                "    CurrentPressureUnits={2:D}\n"
                "    CurrentTemperatureUnits={3:D}\n"
                "    AlternatePressureUnits={4:D}\n"
                "    AlternateTemperatureUnits={5:D}\n"
                "    CurrentPrecision={6:D}\n"
                "    ProgramInterval={7:D}\n"
                "    IntervalUnitsOffset={8:D}\n"
                "    SamplingInterval(ms)={9:D}\n"
                "    SamplingInterval(sec)={10:D}\n"
                "    SamplingInterval(min)={11:D}\n"
                "    SamplingInterval(hr)={12:D}\n"
                "    SamplingTimeLimit={13:D}\n"
                "    TestLoopCount={14:D}\n"
                "    ExperimentNumber={15:D}",
                QCOM_DefaultPressureUnits,
                QCOM_DefaultTemperatureUnits,
                QCOM_CurrentPressureUnits,
                QCOM_CurrentTemperatureUnits,
                QCOM_AlternatePressureUnits,
                QCOM_AlternateTemperatureUnits,
                QCOM_CurrentPrecision,
                QCOM_CurrentProgramInterval,
                QCOM_CurrentIntervalUnitsOffset,
                QCOM_CurrentIntervalUnitsArray[GUI_INTERVAL_MS_OFFSET][GUI_INTERVAL_RECENT_OFFSET],
                QCOM_CurrentIntervalUnitsArray[GUI_INTERVAL_SEC_OFFSET][GUI_INTERVAL_RECENT_OFFSET],
                QCOM_CurrentIntervalUnitsArray[GUI_INTERVAL_MIN_OFFSET][GUI_INTERVAL_RECENT_OFFSET],
                QCOM_CurrentIntervalUnitsArray[GUI_INTERVAL_HR_OFFSET][GUI_INTERVAL_RECENT_OFFSET],
                QCOM_MaximumSamplingRunTimeMinutes,
                QCOM_TestLoopCount,
                QCOM_CurrentExperimentNumber);
            textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
            //----------------------------------------------------------------
            // Save unit and transducer information for all possible units
            //----------------------------------------------------------------
            textWriter->WriteLine("[Unit_Information]");
            for (int unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
            {
                unit = QCOM_UnitInfoArray[unitNumber];
                if (unit)
                {
                    lineString = String::Format(
                        "Unit {0:D2} : ModuleSerialNumber={1}\n"
                        "Unit {0:D2} : ModuleFirmwareVersion={2}\n"
                        "Unit {0:D2} : TransducerSerialNumber={3}\n"
                        "Unit {0:D2} : TransducerType={4}",
                        unitNumber,
                        (QCOM_UnitValid(unit) ?
                            unit->moduleSerialNumber : QCOM_STRING_NONE),
                        ((unit->flags & QCOM_UNIT_FIRMWARE_ID_PRESENT) ?
                            unit->firmwareString : QCOM_STRING_NONE),
                        (QCOM_XDSNValid(unit) ?
                            unit->transducerSerialNumber : QCOM_STRING_NONE),
                        (QCOM_XDPresent(unit) ?
                            String::Concat(unit->transducerType) : QCOM_STRING_NA));
                    textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
                    lineString = String::Format(
                        "Unit {0:D2} : CoefficientFilePath={1}\n"
                        "Unit {0:D2} : DataLogFilePath={2}\n"
                        "Unit {0:D2} : DataLogSnapshotPath={3}\n"
                        "Unit {0:D2} : TestResultsFilePath={4}\n"
                        "Unit {0:D2} : TestDataFilePath={5}\n"
                        "Unit {0:D2} : TestFirmwareFilePath={6}",
                        unitNumber,
                        ((QCOM_CFKnown(unit) && StringSet(unit->coefficientFilePath)) ?
                            unit->coefficientFilePath : QCOM_STRING_NONE),
                        ((QCOM_LogFileKnown(unit) && StringSet(unit->dataLogFilePath)) ?
                            unit->dataLogFilePath : QCOM_STRING_NONE),
                        ((QCOM_LogSSFileKnown(unit) && StringSet(unit->dataLogSnapshotFilePath)) ?
                            unit->dataLogSnapshotFilePath : QCOM_STRING_NONE),
                        ((QCOM_TRFileKnown(unit) && StringSet(unit->testResultsFilePath)) ?
                            unit->testResultsFilePath : QCOM_STRING_NONE),
                        (((unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED) && StringSet(unit->testDataFilePath)) ?
                            unit->testDataFilePath : QCOM_STRING_NONE),
                        (((unit->testFlags & QCOM_UNIT_TEST_FW_FILE_SPECIFIED) && StringSet(unit->testFirmwareFilePath)) ?
                            unit->testFirmwareFilePath : QCOM_STRING_NONE));
                    textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
                    lineString = String::Format(
                        "Unit {0:D2} : UnitFlags={1:X8}\n"
                        "Unit {0:D2} : UnitLogFlags={2:X8}\n"
                        "Unit {0:D2} : UnitLogDataPoints={3:X8}\n"
                        "Unit {0:D2} : UnitTestFlags={4:X8}\n"
                        "Unit {0:D2} : SendEveryInterval={5:D}\n"
                        "Unit {0:D2} : SendEveryIntervalRemaining={6:D}",
                        unitNumber,
                        unit->flags,
                        unit->dataLogFlags,
                        unit->dataLogPoints,
                        unit->testFlags,
                        QCOM_CurrentSendEveryInterval[unitNumber],
                        QCOM_CurrentSendEveryIntervalRemaining[unitNumber]);
                    textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
                    lineString = String::Format(
                        "Unit {0:D2} : GraphingFlags={1:X8}\n"
                        "Unit {0:D2} : GraphingPressureLowBoundaryPSI={2:F8}\n"
                        "Unit {0:D2} : GraphingPressureHighBoundaryPSI={3:F8}\n"
                        "Unit {0:D2} : GraphingTemperatureLowBoundaryCelsius={4:F8}\n"
                        "Unit {0:D2} : GraphingTemperatureHighBoundaryCelsius={5:F8}\n"
                        "Unit {0:D2} : GraphingAmperageLowBoundarymA={6:F8}\n"
                        "Unit {0:D2} : GraphingAmperageHighBoundarymA={7:F8}",
                        unitNumber,
                        unit->graphingFlags,
                        unit->graphingPressureLowBoundaryPSI,
                        unit->graphingPressureHighBoundaryPSI,
                        unit->graphingTemperatureLowBoundaryCelsius,
                        unit->graphingTemperatureHighBoundaryCelsius,
                        unit->graphingAmperageLowBoundarymA,
                        unit->graphingAmperageHighBoundarymA);
                    textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
                    textWriter->WriteLine(halfBorder);
                }                       // end of if (unit)
            }                           // end of for (int unitNumber = 0; ...)
            //----------------------------------------------------------------
            // Write out the footer
            //----------------------------------------------------------------
            textWriter->WriteLine("[QCOM_End]");
            textWriter->WriteLine(border);
            lineString = String::Concat("# End of ", configFileName);
            textWriter->WriteLine(lineString);
            textWriter->WriteLine(border);
            textWriter->Close();
        }                               // end of if (textWriter)
        RecordVerboseEvent(
            "Config information saved in file\n{0}", pathString);
    }                                   // end of if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_CONFIG_DONT_SAVE))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_SaveConfigData()
//----------------------------------------------------------------------------
// QCOM_ToolStripDisplayEventLogDropDownClicked
//
// Handles the click of the Display Event Log drop down
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripDisplayEventLogDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("QCOM_ToolStripDisplayEventLogDropDownClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    QCOM_DisplayMostRecentEventLog();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ToolStripDisplayEventLogDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripEventLogAllDropDownClicked
//
// Handles the click of the All Events Log drop down
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripEventLogAllDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("QCOM_ToolStripEventLogAllDropDownClicked");
    //------------------------------------------------------------------------
    QCOM_EventLogBasicEnabled = (QCOM_EventLogBasicEnabled ? GUI_NO : GUI_YES);
    if (QCOM_EventLogBasicEnabled)
    {
        QCOM_EventLogVerboseEnabled = GUI_YES;
        QCOM_EventLogDetailedEnabled = GUI_YES;
        QCOM_EstablishEventLog(String::Concat(functionName, " called"));
    }
    else
    {
        QCOM_UpdateEventLog(String::Concat(functionName, " called"));
        QCOM_EventLogVerboseEnabled = GUI_NO;
        QCOM_EventLogDetailedEnabled = GUI_NO;
        QCOM_EventLogTestEnabled = GUI_NO;
        QCOM_ConcludeEventLog(String::Concat(functionName, " concluded"));
    }
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ToolStripEventLogAllDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripEventLogBasicDropDownClicked
//
// Handles the click of the Basic Event Log drop down
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripEventLogBasicDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("QCOM_ToolStripEventLogBasicDropDownClicked");
    //------------------------------------------------------------------------
    QCOM_EventLogBasicEnabled = (QCOM_EventLogBasicEnabled ? GUI_NO : GUI_YES);
    if (QCOM_EventLogBasicEnabled)
    {
        QCOM_EstablishEventLog(String::Concat(functionName, " called"));
    }
    else
    {
        QCOM_UpdateEventLog(String::Concat(functionName, " called"));
        QCOM_EventLogVerboseEnabled = GUI_NO;
        QCOM_EventLogDetailedEnabled = GUI_NO;
        QCOM_EventLogTestEnabled = GUI_NO;
        QCOM_ConcludeEventLog(String::Concat(functionName, " concluded"));
    }
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ToolStripEventLogBasicDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripEventLogDetailedDropDownClicked
//
// Handles the click of the Detailed Event Log drop down
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripEventLogDetailedDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("QCOM_ToolStripEventLogDetailedDropDownClicked");
    //------------------------------------------------------------------------
    QCOM_EventLogDetailedEnabled = (QCOM_EventLogDetailedEnabled ? GUI_NO : GUI_YES);
    if (QCOM_EventLogDetailedEnabled)
    {
        if (!QCOM_EventLogVerboseEnabled)
            QCOM_EventLogVerboseEnabled = GUI_YES;
        if (!QCOM_EventLogBasicEnabled)
            QCOM_EventLogBasicEnabled = GUI_YES;
        QCOM_EstablishEventLog(String::Concat(functionName, " called"));
    }
    else
    {
        QCOM_UpdateEventLog(String::Concat(functionName, " called"));
        QCOM_EventLogBasicEnabled = GUI_NO;
        QCOM_EventLogVerboseEnabled = GUI_NO;
        QCOM_EventLogTestEnabled = GUI_NO;
        QCOM_ConcludeEventLog(String::Concat(functionName, " concluded"));
    }
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ToolStripEventLogDetailedDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripEventLogTestDropDownClicked
//
// Handles the click of the Test Event Log drop down
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripEventLogTestDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("QCOM_ToolStripEventLogTestDropDownClicked");
    //------------------------------------------------------------------------
    QCOM_EventLogTestEnabled = (QCOM_EventLogTestEnabled ? GUI_NO : GUI_YES);
    if (QCOM_EventLogTestEnabled)
    {
        if (!QCOM_EventLogBasicEnabled)
            QCOM_EventLogBasicEnabled = GUI_YES;
        QCOM_EstablishEventLog(String::Concat(functionName, " called"));
    }
    else
    {
        QCOM_UpdateEventLog(String::Concat(functionName, " called"));
        QCOM_EventLogBasicEnabled = GUI_NO;
        QCOM_EventLogDetailedEnabled = GUI_NO;
        QCOM_EventLogVerboseEnabled = GUI_NO;
        QCOM_ConcludeEventLog(String::Concat(functionName, " concluded"));
    }
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ToolStripEventLogTestDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_ToolStripEventLogVerboseDropDownClicked
//
// Handles the click of the Verbose Event Log drop down
//
// Called by:   QCOM_InstallToolStrip
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToolStripEventLogVerboseDropDownClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = _T("QCOM_ToolStripEventLogVerboseDropDownClicked");
    //------------------------------------------------------------------------
    QCOM_EventLogVerboseEnabled = (QCOM_EventLogVerboseEnabled ? GUI_NO : GUI_YES);
    if (QCOM_EventLogVerboseEnabled)
    {
        if (!QCOM_EventLogBasicEnabled)
            QCOM_EventLogBasicEnabled = GUI_YES;
        QCOM_EstablishEventLog(String::Concat(functionName, " called"));
    }
    else
    {
        QCOM_UpdateEventLog(String::Concat(functionName, " called"));
        QCOM_EventLogBasicEnabled = GUI_NO;
        QCOM_EventLogDetailedEnabled = GUI_NO;
        QCOM_EventLogTestEnabled = GUI_NO;
        QCOM_ConcludeEventLog(String::Concat(functionName, " concluded"));
    }
    QCOM_UpdateMessageChecks();
}                                       // end of QCOM_ToolStripEventLogVerboseDropDownClicked()
//----------------------------------------------------------------------------
// QCOM_UpdateErrorLog
//
// Updates the error log file with the specified line, preceded by a date-and-
// time stamp
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateErrorLog(
    String          ^descriptionString)
{
    String          ^lineString;
    StreamWriter    ^textWriter;
    DateTime        dateTime = DateTime::Now;
    //------------------------------------------------------------------------
    if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_ERROR_LOG_SPECIFIED) &&
        StringSet(descriptionString))
    {
        //--------------------------------------------------------------------
        // Replace the line terminations
        //--------------------------------------------------------------------
        descriptionString = descriptionString->Replace(QCOM_STRING_LF, Environment::NewLine);
        if (descriptionString->Contains(Environment::NewLine))
        {
            lineString = descriptionString->Replace(
                Environment::NewLine,
                String::Concat(Environment::NewLine, _T("                     :     ")));
        }
        else
        {
            lineString = descriptionString;
        }
        lineString = String::Format(
            "{0:D2} {1} {2:D4} {3:D2}:{4:D2}:{5:D2} : {6}",
            dateTime.Day,
            QCOM_MonthStringArray[dateTime.Month],
            dateTime.Year,
            dateTime.Hour,
            dateTime.Minute,
            dateTime.Second,
            lineString);
        textWriter = File::AppendText(QCOM_GeneralInfo->errorLogPath);
        if (textWriter)
        {
            textWriter->WriteLine(lineString);
            textWriter->Close();
        }
    }
}                                       // end of QCOM_UpdateErrorLog()
//----------------------------------------------------------------------------
// QCOM_UpdateEventLog
//
// Updates the event log file with the specified line, preceded by a date-and-
// time stamp
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateEventLog(
    String          ^descriptionString)
{
    String          ^lineString;
    StreamWriter    ^textWriter;
    DateTime        dateTime = DateTime::Now;
    //------------------------------------------------------------------------
    if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_EVENT_LOG_SPECIFIED) &&
        StringSet(descriptionString))
    {
        //--------------------------------------------------------------------
        // Replace the line terminations
        //--------------------------------------------------------------------
        descriptionString = descriptionString->Replace(QCOM_STRING_LF, Environment::NewLine);
        if (descriptionString->Contains(Environment::NewLine))
        {
            lineString = descriptionString->Replace(
                Environment::NewLine,
                String::Concat(Environment::NewLine, _T("                     :     ")));
        }
        else
        {
            lineString = descriptionString;
        }
        lineString = String::Format(
            "{0:D2} {1} {2:D4} {3:D2}:{4:D2}:{5:D2} : {6}",
            dateTime.Day,
            QCOM_MonthStringArray[dateTime.Month],
            dateTime.Year,
            dateTime.Hour,
            dateTime.Minute,
            dateTime.Second,
            lineString);
        try
        {
            textWriter = File::AppendText(QCOM_GeneralInfo->eventLogPath);
            if (textWriter)
            {
                textWriter->WriteLine(lineString);
                textWriter->Close();
            }
        }
        catch (Exception ^ex)
        {
            UNREFERENCED_PARAMETER(ex);
            //----------------------------------------------------------------
            // If the write failed, just ignore the failure and move on
            //----------------------------------------------------------------
        }
    }
}                                       // end of QCOM_UpdateEventLog()
//----------------------------------------------------------------------------
#endif      // QCONFIG_CPP
//============================================================================
// End of QConfig.cpp
//============================================================================
