//============================================================================
// Sampling.cpp
//
// The regular and event methods used by GUI.cpp for transducer sampling
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     SAMPLING_CPP
#define     SAMPLING_CPP
#include    "Sampling.h"
//----------------------------------------------------------------------------
// QCOM_GetPressureValue
//
// Retrieves the pressure value in the specified units from the specified
// transducer
//----------------------------------------------------------------------------
    double QCOM_GUIClass::
QCOM_GetPressureValue(
    UnitInfo        ^unit,
    int             units)
{
    double          pressureValue = 0.0;
    String          ^functionName = _T("QCOM_GetPressureValue");
    //------------------------------------------------------------------------
    RecordDetailedEvent("{0} called", functionName);
    if (QCOM_UnitValid(unit))
    {
        if (units < QCOM_PressureUnitsStringArray->Length)
        {
            pressureValue = unit->pressureValuePSI * QCOM_PressureUnitsPerPSI[units];
            RecordDetailedEvent("    {0}({1:D}) : Pressure = {2:F4} {3}",
                functionName, unit->unitNumber,
                pressureValue, QCOM_PressureUnitsStringArray[units]);
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0}({1:D}) :\nEncountered invalid pressure units {2:D}",
                functionName, unit->unitNumber,
                units);
        }
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
    RecordDetailedEvent("{0} concluded, returning {1:F4}", functionName, pressureValue);
    return pressureValue;
}                                       // end of QCOM_GetPressureValue()
//----------------------------------------------------------------------------
// QCOM_GetTemperatureValue
//
// Retrieves the temperature value in the specified units from the specified
// transducer
//----------------------------------------------------------------------------
    double QCOM_GUIClass::
QCOM_GetTemperatureValue(
    UnitInfo        ^unit,
    int             units)
{
    double          temperatureValue = 0.0;
    String          ^functionName = _T("QCOM_GetTemperatureValue");
    //------------------------------------------------------------------------
    RecordDetailedEvent("{0} called", functionName);
    if (QCOM_UnitValid(unit))
    {
        switch (units)
        {
            case QCOM_TEMPERATURE_UNITS_CELSIUS :
                temperatureValue = unit->temperatureValueCelsius;
                break;
            case QCOM_TEMPERATURE_UNITS_FAHRENHEIT :
                temperatureValue = FahrenheitFromCelsius(unit->temperatureValueCelsius);
                break;
            case QCOM_TEMPERATURE_UNITS_KELVIN :
                if (unit->temperatureValueCelsius)
                    temperatureValue = unit->temperatureValueCelsius + QCOM_CELSIUS_TO_KELVIN;
                break;
            case QCOM_TEMPERATURE_UNITS_RANKINE :
                if (unit->temperatureValueCelsius)
                    temperatureValue = FahrenheitFromCelsius(unit->temperatureValueCelsius) + QCOM_FAHRENHEIT_TO_RANKINE;
                break;
            default :
                QCOM_RecordAndModalErrorEvent(
                    "{0}({1:D}) :\nEncountered invalid temperature units {2:D}",
                    functionName, unit->unitNumber,
                    units);
                break;
        }
        if (units < QCOM_TemperatureUnitsStringArray->Length)
        {
            RecordDetailedEvent("    {0}({1:D}) : Temperature = {2:F4} {3}",
                functionName, unit->unitNumber,
                temperatureValue, QCOM_TemperatureUnitsStringArray[units]);
        }
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
    RecordDetailedEvent("{0} concluded, returning {1:F4}", functionName, temperatureValue);
    return temperatureValue;
}                                       // end of QCOM_GetTemperatureValue()
//----------------------------------------------------------------------------
// QCOM_MarkSampleTimeThread
//
// Updates the continuously sampling time and/or the continuously logging
// time labels with the current elapsed times
//
// Called by:   QCOM_SamplingTimerElapsed
//
// Note:    This method is spawned from the sampling timer thread in
//          QCOM_SamplingTimerElapsed
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MarkSampleTimeThread(void)
{
    int             lapsedDays;
    int             lapsedHours;
    int             lapsedMinutes;
    int             lapsedSeconds;
    int             lapsedMilliseconds;
    DWORD           totalLapsedMinutes;
    DWORD           currentTime = GetTickCount();
    //------------------------------------------------------------------------
    if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED))
    {
        QCOM_SamplingElapsedTime = currentTime - QCOM_SamplingStartTime;
        totalLapsedMinutes = QCOM_SamplingElapsedTime / 60000;
        QCOM_TimeElapsed(
            QCOM_SamplingElapsedTime,
            &lapsedDays,
            &lapsedHours,
            &lapsedMinutes,
            &lapsedSeconds,
            &lapsedMilliseconds);
        readoutContinuousSamplingTimeLabel->Text = String::Format(
            "Sampling continuously for {0:D} d {1:D} h {2:D} m {3:D} s",
            lapsedDays,
            lapsedHours,
            lapsedMinutes,
            lapsedSeconds);
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_SAMPLING_TIME_LIMITED)
        {
            readoutLimitSamplingTimeMinutesRemainingLabel->Text = String::Format(
                "({0:D} remaining)", (QCOM_MaximumSamplingRunTimeMinutes - totalLapsedMinutes));
        }
        if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING)
        {
            QCOM_LoggingElapsedTime = currentTime - QCOM_LoggingStartTime;
            QCOM_TimeElapsed(
                QCOM_LoggingElapsedTime,
                &lapsedDays,
                &lapsedHours,
                &lapsedMinutes,
                &lapsedSeconds,
                &lapsedMilliseconds);
            logAllContinuousLoggingTimeLabel->Text = String::Format(
                "Logging continuously for {0:D} d {1:D} h {2:D} m {3:D} s",
                lapsedDays,
                lapsedHours,
                lapsedMinutes,
                lapsedSeconds);
            if (QCOM_GeneralInfo->flags & QCOM_GENERAL_SAMPLING_TIME_LIMITED)
            {
                logAllLimitLoggingTimeMinutesRemainingLabel->Text = String::Format(
                    "({0:D} remaining)", (QCOM_MaximumSamplingRunTimeMinutes - totalLapsedMinutes));
            }
        }
        if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_SAMPLING_TIME_LIMITED) &&
            (totalLapsedMinutes >= QCOM_MaximumSamplingRunTimeMinutes))
        {
            QCOM_StartStopSamplingAll();
        }
        else
        {
            QCOM_GeneralInfo->flags |= QCOM_GENERAL_PROCEED_TO_SAMPLE;
        }
    }                                   // end of if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED))
    QCOM_ReadyToMarkSampleTime = GUI_NO;
}                                       // end of QCOM_MarkSampleTimeThread()
//----------------------------------------------------------------------------
// QCOM_QueryStopSampling
//
// If the transducers are being sampled with the timer, queries the user to
// stop the sampling
//
// Returns: GUI_YES     Transducers are being sampled, and the user does not
//                      want to stop the sampling
//          GUI_NO      Either the transducers are not being sampled, or if
//                      they are, the user has chosen to stop the sampling
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_QueryStopSampling(
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    bool            currentlySampling = GUI_NO;
    bool            stopSampling = GUI_YES;
    String          ^promptString;
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
    {
        currentlySampling = GUI_YES;
        if (StringSet(formatString))
        {
            String ^promptHeader = String::Format(formatString, parameters);
            promptString = String::Format(
                "{0}\nStop sampling now?",
                promptHeader);
            delete promptHeader;
        }
        else
        {
            promptString =
                _T("This function could not be performed while transducers are being sampled\n") \
                _T("Stop sampling now?");
        }
        stopSampling = QCOM_PromptModal(
            "Transducers Currently Sampling",
            promptString);
        if (stopSampling)
        {
            QCOM_StartStopSamplingAll();
            currentlySampling =
                (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING) ?
                    GUI_YES : GUI_NO;
        }
    }
    return currentlySampling;
}                                       // end of QCOM_QueryStopSampling()
//----------------------------------------------------------------------------
// QCOM_ReadoutAlternatePressureTemperatureRadioSelected
//
// Handles the click of the Alternate Pressure / Temperature radio button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//              QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutAlternatePressureTemperatureRadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Alternate Pressure ({0}) and Temperature ({1}) radio button selected",
        QCOM_PressureUnitsStringArray[QCOM_AlternatePressureUnits],
        QCOM_TemperatureUnitsStringArray[QCOM_AlternateTemperatureUnits]);
    QCOM_ReadoutDisplayAlternateUnits();
    QCOM_LogAllUpdateCaptions();
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberLegal(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
            QCOM_GraphingClearGraph(unit);
            QCOM_GraphingDisplayCurrentBoundaryValues(unit);
        }
    }
}                                       // end of QCOM_ReadoutAlternatePressureTemperatureRadioSelected()
//----------------------------------------------------------------------------
// QCOM_ReadoutAlternatePressureUnitsComboProcessEnterKey
//
// Processes the result of accepting the Enter key in the Alternate Pressure
// Units combo box
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutAlternatePressureUnitsComboProcessEnterKey(
    Object          ^sender,
    KeyEventArgs    ^evt)
{
    //------------------------------------------------------------------------
    if (evt->KeyCode == Keys::Enter)
    {
        RecordBasicEvent(
            "Alternate Pressure Box Enter Key pressed for {0}",
            readoutAlternatePressureUnitsCombo->Text);
        QCOM_FormerPressureUnits = QCOM_CurrentPressureUnits;
        QCOM_CurrentPressureUnits = QCOM_AlternatePressureUnits =
            readoutAlternatePressureUnitsCombo->FindString(readoutAlternatePressureUnitsCombo->Text);
        evt->SuppressKeyPress = GUI_YES;
        QCOM_UpdateAllReadouts();
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
        QCOM_LogAllUpdateCaptions();
        for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
        {
            if (QCOM_UnitNumberLegal(unitNumber))
            {
                UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
//                QCOM_GraphingConvertBoundaryUnits(unit, GUI_UNIT_GRAPH_CONTEXT_PRESSURE);
                QCOM_GraphingClearGraph(unit);
                QCOM_GraphingDisplayCurrentBoundaryValues(unit);
            }
        }
    }
}                                       // end of QCOM_ReadoutAlternatePressureUnitsComboProcessEnterKey()
//----------------------------------------------------------------------------
// QCOM_ReadoutAlternatePressureUnitsComboProcessSelection
//
// Processes the result of selecting an item in the Alternate Pressure Units
// combo box
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutAlternatePressureUnitsComboProcessSelection(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent(
        "Alternate Pressure Box item selected for {0}",
        readoutAlternatePressureUnitsCombo->Text);
    QCOM_AlternatePressureUnits =
        readoutAlternatePressureUnitsCombo->FindString(readoutAlternatePressureUnitsCombo->Text);
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_DISPLAY_ALT_UNITS)
    {
        QCOM_FormerPressureUnits = QCOM_CurrentPressureUnits;
        QCOM_CurrentPressureUnits = QCOM_AlternatePressureUnits;
    }
    QCOM_UpdateAllReadouts();
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    QCOM_LogAllUpdateCaptions();
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberLegal(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
//            QCOM_GraphingConvertBoundaryUnits(unit, GUI_UNIT_GRAPH_CONTEXT_PRESSURE);
            QCOM_GraphingClearGraph(unit);
            QCOM_GraphingDisplayCurrentBoundaryValues(unit);
        }
    }
}                                       // end of QCOM_ReadoutAlternatePressureUnitsComboProcessSelection()
//----------------------------------------------------------------------------
// QCOM_ReadoutAlternateTemperatureUnitsComboProcessEnterKey
//
// Processes the result of accepting the Enter key in the Alternate Temperature
// Units combo box
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutAlternateTemperatureUnitsComboProcessEnterKey(
    Object          ^sender,
    KeyEventArgs    ^evt)
{
    //------------------------------------------------------------------------
    if (evt->KeyCode == Keys::Enter)
    {
        RecordBasicEvent(
            "Alternate Temperature Box Enter Key pressed for {0}",
            readoutAlternateTemperatureUnitsCombo->Text);
        QCOM_FormerTemperatureUnits = QCOM_CurrentTemperatureUnits;
        QCOM_CurrentTemperatureUnits = QCOM_AlternateTemperatureUnits =
            readoutAlternateTemperatureUnitsCombo->FindString(readoutAlternateTemperatureUnitsCombo->Text);
        evt->SuppressKeyPress = GUI_YES;
        QCOM_UpdateAllReadouts();
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
        QCOM_LogAllUpdateCaptions();
        for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
        {
            if (QCOM_UnitNumberLegal(unitNumber))
            {
                UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
//                QCOM_GraphingConvertBoundaryUnits(unit, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE);
                QCOM_GraphingClearGraph(unit);
                QCOM_GraphingDisplayCurrentBoundaryValues(unit);
            }
        }
    }
}                                       // end of QCOM_ReadoutAlternateTemperatureUnitsComboProcessEnterKey()
//----------------------------------------------------------------------------
// QCOM_ReadoutAlternateTemperatureUnitsComboProcessSelection
//
// Processes the result of selecting an item in the Alternate Temperature Units
// combo box
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutAlternateTemperatureUnitsComboProcessSelection(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent(
        "Alternate Temperature Box item selected for {0}",
        readoutAlternateTemperatureUnitsCombo->Text);
    QCOM_AlternateTemperatureUnits =
        readoutAlternateTemperatureUnitsCombo->FindString(readoutAlternateTemperatureUnitsCombo->Text);
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_DISPLAY_ALT_UNITS)
    {
        QCOM_FormerTemperatureUnits = QCOM_CurrentTemperatureUnits;
        QCOM_CurrentTemperatureUnits = QCOM_AlternateTemperatureUnits;
    }
    QCOM_UpdateAllReadouts();
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    QCOM_LogAllUpdateCaptions();
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberLegal(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
//            QCOM_GraphingConvertBoundaryUnits(unit, GUI_UNIT_GRAPH_CONTEXT_TEMPERATURE);
            QCOM_GraphingClearGraph(unit);
            QCOM_GraphingDisplayCurrentBoundaryValues(unit);
        }
    }
}                                       // end of QCOM_ReadoutAlternateTemperatureUnitsComboProcessSelection()
//----------------------------------------------------------------------------
// QCOM_ReadoutCountsRadioSelected
//
// Handles the click of the Counts radio button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutCountsRadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Counts radio button selected");
    QCOM_ReadoutCountsSelected();
}                                       // end of QCOM_ReadoutCountsRadioSelected()
//----------------------------------------------------------------------------
// QCOM_ReadoutCountsSelected
//
// Performs the tasks that result from the transducer counts selection
//
// Called by:   GUI_CountsRadioButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutCountsSelected(void)
{
    DWORD           status = QCOM_SUCCESS;
    String          ^functionName = FunctionName();
    //------------------------------------------------------------------------
    QCOM_GeneralInfo->flags |= QCOM_GENERAL_DISPLAY_COUNTS;
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberLegal(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
            unit->flags |= QCOM_UNIT_DISPLAY_COUNTS;
            if (QCOM_UnitReady(unit) && !(unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING))
            {
                status = QCOM_RetrieveTransducerReadings(unit);
            }
            if (status == QCOM_SUCCESS)
                QCOM_UpdateReadout(unit);
            else
                status = QCOM_SUCCESS;
        }
    }
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
}                                       // end of QCOM_ReadoutCountsSelected()
//----------------------------------------------------------------------------
// QCOM_ReadoutDefaultPressureTemperatureRadioSelected
//
// Handles the click of the Default Temperature and Pressure radio button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//              QCOM_SetUpUnitGraphingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDefaultPressureTemperatureRadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Default Pressure ({0})and Temperature ({1}) radio button selected",
        QCOM_PressureUnitsStringArray[QCOM_DefaultPressureUnits],
        QCOM_TemperatureUnitsStringArray[QCOM_DefaultTemperatureUnits]);
    QCOM_ReadoutDisplayDefaultUnits();
    QCOM_LogAllUpdateCaptions();
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberLegal(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
            QCOM_GraphingClearGraph(unit);
            QCOM_GraphingDisplayCurrentBoundaryValues(unit);
        }
    }
}                                       // end of QCOM_ReadoutDefaultPressureTemperatureRadioSelected()
//----------------------------------------------------------------------------
// QCOM_ReadoutDisplayAllFrequenciesChecked
//
// Handles the check of the Display All Frequencies checkbox
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDisplayAllFrequenciesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralFlagThenSetUnitFlags(
        QCOM_GENERAL_DISPLAY_ALL_FREQUENCIES,
        QCOM_UNIT_DISPLAY_FREQUENCIES);
    RecordBasicEvent(
        "Display All Frequencies {0}",
        ((QCOM_GeneralInfo->flags & QCOM_GENERAL_DISPLAY_ALL_FREQUENCIES) ? "checked" : "un-checked"));
    QCOM_UpdateAllReadouts();
}                                       // end of QCOM_ReadoutDisplayAllFrequenciesChecked()
//----------------------------------------------------------------------------
// QCOM_ReadoutDisplayAllVIValuesChecked
//
// Handles the check of the Display All V/I Values checkbox
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDisplayAllVIValuesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralFlagThenSetUnitFlags(
        QCOM_GENERAL_DISPLAY_ALL_VI_VALUES,
        QCOM_UNIT_DISPLAY_VI_VALUES);
    RecordBasicEvent(
        "Display ALL VI Values {0}",
        ((QCOM_GeneralInfo->flags & QCOM_GENERAL_DISPLAY_ALL_VI_VALUES) ? "checked" : "un-checked"));
    QCOM_UpdateAllReadouts();
}                                       // end of QCOM_ReadoutDisplayAllVIValuesChecked()
//----------------------------------------------------------------------------
// QCOM_ReadoutDisplayAlternateUnits
//
// Displays the alternate pressure and temperature values in the Readout page
//
// Called by:   QCOM_ReadoutAlternatePressureTemperatureRadioSelected
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDisplayAlternateUnits(void)
{
    DWORD           status = QCOM_SUCCESS;
    String          ^functionName = _T("QCOM_ReadoutDisplayAlternateUnits");
    //------------------------------------------------------------------------
    QCOM_FormerPressureUnits = QCOM_CurrentPressureUnits;
    QCOM_CurrentPressureUnits = QCOM_AlternatePressureUnits;
    QCOM_FormerTemperatureUnits = QCOM_CurrentTemperatureUnits;
    QCOM_CurrentTemperatureUnits = QCOM_AlternateTemperatureUnits;
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_DISPLAY_COUNTS)
        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_DISPLAY_COUNTS;
    QCOM_GeneralInfo->flags |= QCOM_GENERAL_DISPLAY_ALT_UNITS;
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberLegal(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
            if (unit->flags & QCOM_UNIT_DISPLAY_COUNTS)
                unit->flags &= ~QCOM_UNIT_DISPLAY_COUNTS;
            unit->flags |= QCOM_UNIT_DISPLAY_ALT_UNITS;
            if (QCOM_UnitReady(unit) && !(unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING))
            {
                status = QCOM_RetrieveTransducerReadings(unit);
            }
            if (status == QCOM_SUCCESS)
                QCOM_UpdateReadout(unit);
            else
                status = QCOM_SUCCESS;
        }
    }
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    QCOM_LogAllUpdateCaptions();
}                                       // end of QCOM_ReadoutDisplayAlternateUnits()
//----------------------------------------------------------------------------
// QCOM_ReadoutDisplayDefaultUnits
//
// Displays the default pressure and temperature values in the Readout page
//
// Called by:   QCOM_ReadoutDefaultPressureTemperatureRadioSelected
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDisplayDefaultUnits(void)
{
    DWORD           status = QCOM_SUCCESS;
    String          ^functionName = _T("QCOM_ReadoutDisplayDefaultUnits");
    //------------------------------------------------------------------------
    QCOM_FormerPressureUnits = QCOM_CurrentPressureUnits;
    QCOM_CurrentPressureUnits = QCOM_DefaultPressureUnits;
    QCOM_FormerTemperatureUnits = QCOM_CurrentTemperatureUnits;
    QCOM_CurrentTemperatureUnits = QCOM_DefaultTemperatureUnits;
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_DISPLAY_COUNTS)
        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_DISPLAY_COUNTS;
    QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_DISPLAY_ALT_UNITS;
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberLegal(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
            if (unit->flags & QCOM_UNIT_DISPLAY_COUNTS)
                unit->flags &= ~QCOM_UNIT_DISPLAY_COUNTS;
            unit->flags &= ~QCOM_UNIT_DISPLAY_ALT_UNITS;
            if (QCOM_UnitReady(unit) && !(unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING))
            {
                status = QCOM_RetrieveTransducerReadings(unit);
            }
            if (status == QCOM_SUCCESS)
                QCOM_UpdateReadout(unit);
            else
                status = QCOM_SUCCESS;
        }
    }
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    QCOM_LogAllUpdateCaptions();
}                                       // end of QCOM_ReadoutDisplayDefaultUnits()
//----------------------------------------------------------------------------
// QCOM_ReadoutDisplayUnitFrequenciesChecked
//
// Handles the check of the Display Frequencies checkbox
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDisplayUnitFrequenciesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    DWORD           status = QCOM_SUCCESS;
    String          ^functionName = _T("QCOM_ReadoutDisplayUnitFrequenciesChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_DISPLAY_ALL_FREQUENCIES,
            QCOM_UNIT_DISPLAY_FREQUENCIES);
        RecordBasicEvent(
            "Display Frequencies {0} on module {1}",
            ((unit->flags & QCOM_UNIT_DISPLAY_FREQUENCIES) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        if (QCOM_UnitReady(unit) && !(unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING))
        {
            status = QCOM_RetrieveTransducerReadings(unit);
        }
        if (status == QCOM_SUCCESS)
            QCOM_UpdateReadout(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_ReadoutDisplayUnitFrequenciesChecked()
//----------------------------------------------------------------------------
// QCOM_ReadoutDisplayUnitVIValuesChecked
//
// Handles the check of the Display V/I Values checkbox
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutDisplayUnitVIValuesChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    DWORD           status = QCOM_SUCCESS;
    String          ^functionName = _T("QCOM_ReadoutDisplayUnitVIValuesChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_DISPLAY_ALL_VI_VALUES,
            QCOM_UNIT_DISPLAY_VI_VALUES);
        RecordBasicEvent(
            "Display VI Values {0} on module {1}",
            ((unit->flags & QCOM_UNIT_DISPLAY_VI_VALUES) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        if (QCOM_UnitReady(unit) && !(unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING))
        {
            status = QCOM_RetrieveTransducerReadings(unit);
        }
        if (status == QCOM_SUCCESS)
            QCOM_UpdateReadout(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_ReadoutDisplayUnitVIValuesChecked()
//----------------------------------------------------------------------------
// QCOM_ReadoutHexCountsChecked
//
// Handles the click of the Hex radio button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutHexCountsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralFlagThenSetUnitFlags(
        QCOM_GENERAL_DISPLAY_COUNTS_IN_HEX,
        QCOM_UNIT_DISPLAY_COUNTS_IN_HEX);
    RecordBasicEvent(
        "Hex Counts {0}",
        ((QCOM_GeneralInfo->flags & QCOM_GENERAL_DISPLAY_COUNTS_IN_HEX) ? "checked" : "un-checked"));
    QCOM_UpdateAllReadouts();
}                                       // end of QCOM_ReadoutHexCountsChecked()
//----------------------------------------------------------------------------
// QCOM_ReadoutIncludeAllInSamplingChecked
//
// Handles the check of the Include All In Sampling checkbox
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutIncludeAllInSamplingChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralFlagThenSetUnitFlags(
        QCOM_GENERAL_INCLUDE_ALL_IN_SAMPLING,
        QCOM_UNIT_INCLUDE_IN_SAMPLING);
    RecordBasicEvent(
        "Include All in Sampling {0}",
        ((QCOM_GeneralInfo->flags & QCOM_GENERAL_INCLUDE_ALL_IN_SAMPLING) ? "checked" : "un-checked"));
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
}                                       // end of QCOM_ReadoutIncludeAllInSamplingChecked()
//----------------------------------------------------------------------------
// QCOM_ReadoutIncludeUnitInSamplingChecked
//
// Event that handles the check or uncheck of the Include In Sampling check box
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutIncludeUnitInSamplingChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_ReadoutIncludeUnitInSamplingChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_INCLUDE_ALL_IN_SAMPLING,
            QCOM_UNIT_INCLUDE_IN_SAMPLING);
        RecordBasicEvent(
            "Include in Sampling {0} on module {1}",
            ((unit->flags & QCOM_UNIT_INCLUDE_IN_SAMPLING) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_ReadoutIncludeUnitInSamplingChecked()
//----------------------------------------------------------------------------
// QCOM_ReadoutLimitSamplingTimeChecked
//
// Handles the check of the Run For a Specified Time box
//
// Called by:   QCOM_ConstructGeneralExpertGroupBox
//              QCOM_ReadoutLimitSamplingTimeChecked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutLimitSamplingTimeChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralFlagThenSetUnitFlags(
        QCOM_GENERAL_SAMPLING_TIME_LIMITED,
        QCOM_UNIT_ZERO_FLAG);
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_SAMPLING_TIME_LIMITED)
    {
        readoutRunSamplingTimedCheck->Checked = GUI_YES;
        readoutLimitSamplingTimeLabel->Visible = GUI_YES;
        readoutLimitSamplingTimeBox->Visible = GUI_YES;
        readoutLimitSamplingTimeMinutesLabel->Visible = GUI_YES;
        readoutLimitSamplingTimeMinutesRemainingLabel->Visible = GUI_YES;
        logAllRunLoggingTimedCheck->Checked = GUI_YES;
        logAllLimitLoggingTimeLabel->Visible = GUI_YES;
        logAllLimitLoggingTimeBox->Visible = GUI_YES;
        logAllLimitLoggingTimeMinutesLabel->Visible = GUI_YES;
        logAllLimitLoggingTimeMinutesRemainingLabel->Text = QCOM_STRING_EMPTY;
        logAllLimitLoggingTimeMinutesRemainingLabel->Visible = GUI_YES;
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
        {
            QCOM_StartStopSamplingAll();
        }
    }
    else
    {
        readoutRunSamplingTimedCheck->Checked = GUI_NO;
        readoutLimitSamplingTimeLabel->Visible = GUI_NO;
        readoutLimitSamplingTimeBox->Visible = GUI_NO;
        readoutLimitSamplingTimeMinutesLabel->Visible = GUI_NO;
        readoutLimitSamplingTimeMinutesRemainingLabel->Visible = GUI_NO;
        logAllRunLoggingTimedCheck->Checked = GUI_NO;
        logAllLimitLoggingTimeBox->Visible = GUI_NO;
        logAllLimitLoggingTimeLabel->Visible = GUI_NO;
        logAllLimitLoggingTimeMinutesLabel->Visible = GUI_NO;
        logAllLimitLoggingTimeMinutesRemainingLabel->Visible = GUI_NO;
    }
    RecordBasicEvent(
        "Limit Sampling Time {0}",
        ((QCOM_GeneralInfo->flags & QCOM_GENERAL_SAMPLING_TIME_LIMITED) ? "checked" : "un-checked"));
}                                       // end of QCOM_ReadoutLimitSamplingTimeChecked()
//----------------------------------------------------------------------------
// QCOM_ReadoutUnitStartStopSamplingButtonClicked
//
// Handles the click of the readout unit Start / Stop Sampling button
//
// Called by:   QCOM_ConstructUnitReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReadoutUnitStartStopSamplingButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_ReadoutUnitStartStopSamplingButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "    {0} Sampling button clicked for module {1}",
            ((unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING) ? "Stop" : "Start"),
            unit->moduleSerialNumber);
        QCOM_StartStopSamplingUnit(unit);
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitNumberLegal(unitNumber))
    else
    {
        RecordErrorEvent("{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_ReadoutUnitStartStopSamplingButtonClicked()
//----------------------------------------------------------------------------
// QCOM_RetrieveTransducerReadings
//
// Retrieves both the count and conversion of the pressure and the temperature
// values of the specified transducer, plus their voltage and current readings
//
// Returns: 0           Success
//          nonzero     Failure
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_RetrieveTransducerReadings(
    UnitInfo        ^unit)
{
    int             attempts = 3;           // three attempts
    double          pressureValuePSI = 0.0;
    double          temperatureValueCelsius = 0.0;
    double          transducerAmperage = 0.0;
    double          transducerVoltage = 0.0;
    LPBYTE          coefficientData = (LPBYTE) 0;
    DWORD           pressureCount = 0;
    DWORD           status = QCOM_SUCCESS;
    DWORD           temperatureCount = 0;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_RetrieveTransducerReadings");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        //--------------------------------------------------------------------
        // Reset all values, to prevent displaying stale values, should the
        // the transducer readings suddenly become unavailable
        //--------------------------------------------------------------------
        unit->pressureCount = 0;
        unit->temperatureCount = 0;
        unit->pressureValuePSI = 0.0;
        unit->temperatureValueCelsius = 0.0;
        unit->transducerVoltage = 0.0;
        unit->transducerAmperage = 0.0;
        String ^MSN = unit->moduleSerialNumber;
        String ^TSN = unit->transducerSerialNumber;
        coefficientData = (LPBYTE) unit->coefficientData;
        if (coefficientData &&
            (unit->flags & QCOM_UNIT_COEFFICIENTS_VERIFIED))
        {
//            bool spinLockAcquired = GUI_NO;
//            try
//            {
//                QCOM_UnitAccessSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                while (attempts--)
                {
                    status = QD_GetTransducerCounts(
                        unit->unitHandle,
                        &pressureCount,
                        &temperatureCount);
                    if (status == QD_SUCCESS)
                    {
                        unit->pressureCount = pressureCount;
                        unit->temperatureCount = temperatureCount;
                        attempts = 0;
                    }
                    else
                    {
                        if (attempts)
                        {
                            status = QCOM_SUCCESS;
                            Sleep(1000);
                        }
                    }
                }
                if (status == QD_SUCCESS)
                {
                    status = QD_CalculatePressureAndTemperature(
                        coefficientData,
                        pressureCount,
                        temperatureCount,
                        &pressureValuePSI,
                        &temperatureValueCelsius);
                    if (status == QD_SUCCESS)
                    {
                        unit->pressureValuePSI = pressureValuePSI;
                        unit->temperatureValueCelsius = temperatureValueCelsius;
                        RecordDetailedEvent(
                            "Successfully completed pressure and temperature calculations for module {0} transducer {1}\n"
                            "Pressure = {2:F3} psi\nTemperature = {3:F3} �C",
                            MSN, TSN, pressureValuePSI, temperatureValueCelsius);
                    }
                    else
                    {
                        RecordErrorEvent(
                            "{0}({1:D}) :\nQD_CalculatePressureAndTemperature failed with error 0x{2:X8}\n"
                            "on module {3} transducer {4}",
                            functionName, unitNumber, status, MSN, TSN);
                    }
                }
                else
                {
                    RecordErrorEvent(
                        "{0}({1:D}) :\nFailed getting counts with error 0x{2:X8}\n"
                        "on module {3} transducer {4}",
                        functionName, unitNumber, status, MSN, TSN);
                }
                if (status == QD_SUCCESS)
                {
                    status = QD_GetTransducerVoltage(
                        unit->unitHandle,
                        &transducerVoltage);
                    if (status == QD_SUCCESS)
                    {
                        unit->transducerVoltage = transducerVoltage;
                    }
                    else
                    {
                        RecordErrorEvent(
                            "{0}({1:D}) :\nFailed getting voltage reading with error 0x{2:X8}\n"
                            "on module {3} transducer {4}",
                            functionName, unitNumber, status, MSN, TSN);
                    }
                    status = QD_GetTransducerCurrent(
                        unit->unitHandle,
                        &transducerAmperage);
                    //--------------------------------------------------------
                    // The qdUSB.dll module will return error 0x23030027 if
                    // the transducer amperage is detected to read less than
                    // 0.5 mA, which has been the source of some controversy
                    //--------------------------------------------------------
                    if (status == (QD_LOCUS_GET_TRANSDUCER_CURRENT_3 | QD_ERROR_XD_CURRENT_TOO_LOW))
                    {
                        DWORD currentCount = 0;
                        status = QD_ReadUnitADC(
                            unit->unitHandle,
                            QD_READ_ADC_CHANNEL_CURRENT,                        // 0x04
                            &currentCount);
                        if (status == QD_SUCCESS)
                        {
                            //------------------------------------------------
                            // The Current Scale (0.02819) is a derived value
                            // that is normally hidden from the application,
                            // but must be provided here due to the amperage
                            // calculation following the call to
                            // QD_ReadUnitADC
                            //------------------------------------------------
                            transducerAmperage = (DOUBLE) currentCount * 0.02819;
                        }
                    }
                    if (status == QD_SUCCESS)
                    {
                        unit->transducerAmperage = transducerAmperage;
                    }
                    else
                    {
                        RecordErrorEvent(
                            "{0}({1:D}) :\nFailed getting amperage reading with error 0x{2:X8}\n"
                            "on module {3} transducer {4}",
                            functionName, unitNumber, status, MSN, TSN);
                    }
                }                       // end of if (status == QD_SUCCESS)
//            }                           // end of try
//            finally
//            {
//                if (spinLockAcquired == GUI_YES)
//                    QCOM_UnitAccessSpinLockArray[unitNumber]->Exit();
//            }
        }                               // end of if (coefficientData && ...)
        delete TSN;
        delete MSN;
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
        if (status == QD_SUCCESS)
        {
            status = QCOM_ERROR_UNIT_NOT_READY;
        }
    }
    return status;
}                                       // end of QCOM_RetrieveTransducerReadings()
//----------------------------------------------------------------------------
// QCOM_SamplingHoursRadioSelected
//
// Handles the click of the Hours radio button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//              QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SamplingHoursRadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Hours interval units radio button selected");
    QCOM_CurrentIntervalUnitsOffset = GUI_INTERVAL_HR_OFFSET;
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberLegal(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
            QCOM_GraphingClearGraph(unit);
        }
    }
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
}                                       // end of QCOM_SamplingHoursRadioSelected()
//----------------------------------------------------------------------------
// QCOM_SamplingMillisecondsRadioSelected
//
// Handles the click of the Milliseconds radio button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//              QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SamplingMillisecondsRadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Milliseconds interval units radio button selected");
    QCOM_CurrentIntervalUnitsOffset = GUI_INTERVAL_MS_OFFSET;
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberLegal(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
            QCOM_GraphingClearGraph(unit);
        }
    }
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
}                                       // end of QCOM_SamplingMillisecondsRadioSelected()
//----------------------------------------------------------------------------
// QCOM_SamplingMinutesRadioSelected
//
// Handles the click of the Minutes radio button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//              QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SamplingMinutesRadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Minutes interval units radio button selected");
    QCOM_CurrentIntervalUnitsOffset = GUI_INTERVAL_MIN_OFFSET;
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberLegal(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
            QCOM_GraphingClearGraph(unit);
        }
    }
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
}                                       // end of QCOM_SamplingMinutesRadioSelected()
//----------------------------------------------------------------------------
// QCOM_SamplingSecondsRadioSelected
//
// Handles the click of the Seconds radio button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//              QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SamplingSecondsRadioSelected(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Seconds interval units radio button selected");
    QCOM_CurrentIntervalUnitsOffset = GUI_INTERVAL_SEC_OFFSET;
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberLegal(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
            QCOM_GraphingClearGraph(unit);
        }
    }
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
}                                       // end of QCOM_SamplingSecondsRadioSelected()
//----------------------------------------------------------------------------
// QCOM_SamplingTimerElapsed
//
// Handles the lapsing of the sampling timer by updating the transducer readings
//
// Called by:   QCOM_InitializeGUIComponents
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SamplingTimerElapsed(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            errorEncountered = GUI_NO;
    String          ^functionName = _T("QCOM_SamplingTimerElapsed");
    //------------------------------------------------------------------------
    if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_PROCEED_TO_SAMPLE) &&
        !(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED))
    {
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberReady(unitNumber))
            {
                UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                if (unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING)
                {
                    DWORD status = QCOM_RetrieveTransducerReadings(unit);
                    if (status == QCOM_SUCCESS)
                    {
                        QCOM_UpdateReadout(unit);
                    }
                    else
                    {
                        errorEncountered = GUI_YES;
                        if (QCOM_HaltOperationsOnErrors)
                            QCOM_StartStopSamplingUnit(unit);
                        else
                            QCOM_ResetTransducer(unit);
                    }
                }
                //----------------------------------------------------------------
                // At least one field must be selected for logging
                //----------------------------------------------------------------
                if ((unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING) &&
                    (unit->dataLogPoints & QCOM_UNIT_LOG_ALL_POINTS))
                {
                    if (errorEncountered && QCOM_HaltOperationsOnErrors)
                        QCOM_StartStopDataLoggingUnit(unit);
                    else
                        QCOM_CollectDataSample(unitNumber);
                }
            }
        }                               // end of for (DWORD unitNumber = 0; ...)
        if (QCOM_ReadyToMarkSampleTime)
        {
            QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_PROCEED_TO_SAMPLE;
            Thread ^markSampleTimeThread =
                gcnew Thread(gcnew ThreadStart(this, &QCOM_GUIClass::QCOM_MarkSampleTimeThread));
            markSampleTimeThread->Start();
        }
        if (QD_DLLStatus)
        {
            //----------------------------------------------------------------
            // A DLL error can be catastrophic, so stop the sampling timer if
            // QCOM_HaltOperationsOnErrors is set
            //----------------------------------------------------------------
            if (QCOM_HaltOperationsOnErrors)
            {
                GUI_DisplayErrorWithStatus(functionName,
                    _T("DLL error encountered"),
                    nullptr,
                    QD_DLLStatus);
                QCOM_StartStopSamplingAll();
            }
            QD_DLLStatus = QCOM_SUCCESS;
        }
        else
        {
            //----------------------------------------------------------------
            // Reset the sampling timer
            //----------------------------------------------------------------
            samplingTimer->Start();
        }
        if (errorEncountered)
            QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    }                                   // end of if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_PROCEED_TO_SAMPLE) && ...
}                                       // end of QCOM_SamplingTimerElapsed()
//----------------------------------------------------------------------------
// QCOM_StartSamplingUnit
//
// Starts sampling for the specified unit if permitted, then sets the general
// flag
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StartSamplingUnit(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_StartSamplingUnit");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (!(unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING) &&
            (unit->flags & QCOM_UNIT_INCLUDE_IN_SAMPLING))
        {
            bool currentlyPowered = QCOM_QueryEnableTransducerPower(unit);
            if (currentlyPowered && QCOM_UnitReady(unit))
            {
                unit->flags |= QCOM_UNIT_CURRENTLY_SAMPLING;
                //------------------------------------------------------------
                // Set the general sampling flag
                //------------------------------------------------------------
                if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING))
                    QCOM_GeneralInfo->flags |= QCOM_GENERAL_CURRENTLY_SAMPLING;
                //------------------------------------------------------------
                // Get the current time and reset the sampling elapsed time
                //------------------------------------------------------------
                if (!QCOM_SamplingStartTime)
                {
                    QCOM_SamplingStartTime = GetTickCount();
                    QCOM_SamplingElapsedTime = 0;
                    DateTime dateTime = DateTime::Now;
                    unit->graphingPreviousTimeStampMinute =
                        (dateTime.Month * 1000000) + (dateTime.Day * 10000) + (dateTime.Hour * 100) + dateTime.Minute;
                }
                Thread ^markSampleTimeThread =
                    gcnew Thread(gcnew ThreadStart(this, &QCOM_GUIClass::QCOM_MarkSampleTimeThread));
                markSampleTimeThread->Start();
                RecordVerboseEvent("    Sampling started at {1:D} {2} intervals for unit {0:D}",
                    unit->unitNumber,
                    QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_RECENT_OFFSET],
                    QCOM_IntervalUnitsStringArray[QCOM_CurrentIntervalUnitsOffset]);
            }                           // end of if (currentlyPowered && QCOM_UnitReady(unit))
        }                               // end of if (!(unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING) && ...)
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_StartSamplingUnit()
//----------------------------------------------------------------------------
// QCOM_StartStopSamplingAll
//
// Toggle to start or stop sampling for all transducers
//
// Called by:   QCOM_StartStopSamplingButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StartStopSamplingAll(void)
{
    bool            atLeastOneSampling = GUI_NO;
    String          ^functionName = _T("QCOM_StartStopSamplingAll");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
    {
        bool oneStillSampling = GUI_NO;
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                if (unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING)
                {
                    atLeastOneSampling = GUI_YES;
                    if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
                        QCOM_ConcludeDataLoggingUnit(unit);
                    else
                        QCOM_StopSamplingUnit(unit);
                    if (unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING)
                        oneStillSampling = GUI_YES;
                }
            }
        }                               // end of for (DWORD unitNumber = 0; ...)
        if (!atLeastOneSampling)
            RecordErrorEvent("    {0} : General sampling flag was set but no units were sampling",
                functionName);
        if (oneStillSampling)
            RecordErrorEvent("    {0} : At least one unit still sampling after all were stopped",
                functionName);
//        QCOM_SamplingElapsedTime = 0;
        QCOM_StopPausedBlinker();
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED)
            QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_PROGRAM_PAUSED;
        readoutPauseResumeButton->Text = GUI_PAUSE_OPERATIONS_STRING;
        logAllPauseResumeButton->Text = GUI_PAUSE_ALL_STRING;
        testingPauseResumeButton->Text = GUI_PAUSE_ALL_STRING;
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
            QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_CURRENTLY_SAMPLING;
    }                                   // end of if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
    else
    {
        bool currentlyTesting = QCOM_QueryStopTesting(
            "Unable to start sampling while tests are running.");
        if (!currentlyTesting)
        {
            QCOM_GeneralInfo->flags |= QCOM_GENERAL_CURRENTLY_SAMPLING;
            //----------------------------------------------------------------
            // Start sampling
            //----------------------------------------------------------------
            QCOM_SamplingStartTime = GetTickCount();
            QCOM_SamplingElapsedTime = 0;
            for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
            {
                if (QCOM_UnitNumberValid(unitNumber))
                {
                    UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                    if (unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING)
                        atLeastOneSampling = GUI_YES;
                    else
                        QCOM_StartSamplingUnit(unit);
                }
                else
                {
                    QCOM_RecordAndModalErrorEvent(
                        "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                        functionName, unitNumber, QCOM_CurrentNumberOfUnits);
                }
            }                           // end of for (DWORD unitNumber = 0; ...)
            if (atLeastOneSampling)
                RecordErrorEvent("    {0} General sampling flag not set while a unit was sampling",
                    functionName);
            if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING))
                QCOM_GeneralInfo->flags |= QCOM_GENERAL_CURRENTLY_SAMPLING;
        }                               // end of if (!currentlyTesting)
    }                                   // end of else of if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_StartStopSamplingAll()
//----------------------------------------------------------------------------
// QCOM_StartStopSamplingButtonClicked
//
// Handles the click of the Start / Stop Sampling button
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//              QCOM_InstallHomeWindowGraphics
//              QCOM_SetUpAllDataLoggingWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StartStopSamplingButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    bool            currentlyTesting;
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_PROCEED_TO_SAMPLE;
    else
        QCOM_GeneralInfo->flags |= QCOM_GENERAL_PROCEED_TO_SAMPLE;
    RecordBasicEvent(
        "{0} Sampling button clicked",
        ((QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING) ? "Stop" : "Start"));
    currentlyTesting = QCOM_QueryStopTesting(
        "Sampling cannot be started while tests are running.");
    if (!currentlyTesting)
    {
        QCOM_StartStopSamplingAll();
    }
}                                       // end of QCOM_StartStopSamplingButtonClicked()
//----------------------------------------------------------------------------
// QCOM_StartStopSamplingUnit
//
// Toggle to start or stop sampling for the specified module
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StartStopSamplingUnit(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_StartStopSamplingUnit");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        if (unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING)
        {
            //----------------------------------------------------------------
            // Stop sampling and logging on this unit
            //----------------------------------------------------------------
            QCOM_StopSamplingUnit(unit);
            QCOM_StopDataLoggingUnit(unit);
        }
        else
        {
            //----------------------------------------------------------------
            // Start sampling on this unit
            //----------------------------------------------------------------
            QCOM_StartSamplingUnit(unit);
        }                               // end of else of if (unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING)
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_StartStopSamplingUnit()
//----------------------------------------------------------------------------
// QCOM_StopSamplingUnit
//
// Stops sampling for the specified unit, then updates the general flag if all
// units have stopped sampling
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StopSamplingUnit(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_StopSamplingUnit");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING)
        {
            //----------------------------------------------------------------
            // Stop sampling this unit
            //----------------------------------------------------------------
            unit->flags &= ~QCOM_UNIT_CURRENTLY_SAMPLING;
            RecordVerboseEvent("    Sampling stopped for unit {0:D}",
                unit->unitNumber);
            //----------------------------------------------------------------
            // Reset the general flag if no other units are sampling
            //----------------------------------------------------------------
            if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
            {
                bool atLeastOneSampling = GUI_NO;
                for (DWORD moduleNumber = 0; moduleNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; moduleNumber++)
                {
                    if (QCOM_UnitNumberValid(moduleNumber))
                    {
                        UnitInfo ^module = QCOM_UnitInfoArray[moduleNumber];
                        if (module->flags & QCOM_UNIT_CURRENTLY_SAMPLING)
                            atLeastOneSampling = GUI_YES;
                    }
                }
                if (!atLeastOneSampling)
                {
                    QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_CURRENTLY_SAMPLING;
                    RecordVerboseEvent("    General sampling flag reset when unit {0:D} sampling stopped",
                        unit->unitNumber);
                }
            }                           // end of if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
            else
            {
                //------------------------------------------------------------
                // Invalid state: This unit was sampling but the general flag
                // was not set
                //------------------------------------------------------------
                RecordErrorEvent("    General sampling flag not set while unit {0:D} was sampling",
                    unit->unitNumber);
            }
        }                               // end of if (unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING)
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_StopSamplingUnit()
//----------------------------------------------------------------------------
// QCOM_UpdateAllReadouts
//
// Updates the pressure and temperature text boxes on the readout tab for all
// units that are ready but not sampling
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateAllReadouts(void)
{
    DWORD           status = QCOM_SUCCESS;
    String          ^functionName = _T("QCOM_UpdateAllReadouts");
    //------------------------------------------------------------------------
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberReady(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
            if (!(unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING))
            {
                status = QCOM_RetrieveTransducerReadings(unit);
            }
            if (status == QCOM_SUCCESS)
                QCOM_UpdateReadout(unit);
            else
                status = QCOM_SUCCESS;
        }
    }
}                                       // end of QCOM_UpdateAllReadouts()
//----------------------------------------------------------------------------
// QCOM_UpdateReadout
//
// Updates the pressure and temperature text boxes on the readout tab with the
// current values stored in the unit structure
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateReadout(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    double          pressureFrequency;
    double          temperatureFrequency;
    String          ^functionName = _T("QCOM_UpdateReadout");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        if (unit->flags & QCOM_UNIT_DISPLAY_COUNTS)
        {
            String ^dataFormat = 
                (unit->flags & QCOM_UNIT_DISPLAY_COUNTS_IN_HEX) ?
                    _T("0x{0:X8}") : _T("{0:D}");
            readoutPressureBoxArray[unitNumber]->Text = String::Format(
                dataFormat, unit->pressureCount);
            readoutTemperatureBoxArray[unitNumber]->Text = String::Format(
                dataFormat, unit->temperatureCount);
            delete dataFormat;
        }
        else
        {
            //----------------------------------------------------------------
            // Format the floating point values according to the current
            // setting number of decimal places
            //----------------------------------------------------------------
            readoutPressureBoxArray[unitNumber]->Text = String::Format(
                QCOM_PrecisionFormatString,
                QCOM_GetPressureValue(unit, QCOM_CurrentPressureUnits));
            readoutTemperatureBoxArray[unitNumber]->Text = String::Format(
                QCOM_PrecisionFormatString,
                QCOM_GetTemperatureValue(unit, QCOM_CurrentTemperatureUnits));
        }                               // end of else of if (unit->flags & QCOM_UNIT_DISPLAY_COUNTS)
        QCOM_GraphingUpdateDisplayWindow(unit);
//        QCOM_RealTimeWeightUpdateDisplayWindow(unit);
        pressureFrequency =
            ((double) unit->pressureCount) * QCOM_FREQUENCY_MULTIPLIER;
        temperatureFrequency =
            ((double) unit->temperatureCount) * QCOM_FREQUENCY_MULTIPLIER;
        readoutPressureFrequencyBoxArray[unitNumber]->Text = String::Format(
            "{0:F3}", pressureFrequency);
        readoutTemperatureFrequencyBoxArray[unitNumber]->Text = String::Format(
            "{0:F3}", temperatureFrequency);
        readoutVoltageBoxArray[unitNumber]->Text = String::Format(
            "{0:F2}", unit->transducerVoltage);
        readoutAmperageBoxArray[unitNumber]->Text = String::Format(
            "{0:F2}", unit->transducerAmperage);
        //--------------------------------------------------------------------
        // The Event Log is stamped only here in this method due to the
        // possibly high frequency of being called
        //--------------------------------------------------------------------
        RecordDetailedEvent("{0}({1:D}) : Pres = {2} and Temp = {3}",
            functionName,
            unitNumber,
            readoutPressureBoxArray[unitNumber]->Text,
            readoutTemperatureBoxArray[unitNumber]->Text);
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_UpdateReadout()
//----------------------------------------------------------------------------
// QCOM_ValidateSamplingIntervalValue
//
// Validates the sampling timer interval text box
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateSamplingIntervalValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    bool            revertToOriginalValue = GUI_NO;
    DWORD           newInterval;
    String          ^functionName = _T("QCOM_ValidateSamplingIntervalValue");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING))
    {
        if (StringSet(readoutSamplingIntervalBox->Text))
        {
            bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
                readoutSamplingIntervalBox->Text,
                &newInterval);
            if (isCorrectFormat)
            {
                if ((newInterval < QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET]) ||
                    (newInterval > QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MAXIMUM_OFFSET]))
                {
                    QCOM_PromptOKModal(
                        "Invalid Sampling Interval Value",
                        "Valid values are {0:D} through {1:D}, inclusive",
                        QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET],
                        QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MAXIMUM_OFFSET]);
                    RecordErrorEvent(
                        "    Attempted setting sampling interval value to '{0:D}'",
                        newInterval);
                    revertToOriginalValue = GUI_YES;
                }
                else
                {
                    if (newInterval != QCOM_CurrentSamplingInterval)
                    {
                        RecordBasicEvent(
                            "    The Sampling Interval changed from {0:D} to {1:D} {2}",
                            QCOM_CurrentSamplingInterval,
                            newInterval,
                            QCOM_IntervalUnitsStringArray[QCOM_CurrentIntervalUnitsOffset]);
                        QCOM_CurrentSamplingInterval = newInterval;
                        samplingTimer->Interval = QCOM_MapDisplayIntervalToActual(newInterval);
                        QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_RECENT_OFFSET] = newInterval;
                        readoutSamplingIntervalBox->Text = String::Concat(QCOM_CurrentSamplingInterval);
                        logAllIntervalBox->Text = readoutSamplingIntervalBox->Text;
                        for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
                        {
                            graphingTimeBetweenSamplesLabelArray[unitNumber]->Text = String::Concat(
                                _T("Time Between Samples:  "),
                                newInterval,
                                QCOM_STRING_SPACE,
                                QCOM_IntervalUnitsStringArray[QCOM_CurrentIntervalUnitsOffset]);
                        }
                    }
                    evt->Cancel = GUI_NO;
                    RecordBasicEvent("{0} concluded: Accept {1:D}",
                        functionName, QCOM_CurrentSamplingInterval);
                    return;
                }
            }                           // end of if (isCorrectFormat)
            else
            {
                QCOM_PromptOKModal(
                    "Invalid Characters",
                    "The entry contains invalid characters;\n"
                    "enter only decimal digits");
                RecordErrorEvent(
                    "    Attempted setting sampling interval value to '{0}'",
                    readoutSamplingIntervalBox->Text);
                revertToOriginalValue = GUI_YES;
            }
        }                               // end of if (StringSet(readoutSamplingIntervalBox->Text))
        else
        {
            revertToOriginalValue = GUI_YES;
        }
        if (revertToOriginalValue)
        {
            readoutSamplingIntervalBox->Text = String::Concat(QCOM_CurrentSamplingInterval);
            logAllIntervalBox->Text = readoutSamplingIntervalBox->Text;
        }
    }                                   // end of if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING))
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_ValidateSamplingIntervalValue()
//----------------------------------------------------------------------------
// QCOM_ValidateSamplingLimitValue
//
// Validates the sampling limit minutes text box
//
// Called by:   QCOM_ConstructGeneralReadoutGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateSamplingLimitValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    bool            revertToOriginalValue = GUI_NO;
    DWORD           newLimit;
    String          ^functionName = _T("QCOM_ValidateSamplingLimitValue");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(readoutLimitSamplingTimeBox->Text))
    {
        bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
            readoutLimitSamplingTimeBox->Text,
            &newLimit);
        if (isCorrectFormat)
        {
            if ((newLimit < GUI_MINIMUM_SAMPLING_RUN_TIME_MINUTES) ||
                (newLimit > GUI_MAXIMUM_SAMPLING_RUN_TIME_MINUTES))
            {
                QCOM_PromptOKModal(
                    "Invalid Time Limit Value",
                    "Valid values are {0:D} through {1:D} minutes, inclusive",
                    GUI_MINIMUM_SAMPLING_RUN_TIME_MINUTES, GUI_MAXIMUM_SAMPLING_RUN_TIME_MINUTES);
                RecordErrorEvent(
                    "    Attempted setting sampling limit value to '{0:D}'",
                    newLimit);
                revertToOriginalValue = GUI_YES;
            }
            else
            {
                if (newLimit != QCOM_MaximumSamplingRunTimeMinutes)
                {
                    RecordBasicEvent(
                        "    The Sampling Limit changed from {0:D} to {1:D} min",
                        QCOM_MaximumSamplingRunTimeMinutes,
                        newLimit);
                    QCOM_MaximumSamplingRunTimeMinutes = newLimit;
                    readoutLimitSamplingTimeBox->Text = String::Concat(QCOM_MaximumSamplingRunTimeMinutes);
                    logAllLimitLoggingTimeBox->Text = readoutLimitSamplingTimeBox->Text;
                }
                evt->Cancel = GUI_NO;
                RecordBasicEvent("{0} concluded: Accept {1:D}",
                    functionName, QCOM_MaximumSamplingRunTimeMinutes);
                return;
            }
        }                               // end of if (isCorrectFormat)
        else
        {
            QCOM_PromptOKModal(
                "Invalid Characters",
                "The entry contains invalid characters;\n"
                "enter only decimal digits");
            RecordErrorEvent(
                "    Attempted setting sampling limit value to '{0}'",
                readoutLimitSamplingTimeBox->Text);
            revertToOriginalValue = GUI_YES;
        }
    }                                   // end of if (StringSet(readoutLimitSamplingTimeBox->Text))
    else
    {
        revertToOriginalValue = GUI_YES;
    }
    if (revertToOriginalValue)
    {
        readoutLimitSamplingTimeBox->Text = String::Concat(QCOM_MaximumSamplingRunTimeMinutes);
    }
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_ValidateSamplingLimitValue()
//----------------------------------------------------------------------------
#endif      // SAMPLING_CPP
//============================================================================
// End of Sampling.cpp
//============================================================================
