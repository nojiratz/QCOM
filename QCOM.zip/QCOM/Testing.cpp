//============================================================================
// Testing.cpp
//
// The regular and event methods used by GUI.cpp for unit testing
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     TESTING_CPP
#define     TESTING_CPP
#include    "Testing.h"
//----------------------------------------------------------------------------
// QCOM_AppendTestResults
//
// Appends a line to the test results log of the specified unit, using
// variable arguments
//
// Note:    Because this function uses the String::Format method to format the
//          arguments into a single managed string, the calling convention
//          should look similar to
//
//          char    *unmanagedString = "Testing";
//          DWORD   status = QCOM_SUCCESS;
//          . . .
//          QCOM_AppendTestResults(
//              unit,
//              (GUI_LOG_ACTION_APPEND_NEWLINE |
//              GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY),
//              "The function returned {0:X8} for XD {1}",
//              status,
//              gcnew String(unmanagedString));
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_AppendTestResults(
    UnitInfo        ^unit,
    DWORD           actionFlags,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit) && StringSet(formatString))
    {
        unit->testResultsLine = String::Format(formatString, parameters);
        QCOM_TestUnitUpdateResultsLog(unit, actionFlags);
    }
}                                       // end of QCOM_AppendTestResults()
//----------------------------------------------------------------------------
// QCOM_AppendTestResultsError
//
// Shortcut method that appends a string that interprets the specified error
// code to the test log of the specified unit, as a follow-up to a previous
// log entry that titles or describes the function that returned the error code
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_AppendTestResultsError(
    UnitInfo        ^unit,
    String          ^prefix,
    DWORD           errorCode,
    DWORD           actionFlags)
{
    char            errorDescription[QD_MAXIMUM_ERROR_STRING_SIZE];             // 256
    String          ^functionName = _T("QCOM_AppendTestResultsError");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        QCOM_AppendTestResults(
            unit,
            actionFlags | GUI_LOG_ACTION_FAILURE_TEXT,
            "{0}{1}failed with status 0x{2:X8} ({3})",
            (prefix ? prefix : String::Empty),
            (prefix ? QCOM_STRING_SPACE : String::Empty),
            errorCode,
            gcnew String(QD_InterpretErrorCode(errorCode, errorDescription)));
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_AppendTestResultsError()
//----------------------------------------------------------------------------
// QCOM_ApplyGeneralTestFlagToUnitFlags
//
// Applies the specified general flag to all corresponding unit flags, or
// sets the general flag only if all corresponding unit flags are set
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ApplyGeneralTestFlagToUnitFlags(
    DWORD           generalTestFlag,
    DWORD           unitTestFlag)
{
    bool            allUnitFlagsAreSet = GUI_YES;
    bool            atLeastOneUnitIsValid = GUI_NO;
    //------------------------------------------------------------------------
    if (generalTestFlag && unitTestFlag)
    {
        if (QCOM_GeneralInfo->testFlags & generalTestFlag)
        {
            for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
            {
                if (QCOM_UnitNumberValid(unitNumber))
                {
                    QCOM_UnitInfoArray[unitNumber]->testFlags |= unitTestFlag;
                }
            }
        }
        else
        {
            for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
            {
                if (QCOM_UnitNumberValid(unitNumber))
                {
                    atLeastOneUnitIsValid = GUI_YES;
                    if (!(QCOM_UnitInfoArray[unitNumber]->testFlags & unitTestFlag))
                        allUnitFlagsAreSet = GUI_NO;
                }
            }
            if (atLeastOneUnitIsValid && allUnitFlagsAreSet)
                QCOM_GeneralInfo->testFlags |= generalTestFlag;
        }
    }
}                                       // end of QCOM_ApplyGeneralTestFlagToUnitFlags()
//----------------------------------------------------------------------------
// QCOM_ClearTestResults
//
// Resets the test results of the specified unit
//
// Called by:   QCOM_TestAllClearResultsButtonClicked
//              QCOM_TestUnitClearResultsButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ClearTestResults(
    UnitInfo        ^unit)
{
    bool            proceedToClearResults = GUI_YES;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_ClearTestResults");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
        {
            if (unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING)
            {
                proceedToClearResults = QCOM_QueryStopTesting(
                    "Module {0} is currently running tests",
                    unit->moduleSerialNumber);
            }
            if (proceedToClearResults && QCOM_TestResultsPresent(unit))
            {
                QCOM_QuerySaveTestResultsFile(unit);
            }
        }
        if (proceedToClearResults)
        {
            if (unit->testFlags & QCOM_UNIT_TEST_LOOPING_ENABLED)
            {
                testingPassCountLabelArray[unitNumber]->Tag = (0x100 | unitNumber);
                if (unit->testFlags & QCOM_UNIT_TEST_LOOP_FOREVER)
                {
                    testingPassCountLabelArray[unitNumber]->Text = _T("Loop 1");
                }
                else
                {
                    testingPassCountLabelArray[unitNumber]->Text = String::Format(
                        "Loop 1 / {0:D}", QCOM_TestLoopCount);
                }
            }
            //----------------------------------------------------------------
            // Erase the test results
            //----------------------------------------------------------------
            QCOM_TestUnitUpdateResultsLog(
                unit,
                (GUI_LOG_ACTION_CLEAR_LOG |
                GUI_LOG_ACTION_CLEAR_DISPLAY |
                GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY));
            //----------------------------------------------------------------
            // Reset the color of the test check boxes, which represent the
            // results of the most recently run tests
            //----------------------------------------------------------------
            testingAllModuleCheckArray[unitNumber]->ForeColor = Color::Black;
            testingAllTransducerCheckArray[unitNumber]->ForeColor = Color::Black;
            testingQMEMCheckArray[unitNumber]->ForeColor = Color::Black;
            testingI2CCheckArray[unitNumber]->ForeColor = Color::Black;
            testingReadingsCheckArray[unitNumber]->ForeColor = Color::Black;
            testingFirmwareCheckArray[unitNumber]->ForeColor = Color::Black;
            testingX2CheckArray[unitNumber]->ForeColor = Color::Black;
            testingX3CheckArray[unitNumber]->ForeColor = Color::Black;
            testingX4CheckArray[unitNumber]->ForeColor = Color::Black;
            testingXDCommCheckArray[unitNumber]->ForeColor = Color::Black;
            testingXDIntegrityCheckArray[unitNumber]->ForeColor = Color::Black;
            testingXDMemoryCheckArray[unitNumber]->ForeColor = Color::Black;
            //----------------------------------------------------------------
            // Adjust the appearances of items to reflect a cleared test log
            //----------------------------------------------------------------
            testingStateLabelArray[unitNumber]->Text = GUI_TEST_UNTESTED_STRING;
            testingStateLabelArray[unitNumber]->ForeColor = Color::Green;
            testingPercentCompleteLabelArray[unitNumber]->Text = _T("0% Complete");
            testingPercentCompleteProgressArray[unitNumber]->Value = 0;
            //----------------------------------------------------------------
            // If this unit is testing, re-stamp the new log
            //----------------------------------------------------------------
            if (unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING)
            {
                QCOM_StampTestResultsLogBeginLoop(unit, 0, 0);
            }
        }
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_ClearTestResults()
//----------------------------------------------------------------------------
// QCOM_ContinueTestingWithErrors
//
// Stops the tests for the specified unit upon encountering an error if the
// Stop On Errors flag is set
//
// Returns: GUI_YES :   Continue testing
//          GUI_NO  :   Stop testing
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_ContinueTestingWithErrors(
    UnitInfo        ^unit)
{
    bool            keepTesting = GUI_YES;
    String          ^functionName = _T("QCOM_ContinueTestingWithErrors");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        if (unit->testFlags & QCOM_UNIT_TEST_STOP_ON_ERRORS)
        {
            if (unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING)
                unit->testFlags &= ~QCOM_UNIT_TEST_CURRENTLY_TESTING;
        }
        QCOM_CheckActiveTesting(unit, keepTesting);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
    return keepTesting;
}                                       // end of QCOM_ContinueTestingWithErrors()
//----------------------------------------------------------------------------
// QCOM_DetermineTestsViability
//
// Determines whether the tests that have been selected to run should run, and
// even whether any of the tests should run at all, and sets their flags
// accordingly
//
// Called by:   QCOM_TestUnitStartStopTests
//
// Note:    This is run prior to the start of the Initiate thread because some
//          of the checks might require user intervention for choices such as
//          file selection
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DetermineTestsViability(
    UnitInfo        ^unit)
{
    bool            currentlySampling;
    bool            proceedToSelectTestFile = GUI_NO;
    bool            proceedWithTest = GUI_YES;
    bool            userInterventionOK = GUI_YES;
    DWORD           unitNumber;
    String          ^promptString;
    String          ^functionName = _T("QCOM_DetermineTestsViability");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        unit->testsToComplete = 0;
        //--------------------------------------------------------------------
        // Memory Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_QMEM_TEST)
        {
            //----------------------------------------------------------------
            // The Memory Test must not run while the transducer is being
            // sampled, so ensure sampling is stopped before proceeding
            //----------------------------------------------------------------
            currentlySampling = QCOM_QueryStopSampling(
                "The Memory Test for module {0} could not be run during transducer sampling.",
                unit->moduleSerialNumber);
            if (!currentlySampling)
            {
                //------------------------------------------------------------
                // Transducer sampling is stopped, so now ensure the test
                // data file has been specified and the file actually exists
                //------------------------------------------------------------
                if (unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED)
                {
                    if (!File::Exists(unit->testDataFilePath))
                    {
                        GUI_DisplaySimpleError(functionName,
                            "The module {0} test data file\n{1}\ncould not be found",
                            unit->moduleSerialNumber,
                            unit->testDataFilePath);
                        unit->testFlags &= ~QCOM_UNIT_TEST_DATA_FILE_SPECIFIED;
                    }
                }
                if (!(unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED))
                {
                    promptString = String::Format(
                        "The Memory Test for module {0} is selected without a test data file.\n"
                        "The test will be skipped without the file. Select one now?",
                        unit->moduleSerialNumber);
                    proceedToSelectTestFile = QCOM_PromptModal(
                        "Test Data File Missing",
                        promptString);
                    if (proceedToSelectTestFile)
                    {
                        QCOM_SelectTestDataFile(unit);
                    }
                }
            }                           // end of if (!currentlySampling)
            //----------------------------------------------------------------
            // After all that, if the criteria aren't met, bail
            //----------------------------------------------------------------
            if (proceedWithTest &&
                (unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED) &&
                !currentlySampling)
            {
                unit->testsToComplete += GUI_MAXIMUM_NUMBER_OF_QMEM_TESTS;
            }
            else
            {
                unit->testFlags &= ~QCOM_UNIT_TEST_QMEM_TEST;
//                QCOM_TestUnitUpdateChecks(unit);
            }
        }
        //--------------------------------------------------------------------
        // I�C Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_I2C_TEST)
        {
            //----------------------------------------------------------------
            // The Memory Test must not run while the transducer is being
            // sampled, so ensure sampling is stopped before proceeding
            //----------------------------------------------------------------
            currentlySampling = QCOM_QueryStopSampling(
                "The I�C Test for module {0} could not be run during transducer sampling.",
                unit->moduleSerialNumber);
            if (!currentlySampling)
            {
                if (proceedWithTest)
                {
                    unit->testsToComplete += GUI_NUMBER_OF_I2C_TESTS;
                }
                else
                {
                    unit->testFlags &= ~QCOM_UNIT_TEST_I2C_TEST;
//                    QCOM_TestUnitUpdateChecks(unit);
                }
            }                           // end of if (!currentlySampling)
        }
        //--------------------------------------------------------------------
        // Readings Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_READINGS_TEST)
        {
            //----------------------------------------------------------------
            // The Readings Test must not run while the transducer is being
            // sampled, so ensure sampling is stopped before proceeding
            //----------------------------------------------------------------
            currentlySampling = QCOM_QueryStopSampling(
                "The Readings Test for module {0} could not be run during transducer sampling.",
                unit->moduleSerialNumber);
            if (!currentlySampling)
            {
                //------------------------------------------------------------
                // Transducer sampling is stopped, so now make the tester
                // aware that the Readings Test requires user intervention
                //------------------------------------------------------------
                if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
                {
                    userInterventionOK = QCOM_PromptModal(
                        "Test Equipment Reminder",
                        "The Readings Test requires user intervention.\n"
                        "Run the test for module {0} anyway?",
                        unit->moduleSerialNumber);
                    if (userInterventionOK)
                    {
                        proceedWithTest = QCOM_PromptOKModal(
                            "For Your Information",
                            "The Readings Test requires you to have the test\n"
                            "resistor plugs in your possession.\n"
                            "Click OK when you are ready to being testing.");
                    }
                }
            }                       // end of if (!currentlySampling)
            //----------------------------------------------------------------
            // After all that, if the criteria aren't met, bail
            //----------------------------------------------------------------
            if (proceedWithTest && userInterventionOK && !currentlySampling)
            {
                unit->testsToComplete += GUI_NUMBER_OF_READINGS_TESTS;
            }
            else
            {
                userInterventionOK = GUI_YES;
                unit->testFlags &= ~QCOM_UNIT_TEST_READINGS_TEST;
//                QCOM_TestUnitUpdateChecks(unit);
            }
        }
        //--------------------------------------------------------------------
        // Firmware Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_FIRMWARE_TEST)
        {
            //----------------------------------------------------------------
            // The Firmware Test must not run while the transducers are being
            // sampled, so ensure sampling is stopped before proceeding
            //----------------------------------------------------------------
            currentlySampling = QCOM_QueryStopSampling(
                "The Firmware Test for module {0} could not be run during transducer sampling.",
                unit->moduleSerialNumber);
            if (!currentlySampling)
            {
                //------------------------------------------------------------
                // Transducer sampling is stopped, so now verify the
                // presence of the firmware file
                //------------------------------------------------------------
                if (unit->testFlags & QCOM_UNIT_TEST_FW_FILE_SPECIFIED)
                {
                    if (!File::Exists(unit->testFirmwareFilePath))
                    {
                        GUI_DisplaySimpleError(functionName,
                            "The module {0} firmware file\n{1}\ncould not be found",
                            unit->moduleSerialNumber,
                            unit->testFirmwareFilePath);
                        unit->testFlags &= ~QCOM_UNIT_TEST_FW_FILE_SPECIFIED;
                    }
                }
                if (!(unit->testFlags & QCOM_UNIT_TEST_FW_FILE_SPECIFIED))
                {
                    proceedToSelectTestFile = QCOM_PromptModal(
                        "Firmware File Missing",
                        "The Firmware Test for module {0} is selected without a firmware file,\n"
                        "and will be skipped without the file. Select one now?",
                        unit->moduleSerialNumber);
                    if (proceedToSelectTestFile)
                    {
                        QCOM_SelectTestFirmwareFile(unit);
                    }
                }
            }                       // end of if (!currentlySampling)
            //----------------------------------------------------------------
            // After all that, if the criteria aren't met, bail
            //----------------------------------------------------------------
            if (proceedWithTest &&
                (unit->testFlags & QCOM_UNIT_TEST_FW_FILE_SPECIFIED) &&
                !currentlySampling)
            {
                unit->testsToComplete += GUI_NUMBER_OF_FIRMWARE_TESTS;
            }
            else
            {
                unit->testFlags &= ~QCOM_UNIT_TEST_FIRMWARE_TEST;
//                QCOM_TestUnitUpdateChecks(unit);
            }
        }
        //--------------------------------------------------------------------
        // X2 Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_X2_TEST)
        {
            if (proceedWithTest)
            {
                unit->testsToComplete += GUI_NUMBER_OF_X2_TESTS;
            }
            else
            {
                unit->testFlags &= ~QCOM_UNIT_TEST_X2_TEST;
//                QCOM_TestUnitUpdateChecks(unit);
            }
        }
        //--------------------------------------------------------------------
        // X3 Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_X3_TEST)
        {
            if (proceedWithTest)
            {
                unit->testsToComplete += GUI_NUMBER_OF_X3_TESTS;
            }
            else
            {
                unit->testFlags &= ~QCOM_UNIT_TEST_X3_TEST;
//                QCOM_TestUnitUpdateChecks(unit);
            }
        }
        //--------------------------------------------------------------------
        // X4 Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_X4_TEST)
        {
            if (proceedWithTest)
            {
                unit->testsToComplete += GUI_NUMBER_OF_X4_TESTS;
            }
            else
            {
                unit->testFlags &= ~QCOM_UNIT_TEST_X4_TEST;
//                QCOM_TestUnitUpdateChecks(unit);
            }
        }
        //--------------------------------------------------------------------
        // Transducer Communication Test
        //--------------------------------------------------------------------
        if ((unit->testFlags & QCOM_UNIT_TEST_XD_COMM_TEST) &&
            testingAllTransducerCheckArray[unitNumber]->Visible)
        {
            //----------------------------------------------------------------
            // The Transducer Communication Test must not run while the
            // transducers are being sampled, so ensure sampling is stopped
            // before proceeding
            //----------------------------------------------------------------
            currentlySampling = QCOM_QueryStopSampling(
                "The Transducer Communication Test for module {0} could\n"
                "not be run during transducer sampling.",
                unit->moduleSerialNumber);
            if (!currentlySampling)
            {
                if (proceedWithTest)
                {
                    unit->testsToComplete += GUI_NUMBER_OF_XD_COMM_TESTS;
                }
                else
                {
                    unit->testFlags &= ~QCOM_UNIT_TEST_XD_COMM_TEST;
//                    QCOM_TestUnitUpdateChecks(unit);
                }
            }                           // end of if (!currentlySampling)
        }
        //--------------------------------------------------------------------
        // Transducer Integrity Test
        //--------------------------------------------------------------------
        if ((unit->testFlags & QCOM_UNIT_TEST_XD_INTEGRITY_TEST) &&
            testingAllTransducerCheckArray[unitNumber]->Visible)
        {
            if (proceedWithTest)
            {
                unit->testsToComplete += GUI_NUMBER_OF_XD_INTEGRITY_TESTS;
            }
            else
            {
                unit->testFlags &= ~QCOM_UNIT_TEST_XD_INTEGRITY_TEST;
//                QCOM_TestUnitUpdateChecks(unit);
            }
        }
        //--------------------------------------------------------------------
        // Transducer EEPROM (ASIC / FPGA) Memory Test
        //--------------------------------------------------------------------
        if ((unit->testFlags & QCOM_UNIT_TEST_XD_MEMORY_TEST) &&
            testingAllTransducerCheckArray[unitNumber]->Visible)
        {
            if (proceedWithTest)
            {
                unit->testsToComplete += GUI_MAXIMUM_NUMBER_OF_XD_MEMORY_TESTS;
            }
            else
            {
                unit->testFlags &= ~QCOM_UNIT_TEST_XD_MEMORY_TEST;
//                QCOM_TestUnitUpdateChecks(unit);
            }
        }
        if (!(unit->testFlags & QCOM_UNIT_TEST_ALL))
            unit->testFlags &= ~QCOM_UNIT_TEST_CURRENTLY_TESTING;
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_DetermineTestsViability()
//----------------------------------------------------------------------------
// QCOM_InitiateUnitTests
//
// Starts the selected tests for the specified unit
//
// Note:    This method is spawned from QCOM_TestUnitStartStopTests
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InitiateUnitTests(
    Object          ^moduleNumber)
{
    bool            allTransducerTestsPassed = GUI_YES;
    bool            allTransducerTestsRun = GUI_NO;
    bool            allUnitTestsPassed = GUI_YES;
    bool            allUnitTestsRun = GUI_NO;
    bool            keepTesting = GUI_YES;
    bool            someUnitTestsPassed = GUI_NO;
    bool            someTransducerTestsPassed = GUI_NO;
    bool            testPassed;
    DWORD           actionFlags = 0;
    DWORD           loopNumber = 0;
    DWORD           loopsRemaining = GUI_DEFAULT_TEST_LOOP_COUNT;               // 1
    DWORD           unitNumber = (DWORD) (dynamic_cast <Object ^> (moduleNumber));
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_InitiateUnitTests");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_PreTest(unit);
        if ((unit->testFlags & QCOM_UNIT_TEST_LOOPING_ENABLED) && QCOM_TestLoopCount)
            loopsRemaining = QCOM_TestLoopCount;
        while (loopsRemaining && keepTesting)
        {
            unit->testsCompleted = 0;
            loopNumber++;
            if (unit->testFlags & QCOM_UNIT_TEST_LOOPING_ENABLED)
            {
                testingPassCountLabelArray[unitNumber]->Tag = ((loopNumber << 8) | unitNumber);
                if (unit->testFlags & QCOM_UNIT_TEST_LOOP_FOREVER)
                {
                    testingPassCountLabelArray[unitNumber]->Text = String::Format(
                        "Loop {0:D}", loopNumber);
                }
                else
                {
                    testingPassCountLabelArray[unitNumber]->Text = String::Format(
                        "Loop {0:D} / {1:D}",
                        loopNumber,
                        QCOM_TestLoopCount);
                    loopsRemaining--;
                }
            }
            else
                loopsRemaining--;
            if ((unit->testFlags & QCOM_UNIT_TEST_ALL_MODULE) == QCOM_UNIT_TEST_ALL_MODULE)
                allUnitTestsRun = GUI_YES;
            if ((unit->testFlags & QCOM_UNIT_TEST_ALL_TRANSDUCER) == QCOM_UNIT_TEST_ALL_TRANSDUCER)
                allTransducerTestsRun = GUI_YES;
            //----------------------------------------------------------------
            // Clear the log and display unless the Append flag is set
            //----------------------------------------------------------------
            if ((loopNumber > 1) && !(QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_APPEND))
                QCOM_TestUnitUpdateResultsLog(
                    unit,
                    (GUI_LOG_ACTION_CLEAR_LOG |
                    GUI_LOG_ACTION_CLEAR_DISPLAY |
                    GUI_LOG_ACTION_RETAIN_LOG_HEADER |
                    GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY));
            QCOM_StampTestResultsLogBeginLoop(unit, loopNumber, QCOM_TestLoopCount);
            //----------------------------------------------------------------
            // Reset the text color of only the tests selected to run
            //----------------------------------------------------------------
            testingAllModuleCheckArray[unitNumber]->ForeColor = Color::Black;
            testingAllTransducerCheckArray[unitNumber]->ForeColor = Color::Black;
            if (unit->testFlags & QCOM_UNIT_TEST_QMEM_TEST)
                testingQMEMCheckArray[unitNumber]->ForeColor = Color::Black;
            if (unit->testFlags & QCOM_UNIT_TEST_I2C_TEST)
                testingI2CCheckArray[unitNumber]->ForeColor = Color::Black;
            if (unit->testFlags & QCOM_UNIT_TEST_READINGS_TEST)
                testingReadingsCheckArray[unitNumber]->ForeColor = Color::Black;
            if (unit->testFlags & QCOM_UNIT_TEST_FIRMWARE_TEST)
                testingFirmwareCheckArray[unitNumber]->ForeColor = Color::Black;
            if (unit->testFlags & QCOM_UNIT_TEST_X2_TEST)
                testingX2CheckArray[unitNumber]->ForeColor = Color::Black;
            if (unit->testFlags & QCOM_UNIT_TEST_X3_TEST)
                testingX3CheckArray[unitNumber]->ForeColor = Color::Black;
            if (unit->testFlags & QCOM_UNIT_TEST_X4_TEST)
                testingX4CheckArray[unitNumber]->ForeColor = Color::Black;
            if (unit->testFlags & QCOM_UNIT_TEST_XD_COMM_TEST)
                testingXDCommCheckArray[unitNumber]->ForeColor = Color::Black;
            if (unit->testFlags & QCOM_UNIT_TEST_XD_INTEGRITY_TEST)
                testingXDIntegrityCheckArray[unitNumber]->ForeColor = Color::Black;
            if (unit->testFlags & QCOM_UNIT_TEST_XD_MEMORY_TEST)
                testingXDMemoryCheckArray[unitNumber]->ForeColor = Color::Black;
            //----------------------------------------------------------------
            // Reset the test state and progress bar
            //----------------------------------------------------------------
            testingStateLabelArray[unitNumber]->Text = GUI_TEST_RUNNING_STRING;
            testingStateLabelArray[unitNumber]->ForeColor = Color::Purple;
            testingStateLabelArray[unitNumber]->Update();
            testingPercentCompleteLabelArray[unitNumber]->Text = _T("0% Complete");
            testingPercentCompleteLabelArray[unitNumber]->Update();
            testingPercentCompleteProgressArray[unitNumber]->Value = 0;
            testingPercentCompleteProgressArray[unitNumber]->Update();
            if (!(unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                keepTesting = GUI_NO;
            if (unit->testFlags & QCOM_UNIT_TEST_ALL_MODULE)
////            if (unit->testFlags & 0x8000)
            {
                //------------------------------------------------------------
                // Memory Test
                //------------------------------------------------------------
                if ((unit->testFlags & QCOM_UNIT_TEST_QMEM_TEST) && keepTesting)
                {
                    testingQMEMCheckArray[unitNumber]->BackColor = Color::LawnGreen;
                    testPassed = QCOM_TestSuiteQMEM(unit);
                    if (testPassed)
                    {
                        someUnitTestsPassed = GUI_YES;
                        testingQMEMCheckArray[unitNumber]->ForeColor = Color::Blue;
                    }
                    else
                    {
                        allUnitTestsPassed = GUI_NO;
                        testingQMEMCheckArray[unitNumber]->ForeColor = Color::Red;
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    testingQMEMCheckArray[unitNumber]->BackColor = Color::Transparent;
                }
                else
                    allUnitTestsRun = GUI_NO;
                if (!(unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                    keepTesting = GUI_NO;
                //------------------------------------------------------------
                // I�C Test
                //------------------------------------------------------------
                if ((unit->testFlags & QCOM_UNIT_TEST_I2C_TEST) && keepTesting)
                {
                    testingI2CCheckArray[unitNumber]->BackColor = Color::LawnGreen;
                    testPassed = QCOM_TestSuiteI2C(unit);
                    if (testPassed)
                    {
                        someUnitTestsPassed = GUI_YES;
                        testingI2CCheckArray[unitNumber]->ForeColor = Color::Blue;
                    }
                    else
                    {
                        allUnitTestsPassed = GUI_NO;
                        testingI2CCheckArray[unitNumber]->ForeColor = Color::Red;
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    testingI2CCheckArray[unitNumber]->BackColor = Color::Transparent;
                }
                else
                    allUnitTestsRun = GUI_NO;
                if (!(unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                    keepTesting = GUI_NO;
                //------------------------------------------------------------
                // Readings Test
                //------------------------------------------------------------
                if ((unit->testFlags & QCOM_UNIT_TEST_READINGS_TEST) && keepTesting)
                {
                    testingReadingsCheckArray[unitNumber]->BackColor = Color::LawnGreen;
                    testPassed = QCOM_TestSuiteReadings(unit);
                    if (testPassed)
                    {
                        someUnitTestsPassed = GUI_YES;
                        testingReadingsCheckArray[unitNumber]->ForeColor = Color::Blue;
                    }
                    else
                    {
                        allUnitTestsPassed = GUI_NO;
                        testingReadingsCheckArray[unitNumber]->ForeColor = Color::Red;
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    testingReadingsCheckArray[unitNumber]->BackColor = Color::Transparent;
                }
                else
                    allUnitTestsRun = GUI_NO;
                if (!(unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                    keepTesting = GUI_NO;
                //------------------------------------------------------------
                // Firmware Test
                //------------------------------------------------------------
                if ((unit->testFlags & QCOM_UNIT_TEST_FIRMWARE_TEST) && keepTesting)
                {
                    testingFirmwareCheckArray[unitNumber]->BackColor = Color::LawnGreen;
//                    while (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_FIRMWARE_TEST_RUNNING)
//                        Thread::Sleep(10);
//                    QCOM_GeneralInfo->testFlags |= QCOM_GENERAL_TEST_FIRMWARE_TEST_RUNNING;
                    testPassed = QCOM_TestSuiteFirmware(unit);
//                    QCOM_GeneralInfo->testFlags &= ~QCOM_GENERAL_TEST_FIRMWARE_TEST_RUNNING;
                    if (testPassed)
                    {
                        someUnitTestsPassed = GUI_YES;
                        testingFirmwareCheckArray[unitNumber]->ForeColor = Color::Blue;
                    }
                    else
                    {
                        allUnitTestsPassed = GUI_NO;
                        testingFirmwareCheckArray[unitNumber]->ForeColor = Color::Red;
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    testingFirmwareCheckArray[unitNumber]->BackColor = Color::Transparent;
                }
                else
                    allUnitTestsRun = GUI_NO;
                if (!(unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                    keepTesting = GUI_NO;
                //------------------------------------------------------------
                // X2 Test
                //------------------------------------------------------------
                if ((unit->testFlags & QCOM_UNIT_TEST_X2_TEST) && keepTesting)
                {
                    testingX2CheckArray[unitNumber]->BackColor = Color::LawnGreen;
                    testPassed = QCOM_TestSuiteX2(unit);
                    if (testPassed)
                    {
                        someUnitTestsPassed = GUI_YES;
                        testingX2CheckArray[unitNumber]->ForeColor = Color::Blue;
                    }
                    else
                    {
                        allUnitTestsPassed = GUI_NO;
                        testingX2CheckArray[unitNumber]->ForeColor = Color::Red;
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    testingX2CheckArray[unitNumber]->BackColor = Color::Transparent;
                }
                else
                    allUnitTestsRun = GUI_NO;
                if (!(unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                    keepTesting = GUI_NO;
                //------------------------------------------------------------
                // X3 Test
                //------------------------------------------------------------
                if ((unit->testFlags & QCOM_UNIT_TEST_X3_TEST) && keepTesting)
                {
                    testingX3CheckArray[unitNumber]->BackColor = Color::LawnGreen;
                    testPassed = QCOM_TestSuiteX3(unit);
                    if (testPassed)
                    {
                        someUnitTestsPassed = GUI_YES;
                        testingX3CheckArray[unitNumber]->ForeColor = Color::Blue;
                    }
                    else
                    {
                        allUnitTestsPassed = GUI_NO;
                        testingX3CheckArray[unitNumber]->ForeColor = Color::Red;
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    testingX3CheckArray[unitNumber]->BackColor = Color::Transparent;
                }
                else
                    allUnitTestsRun = GUI_NO;
                if (!(unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                    keepTesting = GUI_NO;
                //------------------------------------------------------------
                // X4 Test
                //------------------------------------------------------------
                if ((unit->testFlags & QCOM_UNIT_TEST_X4_TEST) && keepTesting)
                {
                    testingX4CheckArray[unitNumber]->BackColor = Color::LawnGreen;
                    testPassed = QCOM_TestSuiteX4(unit);
                    if (testPassed)
                    {
                        someUnitTestsPassed = GUI_YES;
                        testingX4CheckArray[unitNumber]->ForeColor = Color::Blue;
                    }
                    else
                    {
                        allUnitTestsPassed = GUI_NO;
                        testingX4CheckArray[unitNumber]->ForeColor = Color::Red;
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    testingX4CheckArray[unitNumber]->BackColor = Color::Transparent;
                }
                else
                    allUnitTestsRun = GUI_NO;
            }                           // end of if (unit->testFlags & QCOM_UNIT_TEST_ALL_MODULE)
            if (!(unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                keepTesting = GUI_NO;
            if ((unit->testFlags & QCOM_UNIT_TEST_ALL_TRANSDUCER) &&
                (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_DISPLAY_XD_TESTS))
            {
                //------------------------------------------------------------
                // Transducer Communication Test suite
                //------------------------------------------------------------
                if ((unit->testFlags & QCOM_UNIT_TEST_XD_COMM_TEST) &&
                    testingAllTransducerCheckArray[unitNumber]->Visible &&
                    keepTesting)
                {
                    testingXDCommCheckArray[unitNumber]->BackColor = Color::LawnGreen;
                    testPassed = QCOM_TestSuiteTransducerCommunication(unit);
                    if (testPassed)
                    {
                        someTransducerTestsPassed = GUI_YES;
                        testingXDCommCheckArray[unitNumber]->ForeColor = Color::Blue;
                    }
                    else
                    {
                        allTransducerTestsPassed = GUI_NO;
                        testingXDCommCheckArray[unitNumber]->ForeColor = Color::Red;
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    testingXDCommCheckArray[unitNumber]->BackColor = Color::Transparent;
                }
                else
                    allTransducerTestsRun = GUI_NO;
                if (!(unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                    keepTesting = GUI_NO;
                //------------------------------------------------------------
                // Transducer Integrity Test suite
                //------------------------------------------------------------
                if ((unit->testFlags & QCOM_UNIT_TEST_XD_INTEGRITY_TEST) &&
                    testingAllTransducerCheckArray[unitNumber]->Visible &&
                    keepTesting)
                {
                    testingXDIntegrityCheckArray[unitNumber]->BackColor = Color::LawnGreen;
                    testPassed = QCOM_TestSuiteTransducerIntegrity(unit);
                    if (testPassed)
                    {
                        someTransducerTestsPassed = GUI_YES;
                        testingXDIntegrityCheckArray[unitNumber]->ForeColor = Color::Blue;
                    }
                    else
                    {
                        allTransducerTestsPassed = GUI_NO;
                        testingXDIntegrityCheckArray[unitNumber]->ForeColor = Color::Red;
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    testingXDIntegrityCheckArray[unitNumber]->BackColor = Color::Transparent;
                }
                else
                    allTransducerTestsRun = GUI_NO;
                if (!(unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                    keepTesting = GUI_NO;
                //------------------------------------------------------------
                // Transducer EEPROM (ASIC / FPGA) Memory Test suite
                //------------------------------------------------------------
                if ((unit->testFlags & QCOM_UNIT_TEST_XD_MEMORY_TEST) &&
                    testingAllTransducerCheckArray[unitNumber]->Visible &&
                    keepTesting)
                {
                    testingXDMemoryCheckArray[unitNumber]->BackColor = Color::LawnGreen;
                    testPassed = QCOM_TestSuiteTransducerMemory(unit);
                    if (testPassed)
                    {
                        someTransducerTestsPassed = GUI_YES;
                        testingXDMemoryCheckArray[unitNumber]->ForeColor = Color::Blue;
                    }
                    else
                    {
                        allTransducerTestsPassed = GUI_NO;
                        testingXDMemoryCheckArray[unitNumber]->ForeColor = Color::Red;
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    testingXDMemoryCheckArray[unitNumber]->BackColor = Color::Transparent;
                }
                else
                    allTransducerTestsRun = GUI_NO;
            }                           // end of if ((unit->testFlags & QCOM_UNIT_TEST_ALL_TRANSDUCER) && ...))
            //----------------------------------------------------------------
            // The tests are finished, so post the results
            //----------------------------------------------------------------
            Thread::Sleep(0);
            if (!(unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                keepTesting = GUI_NO;
            if (unit->testFlags & QCOM_UNIT_TEST_LOOPING_ENABLED)
            {
                unit->testResultsLine = String::Format(
                    "Test Loop {0:D} Final Result: ",
                    loopNumber);
            }
            else
            {
                unit->testResultsLine = _T("Tests Final Result: ");
            }
            QCOM_TestUnitUpdateResultsLog(
                unit,
                (GUI_LOG_ACTION_NO_ACTION |
                GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY));
            actionFlags =
                (GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY |
                GUI_LOG_ACTION_PREVENT_TIME_STAMP |
                GUI_LOG_ACTION_APPEND_NEWLINE);
            if (keepTesting)
            {
                if (allUnitTestsRun)
                {
                    if (allUnitTestsPassed && allTransducerTestsPassed)
                    {
                        testingStateLabelArray[unitNumber]->Text = GUI_TEST_PASSED_STRING;
                        testingStateLabelArray[unitNumber]->ForeColor = Color::Blue;
                        testingAllModuleCheckArray[unitNumber]->ForeColor = Color::Blue;
                        actionFlags |= GUI_LOG_ACTION_SUCCESS_TEXT;
                        unit->testResultsLine = GUI_TEST_PASSED_STRING;
                    }
                    else
                    {
                        testingStateLabelArray[unitNumber]->Text = GUI_TEST_FAILED_STRING;
                        testingStateLabelArray[unitNumber]->ForeColor = Color::Red;
                        testingAllModuleCheckArray[unitNumber]->ForeColor = Color::Black;
                        actionFlags |= GUI_LOG_ACTION_FAILURE_TEXT;
                        unit->testResultsLine = GUI_TEST_FAILED_STRING;
                    }
                }
                else
                {
                    if (allUnitTestsPassed && allTransducerTestsPassed)
                    {
                        testingStateLabelArray[unitNumber]->Text = GUI_TEST_INCOMPLETE_STRING;
                        testingStateLabelArray[unitNumber]->ForeColor = Color::OliveDrab;
                        actionFlags |= GUI_LOG_ACTION_BOLD_TEXT;
                        unit->testResultsLine = _T("Incomplete (all selected tests passed, but not all necessary tests were run)");
                    }
                    else
                    {
                        testingStateLabelArray[unitNumber]->Text = GUI_TEST_FAILED_STRING;
                        testingStateLabelArray[unitNumber]->ForeColor = Color::Red;
                        actionFlags |= GUI_LOG_ACTION_FAILURE_TEXT;
                        unit->testResultsLine = GUI_TEST_FAILED_STRING;
                    }
                }
            }
            else
            {
                if (allUnitTestsPassed && allTransducerTestsPassed)
                {
                    testingStateLabelArray[unitNumber]->Text = GUI_TEST_STOPPED_STRING;
                    testingStateLabelArray[unitNumber]->ForeColor = Color::OliveDrab;
                    actionFlags |= GUI_LOG_ACTION_CAUTION_TEXT;
                    unit->testResultsLine = _T("Stopped (user requested test termination)");
                }
                else
                {
                    testingStateLabelArray[unitNumber]->Text = GUI_TEST_FAILED_STRING;
                    testingStateLabelArray[unitNumber]->ForeColor = Color::Red;
                    actionFlags |= GUI_LOG_ACTION_FAILURE_TEXT;
                    unit->testResultsLine = GUI_TEST_FAILED_STRING;
                }
            }
            QCOM_TestUnitUpdateResultsLog(unit, actionFlags);
            QCOM_StampTestResultsLogEndLoop(
                unit,
                loopNumber,
                QCOM_TestLoopCount,
                ((loopsRemaining && keepTesting) ? GUI_NO : GUI_YES));
        }                               // end of while (loopsRemaining && keepTesting)
        QCOM_PostTest(unit);
    }                                   // end of if (QCOM_UnitNumberValid(unitNumber))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_InitiateUnitTests()
//----------------------------------------------------------------------------
// QCOM_MarkTestingTime
//
// Updates the running test time with the current elapsed time
//
// Called by:   QCOM_TestUnitUpdateResultsLog
//
// Note:    This method is spawned from QCOM_TestUnitUpdateResultsLog
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_MarkTestingTime(
    Object          ^moduleNumber)
{
    int             lapsedDays;
    int             lapsedHours;
    int             lapsedMinutes;
    int             lapsedSeconds;
    int             lapsedMilliseconds;
    DWORD           currentTime = GetTickCount();
    DWORD           unitNumber = (DWORD) (dynamic_cast <Object ^> (moduleNumber));
    TestingStatsInfo
                    ^testStats;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_MarkTestingTime");
    //------------------------------------------------------------------------
    if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED))
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            testStats = unit->testingStats;
            if (QCOM_ReadyToMarkTestingTime[unitNumber])
            {
                testStats->cumulative += (currentTime - testStats->startTime);
                testStats->startTime = currentTime;
                QCOM_TimeElapsed(
                    testStats->cumulative,
                    &lapsedDays,
                    &lapsedHours,
                    &lapsedMinutes,
                    &lapsedSeconds,
                    &lapsedMilliseconds);
                testingRunningTimeLabelArray[unitNumber]->Text = String::Format(
                    "{0:D} d {1:D} h {2:D} m {3:D} s",
                    lapsedDays,
                    lapsedHours,
                    lapsedMinutes,
                    lapsedSeconds);
                QCOM_ReadyToMarkTestingTime[unitNumber] = GUI_NO;
            }
            delete testStats;
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0} called with invalid unit number {1:D}",
                functionName, unitNumber);
        }
    }                                   // end of if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED))
}                                       // end of QCOM_MarkTestingTime()
//----------------------------------------------------------------------------
// QCOM_PostTest
//
// Performs the tasks required following a test suite run
//
// Called by:   QCOM_InitiateUnitTests
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PostTest(
    UnitInfo        ^unit)
{
    int             lapsedDays;
    int             lapsedHours;
    int             lapsedMinutes;
    int             lapsedSeconds;
    int             lapsedMilliseconds;
    DWORD           currentTime = GetTickCount();
    DWORD           unitNumber;
    TestingStatsInfo
                    ^testStats;
    String          ^functionName = _T("QCOM_PostTest");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        testStats = unit->testingStats;
        unit->testFlags &= ~QCOM_UNIT_TEST_CURRENTLY_TESTING;
        testingRunningTimeLabelArray[unitNumber]->Enabled = GUI_NO;
        testingStateLabelArray[unitNumber]->Update();
        testingPercentCompleteLabelArray[unitNumber]->Update();
        testingPercentCompleteProgressArray[unitNumber]->Update();
        if (QCOM_TestResultsDisplayed(unit))
        {
            if (QCOM_TestResultsDetailed(unit))
                testingDetailedResultsBoxArray[unitNumber]->Update();
            else
                testingSummaryResultsBoxArray[unitNumber]->Update();
            testingGroupBoxArray[unitNumber]->Update();
        }
        //--------------------------------------------------------------------
        // Re-enable the tests
        //--------------------------------------------------------------------
        testingAllModuleCheckArray[unitNumber]->Enabled = GUI_YES;
        testingQMEMCheckArray[unitNumber]->Enabled = GUI_YES;
        testingI2CCheckArray[unitNumber]->Enabled = GUI_YES;
        testingReadingsCheckArray[unitNumber]->Enabled = GUI_YES;
        testingFirmwareCheckArray[unitNumber]->Enabled = GUI_YES;
        testingX2CheckArray[unitNumber]->Enabled = GUI_YES;
        testingX3CheckArray[unitNumber]->Enabled = GUI_YES;
        testingX4CheckArray[unitNumber]->Enabled = GUI_YES;
        testingAllTransducerCheckArray[unitNumber]->Enabled = GUI_YES;
        testingXDCommCheckArray[unitNumber]->Enabled = GUI_YES;
        testingXDIntegrityCheckArray[unitNumber]->Enabled = GUI_YES;
        //--------------------------------------------------------------------
        // Re-enable relevant affected objects
        //--------------------------------------------------------------------
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
        //--------------------------------------------------------------------
        // Stamp the time elapsed
        //--------------------------------------------------------------------
        testStats->cumulative += (currentTime - testStats->startTime);
        testStats->startTime = currentTime;
        QCOM_TimeElapsed(
            testStats->cumulative,
            &lapsedDays,
            &lapsedHours,
            &lapsedMinutes,
            &lapsedSeconds,
            &lapsedMilliseconds);
        unit->testResultsLine = String::Format(
            "Total test time elapsed: {0:D} day{1} {2:D} hour{3} {4:D} minute{5} {6:D}.{7:D3} second{8}",
            lapsedDays, ((lapsedDays == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
            lapsedHours, ((lapsedHours == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
            lapsedMinutes, ((lapsedMinutes == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
            lapsedSeconds, lapsedMilliseconds,
            (((lapsedSeconds == 1) && (lapsedMilliseconds == 0)) ? QCOM_STRING_EMPTY : QCOM_STRING_S));
        QCOM_TestUnitUpdateResultsLog(
            unit,
            (GUI_LOG_ACTION_PREVENT_TIME_STAMP |
            GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY |
            GUI_LOG_ACTION_APPEND_NEWLINE));
        //--------------------------------------------------------------------
        // Mark the end of the tests
        //--------------------------------------------------------------------
        unit->testResultsLine = String::Concat(
            "End test log for QCOM Unit ",
            unit->moduleSerialNumber);
        QCOM_TestUnitUpdateResultsLog(
            unit,
            (GUI_LOG_ACTION_PREPEND_TIME_STAMP |
            GUI_LOG_ACTION_APPEND_NEWLINE |
            GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY));
        QCOM_HomeUpdateStatusLine("Tests have concluded");
        testingRunningTimeLabelArray[unitNumber]->Text = String::Empty;
        testingRunningTimeLabelArray[unitNumber]->Enabled = GUI_NO;
        if (unit->testFlags & QCOM_UNIT_TEST_RESULTS_AUTO_SAVE)
        {
            bool spinLockAcquired = GUI_NO;
            bool transferResult = GUI_CANCEL;
            try
            {
                QCOM_TestSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                transferResult = QCOM_TransferTestResultsToFile(unit);
            }
            finally
            {
                if (spinLockAcquired == GUI_YES)
                    QCOM_TestSpinLockArray[unitNumber]->Exit();
            }
            if (transferResult == GUI_ACCEPT)
            {
                RecordVerboseEvent(
                    "    Test results log for module {0} saved to file\n{1}",
                    unit->moduleSerialNumber,
                    unit->testResultsFilePath);
            }
            unit->dataLogFlags &= ~QCOM_UNIT_LOG_DATA_UNSAVED;
        }
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_PostTest()
//----------------------------------------------------------------------------
// QCOM_PreTest
//
// Performs the tasks required prior to a test suite run
//
// Called by:   QCOM_InitiateUnitTests
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PreTest(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_PreTest");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        QCOM_HomeUpdateStatusLine("Tests are running");
        unit->testsCompleted = 0;
        if (QCOM_TestResultsDisplayed(unit))
        {
            testingDetailedResultsBoxArray[unitNumber]->BackColor = Color::Aquamarine;
            testingSummaryResultsBoxArray[unitNumber]->BackColor = Color::Aquamarine;
            if (!(QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_APPEND))
                QCOM_TestUnitUpdateResultsLog(
                    unit,
                    (GUI_LOG_ACTION_CLEAR_LOG |
                    GUI_LOG_ACTION_CLEAR_DISPLAY |
                    GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY));
        }
        //--------------------------------------------------------------------
        // Prevent the tests from clicking mid-test
        //--------------------------------------------------------------------
        testingAllModuleCheckArray[unitNumber]->Enabled = GUI_NO;
        testingQMEMCheckArray[unitNumber]->Enabled = GUI_NO;
        testingI2CCheckArray[unitNumber]->Enabled = GUI_NO;
        testingReadingsCheckArray[unitNumber]->Enabled = GUI_NO;
        testingFirmwareCheckArray[unitNumber]->Enabled = GUI_NO;
        testingX2CheckArray[unitNumber]->Enabled = GUI_NO;
        testingX3CheckArray[unitNumber]->Enabled = GUI_NO;
        testingX4CheckArray[unitNumber]->Enabled = GUI_NO;
        testingAllTransducerCheckArray[unitNumber]->Enabled = GUI_NO;
        testingXDCommCheckArray[unitNumber]->Enabled = GUI_NO;
        testingXDIntegrityCheckArray[unitNumber]->Enabled = GUI_NO;
        testingXDMemoryCheckArray[unitNumber]->Enabled = GUI_NO;
        //--------------------------------------------------------------------
        // Disable relevant affected objects
        //--------------------------------------------------------------------
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
        //--------------------------------------------------------------------
        // Reset the running displays
        //--------------------------------------------------------------------
        if (QCOM_TestResultsDisplayed(unit))
        {
            if (QCOM_TestResultsDetailed(unit))
                testingDetailedResultsBoxArray[unitNumber]->Update();
            else
                testingSummaryResultsBoxArray[unitNumber]->Update();
            testingGroupBoxArray[unitNumber]->Update();
        }
//        testingStartStopButtonArray[unitNumber]->Text = GUI_STOP_ALL_UNIT_TESTS_STRING;
        testingStartStopButtonArray[unitNumber]->Update();
        testingRunningTimeLabelArray[unitNumber]->Enabled = GUI_YES;
        //--------------------------------------------------------------------
        // Start the clock running
        //--------------------------------------------------------------------
        QCOM_TestUnitInitializeStatistics(unit);
        //--------------------------------------------------------------------
        // Build the log header and stamp the log with it
        //--------------------------------------------------------------------
        DateTime dateTime = DateTime::Now;
        unit->testResultsLogHeader = String::Format(
            "{0:D2} {1} {2:D4} {3:D2}:{4:D2}:{5:D2} : ",
            dateTime.Day,
            QCOM_MonthStringArray[dateTime.Month],
            dateTime.Year,
            dateTime.Hour,
            dateTime.Minute,
            dateTime.Second);
        if (QCOM_XDSNValid(unit))
        {
            unit->testResultsLogHeader = String::Concat(
                unit->testResultsLogHeader,
                String::Format(
                    "Start test log for QCOM Module {0} with {1} transducer S/N {2}",
                    unit->moduleSerialNumber,
                    (QCOM_XDIsFrequency(unit) ? _T("frequency (analog)") : _T("digital")),
                    unit->transducerSerialNumber));
        }
        else
        {
            unit->testResultsLogHeader = String::Concat(
                unit->testResultsLogHeader,
                "Start test log for QCOM Unit ",
                unit->moduleSerialNumber);
        }
        if (unit->testFlags & QCOM_UNIT_TEST_ALL)
        {
            unit->testResultsLogHeader = String::Concat(
                unit->testResultsLogHeader,
                Environment::NewLine, _T("    The following tests are scheduled to run:"));
            if (unit->testFlags & QCOM_UNIT_TEST_QMEM_TEST)
                unit->testResultsLogHeader = String::Concat(
                    unit->testResultsLogHeader,
                    Environment::NewLine, _T("        Module Memory Test"));
            if (unit->testFlags & QCOM_UNIT_TEST_I2C_TEST)
                unit->testResultsLogHeader = String::Concat(
                    unit->testResultsLogHeader,
                    Environment::NewLine, _T("        I�C Test"));
            if (unit->testFlags & QCOM_UNIT_TEST_READINGS_TEST)
                unit->testResultsLogHeader = String::Concat(
                    unit->testResultsLogHeader,
                    Environment::NewLine, _T("        Readings Test"));
            if (unit->testFlags & QCOM_UNIT_TEST_FIRMWARE_TEST)
                unit->testResultsLogHeader = String::Concat(
                    unit->testResultsLogHeader,
                    Environment::NewLine, _T("        Firmware Test"));
            if (unit->testFlags & QCOM_UNIT_TEST_X2_TEST)
                unit->testResultsLogHeader = String::Concat(
                    unit->testResultsLogHeader,
                    Environment::NewLine, _T("        X2 Test"));
            if (unit->testFlags & QCOM_UNIT_TEST_X3_TEST)
                unit->testResultsLogHeader = String::Concat(
                    unit->testResultsLogHeader,
                    Environment::NewLine, _T("        X3 Test"));
            if (unit->testFlags & QCOM_UNIT_TEST_X4_TEST)
                unit->testResultsLogHeader = String::Concat(
                    unit->testResultsLogHeader,
                    Environment::NewLine, _T("        X4 Test"));
            if (unit->testFlags & QCOM_UNIT_TEST_XD_COMM_TEST)
                unit->testResultsLogHeader = String::Concat(
                    unit->testResultsLogHeader,
                    Environment::NewLine, _T("        Transducer Communications Test"));
            if (unit->testFlags & QCOM_UNIT_TEST_XD_INTEGRITY_TEST)
                unit->testResultsLogHeader = String::Concat(
                    unit->testResultsLogHeader,
                    Environment::NewLine, _T("        Transducer Integrity Test"));
            if (unit->testFlags & QCOM_UNIT_TEST_XD_MEMORY_TEST)
                unit->testResultsLogHeader = String::Concat(
                    unit->testResultsLogHeader,
                    Environment::NewLine, _T("        Transducer Memory Test"));
        }
        unit->testResultsLine = unit->testResultsLogHeader;
        QCOM_TestUnitUpdateResultsLog(
            unit,
            (GUI_LOG_ACTION_APPEND_NEWLINE |
            GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY));
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_PreTest()
//----------------------------------------------------------------------------
// QCOM_PromptAndSaveTestResultsFile
//
// Prompts for a filename used for saving the test results, then saves the
// results, even if none exist
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//
// Called by:   QCOM_TransferTestResultsToFile
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_PromptAndSaveTestResultsFile(
    UnitInfo        ^unit)
{
    bool            promptResult;
    bool            suggestFilename = GUI_NO;
    DWORD           unitNumber;
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("QCOM_PromptAndSaveTestResultsFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (unit)
    {
        unitNumber = unit->unitNumber;
        String ^filePathString = unit->testResultsFilePath;
        StringBuilder ^filePathBuilder = gcnew StringBuilder(
            filePathString, QCOM_MAXIMUM_FILE_PATH_LENGTH);
        promptResult = QCOM_PromptForSaveFile(
            String::Concat(
                "Select Test Results File for Unit ",
                unit->moduleSerialNumber),
            filePathBuilder,
            filePathString,
            GUI_FILE_TYPE_LOG);
        filePathString = filePathBuilder->ToString();
        delete filePathBuilder;
        if (promptResult == GUI_ACCEPT)
        {
            unit->testResultsFilePath = filePathString;
            QCOM_TestDetermineResultsFilePath(unit);
            bool spinLockAcquired = GUI_NO;
            bool transferResult = GUI_CANCEL;
            try
            {
                QCOM_TestSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                transferResult = QCOM_TransferTestResultsToFile(unit);
            }
            finally
            {
                if (spinLockAcquired == GUI_YES)
                    QCOM_TestSpinLockArray[unitNumber]->Exit();
            }
            if (transferResult == GUI_ACCEPT)
            {
                QCOM_RecordAndModalEventByFlags(
                    QCOM_EventLogVerboseEnabled,
                    QCOM_VerboseMessagesEnabled,
                    String::Format("QCOM_TransferTestResultsToFile({0:D})", unitNumber),
                    "Test results log for module {0} saved to file\n{1}",
                    unit->moduleSerialNumber,
                    filePathString);
            }
        }
        delete filePathString;
    }                                   // end of if (QCOM_UnitValid(unit))
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (promptResult ? "Yes" : "No"));
    return promptResult;
}                                       // end of QCOM_PromptAndSaveTestResultsFile()
//----------------------------------------------------------------------------
// QCOM_QuerySaveTestResultsFile
//
// If testing is enabled, queries the user to save the test results log for
// the specified transducer to a file
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//
// Called by:   QCOM_QuerySaveUnsavedTestResults (QCOM_TerminateTesting)
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_QuerySaveTestResultsFile(
    UnitInfo        ^unit)
{
    bool            proceedToSaveTestResultsLog = GUI_YES;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_QuerySaveTestResultsFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (unit)
    {
        unitNumber = unit->unitNumber;
        RecordVerboseEvent("{0}({1:D}) called", functionName, unitNumber);
        if (!(unit->testFlags & QCOM_UNIT_TEST_RESULTS_AUTO_SAVE))
        {
            proceedToSaveTestResultsLog = QCOM_PromptModal(
                "Save Test Results Log",
                "Save the test results log for module {0} ?",
                unit->moduleSerialNumber);
        }
        if (proceedToSaveTestResultsLog)
        {
            bool spinLockAcquired = GUI_NO;
            bool transferResult = GUI_CANCEL;
            try
            {
                QCOM_TestSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                transferResult = QCOM_TransferTestResultsToFile(unit);
            }
            finally
            {
                if (spinLockAcquired == GUI_YES)
                    QCOM_TestSpinLockArray[unitNumber]->Exit();
            }
            if (transferResult == GUI_ACCEPT)
            {
                QCOM_RecordAndModalEventByFlags(
                    QCOM_EventLogVerboseEnabled,
                    QCOM_VerboseMessagesEnabled,
                    String::Format("QCOM_TransferTestResultsToFile({0:D})", unitNumber),
                    "Test results log for module {0} saved to file\n{1}",
                    unit->moduleSerialNumber,
                    unit->testResultsFilePath);
            }
        }
    }
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (proceedToSaveTestResultsLog ? "Yes" : "No"));
    return proceedToSaveTestResultsLog;
}                                       // end of QCOM_QuerySaveTestResultsFile()
//----------------------------------------------------------------------------
// QCOM_QuerySaveUnsavedTestResults
//
// Queries the user whether to save unsaved test results
//
// Called by:   QCOM_HaltAllUserActivity
//              QCOM_TerminateTesting
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_QuerySaveUnsavedTestResults(void)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_QuerySaveUnsavedTestResults");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    if ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_PRESENT) &&
        (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_UNSAVED) &&
        !(QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_DONT_SAVE_ON_EXIT))
    {
        for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            if (unit)
            {
                if (QCOM_TestResultsPresent(unit) &&
                    (unit->testFlags & QCOM_UNIT_TEST_RESULTS_UNSAVED))
                {
                    QCOM_QuerySaveTestResultsFile(unit);
                }
            }
        }
    }
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_QuerySaveUnsavedTestResults()
//----------------------------------------------------------------------------
// QCOM_QuerySelectTestResultsFile
//
// Queries the user to specify a test results file
//
// Returns: GUI_YES     A test results file has been selected
//          GUI_NO      The user has chosen not to select a test results file
//
// Called by:   QCOM_HaltAllUserActivity
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_QuerySelectTestResultsFile(
    UnitInfo        ^unit)
{
    bool            proceedToSelectResultsFile = GUI_NO;
    String          ^functionName = _T("QCOM_QuerySelectTestResultsFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_UnitValid(unit))
    {
        proceedToSelectResultsFile = QCOM_PromptModal(
            "Test Results File Missing",
            String::Format(
                "A test results file for module {0} has not been assigned. Select one now?",
                unit->moduleSerialNumber));
        if (proceedToSelectResultsFile)
        {
            proceedToSelectResultsFile = QCOM_SelectTestResultsFile(unit);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (proceedToSelectResultsFile ? "Yes" : "No"));
    return proceedToSelectResultsFile;
}                                       // end of QCOM_QuerySelectTestResultsFile()
//----------------------------------------------------------------------------
// QCOM_QueryStopTesting
//
// If tests are running, queries the user to stop the tests
//
// Returns: GUI_YES     Tests are running, and the user does not want to stop
//                      them
//          GUI_NO      Either tests are not running, or if they are, the user
//                      has chosen to stop the tests
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_QueryStopTesting(
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    bool            currentlyTesting = GUI_NO;
    bool            stopTesting = GUI_YES;
    String          ^promptString;
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING)
    {
        currentlyTesting = GUI_YES;
        if (StringSet(formatString))
        {
            String ^promptHeader = String::Format(formatString, parameters);
            promptString = String::Format(
                "{0}\nStop all the tests now?",
                promptHeader);
            delete promptHeader;
        }
        else
        {
            promptString =
                _T("This function could not be performed while tests are running\n") \
                _T("Stop all the tests now?");
        }
        stopTesting = QCOM_PromptModal(
            "Tests Currently Running",
            promptString);
        if (stopTesting)
        {
            QCOM_TestStartStopTestingAllUnits();
            currentlyTesting =
                (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING) ?
                    GUI_YES : GUI_NO;
        }
        delete promptString;
    }
    return currentlyTesting;
}                                       // end of QCOM_QueryStopTesting()
//----------------------------------------------------------------------------
// QCOM_SelectTestDataFile
//
// Prompts the user to set the test (coefficient) data file name
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//
// Called by:   QCOM_DetermineTestsViability
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_SelectTestDataFile(
    UnitInfo        ^unit)
{
    bool            promptResult = GUI_CANCEL;
    DWORD           status = QCOM_SUCCESS;
    CoefficientFormatDef
                    *coefficientData;
    CoefficientFormatDef
                    *format;
    String          ^functionName = _T("QCOM_SelectTestDataFile");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        coefficientData = (CoefficientFormatDef *) malloc(sizeof(CoefficientFormatDef));
        if (coefficientData)
        {
            //----------------------------------------------------------------
            // If the current unit doesn't have a data file path specified,
            // determine whether another unit does, and copy that string, to
            // prevent the user from having to possibly drill down to the same
            // directory
            //----------------------------------------------------------------
            if (!(unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED))
            {
                for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
                {
                    if (QCOM_UnitNumberValid(unitNumber))
                    {
                        if (QCOM_UnitInfoArray[unitNumber]->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED)
                        {
                            unit->testDataFilePath = QCOM_UnitInfoArray[unitNumber]->testDataFilePath;
                            break;
                        }
                    }
                    else
                    {
                        QCOM_RecordAndModalErrorEvent(
                            "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                            functionName, unitNumber, QCOM_CurrentNumberOfUnits);
                    }
                }
            }
            do
            {
                StringBuilder ^dataPathBuilder = gcnew StringBuilder(
                    unit->testDataFilePath, QCOM_MAXIMUM_FILE_PATH_LENGTH);
                promptResult = QCOM_PromptForReadFile(
                    String::Concat(
                        "Select Test Data File for Unit ",
                        unit->moduleSerialNumber),
                    dataPathBuilder,
                    ((unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED) ? unit->testDataFilePath : nullptr),
                    GUI_FILE_TYPE_HEX);
                unit->testDataFilePath = dataPathBuilder->ToString();
                delete dataPathBuilder;
                if (promptResult)
                {
                    status = QCOM_ReadCoefficientDataFromFile(
                        unit->testDataFilePath,
                        coefficientData);
                    if (status == QCOM_SUCCESS)
                    {
                        format = coefficientData;
                        if (memcmp(&format->coefficients1[96], "Test", 4))
                        {
                            promptResult = QCOM_PromptModal(
                                "Invalid Test Data File",
                                "The selected coefficient data file is not valid for testing.\n"
                                "Use it anyway?");
                            if (promptResult == GUI_NO)
                            {
                                ClearBuffer(coefficientData, sizeof(CoefficientFormatDef));
                                status = QCOM_FAILURE;
                                promptResult = GUI_ACCEPT;
                            }
                        }
                    }
                }
            }
            while ((status != QCOM_SUCCESS) && (promptResult == GUI_ACCEPT));
            free((void *) coefficientData);
        }
        else
        {
            GUI_DisplaySimpleError(
                String::Format("{0}({1:D})", functionName, unit->unitNumber),
                "Unable to allocate enough memory to complete the selection");
            status = QCOM_FAILURE;
        }
        if ((promptResult == GUI_ACCEPT) && StringSet(unit->testDataFilePath) && (status == QCOM_SUCCESS))
            unit->testFlags |= QCOM_UNIT_TEST_DATA_FILE_SPECIFIED;
//        else
//            unit->testFlags &= ~QCOM_UNIT_TEST_DATA_FILE_SPECIFIED;
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
    return promptResult;
}                                       // end of QCOM_SelectTestDataFile()
//----------------------------------------------------------------------------
// QCOM_SelectTestFirmwareFile
//
// Prompts the user to set the name of the firmware file used for testing
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//
// Called by:   QCOM_DetermineTestsViability
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_SelectTestFirmwareFile(
    UnitInfo        ^unit)
{
    bool            promptResult = GUI_ACCEPT;
    char            *testFirmwareFilePath;
    LPBYTE          firmwareData;
    DWORD           status = QCOM_SUCCESS;
    String          ^functionName = _T("QCOM_SelectTestFirmwareFile");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        firmwareData = (LPBYTE) malloc(QD_FIRMWARE_MAXIMUM_DATA_SIZE);          // (63 * 1024)
        if (firmwareData)
        {
            //----------------------------------------------------------------
            // If the current unit doesn't have a test firmware file path
            // specified, determine whether another unit does, and copy that
            // one, to prevent the user from having to possibly drill down to
            // the same directory
            //----------------------------------------------------------------
            if (!(unit->testFlags & QCOM_UNIT_TEST_FW_FILE_SPECIFIED))
            {
                for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
                {
                    if (QCOM_UnitNumberValid(unitNumber))
                    {
                        if (QCOM_UnitInfoArray[unitNumber]->testFlags & QCOM_UNIT_TEST_FW_FILE_SPECIFIED)
                        {
                            unit->testFirmwareFilePath = QCOM_UnitInfoArray[unitNumber]->testFirmwareFilePath;
                            break;
                        }
                    }
                    else
                    {
                        QCOM_RecordAndModalErrorEvent(
                            "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                            functionName, unitNumber, QCOM_CurrentNumberOfUnits);
                    }
                }
            }
            do
            {
                StringBuilder ^firmwarePathBuilder = gcnew StringBuilder(
                    unit->testFirmwareFilePath, QCOM_MAXIMUM_FILE_PATH_LENGTH);
                promptResult = QCOM_PromptForReadFile(
                    String::Format(
                        "Select Firmware File for Module {0}",
                        unit->moduleSerialNumber),
                    firmwarePathBuilder,
                    nullptr,
                    GUI_FILE_TYPE_HEX);
                unit->testFirmwareFilePath = firmwarePathBuilder->ToString();
                delete firmwarePathBuilder;
                if (promptResult == GUI_ACCEPT)
                {
                    testFirmwareFilePath = (char *) malloc(QCOM_MAXIMUM_FILE_PATH_LENGTH);
                    if (testFirmwareFilePath)
                    {
                        QCOM_ConvertString(
                            unit->testFirmwareFilePath,
                            testFirmwareFilePath,
                            QCOM_MAXIMUM_FILE_PATH_LENGTH);
                        status = QD_ReadFirmwareDataFromFile(
                            (LPBYTE) testFirmwareFilePath,
                            firmwareData);
                        if (status == QD_SUCCESS)
                        {
                            if ((firmwareData[QD_FIRMWARE_TEST_OFFSET] != 0xFF) &&
                                (memcmp(&firmwareData[QD_FIRMWARE_TEST_OFFSET], "Test", 4) == 0))
                            {
                                memset(&firmwareData[QD_FIRMWARE_TEST_OFFSET], 0xFF, 4);
                            }
                            else
                            {
                                GUI_DisplaySimpleError(functionName,
                                    "Invalid firmware test file:\n{0}",
                                    unit->testFirmwareFilePath);
                                status = QD_ERROR_INVALID_FIRMWARE_PAGE;
                            }
                        }
                        free((void *) testFirmwareFilePath);
                    }
                }
            }
            while ((status != QCOM_SUCCESS) && (promptResult == GUI_ACCEPT));
            free((void *) firmwareData);
        }
        else
        {
            GUI_DisplaySimpleError(
                String::Format("{0}({1:D})", functionName, unit->unitNumber),
                "Unable to allocate enough memory to complete the selection");
            status = QCOM_FAILURE;
        }
        if ((promptResult == GUI_ACCEPT) && StringSet(unit->testFirmwareFilePath) && (status == QCOM_SUCCESS))
            unit->testFlags |= QCOM_UNIT_TEST_FW_FILE_SPECIFIED;
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
    return promptResult;
}                                       // end of QCOM_SelectTestFirmwareFile()
//----------------------------------------------------------------------------
// QCOM_SelectTestResultsFile
//
// Prompts the user to set the test results file name
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//
// Called by:   QCOM_QuerySelectTestResultsFile
//              QCOM_TestUnitSelectResultsFileButtonClicked
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_SelectTestResultsFile(
    UnitInfo        ^unit)
{
    bool            promptResult;
    bool            suggestFilename = GUI_NO;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_SelectTestResultsFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        String ^originalFilePathString = unit->testResultsFilePath;
        if (QCOM_TRFileKnown(unit))
        {
            bool spinLockAcquired = GUI_NO;
            bool transferResult = GUI_CANCEL;
            try
            {
                QCOM_TestSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                transferResult = QCOM_TransferTestResultsToFile(unit);
            }
            finally
            {
                if (spinLockAcquired == GUI_YES)
                    QCOM_TestSpinLockArray[unitNumber]->Exit();
            }
            if (transferResult == GUI_ACCEPT)
            {
                QCOM_RecordAndModalEventByFlags(
                    QCOM_EventLogVerboseEnabled,
                    QCOM_VerboseMessagesEnabled,
                    String::Format("QCOM_TransferTestResultsToFile({0:D})", unitNumber),
                    "Test results log for module {0} saved to file\n{1}",
                    unit->moduleSerialNumber,
                    originalFilePathString);
            }
            unit->testFlags &= ~QCOM_UNIT_TEST_RESULTS_UNSAVED;
        }
        StringBuilder ^filePathBuilder = gcnew StringBuilder(
            originalFilePathString, QCOM_MAXIMUM_FILE_PATH_LENGTH);
        promptResult = QCOM_PromptForSaveFile(
            String::Concat(
                "Select Test Results File for Unit ",
                unit->moduleSerialNumber),
            filePathBuilder,
            (suggestFilename ? originalFilePathString : nullptr),
            GUI_FILE_TYPE_LOG);
        String ^newFilePathString = filePathBuilder->ToString();
        delete filePathBuilder;
        if ((promptResult == GUI_ACCEPT) && StringSet(newFilePathString))
        {
            QCOM_TestFileMove(originalFilePathString, newFilePathString);
            unit->testResultsFilePath = newFilePathString;
            unit->testFlags |= QCOM_UNIT_TEST_RESULTS_FILE_SPECIFIED;
        }
        QCOM_TestDetermineResultsFilePath(unit);
        delete newFilePathString;
        delete originalFilePathString;
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (promptResult ? "Yes" : "No"));
    return promptResult;
}                                       // end of QCOM_SelectTestResultsFile()
//----------------------------------------------------------------------------
// QCOM_StampTestResultsLogBeginLoop
//
// Updates the test log to indicate the start of a test loop
//
// Note:    A loopNumber of zero indicates the test log was just cleared
//
// Note:    maximumLoopCount is valid only if the QCOM_UNIT_TEST_LOOP_FOREVER
//          flag is not set
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StampTestResultsLogBeginLoop(
    UnitInfo        ^unit,
    DWORD           loopNumber,
    DWORD           maximumLoopCount)
{
    TestingStatsInfo
                    ^testStats;
    String          ^functionName = _T("QCOM_StampTestResultsLogBeginLoop");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        if (unit->testFlags & QCOM_UNIT_TEST_AVAILABLE)
        {
            if (loopNumber)
            {
                if (unit->testFlags & QCOM_UNIT_TEST_LOOPING_ENABLED)
                {
                    if (unit->testFlags & QCOM_UNIT_TEST_LOOP_FOREVER)
                    {
                        unit->testResultsLine = String::Format(
                            "Begin test loop {0:D} for QCOM Module {1}{2}{3}",
                            loopNumber,
                            unit->moduleSerialNumber,
                            (QCOM_XDSNValid(unit) ? _T(" with transducer ") : QCOM_STRING_EMPTY),
                            (QCOM_XDSNValid(unit) ? unit->transducerSerialNumber : QCOM_STRING_EMPTY));
                    }
                    else
                    {
                        unit->testResultsLine = String::Format(
                            "Begin test loop {0:D} of {1:D} for QCOM Module {2}{3}{4}",
                            loopNumber, maximumLoopCount,
                            unit->moduleSerialNumber,
                            (QCOM_XDSNValid(unit) ? _T(" with transducer ") : QCOM_STRING_EMPTY),
                            (QCOM_XDSNValid(unit) ? unit->transducerSerialNumber : QCOM_STRING_EMPTY));
                    }
                    QCOM_TestUnitUpdateResultsLog(
                        unit,
                        (GUI_LOG_ACTION_APPEND_NEWLINE |
                        GUI_LOG_ACTION_PREPEND_TIME_STAMP |
                        GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY));
                    //------------------------------------------------------------
                    // Start the loop clock running
                    //------------------------------------------------------------
                    testStats = unit->testingStats;
//                    QCOM_TestUnitInitializeStatistics(unit);
                }
            }                           // end of if (loopNumber)
            else
            {
                unit->testResultsLine = String::Concat(
                    "Test log cleared for QCOM Module ",
                    unit->moduleSerialNumber,
                    (QCOM_XDSNValid(unit) ? _T(" with transducer ") : QCOM_STRING_EMPTY),
                    (QCOM_XDSNValid(unit) ? unit->transducerSerialNumber : QCOM_STRING_EMPTY));
                QCOM_TestUnitUpdateResultsLog(
                    unit,
                    (GUI_LOG_ACTION_APPEND_NEWLINE |
                    GUI_LOG_ACTION_PREPEND_TIME_STAMP |
                    GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY));
            }
        }                               // end of if (unit->testFlags & QCOM_UNIT_TEST_AVAILABLE)
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_StampTestResultsLogBeginLoop()
//----------------------------------------------------------------------------
// QCOM_StampTestResultsLogEndLoop
//
// Updates the test log to indicate the end of a test loop
//
// Note:    maximumLoopCount is valid only if the QCOM_UNIT_TEST_LOOP_FOREVER
//          flag is not set
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StampTestResultsLogEndLoop(
    UnitInfo        ^unit,
    DWORD           loopNumber,
    DWORD           maximumLoopCount,
    bool            endOfTest)
{
    int             lapsedDays;
    int             lapsedHours;
    int             lapsedMinutes;
    int             lapsedSeconds;
    int             lapsedMilliseconds;
    DWORD           currentTime = GetTickCount();
    TestingStatsInfo
                    ^testStats;
    String          ^functionName = _T("QCOM_StampTestResultsLogEndLoop");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        if ((unit->testFlags & QCOM_UNIT_TEST_AVAILABLE) &&
            (unit->testFlags & QCOM_UNIT_TEST_LOOPING_ENABLED))
        {
            testStats = unit->testingStats;
            //----------------------------------------------------------------
            // Post the time elapsed for the current loop
            //----------------------------------------------------------------
            testStats->cumulativeLoop = (currentTime - testStats->startLoopTime);
            testStats->startLoopTime = currentTime;
            QCOM_TimeElapsed(
                testStats->cumulativeLoop,
                &lapsedDays,
                &lapsedHours,
                &lapsedMinutes,
                &lapsedSeconds,
                &lapsedMilliseconds);
            unit->testResultsLine = String::Format(
                "    Test loop {0:D} time elapsed: {1:D} day{2} {3:D} hour{4} {5:D} minute{6} {7:D}.{8:D3} second{9}",
                loopNumber,
                lapsedDays, ((lapsedDays == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                lapsedHours, ((lapsedHours == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                lapsedMinutes, ((lapsedMinutes == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                lapsedSeconds, lapsedMilliseconds,
                (((lapsedSeconds == 1) && (lapsedMilliseconds == 0)) ? QCOM_STRING_EMPTY : QCOM_STRING_S));
            QCOM_TestUnitUpdateResultsLog(
                unit,
                (GUI_LOG_ACTION_APPEND_NEWLINE |
                GUI_LOG_ACTION_PREVENT_TIME_STAMP |
                GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY));
            //----------------------------------------------------------------
            // Note the end of the test loop
            //----------------------------------------------------------------
            if (unit->testFlags & QCOM_UNIT_TEST_LOOP_FOREVER)
            {
                unit->testResultsLine = String::Format(
                    "End test loop {0:D} for QCOM Module {1}",
                    loopNumber,
                    unit->moduleSerialNumber);
            }
            else
            {
                unit->testResultsLine = String::Format(
                    "End test loop {0:D} of {1:D} for QCOM Module {2}",
                    loopNumber, maximumLoopCount,
                    unit->moduleSerialNumber);
            }
            QCOM_TestUnitUpdateResultsLog(
                unit,
                (GUI_LOG_ACTION_APPEND_NEWLINE |
                GUI_LOG_ACTION_PREPEND_TIME_STAMP |
                GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY));
            if (!endOfTest)
            {
                //------------------------------------------------------------
                // Note the test time elapsed thus far
                //------------------------------------------------------------
                testStats->cumulative += (currentTime - testStats->startTime);
                testStats->startTime = currentTime;
                QCOM_TimeElapsed(
                    testStats->cumulative,
                    &lapsedDays,
                    &lapsedHours,
                    &lapsedMinutes,
                    &lapsedSeconds,
                    &lapsedMilliseconds);
                unit->testResultsLine = String::Format(
                    "    Total test time so far: {0:D} day{1} {2:D} hour{3} {4:D} minute{5} {6:D}.{7:D3} second{8}",
                    lapsedDays, ((lapsedDays == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                    lapsedHours, ((lapsedHours == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                    lapsedMinutes, ((lapsedMinutes == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                    lapsedSeconds, lapsedMilliseconds,
                    (((lapsedSeconds == 1) && (lapsedMilliseconds == 0)) ? QCOM_STRING_EMPTY : QCOM_STRING_S));
                QCOM_TestUnitUpdateResultsLog(
                    unit,
                    (GUI_LOG_ACTION_APPEND_NEWLINE |
                    GUI_LOG_ACTION_PREVENT_TIME_STAMP |
                    GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY));
            }
            delete testStats;
        }                               // end of if ((unit->testFlags & QCOM_UNIT_TEST_AVAILABLE) && ...)
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_StampTestResultsLogEndLoop()
//----------------------------------------------------------------------------
// QCOM_StampTestResultsLogTruncated
//
// Updates the test log display with an indication that the display has been
// truncated, along with the name of the test log file that contains the
// lines that have been removed
//
// Called by:   QCOM_TestUnitUpdateResultsLog
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_StampTestResultsLogTruncated(
    UnitInfo        ^unit,
    bool            resultsWereSaved)
{
    String          ^functionName = _T("QCOM_StampTestResultsLogTruncated");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        if (unit->testFlags & QCOM_UNIT_TEST_AVAILABLE)
        {
            if (resultsWereSaved)
            {
                unit->testResultsLine = String::Format(
                    "<Lines above for QCOM Module {0} have been moved to {1}>",
                    unit->moduleSerialNumber,
                    unit->testResultsFilePath);
            }
            else
            {
                unit->testResultsLine = String::Format(
                    "<Lines above for QCOM Module {0} have been cleared>",
                    unit->moduleSerialNumber);
            }
            //----------------------------------------------------------------
            // Replace the display with testResultsLine (clear the display,
            // then stamp the display with testResultsLine), but do nothing to
            // the test log itself
            //----------------------------------------------------------------
            QCOM_TestUnitUpdateResultsLog(
                unit,
                (GUI_LOG_ACTION_APPEND_NEWLINE |
                GUI_LOG_ACTION_REPLACE_DISPLAY |
                GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY));
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_StampTestResultsLogTruncated()
//----------------------------------------------------------------------------
// QCOM_TerminateTesting
//
// Stops testing for the entire system, if it's running
//
// Called by:   QCOM_HomeClosingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TerminateTesting(void)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TerminateTesting");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING)
    {
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                unit = QCOM_UnitInfoArray[unitNumber];
                if (unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING)
                {
                    unit->testFlags &= ~QCOM_UNIT_TEST_CURRENTLY_TESTING;
                    unit->testsCompleted = 0;
                    QCOM_StampTestResultsLogEndLoop(unit, 0, 0, GUI_YES);
                }
            }
        }
        QCOM_GeneralInfo->testFlags &= ~QCOM_GENERAL_TEST_CURRENTLY_TESTING;
    }
//    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    QCOM_QuerySaveUnsavedTestResults();
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_TerminateTesting()
//----------------------------------------------------------------------------
// QCOM_TestAllAppendResultsChecked
//
// Handles the check of the Append Results box
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllAppendResultsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralTestFlagThenSetUnitFlags(
        QCOM_GENERAL_TEST_RESULTS_APPEND,
        QCOM_UNIT_TEST_RESULTS_APPEND);
    RecordBasicEvent(
        "Append Test Results {0}",
        ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_APPEND) ? "checked" : "un-checked"));
}                                       // end of QCOM_TestAllAppendResultsChecked()
//----------------------------------------------------------------------------
// QCOM_TestAllAutoSaveResultsChecked
//
// Handles the check of the Auto-save Results box
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllAutoSaveResultsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralTestFlagThenSetUnitFlags(
        QCOM_GENERAL_TEST_RESULTS_AUTO_SAVE,
        QCOM_UNIT_TEST_RESULTS_AUTO_SAVE);
    RecordBasicEvent(
        "Auto-save Test Results {0}",
        ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_AUTO_SAVE) ? "checked" : "un-checked"));
}                                       // end of QCOM_TestAllAutoSaveResultsChecked()
//----------------------------------------------------------------------------
// QCOM_TestAllClearResultsButtonClicked
//
// Handles the click of the Clear All Results button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllClearResultsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = FunctionName();
    //------------------------------------------------------------------------
    RecordBasicEvent("Clear All Test Results button clicked");
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            QCOM_ClearTestResults(QCOM_UnitInfoArray[unitNumber]);
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                functionName, unitNumber, QCOM_CurrentNumberOfUnits);
        }
    }
}                                       // end of QCOM_TestAllClearResultsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_TestAllDetailedResultsChecked
//
// Handles the check of the Detailed All Results checkbox
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllDetailedResultsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    UnitInfo        ^unit;
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralTestFlagThenSetUnitFlags(
        QCOM_GENERAL_TEST_RESULTS_DETAILED,
        QCOM_UNIT_TEST_RESULTS_DETAILED);
    RecordBasicEvent(
        "All Detailed Test Results {0}",
        ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_DETAILED) ? "checked" : "un-checked"));
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            if (QCOM_TestResultsDisplayed(unit))
            {
                if (QCOM_TestResultsDetailed(unit))
                {
                    testingSummaryResultsBoxArray[unitNumber]->Visible = GUI_NO;
                    testingDetailedResultsBoxArray[unitNumber]->Visible = GUI_YES;
                }
                else
                {
                    testingDetailedResultsBoxArray[unitNumber]->Visible = GUI_NO;
                    testingSummaryResultsBoxArray[unitNumber]->Visible = GUI_YES;
                }
            }
        }
    }
}                                       // end of QCOM_TestAllDetailedResultsChecked()
//----------------------------------------------------------------------------
// QCOM_TestAllDisplayResultsChecked
//
// Handles the check of the Display Results box
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllDisplayResultsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralTestFlagThenSetUnitFlags(
        QCOM_GENERAL_TEST_RESULTS_DISPLAYED,
        QCOM_UNIT_TEST_RESULTS_DISPLAYED);
    RecordBasicEvent(
        "Display All Test Results {0}",
        ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_DISPLAYED) ? "checked" : "un-checked"));
}                                       // end of QCOM_TestAllDisplayResultsChecked()
//----------------------------------------------------------------------------
// QCOM_TestAllDisplayTransducerTestsChecked
//
// Handles the check of the Display Transducer Tests box by displaying the
// transducer tests check boxes
//
// Called by:   QCOM_ConstructGeneralUtilitiesGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllDisplayTransducerTestsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralTestFlagThenSetUnitFlags(
        QCOM_GENERAL_TEST_DISPLAY_XD_TESTS,
        QCOM_UNIT_TEST_ZERO_FLAG);
    RecordBasicEvent(
        "Display Transducer Tests {0}",
        ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_DISPLAY_XD_TESTS) ? "checked" : "un-checked"));
}                                       // end of QCOM_TestAllDisplayTransducerTestsChecked()
//----------------------------------------------------------------------------
// QCOM_TestAllLoopChecked
//
// Handles the check of the Loop Tests box
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllLoopChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralTestFlagThenSetUnitFlags(
        QCOM_GENERAL_TEST_LOOPING_ENABLED,
        QCOM_UNIT_TEST_LOOPING_ENABLED);
    RecordBasicEvent(
        "Loop Tests {0}",
        ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_LOOPING_ENABLED) ? "checked" : "un-checked"));
}                                       // end of QCOM_TestAllLoopChecked()
//----------------------------------------------------------------------------
// QCOM_TestAllLoopForeverChecked
//
// Handles the check of the Loop Forever box
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllLoopForeverChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralTestFlagThenSetUnitFlags(
        QCOM_GENERAL_TEST_LOOP_FOREVER,
        QCOM_UNIT_TEST_LOOP_FOREVER);
    RecordBasicEvent(
        "Loop Tests Forever {0}",
        ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_LOOP_FOREVER) ? "checked" : "un-checked"));
}                                       // end of QCOM_TestAllLoopForeverChecked()
//----------------------------------------------------------------------------
// QCOM_TestAllResetButtonClicked
//
// Handles the click of the Reset All Tests button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllResetButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    UnitInfo        ^unit;
    String          ^functionName = FunctionName();
    //------------------------------------------------------------------------
    RecordBasicEvent("Reset All Tests button clicked");
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            unit->testFlags &= ~QCOM_UNIT_TEST_ALL;
            unit->testsToComplete = 0;
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                functionName, unitNumber, QCOM_CurrentNumberOfUnits);
        }
    }
    QCOM_GeneralInfo->testFlags &= ~QCOM_GENERAL_TEST_TESTS_SELECTED;
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
}                                       // end of QCOM_TestAllResetButtonClicked()
//----------------------------------------------------------------------------
// QCOM_TestAllSaveResultsButtonClicked
//
// Handles the click of the Save All Results button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllSaveResultsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestAllSaveResultsButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("Save All Test Results button clicked");
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            bool spinLockAcquired = GUI_NO;
            bool transferResult = GUI_CANCEL;
            try
            {
                QCOM_TestSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                transferResult = QCOM_TransferTestResultsToFile(unit);
            }
            finally
            {
                if (spinLockAcquired == GUI_YES)
                    QCOM_TestSpinLockArray[unitNumber]->Exit();
            }
            if (transferResult == GUI_ACCEPT)
            {
                QCOM_RecordAndModalEventByFlags(
                    QCOM_EventLogVerboseEnabled,
                    QCOM_VerboseMessagesEnabled,
                    String::Format("QCOM_TransferTestResultsToFile({0:D})", unitNumber),
                    "Test results log for module {0} saved to file\n{1}",
                    unit->moduleSerialNumber,
                    unit->testResultsFilePath);
            }
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                functionName, unitNumber, QCOM_CurrentNumberOfUnits);
        }
    }
}                                       // end of QCOM_TestAllSaveResultsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_TestAllStartStopTestingButtonClicked
//
// Handles the click of the Test All Units button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//              QCOM_InstallHomeWindowGraphics
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllStartStopTestingButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent(
        "{0} All Tests button clicked",
        ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING) ? "Stop" : "Start"));
    QCOM_TestStartStopTestingAllUnits();
}                                       // end of QCOM_TestAllStartStopTestingButtonClicked()
//----------------------------------------------------------------------------
// QCOM_TestAllStopOnErrorsChecked
//
// Handles the check of the Stop On Errors box
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllStopOnErrorsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralTestFlagThenSetUnitFlags(
        QCOM_GENERAL_TEST_STOP_ON_ERRORS,
        QCOM_UNIT_TEST_STOP_ON_ERRORS);
    RecordBasicEvent(
        "Stop Tests on Errors {0}",
        ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_STOP_ON_ERRORS) ? "checked" : "un-checked"));
}                                       // end of QCOM_TestAllStopOnErrorsChecked()
//----------------------------------------------------------------------------
// QCOM_TestAllWrapResultsChecked
//
// Handles the check of the Wrap Results box
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestAllWrapResultsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    QCOM_ToggleGeneralTestFlagThenSetUnitFlags(
        QCOM_GENERAL_TEST_RESULTS_WRAP,
        QCOM_UNIT_TEST_RESULTS_WRAP);
    RecordBasicEvent(
        "Wrap Test results {0}",
        ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_WRAP) ? "checked" : "un-checked"));
}                                       // end of QCOM_TestAllWrapResultsChecked()
//----------------------------------------------------------------------------
// QCOM_TestClearCommentButtonClicked
//
// Handles the click of the Test Clear Comment button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestClearCommentButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    RecordBasicEvent("Clear Test Comment button clicked");
    testingInsertCommentBox->Clear();
}                                       // end of QCOM_TestClearCommentButtonClicked()
//----------------------------------------------------------------------------
// QCOM_TestCommentTimeStampChecked
//
// Handles the click of the Test Time Stamp Comments button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestCommentTimeStampChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    //------------------------------------------------------------------------
    QCOM_ToggleGeneralTestFlagThenSetUnitFlags(
        QCOM_GENERAL_TEST_TIME_STAMP_COMMENTS,
        QCOM_UNIT_TEST_ZERO_FLAG);
    RecordBasicEvent(
        "Test Comment Time Stamp {0}",
        ((QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_TIME_STAMP_COMMENTS) ? "checked" : "un-checked"));
}                                       // end of QCOM_TestCommentTimeStampChecked()
//----------------------------------------------------------------------------
// QCOM_TestDetermineDataFilePath
//
// Constructs or detemines the pathname of the test data file
//
// Called by:   QCOM_InitializeUserInterface
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestDetermineDataFilePath(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_TestDetermineDataFilePath");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (!(unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED) ||
            !StringSet(unit->testDataFilePath))
        {
            String ^filePathString = String::Format(
                "{0}\\Test\\QCOM-Memory-Test-{1}.hex",
                Application::StartupPath,
                (QCOM_XDIsFrequency(unit) ? "A" : "5"));
            if (File::Exists(filePathString))
            {
                unit->testDataFilePath = filePathString;
                unit->testFlags |= QCOM_UNIT_TEST_DATA_FILE_SPECIFIED;
            }
            delete filePathString;
        }
    }
}                                       // end of QCOM_TestDetermineDataFilePath()
//----------------------------------------------------------------------------
// QCOM_TestDetermineFirmwareFilePath
//
// Constructs or detemines the pathname of the test firmware file
//
// Called by:   QCOM_InitializeUserInterface
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestDetermineFirmwareFilePath(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_TestDetermineFirmwareFilePath");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (!(unit->testFlags & QCOM_UNIT_TEST_FW_FILE_SPECIFIED) ||
            !StringSet(unit->testFirmwareFilePath))
        {
            String ^filePathString = String::Format(
                "{0}\\Test\\QCOM-FW-Test-{1:D}.hex",
                Application::StartupPath,
                (QCOM_XDIsFrequency(unit) ? 11 : 97));
            if (File::Exists(filePathString))
            {
                unit->testFirmwareFilePath = filePathString;
                unit->testFlags |= QCOM_UNIT_TEST_FW_FILE_SPECIFIED;
            }
            delete filePathString;
        }
    }
}                                       // end of QCOM_TestDetermineFirmwareFilePath()
//----------------------------------------------------------------------------
// QCOM_TestDetermineResultsFilePath
//
// Constructs or detemines the pathname of the test results file
//
// Called by:   QCOM_InitializeUserInterface
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestDetermineResultsFilePath(
    UnitInfo        ^unit)
{
    bool            fileNameIdentified = GUI_NO;
    bool            keepLooking = GUI_YES;
    int             fileInstance = 1;
    DateTime        dateTime = DateTime::Now;
    String          ^filePathString = QCOM_STRING_NONE;
    String          ^functionName = _T("QCOM_TestDetermineResultsFilePath");
    //------------------------------------------------------------------------
    String ^pathCaptionString = _T("Test Results File: ");
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if ((unit->testFlags & QCOM_UNIT_TEST_FW_FILE_SPECIFIED) &&
            StringSet(unit->testFirmwareFilePath))
        {
            filePathString = unit->testResultsFilePath;
            fileNameIdentified = GUI_YES;
        }
        else
        {
            while (keepLooking)
            {
                filePathString = String::Format(
                    "{0}\\QCOM-TestResults-{1}-{2}-{3:D2}{4:D2}{5:D2}-{6:D3}.log",
                    QCOM_GeneralInfo->logDirectory,
                    (QCOM_ModuleSNValid(unit) ?
                        unit->moduleSerialNumber : "Module"),
                    ((QCOM_XDPresent(unit) && QCOM_XDSNValid(unit)) ?
                        unit->transducerSerialNumber : "XD"),
                    (dateTime.Year % 100),
                    dateTime.Month,
                    dateTime.Day,
                    fileInstance);
                if (File::Exists(filePathString))
                {
                    fileInstance++;
                }
                else
                {
                    keepLooking = GUI_NO;
                    fileNameIdentified = GUI_YES;
                }
                if (fileInstance >= 1000)
                    keepLooking = fileNameIdentified = GUI_NO;
            }                           // end of while (keepLooking)
        }
        if (fileNameIdentified)
        {
            unit->testResultsFilePath = filePathString;
            unit->testFlags |= QCOM_UNIT_TEST_RESULTS_FILE_SPECIFIED;
            filePathString = QCOM_LimitFilePathStringWidth(
                filePathString,
                testingResultsFileLabelArray[unit->unitNumber]->Width - QCOM_StringWidth(pathCaptionString));
            testingSelectResultsFileButtonArray[unit->unitNumber]->Text = GUI_CHANGE_TEST_RESULTS_FILE;
        }
        else
        {
            filePathString = QCOM_STRING_NONE;
            testingSelectResultsFileButtonArray[unit->unitNumber]->Text = GUI_SELECT_TEST_RESULTS_FILE;
        }
    }                                   // end of if (QCOM_UnitValid(unit))
    testingResultsFileLabelArray[unit->unitNumber]->Text = String::Concat(
        pathCaptionString, filePathString);
    delete pathCaptionString;
}                                       // end of QCOM_TestDetermineResultsFilePath()
//----------------------------------------------------------------------------
// QCOM_TestFileMove
//
// Moves the specified test results file to the specified destination
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestFileMove(
    String          ^sourcePathString,
    String          ^destinationPathString)
{
    long            fileSize;
    String          ^functionName = _T("QCOM_TestFileMove");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(sourcePathString) && StringSet(destinationPathString))
    {
        sourcePathString = sourcePathString->Trim();
        destinationPathString = destinationPathString->Trim();
        if (File::Exists(sourcePathString))
        {
            FileInfo ^filePathInfo = gcnew FileInfo(sourcePathString);
            fileSize = (long) filePathInfo->Length;
            delete filePathInfo;
            if (!fileSize)
            {
                File::Delete(sourcePathString);
                Thread::Sleep(100);
            }
            if (File::Exists(destinationPathString))
            {
                File::Delete(destinationPathString);
                Thread::Sleep(100);
            }
            if (File::Exists(sourcePathString))
            {
                File::Move(sourcePathString, destinationPathString);
            }
            RecordBasicEvent("    Moved {0} to {1}", sourcePathString, destinationPathString);
        }
    }                                   // end of if (StringSet(sourcePathString) && StringSet(destinationPathString))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_TestFileMove()
//----------------------------------------------------------------------------
// QCOM_TestInsertComment
//
// Inserts a comment in the test results for the specified unit
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestInsertComment(
    UnitInfo        ^unit)
{
    DWORD           logAction = GUI_LOG_ACTION_COMMENT;
    String          ^functionName = _T("QCOM_TestInsertComment");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unit->testResultsLine = testingInsertCommentBox->Text;
        logAction |=
            (GUI_LOG_ACTION_APPEND_NEWLINE |
            GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY |
            GUI_LOG_ACTION_COPY_LOG_TO_DISPLAY);
        if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_TIME_STAMP_COMMENTS)
            logAction |= GUI_LOG_ACTION_PREPEND_TIME_STAMP;
        QCOM_TestUnitUpdateResultsLog(unit, logAction);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_TestInsertComment()
//----------------------------------------------------------------------------
// QCOM_TestInsertCommentButtonClicked
//
// Handles the click of the Log All Add Comment button
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestInsertCommentButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    String          ^functionName = FunctionName();
    //------------------------------------------------------------------------
    RecordBasicEvent(
        "Insert Test Comment button clicked to add text\n'{0}'",
        testingInsertCommentBox->Text);
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            QCOM_TestInsertComment(QCOM_UnitInfoArray[unitNumber]);
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                functionName, unitNumber, QCOM_CurrentNumberOfUnits);
        }
    }
}                                       // end of QCOM_TestInsertCommentButtonClicked()
//----------------------------------------------------------------------------
// QCOM_TestReflectDataPresence
//
// Enable or disable testing objects, depending on whether data is in the
// test log of the specified unit
//
// Called by:   QCOM_TestUnitUpdateResultsLog
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestReflectDataPresence(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_TestReflectDataPresence");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_PRESENT)
        {
            testingClearAllResultsButton->Enabled = GUI_YES;
            testingSaveAllResultsButton->Enabled = GUI_YES;
        }
        else
        {
            testingClearAllResultsButton->Enabled = GUI_NO;
//            testingSaveAllResultsButton->Enabled = GUI_NO;
        }
        if (QCOM_TestResultsPresent(unit))
        {
            testingClearResultsButtonArray[unitNumber]->Enabled = GUI_YES;
            testingSaveResultsButtonArray[unitNumber]->Enabled = GUI_YES;
        }
        else
        {
            testingClearResultsButtonArray[unitNumber]->Enabled = GUI_NO;
//            testingSaveResultsButtonArray[unitNumber]->Enabled = GUI_NO;
            testingStateLabelArray[unitNumber]->Text = GUI_TEST_UNTESTED_STRING;
            testingStateLabelArray[unitNumber]->ForeColor = Color::Green;
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_TestReflectDataPresence()
//----------------------------------------------------------------------------
// QCOM_TestStartStopTestingAllUnits
//
// Runs all the applicable QCOM hardware tests
//
// Called by:   QCOM_TestAllStartStopTestingButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestStartStopTestingAllUnits(void)
{
    bool            stopAll = GUI_NO;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestStartStopTestingAllUnits");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING)
    {
        stopAll = GUI_YES;
    }
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            if (stopAll)
            {
                if (unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING)
                {
                    QCOM_TestUnitStartStopTests(unit);
                }
            }
            else
            {
                if (!(unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                {
                    QCOM_TestUnitStartStopTests(unit);
                }
            }
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                functionName, unitNumber, QCOM_CurrentNumberOfUnits);
        }
    }                                   // end of for (DWORD unitNumber = 0; ...)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_TestStartStopTestingAllUnits()
//----------------------------------------------------------------------------
// QCOM_TestUnitAllModuleChecked
//
// Handles the check of the All Unit Tests box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitAllModuleChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^promptString;
    String          ^functionName = _T("QCOM_TestUnitAllModuleChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if ((unit->testFlags & QCOM_UNIT_TEST_ALL_MODULE) == QCOM_UNIT_TEST_ALL_MODULE)
        {
            unit->testFlags &= ~QCOM_UNIT_TEST_ALL_MODULE;
        }
        else
        {
            unit->testFlags |= QCOM_UNIT_TEST_ALL_MODULE;
            if (!QCOM_UnitReady(unit))
            {
                if (QCOM_XDSNValid(unit))
                {
                    promptString = String::Format(
                        "Transducer {0} cannot be accessed, making\n"
                        "some tests unavailable on module {1}",
                        unit->transducerSerialNumber,
                        unit->moduleSerialNumber);
                }
                else
                {
                    promptString = String::Format(
                        "The transducer cannot be accessed, making\n"
                        "some tests unavailable on module {0}",
                        unit->moduleSerialNumber);
                }
                QCOM_PromptOKModal(
                    "Some Tests Disabled",
                    promptString);
            }
        }
        RecordBasicEvent(
            "All Tests {0} for module {1}",
            (((unit->testFlags & QCOM_UNIT_TEST_ALL_MODULE) == QCOM_UNIT_TEST_ALL_MODULE) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitAllModuleChecked()
//----------------------------------------------------------------------------
// QCOM_TestUnitAllTransducerChecked
//
// Handles the check of the All Transducer Tests box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitAllTransducerChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitAllTransducerChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if ((unit->testFlags & QCOM_UNIT_TEST_ALL_TRANSDUCER) == QCOM_UNIT_TEST_ALL_TRANSDUCER)
            unit->testFlags &= ~QCOM_UNIT_TEST_ALL_TRANSDUCER;
        else
            unit->testFlags |= QCOM_UNIT_TEST_ALL_TRANSDUCER;
        RecordBasicEvent(
            "All Transducer Tests {0} for module {1}",
            ((unit->testFlags & QCOM_UNIT_TEST_ALL_TRANSDUCER) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitAllTransducerChecked()
//----------------------------------------------------------------------------
// QCOM_TestUnitClearResultsButtonClicked
//
// Handles the click of the Clear Test Results button
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitClearResultsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitClearResultsButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Clear Test Results button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_ClearTestResults(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitClearResultsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_TestUnitDetailedResultsChecked
//
// Handles the check of the Detailed Test Results box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitDetailedResultsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitDetailedResultsChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
         QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_TEST_RESULTS_DETAILED,
            QCOM_UNIT_TEST_RESULTS_DETAILED);
        RecordBasicEvent(
            "Detail All Test Results {0} for module {1}",
            (QCOM_TestResultsDetailed(unit) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
        if (QCOM_TestResultsDisplayed(unit))
        {
            if (QCOM_TestResultsDetailed(unit))
            {
                testingSummaryResultsBoxArray[unitNumber]->Visible = GUI_NO;
                testingDetailedResultsBoxArray[unitNumber]->Visible = GUI_YES;
            }
            else
            {
                testingDetailedResultsBoxArray[unitNumber]->Visible = GUI_NO;
                testingSummaryResultsBoxArray[unitNumber]->Visible = GUI_YES;
            }
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitDetailedResultsChecked()
//----------------------------------------------------------------------------
// QCOM_TestUnitFirmwareChecked
//
// Handles the check of the Firmware Test box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitFirmwareChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitFirmwareChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_TEST_ZERO_FLAG,
            QCOM_UNIT_TEST_FIRMWARE_TEST);
        RecordBasicEvent(
            "Firmware Test {0} for module {1}",
            ((unit->testFlags & QCOM_UNIT_TEST_FIRMWARE_TEST) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitFirmwareChecked()
//----------------------------------------------------------------------------
// QCOM_TestUnitI2CChecked
//
// Handles the check of the I�C Test box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitI2CChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitI2CChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_TEST_ZERO_FLAG,
            QCOM_UNIT_TEST_I2C_TEST);
        RecordBasicEvent(
            "I�C Test {0} for module {1}",
            ((unit->testFlags & QCOM_UNIT_TEST_I2C_TEST) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitI2CChecked()
//----------------------------------------------------------------------------
// QCOM_TestUnitInitializeStatistics
//
// Resets the testing stats and sets the start time to the current moment
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitInitializeStatistics(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_TestUnitInitializeStatistics");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    if (QCOM_UnitValid(unit))
    {
        unit->testingStats->cumulative = 0;
        unit->testingStats->cumulativeLoop = 0;
        unit->testingStats->startLoopTime =
        unit->testingStats->startTime = GetTickCount();
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_TestUnitInitializeStatistics()
//----------------------------------------------------------------------------
// QCOM_TestUnitQMEMChecked
//
// Handles the check of the Memory Test box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitQMEMChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitQMEMChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_TEST_ZERO_FLAG,
            QCOM_UNIT_TEST_QMEM_TEST);
        RecordBasicEvent(
            "Memory Test {0} for module {1}",
            ((unit->testFlags & QCOM_UNIT_TEST_QMEM_TEST) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitQMEMChecked()
//----------------------------------------------------------------------------
// QCOM_TestUnitReadingsChecked
//
// Handles the check of the Readings Test box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitReadingsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitReadingsChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_TEST_ZERO_FLAG,
            QCOM_UNIT_TEST_READINGS_TEST);
        RecordBasicEvent(
            "Readings Test {0} for module {1}",
            ((unit->testFlags & QCOM_UNIT_TEST_READINGS_TEST) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitReadingsChecked()
//----------------------------------------------------------------------------
// QCOM_TestUnitSaveResultsButtonClicked
//
// Handles the click of the Save Test Results button
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitSaveResultsButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitSaveResultsButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Save Test Results button clicked for module {0}",
            unit->moduleSerialNumber);
        bool spinLockAcquired = GUI_NO;
        bool transferResult = GUI_CANCEL;
        try
        {
            QCOM_TestSpinLockArray[unitNumber]->Enter(spinLockAcquired);
            transferResult = QCOM_TransferTestResultsToFile(unit);
        }
        finally
        {
            if (spinLockAcquired == GUI_YES)
                QCOM_TestSpinLockArray[unitNumber]->Exit();
        }
        if (transferResult == GUI_ACCEPT)
        {
            QCOM_RecordAndModalEventByFlags(
                QCOM_EventLogVerboseEnabled,
                QCOM_VerboseMessagesEnabled,
                String::Format("QCOM_TransferTestResultsToFile({0:D})", unitNumber),
                "Test results log for module {0} saved to file\n{1}",
                unit->moduleSerialNumber,
                unit->testResultsFilePath);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitSaveResultsButtonClicked()
//----------------------------------------------------------------------------
// QCOM_TestUnitSaveResultsLog
//
// Saves the test detailed results of the specified unit to the specified file
// or the default test results log file
//
// Returns: 0           Success
//          nonzero     Failure
//
// Note:    This function only saves the test results to file if the
//          QCOM_UNIT_TEST_RESULTS_PRESENT flag is set, whether the
//          QCOM_UNIT_TEST_RESULTS_UNSAVED flag is set or not
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_TestUnitSaveResultsLog(
    UnitInfo        ^unit,
    String          ^pathString)
{
    DWORD           status = QCOM_SUCCESS;
    StreamWriter    ^textWriter;
    String          ^functionName = _T("QCOM_TestUnitSaveResultsLog");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordVerboseEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (String::IsNullOrEmpty(pathString))
            pathString = unit->testResultsFilePath;
        if (QCOM_TestResultsPresent(unit))
        {
            String ^testResultsLog = unit->testDetailedResultsLog->ToString();
            if (testResultsLog->Contains("�"))
                testResultsLog = testResultsLog->Replace("�", "2");
            if (unit->testFlags & QCOM_UNIT_TEST_RESULTS_APPEND)
                textWriter = File::AppendText(pathString);
            else
                textWriter = File::CreateText(pathString);
            if (textWriter)
            {
                //------------------------------------------------------------
                // Remove extraneous CR/LF at the end of the log to be saved
                //------------------------------------------------------------
                if ((testResultsLog->Length >= 2) &&
                    testResultsLog->EndsWith(QCOM_STRING_CRLF))
                {
                    testResultsLog = testResultsLog->Substring(
                        0, testResultsLog->LastIndexOf(QCOM_STRING_CRLF));
                }
                //------------------------------------------------------------
                // Write out the entire log in one transfer
                //------------------------------------------------------------
                textWriter->WriteLine(testResultsLog);
                textWriter->Close();
                QCOM_UpdateDeleteLogFilesDropDown();
                QCOM_RecordAndModalEventByFlags(
                    QCOM_EventLogVerboseEnabled,
                    QCOM_DetailedMessagesEnabled,
                    functionName,
                    "Test results for module {0} transducer {1} saved successfully",
                    unit->moduleSerialNumber,
                    unit->transducerSerialNumber);
                delete textWriter;
                delete testResultsLog;
            }
            else
            {
                QCOM_RecordAndModalErrorEvent(
                    "{0}({1:D}) :\nFile cannot be opened for writing:\n{2}",
                    functionName, unit->unitNumber, pathString);
                status = QD_ERROR_FILE_OPEN_FAILURE;                            // 0x0015
            }
        }                               // end of if (QCOM_TestResultsPresent(unit))
        else
        {
            RecordVerboseEvent("    {0}({1:D}) : No test data present for transducer {2} to save",
                functionName, unit->unitNumber,
                unit->transducerSerialNumber);
        }
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
    return status;
}                                       // end of QCOM_TestUnitSaveResultsLog()
//----------------------------------------------------------------------------
// QCOM_TestUnitSelectResultsFileButtonClicked
//
// Handles the click of the Select Test Results File button
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitSelectResultsFileButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitSelectResultsFileButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "Select Test Results File button clicked for module {0}",
            unit->moduleSerialNumber);
        QCOM_SelectTestResultsFile(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_TestUnitSelectResultsFileButtonClicked()
//----------------------------------------------------------------------------
// QCOM_TestUnitStartStopButtonClicked
//
// Handles the click of the Run All Tests button
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitStartStopButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitStartStopButtonClicked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        RecordBasicEvent(
            "{0} Test button clicked for module {1}",
            ((unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING) ? "Stop" : "Start"),
            unit->moduleSerialNumber);
        QCOM_TestUnitStartStopTests(unit);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitStartStopButtonClicked()
//----------------------------------------------------------------------------
// QCOM_TestUnitStartStopTests
//
// Runs all the applicable tests on the specified unit
//
// Called by:   QCOM_HaltAllUserActivity
//              QCOM_TestStartStopTestingAllUnits
//              QCOM_TestUnitStartStopButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitStartStopTests(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_TestUnitStartStopTests");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        if (unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING)
        {
            //----------------------------------------------------------------
            // Stop testing
            //----------------------------------------------------------------
            unit->testFlags &= ~QCOM_UNIT_TEST_CURRENTLY_TESTING;
            if (unit->testFlags & QCOM_UNIT_TEST_RESULTS_AUTO_SAVE)
            {
                bool spinLockAcquired = GUI_NO;
                bool transferResult = GUI_CANCEL;
                try
                {
                    QCOM_TestSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                    transferResult = QCOM_TransferTestResultsToFile(unit);
                }
                finally
                {
                    if (spinLockAcquired == GUI_YES)
                        QCOM_TestSpinLockArray[unitNumber]->Exit();
                }
                if (transferResult == GUI_ACCEPT)
                {
                    RecordVerboseEvent(
                        "    Test results log for module {0} saved to file\n{1}",
                        unit->moduleSerialNumber,
                        unit->testResultsFilePath);
                }
                unit->testFlags &= ~QCOM_UNIT_TEST_RESULTS_UNSAVED;
            }
        }
        else
        {
            //----------------------------------------------------------------
            // Start testing
            //----------------------------------------------------------------
            if (unit->testFlags & QCOM_UNIT_TEST_ALL)
            {
                unit->testFlags |= QCOM_UNIT_TEST_CURRENTLY_TESTING;
            }
            if (unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING)
            {
                QCOM_DetermineTestsViability(unit);
                //------------------------------------------------------------
                // If tests are selected to run, spawn a thread to run them
                //------------------------------------------------------------
                if (unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING)
                {
                    Thread ^testThread =
                        gcnew Thread(gcnew ParameterizedThreadStart(this, &QCOM_GUIClass::QCOM_InitiateUnitTests));
                    testThread->Start(unitNumber);
                }
            }
        }
        RecordBasicEvent("{0} concluded", functionName);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_TestUnitStartStopTests()
//----------------------------------------------------------------------------
// QCOM_TestUnitTimeStampResultsChecked
//
// Handles the check of the Include Time Stamp box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitTimeStampResultsChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitTimeStampResultsChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_TEST_ZERO_FLAG,
            QCOM_UNIT_TEST_RESULTS_TIME_STAMP);
        RecordBasicEvent(
            "Time Stamp Test Results {0} for module {1}",
            ((unit->testFlags & QCOM_UNIT_TEST_RESULTS_TIME_STAMP) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitTimeStampResultsChecked()
//----------------------------------------------------------------------------
// QCOM_TestUnitUpdateChecks
//
// Updates the check marks in the unit tests windows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitUpdateChecks(
    UnitInfo        ^unit)
{
    bool            someTestsSelected = GUI_NO;
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_TestUnitUpdateChecks");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        //--------------------------------------------------------------------
        // Set unit checks and tests based on transducer presence
        //--------------------------------------------------------------------
        if (!QCOM_XDPresent(unit))
        {
            unit->testFlags &= ~QCOM_UNIT_TEST_READINGS_TEST;
            unit->testFlags &= ~QCOM_UNIT_TEST_XD_COMM_TEST;
            unit->testFlags &= ~QCOM_UNIT_TEST_XD_INTEGRITY_TEST;
            unit->testFlags &= ~QCOM_UNIT_TEST_XD_MEMORY_TEST;
        }
        //--------------------------------------------------------------------
        // Memory Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_QMEM_TEST)
            testingQMEMCheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingQMEMCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // I�C Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_I2C_TEST)
            testingI2CCheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingI2CCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Readings Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_READINGS_TEST)
            testingReadingsCheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingReadingsCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Firmware Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_FIRMWARE_TEST)
            testingFirmwareCheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingFirmwareCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // X2 Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_X2_TEST)
            testingX2CheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingX2CheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // X3 Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_X3_TEST)
            testingX3CheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingX3CheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // X4 Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_X4_TEST)
            testingX4CheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingX4CheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Transducer Communication Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_XD_COMM_TEST)
            testingXDCommCheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingXDCommCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Transducer Integrity Test
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_XD_INTEGRITY_TEST)
            testingXDIntegrityCheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingXDIntegrityCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Transducer EEPROM (ASIC or FPGA) Memory Test
        //--------------------------------------------------------------------
        if ((unit->testFlags & QCOM_UNIT_TEST_XD_MEMORY_TEST) &&
            !QCOM_XDIsFrequency(unit) && !QCOM_XDIsDigitalNoMem(unit))
            testingXDMemoryCheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingXDMemoryCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Time Stamp Test Results
        //--------------------------------------------------------------------
        if (unit->testFlags & QCOM_UNIT_TEST_RESULTS_TIME_STAMP)
            testingTimeStampCheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingTimeStampCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // Detailed Test Results
        //--------------------------------------------------------------------
        if (QCOM_TestResultsDetailed(unit))
            testingDetailedCheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingDetailedCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // All Transducer Tests
        //--------------------------------------------------------------------
        if ((unit->testFlags & QCOM_UNIT_TEST_ALL_TRANSDUCER) == QCOM_UNIT_TEST_ALL_TRANSDUCER)
            testingAllTransducerCheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingAllTransducerCheckArray[unitNumber]->Checked = GUI_NO;
        //--------------------------------------------------------------------
        // All Module Tests
        //--------------------------------------------------------------------
        if ((unit->testFlags & QCOM_UNIT_TEST_ALL_MODULE) == QCOM_UNIT_TEST_ALL_MODULE)
            testingAllModuleCheckArray[unitNumber]->Checked = GUI_YES;
        else
            testingAllModuleCheckArray[unitNumber]->Checked = GUI_NO;
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
    //------------------------------------------------------------------------
    // General test checks
    //------------------------------------------------------------------------
}                                       // end of QCOM_TestUnitUpdateChecks()
//----------------------------------------------------------------------------
// QCOM_TestUnitUpdateProgressBar
//
// Updates the testing progress bar with the whole number percentage,
// calculated from the amount of testing items completed out of the number of
// tesing items to complete
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitUpdateProgressBar(
    UnitInfo        ^unit)
{
    int             percentComplete = 0;
    String          ^functionName = _T("QCOM_TestUnitUpdateProgressBar");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        if (unit->testsToComplete)
        {
            percentComplete =
                QCOM_CalculatePercentage(
                    unit->testsCompleted,
                    unit->testsToComplete);
            if ((percentComplete <= 100) &&
                (unit->testsCompleted <= unit->testsToComplete))
            {
                if (unit->testsCompleted == unit->testsToComplete)
                {
                    testingPercentCompleteLabelArray[unit->unitNumber]->Text = _T("Completed");
                }
                else
                {
                    testingPercentCompleteLabelArray[unit->unitNumber]->Text =
                        String::Format("{0:D}% Complete", percentComplete);
                }
                testingPercentCompleteProgressArray[unit->unitNumber]->Value = percentComplete;
            }
            else
            {
                GUI_DisplaySimpleError(functionName,
                    "Unit {0:D} test percentage out of range:\n"
                    "Completed = {1:D} to complete = {2:D}",
                    unit->unitNumber,
                    unit->testsCompleted,
                    unit->testsToComplete);
            }
        }
        else
        {
            testingPercentCompleteLabelArray[unit->unitNumber]->Text = _T("0% Complete");
            testingPercentCompleteProgressArray[unit->unitNumber]->Value = 0;
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_TestUnitUpdateProgressBar()
//----------------------------------------------------------------------------
// QCOM_TestUnitUpdateResultsLog
//
// Updates the test results log and displays according to the action flags
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitUpdateResultsLog(
    UnitInfo        ^unit,
    DWORD           actionFlags)
{
    bool            chooseToSave = GUI_NO;
    bool            logDetail = GUI_NO;
    bool            logSummary = GUI_YES;
    bool            mustEmptyTestLog = GUI_NO;
    bool            someHaveData = GUI_NO;
    DWORD           testFlags;
    DWORD           unitNumber;
    DateTime        dateTime = DateTime::Now;
    String          ^testResultsLine;
    String          ^functionName = _T("QCOM_TestUnitUpdateResultsLog");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        testResultsLine = unit->testResultsLine;
        if (actionFlags & GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY)
        {
            if (unit->testFlags & QCOM_UNIT_TEST_DETAILED_LOG_AVAILABLE)
                logDetail = GUI_YES;
        }
        else
        {
            if (actionFlags & GUI_LOG_ACTION_DETAILED_LOG)
            {
                logSummary = GUI_NO;
                if (unit->testFlags & QCOM_UNIT_TEST_DETAILED_LOG_AVAILABLE)
                    logDetail = GUI_YES;
            }
        }
        if (!(unit->testFlags & QCOM_UNIT_TEST_DETAILED_LOG_AVAILABLE))
        {
            logDetail = GUI_NO;
            logSummary = GUI_YES;
        }
        if (!logDetail && !logSummary)
        {
            GUI_DisplaySimpleError(functionName, "Neither test log is specified");
        }
        if (unit->testFlags & QCOM_UNIT_TEST_AVAILABLE)
        {
            if (actionFlags &
                (GUI_LOG_ACTION_CLEAR_LOG |
                GUI_LOG_ACTION_CLEAR_DISPLAY |
                GUI_LOG_ACTION_REPLACE_DISPLAY))
            {
                //------------------------------------------------------------
                // Clear the test log and/or display
                //------------------------------------------------------------
                if (actionFlags & GUI_LOG_ACTION_CLEAR_LOG)
                {
                    //--------------------------------------------------------
                    // Clear the test logs
                    //--------------------------------------------------------
                    testResultsLine = unit->testResultsLogHeader;
                    String ^headerLine = String::Concat(
                        unit->testResultsLogHeader,
                        QCOM_STRING_CRLF);
                    if (logSummary)
                    {
                        if (actionFlags & GUI_LOG_ACTION_RETAIN_LOG_HEADER)
                        {
                            unit->testSummaryResultsLogRemaining =
                                unit->testSummaryResultsLogSize - headerLine->Length;
                            unit->testFlags |=
                                (QCOM_UNIT_TEST_RESULTS_PRESENT | QCOM_UNIT_TEST_RESULTS_UNSAVED);
                            QCOM_GeneralInfo->testFlags |=
                                (QCOM_GENERAL_TEST_RESULTS_PRESENT | QCOM_GENERAL_TEST_RESULTS_UNSAVED);
                            actionFlags |= (GUI_LOG_ACTION_REPLACE_DISPLAY | GUI_LOG_ACTION_APPEND_NEWLINE);
                            GUI_StringToBuilder(
                                headerLine,
                                unit->testSummaryResultsLog);
                        }
                        else
                        {
                            unit->testSummaryResultsLog->Clear();
                            unit->testSummaryResultsLogRemaining = unit->testSummaryResultsLogSize;
                        }
                    }
                    if (logDetail)
                    {
                        if (actionFlags & GUI_LOG_ACTION_RETAIN_LOG_HEADER)
                        {
                            unit->testDetailedResultsLogRemaining =
                                unit->testDetailedResultsLogSize - headerLine->Length;
                            unit->testFlags |=
                                (QCOM_UNIT_TEST_RESULTS_PRESENT | QCOM_UNIT_TEST_RESULTS_UNSAVED);
                            QCOM_GeneralInfo->testFlags |=
                                (QCOM_GENERAL_TEST_RESULTS_PRESENT | QCOM_GENERAL_TEST_RESULTS_UNSAVED);
                            actionFlags |= (GUI_LOG_ACTION_REPLACE_DISPLAY | GUI_LOG_ACTION_APPEND_NEWLINE);
                            GUI_StringToBuilder(
                                headerLine,
                                unit->testDetailedResultsLog);
                        }
                        else
                        {
                            unit->testDetailedResultsLog->Clear();
                            unit->testDetailedResultsLogRemaining = unit->testDetailedResultsLogSize;
                        }
                    }
                    unit->testFlags &=
                        ~(QCOM_UNIT_TEST_RESULTS_PRESENT | QCOM_UNIT_TEST_RESULTS_UNSAVED);
                    delete headerLine;
                }                       // end of if (actionFlags & GUI_LOG_ACTION_CLEAR_LOG)
                if (actionFlags & (GUI_LOG_ACTION_CLEAR_DISPLAY | GUI_LOG_ACTION_REPLACE_DISPLAY))
                {
                    //--------------------------------------------------------
                    // Clear the display
                    //--------------------------------------------------------
                    testingSummaryResultsBoxArray[unitNumber]->Clear();
                    testingDetailedResultsBoxArray[unitNumber]->Clear();
                    //--------------------------------------------------------
                    // Force the Garbage Collector to reclaim unreferenced
                    // memory created by managed code
                    //--------------------------------------------------------
                    GC::Collect();
                    Thread::Sleep(100);
                    //--------------------------------------------------------
                    // Then update the display with the specified display line,
                    // if required
                    //--------------------------------------------------------
                    if (actionFlags & GUI_LOG_ACTION_REPLACE_DISPLAY)
                    {
                        if (actionFlags & GUI_LOG_ACTION_APPEND_NEWLINE)
                        {
                            testResultsLine = String::Concat(testResultsLine, QCOM_STRING_LF);
                        }
                        if (testResultsLine->Length)
                        {
                            if (logSummary)
                                testingSummaryResultsBoxArray[unitNumber]->SelectedText =
                                    testResultsLine;
                            if (logDetail)
                                testingDetailedResultsBoxArray[unitNumber]->SelectedText =
                                    testResultsLine;
                        }
                    }
                }
                for (DWORD moduleNumber = 0; moduleNumber < QCOM_CurrentNumberOfUnits; moduleNumber++)
                {
                    if (QCOM_UnitNumberValid(moduleNumber))
                    {
                        if (QCOM_UnitInfoArray[moduleNumber]->testFlags & QCOM_UNIT_TEST_RESULTS_PRESENT)
                            someHaveData = GUI_YES;
                    }
                }
                if (someHaveData)
                    QCOM_GeneralInfo->testFlags |= QCOM_GENERAL_TEST_RESULTS_PRESENT;
                else
                    QCOM_GeneralInfo->testFlags &= ~QCOM_GENERAL_TEST_RESULTS_PRESENT;
                unit->testFlags |= QCOM_UNIT_TEST_RESULTS_STATE_CHANGED;
            }                           // end of if (actionFlags & (...))
            else
            {
                //------------------------------------------------------------
                // Process the line normally by updating both the log and the
                // display
                //------------------------------------------------------------
                if (unit->testFlags & QCOM_UNIT_TEST_AVAILABLE)
                {
                    if (!QCOM_TestResultsPresent(unit))
                        unit->testFlags |= QCOM_UNIT_TEST_RESULTS_STATE_CHANGED;
                    //--------------------------------------------------------
                    // Pre-pend the test log with the date and time stamp
                    //
                    // Note:    The GUI_LOG_ACTION_PREVENT_TIME_STAMP flag has
                    //          precedence over the other time stamp flags
                    //--------------------------------------------------------
                    if (((actionFlags & GUI_LOG_ACTION_PREPEND_TIME_STAMP) ||
                         (unit->testFlags & QCOM_UNIT_TEST_RESULTS_TIME_STAMP)) &&
                         !(actionFlags & GUI_LOG_ACTION_PREVENT_TIME_STAMP))
                    {
                        DateTime dateTime = DateTime::Now;
                        testResultsLine = String::Concat(
                            String::Format(
                                "{0:D2} {1} {2:D4} {3:D2}:{4:D2}:{5:D2} : ",
                                dateTime.Day,
                                QCOM_MonthStringArray[dateTime.Month],
                                dateTime.Year,
                                dateTime.Hour,
                                dateTime.Minute,
                                dateTime.Second),
                            testResultsLine);
                    }
                    //--------------------------------------------------------
                    // Mark the line if it is a comment
                    //--------------------------------------------------------
                    if (actionFlags & GUI_LOG_ACTION_COMMENT)
                    {
                        actionFlags |= GUI_LOG_ACTION_COMMENT_TEXT;
                        testResultsLine = testResultsLine->Insert(0, "# ");
                        if (testResultsLine->Contains(QCOM_STRING_LF))
                        {
                            testResultsLine = testResultsLine->Replace(QCOM_STRING_LF,
                                ((actionFlags & GUI_LOG_ACTION_PREPEND_TIME_STAMP) ?
                                    _T("\n#                      : ") : _T("\n# ")));
                        }
                    }
                    //--------------------------------------------------------
                    // Append the test log with a CR/LF pair
                    //--------------------------------------------------------
                    if (actionFlags & GUI_LOG_ACTION_APPEND_NEWLINE)
                    {
                        testResultsLine = String::Concat(testResultsLine, QCOM_STRING_CRLF);
                    }
                    //--------------------------------------------------------
                    // Append the test log with the updated line
                    //--------------------------------------------------------
                    if (logSummary)
                    {
                        unit->testSummaryResultsLog->Append(testResultsLine);
                        unit->testSummaryResultsLogRemaining =
                            unit->testSummaryResultsLogSize - unit->testSummaryResultsLog->Length;
                    }
                    if (logDetail)
                    {
                        unit->testDetailedResultsLog->Append(testResultsLine);
                        unit->testDetailedResultsLogRemaining =
                            unit->testDetailedResultsLogSize - unit->testDetailedResultsLog->Length;
                    }
                    unit->testFlags |=
                        (QCOM_UNIT_TEST_RESULTS_PRESENT | QCOM_UNIT_TEST_RESULTS_UNSAVED);
                    QCOM_GeneralInfo->testFlags |=
                        (QCOM_GENERAL_TEST_RESULTS_PRESENT | QCOM_GENERAL_TEST_RESULTS_UNSAVED);
                    //--------------------------------------------------------
                    // Post-test the remaining test log size for sufficient
                    // data space for at least one line
                    //--------------------------------------------------------
                    if ((unit->testSummaryResultsLogRemaining < QCOM_MAXIMUM_TEST_LOG_LINE_SIZE) ||
                        (unit->testDetailedResultsLogRemaining < QCOM_MAXIMUM_TEST_LOG_LINE_SIZE))
                    {
                        mustEmptyTestLog = GUI_YES;
                        testFlags = unit->testFlags;
                        if (testFlags & QCOM_UNIT_TEST_RESULTS_AUTO_SAVE)
                        {
                            chooseToSave = GUI_YES;
                        }
                        else
                        {
                            chooseToSave = QCOM_PromptYesNoModal(
                                "Test Results Log Full",
                                "Save", "Delete",
                                "The test results log for module {0} has reached its capacity\n"
                                "Save the results to a file or Delete the results?",
                                unit->moduleSerialNumber);
                        }
                        if (chooseToSave)
                        {
                            //------------------------------------------------
                            // Protect the access to the results file by
                            // acquiring a spin lock
                            //------------------------------------------------
                            bool spinLockAcquired = GUI_NO;
                            try
                            {
                                QCOM_TestSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                                QCOM_TransferTestResultsToFile(unit);
                            }
                            finally
                            {
                                if (spinLockAcquired == GUI_YES)
                                    QCOM_TestSpinLockArray[unitNumber]->Exit();
                            }
                        }
                        unit->testSummaryResultsLog->Clear();
                        unit->testSummaryResultsLogRemaining = unit->testSummaryResultsLogSize;
                        unit->testDetailedResultsLog->Clear();
                        unit->testDetailedResultsLogRemaining = unit->testDetailedResultsLogSize;
                        unit->testFlags &=
                            ~(QCOM_UNIT_TEST_RESULTS_PRESENT | QCOM_UNIT_TEST_RESULTS_UNSAVED);
                    }                   // end of if ((unit->testSummaryResultsLogRemaining < QCOM_MAXIMUM_TEST_LOG_LINE_SIZE) || ...)
                }                       // end of if (unit->testFlags & QCOM_UNIT_TEST_AVAILABLE)
                //------------------------------------------------------------
                // Now update the displays
                //------------------------------------------------------------
                if (QCOM_TestResultsDisplayed(unit))
                {
                    if (mustEmptyTestLog)
                    {
                        QCOM_StampTestResultsLogTruncated(unit, chooseToSave);
                    }
                    else
                    {
                        if (!(actionFlags & GUI_LOG_ACTION_FILE_ONLY))
                        {
                            String ^testResultsDisplayLine = testResultsLine->Replace(
                                QCOM_STRING_CRLF, QCOM_STRING_LF);
                            if (logSummary)
                            {
                                if (actionFlags & GUI_LOG_ACTION_COLOR_TEXT)
                                {
                                    testingSummaryResultsBoxArray[unitNumber]->SelectionFont = gcnew
                                        Drawing::Font(
                                            this->Font,
                                            FontStyle::Bold);
                                    if (actionFlags & GUI_LOG_ACTION_BOLD_TEXT)
                                    {
                                        testingSummaryResultsBoxArray[unitNumber]->SelectionColor = Color::Green;
                                    }
                                    if (actionFlags & GUI_LOG_ACTION_COMMENT_TEXT)
                                    {
                                        testingSummaryResultsBoxArray[unitNumber]->SelectionColor = Color::Brown;
                                    }
                                    if (actionFlags & GUI_LOG_ACTION_CAUTION_TEXT)
                                    {
                                        testingSummaryResultsBoxArray[unitNumber]->SelectionColor = Color::Purple;
                                    }
                                    if (actionFlags & GUI_LOG_ACTION_WARNING_TEXT)
                                    {
                                        testingSummaryResultsBoxArray[unitNumber]->SelectionColor = Color::Orange;
                                    }
                                    if (actionFlags & GUI_LOG_ACTION_FAILURE_TEXT)
                                    {
                                        testingSummaryResultsBoxArray[unitNumber]->SelectionColor = Color::Red;
                                    }
                                    if (actionFlags & GUI_LOG_ACTION_SUCCESS_TEXT)
                                    {
                                        testingSummaryResultsBoxArray[unitNumber]->SelectionColor = Color::Blue;
                                    }
                                    testingSummaryResultsBoxArray[unitNumber]->SelectedText = testResultsDisplayLine;
                                }       // end of if (actionFlags & GUI_LOG_ACTION_COLOR_TEXT)
                                else
                                {
//                                    testingSummaryResultsBoxArray[unitNumber]->SelectionFont = gcnew
//                                        Drawing::Font(
//                                            this->Font,
//                                            FontStyle::Regular);
                                    testingSummaryResultsBoxArray[unitNumber]->SelectionFont =
                                        testingSummaryResultsBoxArray[unitNumber]->Font;
                                    testingSummaryResultsBoxArray[unitNumber]->SelectionColor = Color::Black;
                                    testingSummaryResultsBoxArray[unitNumber]->SelectedText = testResultsDisplayLine;
                                }
                                if (testResultsDisplayLine->EndsWith(QCOM_STRING_LF))
                                    testingSummaryResultsBoxArray[unitNumber]->ScrollToCaret();
                            }           // end of if (logSummary)
                            if (logDetail)
                            {
                                if (actionFlags & GUI_LOG_ACTION_COLOR_TEXT)
                                {
                                    testingDetailedResultsBoxArray[unitNumber]->SelectionFont = gcnew
                                        Drawing::Font(
                                            this->Font,
                                            FontStyle::Bold);
                                    if (actionFlags & GUI_LOG_ACTION_BOLD_TEXT)
                                    {
                                        testingDetailedResultsBoxArray[unitNumber]->SelectionColor = Color::Green;
                                    }
                                    if (actionFlags & GUI_LOG_ACTION_COMMENT_TEXT)
                                    {
                                        testingDetailedResultsBoxArray[unitNumber]->SelectionColor = Color::Brown;
                                    }
                                    if (actionFlags & GUI_LOG_ACTION_CAUTION_TEXT)
                                    {
                                        testingDetailedResultsBoxArray[unitNumber]->SelectionColor = Color::Purple;
                                    }
                                    if (actionFlags & GUI_LOG_ACTION_WARNING_TEXT)
                                    {
                                        testingDetailedResultsBoxArray[unitNumber]->SelectionColor = Color::Orange;
                                    }
                                    if (actionFlags & GUI_LOG_ACTION_FAILURE_TEXT)
                                    {
                                        testingDetailedResultsBoxArray[unitNumber]->SelectionColor = Color::Red;
                                    }
                                    if (actionFlags & GUI_LOG_ACTION_SUCCESS_TEXT)
                                    {
                                        testingDetailedResultsBoxArray[unitNumber]->SelectionColor = Color::Blue;
                                    }
                                    testingDetailedResultsBoxArray[unitNumber]->SelectedText = testResultsDisplayLine;
                                }       // end of if (actionFlags & GUI_LOG_ACTION_COLOR_TEXT)
                                else
                                {
//                                    testingDetailedResultsBoxArray[unitNumber]->SelectionFont = gcnew
//                                        Drawing::Font(
//                                            this->Font,
//                                            FontStyle::Regular);
                                    testingDetailedResultsBoxArray[unitNumber]->SelectionFont =
                                        testingDetailedResultsBoxArray[unitNumber]->Font;
                                    testingDetailedResultsBoxArray[unitNumber]->SelectionColor = Color::Black;
                                    testingDetailedResultsBoxArray[unitNumber]->SelectedText = testResultsDisplayLine;
                                }
                                if (testResultsDisplayLine->EndsWith(QCOM_STRING_LF))
                                    testingDetailedResultsBoxArray[unitNumber]->ScrollToCaret();
                            }           // end of if (logDetail)
                            delete testResultsDisplayLine;
                        }               // end of if (!(actionFlags & GUI_LOG_ACTION_FILE_ONLY))
                    }                   // end of else of if (mustEmptyTestLog)
                }                       // end of if (QCOM_TestResultsDisplayed(unit))
                if (QCOM_ReadyToMarkTestingTime[unitNumber] && (unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                {
                    Thread ^markTestTimeThread =
                        gcnew Thread(gcnew ParameterizedThreadStart(this, &QCOM_GUIClass::QCOM_MarkTestingTime));
                    markTestTimeThread->Start(unitNumber);
                }
            }                           // end of else of if (actionFlags & (...))
            //----------------------------------------------------------------
            // Update affected properties
            //----------------------------------------------------------------
            if (unit->testFlags & QCOM_UNIT_TEST_RESULTS_STATE_CHANGED)
            {
                QCOM_TestReflectDataPresence(unit);
                unit->testFlags &= ~QCOM_UNIT_TEST_RESULTS_STATE_CHANGED;
            }
            //----------------------------------------------------------------
            // Update the progress bar
            //----------------------------------------------------------------
            QCOM_TestUnitUpdateProgressBar(unit);
        }                               // end of if (unit->testFlags & QCOM_UNIT_TEST_AVAILABLE)
        testingStateLabelArray[unitNumber]->Update();
        testingPercentCompleteLabelArray[unitNumber]->Update();
        testingPercentCompleteProgressArray[unitNumber]->Update();
        delete testResultsLine;
        unit->testResultsLine = String::Empty;
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_TestUnitUpdateResultsLog()
//----------------------------------------------------------------------------
// QCOM_TestUnitX2Checked
//
// Handles the check of the X2 Test box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitX2Checked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitX2Checked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_TEST_ZERO_FLAG,
            QCOM_UNIT_TEST_X2_TEST);
        RecordBasicEvent(
            "X2 Test {0} for module {1}",
            ((unit->testFlags & QCOM_UNIT_TEST_X2_TEST) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitX2Checked()
//----------------------------------------------------------------------------
// QCOM_TestUnitX3Checked
//
// Handles the check of the X3 Test box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitX3Checked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitX3Checked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_TEST_ZERO_FLAG,
            QCOM_UNIT_TEST_X3_TEST);
        RecordBasicEvent(
            "X3 Test {0} for module {1}",
            ((unit->testFlags & QCOM_UNIT_TEST_X3_TEST) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitX3Checked()
//----------------------------------------------------------------------------
// QCOM_TestUnitX4Checked
//
// Handles the check of the X4 Test box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitX4Checked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitX4Checked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_TEST_ZERO_FLAG,
            QCOM_UNIT_TEST_X4_TEST);
        RecordBasicEvent(
            "X4 Test {0} for module {1}",
            ((unit->testFlags & QCOM_UNIT_TEST_X4_TEST) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitX4Checked()
//----------------------------------------------------------------------------
// QCOM_TestUnitXDCommChecked
//
// Handles the check of the Transducer Communication Test box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitXDCommChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitXDCommChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_TEST_ZERO_FLAG,
            QCOM_UNIT_TEST_XD_COMM_TEST);
        RecordBasicEvent(
            "Transducer Communications Test {0} for module {1}",
            ((unit->testFlags & QCOM_UNIT_TEST_XD_COMM_TEST) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitXDCommChecked()
//----------------------------------------------------------------------------
// QCOM_TestUnitXDIntegrityChecked
//
// Handles the check of the Transducer Integrity Test box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitXDIntegrityChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitXDIntegrityChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_TEST_ZERO_FLAG,
            QCOM_UNIT_TEST_XD_INTEGRITY_TEST);
        RecordBasicEvent(
            "Transducer Integrity Test {0} for module {1}",
            ((unit->testFlags & QCOM_UNIT_TEST_XD_INTEGRITY_TEST) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitXDIntegrityChecked()
//----------------------------------------------------------------------------
// QCOM_TestUnitXDMemoryChecked
//
// Handles the check of the Transducer Memory Test box
//
// Called by:   QCOM_ConstructUnitTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_TestUnitXDMemoryChecked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <CheckBox ^> (sender))->Tag;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_TestUnitXDMemoryChecked");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberValid(unitNumber))
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
            unit,
            QCOM_GENERAL_TEST_ZERO_FLAG,
            QCOM_UNIT_TEST_XD_MEMORY_TEST);
        RecordBasicEvent(
            "Transducer Memory Test {0} for module {1}",
            ((unit->testFlags & QCOM_UNIT_TEST_XD_MEMORY_TEST) ? "checked" : "un-checked"),
            unit->moduleSerialNumber);
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with invalid unit number {1:D}",
            functionName, unitNumber);
    }
}                                       // end of QCOM_TestUnitXDMemoryChecked()
//----------------------------------------------------------------------------
// QCOM_ToggleGeneralTestFlagThenSetUnitFlags
//
// Toggles the specified general test flag, then sets the corresponding test
// flag for all valid units
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToggleGeneralTestFlagThenSetUnitFlags(
    DWORD           generalTestFlag,
    DWORD           unitTestFlag)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_ToggleGeneralTestFlagThenSetUnitFlags");
    //------------------------------------------------------------------------
    if (generalTestFlag)
    {
        if (QCOM_GeneralInfo->testFlags & generalTestFlag)
            QCOM_GeneralInfo->testFlags &= ~generalTestFlag;
        else
            QCOM_GeneralInfo->testFlags |= generalTestFlag;
        if (unitTestFlag)
        {
            for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
            {
                if (QCOM_UnitNumberValid(unitNumber))
                {
                    unit = QCOM_UnitInfoArray[unitNumber];
                    if (QCOM_GeneralInfo->testFlags & generalTestFlag)
                        unit->testFlags |= unitTestFlag;
                    else
                        unit->testFlags &= ~unitTestFlag;
                }
                else
                {
                    QCOM_RecordAndModalErrorEvent(
                        "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                        functionName, unitNumber, QCOM_CurrentNumberOfUnits);
                }
            }
        }
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    }
}                                       // end of QCOM_ToggleGeneralTestFlagThenSetUnitFlags()
//----------------------------------------------------------------------------
// QCOM_ToggleUnitTestFlagThenSetGeneralFlag
//
// Toggles the specified unit flag, then sets the corresponding general flag
// as needed
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToggleUnitTestFlagThenSetGeneralFlag(
    UnitInfo        ^unit,
    DWORD           generalTestFlag,
    DWORD           unitTestFlag)
{
    bool            allUnitsSet = GUI_YES;
    String          ^functionName = _T("QCOM_ToggleUnitTestFlagThenSetGeneralFlag");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        if (unitTestFlag)
        {
            if (unit->testFlags & unitTestFlag)
            {
                unit->testFlags &= ~unitTestFlag;
                if (generalTestFlag)
                {
                    if (QCOM_GeneralInfo->testFlags & generalTestFlag)
                        QCOM_GeneralInfo->testFlags &= ~generalTestFlag;
                }
            }
            else
            {
                unit->testFlags |= unitTestFlag;
                if (generalTestFlag)
                {
                    if (!(QCOM_GeneralInfo->testFlags & generalTestFlag))
                    {
                        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
                        {
                            if (QCOM_UnitNumberValid(unitNumber))
                            {
                                if (!(QCOM_UnitInfoArray[unitNumber]->testFlags & unitTestFlag))
                                    allUnitsSet = GUI_NO;
                            }
                            else
                            {
                                QCOM_RecordAndModalErrorEvent(
                                    "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                                    functionName, unitNumber, QCOM_CurrentNumberOfUnits);
                            }
                        }
                        if (allUnitsSet)
                            QCOM_GeneralInfo->testFlags |= generalTestFlag;
                    }
                }
            }
            QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_ToggleUnitTestFlagThenSetGeneralFlag()
//----------------------------------------------------------------------------
// QCOM_TransferTestResultsToFile
//
// Saves the test results of the specified unit to a file, prompting the user as
// needed
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//
// Note:    This method should be protected by a spin lock
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_TransferTestResultsToFile(
    UnitInfo        ^unit)
{
    bool            promptResult = GUI_CANCEL;
    DWORD           status;
    String          ^functionName = _T("QCOM_TransferTestResultsToFile");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    if (unit)
    {
        RecordVerboseEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (QCOM_TRFileKnown(unit))
        {
//            if (unit->testFlags & QCOM_UNIT_TEST_RESULTS_AUTO_SAVE)
//            {
                status = QCOM_TestUnitSaveResultsLog(unit, nullptr);
                if (status == QCOM_SUCCESS)
                {
                    promptResult = GUI_ACCEPT;
                    unit->testFlags &= ~QCOM_UNIT_TEST_RESULTS_UNSAVED;
                    if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_EXITING) &&
                        !(unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING))
                    {
                        QCOM_RecordAndModalEventByFlags(
                            QCOM_EventLogVerboseEnabled,
                            QCOM_DetailedMessagesEnabled,
                            String::Format("{0}({1:D})", functionName, unit->unitNumber),
                            "Test results for transducer {0} saved to file\n{1}",
                            unit->transducerSerialNumber,
                            unit->testResultsFilePath);
                    }
                }
                else
                {
                    GUI_DisplayUnitErrorWithStatus(
                        "Transfer Test Results To File",
                        "QCOM_TestUnitSaveResultsLog",
                        unit,
                        status);
                }
//            }
//            else
//            {
//                promptResult = QCOM_PromptAndSaveTestResultsFile(unit);
//            }
        }
        else
        {
//Modal("Test results file not specified");
            promptResult = QCOM_PromptAndSaveTestResultsFile(unit);
        }
    }
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
    RecordVerboseEvent("{0} concluded, returning {1}",
        functionName, (promptResult ? "Save" : "Cancel"));
    return promptResult;
}                                       // end of QCOM_TransferTestResultsToFile()
//----------------------------------------------------------------------------
// QCOM_ValidateTestLoopCountValue
//
// Handles changes of the test loop count field; ensures that the
// integer value of the field falls within the appropriate limits
//
// Called by:   QCOM_ConstructGeneralTestingGroupBox
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ValidateTestLoopCountValue(
    Object          ^sender,
    CancelEventArgs ^evt)
{
    bool            revertToOriginalValue = GUI_NO;
    DWORD           newCount;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_ValidateTestLoopCountValue");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (!(QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING))
    {
        if (StringSet(testingLoopCountBox->Text))
        {
            bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
                testingLoopCountBox->Text,
                &newCount);
            if (isCorrectFormat)
            {
                if ((newCount < GUI_MINIMUM_TEST_LOOP_COUNT) ||
                    (newCount > GUI_MAXIMUM_TEST_LOOP_COUNT))
                {
                    QCOM_PromptOKModal(
                        "Invalid Interval Value",
                        "Valid values are {0:D} through {1:D}, inclusive",
                        GUI_MINIMUM_TEST_LOOP_COUNT,
                        GUI_MAXIMUM_TEST_LOOP_COUNT);
                    RecordErrorEvent(
                        "    Attempted setting loop count value to '{0:D}'",
                        newCount);
                    revertToOriginalValue = GUI_YES;
                }
                else
                {
                    if (newCount != QCOM_TestLoopCount)
                    {
                        RecordBasicEvent(
                            "    The Testing Loop Count changed from {0:D} to {1:D}",
                            QCOM_TestLoopCount,
                            newCount);
                        QCOM_TestLoopCount = newCount;
                        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
                        {
                            if (QCOM_UnitNumberValid(unitNumber))
                            {
                                unit = QCOM_UnitInfoArray[unitNumber];
                                if (!(unit->testFlags & QCOM_UNIT_TEST_LOOP_FOREVER))
                                {
                                    testingPassCountLabelArray[unitNumber]->Tag = (0x100 | unitNumber);
                                    testingPassCountLabelArray[unitNumber]->Text = String::Format(
                                        "Loop 1 / {0:D}", QCOM_TestLoopCount);
                                }
                            }
                        }
                        revertToOriginalValue = GUI_YES;
                    }
                    evt->Cancel = GUI_NO;
                    RecordBasicEvent("{0} concluded: Accept {1:D}",
                        functionName, QCOM_TestLoopCount);
                    return;
                }
            }                           // end of if (isCorrectFormat)
            else
            {
                QCOM_PromptOKModal(
                    "Invalid Characters",
                    "The entry contains invalid characters;\n"
                    "enter only decimal digits");
                RecordErrorEvent(
                    "    Attempted setting loop count value to '{0}'",
                    testingLoopCountBox->Text);
                revertToOriginalValue = GUI_YES;
            }
        }                               // end of if (StringSet(testingLoopCountBox->Text))
        else
        {
            testingLoopCountBox->Text = String::Concat(GUI_DEFAULT_TEST_LOOP_COUNT);
        }
        if (revertToOriginalValue)
        {
            testingLoopCountBox->Text = String::Concat(QCOM_TestLoopCount);
        }
    }                                   // end of if (!(QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING))
    evt->Cancel = GUI_YES;
    RecordBasicEvent("{0} concluded: Cancel", functionName);
}                                       // end of QCOM_ValidateTestLoopCountValue()
//----------------------------------------------------------------------------
#endif      // TESTING_CPP
//============================================================================
// End of Testing.cpp
//============================================================================
