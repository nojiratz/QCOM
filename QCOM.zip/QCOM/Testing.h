//============================================================================
// Testing.h
//
// Header for Testing.cpp
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#pragma once
#ifndef     TESTING_H
#define     TESTING_H
//----------------------------------------------------------------------------
// Include appropriate headers
//----------------------------------------------------------------------------
#include    "GUI.h"
//----------------------------------------------------------------------------
// Test utility macros
//----------------------------------------------------------------------------
#define     QCOM_CheckActiveTesting(U,K)                                                \
                {                                                                       \
                    if (U)                                                              \
                    {                                                                   \
                        if ((U)->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING)          \
                            (K) = GUI_YES;                                              \
                        else                                                            \
                            (K) = GUI_NO;                                               \
                    }                                                                   \
                    while (QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED)       \
                    {                                                                   \
                        Thread::Sleep(10);                                              \
                    }                                                                   \
                }
//----------------------------------------------------------------------------
// Test results logging macros
//----------------------------------------------------------------------------
#define     LogDetailedEntry(U,F,...)       QCOM_AppendTestResults((U), (GUI_LOG_ACTION_DETAILED_LOG), (F), __VA_ARGS__)
#define     LogDetailedStatus(U,S,E)        QCOM_AppendTestResultsError((U), (S), (E), (GUI_LOG_ACTION_DETAILED_LOG | GUI_LOG_ACTION_APPEND_NEWLINE))
#define     LogDetailedDot(U)               QCOM_AppendTestResults((U), (GUI_LOG_ACTION_DETAILED_LOG), QCOM_STRING_DOT)
#define     LogDetailedLine(U,F,...)        QCOM_AppendTestResults((U), (GUI_LOG_ACTION_DETAILED_LOG | GUI_LOG_ACTION_APPEND_NEWLINE), (F), __VA_ARGS__)
#define     LogDetailedFailure(U,F,...)     QCOM_AppendTestResults((U), (GUI_LOG_ACTION_DETAILED_LOG | GUI_LOG_ACTION_FAILURE_TEXT), (F), __VA_ARGS__)
#define     LogDetailedFailureLine(U,F,...) QCOM_AppendTestResults((U), (GUI_LOG_ACTION_DETAILED_LOG | GUI_LOG_ACTION_FAILURE_TEXT | GUI_LOG_ACTION_APPEND_NEWLINE), (F), __VA_ARGS__)
#define     LogDetailedSuccessLine(U,F,...) QCOM_AppendTestResults((U), (GUI_LOG_ACTION_DETAILED_LOG | GUI_LOG_ACTION_SUCCESS_TEXT | GUI_LOG_ACTION_APPEND_NEWLINE), (F), __VA_ARGS__)
#define     LogDetailedWarningLine(U,F,...) QCOM_AppendTestResults((U), (GUI_LOG_ACTION_DETAILED_LOG | GUI_LOG_ACTION_WARNING_TEXT | GUI_LOG_ACTION_APPEND_NEWLINE), (F), __VA_ARGS__)
#define     LogBothFailureLine(U,F,...)     QCOM_AppendTestResults((U), (GUI_LOG_ACTION_PREVENT_TIME_STAMP | GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY | GUI_LOG_ACTION_FAILURE_TEXT | GUI_LOG_ACTION_APPEND_NEWLINE), (F), __VA_ARGS__)
#define     LogBothSuccessLine(U,F,...)     QCOM_AppendTestResults((U), (GUI_LOG_ACTION_PREVENT_TIME_STAMP | GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY | GUI_LOG_ACTION_SUCCESS_TEXT | GUI_LOG_ACTION_APPEND_NEWLINE), (F), __VA_ARGS__)
#define     LogBothWarningLine(U,F,...)     QCOM_AppendTestResults((U), (GUI_LOG_ACTION_PREVENT_TIME_STAMP | GUI_LOG_ACTION_BOTH_DETAILED_AND_SUMMARY | GUI_LOG_ACTION_WARNING_TEXT | GUI_LOG_ACTION_APPEND_NEWLINE), (F), __VA_ARGS__)
#define     LogSummaryEntry(U,F,...)        QCOM_AppendTestResults((U), (GUI_LOG_ACTION_SUMMARY_LOG), (F), __VA_ARGS__)
#define     LogSummaryLine(U,F,...)         QCOM_AppendTestResults((U), (GUI_LOG_ACTION_SUMMARY_LOG | GUI_LOG_ACTION_APPEND_NEWLINE), (F), __VA_ARGS__)
#define     LogSummaryFailure(U,F,...)      QCOM_AppendTestResults((U), (GUI_LOG_ACTION_SUMMARY_LOG | GUI_LOG_ACTION_FAILURE_TEXT), (F), __VA_ARGS__)
#define     LogSummaryFailureLine(U,F,...)  QCOM_AppendTestResults((U), (GUI_LOG_ACTION_SUMMARY_LOG | GUI_LOG_ACTION_FAILURE_TEXT | GUI_LOG_ACTION_APPEND_NEWLINE), (F), __VA_ARGS__)
#define     LogSummarySuccessLine(U,F,...)  QCOM_AppendTestResults((U), (GUI_LOG_ACTION_SUMMARY_LOG | GUI_LOG_ACTION_SUCCESS_TEXT | GUI_LOG_ACTION_APPEND_NEWLINE), (F), __VA_ARGS__)
#define     LogSummaryWarningLine(U,F,...)  QCOM_AppendTestResults((U), (GUI_LOG_ACTION_SUMMARY_LOG | GUI_LOG_ACTION_WARNING_TEXT | GUI_LOG_ACTION_APPEND_NEWLINE), (F), __VA_ARGS__)
//----------------------------------------------------------------------------
// The following lines are only seen by Testing.cpp
//----------------------------------------------------------------------------
#ifdef      TESTING_CPP
//----------------------------------------------------------------------------
// End of the lines that are only seen by Testing.cpp
//----------------------------------------------------------------------------
#endif      // TESTING_CPP
#endif      // TESTING_H
//============================================================================
// End of Testing.h
//============================================================================
