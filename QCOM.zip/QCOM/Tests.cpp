//============================================================================
// Tests.cpp
//
// The test methods called by Testing.cpp for unit testing
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     TESTS_CPP
#define     TESTS_CPP
#include    "Tests.h"
//----------------------------------------------------------------------------
// QCOM_TestSuiteFirmware
//
// Runs the Firmware Test suite
//
// Returns: GUI_YES     All the tests passed
//          GUI_NO      At least one test failed
//
// Called by:   QCOM_InitiateUnitTests
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_TestSuiteFirmware(
    UnitInfo        ^unit)
{
    bool            keepTesting;
    bool            testPassed;         // unit section tests
    bool            testsPassed = GUI_YES;
    double          originalDataRate = 0.0;
    BYTE            deviceInfoBuffer[sizeof(UnitDeviceInfoDef)];
    BYTE            firmwareID[4];
    BYTE            FWVHigh = 0;
    BYTE            FWVLow = 0;
    WORD            errorCode;
    DWORD           status;
    DWORD           testsCompleted = 0;
    DWORD           waited = 0;
    UnitDeviceInfoDef
                    *deviceInfo = (UnitDeviceInfoDef *) deviceInfoBuffer;
    String          ^terminationSource;
    String          ^functionName = _T("QCOM_TestSuiteFirmware");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        //--------------------------------------------------------------------
        // Announce the start of the test
        //--------------------------------------------------------------------
        LogDetailedLine(unit, "Firmware Test started");
        LogSummaryEntry(unit, "Firmware Test...");
        if (QCOM_UnitOpen(unit))
        {
            QD_GetI2CDataRate(unit->unitHandle, &originalDataRate);
            terminationSource =
                (unit->testFlags & QCOM_UNIT_TEST_STOP_ON_ERRORS) ?
                    _T("error") : _T("user");
            unit->flags |= QCOM_UNIT_FIRMWARE_UPDATING;
            //----------------------------------------------------------------
            // Bootloader Mode Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Bootloader Mode Test Begin");
                testPassed = GUI_YES;
                if (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE)
                {
                    LogDetailedLine(
                        unit,
                        "        Firmware is already in Bootloader Mode, "
                        "so a reset will be attempted before the test could begin");
                    status = QD_SetFirmwareMode(
                        unit->unitHandle,
                        QD_SET_APPLICATION_MODE);
                    if (status)
                    {
                        testPassed = GUI_NO;
                        LogDetailedStatus(
                            unit,
                            "        Attempt to exit Bootloader Mode ",
                            status);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    Thread::Sleep(QD_MINIMUM_BOOT_LOADER_MODE_WAIT_TIME);
                    QCOM_CloseUnit(unit);
                    status = QCOM_OpenUnit(unit);
                    QCOM_GetModuleInfo(unit);
                    if (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE)
                    {
                        testPassed = GUI_NO;
                        LogDetailedFailureLine(
                            unit,
                            "        Firmware remains in Bootloader Mode, "
                            "so the rest of the test will be skipped");
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                }
                if (testPassed && !(unit->flags & QCOM_UNIT_BOOT_LOADER_MODE))
                {
                    LogDetailedEntry(
                        unit,
                        "        Switch to Bootloader mode ");
                    status = QD_SetFirmwareMode(
                        unit->unitHandle,
                        QD_SET_BOOT_LOADER_MODE);
                    if (status == QD_SUCCESS)
                    {
                        Thread::Sleep(QD_MINIMUM_BOOT_LOADER_MODE_WAIT_TIME);
                        LogDetailedLine(unit, "succeeded");
                        unit->testsCompleted++;
                        testsCompleted++;
                        LogDetailedEntry(unit, "        Closing and re-opening the module ");
                        QCOM_CloseUnit(unit);
                        status = QCOM_OpenUnit(unit);
                        if ((status == QCOM_SUCCESS) && HandleIsValid(unit->unitHandle))
                        {
                            LogDetailedLine(unit, "succeeded");
                            QCOM_GetModuleInfo(unit);
                            if (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE)
                            {
                                LogDetailedEntry(unit, "        Retrieving device info in Bootloader mode ");
                                status = QD_GetFirmwareDeviceInfo(
                                    unit->unitHandle,
                                    (LPBYTE) deviceInfo);
                                if (status == QD_SUCCESS)
                                {
                                    LogDetailedLine(unit, "succeeded");
                                    if (deviceInfo->deviceCode != QD_FIRMWARE_DEVICE_CODE_C8051F320)
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedFailureLine(
                                            unit,
                                            "        QD_GetFirmwareDeviceInfo returned "
                                            "incorrect device code of 0x{0:X2}",
                                            deviceInfo->deviceCode);
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                    if (deviceInfo->signature != QD_FIRMWARE_SIGNATURE)
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedFailureLine(
                                            unit,
                                            "        QD_GetFirmwareDeviceInfo returned "
                                            "incorrect signature 0x{0:X4}",
                                            deviceInfo->signature);
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                    //----------------------------------------
                                    // Save the major and minor versions for
                                    // the Firmware ID Test
                                    //----------------------------------------
                                    FWVHigh = deviceInfo->applicationFWVersionHigh;
                                    FWVLow = deviceInfo->applicationFWVersionLow;
                                    unit->testsCompleted++;
                                    testsCompleted++;
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                            }
                            else
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "        Firmware should be in Bootloader Mode, but is not");
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                        }
                        else
                        {
                            testPassed = GUI_NO;
                            LogDetailedStatus(unit, String::Empty, status);
                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                        }
                    }
                    else
                    {
                        testPassed = GUI_NO;
                        LogDetailedStatus(unit, String::Empty, status);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                }
                LogDetailedEntry(
                    unit,
                    "    Bootloader Mode Test End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Application Mode Test
            //----------------------------------------------------------------
//            QCOM_CheckActiveTesting(unit, keepTesting); // must not abort while in BL Mode
//            if (keepTesting)
            {
                if (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE)
                {
                    LogDetailedLine(unit, "    Application Mode Test Begin");
                    testPassed = GUI_YES;
                    LogDetailedEntry(
                        unit,
                        "        Switch from Bootloader mode back to Application mode ");
                    status = QD_SetFirmwareMode(
                        unit->unitHandle,
                        QD_SET_APPLICATION_MODE);
                    if (status == QD_SUCCESS)
                    {
                        Thread::Sleep(QD_MINIMUM_BOOT_LOADER_MODE_WAIT_TIME);
                        LogDetailedLine(unit, "succeeded");
                        unit->testsCompleted++;
                        testsCompleted++;
                        LogDetailedEntry(unit, "        Closing and re-opening the module ");
                        QCOM_CloseUnit(unit);
                        status = QCOM_OpenUnit(unit);
                        if (status == QCOM_SUCCESS)
                        {
                            LogDetailedLine(unit, "succeeded");
                            Thread::Sleep(2000);
                            QCOM_GetModuleInfo(unit);
                            if (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE)
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "        Firmware is in Bootloader Mode, but should not be");
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            LogDetailedEntry(
                                unit,
                                "        Retrieving the QCOM internal error code ");
                            status = QD_GetInternalErrorCode(unit->unitHandle, (LPWORD) &errorCode);
                            if ((status == QCOM_SUCCESS) && (errorCode == QCOM_SUCCESS))
                            {
                                LogDetailedLine(
                                    unit,
                                    "succeeded");
                                unit->testsCompleted++;
                                testsCompleted++;
                            }
                            else
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "failed, with status = 0x{0:X8} and internal error code = 0x{1:X4}",
                                    status, errorCode);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                        }
                        else
                        {
                            testPassed = GUI_NO;
                            LogDetailedStatus(unit, String::Empty, status);
                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                        }
                    }
                    else
                    {
                        testPassed = GUI_NO;
                        LogDetailedStatus(unit, String::Empty, status);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    LogDetailedLine(
                        unit,
                        "    Application Mode Test End: {0}",
                        (testPassed ? GUI_TEST_PASSED_STRING : GUI_TEST_FAILED_STRING));
                    LogDetailedEntry(
                        unit,
                        "    Application Mode Test End: ");
                    if (testPassed)
                        LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                    else
                        LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                }
                else
                {
                    testPassed = GUI_NO;
                    LogDetailedWarningLine(
                        unit,
                        "    Skipping Application Mode Test because "
                        "the firmware is not in Bootloader Mode");
                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                }
                if (testPassed == GUI_NO)
                    testsPassed = GUI_NO;
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            unit->flags &= ~QCOM_UNIT_FIRMWARE_UPDATING;
            QD_SetI2CDataRate(unit->unitHandle, originalDataRate);
            //----------------------------------------------------------------
            // Firmware ID Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Firmware ID Test Begin");
                testPassed = GUI_YES;
                LogDetailedEntry(unit, "        Retrieving and comparing the firmware ID ");
                status = QD_GetModuleFirmwareID(
                    unit->unitHandle,
                    (LPBYTE) firmwareID);
                if (status == QD_SUCCESS)
                {
                    LogDetailedLine(unit, "succeeded");
                    if (firmwareID[0] != QD_FIRMWARE_QUARTZDYNE_ID)             // 0x0D
                    {
                        testPassed = GUI_NO;
                        LogDetailedFailureLine(
                            unit,
                            "        Incorrect company ID: 0x{0:X2}",
                            firmwareID[0]);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    if (firmwareID[1] != QD_FIRMWARE_QCOM_ID)                   // 0x16
                    {
                        testPassed = GUI_NO;
                        LogDetailedFailureLine(
                            unit,
                            "        Incorrect product ID: 0x{0:X2}",
                            firmwareID[1]);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    if (firmwareID[2] != FWVHigh)
                    {
                        testPassed = GUI_NO;
                        LogDetailedFailureLine(
                            unit,
                            "        Major version mismatch: FWID = 0x{0:X2} / FWVHigh = 0x{1:X2}",
                            firmwareID[2],
                            FWVHigh);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    if (firmwareID[3] != FWVLow)
                    {
                        testPassed = GUI_NO;
                        LogDetailedFailureLine(
                            unit,
                            "        Minor version mismatch: FWID = 0x{0:X2} / FWVLow = 0x{1:X2}",
                            firmwareID[3],
                            FWVLow);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                }
                else
                {
                    testPassed = GUI_NO;
                    LogDetailedStatus(unit, String::Empty, status);
                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                }
                LogDetailedEntry(
                    unit,
                    "    Firmware ID Test End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
            }
            //----------------------------------------------------------------
            // The tests have concluded
            //----------------------------------------------------------------
            LogDetailedEntry(unit, "Firmware Test End Result: ");
            if (keepTesting)
            {
                if (testsPassed)
                    LogBothSuccessLine(unit, GUI_TEST_PASSED_STRING);
                else
                    LogBothFailureLine(unit, GUI_TEST_FAILED_STRING);
            }
            else
            {
                LogBothWarningLine(unit,
                    String::Concat(
                        "Terminated by ",
                        (testsPassed ? _T("user") : terminationSource)));
            }
        }                               // end of if (QCOM_UnitOpen(unit))
        else
        {
            testsPassed = GUI_NO;
            String ^failureLine = String::Format(
                "Unit {0:D} not open for testing",
                unit->unitNumber);
            LogDetailedFailureLine(unit, String::Concat("    ", failureLine));
            LogSummaryFailureLine(unit, failureLine);
        }
        unit->testsCompleted += (GUI_NUMBER_OF_FIRMWARE_TESTS - testsCompleted);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
        //--------------------------------------------------------------------
        // Not much else can be done if the unit pointer is invalid
        //--------------------------------------------------------------------
        testsPassed = GUI_NO;
    }
    return testsPassed;
}                                       // end of QCOM_TestSuiteFirmware()
//----------------------------------------------------------------------------
// QCOM_TestSuiteI2C
//
// Tests the ability of the QCOM device unit to communicate I�C without problems
//
// Returns: GUI_YES     All the tests passed
//          GUI_NO      At least one test failed
//
// Called by:   QCOM_InitiateUnitTests
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_TestSuiteI2C(
    UnitInfo        ^unit)
{
    bool            keepTesting;
    bool            testPassed;         // unit section tests
    bool            testsPassed = GUI_YES;
    int             dotCount;
    int             index;
    int             numberOfI2CCommands = 0;
    int             XDType = 0;
    char            *commandString;
    char            *replyString;
    char            *i2cCommand[][4] =
    {
        //  Digital wo/chksum     Analog wo/chksum    Digital w/chksum        Analog w/chksum
        { "S9CR9DFFFFFFFFP",    "S98R99FFFFFFFFP",  "S9CR9DFFFFFFFFFFP",    "S98R99FFFFFFFFFFP" },  // XD type, ID, and checksum
        { "S9DFFFFFFFFP",       "S99FFFFFFFFP",     "S9DFFFFFFFFFFP",       "S99FFFFFFFFFFP"    },  // Read Pressure, checksum
        { "S9FFFFFFFFFP",       "S9BFFFFFFFFP",     "S9FFFFFFFFFFFP",       "S9BFFFFFFFFFFP"    },  // Read Temperature, checksum
        { "S9CR9FFFFFP",        "S98R9BFFFFP",      "S9CR9FFFFFP",          "S98R9BFFFFP"       },  // Read Status - 2 bytes
        { "S9DFFP",             "S99FFP",           "S9DFFP",               "S99FFP"            },  // Poll ACK
        { "SADFFFFFFP",         "SA3FFFFFFP",       "SADFFFFFFP",           "SA3FFFFFFP"        },  // Read ASIC Current Address
        { "SAC0000RADFFP",      "SA20000RA3FFP",    "SAC0000RADFFP",        "SA20000RA3FFP"     },  // Read ASIC Specific Address 0000 - 1 byte
        { 0, 0, 0, 0 }
    };
    char            *testCommand;
    double          originalDataRate = 0.0;
    double          getDataRate;
    double          randomDataRate;
    DWORD           address;
    DWORD           status;
    DWORD           testsCompleted = 0;
    HANDLE          unitHandle;
    Random          ^randomNumber = gcnew Random();
    String          ^terminationSource;
    String          ^functionName = _T("QCOM_TestSuiteI2C");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitHandle = unit->unitHandle;
        //--------------------------------------------------------------------
        // Announce the start of the test
        //--------------------------------------------------------------------
        LogDetailedLine(unit, "I�C Test started");
        LogSummaryEntry(unit, "I�C Test...");
        if (QCOM_UnitReady(unit))
        {
            terminationSource =
                (unit->testFlags & QCOM_UNIT_TEST_STOP_ON_ERRORS) ?
                    "error" : "user";
            if (QCOM_XDIsFrequency(unit))
                XDType = 1;
            if ((unit->transducerChipID[2] >= 4) && (unit->transducerChipID[3] >= 2))
            {
                //------------------------------------------------------------
                // The ASIC is version 4.02 or later, so request checksums
                //------------------------------------------------------------
                XDType += 2;
            }
            if (QCOM_XDIsDigitalNoMem(unit))
                numberOfI2CCommands = 5;                                        // ==> must get rid of this magic number
            else
                while (i2cCommand[numberOfI2CCommands][XDType])
                    numberOfI2CCommands++;
            QD_GetI2CDataRate(unitHandle, &originalDataRate);
            commandString = (char *) malloc(QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE);
            replyString = (char *) malloc(QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
            if (commandString && replyString)
            {
                ClearBuffer(commandString, QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE);
                ClearBuffer(replyString, QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
                //------------------------------------------------------------
                // Sequential I�C Test
                //------------------------------------------------------------
                QCOM_CheckActiveTesting(unit, keepTesting);
                if (keepTesting)
                {
                    LogDetailedLine(unit, "    Sequential I�C Test Begin");
                    testPassed = GUI_YES;
                    LogDetailedEntry(
                        unit,
                        "        Rapid succession of Read Pressure commands...");
                    for (int count = dotCount = 0; (count < 100) && keepTesting && testPassed; count++)
                    {
                        //----------------------------------------------------
                        // Read Pressure
                        //----------------------------------------------------
                        testCommand = i2cCommand[1][XDType];
                        strcpy_s(
                            commandString,
                            QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                            testCommand);
                        status = QD_ExecuteI2CCommand(
                            unitHandle,
                            (LPBYTE) commandString,
                            (LPBYTE) replyString);
                        if (status == QD_SUCCESS)
                        {
                            if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                            {
                                replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                            }
                            if ((replyString[0] != 'S') ||
                                (strlen(replyString) != strlen(testCommand)) ||
                                (replyString[strlen(replyString) - 1] != 'P') ||
                                (replyString[strlen(replyString) - 2] == 'N'))
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "failed during iteration {0:D}: Command {1} => Reply {2}",
                                    count,
                                    gcnew String(commandString),
                                    gcnew String(replyString));
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            if (testPassed && (XDType > 1))
                            {
                                if ((strlen(replyString) < 14) ||
                                    !QCOM_I2CChecksumVerified(&replyString[3]))
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedFailureLine(
                                        unit,
                                        "failed due to an incorrect reply checksum");
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                            }
                        }
                        else
                        {
                            testPassed = GUI_NO;
                            LogDetailedStatus(unit, String::Empty, status);
                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                        }
                        if (testPassed && (dotCount++ & 0x01))
                            LogDetailedDot(unit);
                        Thread::Sleep(20);
                        QCOM_CheckActiveTesting(unit, keepTesting);
                    }                   // end of for (int count = dotCount = 0; ...)
                    if (testPassed)
                    {
                        LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                    }
                    if (testPassed == GUI_NO)
                        testsPassed = GUI_NO;
                    unit->testsCompleted++;
                    testsCompleted++;
                    Thread::Sleep(1000);
                    if (keepTesting)
                    {
                        testPassed = GUI_YES;
                        LogDetailedEntry(
                            unit,
                            "        Rapid succession of Read Temperature commands...");
                        for (int count = dotCount = 0; (count < 100) && keepTesting && testPassed; count++)
                        {
                            //------------------------------------------------
                            // Read Temperature
                            //------------------------------------------------
                            testCommand = i2cCommand[2][XDType];
                            strcpy_s(
                                commandString,
                                QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                testCommand);
                            status = QD_ExecuteI2CCommand(
                                unitHandle,
                                (LPBYTE) commandString,
                                (LPBYTE) replyString);
                            if (status == QD_SUCCESS)
                            {
                                if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                {
                                    replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                }
                                if ((replyString[0] != 'S') ||
                                    (strlen(replyString) != strlen(testCommand)) ||
                                    (replyString[strlen(replyString) - 1] != 'P') ||
                                    (replyString[strlen(replyString) - 2] == 'N'))
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedFailureLine(
                                        unit,
                                        "failed during iteration {0:D}: Command {1} => Reply {2}",
                                        count,
                                        gcnew String(commandString),
                                        gcnew String(replyString));
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                if (testPassed && (XDType > 1))
                                {
                                    if ((strlen(replyString) < 11) ||
                                        !QCOM_I2CChecksumVerified(&replyString[strlen(replyString) - 11]))
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedFailureLine(
                                            unit,
                                            "failed due to an incorrect reply checksum");
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                }
                            }
                            else
                            {
                                testPassed = GUI_NO;
                                LogDetailedStatus(unit, String::Empty, status);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            if (testPassed && (dotCount++ & 0x01))
                                LogDetailedDot(unit);
                            Thread::Sleep(20);
                            QCOM_CheckActiveTesting(unit, keepTesting);
                        }               // end of for (int count = dotCount = 0; ...)
                        if (testPassed)
                        {
                            LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                        }
                        else
                        {
                            testsPassed = GUI_NO;
                        }
                    }
                    LogDetailedEntry(
                        unit,
                        "    Sequential I�C Test End: ");
                    if (testPassed)
                    {
                        LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                    }
                    else
                    {
                        LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                        testsPassed = GUI_NO;
                    }
                    unit->testsCompleted++;
                    testsCompleted++;
                    Thread::Sleep(1000);
                }
                //------------------------------------------------------------
                // Random I�C Test
                //------------------------------------------------------------
                QCOM_CheckActiveTesting(unit, keepTesting);
                if (keepTesting)
                {
                    LogDetailedLine(unit, "    Random I�C Test Begin");
                    testPassed = GUI_YES;
                    LogDetailedEntry(
                        unit,
                        "        Rapid succession of random commands...");
                    for (int count = dotCount = 0; (count < 100) && keepTesting && testPassed; count++)
                    {
                        index = randomNumber->Next() % numberOfI2CCommands;
                        testCommand = i2cCommand[index][XDType];
                        strcpy_s(
                            commandString,
                            QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                            testCommand);
                        if (index == 6)                                         // ==> this magic number has to go
                        {
                            address = randomNumber->Next() % 1024;
                            commandString[4] = XtoA((address & 0xF00) >> 8);
                            commandString[5] = XtoA((address & 0x0F0) >> 4);
                            commandString[6] = XtoA(address & 0x00F);
                        }
                        status = QD_ExecuteI2CCommand(
                            unitHandle,
                            (LPBYTE) commandString,
                            (LPBYTE) replyString);
                        if (status == QD_SUCCESS)
                        {
                            if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                            {
                                replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                            }
                            if ((replyString[0] != 'S') ||
                                (strlen(replyString) != strlen(testCommand)) ||
                                (replyString[strlen(replyString) - 1] != 'P') ||
                                (replyString[strlen(replyString) - 2] == 'N'))
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "failed during iteration {0:D}: Command {1} => Reply {2}",
                                    count,
                                    gcnew String(commandString),
                                    gcnew String(replyString));
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            switch (index)
                            {
                                case 0 :    case 1 :    case 2 :
                                    if (testPassed && (XDType > 1))
                                    {
                                        if ((strlen(replyString) < 11) ||
                                            !QCOM_I2CChecksumVerified(&replyString[strlen(replyString) - 11]))
                                        {
                                            testPassed = GUI_NO;
                                            LogDetailedFailureLine(
                                                unit,
                                                "failed due to an incorrect reply checksum");
                                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                        }
                                    }
                                    break;
                                default : break;
                            }
                        }
                        else
                        {
                            testPassed = GUI_NO;
                            LogDetailedStatus(unit, String::Empty, status);
                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                        }
                        if (testPassed && (dotCount++ & 0x01))
                            LogDetailedDot(unit);
                        Thread::Sleep(20);
                        QCOM_CheckActiveTesting(unit, keepTesting);
                    }                   // end of for (int count = dotCount = 0; ...)
                    if (testPassed)
                    {
                        LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                    }
                    LogDetailedEntry(
                        unit,
                        "    Random I�C Test End: ");
                    if (testPassed)
                    {
                        LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                    }
                    else
                    {
                        LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                        testsPassed = GUI_NO;
                    }
                    unit->testsCompleted++;
                    testsCompleted++;
                    Thread::Sleep(1000);
                }
                //------------------------------------------------------------
                // I2C Ramp-up Test
                //------------------------------------------------------------
                QCOM_CheckActiveTesting(unit, keepTesting);
                if (keepTesting)
                {
                    LogDetailedLine(unit, "    I�C Ramp-up Test Begin");
                    testPassed = GUI_YES;
                    LogDetailedEntry(
                        unit,
                        "        Rapid succession of random commands in increasing data rates...");
                    dotCount = 0;
                    for (double setDataRate = 33.3; (setDataRate <= 100.0) && keepTesting && testPassed; setDataRate += 0.1)
                    {
                        status = QD_SetI2CDataRate(unitHandle, setDataRate);
                        if (status == QD_SUCCESS)
                        {
                            Thread::Sleep(20);
                            status = QD_GetI2CDataRate(unitHandle, &getDataRate);
                            if (status == QD_SUCCESS)
                            {
                                Thread::Sleep(10);
                                if (abs(((int) (getDataRate - setDataRate))) < 3.0)
                                {
                                    index = randomNumber->Next() % numberOfI2CCommands;
                                    testCommand = i2cCommand[index][XDType];
                                    strcpy_s(
                                        commandString,
                                        QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                        testCommand);
                                    if (index == 6)                             // ==> this magic number has to go
                                    {
                                        address = randomNumber->Next() % 1024;
                                        commandString[4] = XtoA((address & 0xF00) >> 8);
                                        commandString[5] = XtoA((address & 0x0F0) >> 4);
                                        commandString[6] = XtoA(address & 0x00F);
                                    }
                                    status = QD_ExecuteI2CCommand(
                                        unitHandle,
                                        (LPBYTE) commandString,
                                        (LPBYTE) replyString);
                                    if (status == QD_SUCCESS)
                                    {
                                        if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                        {
                                            replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                        }
                                        if ((replyString[0] != 'S') ||
                                            (strlen(replyString) != strlen(testCommand)) ||
                                            (replyString[strlen(replyString) - 1] != 'P') ||
                                            (replyString[strlen(replyString) - 2] == 'N'))
                                        {
                                            testPassed = GUI_NO;
                                            LogDetailedFailureLine(
                                                unit,
                                                "failed at data rate = {0:F2}: Command {1} => Reply {2}",
                                                setDataRate,
                                                gcnew String(commandString),
                                                gcnew String(replyString));
                                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                        }
                                        switch (index)
                                        {
                                            case 0 :    case 1 :    case 2 :
                                                if (testPassed && (XDType > 1))
                                                {
                                                    if ((strlen(replyString) < 11) ||
                                                        !QCOM_I2CChecksumVerified(&replyString[strlen(replyString) - 11]))
                                                    {
                                                        testPassed = GUI_NO;
                                                        LogDetailedFailureLine(
                                                            unit,
                                                            "failed due to an incorrect reply checksum");
                                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                                    }
                                                }
                                                break;
                                            default : break;
                                        }
                                    }
                                    else
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedStatus(
                                            unit,
                                            String::Format("at a data rate of {0:F2} kHz", setDataRate),
                                            status);
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedFailureLine(
                                        unit,
                                        "failed tolerance test (data rate should be {0:F2} but reads {1:F2})",
                                        setDataRate,
                                        getDataRate);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                            }
                            else
                            {
                                testPassed = GUI_NO;
                                LogDetailedStatus(
                                    unit,
                                    String::Format("getting data rate of {0:F2} kHz", setDataRate),
                                    status);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                        }
                        else
                        {
                            testPassed = GUI_NO;
                            LogDetailedStatus(
                                unit,
                                String::Format("setting data rate to {0:F2} kHz", setDataRate),
                                status);
                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                        }
                        if (dotCount > 12)
                            dotCount = 0;
                        if (testPassed && !dotCount++)
                            LogDetailedDot(unit);
                        Thread::Sleep(20);
                        QCOM_CheckActiveTesting(unit, keepTesting);
                    }                   // end of for (double setDataRate = 33.3; ...)
                    if (testPassed)
                    {
                        LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                    }
                    LogDetailedEntry(
                        unit,
                        "    I�C Ramp-up Test End: ");
                    if (testPassed)
                    {
                        LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                    }
                    else
                    {
                        LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                        testsPassed = GUI_NO;
                    }
                    unit->testsCompleted++;
                    testsCompleted++;
                    Thread::Sleep(1000);
                }
                //------------------------------------------------------------
                // I2C Ramp-down Test
                //------------------------------------------------------------
                QCOM_CheckActiveTesting(unit, keepTesting);
                if (keepTesting)
                {
                    LogDetailedLine(unit, "    I�C Ramp-down Test Begin");
                    testPassed = GUI_YES;
                    LogDetailedEntry(
                        unit,
                        "        Rapid succession of random commands in decreasing data rates...");
                    dotCount = 0;
                    for (double setDataRate = 100.0; (setDataRate >= 33.3) && keepTesting && testPassed; setDataRate -= 0.1)
                    {
                        status = QD_SetI2CDataRate(unitHandle, setDataRate);
                        if (status == QD_SUCCESS)
                        {
                            Thread::Sleep(20);
                            status = QD_GetI2CDataRate(unitHandle, &getDataRate);
                            if (status == QD_SUCCESS)
                            {
                                Thread::Sleep(10);
                                if (abs(((int) (getDataRate - setDataRate))) < 3.0)
                                {
                                    index = randomNumber->Next() % numberOfI2CCommands;
                                    testCommand = i2cCommand[index][XDType];
                                    strcpy_s(
                                        commandString,
                                        QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                        testCommand);
                                    if (index == 6)                             // ==> this magic number has to go too
                                    {
                                        address = randomNumber->Next() % 1024;
                                        commandString[4] = XtoA((address & 0xF00) >> 8);
                                        commandString[5] = XtoA((address & 0x0F0) >> 4);
                                        commandString[6] = XtoA(address & 0x00F);
                                    }
                                    status = QD_ExecuteI2CCommand(
                                        unitHandle,
                                        (LPBYTE) commandString,
                                        (LPBYTE) replyString);
                                    if (status == QD_SUCCESS)
                                    {
                                        if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                        {
                                            replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                        }
                                        if ((replyString[0] != 'S') ||
                                            (strlen(replyString) != strlen(testCommand)) ||
                                            (replyString[strlen(replyString) - 1] != 'P') ||
                                            (replyString[strlen(replyString) - 2] == 'N'))
                                        {
                                            testPassed = GUI_NO;
                                            LogDetailedFailureLine(
                                                unit,
                                                "failed at data rate = {0:F2} due to a malformed reply ({1})",
                                                setDataRate,
                                                gcnew String(replyString));
                                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                        }
                                        switch (index)
                                        {
                                            case 0 :    case 1 :    case 2 :
                                                if (testPassed && (XDType > 1))
                                                {
                                                    if ((strlen(replyString) < 11) ||
                                                        !QCOM_I2CChecksumVerified(&replyString[strlen(replyString) - 11]))
                                                    {
                                                        testPassed = GUI_NO;
                                                        LogDetailedFailureLine(
                                                            unit,
                                                            "failed due to an incorrect reply checksum");
                                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                                    }
                                                }
                                                break;
                                            default : break;
                                        }
                                    }
                                    else
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedStatus(
                                            unit,
                                            String::Format("at data rate {0:F2} kHz", setDataRate),
                                            status);
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedFailureLine(
                                        unit,
                                        "failed tolerance test (data rate should be {0:F2} but reads {1:F2})",
                                        setDataRate,
                                        getDataRate);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                            }
                            else
                            {
                                testPassed = GUI_NO;
                                LogDetailedStatus(unit, String::Empty, status);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                        }
                        else
                        {
                            testPassed = GUI_NO;
                            LogDetailedStatus(
                                unit,
                                String::Format("setting data rate to {0:F2} kHz", setDataRate),
                                status);
                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                        }
                        if (dotCount > 12)
                            dotCount = 0;
                        if (testPassed && !dotCount++)
                            LogDetailedDot(unit);
                        Thread::Sleep(20);
                        QCOM_CheckActiveTesting(unit, keepTesting);
                    }                   // end of for (double setDataRate = 100.0; ...)
                    if (testPassed)
                    {
                        LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                    }
                    LogDetailedEntry(
                        unit,
                        "    I�C Ramp-down Test End: ");
                    if (testPassed)
                    {
                        LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                    }
                    else
                    {
                        LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                        testsPassed = GUI_NO;
                    }
                    unit->testsCompleted++;
                    testsCompleted++;
                    Thread::Sleep(1000);
                }
                //------------------------------------------------------------
                // Random-Random Test
                //------------------------------------------------------------
                QCOM_CheckActiveTesting(unit, keepTesting);
                if (keepTesting)
                {
                    LogDetailedLine(unit, "    Random-Random Test Begin");
                    testPassed = GUI_YES;
                    LogDetailedEntry(
                        unit,
                        "        Rapid succession of random commands at random data rates...");
                    for (int count = dotCount = 0; (count < 100) && keepTesting && testPassed; count++)
                    {
                        do
                        {
                            randomDataRate = ((double) ((randomNumber->Next() % 666) + 334)) / 10.0;
                        }
                        while ((randomDataRate < 33.4) || (randomDataRate > 99.9));
                        status = QD_SetI2CDataRate(unitHandle, randomDataRate);
                        if (status == QD_SUCCESS)
                        {
                            Thread::Sleep(20);
                            status = QD_GetI2CDataRate(unitHandle, &getDataRate);
                            if (status == QD_SUCCESS)
                            {
                                Thread::Sleep(10);
                                if (abs(((int) (getDataRate - randomDataRate))) < 3.0)
                                {
                                    index = randomNumber->Next() % numberOfI2CCommands;
                                    testCommand = i2cCommand[index][XDType];
                                    strcpy_s(
                                        commandString,
                                        QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                        testCommand);
                                    if (index == 6)                             // ==> this magic number has to go
                                    {
                                        address = randomNumber->Next() % 1024;
                                        commandString[4] = XtoA((address & 0xF00) >> 8);
                                        commandString[5] = XtoA((address & 0x0F0) >> 4);
                                        commandString[6] = XtoA(address & 0x00F);
                                    }
                                    status = QD_ExecuteI2CCommand(
                                        unitHandle,
                                        (LPBYTE) commandString,
                                        (LPBYTE) replyString);
                                    if (status == QD_SUCCESS)
                                    {
                                        if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                        {
                                            replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                        }
                                        if ((replyString[0] != 'S') ||
                                            (strlen(replyString) != strlen(testCommand)) ||
                                            (replyString[strlen(replyString) - 1] != 'P') ||
                                            (replyString[strlen(replyString) - 2] == 'N'))
                                        {
                                            testPassed = GUI_NO;
                                            LogDetailedFailureLine(
                                                unit,
                                                "failed during iteration {0:D}: Command {1} => Reply {2}",
                                                count,
                                                gcnew String(commandString),
                                                gcnew String(replyString));
                                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                        }
                                        switch (index)
                                        {
                                            case 0 :    case 1 :    case 2 :
                                                if (testPassed && (XDType > 1))
                                                {
                                                    if ((strlen(replyString) < 11) ||
                                                        !QCOM_I2CChecksumVerified(&replyString[strlen(replyString) - 11]))
                                                    {
                                                        testPassed = GUI_NO;
                                                        LogDetailedFailureLine(
                                                            unit,
                                                            "failed due to an incorrect reply checksum");
                                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                                    }
                                                }
                                                break;
                                            default : break;
                                        }
                                    }
                                    else
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedStatus(unit, String::Empty, status);
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedFailureLine(
                                        unit,
                                        "failed tolerance test (data rate should be {0:F1} but reads {1:F1})",
                                        randomDataRate,
                                        getDataRate);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                            }
                            else
                            {
                                testPassed = GUI_NO;
                                LogDetailedStatus(unit, String::Empty, status);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                        }
                        else
                        {
                            testPassed = GUI_NO;
                            LogDetailedStatus(unit, String::Empty, status);
                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                        }
                        if (dotCount > 12)
                            dotCount = 0;
                        if (testPassed && !dotCount++)
                            LogDetailedDot(unit);
                        Thread::Sleep(20);
                        QCOM_CheckActiveTesting(unit, keepTesting);
                    }                   // end of for (int count = dotCount = 0; ...)
                    if (testPassed)
                    {
                        LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                    }
                    LogDetailedEntry(
                        unit,
                        "    Random-Random Test End: ");
                    if (testPassed)
                    {
                        LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                    }
                    else
                    {
                        LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                        testsPassed = GUI_NO;
                    }
                    unit->testsCompleted++;
                    testsCompleted++;
                    Thread::Sleep(1000);
                }
                free((void *) replyString);
                free((void *) commandString);
            }
            else
            {
                testsPassed = GUI_NO;
                LogDetailedFailureLine(unit, "    Unable to allocate test buffers");
                keepTesting = QCOM_ContinueTestingWithErrors(unit);
            }
            //----------------------------------------------------------------
            // The tests have concluded
            //----------------------------------------------------------------
            QD_SetI2CDataRate(unitHandle, originalDataRate);
            LogDetailedEntry(unit, "I�C Test End Result: ");
            if (keepTesting)
            {
                if (testsPassed)
                    LogBothSuccessLine(unit, GUI_TEST_PASSED_STRING);
                else
                    LogBothFailureLine(unit, GUI_TEST_FAILED_STRING);
            }
            else
            {
                LogBothWarningLine(unit,
                    String::Concat(
                        "Terminated by ",
                        (testsPassed ? _T("user") : terminationSource)));
            }
        }                               // end of if (QCOM_UnitReady(unit))
        else
        {
            testsPassed = GUI_NO;
            String ^failureLine;
            if (QCOM_XDPresent(unit) && QCOM_XDSNValid(unit))
            {
                failureLine = String::Format(
                    "Failed: module {0} not ready for testing with transducer {1}",
                    unit->moduleSerialNumber,
                    unit->transducerSerialNumber);
            }
            else
            {
                failureLine = String::Format(
                    "Failed: module {0} requires a transducer for testing",
                    unit->moduleSerialNumber);
            }
            LogDetailedFailureLine(unit, String::Concat("    ", failureLine));
            LogSummaryFailureLine(unit, failureLine);
        }
        unit->testsCompleted += (GUI_NUMBER_OF_I2C_TESTS - testsCompleted);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
        //--------------------------------------------------------------------
        // Not much else can be done if the unit pointer is invalid
        //--------------------------------------------------------------------
        testsPassed = GUI_NO;
    }
    delete randomNumber;
    return testsPassed;
}                                       // end of QCOM_TestSuiteI2C()
//----------------------------------------------------------------------------
// QCOM_TestSuiteQMEM
//
// Tests the ability to read from and write to the QCOM unit device memory at
// the first four 256-byte pages
//
// Returns: GUI_YES     All the tests passed
//          GUI_NO      At least one test failed
//
// Called by:   QCOM_InitiateUnitTests
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_TestSuiteQMEM(
    UnitInfo        ^unit)
{
    bool            keepTesting;
    bool            testPassed;         // unit section tests
    bool            testsPassed = GUI_YES;
    int             numberOfTestsToRun;
    int             numberOfMemoryPagesToTest = QD_MAXIMUM_NUMBER_OF_QMEM_PAGES;
    BYTE            checkSum = 0;
    DWORD           status = QCOM_SUCCESS;                                      // 0x0000
    DWORD           testsCompleted = 0;
    HANDLE          unitHandle;
    String          ^terminationSource;
    String          ^functionName = _T("QCOM_TestSuiteQMEM");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitHandle = unit->unitHandle;
        if (numberOfMemoryPagesToTest != unit->numberOfModuleMemoryPages)
            numberOfMemoryPagesToTest = unit->numberOfModuleMemoryPages;
        //--------------------------------------------------------------------
        // Announce the start of the test
        //--------------------------------------------------------------------
        LogDetailedLine(unit,
            "Module Memory Test started for {0:D} pages",
            numberOfMemoryPagesToTest);
        LogSummaryEntry(unit, "Module Memory Test...");
        if (QCOM_UnitOpen(unit))
        {
            terminationSource =
                (unit->testFlags & QCOM_UNIT_TEST_STOP_ON_ERRORS) ?
                    _T("error") : _T("user");
            if (unit->numberOfModuleMemoryPages)
            {
                numberOfTestsToRun = (numberOfMemoryPagesToTest * 11) + 2;
                if (numberOfTestsToRun != GUI_MAXIMUM_NUMBER_OF_QMEM_TESTS)
                {
                    unit->testsToComplete -= GUI_MAXIMUM_NUMBER_OF_QMEM_TESTS;
                    unit->testsToComplete += numberOfTestsToRun;
                }
                //------------------------------------------------------------
                // Start the test
                //------------------------------------------------------------
                QCOM_CheckActiveTesting(unit, keepTesting);
                if (keepTesting)
                {
                    LogDetailedLine(unit, "    Setting up the test");
                    testPassed = GUI_YES;
                    //--------------------------------------------------------
                    // Allocate test buffers
                    //--------------------------------------------------------
                    LPBYTE *originalData = (LPBYTE *) malloc(numberOfMemoryPagesToTest * sizeof(LPBYTE));
                    LPBYTE testData = (LPBYTE) malloc(QD_BYTES_PER_QMEM_PAGE);
                    LPBYTE zeroData = (LPBYTE) malloc(QD_BYTES_PER_QMEM_PAGE);
                    if (originalData && testData && zeroData)
                    {
                        QCOM_CheckActiveTesting(unit, keepTesting);
                        if (keepTesting)
                        {
                            testingStartStopAllButton->Enabled = GUI_NO;
                            testingStartStopButtonArray[unit->unitNumber]->Enabled = GUI_NO;
                            for (BYTE pageNumber = 0; pageNumber < numberOfMemoryPagesToTest; pageNumber++)
                            {
                                originalData[pageNumber] = (LPBYTE) malloc(QD_BYTES_PER_QMEM_PAGE);
                                if (originalData[pageNumber])
                                {
                                    ClearBuffer(originalData[pageNumber], QD_BYTES_PER_QMEM_PAGE);
                                    //----------------------------------------
                                    // Save a copy of the original stored
                                    // coefficient data at this page
                                    //----------------------------------------
                                    LogDetailedEntry(
                                        unit,
                                        "        Backing up the original copy of page {0:D} ",
                                        pageNumber);
                                    status = QD_ReadCoefficientDataFromModulePage(
                                        unitHandle,
                                        pageNumber,
                                        originalData[pageNumber]);
                                    if ((status == QCOM_SUCCESS) || ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA))
                                    {
                                        LogDetailedLine(unit, "succeeded");
                                    }
                                    else
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedStatus(unit, String::Empty, status);
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                    unit->testsCompleted++;         // Preliminary 1
                                    testsCompleted++;
                                }
                                else
                                {
                                    testsPassed = GUI_NO;
                                    LogDetailedFailureLine(unit, "    Unable to allocate test buffers");
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    break;
                                }
                            }           // end of for (BYTE pageNumber = 0; ...)
                            testingStartStopAllButton->Enabled = GUI_YES;
                            testingStartStopButtonArray[unit->unitNumber]->Enabled = GUI_YES;
                        }
                        QCOM_CheckActiveTesting(unit, keepTesting);
                        if (keepTesting)
                        {
                            //------------------------------------------------
                            // Retrieve the test data from the test file
                            //------------------------------------------------
                            if ((unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED) &&
                                StringSet(unit->testDataFilePath))
                            {
                                LogDetailedEntry(
                                    unit,
                                    "        Retrieving the test coefficient data from {0} ",
                                    unit->testDataFilePath);
                                char *testDataFilePath = (char *) malloc(QCOM_MAXIMUM_FILE_PATH_LENGTH);
                                if (testDataFilePath)
                                {
                                    QCOM_ConvertString(
                                        unit->testDataFilePath,
                                        testDataFilePath,
                                        QCOM_MAXIMUM_FILE_PATH_LENGTH);
                                    status = QD_ReadCoefficientDataFromHexFile(
                                        (LPBYTE) testDataFilePath,
                                        testData);
                                    if (status == QD_SUCCESS)
                                    {
                                        LogDetailedLine(unit, "succeeded");
                                    }
                                    else
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedStatus(unit, String::Empty, status);
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                    free((void *) testDataFilePath);
                                }
                            }
                            else
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "        The test file path is not yet specified");
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            unit->testsCompleted++;         // Preliminary 2
                            testsCompleted++;
                        }
                        if (testPassed == GUI_NO)
                            testsPassed = GUI_NO;
                        QCOM_CheckActiveTesting(unit, keepTesting);
                        //----------------------------------------------------
                        // Begin testing the first 32 memory pages
                        //----------------------------------------------------
                        for (BYTE pageNumber = 0;
                            keepTesting && testPassed && (pageNumber < numberOfMemoryPagesToTest);
                            pageNumber++)
                        {
                            LogDetailedLine(
                                unit,
                                "    Testing module memory page {0:D}",
                                pageNumber);
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Zero out the unit memory page
                                //--------------------------------------------
                                ClearBuffer(zeroData, QD_BYTES_PER_QMEM_PAGE);
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Setting the page to all zeroes ",
                                    pageNumber);
                                status = QD_WriteCoefficientDataToModulePage(
                                    unitHandle,
                                    pageNumber,
                                    zeroData);
                                if (status == QD_SUCCESS)
                                {
                                    LogDetailedLine(unit, "succeeded");
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                unit->testsCompleted++;     // Loop 1
                                testsCompleted++;
                                //--------------------------------------------
                                // Fill the buffer with 9A (singlets and doublets)
                                //--------------------------------------------
                                memset((void *) zeroData, 0x9A, QD_BYTES_PER_QMEM_PAGE);
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Read back the zero-filled memory page into
                                // a nonzero buffer
                                //--------------------------------------------
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Copying the zeroed page into a nonzero pattern buffer ",
                                    pageNumber);
                                status = QD_ReadCoefficientDataFromModulePage(
                                    unitHandle,
                                    pageNumber,
                                    zeroData);
                                if ((status == QCOM_SUCCESS) || ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA))
                                {
                                    LogDetailedLine(unit, "succeeded");
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                unit->testsCompleted++;     // Loop 2
                                testsCompleted++;
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Ensure it is all zeroes
                                //--------------------------------------------
                                for (int offset = 0; offset < QD_BYTES_PER_QMEM_PAGE; offset++)
                                {
                                    if (zeroData[offset] != QCOM_CHAR_NULL)
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedFailureLine(
                                            unit,
                                            "        At least one byte (offset {0:D}) on page {1:D} "
                                            "did not remain zeroed",
                                            offset,
                                            pageNumber);
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                        break;      // this only breaks out of the for (int offset = 0; ...) loop
                                    }
                                }
                                unit->testsCompleted++;     // Loop 3
                                testsCompleted++;
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Write the test pattern to the memory page
                                //--------------------------------------------
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Copying the test coefficient data into the page ",
                                    pageNumber);
                                status = QD_WriteCoefficientDataToModulePage(
                                    unitHandle,
                                    pageNumber,
                                    testData);
                                if (status == QD_SUCCESS)
                                {
                                    LogDetailedLine(unit, "succeeded");
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                unit->testsCompleted++;     // Loop 4
                                testsCompleted++;
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Read back the test pattern in a zeroed buffer
                                //--------------------------------------------
                                ClearBuffer(zeroData, QD_BYTES_PER_QMEM_PAGE);
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Copying the test coefficient data from "
                                    "the page into a zeroed buffer",
                                    pageNumber);
                                status = QD_ReadCoefficientDataFromModulePage(
                                    unitHandle,
                                    pageNumber,
                                    zeroData);
                                if ((status == QCOM_SUCCESS) || ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA))
                                {
                                    LogDetailedLine(unit, " succeeded");
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                unit->testsCompleted++;     // Loop 5
                                testsCompleted++;
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Ensure the contents of the write and read
                                // buffers are identical
                                //--------------------------------------------
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Contents written to and read from the page ",
                                    pageNumber);
                                if (memcmp((void *) testData, (void *) zeroData, QD_BYTES_PER_QMEM_PAGE))
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedFailureLine(
                                        unit,
                                        "are not identical, but should be");
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                else
                                {
                                    LogDetailedLine(unit, "are identical");
                                }
                                unit->testsCompleted++;     // Loop 6
                                testsCompleted++;
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Calculate and test the checksum
                                //--------------------------------------------
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Checksum for the page ",
                                    pageNumber);
                                checkSum = 0;
                                for (int offset = 0; offset < QD_BYTES_PER_QMEM_PAGE; offset++)
                                {
                                    checkSum += zeroData[offset];
                                }
                                if (checkSum)
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedFailureLine(unit, "is invalid");
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                else
                                {
                                    LogDetailedLine(unit, "is correct");
                                }
                                unit->testsCompleted++;     // Loop 7
                                testsCompleted++;
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Leave the unit memory page in a zeroed-out
                                // state
                                //--------------------------------------------
                                ClearBuffer(zeroData, QD_BYTES_PER_QMEM_PAGE);
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Resetting the page to all zeroes ",
                                    pageNumber);
                                status = QD_WriteCoefficientDataToModulePage(
                                    unitHandle,
                                    pageNumber,
                                    zeroData);
                                if (status == QD_SUCCESS)
                                {
                                    LogDetailedLine(unit, "succeeded");
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                unit->testsCompleted++;     // Loop 8
                                testsCompleted++;
                                //--------------------------------------------
                                // Fill the buffer with E8 (singlets and triplets)
                                //--------------------------------------------
                                memset((void *) zeroData, 0xE8, QD_BYTES_PER_QMEM_PAGE);
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Read back the zero-filled memory page into
                                // a nonzero buffer
                                //--------------------------------------------
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Copying the zeroed page into "
                                    "another nonzero pattern buffer ",
                                    pageNumber);
                                status = QD_ReadCoefficientDataFromModulePage(
                                    unitHandle,
                                    pageNumber,
                                    zeroData);
                                if ((status == QCOM_SUCCESS) || ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA))
                                {
                                    LogDetailedLine(unit, "succeeded");
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                unit->testsCompleted++;     // Loop 9
                                testsCompleted++;
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Ensure it is all zeroes
                                //--------------------------------------------
                                for (int offset = 0; offset < QD_BYTES_PER_QMEM_PAGE; offset++)
                                {
                                    if (zeroData[offset] != QCOM_CHAR_NULL)
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedFailureLine(
                                            unit,
                                            "        At least one byte (offset {0:D}) on page {1:D} "
                                            "did not remain zeroed",
                                            offset,
                                            pageNumber);
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                        break;          // this only breaks out of the for (int offset = 0; ...) loop
                                    }
                                }
                                unit->testsCompleted++; // Loop 10
                                testsCompleted++;
                            }
                            LogDetailedEntry(
                                unit,
                                "        Memory test of module page {0:D} ", pageNumber);
                            if (testPassed)
                            {
                                LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                            }
                            else
                            {
                                LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                                testsPassed = GUI_NO;
                                testPassed = GUI_YES;   // ensure all four pages are tested
                            }
                            Thread::Sleep(100);
                            QCOM_CheckActiveTesting(unit, keepTesting);
                        }               // end of for (BYTE pageNumber = 0; ...)
                        LogDetailedLine(unit, "    Concluding the test");
                        //----------------------------------------------------
                        // Restore the memory pages to their original contents
                        //----------------------------------------------------
                        testingStartStopAllButton->Enabled = GUI_NO;
                        testingStartStopButtonArray[unit->unitNumber]->Enabled = GUI_NO;
                        for (BYTE pageNumber = 0; pageNumber < numberOfMemoryPagesToTest; pageNumber++)
                        {
                            LogDetailedEntry(
                                unit,
                                "        Restoring the original copy of page {0:D} ",
                                pageNumber);
                            status = QD_WriteCoefficientDataToModulePage(
                                unitHandle,
                                pageNumber,
                                originalData[pageNumber]);
                            if (status == QD_SUCCESS)
                            {
                                LogDetailedLine(unit, "succeeded");
                            }
                            else
                            {
                                testsPassed = GUI_NO;
                                LogDetailedStatus(unit, String::Empty, status);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            free((void *) originalData[pageNumber]);
                        }
                        testingStartStopAllButton->Enabled = GUI_YES;
                        testingStartStopButtonArray[unit->unitNumber]->Enabled = GUI_YES;
                        unit->testsCompleted++;     // Post 1
                        testsCompleted++;
                        free((void *) zeroData);
                        free((void *) testData);
                        free((void *) originalData);
                    }                   // end of if (originalData && testData && zeroData)
                    else
                    {
                        testsPassed = GUI_NO;
                        LogDetailedFailureLine(unit, "    Unable to allocate test buffers");
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                }                       // end of if (keepTesting)
                //------------------------------------------------------------
                // The tests have concluded
                //------------------------------------------------------------
                LogDetailedEntry(unit, "Module Memory Test End Result: ");
                if (keepTesting)
                {
                    if (testsPassed)
                        LogBothSuccessLine(unit, GUI_TEST_PASSED_STRING);
                    else
                        LogBothFailureLine(unit, GUI_TEST_FAILED_STRING);
                }
                else
                {
                    LogBothWarningLine(unit,
                        String::Concat(
                            "Terminated by ",
                            (testsPassed ? _T("user") : terminationSource)));
                }
            }                           // end of if (unit->numberOfModuleMemoryPages)
            else
            {
                testsPassed = GUI_NO;
                String ^failureLine = String::Format(
                    "Transducer {0} has no memory pages available to test",
                    unit->transducerSerialNumber);
                LogDetailedFailureLine(unit, String::Concat("    ", failureLine));
                LogSummaryFailureLine(unit, failureLine);
            }
        }                               // end of if (QCOM_UnitOpen(unit))
        else
        {
            testsPassed = GUI_NO;
            String ^failureLine;
            if (QCOM_XDPresent(unit) && QCOM_XDSNValid(unit))
            {
                failureLine = String::Format(
                    "Failed: module {0} not open for testing with transducer {1}",
                    unit->moduleSerialNumber,
                    unit->transducerSerialNumber);
            }
            else
            {
                failureLine = String::Format(
                    "Failed: module {0} not open for testing",
                    unit->moduleSerialNumber);
            }
            LogDetailedFailureLine(unit, String::Concat("    ", failureLine));
            LogSummaryFailureLine(unit, failureLine);
        }
        unit->testsCompleted += (numberOfTestsToRun - testsCompleted);
        //--------------------------------------------------------------------
        // EC2812: A 2000 ms delay is placed here to allow the firmware to
        // refresh the transducer frequency counts before the next test begins
        //--------------------------------------------------------------------
        Thread::Sleep(2000);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
        //--------------------------------------------------------------------
        // Not much else can be done if the unit pointer is invalid
        //--------------------------------------------------------------------
        testsPassed = GUI_NO;
    }
    return testsPassed;
}                                       // end of QCOM_TestSuiteQMEM()
//----------------------------------------------------------------------------
// QCOM_TestSuiteReadings
//
// Tests the ability of the QCOM device unit to take firmware and transducer
// readings without problems
//
// Returns: GUI_YES     All the tests passed
//          GUI_NO      At least one test failed
//
// Called by:   QCOM_InitiateUnitTests
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_TestSuiteReadings(
    UnitInfo        ^unit)
{
    bool            keepTesting;
    bool            originalDLLMessages = QD_DLLMessagesEnabled;
    bool            testPassed;         // unit section tests
    bool            testsPassed = GUI_YES;
    BYTE            statusRegister;
    WORD            errorCode;
    DWORD           actionFlags = 0;
    DWORD           testsCompleted = 0;
    DWORD           status = QCOM_SUCCESS;
    DOUBLE          current;
    DOUBLE          voltage;
    HANDLE          unitHandle;
    String          ^terminationSource;
    String          ^titleString;
    String          ^functionName = _T("QCOM_TestSuiteReadings");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitHandle = unit->unitHandle;
        //--------------------------------------------------------------------
        // Announce the start of the test
        //--------------------------------------------------------------------
        LogDetailedLine(unit, "Readings Test started");
        LogSummaryEntry(unit, "Readings Test...");
        if (QCOM_UnitReady(unit))
        {
            terminationSource =
                (unit->testFlags & QCOM_UNIT_TEST_STOP_ON_ERRORS) ?
                    _T("error") : _T("user");
            QD_DLLMessagesEnabled = GUI_NO;
            titleString = String::Format(
                "Readings Test for Module {0}",
                unit->moduleSerialNumber);
            //----------------------------------------------------------------
            // P/T Readings Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    P/T Readings Test Begin");
                testPassed = GUI_YES;
                LogDetailedEntry(
                    unit,
                    "        First set of transducer readings ");
                status = QCOM_RetrieveTransducerReadings(unit);
                if (status == QCOM_SUCCESS)
                {
                    LogDetailedLine(unit, "succeeded");
                    if (!unit->pressureCount || !unit->temperatureCount)
                    {
                        testPassed = GUI_NO;
                        LogDetailedFailureLine(
                            unit,
                            "        Zero: Pressure Count = {0:D} / Temperature Count = {1:D}",
                            unit->pressureCount,
                            unit->temperatureCount);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    if ((unit->pressureCount < 1000000) || (unit->temperatureCount < 1000000))
                    {
                        testPassed = GUI_NO;
                        LogDetailedFailureLine(
                            unit,
                            "        Too Low: Pressure Count = {0:D} / Temperature Count = {1:D}",
                            unit->pressureCount,
                            unit->temperatureCount);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    if ((unit->pressureValuePSI == 0.0) || (unit->temperatureValueCelsius == 0.0))
                    {
                        testPassed = GUI_NO;
                        LogDetailedFailureLine(
                            unit,
                            "        Zero: Pressure = {0:F1} psi / Temperature = {1:F1} �C",
                            unit->pressureValuePSI,
                            unit->temperatureValueCelsius);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    if ((unit->pressureValuePSI < 5.0) || (unit->temperatureValueCelsius < 10.0))
                    {
                        testPassed = GUI_NO;
                        LogDetailedFailureLine(
                            unit,
                            "        Too Low: Pressure = {0:F1} psi / Temperature = {1:F1} �C",
                            unit->pressureValuePSI,
                            unit->temperatureValueCelsius);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    QCOM_WaitMS(2400);  // wait 2.4 seconds
                    QCOM_CheckActiveTesting(unit, keepTesting);
                    if (keepTesting)
                    {
                        LogDetailedEntry(
                            unit,
                            "        Second set of transducer readings ");
                        status = QCOM_RetrieveTransducerReadings(unit);
                        if (status == QCOM_SUCCESS)
                        {
                            LogDetailedLine(unit, "succeeded");
                            if (!unit->pressureCount || !unit->temperatureCount)
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "        Zero: Pressure Count = {0:D} / Temperature Count = {1:D}",
                                    unit->pressureCount,
                                    unit->temperatureCount);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            if ((unit->pressureCount < 1000000) || (unit->temperatureCount < 1000000))
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "        Too Low: Pressure Count = {0:D} / Temperature Count = {1:D}",
                                    unit->pressureCount,
                                    unit->temperatureCount);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            if ((unit->pressureValuePSI == 0.0) || (unit->temperatureValueCelsius == 0.0))
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "        Zero: Pressure = {0:F1} psi / Temperature = {1:F1} �C",
                                    unit->pressureValuePSI,
                                    unit->temperatureValueCelsius);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            if ((unit->pressureValuePSI < 5.0) || (unit->temperatureValueCelsius < 10.0))
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "        Too Low: Pressure = {0:F1} psi / Temperature = {1:F1} �C",
                                    unit->pressureValuePSI,
                                    unit->temperatureValueCelsius);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                        }
                        else
                        {
                            testPassed = GUI_NO;
                            LogDetailedStatus(unit, String::Empty, status);
                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                        }
                    }
                }
                else
                {
                    testPassed = GUI_NO;
                    LogDetailedStatus(unit, String::Empty, status);
                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                }
                LogDetailedEntry(
                    unit,
                    "    P/T Readings Test End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // V/I Readings Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    V/I Readings Test Begin");
                testPassed = GUI_YES;
                status = QD_SetTransducerPowerState(
                    unitHandle,
                    QD_DISABLE_TRANSDUCER_POWER);
                if (status)
                {
                    testPassed = GUI_NO;
                    LogDetailedStatus(
                        unit,
                        "        Disabling transducer power ",
                        status);
                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                }
                QCOM_PromptOKModal(titleString,
                    "Remove the transducer from module {0}\n"
                    "and attach the 503 ohm resistor plug, then click OK",
                    unit->moduleSerialNumber);
                status = QD_SetTransducerPowerState(
                    unitHandle,
                    QD_ENABLE_TRANSDUCER_POWER);
                if (status)
                {
                    testPassed = GUI_NO;
                    LogDetailedStatus(
                        unit,
                        "        Enabling transducer power ",
                        status);
                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                }
                Thread::Sleep(100);
                QCOM_CheckActiveTesting(unit, keepTesting);
                if (keepTesting)
                {
                    status = QD_GetTransducerVoltage(unitHandle, &voltage);
                    if (status)
                    {
                        testPassed = GUI_NO;
                        LogDetailedStatus(
                            unit,
                            "        QD_GetTransducerVoltage ",
                            status);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    Thread::Sleep(100);
                }
                QCOM_CheckActiveTesting(unit, keepTesting);
                if (keepTesting)
                {
                    status = QD_GetTransducerCurrent(unitHandle, &current);
                    if (status)
                    {
                        testPassed = GUI_NO;
                        LogDetailedStatus(
                            unit,
                            "        QD_GetTransducerCurrent ",
                            status);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    Thread::Sleep(100);
                }
                QCOM_CheckActiveTesting(unit, keepTesting);
                if (keepTesting)
                {
                    LogDetailedEntry(unit, "        Voltage Reading Test ");
                    if ((voltage < 4.8) || (voltage > 5.2))
                    {
                        testPassed = GUI_NO;
                        LogDetailedFailureLine(
                            unit,
                            "failed with a voltage of {0:F2} V, and should be 5.00 V +/- 0.2 V",
                            voltage);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    else
                    {
                        LogDetailedLine(unit, "succeeded at {0:F2} V", voltage);
                    }
                    LogDetailedEntry(unit, "        Current Reading Test ");
                    if ((current < 9.5) || (current > 10.5))
                    {
                        testPassed = GUI_NO;
                        LogDetailedFailureLine(
                            unit,
                            "failed with a current of {0:F2} mA, and should be 10.00 mA +/- 0.4 mA",
                            current);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    else
                    {
                        LogDetailedLine(unit, "succeeded at {0:F2} mA", current);
                    }
                    status = QD_SetTransducerPowerState(
                        unitHandle,
                        QD_DISABLE_TRANSDUCER_POWER);
                    if (status)
                    {
                        testPassed = GUI_NO;
                        LogDetailedStatus(
                            unit,
                            "        Disabling transducer power ",
                            status);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    QCOM_PromptOKModal(titleString,
                        "Remove the 503 ohm resistor plug from module {0}\n"
                        "and re-attach the transducer, then click OK",
                        unit->moduleSerialNumber);
                    status = QD_SetTransducerPowerState(
                        unitHandle,
                        QD_ENABLE_TRANSDUCER_POWER);
                    if (status)
                    {
                        testPassed = GUI_NO;
                        LogDetailedStatus(
                            unit,
                            "        Enabling transducer power ",
                            status);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                }
                QD_SetTransducerPowerState(
                    unitHandle,
                    QD_ENABLE_TRANSDUCER_POWER);
                LogDetailedEntry(
                    unit,
                    "    V/I Readings Test End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Overcurrent Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Overcurrent Test Begin");
                testPassed = GUI_YES;
                status = QD_SetTransducerPowerState(
                    unitHandle,
                    QD_DISABLE_TRANSDUCER_POWER);
                if (status)
                {
                    testPassed = GUI_NO;
                    LogDetailedStatus(
                        unit,
                        "        Disabling transducer power ",
                        status);
                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                }
                QCOM_PromptOKModal(titleString,
                    "Remove the transducer from module {0}\n"
                    "and attach the 150 ohm resistor plug, then click OK",
                    unit->moduleSerialNumber);
                status = QD_SetTransducerPowerState(
                    unitHandle,
                    QD_ENABLE_TRANSDUCER_POWER);
                if (status)
                {
                    testPassed = GUI_NO;
                    LogDetailedStatus(
                        unit,
                        "        Enabling transducer power ",
                        status);
                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                }
                Thread::Sleep(100);
                QCOM_CheckActiveTesting(unit, keepTesting);
                if (keepTesting)
                {
                    status = QD_GetModuleStatusRegister(
                        unitHandle,
                        (LPBYTE) &statusRegister);
                    if (status == QD_SUCCESS)
                    {
                        LogDetailedEntry(
                            unit,
                            "        The QCOM Status Register ");
                        //----------------------------------------------------
                        // The OVER_CURRENT bit (0x10) in the Status Register
                        // is not useful for testing, primarily because it
                        // triggers the firmware to disable power to the
                        // transducer immediately, which in turn clears the
                        // OVER_CURRENT bit.  So, to test for over-current,
                        // check the ERROR_PRESENT (0x80) bit in the Status
                        // Register, plus the QCOM Error Code, both of which
                        // should be set in an over-current condition.
                        //----------------------------------------------------
//                        if (statusRegister & QD_SREG_TRANSDUCER_OVER_CURRENT)
                        if (statusRegister & QD_SREG_ERROR_PRESENCE)
                        {
                            LogDetailedLine(
                                unit,
                                "successfully reported the overcurrent error");
                        }
                        else
                        {
                            testPassed = GUI_NO;
                            LogDetailedFailureLine(
                                unit,
                                "failed to report the overcurrent error");
                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                        }
                    }
                    else
                    {
                        testPassed = GUI_NO;
                        LogDetailedStatus(
                            unit,
                            "        QD_GetModuleStatusRegister ",
                            status);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    Thread::Sleep(100);
                    status = QD_GetInternalErrorCode(
                        unitHandle,
                        (LPWORD) &errorCode);
                    if (status == QD_SUCCESS)
                    {
                        LogDetailedEntry(
                            unit,
                            "        The QCOM Internal Error Code ");
                        if (errorCode)
                        {
                            LogDetailedLine(
                                unit,
                                "successfully reported the overcurrent error (0x{0:X4})",
                                errorCode);
                            status = QD_ClearInternalError(unitHandle);
                            if (status == QD_SUCCESS)
                            {
                                Thread::Sleep(10);
                                status = QD_GetInternalErrorCode(
                                    unitHandle,
                                    (LPWORD) &errorCode);
                                if (status == QD_SUCCESS)
                                {
                                    LogDetailedEntry(
                                        unit,
                                        "        The software ");
                                    if (errorCode)
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedFailureLine(
                                            unit,
                                            "failed to clear the overcurrent error");
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                    else
                                    {
                                        LogDetailedLine(
                                            unit,
                                            "successfully cleared the overcurrent error");
                                    }
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(
                                        unit,
                                        "        QD_GetInternalErrorCode ",
                                        status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                Thread::Sleep(100);
                            }
                            else
                            {
                                testPassed = GUI_NO;
                                LogDetailedStatus(
                                    unit,
                                    "        QD_ClearInternalError ",
                                    status);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                        }
                        else
                        {
                            testPassed = GUI_NO;
                            LogDetailedFailureLine(
                                unit,
                                "failed to report the overcurrent error");
                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                        }
                    }
                    else
                    {
                        testPassed = GUI_NO;
                        LogDetailedStatus(
                            unit,
                            "        QD_GetInternalErrorCode ",
                            status);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    Thread::Sleep(100);
                    status = QD_SetTransducerPowerState(
                        unitHandle,
                        QD_DISABLE_TRANSDUCER_POWER);
                    if (status)
                    {
                        testPassed = GUI_NO;
                        LogDetailedStatus(
                            unit,
                            "        Disabling transducer power ",
                            status);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    QCOM_PromptOKModal(titleString,
                        "Remove the 150 ohm resistor plug from module {0}\n"
                        "and re-attach the transducer, then click OK",
                        unit->moduleSerialNumber);
                    status = QD_SetTransducerPowerState(
                        unitHandle,
                        QD_ENABLE_TRANSDUCER_POWER);
                    if (status)
                    {
                        testPassed = GUI_NO;
                        LogDetailedStatus(
                            unit,
                            "        Enabling transducer power ",
                            status);
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                    Thread::Sleep(100);
                }
                QD_SetTransducerPowerState(
                    unitHandle,
                    QD_ENABLE_TRANSDUCER_POWER);
                LogDetailedEntry(
                    unit,
                    "    Overcurrent Test End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }                           // end of if (keepTesting)
            //----------------------------------------------------------------
            // Section 4 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 4 Begin");
                testPassed = GUI_YES;
                // TODO: Test 4
                LogDetailedEntry(
                    unit,
                    "    Section 4 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 5 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 5 Begin");
                testPassed = GUI_YES;
                // TODO: Test 5
                LogDetailedEntry(
                    unit,
                    "    Section 5 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // The tests have concluded
            //----------------------------------------------------------------
            LogDetailedEntry(unit, "Readings Test End Result: ");
            if (keepTesting)
            {
                if (testsPassed)
                    LogBothSuccessLine(unit, GUI_TEST_PASSED_STRING);
                else
                    LogBothFailureLine(unit, GUI_TEST_FAILED_STRING);
            }
            else
            {
                LogBothWarningLine(unit,
                    String::Concat(
                        "Terminated by ",
                        (testsPassed ? _T("user") : terminationSource)));
            }
        }                               // end of if (QCOM_UnitReady(unit))
        else
        {
            testsPassed = GUI_NO;
            String ^failureLine;
            if (QCOM_XDPresent(unit) && QCOM_XDSNValid(unit))
            {
                failureLine = String::Format(
                    "Failed: module {0} not ready for testing with transducer {1}",
                    unit->moduleSerialNumber,
                    unit->transducerSerialNumber);
            }
            else
            {
                failureLine = String::Format(
                    "Failed: module {0} requires a transducer for testing",
                    unit->moduleSerialNumber);
            }
            LogDetailedFailureLine(unit, String::Concat("    ", failureLine));
            LogSummaryFailureLine(unit, failureLine);
        }
        unit->testsCompleted += (GUI_NUMBER_OF_READINGS_TESTS - testsCompleted);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
        //--------------------------------------------------------------------
        // Not much else can be done if the unit pointer is invalid
        //--------------------------------------------------------------------
        testsPassed = GUI_NO;
    }
    return testsPassed;
}                                       // end of QCOM_TestSuiteReadings()
//----------------------------------------------------------------------------
// QCOM_TestSuiteTransducerCommunication
//
// Runs the Transducer Communication Test
//
// Returns: GUI_YES     All the tests passed
//          GUI_NO      At least one test failed
//
// Called by:   QCOM_InitiateUnitTests
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_TestSuiteTransducerCommunication(
    UnitInfo        ^unit)
{
    bool            keepTesting;
    bool            originalDLLMessages = QD_DLLMessagesEnabled;
    bool            testPassed;             // unit section tests
    bool            testsPassed = GUI_YES;
    int             dotCount;
    BYTE            transducerType = QD_TRANSDUCER_TYPE_ABSENT;                 // 0
    DWORD           status;
    DWORD           testsCompleted = 0;
    String          ^terminationSource;
    String          ^functionName = _T("QCOM_TestSuiteTransducerCommunication");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        //--------------------------------------------------------------------
        // Announce the start of the test
        //--------------------------------------------------------------------
        LogDetailedLine(unit, "Transducer Communication Test started");
        LogSummaryEntry(unit, "Transducer Communication Test...");
        if (QCOM_UnitReady(unit))
        {
            terminationSource =
                (unit->testFlags & QCOM_UNIT_TEST_STOP_ON_ERRORS) ?
                    _T("error") : _T("user");
            QD_DLLMessagesEnabled = GUI_NO;
            //----------------------------------------------------------------
            // Section 1 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Basic Commands Begin");
                testPassed = GUI_YES;
                LogDetailedEntry(
                    unit,
                    "        Rapid succession of Get Transducer Type commands...");
                for (int count = dotCount = 0; keepTesting && testPassed && (count < 100); count++)
                {
                    status = QD_GetTransducerType(
                        unit->unitHandle,
                        &transducerType);
                    if (status == QD_SUCCESS)
                    {
                        if (transducerType != (BYTE) unit->transducerType)
                        {
                            testPassed = GUI_NO;
                            LogDetailedFailureLine(
                                unit,
                                "        Incorrect transducer type {0:D} returned (should be {1:D})",
                                (DWORD) transducerType,
                                unit->transducerType);
                        }
                    }
                    else
                    {
                        testPassed = GUI_NO;
                        LogDetailedFailureLine(
                            unit,
                            "        QD_GetTransducerType returned status 0x{0:X8}",
                            status);
                    }
                    if (dotCount > 10)
                        dotCount = 0;
                    if (testPassed && !dotCount++)
                        LogDetailedDot(unit);
                    Thread::Sleep(10);
                    QCOM_CheckActiveTesting(unit, keepTesting);
                }                       // end of for (int count = dotCount = 0; ...)
                if (testPassed)
                {
                    LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                }
                LogDetailedEntry(
                    unit,
                    "    Basic Commands End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 2 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 2 Begin");
                testPassed = GUI_YES;
                // TODO: Test 2
                LogDetailedEntry(
                    unit,
                    "    Section 2 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 3 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 3 Begin");
                testPassed = GUI_YES;
                // TODO: Test 3
                LogDetailedEntry(
                    unit,
                    "    Section 3 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 4 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 4 Begin");
                testPassed = GUI_YES;
                // TODO: Test 4
                LogDetailedEntry(
                    unit,
                    "    Section 4 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 5 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 5 Begin");
                testPassed = GUI_YES;
                // TODO: Test 5
                LogDetailedEntry(
                    unit,
                    "    Section 5 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // The tests have concluded
            //----------------------------------------------------------------
            LogDetailedEntry(
                unit,
                "Transducer Communication Test End Result: ");
            if (keepTesting)
            {
                if (testsPassed)
                    LogBothSuccessLine(unit, GUI_TEST_PASSED_STRING);
                else
                    LogBothFailureLine(unit, GUI_TEST_FAILED_STRING);
            }
            else
            {
                LogBothWarningLine(unit,
                    String::Concat(
                        "Terminated by ",
                        (testsPassed ? _T("user") : terminationSource)));
            }
            QD_DLLMessagesEnabled = originalDLLMessages;
        }                               // end of if (QCOM_UnitReady(unit))
        else
        {
            testsPassed = GUI_NO;
            String ^failureLine;
            if (QCOM_XDPresent(unit) && QCOM_XDSNValid(unit))
            {
                failureLine = String::Format(
                    "Failed: module {0} not ready for testing with transducer {1}",
                    unit->moduleSerialNumber,
                    unit->transducerSerialNumber);
            }
            else
            {
                failureLine = String::Format(
                    "Failed: module {0} requires a transducer for testing",
                    unit->moduleSerialNumber);
            }
            LogDetailedFailureLine(unit, String::Concat("    ", failureLine));
            LogSummaryFailureLine(unit, failureLine);
        }
        unit->testsCompleted += (GUI_NUMBER_OF_XD_COMM_TESTS - testsCompleted);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        //--------------------------------------------------------------------
        // Not much else can be done if the unit pointer is invalid
        //--------------------------------------------------------------------
        testsPassed = GUI_NO;
        GUI_DisplaySimpleError(functionName, "Unit pointer is invalid");
    }
    return testsPassed;
}                                       // end of QCOM_TestSuiteTransducerCommunication()
//----------------------------------------------------------------------------
// QCOM_TestSuiteTransducerIntegrity
//
// Runs the Transducer Integrity Test suite
//
// Returns: GUI_YES     All the tests passed
//          GUI_NO      At least one test failed
//
// Called by:   QCOM_InitiateUnitTests
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_TestSuiteTransducerIntegrity(
    UnitInfo        ^unit)
{
    bool            keepTesting;
    bool            originalDLLMessages = QD_DLLMessagesEnabled;
    bool            testPassed;         // unit section tests
    bool            testsPassed = GUI_YES;
//    int             address;
//    int             count;
//    int             index;
    int             dotCount;
    int             memoryOffset;
    int             XDType = 0;
    char            *commandString;
    char            *i2cCommand[][4] =
    {
        //  Digital w/o chksum    Analog w/o chksum   Module w/o chksum   Digital no-memory
        { "SADFFFFFFP",         "SA3FFFFFFP",       "SADFFFFFFP",       "SADFFFFFFP"        },  // Read ASIC Current Address
        { "SAC0000RADFFP",      "SA20000RA3FFP",    "SAC0000RADFFP",    "SAC0000RADFFP"     },  // Read ASIC Specific Address 0000 - 1 byte
        { "S9C1FP",             "S981FP",           "S9C1FP",           "S9C1FP"            },  // Unlock memory
        { "S9C3FP",             "S983FP",           "S9C3FP",           "S9C3FP"            },  // Lock memory
        { "SAC0000XXP",         "SA20000XXP",       "SAC0000XXP",       "SAC0000XXP"        },  // Write memory
        { "S9CR9FFFP",          "S98R9BFFP",        "S9CR9FFFP",        "S9CR9FFFP"         },  // Read status
        { "S9CR9DFFFFFFFFP",    "S98R99FFFFFFFFP",  "S9CR9DFFFFFFFFP",  "S9CR9DFFFFFFFFP"   },  // Get chip ID
        { 0, 0 }
    };
    char            *replyString;
    char            *testCommand;
    BYTE            readValue;
    BYTE            statusValue;
    BYTE            writeValue;
    BYTE            *XDMemoryCopy;
    long            memorySize;
    DWORD           status;
    DWORD           testsCompleted = 0;
    HANDLE          unitHandle;
    Random          ^randomNumber = gcnew Random();
    String          ^terminationSource;
    String          ^XDChipType;
    String          ^XDTypeString;
    String          ^functionName = _T("QCOM_TestSuiteTransducerIntegrity");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitHandle = unit->unitHandle;
        XDTypeString = QCOM_XDIsFrequency(unit) ? _T("Frequency (Analog)") : _T("Digital");
        //--------------------------------------------------------------------
        // Announce the start of the test
        //--------------------------------------------------------------------
        LogDetailedLine(unit, "{0} Transducer Integrity Test started", XDTypeString);
        LogSummaryEntry(unit, "{0} Transducer Integrity Test...", XDTypeString);
        if (QCOM_UnitReady(unit))
        {
            terminationSource =
                (unit->testFlags & QCOM_UNIT_TEST_STOP_ON_ERRORS) ?
                    _T("error") : _T("user");
            switch (unit->transducerType)
            {
                case QD_TRANSDUCER_TYPE_ABSENT :                                // 0
                    XDType = 2;
                    keepTesting = GUI_NO;
                    break;
                case QD_TRANSDUCER_TYPE_FREQUENCY :                             // 1
                    XDType = 1;
                    break;
                case QD_TRANSDUCER_TYPE_DIGITAL_NOMEM :                         // 5
                    XDType = 3;
                    break;
                default :
                    if (unit->transducerMemorySize == 0)
                        XDType = 3;
                    break;
            }                           // end of switch (unit->transducerType)
            XDChipType = 
                (unit->transducerChipID[1] == QD_TRANSDUCER_CHIP_ASIC) ?
                    _T("ASIC") : _T("FPGA");
            if (unit->transducerMemorySize)
                memorySize = unit->transducerMemorySize;
            else
                memorySize = unit->moduleMemorySize;
            QD_DLLMessagesEnabled = GUI_NO;
            commandString = (char *) malloc(QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE);
            replyString = (char *) malloc(QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
            XDMemoryCopy = (BYTE *) malloc(memorySize);
            if (commandString && replyString && XDMemoryCopy && memorySize)
            {
                ClearBuffer(commandString, QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE);
                ClearBuffer(replyString, QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE);
                if (XDType == 0)
                {
                    //--------------------------------------------------------
                    // Read Current Address Test
                    //--------------------------------------------------------
                    QCOM_CheckActiveTesting(unit, keepTesting);
                    if (keepTesting)
                    {
                        LogDetailedLine(unit, "    Read Current Address Test Begin");
                        testPassed = GUI_YES;
                        LogDetailedEntry(
                            unit,
                            "        Rapid succession of Read Current Address commands...");
                        for (int count = dotCount = 0; keepTesting && testPassed && (count < 256); count++)
                        {
                            testCommand = i2cCommand[0][XDType];
                            strcpy_s(
                                commandString,
                                QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                testCommand);
                            status = QD_ExecuteI2CCommand(
                                unitHandle,
                                (LPBYTE) commandString,
                                (LPBYTE) replyString);
                            if (status == QD_SUCCESS)
                            {
                                if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                {
                                    replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                }
                                if ((replyString[0] != 'S') ||
                                    (strlen(replyString) != strlen(testCommand)) ||
                                    (replyString[strlen(replyString) - 1] != 'P') ||
                                    (replyString[strlen(replyString) - 2] == 'N'))
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedFailureLine(
                                        unit,
                                        "failed during iteration {0:D}: Command {1} => Reply {2}",
                                        count,
                                        gcnew String(commandString),
                                        gcnew String(replyString));
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                            }
                            else
                            {
                                testPassed = GUI_NO;
                                LogDetailedStatus(unit, String::Empty, status);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            if (dotCount > 16)
                                dotCount = 0;
                            if (testPassed && !dotCount++)
                                LogDetailedDot(unit);
                            Thread::Sleep(10);
                            QCOM_CheckActiveTesting(unit, keepTesting);
                        }               // end of for (int count = dotCount = 0; ...)
                        if (testPassed)
                        {
                            LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                        }
                        LogDetailedEntry(
                            unit,
                            "    Read Current Address Test End: ");
                        if (testPassed)
                        {
                            LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                        }
                        else
                        {
                            LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                            testsPassed = GUI_NO;
                        }
                        unit->testsCompleted++;
                        testsCompleted++;
                        Thread::Sleep(100);
                    }
                    //--------------------------------------------------------
                    // Memory Ramp-up Test
                    //--------------------------------------------------------
                    QCOM_CheckActiveTesting(unit, keepTesting);
                    if (keepTesting)
                    {
                        LogDetailedLine(unit, "    Memory Ramp-up Test Begin");
                        testPassed = GUI_YES;
                        LogDetailedEntry(
                            unit,
                            String::Format(
                                _T("        Reading memory addresses\n            0x0000 to 0x{0:X4}..."),
                                (memorySize - 1)));
                        testCommand = i2cCommand[1][XDType];
                        strcpy_s(
                            commandString,
                            QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                            testCommand);
                        for (int address = memoryOffset = dotCount = 0; keepTesting && testPassed && (address < memorySize); address++)
                        {
                            commandString[4] = XtoA((address & 0xF00) >> 8);
                            commandString[5] = XtoA((address & 0x0F0) >> 4);
                            commandString[6] = XtoA(address & 0x00F);
                            status = QD_ExecuteI2CCommand(
                                unitHandle,
                                (LPBYTE) commandString,
                                (LPBYTE) replyString);
                            if (status == QD_SUCCESS)
                            {
                                if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                {
                                    replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                }
                                if ((replyString[0] != 'S') ||
                                    (strlen(replyString) != strlen(testCommand)) ||
                                    (replyString[strlen(replyString) - 1] != 'P') ||
                                    (replyString[strlen(replyString) - 2] == 'N'))
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedFailureLine(
                                        unit,
                                        "failed at address {0:X4}: Command {1} => Reply {2}",
                                        address,
                                        gcnew String(commandString),
                                        gcnew String(replyString));
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                else
                                {
                                    XDMemoryCopy[memoryOffset++] =
                                        (AtoX(replyString[10]) << 4) | AtoX(replyString[11]);
                                }
                            }
                            else
                            {
                                testPassed = GUI_NO;
                                LogDetailedStatus(unit, String::Empty, status);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            if (dotCount > 256)
                                dotCount = 0;
                            if (testPassed && !dotCount++)
                                LogDetailedDot(unit);
                            Thread::Sleep(10);
                            QCOM_CheckActiveTesting(unit, keepTesting);
                        }               // end of for (int address = dotCount = 0; ...)
                        if (testPassed)
                        {
                            LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                        }
                        LogDetailedEntry(
                            unit,
                            "    Memory Ramp-up Test End: ");
                        if (testPassed)
                        {
                            LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                        }
                        else
                        {
                            LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                            testsPassed = GUI_NO;
                        }
                        unit->testsCompleted++;
                        testsCompleted++;
                        Thread::Sleep(100);
                    }
                    //--------------------------------------------------------
                    // Memory Ramp-down Test
                    //--------------------------------------------------------
                    QCOM_CheckActiveTesting(unit, keepTesting);
                    if (keepTesting)
                    {
                        LogDetailedLine(unit, "    Memory Ramp-down Test Begin");
                        testPassed = GUI_YES;
                        LogDetailedEntry(
                            unit,
                            String::Format(
                                _T("        Reading memory addresses\n            0x{0:X4} to 0x0000..."),
                                (memorySize - 1)));
                        testCommand = i2cCommand[1][XDType];
                        strcpy_s(
                            commandString,
                            QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                            testCommand);
                        dotCount = 0;
                        for (int address = memorySize - 1; keepTesting && testPassed && (address >= 0); address--)
                        {
                            commandString[4] = XtoA((address & 0xF00) >> 8);
                            commandString[5] = XtoA((address & 0x0F0) >> 4);
                            commandString[6] = XtoA(address & 0x00F);
                            status = QD_ExecuteI2CCommand(
                                unitHandle,
                                (LPBYTE) commandString,
                                (LPBYTE) replyString);
                            if (status == QD_SUCCESS)
                            {
                                if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                {
                                    replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                }
                                if ((replyString[0] != 'S') ||
                                    (strlen(replyString) != strlen(testCommand)) ||
                                    (replyString[strlen(replyString) - 1] != 'P') ||
                                    (replyString[strlen(replyString) - 2] == 'N'))
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedFailureLine(
                                        unit,
                                        "failed at address {0:X4}: Command {1} => Reply {2}",
                                        address,
                                        gcnew String(commandString),
                                        gcnew String(replyString));
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                            }
                            else
                            {
                                testPassed = GUI_NO;
                                LogDetailedStatus(unit, String::Empty, status);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            if (dotCount > 256)
                                dotCount = 0;
                            if (testPassed && !dotCount++)
                                LogDetailedDot(unit);
                            Thread::Sleep(10);
                            QCOM_CheckActiveTesting(unit, keepTesting);
                        }               // end of for (int address = 1023; ...)
                        if (testPassed)
                        {
                            LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                        }
                        LogDetailedEntry(
                            unit,
                            "    Memory Ramp-down Test End: ");
                        if (testPassed)
                        {
                            LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                        }
                        else
                        {
                            LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                            testsPassed = GUI_NO;
                        }
                        unit->testsCompleted++;
                        testsCompleted++;
                        Thread::Sleep(100);
                    }
                    //--------------------------------------------------------
                    // Random Memory Test
                    //--------------------------------------------------------
                    QCOM_CheckActiveTesting(unit, keepTesting);
                    if (keepTesting)
                    {
                        LogDetailedLine(unit, "    Random Memory Test Begin");
                        testPassed = GUI_YES;
                        LogDetailedEntry(
                            unit,
                            "        Reading from random addresses...");
                        testCommand = i2cCommand[1][XDType];
                        strcpy_s(
                            commandString,
                            QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                            testCommand);
                        for (int count = dotCount = 0; keepTesting && testPassed && (count < 256); count++)
                        {
                            int address = randomNumber->Next() % memorySize;
                            commandString[4] = XtoA((address & 0xF00) >> 8);
                            commandString[5] = XtoA((address & 0x0F0) >> 4);
                            commandString[6] = XtoA(address & 0x00F);
                            status = QD_ExecuteI2CCommand(
                                unitHandle,
                                (LPBYTE) commandString,
                                (LPBYTE) replyString);
                            if (status == QD_SUCCESS)
                            {
                                if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                {
                                    replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                }
                                if ((replyString[0] != 'S') ||
                                    (strlen(replyString) != strlen(testCommand)) ||
                                    (replyString[strlen(replyString) - 1] != 'P') ||
                                    (replyString[strlen(replyString) - 2] == 'N'))
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedFailureLine(
                                        unit,
                                        "failed at address {0:X4}: Command {1} => Reply {2}",
                                        address,
                                        gcnew String(commandString),
                                        gcnew String(replyString));
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                            }
                            else
                            {
                                testPassed = GUI_NO;
                                LogDetailedStatus(unit, String::Empty, status);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            if (dotCount > 16)
                                dotCount = 0;
                            if (testPassed && !dotCount++)
                                LogDetailedDot(unit);
                            Thread::Sleep(10);
                            QCOM_CheckActiveTesting(unit, keepTesting);
                        }               // end of for (int count = dotCount = 0; ...)
                        if (testPassed)
                        {
                            LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                        }
                        LogDetailedEntry(
                            unit,
                            "    Random Memory Test End: ");
                        if (testPassed)
                        {
                            LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                        }
                        else
                        {
                            LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                            testsPassed = GUI_NO;
                        }
                        unit->testsCompleted++;
                        testsCompleted++;
                        Thread::Sleep(100);
                    }
                    //--------------------------------------------------------
                    // Write Memory Test
                    //--------------------------------------------------------
                    QCOM_CheckActiveTesting(unit, keepTesting);
                    if (keepTesting)
                    {
                        LogDetailedLine(unit, "    Write Memory Test Begin");
//                    testPassed = GUI_YES;
//                    //----------------------------------------------------
//                    // First, make a copy of transducer memory
//                    //----------------------------------------------------
//                    LogDetailedEntry(
//                        unit,
//                        String::Format(
//                            "        Backing up memory addresses\n            0x0000 to 0x{0:X4}...",
//                            (memorySize - 1)));
//                    testCommand = i2cCommand[1][XDType];
//                    strcpy_s(
//                        commandString,
//                        QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
//                        testCommand);
//                    for (int address = memoryOffset = dotCount = 0; keepTesting && testPassed && (address < memorySize); address++)
//                    {
//                        commandString[4] = XtoA((address & 0xF00) >> 8);
//                        commandString[5] = XtoA((address & 0x0F0) >> 4);
//                        commandString[6] = XtoA(address & 0x00F);
//                        status = QD_ExecuteI2CCommand(
//                            unitHandle,
//                            (LPBYTE) commandString,
//                            (LPBYTE) replyString);
//                        if (status == QD_SUCCESS)
//                        {
//                            if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
//                            {
//                                replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
//                            }
//                            if ((replyString[0] != 'S') ||
//                                (strlen(replyString) != strlen(testCommand)) ||
//                                (replyString[strlen(replyString) - 1] != 'P') ||
//                                (replyString[strlen(replyString) - 2] == 'N'))
//                            {
//                                testPassed = GUI_NO;
//                                LogDetailedFailureLine(
//                                    unit,
//                                    "failed at address {0:X4}: Command {1} => Reply {2}",
//                                    address,
//                                    gcnew String(commandString),
//                                    gcnew String(replyString));
//                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
//                            }
//                            else
//                            {
//                                XDMemoryCopy[memoryOffset++] =
//                                    (AtoX(replyString[10]) << 4) | AtoX(replyString[11]);
//                            }
//                        }
//                        else
//                        {
//                            testPassed = GUI_NO;
//                            LogDetailedStatus(unit, String::Empty, status);
//                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
//                        }
//                        if (dotCount > 256)
//                            dotCount = 0;
//                        if (testPassed && !dotCount++)
//                            LogDetailedDot(unit);
//                        Thread::Sleep(10);
//                        QCOM_CheckActiveTesting(unit, keepTesting);
//                    }               // end of for (int address = memoryOffset = dotCount = 0; ...)
//                    if (testPassed)
//                    {
//                        LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
//                    }
//                    testPassed = GUI_YES;
                        //----------------------------------------------------
                        // Zero out the transducer memory
                        //----------------------------------------------------
                        LogDetailedEntry(
                            unit,
                            String::Format(
                                "        Clearing memory addresses\n            0x0000 to 0x{0:X4}...",
                                (memorySize - 1)));
                        //----------------------------------------------------
                        // Unlock the memory
                        //----------------------------------------------------
                        testPassed = GUI_YES;
                        testCommand = i2cCommand[2][XDType];
                        strcpy_s(
                            commandString,
                            QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                            testCommand);
                        status = QD_ExecuteI2CCommand(
                            unitHandle,
                            (LPBYTE) commandString,
                            (LPBYTE) replyString);
                        if (status == QD_SUCCESS)
                        {
                            if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                            {
                                replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                            }
                            if ((replyString[0] != 'S') ||
                                (strlen(replyString) != strlen(testCommand)) ||
                                (replyString[strlen(replyString) - 1] != 'P') ||
                                (replyString[strlen(replyString) - 2] == 'N'))
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "failed performing Memory Unlock: Command {0} => Reply {1}",
                                    gcnew String(commandString),
                                    gcnew String(replyString));
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            else
                            {
                                //--------------------------------------------
                                // Read the transducer status
                                //--------------------------------------------
                                testCommand = i2cCommand[5][XDType];
                                strcpy_s(
                                    commandString,
                                    QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                    testCommand);
                                status = QD_ExecuteI2CCommand(
                                    unitHandle,
                                    (LPBYTE) commandString,
                                    (LPBYTE) replyString);
                                if (status == QD_SUCCESS)
                                {
                                    if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                    {
                                        replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                    }
                                    if ((replyString[0] != 'S') ||
                                        (strlen(replyString) != strlen(testCommand)) ||
                                        (replyString[strlen(replyString) - 1] != 'P') ||
                                        (replyString[strlen(replyString) - 2] == 'N'))
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedFailureLine(
                                            unit,
                                            "failed performing Read Status: Command {0} => Reply {1}",
                                            gcnew String(commandString),
                                            gcnew String(replyString));
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                    else
                                    {
                                        statusValue = (AtoX(replyString[6]) << 4) | AtoX(replyString[7]);
                                        if ((statusValue & 0xFF) == 0xDF)
                                        {
                                            //--------------------------------
                                            // The Write Protected bit is
                                            // cleared, so write to the memory
                                            //--------------------------------
                                            writeValue = 0;
                                            for (int address = dotCount = 0; keepTesting && testPassed && (address < memorySize); address++)
                                            {
                                                testCommand = i2cCommand[4][XDType];
                                                strcpy_s(
                                                    commandString,
                                                    QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                                    testCommand);
                                                commandString[4] = XtoA((address & 0xF00) >> 8);
                                                commandString[5] = XtoA((address & 0x0F0) >> 4);
                                                commandString[6] = XtoA(address & 0x00F);
                                                commandString[7] = XtoA(writeValue >> 4);
                                                commandString[8] = XtoA(writeValue);
                                                status = QD_ExecuteI2CCommand(
                                                    unitHandle,
                                                    (LPBYTE) commandString,
                                                    (LPBYTE) replyString);
                                                if (status == QD_SUCCESS)
                                                {
                                                    if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                                    {
                                                        replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                                    }
                                                    if ((replyString[0] != 'S') ||
                                                        (strlen(replyString) != strlen(testCommand)) ||
                                                        (replyString[strlen(replyString) - 1] != 'P') ||
                                                        (replyString[strlen(replyString) - 2] == 'N'))
                                                    {
                                                        testPassed = GUI_NO;
                                                        LogDetailedFailureLine(
                                                            unit,
                                                            "failed at address {0:X4} performing Memory Write: Command {1} => Reply {2}",
                                                            address,
                                                            gcnew String(commandString),
                                                            gcnew String(replyString));
                                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                                    }
                                                    else
                                                    {
                                                        //--------------------
                                                        // Read the memory
                                                        //--------------------
                                                        testCommand = i2cCommand[1][XDType];
                                                        strcpy_s(
                                                            commandString,
                                                            QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                                            testCommand);
                                                        commandString[4] = XtoA((address & 0xF00) >> 8);
                                                        commandString[5] = XtoA((address & 0x0F0) >> 4);
                                                        commandString[6] = XtoA(address & 0x00F);
                                                        status = QD_ExecuteI2CCommand(
                                                            unitHandle,
                                                            (LPBYTE) commandString,
                                                            (LPBYTE) replyString);
                                                        if (status == QD_SUCCESS)
                                                        {
                                                            if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                                            {
                                                                replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                                            }
                                                            if ((replyString[0] != 'S') ||
                                                                (strlen(replyString) != strlen(testCommand)) ||
                                                                (replyString[strlen(replyString) - 1] != 'P') ||
                                                                (replyString[strlen(replyString) - 2] == 'N'))
                                                            {
                                                                testPassed = GUI_NO;
                                                                LogDetailedFailureLine(
                                                                    unit,
                                                                    "failed at address {0:X4} performing Memory Read: Command {1} => Reply {2}",
                                                                    address,
                                                                    gcnew String(commandString),
                                                                    gcnew String(replyString));
                                                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                                            }
                                                            else
                                                            {
                                                                readValue = (AtoX(replyString[10]) << 4) | AtoX(replyString[11]);
                                                                if (readValue != writeValue)
                                                                {
                                                                    testPassed = GUI_NO;
                                                                    LogDetailedFailureLine(
                                                                        unit,
                                                                        "failed at address {0:X4} because the Memory Read-back did not match the byte written",
                                                                        address);
                                                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                                                }
                                                            }
                                                        }
                                                        else
                                                        {
                                                            testPassed = GUI_NO;
                                                            LogDetailedStatus(unit, String::Empty, status);
                                                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    testPassed = GUI_NO;
                                                    LogDetailedStatus(unit, String::Empty, status);
                                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                                }
                                                if (dotCount > 256)
                                                    dotCount = 0;
                                                if (testPassed && !dotCount++)
                                                    LogDetailedDot(unit);
                                                Thread::Sleep(10);
                                                QCOM_CheckActiveTesting(unit, keepTesting);
                                            }   // end of for (int address = dotCount = 0; ...)
                                        }       // end of if ((statusValue & 0xFF) == 0xDF)
                                        else
                                        {
                                            testPassed = GUI_NO;
                                            LogDetailedFailureLine(
                                                unit,
                                                "failed because the Write-protect bit did not clear");
                                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                        }
                                    }
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                testPassed = GUI_YES;
                                testCommand = i2cCommand[3][XDType];
                                strcpy_s(
                                    commandString,
                                    QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                    testCommand);
                                status = QD_ExecuteI2CCommand(
                                    unitHandle,
                                    (LPBYTE) commandString,
                                    (LPBYTE) replyString);
                                if (status == QD_SUCCESS)
                                {
                                    if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                    {
                                        replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                    }
                                    if ((replyString[0] != 'S') ||
                                        (strlen(replyString) != strlen(testCommand)) ||
                                        (replyString[strlen(replyString) - 1] != 'P') ||
                                        (replyString[strlen(replyString) - 2] == 'N'))
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedFailureLine(
                                            unit,
                                            "failed performing Memory Lock: Command {0} => Reply {1}",
                                            gcnew String(commandString),
                                            gcnew String(replyString));
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                            }
                        }
                        else
                        {
                            testPassed = GUI_NO;
                            LogDetailedStatus(unit, String::Empty, status);
                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                        }
                        if (testPassed)
                        {
                            LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                        }
                        //----------------------------------------------------
                        // Restore the transducer memory
                        //----------------------------------------------------
                        LogDetailedEntry(
                            unit,
                            String::Format(
                                "        Restoring memory addresses\n            0x0000 to 0x{0:X4}...",
                                (memorySize - 1)));
                        //----------------------------------------------------
                        // Unlock the memory
                        //----------------------------------------------------
                        testPassed = GUI_YES;
                        testCommand = i2cCommand[2][XDType];
                        strcpy_s(
                            commandString,
                            QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                            testCommand);
                        status = QD_ExecuteI2CCommand(
                            unitHandle,
                            (LPBYTE) commandString,
                            (LPBYTE) replyString);
                        if (status == QD_SUCCESS)
                        {
                            if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                            {
                                replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                            }
                            if ((replyString[0] != 'S') ||
                                (strlen(replyString) != strlen(testCommand)) ||
                                (replyString[strlen(replyString) - 1] != 'P') ||
                                (replyString[strlen(replyString) - 2] == 'N'))
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "failed performing Memory Unlock: Command {0} => Reply {1}",
                                    gcnew String(commandString),
                                    gcnew String(replyString));
                            }
                            else
                            {
                                //--------------------------------------------
                                // Read the transducer status
                                //--------------------------------------------
                                testCommand = i2cCommand[5][XDType];
                                strcpy_s(
                                    commandString,
                                    QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                    testCommand);
                                status = QD_ExecuteI2CCommand(
                                    unitHandle,
                                    (LPBYTE) commandString,
                                    (LPBYTE) replyString);
                                if (status == QD_SUCCESS)
                                {
                                    if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                    {
                                        replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                    }
                                    if ((replyString[0] != 'S') ||
                                        (strlen(replyString) != strlen(testCommand)) ||
                                        (replyString[strlen(replyString) - 1] != 'P') ||
                                        (replyString[strlen(replyString) - 2] == 'N'))
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedFailureLine(
                                            unit,
                                            "failed because the Read Status\n"
                                            "resulted in a malformed reply ({0})",
                                            gcnew String(replyString));
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                    else
                                    {
                                        statusValue = (AtoX(replyString[6]) << 4) | AtoX(replyString[7]);
                                        if ((statusValue & 0xFF) == 0xDF)
                                        {
                                            //--------------------------------
                                            // Write to the memory
                                            //--------------------------------
                                            for (int address = memoryOffset = dotCount = 0; keepTesting && testPassed && (address < memorySize); address++)
                                            {
                                                writeValue = XDMemoryCopy[memoryOffset++];
                                                testCommand = i2cCommand[4][XDType];
                                                strcpy_s(
                                                    commandString,
                                                    QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                                    testCommand);
                                                commandString[4] = XtoA((address & 0xF00) >> 8);
                                                commandString[5] = XtoA((address & 0x0F0) >> 4);
                                                commandString[6] = XtoA(address & 0x00F);
                                                commandString[7] = XtoA(writeValue >> 4);
                                                commandString[8] = XtoA(writeValue);
                                                status = QD_ExecuteI2CCommand(
                                                    unitHandle,
                                                    (LPBYTE) commandString,
                                                    (LPBYTE) replyString);
                                                if (status == QD_SUCCESS)
                                                {
                                                    if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                                    {
                                                        replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                                    }
                                                    if ((replyString[0] != 'S') ||
                                                        (strlen(replyString) != strlen(testCommand)) ||
                                                        (replyString[strlen(replyString) - 1] != 'P') ||
                                                        (replyString[strlen(replyString) - 2] == 'N'))
                                                    {
                                                        testPassed = GUI_NO;
                                                        LogDetailedFailureLine(
                                                            unit,
                                                            "failed at address {0:X4} performing Memory Write: Command {1} => Reply {2}",
                                                            address,
                                                            gcnew String(commandString),
                                                            gcnew String(replyString));
                                                    }
                                                    else
                                                    {
                                                        //--------------------
                                                        // Read the memory
                                                        //--------------------
                                                        testCommand = i2cCommand[1][XDType];
                                                        strcpy_s(
                                                            commandString,
                                                            QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                                            testCommand);
                                                        commandString[4] = XtoA((address & 0xF00) >> 8);
                                                        commandString[5] = XtoA((address & 0x0F0) >> 4);
                                                        commandString[6] = XtoA(address & 0x00F);
                                                        status = QD_ExecuteI2CCommand(
                                                            unitHandle,
                                                            (LPBYTE) commandString,
                                                            (LPBYTE) replyString);
                                                        if (status == QD_SUCCESS)
                                                        {
                                                            if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                                            {
                                                                replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                                            }
                                                            if ((replyString[0] != 'S') ||
                                                                (strlen(replyString) != strlen(testCommand)) ||
                                                                (replyString[strlen(replyString) - 1] != 'P') ||
                                                                (replyString[strlen(replyString) - 2] == 'N'))
                                                            {
                                                                testPassed = GUI_NO;
                                                                LogDetailedFailureLine(
                                                                    unit,
                                                                    "failed at address {0:X4} performing Memory Read: Command {1} => Reply {2}",
                                                                    address,
                                                                    gcnew String(commandString),
                                                                    gcnew String(replyString));
                                                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                                            }
                                                            else
                                                            {
                                                                readValue = (AtoX(replyString[10]) << 4) | AtoX(replyString[11]);
                                                                if (readValue != writeValue)
                                                                {
                                                                    testPassed = GUI_NO;
                                                                    LogDetailedFailureLine(
                                                                        unit,
                                                                        "failed at address {0:X4} because the Memory Read-back "
                                                                        "did not match the byte written",
                                                                        address);
                                                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                                                }
                                                            }
                                                        }
                                                        else
                                                        {
                                                            testPassed = GUI_NO;
                                                            LogDetailedStatus(unit, String::Empty, status);
                                                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    testPassed = GUI_NO;
                                                    LogDetailedStatus(unit, String::Empty, status);
                                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                                }
                                                if (dotCount > 256)
                                                    dotCount = 0;
                                                if (testPassed && !dotCount++)
                                                    LogDetailedDot(unit);
                                                Thread::Sleep(10);
                                                QCOM_CheckActiveTesting(unit, keepTesting);
                                            }   // end of for (int address = memoryOffset = dotCount = 0; ...)
                                        }   // end of if ((statusValue & 0xFF) == 0xDF)
                                        else
                                        {
                                            testPassed = GUI_NO;
                                            LogDetailedFailureLine(
                                                unit,
                                                "failed because the Write-protect bit did not clear");
                                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                        }
                                    }
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                //--------------------------------------------
                                // Lock the memory
                                //--------------------------------------------
                                testPassed = GUI_YES;
                                testCommand = i2cCommand[3][XDType];
                                strcpy_s(
                                    commandString,
                                    QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                                    testCommand);
                                status = QD_ExecuteI2CCommand(
                                    unitHandle,
                                    (LPBYTE) commandString,
                                    (LPBYTE) replyString);
                                if (status == QD_SUCCESS)
                                {
                                    if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                                    {
                                        replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                                    }
                                    if ((replyString[0] != 'S') ||
                                        (strlen(replyString) != strlen(testCommand)) ||
                                        (replyString[strlen(replyString) - 1] != 'P') ||
                                        (replyString[strlen(replyString) - 2] == 'N'))
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedFailureLine(
                                            unit,
                                            "failed performing Memory Lock: Command {0} => Reply {1}",
                                            gcnew String(commandString),
                                            gcnew String(replyString));
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                            }
                        }
                        else
                        {
                            testPassed = GUI_NO;
                            LogDetailedStatus(unit, String::Empty, status);
                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                        }
                        if (testPassed)
                        {
                            LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                        }
                        LogDetailedEntry(
                            unit,
                            "    Write Memory Test End: ");
                        if (testPassed)
                        {
                            LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                        }
                        else
                        {
                            LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                            testsPassed = GUI_NO;
                        }
                        unit->testsCompleted++;
                        testsCompleted++;
                        Thread::Sleep(100);
                    }
                }                       // end of if (XDType == 0)
                //------------------------------------------------------------
                // Random Information Test
                //------------------------------------------------------------
                QCOM_CheckActiveTesting(unit, keepTesting);
                if (keepTesting)
                {
                    LogDetailedLine(unit, "    Random Information Test Begin");
                    testPassed = GUI_YES;
                    LogDetailedEntry(
                        unit,
                        "        Reading random information...");
                    for (int count = dotCount = 0; keepTesting && testPassed && (count < 256); count++)
                    {
                        //----------------------------------------------------
                        // There are 2 commands, and they start at offset 5
                        //----------------------------------------------------
                        int commandOffset = (randomNumber->Next() % 2) + 5;
                        testCommand = i2cCommand[commandOffset][XDType];
                        strcpy_s(
                            commandString,
                            QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                            testCommand);
                        status = QD_ExecuteI2CCommand(
                            unitHandle,
                            (LPBYTE) commandString,
                            (LPBYTE) replyString);
                        if (status == QD_SUCCESS)
                        {
                            if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                            {
                                replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                            }
                            if ((replyString[0] != 'S') ||
                                (strlen(replyString) != strlen(testCommand)) ||
                                (replyString[strlen(replyString) - 1] != 'P') ||
                                (replyString[strlen(replyString) - 2] == 'N'))
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "failed: Command {0} => Reply {1}",
                                    gcnew String(commandString),
                                    gcnew String(replyString));
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                        }
                        else
                        {
                            testPassed = GUI_NO;
                            LogDetailedStatus(unit, String::Empty, status);
                            keepTesting = QCOM_ContinueTestingWithErrors(unit);
                        }
                        if (dotCount > 16)
                            dotCount = 0;
                        if (testPassed && !dotCount++)
                            LogDetailedDot(unit);
                        Thread::Sleep(10);
                        QCOM_CheckActiveTesting(unit, keepTesting);
                    }                   // end of for (int count = dotCount = 0; ...)
                    if (testPassed)
                    {
                        LogDetailedLine(unit, (keepTesting ? "succeeded" : "aborted"));
                    }
                    LogDetailedEntry(
                        unit,
                        "    Random Information Test End: ");
                    if (testPassed)
                    {
                        LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                    }
                    else
                    {
                        LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                        testsPassed = GUI_NO;
                    }
                    unit->testsCompleted++;
                    testsCompleted++;
                    Thread::Sleep(100);
                }
                free((void *) XDMemoryCopy);
                free((void *) replyString);
                free((void *) commandString);
            }                           // end of if (commandString && replyString && ...)
            else
            {
                testsPassed = GUI_NO;
                LogDetailedFailureLine(unit, "    Unable to allocate test buffers");
                keepTesting = QCOM_ContinueTestingWithErrors(unit);
            }
            //----------------------------------------------------------------
            // The tests have concluded
            //----------------------------------------------------------------
            LogDetailedEntry(
                unit,
                "{0} Transducer Integrity Test End Result: ",
                XDTypeString);
            if (keepTesting)
            {
                if (testsPassed)
                    LogBothSuccessLine(unit, GUI_TEST_PASSED_STRING);
                else
                    LogBothFailureLine(unit, GUI_TEST_FAILED_STRING);
            }
            else
            {
                LogBothWarningLine(unit,
                    String::Concat(
                        "Terminated by ",
                        (testsPassed ? _T("user") : terminationSource)));
            }
            QD_DLLMessagesEnabled = originalDLLMessages;
        }                               // end of if (QCOM_UnitReady(unit))
        else
        {
            testsPassed = GUI_NO;
            String ^failureLine;
            if (QCOM_XDPresent(unit) && QCOM_XDSNValid(unit))
            {
                failureLine = String::Format(
                    "Failed: module {0} not ready for testing with transducer {1}",
                    unit->moduleSerialNumber,
                    unit->transducerSerialNumber);
            }
            else
            {
                failureLine = String::Format(
                    "Failed: module {0} requires a transducer for testing",
                    unit->moduleSerialNumber);
            }
            LogDetailedFailureLine(unit, String::Concat("    ", failureLine));
            LogSummaryFailureLine(unit, failureLine);
        }
        unit->testsCompleted += (GUI_NUMBER_OF_XD_INTEGRITY_TESTS - testsCompleted);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
        //--------------------------------------------------------------------
        // Not much else can be done if the unit pointer is invalid
        //--------------------------------------------------------------------
        testsPassed = GUI_NO;
    }
    return testsPassed;
}                                       // end of QCOM_TestSuiteTransducerIntegrity()
//----------------------------------------------------------------------------
// QCOM_TestSuiteTransducerMemory
//
// Runs the Transducer Memory Test suite
//
// Returns: GUI_YES     All the tests passed
//          GUI_NO      At least one test failed
//
// Called by:   QCOM_InitiateUnitTests
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_TestSuiteTransducerMemory(
    UnitInfo        ^unit)
{
    bool            keepTesting;
    bool            originalDLLMessages = QD_DLLMessagesEnabled;
    bool            testPassed;         // unit section tests
    bool            testsPassed = GUI_YES;
    int             numberOfTestsToRun;
    int             numberOfMemoryPagesToTest = QD_MAXIMUM_NUMBER_OF_QMEM_PAGES;
    int             XDType = 0;
    char            *testDataFilePath;
    BYTE            checkSum;
    LPBYTE          *originalData;
    LPBYTE          testData;
    LPBYTE          zeroData;
    DWORD           status = QCOM_SUCCESS;                                      // 0x0000
    DWORD           testsCompleted = 0;
    HANDLE          unitHandle;
    String          ^terminationSource;
    String          ^XDChipType;
    String          ^functionName = _T("QCOM_TestSuiteTransducerMemory");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitHandle = unit->unitHandle;
        if (numberOfMemoryPagesToTest > unit->numberOfTransducerMemoryPages)
            numberOfMemoryPagesToTest = unit->numberOfTransducerMemoryPages;
        //--------------------------------------------------------------------
        // Announce the start of the test
        //--------------------------------------------------------------------
        LogDetailedLine(unit,
            "Transducer Memory Test started for {0:D} pages",
            numberOfMemoryPagesToTest);
        LogSummaryEntry(unit, "Transducer Memory Test...");
        if (QCOM_UnitReady(unit))
        {
            terminationSource =
                (unit->testFlags & QCOM_UNIT_TEST_STOP_ON_ERRORS) ?
                    _T("error") : _T("user");
            if (unit->numberOfTransducerMemoryPages)
            {
                if (QCOM_XDIsFrequency(unit) || QCOM_XDIsDigitalNoMem(unit))
                    XDType = 1;
                XDChipType = 
                    (unit->transducerChipID[1] == QD_TRANSDUCER_CHIP_ASIC) ?
                        _T("ASIC") : _T("FPGA");
                numberOfTestsToRun = (numberOfMemoryPagesToTest * 11) + 2;
                if (numberOfTestsToRun != GUI_MAXIMUM_NUMBER_OF_XD_MEMORY_TESTS)
                {
                    unit->testsToComplete -= GUI_MAXIMUM_NUMBER_OF_XD_MEMORY_TESTS;
                    unit->testsToComplete += numberOfTestsToRun;
                }
                QD_DLLMessagesEnabled = GUI_NO;
                //------------------------------------------------------------
                // Start the test
                //------------------------------------------------------------
                QCOM_CheckActiveTesting(unit, keepTesting);
                if (keepTesting)
                {
                    LogDetailedLine(unit, "    Setting up the test");
                    testPassed = GUI_YES;
                    //--------------------------------------------------------
                    // Allocate test buffers
                    //--------------------------------------------------------
                    originalData = (LPBYTE *) malloc(numberOfMemoryPagesToTest * sizeof(LPBYTE));
                    testData = (LPBYTE) malloc(QD_BYTES_PER_QMEM_PAGE);
                    zeroData = (LPBYTE) malloc(QD_BYTES_PER_QMEM_PAGE);
                    if (originalData && testData && zeroData)
                    {
                        QCOM_CheckActiveTesting(unit, keepTesting);
                        if (keepTesting)
                        {
                            for (BYTE pageNumber = 0; pageNumber < numberOfMemoryPagesToTest; pageNumber++)
                            {
                                originalData[pageNumber] = (LPBYTE) malloc(QD_BYTES_PER_QMEM_PAGE);
                                if (originalData[pageNumber])
                                {
                                    ClearBuffer(originalData[pageNumber], QD_BYTES_PER_QMEM_PAGE);
                                    //----------------------------------------
                                    // Save a copy of the original stored
                                    // coefficient data at this page
                                    //----------------------------------------
                                    LogDetailedEntry(
                                        unit,
                                        "        Backing up the original copy of page {0:D} ",
                                        pageNumber);
                                    status = QD_ReadCoefficientDataFromSourcePage(
                                        unitHandle,
                                        QD_DEVICE_TRANSDUCER,                   // 0
                                        pageNumber,
                                        originalData[pageNumber]);
                                    if ((status == QCOM_SUCCESS) || ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA))
                                    {
                                        LogDetailedLine(unit, "succeeded");
                                    }
                                    else
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedStatus(unit, String::Empty, status);
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                    unit->testsCompleted++;         // Preliminary 1
                                    testsCompleted++;
                                }
                                else
                                {
                                    testsPassed = GUI_NO;
                                    LogDetailedFailureLine(unit, "    Unable to allocate test buffers");
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    break;
                                }
                                Thread::Sleep(10);
                            }           // end of for (BYTE pageNumber = 0; ...)
                        }
                        QCOM_CheckActiveTesting(unit, keepTesting);
                        if (keepTesting)
                        {
                            //------------------------------------------------
                            // Retrieve the test data from the test file
                            //------------------------------------------------
                            if ((unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED) &&
                                StringSet(unit->testDataFilePath))
                            {
                                LogDetailedEntry(
                                    unit,
                                    "        Retrieving the test coefficient data from {0} ",
                                    unit->testDataFilePath);
                                testDataFilePath = (char *) malloc(QCOM_MAXIMUM_FILE_PATH_LENGTH);
                                if (testDataFilePath)
                                {
                                    QCOM_ConvertString(
                                        unit->testDataFilePath,
                                        testDataFilePath,
                                        QCOM_MAXIMUM_FILE_PATH_LENGTH);
                                    status = QD_ReadCoefficientDataFromHexFile(
                                        (LPBYTE) testDataFilePath,
                                        testData);
                                    if (status == QD_SUCCESS)
                                    {
                                        LogDetailedLine(unit, "succeeded");
                                    }
                                    else
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedStatus(unit, String::Empty, status);
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                    }
                                    free((void *) testDataFilePath);
                                }
                            }
                            else
                            {
                                testPassed = GUI_NO;
                                LogDetailedFailureLine(
                                    unit,
                                    "        The test file path is not yet specified");
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            unit->testsCompleted++;         // Preliminary 2
                            testsCompleted++;
                            Thread::Sleep(10);
                        }
                        if (testPassed == GUI_NO)
                            testsPassed = GUI_NO;
                        QCOM_CheckActiveTesting(unit, keepTesting);
                        //----------------------------------------------------
                        // Begin testing the first 32 memory pages
                        //----------------------------------------------------
                        for (BYTE pageNumber = 0;
                            keepTesting && testPassed && (pageNumber < numberOfMemoryPagesToTest);
                            pageNumber++)
                        {
                            LogDetailedLine(
                                unit,
                                "    Testing transducer memory page {0:D}",
                                pageNumber);
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Zero out the unit memory page
                                //--------------------------------------------
                                ClearBuffer(zeroData, QD_BYTES_PER_QMEM_PAGE);
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Setting the page to all zeroes ",
                                    pageNumber);
                                status = QD_WriteCoefficientDataToTargetPage(
                                    unitHandle,
                                    QD_DEVICE_TRANSDUCER,                       // 0
                                    pageNumber,
                                    zeroData);
                                if (status == QD_SUCCESS)
                                {
                                    LogDetailedLine(unit, "succeeded");
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                unit->testsCompleted++;     // Loop 1
                                testsCompleted++;
                                Thread::Sleep(10);
                                //--------------------------------------------
                                // Fill the buffer with 9A (singlets and doublets)
                                //--------------------------------------------
                                memset((void *) zeroData, 0x9A, QD_BYTES_PER_QMEM_PAGE);
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Read back the zero-filled memory page into
                                // a nonzero buffer
                                //--------------------------------------------
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Copying the zeroed page into a nonzero pattern buffer ",
                                    pageNumber);
                                status = QD_ReadCoefficientDataFromSourcePage(
                                    unitHandle,
                                    QD_DEVICE_TRANSDUCER,                       // 0
                                    pageNumber,
                                    zeroData);
                                if ((status == QCOM_SUCCESS) || ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA))
                                {
                                    LogDetailedLine(unit, "succeeded");
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                unit->testsCompleted++;     // Loop 2
                                testsCompleted++;
                                Thread::Sleep(10);
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Ensure it is all zeroes
                                //--------------------------------------------
                                for (int offset = 0; offset < QD_BYTES_PER_QMEM_PAGE; offset++)
                                {
                                    if (zeroData[offset] != QCOM_CHAR_NULL)
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedFailureLine(
                                            unit,
                                            "        At least one byte (offset {0:D}) on page {1:D}"
                                            "did not remain zeroed",
                                            offset,
                                            pageNumber);
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                        break;
                                    }
                                }
                                unit->testsCompleted++;     // Loop 3
                                testsCompleted++;
                                Thread::Sleep(10);
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Write the test pattern to the memory page
                                //--------------------------------------------
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Copying the test coefficient data into the page ",
                                    pageNumber);
                                status = QD_WriteCoefficientDataToTargetPage(
                                    unitHandle,
                                    QD_DEVICE_TRANSDUCER,                       // 0
                                    pageNumber,
                                    testData);
                                if (status == QD_SUCCESS)
                                {
                                    LogDetailedLine(unit, "succeeded");
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                unit->testsCompleted++;     // Loop 4
                                testsCompleted++;
                                Thread::Sleep(10);
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                int attempts;
                                //--------------------------------------------
                                // Read back the test pattern in a zeroed buffer
                                //--------------------------------------------
                                ClearBuffer(zeroData, QD_BYTES_PER_QMEM_PAGE);
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Copying the test coefficient data from "
                                    "the page into a zeroed buffer",
                                    pageNumber);
                                for (int retries = 5; retries;)
                                {
                                    attempts = 6 - retries;
                                    status = QD_ReadCoefficientDataFromSourcePage(
                                        unitHandle,
                                        QD_DEVICE_TRANSDUCER,                   // 0
                                        pageNumber,
                                        zeroData);
                                    if ((status == QCOM_SUCCESS) || ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA))
                                    {
                                        if (memcmp((void *) testData, (void *) zeroData, QD_BYTES_PER_QMEM_PAGE) == 0)
                                            retries = 0;
                                        else
                                            Thread::Sleep(100);
                                    }
                                    if (retries)
                                        retries--;
                                }
                                if (status == QCOM_SUCCESS)
                                {
                                    LogDetailedLine(
                                        unit,
                                        " succeeded after {0:D} attempt{1}",
                                        attempts,
                                        ((attempts == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S));
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                unit->testsCompleted++;     // Loop 5
                                testsCompleted++;
                                Thread::Sleep(10);
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Ensure the contents of the write and read
                                // buffers are identical
                                //--------------------------------------------
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Contents written to and read from the page ",
                                    pageNumber);
                                if (memcmp((void *) testData, (void *) zeroData, QD_BYTES_PER_QMEM_PAGE))
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedFailureLine(
                                        unit,
                                        "are not identical, but should be");
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                else
                                {
                                    LogDetailedLine(unit, "are identical");
                                }
                                unit->testsCompleted++;     // Loop 6
                                testsCompleted++;
                                Thread::Sleep(10);
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Calculate and test the checksum
                                //--------------------------------------------
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Checksum for the page ",
                                    pageNumber);
                                checkSum = 0;
                                for (int offset = 0; offset < QD_BYTES_PER_QMEM_PAGE; offset++)
                                {
                                    checkSum += zeroData[offset];
                                }
                                if (checkSum)
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedFailureLine(unit, "is invalid");
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                else
                                {
                                    LogDetailedLine(unit, "is correct");
                                }
                                unit->testsCompleted++;     // Loop 7
                                testsCompleted++;
                                Thread::Sleep(10);
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Leave the unit memory page in a zeroed-out
                                // state
                                //--------------------------------------------
                                ClearBuffer(zeroData, QD_BYTES_PER_QMEM_PAGE);
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Resetting the page to all zeroes ",
                                    pageNumber);
                                status = QD_WriteCoefficientDataToTargetPage(
                                    unitHandle,
                                    QD_DEVICE_TRANSDUCER,                       // 0
                                    pageNumber,
                                    zeroData);
                                if (status == QD_SUCCESS)
                                {
                                    LogDetailedLine(unit, "succeeded");
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                unit->testsCompleted++;     // Loop 8
                                testsCompleted++;
                                Thread::Sleep(10);
                                //--------------------------------------------
                                // Fill the buffer with E8 (singlets and triplets)
                                //--------------------------------------------
                                memset((void *) zeroData, 0xE8, QD_BYTES_PER_QMEM_PAGE);
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Read back the zero-filled memory page into
                                // a nonzero buffer
                                //--------------------------------------------
                                LogDetailedEntry(
                                    unit,
                                    "        Page {0:D} : Copying the zeroed page into "
                                    "another nonzero pattern buffer ",
                                    pageNumber);
                                status = QD_ReadCoefficientDataFromSourcePage(
                                    unitHandle,
                                    QD_DEVICE_TRANSDUCER,                       // 0
                                    pageNumber,
                                    zeroData);
                                if ((status == QCOM_SUCCESS) || ((status & QD_ERROR_CODE_MASK) == QD_ERROR_INVALID_COEFFICIENT_DATA))
                                {
                                    LogDetailedLine(unit, "succeeded");
                                }
                                else
                                {
                                    testPassed = GUI_NO;
                                    LogDetailedStatus(unit, String::Empty, status);
                                    keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                }
                                unit->testsCompleted++;     // Loop 9
                                testsCompleted++;
                                Thread::Sleep(10);
                            }
                            QCOM_CheckActiveTesting(unit, keepTesting);
                            if (keepTesting)
                            {
                                //--------------------------------------------
                                // Ensure it is all zeroes
                                //--------------------------------------------
                                for (int offset = 0; offset < QD_BYTES_PER_QMEM_PAGE; offset++)
                                {
                                    if (zeroData[offset] != QCOM_CHAR_NULL)
                                    {
                                        testPassed = GUI_NO;
                                        LogDetailedFailureLine(
                                            unit,
                                            "        At least one byte (offset {0:D}) on page {1:D}"
                                            "did not remain zeroed",
                                            offset,
                                            pageNumber);
                                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                                        break;
                                    }
                                }
                                unit->testsCompleted++;     // Loop 10
                                testsCompleted++;
                                Thread::Sleep(10);
                            }
                            if (testPassed == GUI_NO)
                            {
                                testsPassed = GUI_NO;
                                testPassed = GUI_YES;   // ensure all four pages are tested
                            }
                            Thread::Sleep(1000);
                            QCOM_CheckActiveTesting(unit, keepTesting);
                        }               // end of for (BYTE pageNumber = 0; ...)
                        LogDetailedLine(unit, "    Concluding the test");
                        //----------------------------------------------------
                        // Restore the memory pages to their original contents
                        //----------------------------------------------------
                        for (BYTE pageNumber = 0; pageNumber < numberOfMemoryPagesToTest; pageNumber++)
                        {
                            LogDetailedEntry(
                                unit,
                                "        Restoring the original copy of page {0:D} ",
                                pageNumber);
                            status = QD_WriteCoefficientDataToTargetPage(
                                unitHandle,
                                QD_DEVICE_TRANSDUCER,                           // 0
                                pageNumber,
                                originalData[pageNumber]);
                            if (status == QD_SUCCESS)
                            {
                                LogDetailedLine(unit, "succeeded");
                            }
                            else
                            {
                                testsPassed = GUI_NO;
                                LogDetailedStatus(unit, String::Empty, status);
                                keepTesting = QCOM_ContinueTestingWithErrors(unit);
                            }
                            free((void *) originalData[pageNumber]);
                        }
                        unit->testsCompleted++;     // Post 1
                        testsCompleted++;
                        free((void *) zeroData);
                        free((void *) testData);
                        free((void *) originalData);
                    }
                    else
                    {
                        testsPassed = GUI_NO;
                        LogDetailedFailureLine(unit, "    Unable to allocate test buffers");
                        keepTesting = QCOM_ContinueTestingWithErrors(unit);
                    }
                }                       // end of if (keepTesting)
                //------------------------------------------------------------
                // The tests have concluded
                //------------------------------------------------------------
                LogDetailedEntry(
                    unit,
                    "Transducer ({0}) Memory Test End Result: ",
                    XDChipType);
                if (keepTesting)
                {
                    if (testsPassed)
                        LogBothSuccessLine(unit, GUI_TEST_PASSED_STRING);
                    else
                        LogBothFailureLine(unit, GUI_TEST_FAILED_STRING);
                }
                else
                {
                    LogBothWarningLine(unit,
                        String::Concat(
                            "Terminated by ",
                            (testsPassed ? _T("user") : terminationSource)));
                }
            }                           // end of if (unit->numberOfTransducerMemoryPages)
            else
            {
                testsPassed = GUI_NO;
                String ^failureLine = String::Format(
                    "Transducer {0} has no memory pages available to test",
                    unit->transducerSerialNumber);
                LogDetailedFailureLine(unit, String::Concat("    ", failureLine));
                LogSummaryFailureLine(unit, failureLine);
            }
            QD_DLLMessagesEnabled = originalDLLMessages;
        }                               // end of if (QCOM_UnitReady(unit))
        else
        {
            testsPassed = GUI_NO;
            String ^failureLine;
            if (QCOM_XDPresent(unit) && QCOM_XDSNValid(unit))
            {
                failureLine = String::Format(
                    "Failed: module {0} not ready for testing with transducer {1}",
                    unit->moduleSerialNumber,
                    unit->transducerSerialNumber);
            }
            else
            {
                failureLine = String::Format(
                    "Failed: module {0} requires a transducer for testing",
                    unit->moduleSerialNumber);
            }
            LogDetailedFailureLine(unit, String::Concat("    ", failureLine));
            LogSummaryFailureLine(unit, failureLine);
        }
        unit->testsCompleted += (numberOfTestsToRun - testsCompleted);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
        //--------------------------------------------------------------------
        // Not much else can be done if the unit pointer is invalid
        //--------------------------------------------------------------------
        testsPassed = GUI_NO;
    }
    return testsPassed;
}                                       // end of QCOM_TestSuiteTransducerMemory()
//----------------------------------------------------------------------------
// QCOM_TestSuiteX2
//
// Runs the X2 Test suite
//
// Returns: GUI_YES     All the tests passed
//          GUI_NO      At least one test failed
//
// Called by:   QCOM_InitiateUnitTests
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_TestSuiteX2(
    UnitInfo        ^unit)
{
    bool            keepTesting;
    bool            testPassed;             // unit section tests
    bool            testsPassed = GUI_YES;
    DWORD           testsCompleted = 0;
//    DWORD           status;
    String          ^terminationSource;
    String          ^functionName = _T("QCOM_TestSuiteX2");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        //--------------------------------------------------------------------
        // Announce the start of the test
        //--------------------------------------------------------------------
        LogDetailedLine(unit, "X2 Test started");
        LogSummaryEntry(unit, "X2 Test...");
        if (QCOM_UnitReady(unit))
        {
            terminationSource =
                (unit->testFlags & QCOM_UNIT_TEST_STOP_ON_ERRORS) ?
                    _T("error") : _T("user");
            //----------------------------------------------------------------
            // Section 1 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 1 Begin");
                testPassed = GUI_YES;
                // TODO: Test 1
                LogDetailedEntry(
                    unit,
                    "    Section 1 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 2 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 2 Begin");
                testPassed = GUI_YES;
                // TODO: Test 2
                LogDetailedEntry(
                    unit,
                    "    Section 2 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 3 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 3 Begin");
                testPassed = GUI_YES;
                // TODO: Test 3
                LogDetailedEntry(
                    unit,
                    "    Section 3 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 4 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 4 Begin");
                testPassed = GUI_YES;
                // TODO: Test 4
                LogDetailedEntry(
                    unit,
                    "    Section 4 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 5 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 5 Begin");
                testPassed = GUI_YES;
                // TODO: Test 5
                LogDetailedEntry(
                    unit,
                    "    Section 5 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // The tests have concluded
            //----------------------------------------------------------------
            LogDetailedEntry(unit, "X2 Test End Result: ");
            if (keepTesting)
            {
                if (testsPassed)
                    LogBothSuccessLine(unit, GUI_TEST_PASSED_STRING);
                else
                    LogBothFailureLine(unit, GUI_TEST_FAILED_STRING);
            }
            else
            {
                LogBothWarningLine(unit,
                    String::Concat(
                        "Terminated by ",
                        (testsPassed ? _T("user") : terminationSource)));
            }
        }                               // end of if (QCOM_UnitReady(unit))
        else
        {
            testsPassed = GUI_NO;
            String ^failureLine;
            if (QCOM_XDPresent(unit) && QCOM_XDSNValid(unit))
            {
                failureLine = String::Format(
                    "Failed: module {0} not ready for testing with transducer {1}",
                    unit->moduleSerialNumber,
                    unit->transducerSerialNumber);
            }
            else
            {
                failureLine = String::Format(
                    "Failed: module {0} requires a transducer for testing",
                    unit->moduleSerialNumber);
            }
            LogDetailedFailureLine(unit, String::Concat("    ", failureLine));
            LogSummaryFailureLine(unit, failureLine);
        }
        unit->testsCompleted += (GUI_NUMBER_OF_X2_TESTS - testsCompleted);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
        //--------------------------------------------------------------------
        // Not much else can be done if the unit pointer is invalid
        //--------------------------------------------------------------------
        testsPassed = GUI_NO;
    }
    return testsPassed;
}                                       // end of QCOM_TestSuiteX2()
//----------------------------------------------------------------------------
// QCOM_TestSuiteX3
//
// Runs the X3 Test suite
//
// Returns: GUI_YES     All the tests passed
//          GUI_NO      At least one test failed
//
// Called by:   QCOM_InitiateUnitTests
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_TestSuiteX3(
    UnitInfo        ^unit)
{
    bool            keepTesting;
    bool            testPassed;             // unit section tests
    bool            testsPassed = GUI_YES;
    DWORD           testsCompleted = 0;
    String          ^terminationSource;
    String          ^functionName = _T("QCOM_TestSuiteX3");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        //--------------------------------------------------------------------
        // Announce the start of the test
        //--------------------------------------------------------------------
        LogDetailedLine(unit, "X3 Test started");
        LogSummaryEntry(unit, "X3 Test...");
        if (QCOM_UnitReady(unit))
        {
            terminationSource =
                (unit->testFlags & QCOM_UNIT_TEST_STOP_ON_ERRORS) ?
                    _T("error") : _T("user");
            //----------------------------------------------------------------
            // Section 1 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 1 Begin");
                testPassed = GUI_YES;
                // TODO: Test 1
                LogDetailedEntry(
                    unit,
                    "    Section 1 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 2 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 2 Begin");
                testPassed = GUI_YES;
                // TODO: Test 2
                LogDetailedEntry(
                    unit,
                    "    Section 2 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 3 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 3 Begin");
                testPassed = GUI_YES;
                // TODO: Test 3
                LogDetailedEntry(
                    unit,
                    "    Section 3 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 4 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 4 Begin");
                testPassed = GUI_YES;
                // TODO: Test 4
                LogDetailedEntry(
                    unit,
                    "    Section 4 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 5 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 5 Begin");
                testPassed = GUI_YES;
                // TODO: Test 5
                LogDetailedEntry(
                    unit,
                    "    Section 5 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // The tests have concluded
            //----------------------------------------------------------------
            LogDetailedEntry(unit, "X3 Test End Result: ");
            if (keepTesting)
            {
                if (testsPassed)
                    LogBothSuccessLine(unit, GUI_TEST_PASSED_STRING);
                else
                    LogBothFailureLine(unit, GUI_TEST_FAILED_STRING);
            }
            else
            {
                LogBothWarningLine(unit,
                    String::Concat(
                        "Terminated by ",
                        (testsPassed ? _T("user") : terminationSource)));
            }
        }                               // end of if (QCOM_UnitReady(unit))
        else
        {
            testsPassed = GUI_NO;
            String ^failureLine;
            if (QCOM_XDPresent(unit) && QCOM_XDSNValid(unit))
            {
                failureLine = String::Format(
                    "Failed: module {0} not ready for testing with transducer {1}",
                    unit->moduleSerialNumber,
                    unit->transducerSerialNumber);
            }
            else
            {
                failureLine = String::Format(
                    "Failed: module {0} requires a transducer for testing",
                    unit->moduleSerialNumber);
            }
            LogDetailedFailureLine(unit, String::Concat("    ", failureLine));
            LogSummaryFailureLine(unit, failureLine);
        }
        unit->testsCompleted += (GUI_NUMBER_OF_X3_TESTS - testsCompleted);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
        //--------------------------------------------------------------------
        // Not much else can be done if the unit pointer is invalid
        //--------------------------------------------------------------------
        testsPassed = GUI_NO;
    }
    return testsPassed;
}                                       // end of QCOM_TestSuiteX3()
//----------------------------------------------------------------------------
// QCOM_TestSuiteX4
//
// Runs the X4 Test suite
//
// Returns: GUI_YES     All the tests passed
//          GUI_NO      At least one test failed
//
// Called by:   QCOM_InitiateUnitTests
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_TestSuiteX4(
    UnitInfo        ^unit)
{
    bool            keepTesting;
    bool            testPassed;             // unit section tests
    bool            testsPassed = GUI_YES;
    DWORD           testsCompleted = 0;
    String          ^terminationSource;
    String          ^functionName = _T("QCOM_TestSuiteX4");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        //--------------------------------------------------------------------
        // Announce the start of the test
        //--------------------------------------------------------------------
        LogDetailedLine(unit, "X4 Test started");
        LogSummaryEntry(unit, "X4 Test...");
        if (QCOM_UnitReady(unit))
        {
            terminationSource =
                (unit->testFlags & QCOM_UNIT_TEST_STOP_ON_ERRORS) ?
                    _T("error") : _T("user");
            //----------------------------------------------------------------
            // Section 1 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 1 Begin");
                testPassed = GUI_YES;
                // TODO: Test 1
                LogDetailedEntry(
                    unit,
                    "    Section 1 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 2 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 2 Begin");
                testPassed = GUI_YES;
                // TODO: Test 2
                LogDetailedEntry(
                    unit,
                    "    Section 2 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 3 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 3 Begin");
                testPassed = GUI_YES;
                // TODO: Test 3
                LogDetailedEntry(
                    unit,
                    "    Section 3 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 4 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 4 Begin");
                testPassed = GUI_YES;
                // TODO: Test 4
                LogDetailedEntry(
                    unit,
                    "    Section 4 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // Section 5 Test
            //----------------------------------------------------------------
            QCOM_CheckActiveTesting(unit, keepTesting);
            if (keepTesting)
            {
                LogDetailedLine(unit, "    Section 5 Begin");
                testPassed = GUI_YES;
                // TODO: Test 5
                LogDetailedEntry(
                    unit,
                    "    Section 5 End: ");
                if (testPassed)
                {
                    LogDetailedSuccessLine(unit, GUI_TEST_PASSED_STRING);
                }
                else
                {
                    LogDetailedFailureLine(unit, GUI_TEST_FAILED_STRING);
                    testsPassed = GUI_NO;
                }
                unit->testsCompleted++;
                testsCompleted++;
                Thread::Sleep(100);
            }
            //----------------------------------------------------------------
            // The tests have concluded
            //----------------------------------------------------------------
            LogDetailedEntry(unit, "X4 Test End Result: ");
            if (keepTesting)
            {
                if (testsPassed)
                    LogBothSuccessLine(unit, GUI_TEST_PASSED_STRING);
                else
                    LogBothFailureLine(unit, GUI_TEST_FAILED_STRING);
            }
            else
            {
                LogBothWarningLine(unit,
                    String::Concat(
                        "Terminated by ",
                        (testsPassed ? _T("user") : terminationSource)));
            }
        }                               // end of if (QCOM_UnitReady(unit))
        else
        {
            testsPassed = GUI_NO;
            String ^failureLine;
            if (QCOM_XDPresent(unit) && QCOM_XDSNValid(unit))
            {
                failureLine = String::Format(
                    "Failed: module {0} not ready for testing with transducer {1}",
                    unit->moduleSerialNumber,
                    unit->transducerSerialNumber);
            }
            else
            {
                failureLine = String::Format(
                    "Failed: module {0} requires a transducer for testing",
                    unit->moduleSerialNumber);
            }
            LogDetailedFailureLine(unit, String::Concat("    ", failureLine));
            LogSummaryFailureLine(unit, failureLine);
        }
        unit->testsCompleted += (GUI_NUMBER_OF_X4_TESTS - testsCompleted);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
        //--------------------------------------------------------------------
        // Not much else can be done if the unit pointer is invalid
        //--------------------------------------------------------------------
        testsPassed = GUI_NO;
    }
    return testsPassed;
}                                       // end of QCOM_TestSuiteX4()
//----------------------------------------------------------------------------
#endif      // TESTS_CPP
//============================================================================
// End of Tests.cpp
//============================================================================
