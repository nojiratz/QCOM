//============================================================================
// Update.cpp
//
// The methods used by GUI.cpp for display updating tasks
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     UPDATE_CPP
#define     UPDATE_CPP
#include    "Update.h"
//----------------------------------------------------------------------------
// QCOM_AffirmStartupConditions
//
// Ensures the operating environment and other conditions are what they should
// be prior to displaying the user interface
//
// Called by:   QCOM_InitializeGUIComponents
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_AffirmStartupConditions(void)
{
    UnitInfo        ^unit;
    String          ^promptString;
    String          ^functionName = _T("QCOM_AffirmStartupConditions");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Check for an update to the current software version
    //------------------------------------------------------------------------
    QCOM_CheckForCurrentSoftwareVersion(AnyNonErrorMessageEnabled);
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            String ^MSN = unit->moduleSerialNumber;
            //----------------------------------------------------------------
            // If a valid module is attached, ensure its firmware version is
            // current
            //----------------------------------------------------------------
            QCOM_CheckForCurrentFirmwareVersion(unit);
            if (QCOM_XDPresent(unit))
            {
                //------------------------------------------------------------
                // If an analog transducer is attached, ensure its coefficient
                // data has a serial number that matches what the user wants
                //------------------------------------------------------------
                QCOM_CheckForTransducerCoefficientData(unit);
                if (!QCOM_UnitReady(unit))
                {
                    //--------------------------------------------------------
                    // A transducer is present, but communication with it is
                    // unreliable
                    //--------------------------------------------------------
                    if (QCOM_XDSNValid(unit))
                    {
                        if (unit->transducerType == QD_TRANSDUCER_TYPE_ABSENT)
                        {
                            promptString = String::Format(
                                "The software has limited access to the transducer attached\n"
                                "to module {0}, rendering some services and utilities unavailable",
                                MSN);
                        }
                        else
                        {
                            promptString = String::Format(
                                "The software has limited access to transducer {0},\n"
                                "rendering some services and utilities unavailable to module {1}",
                                unit->transducerSerialNumber, MSN);
                        }
                    }
                    else
                    {
                        promptString = String::Format(
                            "The software has limited access to the transducer attached to\n"
                            "module {0}, rendering some services and utilities unavailable",
                            MSN);
                    }
                    RecordErrorEvent(promptString);
                    GUI_PlaySound(errorSound);
                    QCOM_PromptOKModal(
                        "Warning",
                        promptString);
                }
            }
            else
            {
                if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_GUI_UP_AND_RUNNING))
                {
                    //--------------------------------------------------------
                    // The transducer is not attached
                    //--------------------------------------------------------
                    if (QCOM_ModuleSNValid(unit))
                    {
                        promptString = String::Format(
                            "Unit {0:D} : No transducer is attached to module {1}",
                            unit->unitNumber, MSN);
                    }
                    else
                    {
                        promptString = String::Format(
                            "Unit {0:D} : No transducer is attached to the QCOM module",
                            unit->unitNumber);
                    }
                    RecordErrorEvent(promptString);
                    GUI_PlaySound(errorSound);
                    QCOM_PromptOKModal(
                        "Warning",
                        promptString);
                }
            }
            delete MSN;
        }                               // end of if (QCOM_UnitNumberValid(unitNumber))
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0}\nUnit number {1:D} should be valid,\n"
                "but is not (number of units = {2:D})",
                functionName, unitNumber, QCOM_CurrentNumberOfUnits);
        }
    }                                   // end of for (DWORD unitNumber = 0; ...)
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_AffirmStartupConditions()
//----------------------------------------------------------------------------
// QCOM_ApplyGeneralFlagToUnitFlags
//
// Applies the specified general flag to all corresponding unit flags, or
// sets the general flag only if all corresponding unit flags are set
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ApplyGeneralFlagToUnitFlags(
    DWORD           generalFlag,
    DWORD           unitFlag)
{
    bool            allUnitFlagsAreSet = GUI_YES;
    bool            atLeastOneUnitIsValid = GUI_NO;
    //------------------------------------------------------------------------
    if (generalFlag && unitFlag)
    {
        if (QCOM_GeneralInfo->flags & generalFlag)
        {
            for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
            {
                if (QCOM_UnitNumberLegal(unitNumber))
                {
                    QCOM_UnitInfoArray[unitNumber]->flags |= unitFlag;
                }
            }
        }
        else
        {
            for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
            {
                if (QCOM_UnitNumberLegal(unitNumber))
                {
                    atLeastOneUnitIsValid = GUI_YES;
                    if (!(QCOM_UnitInfoArray[unitNumber]->flags & unitFlag))
                        allUnitFlagsAreSet = GUI_NO;
                }
            }
            if (atLeastOneUnitIsValid && allUnitFlagsAreSet)
                QCOM_GeneralInfo->flags |= generalFlag;
        }
    }
}                                       // end of QCOM_ApplyGeneralFlagToUnitFlags()
//----------------------------------------------------------------------------
// QCOM_CheckForCurrentSoftwareVersion
//
// Checks the internet for an update to the current software version
//
// Called by:   QCOM_AffirmStartupConditions
//              QCOM_ToolStripCheckForUpdateDropDownClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_CheckForCurrentSoftwareVersion(
    bool            announceResults)
{
    bool            fileDLLNeedsUpdating = GUI_NO;
    bool            fileFWNeedsUpdating = GUI_NO;
    bool            fileSWNeedsUpdating = GUI_NO;
    bool            proceedToDownload = GUI_NO;
    bool            proceedToInstall = GUI_NO;
    bool            promptResult = GUI_CANCEL;
    bool            versionDLLFound = GUI_NO;
    bool            versionFWFound = GUI_NO;
    bool            versionSWFound = GUI_NO;
    BYTE            buildVersion;
    BYTE            majorVersion;
    BYTE            minorVersion;
    StringBuilder   ^filePathBuilder;
    String          ^promptTitle;
    String          ^functionName = _T("QCOM_CheckForCurrentSoftwareVersion");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_InternetIsAvailable())
    {
        //--------------------------------------------------------------------
        // The software has access to the web, so check for the presence of
        // the QCOM version file
        //--------------------------------------------------------------------
        if (QCOM_URLExists(QCOM_VERSION_URL))
        {
            //----------------------------------------------------------------
            // The version file has been located, so download and parse it
            //----------------------------------------------------------------
            WebClient ^webAccess = gcnew WebClient;
            String ^webVersionFile = webAccess->DownloadString(QCOM_VERSION_URL);
            if (!String::IsNullOrEmpty(webVersionFile))
            {
                //------------------------------------------------------------
                // Split up the file into separate lines
                //------------------------------------------------------------
                array <Char> ^pageDelimiters = gcnew array <Char> {QCOM_CHAR_CR, QCOM_CHAR_LF};
                array <String ^> ^pageLines = webVersionFile->Split(
                    pageDelimiters,
                    StringSplitOptions::RemoveEmptyEntries);
                //------------------------------------------------------------
                // Ensure the first line represents the correct format
                //------------------------------------------------------------
                if (StringICompare(pageLines[0], _T("[QCOM]")) == 0)
                {
                    String ^webFWVersion;
                    String ^webDLLVersion;
                    String ^webSWVersion;
                    array <Char> ^lineDelimiters = gcnew array <Char> {'='};
                    array <String ^> ^lineParts;
                    for each (String ^pageLine in pageLines)
                    {
                        //----------------------------------------------------
                        // Only parse lines that contain the = character
                        //----------------------------------------------------
                        if (pageLine->Contains("="))
                        {
                            //------------------------------------------------
                            // Split up each line into tag and version
                            //------------------------------------------------
                            lineParts = pageLine->Split(
                                lineDelimiters,
                                StringSplitOptions::RemoveEmptyEntries);
                            if (!String::IsNullOrEmpty(lineParts[1]))
                            {
                                if (StringICompare(lineParts[0], _T("SW")) == 0)
                                {
                                    webSWVersion = lineParts[1];
                                    versionSWFound = GUI_YES;
                                }
                                if (StringICompare(lineParts[0], _T("DLL")) == 0)
                                {
                                    webDLLVersion = lineParts[1];
                                    versionDLLFound = GUI_YES;
                                }
                                if (StringICompare(lineParts[0], _T("FW")) == 0)
                                {
                                    webFWVersion = lineParts[1];
                                    versionFWFound = GUI_YES;
                                }
                            }
                        }
                    }
                    delete [] lineParts;
                    delete [] lineDelimiters;
                    //--------------------------------------------------------
                    // Check whether the DLL should be updated
                    //--------------------------------------------------------
                    if (versionDLLFound)
                    {
                        QD_GetQDDLLVersion(
                            (LPBYTE) &majorVersion,
                            (LPBYTE) &minorVersion,
                            (LPBYTE) &buildVersion);
                        String ^installedDLLVersion = String::Concat(
                            majorVersion,
                            QCOM_STRING_DOT,
                            minorVersion,
                            QCOM_STRING_DOT,
                            buildVersion);
                        if (StringICompare(webDLLVersion, installedDLLVersion) > 0)
                        {
                            promptTitle = _T("Download DLL Update");
                            proceedToDownload = QCOM_PromptModal(
                                promptTitle,
                                "Your QCOM DLL is version {0}, and\n"
                                "version {1} is available for download.\n\n"
                                "Download updated version now?",
                                installedDLLVersion,
                                webDLLVersion);
                            if (proceedToDownload)
                            {
                                String ^webDLLFile = String::Concat(
                                    "qdUSB-", webDLLVersion, ".dll");
                                String ^downloadDLLURL = String::Concat(
                                    QCOM_PKG_URL_DIR, webDLLFile);
                                String ^localDLLFile = String::Concat(
                                    Application::StartupPath, "\\", webDLLFile);
                                filePathBuilder = gcnew StringBuilder(
                                    localDLLFile, QCOM_MAXIMUM_FILE_PATH_LENGTH);
                                promptResult = QCOM_PromptForSaveFile(
                                    promptTitle,
                                    filePathBuilder,
                                    localDLLFile,
                                    GUI_FILE_TYPE_DLL);
                                localDLLFile = filePathBuilder->ToString();
                                delete filePathBuilder;
                                if (promptResult == GUI_ACCEPT)
                                {
                                    webAccess->DownloadFile(downloadDLLURL, localDLLFile);
                                    String ^webPDBFile = String::Concat(
                                        "qdUSB-", webDLLVersion, ".pdb");
                                    String ^downloadPDBURL = String::Concat(
                                        QCOM_PKG_URL_DIR, webPDBFile);
                                    String ^localPDBFile = String::Concat(
                                        Application::StartupPath, "\\", "qdUSB.pdb");
                                    webAccess->DownloadFile(downloadPDBURL, localPDBFile);
                                    QCOM_PromptOKModal(
                                        promptTitle,
                                        "To install the updated DLL, exit QCOM,\n"
                                        "delete the outdated qdUSB.dll file from the\n"
                                        "QCOM executable folder, rename {0}\n"
                                        "to qdUSB.dll, then restart QCOM",
                                        webDLLFile);
                                }
                                delete localDLLFile;
                                delete downloadDLLURL;
                                delete webDLLFile;
                            }           // end of if (proceedToDownload)
                        }               // end of if (StringICompare(webDLLVersion, installedDLLVersion) > 0)
                        else
                        {
                            QCOM_RecordAndModalEventByFlags(
                                QCOM_EventLogBasicEnabled,
                                QCOM_BasicMessagesEnabled,
                                functionName,
                                "Your QCOM DLL (version {0}) is up-to-date\n(online version = {1})",
                                installedDLLVersion,
                                webDLLVersion);
                        }
                        delete installedDLLVersion;
                    }                   // end of if (versionDLLFound)
                    delete webDLLVersion;
                    //--------------------------------------------------------
                    // Check whether the software should be updated
                    //--------------------------------------------------------
                    if (versionSWFound)
                    {
                        if (StringICompare(webSWVersion, QCOM_PROGRAM_VERSION_STRING) > 0)
                        {
                            promptTitle = _T("Download Software Update");
                            proceedToDownload = QCOM_PromptModal(
                                promptTitle,
                                "Your QCOM software is version {0}, and\n"
                                "version {1} is available for download.\n\n"
                                "Update your software now?",
                                QCOM_PROGRAM_VERSION_STRING,
                                webSWVersion);
                            if (proceedToDownload)
                            {
                                QCOM_SoftwareUpdateInProgress = GUI_YES;
                                //--------------------------------------------
                                // Download the update from the web to the
                                // same folder from where this program started
                                //--------------------------------------------
                                String ^webSWFile = String::Concat(
                                    "QCOM-", webSWVersion, ".exe");
                                String ^downloadSWURL = String::Concat(
                                    QCOM_PKG_URL_DIR, webSWFile);
                                String ^localSWFile = String::Concat(
                                    Application::StartupPath, "\\", webSWFile);
                                webAccess->DownloadFile(downloadSWURL, localSWFile);
                                //--------------------------------------------
                                // Download the accompanying PDB file as well
                                //--------------------------------------------
                                String ^webPDBFile = String::Concat(
                                    "QCOM-", webSWVersion, ".pdb");
                                String ^downloadPDBURL = String::Concat(
                                    QCOM_PKG_URL_DIR, webPDBFile);
                                String ^localPDBFile = String::Concat(
                                    Application::StartupPath, "\\", "QCOM.pdb");
                                webAccess->DownloadFile(downloadPDBURL, localPDBFile);
                                //--------------------------------------------
                                // Create a new update file, which contains the
                                // path of this program's executable file, the
                                // path of the downloaded executable file, and
                                // the original command-line parameters that
                                // were passed to this program, in that order
                                //--------------------------------------------
                                String ^updateFile = String::Concat(
                                    Application::StartupPath, "\\", QCOM_SW_UPDATE_FILENAME);
                                if (File::Exists(updateFile))
                                    File::Delete(updateFile);
                                StreamWriter ^textWriter = File::CreateText(updateFile);
                                textWriter->WriteLine(Application::ExecutablePath);
                                textWriter->WriteLine(localSWFile);
                                textWriter->WriteLine(QCOM_GeneralInfo->commandLine);
                                textWriter->Close();
                                //--------------------------------------------
                                // Begin shutting down this program, and
                                // release all allocated memory
                                //--------------------------------------------
                                QCOM_Finalize(String::Concat(functionName, " concluded"));
                                //--------------------------------------------
                                // Start the downloaded program running, but
                                // with the /u parameter, which signals the
                                // fact that the program is in process of
                                // being updated
                                //--------------------------------------------
                                ProcessStartInfo ^startNewAppCommand = gcnew ProcessStartInfo(localSWFile);
                                startNewAppCommand->WindowStyle = ProcessWindowStyle::Hidden;
                                startNewAppCommand->Arguments = _T("/u");
                                startNewAppCommand->CreateNoWindow = GUI_YES;
                                startNewAppCommand->UseShellExecute = GUI_NO;
                                System::Diagnostics::Process::Start(startNewAppCommand);
                                delete localPDBFile;
                                delete downloadPDBURL;
                                delete webPDBFile;
                                delete localSWFile;
                                delete downloadSWURL;
                                delete webSWFile;
                                //--------------------------------------------
                                // Exit this program
                                //--------------------------------------------
                                Environment::Exit(QCOM_SUCCESS);
                            }           // end of if (proceedToDownload)
                        }               // end of if (StringICompare(webSWVersion, QCOM_PROGRAM_VERSION_STRING) > 0)
                        else
                        {
                            QCOM_RecordAndModalEventByFlags(
                                QCOM_EventLogBasicEnabled,
                                announceResults,
                                functionName,
                                "Your QCOM software (version {0}) is up-to-date\n(online version = {1})",
                                QCOM_PROGRAM_VERSION_STRING,
                                webSWVersion);
                        }
                    }                   // end of if (versionSWFound)
                    delete webSWVersion;
                    //--------------------------------------------------------
                    // Check whether the firmware should be updated
                    //
                    // Note: This block checks whether the minimum firmware
                    // version expected by the software should be updated to
                    // reflect the version that is available online, and not
                    // whether the version of the actual firmware in the
                    // attached modules should be updated, which is done later
                    //--------------------------------------------------------
                    if (versionFWFound)
                    {
                        String ^programFWVersion = String::Concat(
                            QCOM_MINIMUM_FIRMWARE_MAJOR_VERSION,
                            QCOM_STRING_DOT,
                            QCOM_MINIMUM_FIRMWARE_MINOR_VERSION);
                        if (StringICompare(webFWVersion, programFWVersion) > 0)
                        {
                            promptTitle = _T("Download Firmware Update");
                            proceedToDownload = QCOM_PromptModal(
                                promptTitle,
                                "Your QCOM firmware is version {0}, and\n"
                                "version {1} is available for download.\n\n"
                                "Download updated version now?",
                                programFWVersion,
                                webFWVersion);
                            if (proceedToDownload)
                            {
                                String ^webFWFile = String::Concat(
                                    "QCOM-Firmware-", webFWVersion, ".zip");
                                String ^downloadFWURL = String::Concat(
                                    QCOM_PKG_URL_DIR, webFWFile);
                                String ^localFWDirectory = String::Concat(
                                    Application::StartupPath, "\\Firmware");
                                String ^localFWFile = String::Concat(
                                    localFWDirectory,
                                    "\\QCOM-Firmware-", webFWVersion, ".zip");
                                if (Directory::Exists(localFWDirectory))
                                {
                                    if (File::Exists(localFWFile))
                                        File::Delete(localFWFile);
                                }
                                else
                                {
                                    Directory::CreateDirectory(localFWDirectory);
                                }
                                filePathBuilder = gcnew StringBuilder(
                                    localFWFile, QCOM_MAXIMUM_FILE_PATH_LENGTH);
                                promptResult = QCOM_PromptForSaveFile(
                                    promptTitle,
                                    filePathBuilder,
                                    localFWFile,
                                    GUI_FILE_TYPE_ZIP);
                                localFWFile = filePathBuilder->ToString();
                                delete filePathBuilder;
                                if (promptResult == GUI_ACCEPT)
                                {
                                    webAccess->DownloadFile(downloadFWURL, localFWFile);
                                    proceedToInstall = QCOM_PromptModal(
                                        promptTitle,
                                        "Install the QCOM firmware {0} update ?",
                                        webFWVersion);
                                    if (proceedToInstall == GUI_ACCEPT)
                                    {
                                        System::Diagnostics::Process::Start(localFWFile);
                                    }
                                }
                                delete localFWFile;
                                delete localFWDirectory;
                                delete downloadFWURL;
                                delete webFWFile;
                            }           // end of if (proceedToDownload)
                        }               // end of if (StringICompare(webFWVersion, programFWVersion) > 0)
                        else
                        {
                            QCOM_RecordAndModalEventByFlags(
                                QCOM_EventLogBasicEnabled,
                                QCOM_BasicMessagesEnabled,
                                functionName,
                                "Your program-specified firmware (version {0}) is up-to-date\n(online version = {1})",
                                programFWVersion,
                                webFWVersion);
                        }
                        delete programFWVersion;
                    }                   // end of if (versionFWFound)
                    delete webFWVersion;
                }                       // end of if (StringICompare(pageLines[0], _T("[QCOM]")) == 0)
                delete [] pageLines;
                delete [] pageDelimiters;
            }                           // end of if (!String::IsNullOrEmpty(webVersionFile))
            delete webVersionFile;
            delete webAccess;
        }                               // end of if (QCOM_URLExists(QCOM_VERSION_URL))
        else
        {
            GUI_DisplaySimpleError(
                functionName,
                "The version file {0} can't be located", QCOM_VERSION_URL);
        }
    }                                   // end of if (QCOM_InternetIsAvailable())
    else
    {
        QCOM_RecordAndModalEventByFlags(
            QCOM_EventLogBasicEnabled,
            QCOM_VerboseMessagesEnabled,
            functionName,
            "The internet is unavailable at the moment");
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_CheckForCurrentSoftwareVersion()
//----------------------------------------------------------------------------
// QCOM_DownloadLatestSoftwareVersion
//
// Downloads the latest version of QCOM software
//
// Called by:   QCOM_ToolStripDownloadTheLatestDropDownClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DownloadLatestSoftwareVersion(
    bool            announceResults)
{
    bool            proceedToDownload = GUI_YES;
    String          ^functionName = _T("QCOM_DownloadLatestSoftwareVersion");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_InternetIsAvailable())
    {
        //--------------------------------------------------------------------
        // The software has access to the web
        //--------------------------------------------------------------------
        WebClient ^webAccess = gcnew WebClient;
        //--------------------------------------------------------------------
        // Download the latest software, which is always in QCOM.zip, and save
        // it to the startup folder of this running software
        //--------------------------------------------------------------------
        String ^downloadSWZIPURL = String::Concat(
            QCOM_PKG_URL_DIR, _T("QCOM.zip"));
        String ^localSWZIPFile = String::Concat(
            Application::StartupPath, _T("\\QCOM.zip"));
        if (File::Exists(localSWZIPFile))
        {
            proceedToDownload = QCOM_PromptModal(
                "Download File Exists",
                "Over-write {0} ?",
                localSWZIPFile);
        }
        if (proceedToDownload)
        {
            webAccess->DownloadFile(downloadSWZIPURL, localSWZIPFile);
            if (QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE)
            {
                QCOM_PromptOKModal(
                    "Latest Software Downloaded",
                    "The updated software was downloaded as\n\n"
                    "    {0}",
                    localSWZIPFile);
            }
            else
            {
                QCOM_PromptOKModal(
                    "Latest Software Downloaded",
                    "Update your software as follows:\n\n"
                    "1.  Exit the QCOM software\n"
                    "2.  Delete the two files\n"
                    "        {0}\n"
                    "        {1}\n"
                    "3.  Un-ZIP QCOM.zip and copy the two uncompressed files\n"
                    "        into the {2} folder\n"
                    "4.  Restart the software",
                    String::Concat(Application::StartupPath, _T("\\QCOM.exe")),
                    String::Concat(Application::StartupPath, _T("\\QCOM.pdb")),
                    Application::StartupPath);
            }
        }
        delete localSWZIPFile;
        delete downloadSWZIPURL;
        delete webAccess;
    }                                   // end of if (QCOM_InternetIsAvailable())
    else
    {
        QCOM_RecordAndModalEventByFlags(
            QCOM_EventLogBasicEnabled,
            QCOM_VerboseMessagesEnabled,
            functionName,
            "The internet is unavailable at the moment");
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_DownloadLatestSoftwareVersion()
//----------------------------------------------------------------------------
// QCOM_DisplayStatusLine
//
// Displays the text of the status line in the main (home) window, using
// variable arguments
//
// Note:    Because this function uses the String::Format method to format the
//          arguments into a single managed string, the calling convention
//          should look like
//
//          char    *unmanagedString = "Testing";
//          DWORD   status = QCOM_SUCCESS;
//          . . .
//          String ^managedString = gcnew String(unmanagedString);
//          QCOM_DisplayStatusLine(
//              "The function returned {0:X8} for XD {1}",
//              status, managedString);
//          delete managedString;
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayStatusLine(
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    //------------------------------------------------------------------------
    if (StringSet(formatString) && (QCOM_GeneralInfo->flags & QCOM_GENERAL_STATUS_LINE_AVAILABLE))
    {
        String ^formattedString = String::Format(formatString, parameters);
        if (StringSet(formattedString))
        {
            homeStatusLineTSSLabel->Text = String::Concat(formattedString);
            homeStatusStrip->Update();
        }
        else
        {
            homeStatusLineTSSLabel->Text = String::Empty;
        }
    }
}                                       // end of QCOM_DisplayStatusLine()
//----------------------------------------------------------------------------
// QCOM_HomeUpdateProgressBar
//
// Updates the home progress bar with the specified whole number percentage,
// calculated from the numbers of items completed out of the items to complete
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_HomeUpdateProgressBar(
    DWORD           itemsCompleted,
    DWORD           itemsToComplete)
{
    int             percentComplete = 0;
    String          ^functionName = _T("Update Home Progress Bar");
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_STATUS_LINE_AVAILABLE)
    {
        if (itemsToComplete)
        {
            percentComplete = QCOM_CalculatePercentage(
                itemsCompleted,
                itemsToComplete);
        }
        if ((percentComplete <= 100) && (itemsCompleted <= itemsToComplete))
        {
            if (homeTSProgressBar && homeStatusStrip)
            {
                //------------------------------------------------------------
                // Set the bar to 100% to erase the previous percentage value,
                // then display the actual percentage bar
                //------------------------------------------------------------
                homeTSProgressBar->Value = 100;
                homeTSProgressBar->Value = percentComplete;
                //------------------------------------------------------------
                // Display the percentage string by creating a graphic, but
                // only for nonzero percentage values
                //------------------------------------------------------------
                if (percentComplete)
                {
                    Graphics ^percentGraphics = homeTSProgressBar->ProgressBar->CreateGraphics();
                    String ^percentString = String::Concat(percentComplete, _T("%"));
                    percentGraphics->DrawString(
                        percentString,
                        SystemFonts::DefaultFont,
                        Brushes::Black,
                        PointF(
                            (homeTSProgressBar->Width / 2) - (percentGraphics->MeasureString(percentString, SystemFonts::DefaultFont).Width / 2.0F),
                            (homeTSProgressBar->Height / 2) - (percentGraphics->MeasureString(percentString, SystemFonts::DefaultFont).Height / 2.0F)));
                }
                homeStatusStrip->Update();
                Thread::Sleep(10);
            }
        }
        else
        {
            GUI_DisplaySimpleError(functionName,
                "Home progress percentage out of range:\n"
                "Completed = {0:D} to complete = {1:D}",
                itemsCompleted,
                itemsToComplete);
        }
    }
}                                       // end of QCOM_HomeUpdateProgressBar()
//----------------------------------------------------------------------------
// QCOM_HomeUpdateStatusLine
//
// Updates the home status strip message box with the specified string
//
// Note:    The status line can hold at most GUI_MAXIMUM_STATUS_LINE_PIXEL_SIZE
//          (556) pixels of text
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_HomeUpdateStatusLine(
    String          ^statusString)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_STATUS_LINE_AVAILABLE)
    {
        if (StringSet(statusString))
        {
            while (QCOM_StringWidth(statusString) > GUI_MAXIMUM_STATUS_LINE_PIXEL_SIZE)
            {
                statusString = statusString->Insert(statusString->Length - 1, String::Empty);
            }
            homeStatusLineTSSLabel->Text = statusString;
            homeStatusStrip->Update();
        }
        else
        {
            homeStatusLineTSSLabel->Text = String::Empty;
        }
    }
}                                       // end of QCOM_HomeUpdateStatusLine()
//----------------------------------------------------------------------------
// QCOM_MapDisplayIntervalToActual
//
// Converts the specified display interval value into its corresponding actual
// millisecond value
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_MapDisplayIntervalToActual(
    DWORD           displayInterval)
{
    DWORD           actualInterval = QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET];
    //------------------------------------------------------------------------
    actualInterval = (DWORD)
        (displayInterval * QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MULTIPLIER_OFFSET]);
    if (displayInterval < QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET])
        displayInterval = QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET];
    if (displayInterval < 500)
    {
        if (displayInterval > 250)
        {
            if (actualInterval > 46)
                actualInterval -= 46;
            else
                actualInterval = 1;
        }
        else
        {
            if (displayInterval > 30)
            {
                if (actualInterval > 24)
                    actualInterval -= 24;
                else
                    actualInterval = 1;
            }
            else
            {
                if (actualInterval > 15)
                    actualInterval -= 15;
                else
                    actualInterval = 1;
            }
        }
    }
    if (actualInterval < QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET])
        actualInterval = QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET];
    return actualInterval;
}                                       // end of QCOM_MapDisplayIntervalToActual()
//----------------------------------------------------------------------------
// QCOM_ReDrawWindows
//
// Redraws all the windows affected by an update in hardware
//
// Called by:   QCOM_ProgramTimerElapsed
//
// Note:    This method is spawned from the program timer thread in
//          QCOM_ProgramTimerElapsed
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReDrawWindows(
    Object          ^hotPlugContext)
{
    DWORD           hotPlugLevel = (DWORD) (dynamic_cast <Object ^> (hotPlugContext));
    String          ^functionName = _T("QCOM_ReDrawWindows");
    //------------------------------------------------------------------------
    if ((hotPlugLevel != QCOM_HOT_PLUG_LEVEL_NO_CHANGE) &&
        !(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_EXITING))
    {
        RecordBasicEvent("{0} called", functionName);
        this->Cursor = Cursors::WaitCursor;
        QCOM_GeneralInfo->flags |= QCOM_GENERAL_PROGRAM_REDRAWING;
        QCOM_HomeUpdateStatusLine("Updating and redrawing");
        QCOM_PleaseWait(GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE, "Updating");
        QCOM_HaltAllUserActivity();
        QCOM_ReScanForDevices(hotPlugLevel);
        QCOM_CheckAllTransducerCoefficientData();
        QCOM_ReInitializeUserInterface(hotPlugLevel);
        QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
        QCOM_HomeUpdateStatusLine("Finished updating and redrawing");
        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_PROGRAM_REDRAWING;
        this->Cursor = Cursors::Default;
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if ((hotPlugLevel != QCOM_HOT_PLUG_LEVEL_NO_CHANGE) && ...)
}                                       // end of QCOM_ReDrawWindows()
//----------------------------------------------------------------------------
// QCOM_ReInitializeUserInterface
//
// Updates the user interface with initial values
//
// Called by:   QCOM_ReDrawWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReInitializeUserInterface(
    DWORD           hotPlugLevel)
{
    bool            atLeastOneTransducerAvailable = GUI_NO;
    DateTime        dateTime = DateTime::Now;
    String          ^functionName = _T("QCOM_ReInitializeUserInterface");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    //------------------------------------------------------------------------
    // Populate the readout text boxes with initial values
    //------------------------------------------------------------------------
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberLegal(unitNumber))
        {
            UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
            if (QCOM_XDPresent(unit))
            {
                atLeastOneTransducerAvailable = GUI_YES;
            }
            if (QCOM_UnitReady(unit))
            {
                QCOM_RetrieveTransducerReadings(unit);
            }
            QCOM_LogUnitDetermineDataLogFilePaths(unit);
            QCOM_TestDetermineResultsFilePath(unit);
            QCOM_TestDetermineDataFilePath(unit);
            QCOM_TestDetermineFirmwareFilePath(unit);
            QCOM_UpdateReadout(unit);
            //----------------------------------------------------------------
            // Copy and reset the module-transducer pair structures
            //----------------------------------------------------------------
            ModuleTransducerPair ^unitPair = QCOM_ModuleTransducerPairArray[unitNumber];
            if (unitPair)
            {
                if (StringSet(unitPair->newModuleSerialNumber) &&
                    StringSet(unitPair->newTransducerSerialNumber))
                    unitPair->currentUnitPair = String::Concat(
                        unitPair->newModuleSerialNumber,
                        unitPair->newTransducerSerialNumber);
                else
                    unitPair->currentUnitPair = String::Empty;
                unitPair->currentModuleSerialNumber = unitPair->newModuleSerialNumber;
                unitPair->currentTransducerSerialNumber = unitPair->newTransducerSerialNumber;
                unitPair->newModuleSerialNumber = String::Empty;
                unitPair->newTransducerSerialNumber = String::Empty;
            }
        }                               // end of if (QCOM_UnitNumberLegal(unitNumber))
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ReInitializeUserInterface()
//----------------------------------------------------------------------------
// QCOM_ReScanForDevices
//
// Scans the USB interface for all possible QCOM devices, preserving the
// original device information per flags
//
// Called by:   QCOM_ReDrawWindows
//              QCOM_ReScanSystem
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReScanForDevices(
    DWORD           hotPlugLevel)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_ReScanForDevices");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    QCOM_InitializeGeneralFields();
    QCOM_GeneralInfo->flags &= QCOM_GENERAL_HOT_PLUG_FLAGS;
    QCOM_GeneralInfo->logFlags &= QCOM_GENERAL_LOG_HOT_PLUG_FLAGS;
    QCOM_GeneralInfo->testFlags &= QCOM_GENERAL_TEST_HOT_PLUG_FLAGS;
    for (DWORD unitNumber = 0;
        unitNumber < Min(QCOM_GeneralInfo->maximumNumberOfUnits, QCOM_MAXIMUM_NUMBER_OF_UNITS);
        unitNumber++)
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if (unit)
        {
            QCOM_InitializeUnitFields(unit);
            unit->flags &= QCOM_UNIT_HOT_PLUG_FLAGS;
            unit->dataLogFlags &= QCOM_UNIT_LOG_HOT_PLUG_FLAGS;
            unit->dataLogPoints &= QCOM_UNIT_LOG_HOT_PLUG_POINTS;
            unit->testFlags &= QCOM_UNIT_TEST_HOT_PLUG_FLAGS;
            unit->graphingFlags &= QCOM_UNIT_GRAPH_HOT_PLUG_FLAGS;
        }
    }
    QCOM_ScanForDevices();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ReScanForDevices()
//----------------------------------------------------------------------------
// QCOM_ReScanModules
//
// Rescans the USB interface for all possible QCOM modules
//
//// Called by:   QCOM_ReDrawWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReScanModules(void)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_ReScanModules");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    QCOM_GeneralInfo->numberOfUnits = QD_GetNumberOfModules();
    QCOM_GeneralInfo->readyUnitBitMap = 0;
    //------------------------------------------------------------------------
    // Search for all possible units, in spite of the actual number of modules
    // reported
    //------------------------------------------------------------------------
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        unit = QCOM_UnitInfoArray[unitNumber];
        if (unit && (unit->unitNumber == unitNumber))
        {
            unit->physicalUnitNumber = unitNumber;
            //----------------------------------------------------------------
            // Retrieve the serial number of the specified module
            //----------------------------------------------------------------
            QCOM_GetModuleInfo(unit);
            if (QCOM_UnitValid(unit))
            {
                QCOM_SetUnitFlagsToInitialValues(unit);
                QCOM_CloseUnit(unit);
                Sleep(100);
                //------------------------------------------------------------
                // Retrieve the QCOM unit firmware version and ID
                //------------------------------------------------------------
                QCOM_RetrieveFirmwareInformation(unit);
            }                           // end of if (QCOM_UnitValid(unit))
        }
    }                                   // end of for (DWORD unitNumber = 0; ...)
    QCOM_SetCurrentNumberOfUnits();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ReScanModules()
//----------------------------------------------------------------------------
// QCOM_ReScanSystem
//
// Re-scans the system for applicable hardware and software changes
//
// Called by:   QCOM_ToolStripReScanDropDownClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ReScanSystem(void)
{
    bool            proceedWithRescan;
    String          ^functionName = _T("QCOM_ReScanSystem");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
        proceedWithRescan = QCOM_PromptModal(
            "Rescan QCOM",
            "Rescan the system for QCOM devices ?");
        if (proceedWithRescan)
        {
            Cursor = Cursors::WaitCursor;
            QCOM_HomeUpdateStatusLine("Scanning the system for QCOM modules and transducers");
//            QCOM_ReScanForDevices();
//            QCOM_ReDrawWindows();
            for (int percent = 0; percent < 100; percent++)
            {
                QCOM_HomeUpdateProgressBar(percent, 100);
                Thread::Sleep(10);
            }
            QCOM_HomeUpdateProgressBar(0, 0);
            QCOM_HomeUpdateStatusLine("Re-scan completed");
            Cursor = Cursors::Default;
        }                               // end of if (proceedWithRescan)
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ReScanSystem()
//----------------------------------------------------------------------------
// QCOM_ResetAll
//
// Resets the states the entire QCOM system
//
// Called by:   QCOM_ResetAllButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ResetAll(void)
{
    bool            proceedWithReset;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_ResetAll");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    proceedWithReset = QCOM_PromptModal(
        "Reset All",
        "Reset all the QCOM hardware and software ?");
    if (proceedWithReset)
    {
        Cursor = Cursors::WaitCursor;
        QCOM_HomeUpdateStatusLine("Resetting the QCOM system");
        for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                unit = QCOM_UnitInfoArray[unitNumber];
//                QCOM_ResetUnit(unit);
//                QCOM_ResetSystem();
            }
        }
        for (int percent = 0; percent < 100; percent++)
        {
            QCOM_HomeUpdateProgressBar(percent, 100);
            Thread::Sleep(10);
        }
        QCOM_HomeUpdateProgressBar(0, 0);
        QCOM_HomeUpdateStatusLine("QCOM hardware and software reset");
        Cursor = Cursors::Default;
    }                                   // end of if (proceedWithReset)
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ResetAll()
//----------------------------------------------------------------------------
// QCOM_ResetAllSoftware
//
// Resets the states of all the QCOM structures and program flags
//
// Called by:   QCOM_ToolStripResetAllSoftwareDropDownClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ResetAllSoftware(void)
{
    bool            currentlySampling;
    bool            currentlyTesting;
    bool            proceedWithReset;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_ResetAllSoftware");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    currentlySampling = QCOM_QueryStopSampling(
        "QCOM cannot be reset during transducer sampling.");
    currentlyTesting = QCOM_QueryStopTesting(
        "QCOM cannot be reset while tests are running.");
    if (!currentlySampling && !currentlyTesting)
    {
        proceedWithReset = QCOM_PromptModal(
            "Reset QCOM Software",
            "Reset all QCOM software ?");
        if (proceedWithReset)
        {
            Cursor = Cursors::WaitCursor;
            QCOM_HomeUpdateStatusLine("Resetting the QCOM software");
            //----------------------------------------------------------------
            // Reset general objects and values
            //----------------------------------------------------------------
            QCOM_CurrentPrecision = GUI_DEFAULT_READOUT_DECIMAL_POINTS;
            QCOM_PrecisionFormatString = String::Concat("{0:F", QCOM_CurrentPrecision, "}");
            QCOM_CurrentProgramInterval = GUI_DEFAULT_PROGRAM_INTERVAL;
            QCOM_CurrentIntervalUnitsOffset = GUI_INTERVAL_DEFAULT_UNITS;
            QCOM_CurrentSamplingInterval = QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_DEFAULT_OFFSET];
            QCOM_LoggingElapsedTime = QCOM_SamplingElapsedTime = 0;
            QCOM_TestLoopCount = GUI_DEFAULT_TEST_LOOP_COUNT;
            QCOM_GeneralInfo->generalUsePath = String::Empty;
            QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_USE_PATH_SPECIFIED;
            //----------------------------------------------------------------
            // Reset unit objects and values
            //----------------------------------------------------------------
            for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
            {
                if (QCOM_UnitNumberValid(unitNumber))
                {
                    unit = QCOM_UnitInfoArray[unitNumber];
                    QCOM_ResetUnitSoftware(unit);
                }
            }
            QCOM_HomeUpdateStatusLine("Resetting the QCOM software");
            for (int percent = 0; percent < 100; percent++)
            {
                QCOM_HomeUpdateProgressBar(percent, 100);
                Thread::Sleep(10);
            }
            QCOM_HomeUpdateProgressBar(0, 0);
            QCOM_HomeUpdateStatusLine("QCOM software reset");
            QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
            Cursor = Cursors::Default;
        }                               // end of if (proceedWithReset)
    }                                   // end of if (!currentlySampling && !currentlyTesting)
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ResetAllSoftware()
//----------------------------------------------------------------------------
// QCOM_ResetUnitSoftware
//
// Resets the software state for the specified unit
//
// Called by:   QCOM_ResetUnitSoftwareButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ResetUnitSoftware(
    UnitInfo        ^unit)
{
    bool            currentlySampling;
    bool            proceedWithReset = GUI_YES;
    String          ^functionName = _T("QCOM_ResetUnitSoftware");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        RecordBasicEvent("{0} called", functionName);
        currentlySampling =
            QCOM_QueryStopSampling("The QCOM software cannot be reset during transducer sampling.");
        if (!currentlySampling)
        {
            proceedWithReset = QCOM_PromptModal(
                "Reset Software",
                String::Format(
                    "Reset QCOM software for unit {0:D} ?",
                    unit->unitNumber));
            if (proceedWithReset)
            {
                Cursor = Cursors::WaitCursor;
                QCOM_HomeUpdateStatusLine(
                    String::Format(
                        "Resetting the software for unit {0:D}",
                        unit->unitNumber));
/*
            QCOM_CurrentProgramInterval = GUI_DEFAULT_PROGRAM_INTERVAL;
            QCOM_CurrentSamplingInterval = GUI_DEFAULT_SAMPLING_INTERVAL;
            QCOM_CurrentPrecision = GUI_DEFAULT_READOUT_DECIMAL_POINTS;
            QCOM_PrecisionFormatString = String::Concat("{0:F", QCOM_CurrentPrecision, "}");
            // TODO: Insert code to automatically update pres/temp displays
            samplingTimer->Stop();
            QCOM_TerminateDataLogging();
            QCOM_GeneralInfo->generalUsePath = String::Empty;
            QCOM_GeneralInfo->flags &=
                ~(QCOM_GENERAL_USE_PATH_SPECIFIED |
                  QCOM_GENERAL_CURRENTLY_SAMPLING |
                  QCOM_GENERAL_DISPLAY_COUNTS |
                  QCOM_GENERAL_DISPLAY_ALT_UNITS |
                  QCOM_GENERAL_EXPERT_MODE);
            QCOM_GeneralInfo->logFlags &=
                ~(QCOM_GENERAL_LOG_CURRENTLY_LOGGING |
                  QCOM_GENERAL_LOG_ALL_LOGGING);
            for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
            {
                unit = QCOM_UnitInfoArray[unitNumber];
                if (unit)
                {
                    ClearBuffer(unit->coefficientFilePath, QCOM_MAXIMUM_FILE_PATH_LENGTH);
                    unit->flags &=
                        ~(QCOM_UNIT_DISPLAY_COUNTS |
                          QCOM_UNIT_DISPLAY_ALT_UNITS |
                          QCOM_UNIT_COEFFICIENT_FILE_SPECIFIED);
                    ClearBuffer(unit->dataLogFilePath, QCOM_MAXIMUM_FILE_PATH_LENGTH);
                    ClearBuffer(unit->dataLogSnapshotFilePath, QCOM_MAXIMUM_FILE_PATH_LENGTH);
                    unit->dataLogPosition = unit->dataLog;
                    unit->dataLogRemaining = unit->dataLogSize;
                    logUnitBoxArray[unitNumber]->Clear();
                    logAllBoxArray[unitNumber]->Clear();
                    unit->dataLogFlags &=
                        ~(QCOM_UNIT_LOG_DATA_PRESENT |
                          QCOM_UNIT_LOG_CURRENTLY_LOGGING |
                          QCOM_UNIT_LOG_FILE_SPECIFIED |                        // 0x00000010
                          QCOM_UNIT_LOG_FILE_AUTO_SAVE |                        // 0x00000020
                          QCOM_UNIT_LOG_FILE_APPEND |                           // 0x00000040
                          QCOM_UNIT_LOG_FILE_PROMPT_OVERWRITE |                 // 0x00000080
                          QCOM_UNIT_LOG_DATA_UNSAVED |                          // 0x00000100
                          QCOM_UNIT_LOG_SNAPSHOT_FILE_SPECIFIED);               // 0x00000200
                    unit->dataLogPoints |= QCOM_UNIT_LOG_DEFAULT_DATA_POINTS;    // 0x00DE0000
                    ClearBuffer(unit->testResultsFilePath, QCOM_MAXIMUM_FILE_PATH_LENGTH);
                    ClearBuffer(unit->testDataFilePath, QCOM_MAXIMUM_FILE_PATH_LENGTH);
                    unit->testSummaryResultsLogPosition = unit->testSummaryResultsLog;
                    unit->testSummaryResultsLogRemaining = unit->testSummaryResultsLogSize;
                    testingSummaryResultsBoxArray[unitNumber]->Clear();
                    testingDetailedResultsBoxArray[unitNumber]->Clear();
                    unit->testFlags &=
                        ~(QCOM_UNIT_TEST_RESULTS_PRESENT |                      // 0x00000004
                          QCOM_UNIT_TEST_CURRENTLY_TESTING |                    // 0x00000008
                          QCOM_UNIT_TEST_RESULTS_FILE_SPECIFIED |               // 0x00000010
                          QCOM_UNIT_TEST_RESULTS_AUTO_SAVE |                    // 0x00000020
                          QCOM_UNIT_TEST_RESULTS_APPEND |                  // 0x00000040
                          QCOM_UNIT_TEST_RESULTS_UNSAVED |                      // 0x00000100
                          QCOM_UNIT_TEST_DATA_FILE_SPECIFIED |                  // 0x00000200
                          QCOM_UNIT_TEST_ALL);                                  // 0x077F0000
                }
            }
*/
                for (int percent = 0; percent < 100; percent += 10)
                {
                    QCOM_HomeUpdateProgressBar(percent, 100);
                    Thread::Sleep(10);
                }
                QCOM_HomeUpdateProgressBar(0, 0);
                QCOM_HomeUpdateStatusLine(
                    String::Format(
                        "Unit {0:D} software reset",
                        unit->unitNumber));
                Cursor = Cursors::Default;
            }                           // end of if (proceedWithReset)
        }                               // end of if (!currentlySampling)
        RecordVerboseEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_ResetUnitSoftware()
//----------------------------------------------------------------------------
// QCOM_ToggleExpertMode
//
// Toggle to enable or disable Expert Mode
//
// Called by:   QCOM_ToolStripExpertModeDropDownClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToggleExpertMode(void)
{
    String          ^functionName = _T("QCOM_ToggleExpertMode");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE)
    {
        //--------------------------------------------------------------------
        // Stop all transducers from sending
        //--------------------------------------------------------------------
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                if (unit->flags & QCOM_UNIT_SEND_XD_READINGS)
                {
                    unit->flags &= ~QCOM_UNIT_SEND_XD_READINGS;
                    expertSendEveryLabelArray[unitNumber]->Visible = GUI_NO;
                    expertSendEveryBoxArray[unitNumber]->Visible = GUI_NO;
                    expertSendEveryMinutesLabelArray[unitNumber]->Visible = GUI_NO;
                    expertSendEveryMinutesRemainingLabelArray[unitNumber]->Visible = GUI_NO;
                    sendEveryTimerArray[unitNumber]->Stop();
                }
            }
        }                               // end of for (DWORD unitNumber = 0; ...)
        homeTabControl->Controls->Remove(expertHomeTabPage);
        expertFunctionTSButton->Text = GUI_ENABLE_EXPERT_MODE_STRING;
        advancedTSDDButton->Visible = GUI_NO;
        homeSendingStatusButton->Visible = GUI_NO;
        homeSendingStatusLabel->Visible = GUI_NO;
        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_EXPERT_MODE;
        RecordBasicEvent("    Expert Mode disabled");
    }
    else
    {
        homeTabControl->Controls->Add(expertHomeTabPage);
        expertFunctionTSButton->Text = GUI_DISABLE_EXPERT_MODE_STRING;
        advancedTSDDButton->Visible = GUI_YES;
        homeSendingStatusButton->Visible = GUI_YES;
        homeSendingStatusLabel->Visible = GUI_YES;
        QCOM_GeneralInfo->flags |= QCOM_GENERAL_EXPERT_MODE;
        RecordBasicEvent("    Expert Mode enabled");
    }
    QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_ToggleExpertMode()
//----------------------------------------------------------------------------
// QCOM_ToggleGeneralFlagThenSetUnitFlags
//
// Toggles the specified general flag, then sets the corresponding flag for
// all valid units
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToggleGeneralFlagThenSetUnitFlags(
    DWORD           generalFlag,
    DWORD           unitFlag)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_ToggleGeneralFlagThenSetUnitFlags");
    //------------------------------------------------------------------------
    if (generalFlag)
    {
        if (QCOM_GeneralInfo->flags & generalFlag)
            QCOM_GeneralInfo->flags &= ~generalFlag;
        else
            QCOM_GeneralInfo->flags |= generalFlag;
        if (unitFlag)
        {
            for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
            {
                if (QCOM_UnitNumberValid(unitNumber))
                {
                    unit = QCOM_UnitInfoArray[unitNumber];
                    if (QCOM_GeneralInfo->flags & generalFlag)
                        unit->flags |= unitFlag;
                    else
                        unit->flags &= ~unitFlag;
                }
                else
                {
                    QCOM_RecordAndModalErrorEvent(
                        "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                        functionName, unitNumber, QCOM_CurrentNumberOfUnits);
                }
            }
        }
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    }
}                                       // end of QCOM_ToggleGeneralFlagThenSetUnitFlags()
//----------------------------------------------------------------------------
// QCOM_ToggleUnitFlagThenSetGeneralFlag
//
// Toggles the specified unit flag, then sets the corresponding general flag
// as needed
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ToggleUnitFlagThenSetGeneralFlag(
    UnitInfo        ^unit,
    DWORD           generalFlag,
    DWORD           unitFlag)
{
    bool            allUnitsSet = GUI_YES;
    String          ^functionName = _T("QCOM_ToggleUnitFlagThenSetGeneralFlag");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        if (unitFlag)
        {
            if (unit->flags & unitFlag)
            {
                unit->flags &= ~unitFlag;
                if (generalFlag)
                {
                    if (QCOM_GeneralInfo->flags & generalFlag)
                        QCOM_GeneralInfo->flags &= ~generalFlag;
                }
            }
            else
            {
                unit->flags |= unitFlag;
                if (generalFlag)
                {
                    if (!(QCOM_GeneralInfo->flags & generalFlag))
                    {
                        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
                        {
                            if (QCOM_UnitNumberValid(unitNumber))
                            {
                                if (!(QCOM_UnitInfoArray[unitNumber]->flags & unitFlag))
                                    allUnitsSet = GUI_NO;
                            }
                            else
                            {
                                QCOM_RecordAndModalErrorEvent(
                                    "{0}\nUnit number {1:D} should be valid,\nbut is not (number of units = {2:D})",
                                    functionName, unitNumber, QCOM_CurrentNumberOfUnits);
                            }
                        }
                        if (allUnitsSet)
                            QCOM_GeneralInfo->flags |= generalFlag;
                    }
                }
            }
            QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
        }
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_ToggleUnitFlagThenSetGeneralFlag()
//----------------------------------------------------------------------------
// QCOM_UpdateDeleteLogFilesDropDown
//
// Updates the File tool strip Delete Log Files drop down to reflect the
// presence or absence of corresponding log files in the QLog folder
//
// Called by:   QCOM_ConcludeEventLog
//              QCOM_DeleteLogFiles
//              QCOM_EstablishEventLog
//              QCOM_InstallToolStrip
//              QCOM_LogUnitSaveDataLog
//              QCOM_TestUnitSaveResultsLog
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateDeleteLogFilesDropDown(void)
{
    bool            atLeastOneLogFileIsPresent = GUI_NO;
    bool            logFilesArePresent = GUI_NO;
    String          ^logDir = String::Concat(QCOM_GeneralInfo->logDirectory, "\\");
    //------------------------------------------------------------------------
    if (deleteAllDataLogFilesTSButton)
    {
        array <String ^> ^dataLogFiles = Directory::GetFiles(logDir, "QCOM-DataLog-*.log");
        logFilesArePresent = StringSet(dataLogFiles) ? GUI_YES : GUI_NO;
        if (!logFilesArePresent)
        {
            dataLogFiles = Directory::GetFiles(logDir, "QCOM-SnapshotLog-*.log");
            logFilesArePresent = StringSet(dataLogFiles) ? GUI_YES : GUI_NO;
        }
        delete [] dataLogFiles;
        deleteAllDataLogFilesTSButton->Enabled = logFilesArePresent;
        if (logFilesArePresent)
            atLeastOneLogFileIsPresent = GUI_YES;
    }
    if (deleteAllDataCSVFilesTSButton)
    {
        array <String ^> ^dataCSVFiles = Directory::GetFiles(logDir, "QCOM-DataLog-*.csv");
        logFilesArePresent = StringSet(dataCSVFiles) ? GUI_YES : GUI_NO;
        if (!logFilesArePresent)
        {
            dataCSVFiles = Directory::GetFiles(logDir, "QCOM-SnapshotLog-*.csv");
            logFilesArePresent = StringSet(dataCSVFiles) ? GUI_YES : GUI_NO;
        }
        delete [] dataCSVFiles;
        deleteAllDataCSVFilesTSButton->Enabled = logFilesArePresent;
        if (logFilesArePresent)
            atLeastOneLogFileIsPresent = GUI_YES;
    }
    if (deleteAllTestResultsFilesTSButton)
    {
        array <String ^> ^testResultsFiles = Directory::GetFiles(logDir, "QCOM-TestResults-*.log");
        logFilesArePresent = StringSet(testResultsFiles) ? GUI_YES : GUI_NO;
        delete [] testResultsFiles;
        deleteAllTestResultsFilesTSButton->Enabled = logFilesArePresent;
        if (logFilesArePresent)
            atLeastOneLogFileIsPresent = GUI_YES;
    }
    if (deleteAllEventLogFilesTSButton)
    {
        array <String ^> ^eventLogFiles = Directory::GetFiles(logDir, "QCOM-EventLog-*.log");
        logFilesArePresent = GUI_NO;
        for each (String ^pathString in eventLogFiles)
        {
            if (StringICompare(pathString, QCOM_GeneralInfo->eventLogPath))
            {
                logFilesArePresent = GUI_YES;
                break;
            }
        }
        delete [] eventLogFiles;
        deleteAllEventLogFilesTSButton->Enabled = logFilesArePresent;
        if (logFilesArePresent)
            atLeastOneLogFileIsPresent = GUI_YES;
    }
    if (deleteAllErrorLogFilesTSButton)
    {
        array <String ^> ^errorLogFiles = Directory::GetFiles(logDir, "QCOM-ErrorLog-*.log");
        logFilesArePresent = GUI_NO;
        for each (String ^pathString in errorLogFiles)
        {
            if (StringICompare(pathString, QCOM_GeneralInfo->errorLogPath))
            {
                logFilesArePresent = GUI_YES;
                break;
            }
        }
        delete [] errorLogFiles;
        deleteAllErrorLogFilesTSButton->Enabled = logFilesArePresent;
        if (logFilesArePresent)
            atLeastOneLogFileIsPresent = GUI_YES;
    }
    if (deleteAllLogFilesTSButton)
    {
        deleteAllLogFilesTSButton->Enabled = atLeastOneLogFileIsPresent;
    }
    delete logDir;
}                                       // end of QCOM_UpdateDeleteLogFilesDropDown()
//----------------------------------------------------------------------------
// QCOM_UpdateGlobalObjects
//
// Updates the states and/or appearances of applicable general and unit global
// elements. This is the main method that coordinates the functions and
// appearances of most, if not all, global objects.
//
// Note:    The primary purpose of this method is to advertise or propogate
//          changes to software objects resulting from hardware (hot plug)
//          changes or user selections
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateGlobalObjects(
    DWORD           context)
{
    bool            allLogBothFileFormats = GUI_YES;
    bool            allLogSummariesDisplayed = GUI_YES;
    bool            allTestsLoopForever = GUI_YES;
    bool            allTestsLoopingEnabled = GUI_YES;
    bool            allTestResultsDisplayed = GUI_YES;
    bool            allUnitsCurrentlyLogging = GUI_YES;
    bool            allUnitsCurrentlySampling = GUI_YES;
    bool            allUnitsCurrentlyTesting = GUI_YES;
    bool            atLeastOneLogHasData = GUI_NO;
    bool            atLeastOneTransducerAvailable = GUI_NO;
    bool            atLeastOneUnitCanBeSampled = GUI_NO;
    bool            atLeastOneUnitHasTestResults = GUI_NO;
    bool            atLeastOneUnitHasTestsSelected = GUI_NO;
    bool            atLeastOneUnitHasUnsavedLogData = GUI_NO;
    bool            atLeastOneUnitHasUnsavedTestResults = GUI_NO;
    bool            atLeastOneUnitLogging = GUI_NO;
    bool            atLeastOneUnitReady = GUI_NO;
    bool            atLeastOneUnitSampling = GUI_NO;
    bool            atLeastOneUnitSending = GUI_NO;
    bool            atLeastOneUnitTesting = GUI_NO;
    bool            atLeastOneUnitValid = GUI_NO;
    bool            moreThanOneUnitReady = GUI_NO;
    bool            noUnitsAreValid = GUI_YES;
    DWORD           numberOfUnits = QCOM_GeneralInfo->numberOfUnits;
    DWORD           numberOfTransducers = QCOM_GeneralInfo->numberOfTransducers;
//    DWORD           allUnits[QCOM_MAXIMUM_NUMBER_OF_UNITS];
//    DWORD           atLeastOneUnit[QCOM_MAXIMUM_NUMBER_OF_UNITS];
//    DWORD           moreThanOneUnit[QCOM_MAXIMUM_NUMBER_OF_UNITS];
    DWORD           unitExpertState[QCOM_MAXIMUM_NUMBER_OF_UNITS];
    DWORD           unitLogState[QCOM_MAXIMUM_NUMBER_OF_UNITS];
    DWORD           unitState[QCOM_MAXIMUM_NUMBER_OF_UNITS];
    DWORD           unitTestState[QCOM_MAXIMUM_NUMBER_OF_UNITS];
    String          ^functionName = _T("QCOM_UpdateGlobalObjects");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0}(0x{1:X8}) called", functionName, context);
    if (context)
    {
        if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_GUI_READY_FOR_UPDATING) &&
            !(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_EXITING))
        {
            QCOM_UpdateGlobalObjectsPerFlags();
            for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
            {
                unitState[unitNumber] = QCOM_UPDATE_ZERO_FLAG;
                unitLogState[unitNumber] = QCOM_UPDATE_ZERO_FLAG;
                unitTestState[unitNumber] = QCOM_UPDATE_ZERO_FLAG;
                unitExpertState[unitNumber] = QCOM_UPDATE_ZERO_FLAG;
//                atLeastOneUnit[unitNumber] = QCOM_UPDATE_ZERO_FLAG;
//                allUnits[unitNumber] = QCOM_UPDATE_ZERO_FLAG;
//                moreThanOneUnit[unitNumber] = QCOM_UPDATE_ZERO_FLAG;
            }
            //----------------------------------------------------------------
            // First pass: determine unit object states
            //----------------------------------------------------------------
            for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
            {
                if (QCOM_UnitNumberValid(unitNumber))
                {
                    unitState[unitNumber] |= QCOM_UPDATE_UNIT_VALID;
                    UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                    if (QCOM_ModuleIsCalMux(unit))
                        unitState[unitNumber] |= QCOM_UPDATE_UNIT_CAL_MUX;
                    if (QCOM_ModuleSNValid(unit))
                        unitState[unitNumber] |= QCOM_UPDATE_UNIT_MSN_VALID;
                    noUnitsAreValid = GUI_NO;
                    atLeastOneUnitValid = GUI_YES;
                    if (QCOM_UnitNumberOpen(unitNumber))
                        unitState[unitNumber] |= QCOM_UPDATE_UNIT_OPEN;
                    //--------------------------------------------------------
                    // Set unit flags
                    //--------------------------------------------------------
                    if (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE)
                    {
                        unitState[unitNumber] |= QCOM_UPDATE_UNIT_BOOT_LOADER_MODE;
                    }
                    if (QCOM_XDPresent(unit))
                    {
                        unitState[unitNumber] |= QCOM_UPDATE_UNIT_XD_PRESENT;
                        unitState[unitNumber] |= QCOM_UPDATE_UNIT_XD_HAS_MEMORY;
                        atLeastOneTransducerAvailable = GUI_YES;
                        if (QCOM_XDIsFrequency(unit) || QCOM_XDIsDigitalNoMem(unit))
                        {
                            unitState[unitNumber] &= ~QCOM_UPDATE_UNIT_XD_HAS_MEMORY;
                            if (QCOM_XDIsFrequency(unit))
                                unitState[unitNumber] |= QCOM_UPDATE_UNIT_XD_FREQUENCY;
                        }
                        if (QCOM_UnitReady(unit))
                        {
                            unitState[unitNumber] |= QCOM_UPDATE_UNIT_READY;
                            if (atLeastOneUnitReady)
                                moreThanOneUnitReady = GUI_YES;
                            atLeastOneUnitReady = GUI_YES;
                        }
                    }                   // end of if (QCOM_XDPresent(unit))
                    if (unit->flags & QCOM_UNIT_TRANSDUCER_POWER_ENABLED)
                        unitState[unitNumber] |= QCOM_UPDATE_UNIT_XD_POWER_ENABLED;
                    //--------------------------------------------------------
                    // Set unit readout flags
                    //--------------------------------------------------------
                    if (unit->flags & QCOM_UNIT_INCLUDE_IN_SAMPLING)
                    {
                        unitState[unitNumber] |= QCOM_UPDATE_UNIT_INCLUDE_IN_SAMPLING;
                        atLeastOneUnitCanBeSampled = GUI_YES;
                    }
                    if (unit->flags & QCOM_UNIT_DISPLAY_COUNTS)
                        unitState[unitNumber] |= QCOM_UPDATE_UNIT_DISPLAY_COUNTS;
                    if (unit->flags & QCOM_UNIT_DISPLAY_FREQUENCIES)
                        unitState[unitNumber] |= QCOM_UPDATE_UNIT_DISPLAY_FREQUENCIES;
                    if (unit->flags & QCOM_UNIT_DISPLAY_VI_VALUES)
                        unitState[unitNumber] |= QCOM_UPDATE_UNIT_DISPLAY_VI_VALUES;
                    if (unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING)
                    {
                        unitState[unitNumber] |= QCOM_UPDATE_UNIT_SAMPLING;
                        atLeastOneUnitSampling = GUI_YES;
                    }
                    else
                    {
                        allUnitsCurrentlySampling = GUI_NO;
                    }
                    //--------------------------------------------------------
                    // Set unit log flags
                    //--------------------------------------------------------
                    if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
                    {
                        unitLogState[unitNumber] |= QCOM_UPDATE_UNIT_LOG_LOGGING;
                        atLeastOneUnitLogging = GUI_YES;
                    }
                    else
                    {
                        allUnitsCurrentlyLogging = GUI_NO;
                    }
                    if (QCOM_LogDataPresent(unit))
                    {
                        unitLogState[unitNumber] |= QCOM_UPDATE_UNIT_LOG_HAS_DATA;
                        atLeastOneLogHasData = GUI_YES;
                        if (unit->dataLogFlags & QCOM_UNIT_LOG_DATA_UNSAVED)
                        {
                            unitLogState[unitNumber] |= QCOM_UPDATE_UNIT_LOG_DATA_UNSAVED;
                            atLeastOneUnitHasUnsavedLogData = GUI_YES;
                        }
                    }
                    if (unit->dataLogPoints & QCOM_UNIT_LOG_TIME_STAMP)
                        unitLogState[unitNumber] |= QCOM_UPDATE_UNIT_LOG_TIME_STAMP;
                    if (unit->dataLogFlags & QCOM_UNIT_LOG_DISPLAY_SUMMARY)
                        unitLogState[unitNumber] |= QCOM_UPDATE_UNIT_LOG_DISPLAY_SUMMARY;
                    else
                        allLogSummariesDisplayed = GUI_NO;
                    if (unit->dataLogFlags & QCOM_UNIT_LOG_DISPLAY_WRAP)
                        unitLogState[unitNumber] |= QCOM_UPDATE_UNIT_LOG_DISPLAY_WRAP;
                    if (QCOM_LogFileKnown(unit))
                        unitLogState[unitNumber] |= QCOM_UPDATE_UNIT_LOG_FILE_SPECIFIED;
                    if (unit->dataLogFlags & QCOM_UNIT_LOG_FILE_AUTO_SAVE)
                        unitLogState[unitNumber] |= QCOM_UPDATE_UNIT_LOG_FILE_AUTO_SAVE;
                    //--------------------------------------------------------
                    // Set unit test flags
                    //--------------------------------------------------------
                    if (unit->testFlags & QCOM_UNIT_TEST_ALL)
                    {
                        unitTestState[unitNumber] |= QCOM_UPDATE_UNIT_TEST_ALL;
                        if (unit->testFlags & QCOM_UNIT_TEST_ALL_TRANSDUCER)
                        {
                            unitTestState[unitNumber] |= QCOM_UPDATE_UNIT_TEST_TRANSDUCER;
                            if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_DISPLAY_XD_TESTS)
                            {
                                atLeastOneUnitHasTestsSelected = GUI_YES;
                            }
                        }
                        if (unit->testFlags & QCOM_UNIT_TEST_ALL_MODULE)
                        {
                            atLeastOneUnitHasTestsSelected = GUI_YES;
                        }
                    }
                    if (unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING)
                    {
                        unitTestState[unitNumber] |= QCOM_UPDATE_UNIT_TEST_TESTING;
                        atLeastOneUnitTesting = GUI_YES;
                    }
                    else
                    {
                        allUnitsCurrentlyTesting = GUI_NO;
                    }
                    if (unit->testFlags & QCOM_UNIT_TEST_LOOPING_ENABLED)
                        unitTestState[unitNumber] |= QCOM_UPDATE_UNIT_TEST_LOOPING_ENABLED;
                    else
                        allTestsLoopingEnabled = GUI_NO;
                    if (unit->testFlags & QCOM_UNIT_TEST_LOOP_FOREVER)
                        unitTestState[unitNumber] |= QCOM_UPDATE_UNIT_TEST_LOOP_FOREVER;
                    else
                        allTestsLoopForever = GUI_NO;
                    if (QCOM_TestResultsPresent(unit))
                    {
                        atLeastOneUnitHasTestResults = GUI_YES;
                        unitTestState[unitNumber] |= QCOM_UPDATE_UNIT_TEST_HAS_RESULTS;
                        if (unit->testFlags & QCOM_UNIT_TEST_RESULTS_UNSAVED)
                            atLeastOneUnitHasUnsavedTestResults = GUI_YES;
                    }
                    if (unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED)
                    {
                        unitTestState[unitNumber] |= QCOM_UPDATE_UNIT_TEST_FILE_SPECIFIED;
                    }
                    if (QCOM_TestResultsDisplayed(unit))
                    {
                        unitTestState[unitNumber] |= QCOM_UPDATE_UNIT_TEST_DISPLAY_RESULTS;
                    }
                    else
                    {
                        allTestResultsDisplayed = GUI_NO;
                    }
                    if (unit->testFlags & QCOM_UNIT_TEST_RESULTS_WRAP)
                        unitTestState[unitNumber] |= QCOM_UPDATE_UNIT_TEST_DISPLAY_WRAP;
                    //--------------------------------------------------------
                    // Set expert flags
                    //--------------------------------------------------------
                    if (unit->flags & QCOM_UNIT_SEND_XD_READINGS)
                    {
                        unitExpertState[unitNumber] |= QCOM_UPDATE_UNIT_SEND_READINGS;
                        atLeastOneUnitSending = GUI_YES;
                    }
                }                       // end of if (QCOM_UnitNumberValid(unitNumber))
                else
                {
                    allUnitsCurrentlySampling = GUI_NO;
                    allUnitsCurrentlyLogging = GUI_NO;
                    allUnitsCurrentlyTesting = GUI_NO;
                }
            }                           // end of for (DWORD unitNumber = 0; ...) [first pass]
            //----------------------------------------------------------------
            // The case in which no units are valid
            //----------------------------------------------------------------
            if (noUnitsAreValid)
            {
            }
            //----------------------------------------------------------------
            // Second pass: set unit object states accordingly
            //----------------------------------------------------------------
            for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
            {
                if (UGO_UnitValid(unitNumber))
                {
                    UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                    if (UGO_ModuleSNValid(unitNumber) && !UGO_IsCalMux(unitNumber))
                    {
                        if (!expertTabControl->Controls->Contains(expertUnitTabPageArray[unitNumber]))
                        {
                            if (expertTabControl->InvokeRequired)
                            {
                                array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                                {
                                    expertTabControl,
                                    expertUnitTabPageArray[unitNumber]
                                };
                                expertTabControl->BeginInvoke(gcnew QCOM_AddTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageAddDelegate), unitTabPageArray);
                                delete [] unitTabPageArray;
                            }
                            else
                                expertTabControl->Controls->Add(expertUnitTabPageArray[unitNumber]);
                        }
                        if (!loggingTabControl->Controls->Contains(logAllUnitTabPageArray[unitNumber]))
                        {
                            if (loggingTabControl->InvokeRequired)
                            {
                                array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                                {
                                    loggingTabControl,
                                    logAllUnitTabPageArray[unitNumber]
                                };
                                loggingTabControl->BeginInvoke(gcnew QCOM_AddTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageAddDelegate), unitTabPageArray);
                                delete [] unitTabPageArray;
                            }
                            else
                                loggingTabControl->Controls->Add(logAllUnitTabPageArray[unitNumber]);
                        }
                        if (!readoutTabControl->Controls->Contains(readoutUnitTabPageArray[unitNumber]))
                        {
                            if (readoutTabControl->InvokeRequired)
                            {
                                array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                                {
                                    readoutTabControl,
                                    readoutUnitTabPageArray[unitNumber]
                                };
                                readoutTabControl->BeginInvoke(gcnew QCOM_AddTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageAddDelegate), unitTabPageArray);
                                delete [] unitTabPageArray;
                            }
                            else
                                readoutTabControl->Controls->Add(readoutUnitTabPageArray[unitNumber]);
                        }
                        if (!testingTabControl->Controls->Contains(testingUnitTabPageArray[unitNumber]))
                        {
                            if (testingTabControl->InvokeRequired)
                            {
                                array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                                {
                                    testingTabControl,
                                    testingUnitTabPageArray[unitNumber]
                                };
                                testingTabControl->BeginInvoke(gcnew QCOM_AddTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageAddDelegate), unitTabPageArray);
                                delete [] unitTabPageArray;
                            }
                            else
                                testingTabControl->Controls->Add(testingUnitTabPageArray[unitNumber]);
                        }
                        if (!utilitiesTabControl->Controls->Contains(utilitiesUnitTabPageArray[unitNumber]))
                        {
                            if (utilitiesTabControl->InvokeRequired)
                            {
                                array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                                {
                                    utilitiesTabControl,
                                    utilitiesUnitTabPageArray[unitNumber]
                                };
                                utilitiesTabControl->BeginInvoke(gcnew QCOM_AddTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageAddDelegate), unitTabPageArray);
                                delete [] unitTabPageArray;
                            }
                            else
                                utilitiesTabControl->Controls->Add(utilitiesUnitTabPageArray[unitNumber]);
                        }
                        if (!miscTabControl->Controls->Contains(miscTabPageArray[unitNumber]))
                        {
                            if (miscTabControl->InvokeRequired)
                            {
                                array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                                {
                                    miscTabControl,
                                    miscTabPageArray[unitNumber]
                                };
                                miscTabControl->BeginInvoke(gcnew QCOM_AddTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageAddDelegate), unitTabPageArray);
                                delete [] unitTabPageArray;
                            }
                            else
                                miscTabControl->Controls->Add(miscTabPageArray[unitNumber]);
                        }
                    }                   // end of if (UGO_ModuleSNValid(unitNumber) && !UGO_IsCalMux(unitNumber))
                    else
                    {
                        if (expertTabControl->Controls->Contains(expertUnitTabPageArray[unitNumber]))
                        {
                            if (expertTabControl->InvokeRequired)
                            {
                                array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                                {
                                    expertTabControl,
                                    expertUnitTabPageArray[unitNumber]
                                };
                                expertTabControl->BeginInvoke(gcnew QCOM_RemoveTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageRemoveDelegate), unitTabPageArray);
                                delete [] unitTabPageArray;
                            }
                            else
                                expertTabControl->Controls->Remove(expertUnitTabPageArray[unitNumber]);
                        }
                        if (loggingTabControl->Controls->Contains(logAllUnitTabPageArray[unitNumber]))
                        {
                            if (loggingTabControl->InvokeRequired)
                            {
                                array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                                {
                                    loggingTabControl,
                                    logAllUnitTabPageArray[unitNumber]
                                };
                                loggingTabControl->BeginInvoke(gcnew QCOM_RemoveTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageRemoveDelegate), unitTabPageArray);
                                delete [] unitTabPageArray;
                            }
                            else
                                loggingTabControl->Controls->Remove(logAllUnitTabPageArray[unitNumber]);
                        }
                        if (readoutTabControl->Controls->Contains(readoutUnitTabPageArray[unitNumber]))
                        {
                            if (readoutTabControl->InvokeRequired)
                            {
                                array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                                {
                                    readoutTabControl,
                                    readoutUnitTabPageArray[unitNumber]
                                };
                                readoutTabControl->BeginInvoke(gcnew QCOM_RemoveTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageRemoveDelegate), unitTabPageArray);
                                delete [] unitTabPageArray;
                            }
                            else
                                readoutTabControl->Controls->Remove(readoutUnitTabPageArray[unitNumber]);
                        }
                        if (testingTabControl->Controls->Contains(testingUnitTabPageArray[unitNumber]))
                        {
                            if (testingTabControl->InvokeRequired)
                            {
                                array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                                {
                                    testingTabControl,
                                    testingUnitTabPageArray[unitNumber]
                                };
                                testingTabControl->BeginInvoke(gcnew QCOM_RemoveTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageRemoveDelegate), unitTabPageArray);
                                delete [] unitTabPageArray;
                            }
                            else
                                testingTabControl->Controls->Remove(testingUnitTabPageArray[unitNumber]);
                        }
                        if (utilitiesTabControl->Controls->Contains(utilitiesUnitTabPageArray[unitNumber]))
                        {
                            if (utilitiesTabControl->InvokeRequired)
                            {
                                array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                                {
                                    utilitiesTabControl,
                                    utilitiesUnitTabPageArray[unitNumber]
                                };
                                utilitiesTabControl->BeginInvoke(gcnew QCOM_RemoveTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageRemoveDelegate), unitTabPageArray);
                                delete [] unitTabPageArray;
                            }
                            else
                                utilitiesTabControl->Controls->Remove(utilitiesUnitTabPageArray[unitNumber]);
                        }
                        if (miscTabControl->Controls->Contains(miscTabPageArray[unitNumber]))
                        {
                            if (miscTabControl->InvokeRequired)
                            {
                                array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                                {
                                    miscTabControl,
                                    miscTabPageArray[unitNumber]
                                };
                                miscTabControl->BeginInvoke(gcnew QCOM_RemoveTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageRemoveDelegate), unitTabPageArray);
                                delete [] unitTabPageArray;
                            }
                            else
                                miscTabControl->Controls->Remove(miscTabPageArray[unitNumber]);
                        }
                    }                   // end of else of if (UGO_ModuleSNValid(unitNumber) && !UGO_IsCalMux(unitNumber))
                    if (UGO_IncludeInSampling(unitNumber))
                    {
                        if (!UGO_CurrentlySampling(unitNumber))
                        {
                            if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
                            {
//                                unit->flags |= QCOM_UNIT_CURRENTLY_SAMPLING;
//                                unitState[unitNumber] |= QCOM_UPDATE_UNIT_SAMPLING;
                            }
                        }
//
// This code caused problems, starting one unit logging when it wasn't selected for logging
//
//                        if (!UGO_CurrentlyLogging(unitNumber))
//                        {
//                            if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING)
//                            {
//                                unit->dataLogFlags |= QCOM_UNIT_LOG_CURRENTLY_LOGGING;
//                                unitLogState[unitNumber] |= QCOM_UPDATE_UNIT_LOG_LOGGING;
//                            }
//                        }
                    }
                    else
                    {
                        if (UGO_CurrentlySampling(unitNumber))
                        {
                            unit->flags &= ~QCOM_UNIT_CURRENTLY_SAMPLING;
                            unitState[unitNumber] &= ~QCOM_UPDATE_UNIT_SAMPLING;
                        }
                        if (UGO_CurrentlyLogging(unitNumber))
                        {
                            unit->dataLogFlags &= ~QCOM_UNIT_LOG_CURRENTLY_LOGGING;
                            unitLogState[unitNumber] &= ~QCOM_UPDATE_UNIT_LOG_LOGGING;
                        }
                    }
                    if (UGO_XDPowered(unitNumber))
                    {
                        expertTransducerPowerButtonArray[unitNumber]->Text = _T("Disable Transducer Power");
                        expertTransducerPowerButtonArray[unitNumber]->BackgroundImage = sandBackground;
                    }
                    else
                    {
                        expertTransducerPowerButtonArray[unitNumber]->Text = _T("Enable Transducer Power");
                        expertTransducerPowerButtonArray[unitNumber]->BackgroundImage = violetStuccoBackground;
                    }
                    //--------------------------------------------------------
                    // Unit readout objects
                    //--------------------------------------------------------
                    if (UGO_CurrentlySampling(unitNumber))
                    {
                        readoutStartStopSamplingButtonArray[unitNumber]->Text = GUI_STOP_SAMPLING_STRING_1;
                        graphingStartStopSamplingButtonArray[unitNumber]->Text = GUI_STOP_SAMPLING_STRING_1;
                        readoutPressureBoxArray[unitNumber]->BackColor = Color::Aquamarine;
                        readoutTemperatureBoxArray[unitNumber]->BackColor = Color::Aquamarine;
                        readoutPressureFrequencyBoxArray[unitNumber]->BackColor = Color::Aquamarine;
                        readoutTemperatureFrequencyBoxArray[unitNumber]->BackColor = Color::Aquamarine;
                        readoutVoltageBoxArray[unitNumber]->BackColor = Color::Aquamarine;
                        readoutAmperageBoxArray[unitNumber]->BackColor = Color::Aquamarine;
                        if ((unitNumber == 0) && expertRealTimeWeightStartStopButtonArray[unitNumber])
                            expertRealTimeWeightStartStopButtonArray[unitNumber]->Text = _T("Stop");
                    }
                    else
                    {
                        readoutStartStopSamplingButtonArray[unitNumber]->Text = GUI_START_SAMPLING_STRING_1;
                        graphingStartStopSamplingButtonArray[unitNumber]->Text = GUI_START_SAMPLING_STRING_1;
                        readoutPressureBoxArray[unitNumber]->BackColor = Color::Lavender;
                        readoutTemperatureBoxArray[unitNumber]->BackColor = Color::Lavender;
                        readoutPressureFrequencyBoxArray[unitNumber]->BackColor = Color::Lavender;
                        readoutTemperatureFrequencyBoxArray[unitNumber]->BackColor = Color::Lavender;
                        readoutVoltageBoxArray[unitNumber]->BackColor = Color::Lavender;
                        readoutAmperageBoxArray[unitNumber]->BackColor = Color::Lavender;
                        if ((unitNumber == 0) && expertRealTimeWeightStartStopButtonArray[unitNumber])
                            expertRealTimeWeightStartStopButtonArray[unitNumber]->Text = _T("Start");
                    }
                    readoutIncludeInSamplingCheckArray[unitNumber]->Checked = UGO_IncludeInSampling(unitNumber);
                    //--------------------------------------------------------
                    // Readout counts displays
                    //--------------------------------------------------------
                    readoutPressureUnitsLabelArray[unitNumber]->Visible = UGO_DisplayCounts(unitNumber) ? GUI_NO : GUI_YES;
                    readoutTemperatureUnitsLabelArray[unitNumber]->Visible = UGO_DisplayCounts(unitNumber) ? GUI_NO : GUI_YES;
                    //--------------------------------------------------------
                    // Readout pressure and temperature units
                    //--------------------------------------------------------
                    readoutPressureUnitsLabelArray[unitNumber]->Text =
                        QCOM_PressureUnitsStringArray[QCOM_CurrentPressureUnits];
                    readoutTemperatureUnitsLabelArray[unitNumber]->Text =
                        QCOM_TemperatureUnitsStringArray[QCOM_CurrentTemperatureUnits];
                    //--------------------------------------------------------
                    // Graphing objects
                    //--------------------------------------------------------
                    QCOM_GraphingReflectBoundaryValues(unit);
                    graphingPressureUnitsLabelArray[unitNumber]->Text =
                        QCOM_PressureUnitsStringArray[QCOM_CurrentPressureUnits];
                    graphingPressureHighBoundaryUnitsLabelArray[unitNumber]->Text =
                        QCOM_PressureUnitsStringArray[QCOM_CurrentPressureUnits];
                    graphingPressureLowBoundaryUnitsLabelArray[unitNumber]->Text =
                        QCOM_PressureUnitsStringArray[QCOM_CurrentPressureUnits];
                    graphingTemperatureUnitsLabelArray[unitNumber]->Text =
                        QCOM_TemperatureUnitsStringArray[QCOM_CurrentTemperatureUnits];
                    graphingTemperatureHighBoundaryUnitsLabelArray[unitNumber]->Text =
                        QCOM_TemperatureUnitsStringArray[QCOM_CurrentTemperatureUnits];
                    graphingTemperatureLowBoundaryUnitsLabelArray[unitNumber]->Text =
                        QCOM_TemperatureUnitsStringArray[QCOM_CurrentTemperatureUnits];
                    graphingDefaultPTUnitsRadioArray[unitNumber]->Text = String::Concat(
                        QCOM_PressureUnitsStringArray[QCOM_DefaultPressureUnits], _T(" / "),
                        QCOM_TemperatureUnitsStringArray[QCOM_DefaultTemperatureUnits], _T(" (default)"));
                    graphingAlternatePTUnitsRadioArray[unitNumber]->Text = String::Concat(
                        QCOM_PressureUnitsStringArray[QCOM_AlternatePressureUnits], _T(" / "),
                        QCOM_TemperatureUnitsStringArray[QCOM_AlternateTemperatureUnits], _T(" (alternate)"));
                    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_DISPLAY_ALT_UNITS)
                    {
                        graphingDefaultPTUnitsRadioArray[unitNumber]->Checked = GUI_NO;
                        graphingAlternatePTUnitsRadioArray[unitNumber]->Checked = GUI_YES;
                    }
                    else
                    {
                        graphingDefaultPTUnitsRadioArray[unitNumber]->Checked = GUI_YES;
                        graphingAlternatePTUnitsRadioArray[unitNumber]->Checked = GUI_NO;
                    }
                    graphingTimeBetweenSamplesLabelArray[unitNumber]->Text = String::Concat(
                        _T("Time Between Samples:  "),
                        String::Concat(QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_RECENT_OFFSET]),
                        QCOM_STRING_SPACE,
                        QCOM_IntervalUnitsStringArray[QCOM_CurrentIntervalUnitsOffset]);
                    //--------------------------------------------------------
                    // Readout frequency objects
                    //--------------------------------------------------------
                    readoutDisplayFrequenciesCheckArray[unitNumber]->Checked = UGO_DisplayFrequencies(unitNumber);
                    readoutPressureFrequencyBoxArray[unitNumber]->Visible = UGO_DisplayFrequencies(unitNumber);
                    readoutTemperatureFrequencyBoxArray[unitNumber]->Visible = UGO_DisplayFrequencies(unitNumber);
                    readoutPressureFrequencyUnitsLabelArray[unitNumber]->Visible = UGO_DisplayFrequencies(unitNumber);
                    readoutTemperatureFrequencyUnitsLabelArray[unitNumber]->Visible = UGO_DisplayFrequencies(unitNumber);
                    readoutPressureFrequencyTitleLabelArray[unitNumber]->Visible = UGO_DisplayFrequencies(unitNumber);
                    readoutTemperatureFrequencyTitleLabelArray[unitNumber]->Visible = UGO_DisplayFrequencies(unitNumber);
                    //--------------------------------------------------------
                    // Readout voltage and amperage objects
                    //--------------------------------------------------------
                    readoutDisplayVIValuesCheckArray[unitNumber]->Checked = UGO_DisplayVI(unitNumber);
                    readoutVoltageBoxArray[unitNumber]->Visible = UGO_DisplayVI(unitNumber);
                    readoutAmperageBoxArray[unitNumber]->Visible = UGO_DisplayVI(unitNumber);
                    readoutVoltageTitleLabelArray[unitNumber]->Visible = UGO_DisplayVI(unitNumber);
                    readoutAmperageTitleLabelArray[unitNumber]->Visible = UGO_DisplayVI(unitNumber);
                    readoutVoltageUnitsLabelArray[unitNumber]->Visible = UGO_DisplayVI(unitNumber);
                    readoutAmperageUnitsLabelArray[unitNumber]->Visible = UGO_DisplayVI(unitNumber);
                    //--------------------------------------------------------
                    // Readout objects enabled by transducer presence
                    //--------------------------------------------------------
                    readoutPressureTitleLabelArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutPressureBoxArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutPressureUnitsLabelArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutTemperatureTitleLabelArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutTemperatureBoxArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutTemperatureUnitsLabelArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutPressureFrequencyTitleLabelArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutPressureFrequencyBoxArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutPressureFrequencyUnitsLabelArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutTemperatureFrequencyTitleLabelArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutTemperatureFrequencyBoxArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutTemperatureFrequencyUnitsLabelArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutVoltageTitleLabelArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutVoltageBoxArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutVoltageUnitsLabelArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutAmperageTitleLabelArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutAmperageBoxArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    readoutAmperageUnitsLabelArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                    //--------------------------------------------------------
                    // Unit log objects
                    //--------------------------------------------------------
                    logUnitDefPressureCheckArray[unitNumber]->Text = String::Concat(
                        _T("Pressure "), QCOM_PressureUnitsStringArray[QCOM_DefaultPressureUnits]);
                    logUnitAltPressureCheckArray[unitNumber]->Text = String::Concat(
                        _T("Pressure "), QCOM_PressureUnitsStringArray[QCOM_AlternatePressureUnits]);
                    logUnitDefTemperatureCheckArray[unitNumber]->Text = String::Concat(
                        _T("Temperature "), QCOM_TemperatureUnitsStringArray[QCOM_DefaultTemperatureUnits]);
                    logUnitAltTemperatureCheckArray[unitNumber]->Text = String::Concat(
                        _T("Temperature "), QCOM_TemperatureUnitsStringArray[QCOM_AlternateTemperatureUnits]);
                    //--------------------------------------------------------
                    // Unit log objects
                    //--------------------------------------------------------
                    if (UGO_CurrentlyLogging(unitNumber))
                    {
                        logAllBoxArray[unitNumber]->BackColor = Color::Aquamarine;
                        logUnitBoxArray[unitNumber]->BackColor = Color::Aquamarine;
                        logAllStartStopButtonArray[unitNumber]->Text = GUI_STOP_LOGGING_STRING_1;
                        logUnitStartStopButtonArray[unitNumber]->Text = GUI_STOP_LOGGING_STRING_1;
                        readoutStartStopLoggingButtonArray[unitNumber]->Text = GUI_STOP_LOGGING_STRING_1;
                        graphingStartStopLoggingButtonArray[unitNumber]->Text = GUI_STOP_LOGGING_STRING_1;
                    }
                    else
                    {
                        logAllBoxArray[unitNumber]->BackColor = Color::Lavender;
                        logUnitBoxArray[unitNumber]->BackColor = Color::Lavender;
                        logAllStartStopButtonArray[unitNumber]->Text = GUI_START_LOGGING_STRING_1;
                        logUnitStartStopButtonArray[unitNumber]->Text = GUI_START_LOGGING_STRING_1;
                        readoutStartStopLoggingButtonArray[unitNumber]->Text = GUI_START_LOGGING_STRING_1;
                        graphingStartStopLoggingButtonArray[unitNumber]->Text = GUI_START_LOGGING_STRING_1;
                    }
                    if (UGO_LogFileKnown(unitNumber))
                    {
                        logAllSelectFileButtonArray[unitNumber]->Text = GUI_CHANGE_DATA_LOG_FILE;
                        logUnitSelectFileButtonArray[unitNumber]->Text = GUI_CHANGE_DATA_LOG_FILE;
                    }
                    else
                    {
                        logAllSelectFileButtonArray[unitNumber]->Text = GUI_SELECT_DATA_LOG_FILE;
                        logUnitSelectFileButtonArray[unitNumber]->Text = GUI_SELECT_DATA_LOG_FILE;
                    }
                    logUnitAutoSaveRadioArray[unitNumber]->Checked = UGO_LogFileAutoSave(unitNumber);
                    logUnitPromptRadioArray[unitNumber]->Checked = !UGO_LogFileAutoSave(unitNumber);
                    logAllBoxArray[unitNumber]->WordWrap = UGO_LogDisplayWrap(unitNumber);
                    logUnitBoxArray[unitNumber]->WordWrap = UGO_LogDisplayWrap(unitNumber);
                    logUnitMillisecondsCheckArray[unitNumber]->Enabled = UGO_LogTimeStamp(unitNumber);
                    if ((unit->dataLogPoints & QCOM_UNIT_LOG_PRESSURE_COUNT) ||
                        (unit->dataLogPoints & QCOM_UNIT_LOG_TEMP_COUNT))
                        logUnitCountsInHexCheckArray[unitNumber]->Enabled = GUI_YES;
                    else
                        logUnitCountsInHexCheckArray[unitNumber]->Enabled = GUI_NO;
                    if (unit->loggingStats->startTime)
                    {
                        logUnitTimeLabelArray[unitNumber]->Visible = GUI_YES;
                    }
                    else
                    {
                        logUnitTimeLabelArray[unitNumber]->Visible = GUI_NO;
                    }
                    logAllStartStopButtonArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                    logUnitStartStopButtonArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                    utilLogUnitDisplayButtonArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                    utilDisplayTCCheckButtonArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                    //--------------------------------------------------------
                    // Logging objects that depend on log file presence
                    //--------------------------------------------------------
                    logAllAppendOverwriteGroupBoxArray[unitNumber]->Enabled = UGO_LogFileKnown(unitNumber);
                    logUnitAppendOverwriteGroupBoxArray[unitNumber]->Enabled = UGO_LogFileKnown(unitNumber);
                    logAllEmbedCaptionCheckArray[unitNumber]->Enabled = UGO_LogFileKnown(unitNumber);
                    logUnitEmbedCaptionCheckArray[unitNumber]->Enabled = UGO_LogFileKnown(unitNumber);
                    //--------------------------------------------------------
                    // Unit test objects
                    //--------------------------------------------------------
                    if (UGO_CurrentlyTesting(unitNumber))
                    {
                        if (UGO_TestDisplayResults(unitNumber))
                        {
                            testingSummaryResultsBoxArray[unitNumber]->BackColor = Color::Aquamarine;
                            testingDetailedResultsBoxArray[unitNumber]->BackColor = Color::Aquamarine;
                        }
                        testingStartStopButtonArray[unitNumber]->Text =
                            GUI_STOP_ALL_UNIT_TESTS_STRING;
                    }
                    else
                    {
                        if (UGO_TestDisplayResults(unitNumber))
                        {
                            testingSummaryResultsBoxArray[unitNumber]->BackColor = Color::Lavender;
                            testingDetailedResultsBoxArray[unitNumber]->BackColor = Color::Lavender;
                        }
                        testingStartStopButtonArray[unitNumber]->Text =
                            GUI_RUN_SELECTED_TESTS_STRING;
                    }
                    if (!UGO_TestDisplayResults(unitNumber))
                    {
                        testingSummaryResultsBoxArray[unitNumber]->Clear();
                        testingDetailedResultsBoxArray[unitNumber]->Clear();
                    }
                    testingStartStopButtonArray[unitNumber]->Update();
                    if (UGO_TestLoopingEnabled(unitNumber))
                    {
                        DWORD currentLoopNumber = (DWORD)
                            (((((DWORD) testingPassCountLabelArray[unitNumber]->Tag) & 0xFFFFFF00) >> 8) & 0x00FFFFFF);
                        if (UGO_TestLoopForever(unitNumber))
                        {
                            testingPassCountLabelArray[unitNumber]->Text = String::Format(
                                "Loop {0:D}", currentLoopNumber);
                        }
                        else
                        {
                            testingPassCountLabelArray[unitNumber]->Text = String::Format(
                                "Loop {0:D} / {1:D}",
                                currentLoopNumber,
                                QCOM_TestLoopCount);
                        }
                    }
                    testingPassCountLabelArray[unitNumber]->Visible = UGO_TestLoopingEnabled(unitNumber);
                    if (UGO_TestFileKnown(unitNumber))
                        testingSelectResultsFileButtonArray[unitNumber]->Text = GUI_CHANGE_TEST_RESULTS_FILE;
                    else
                        testingSelectResultsFileButtonArray[unitNumber]->Text = GUI_SELECT_TEST_RESULTS_FILE;
                    testingSummaryResultsBoxArray[unitNumber]->WordWrap = UGO_TestDisplayWrap(unitNumber);
                    testingDetailedResultsBoxArray[unitNumber]->WordWrap = UGO_TestDisplayWrap(unitNumber);
                    testingSaveResultsButtonArray[unitNumber]->Enabled = UGO_TestHasResults(unitNumber);
                    testingClearResultsButtonArray[unitNumber]->Enabled = UGO_TestHasResults(unitNumber);
                    if (UGO_CurrentlyTesting(unitNumber))
                    {
                        testingI2CCheckArray[unitNumber]->Enabled = GUI_NO;
                        testingReadingsCheckArray[unitNumber]->Enabled = GUI_NO;
                    }
                    else
                    {
                        if (UGO_UnitReady(unitNumber))
                        {
                            testingI2CCheckArray[unitNumber]->Enabled = GUI_YES;
                            testingReadingsCheckArray[unitNumber]->Enabled = GUI_YES;
                        }
                        else
                        {
                            testingI2CCheckArray[unitNumber]->Enabled = GUI_NO;
                            testingI2CCheckArray[unitNumber]->Checked = GUI_NO;
                            unit->testFlags &= ~QCOM_UNIT_TEST_I2C_TEST;
                            testingReadingsCheckArray[unitNumber]->Enabled = GUI_NO;
                            testingReadingsCheckArray[unitNumber]->Checked = GUI_NO;
                            unit->testFlags &= ~QCOM_UNIT_TEST_READINGS_TEST;
                        }
                    }
                    if (UGO_XDPresent(unitNumber) && UGO_XDHasMemory(unitNumber))
                    {
                        miscReadXDMemoryButtonArray[unitNumber]->Visible = GUI_YES;
                        miscWriteXDMemoryButtonArray[unitNumber]->Visible = GUI_YES;
                        miscDisplayRawXDCoeffButtonArray[unitNumber]->Visible = GUI_YES;
                        testingXDMemoryCheckArray[unitNumber]->Enabled =
                            UGO_CurrentlyTesting(unitNumber) ? GUI_NO :
                                UGO_UnitReady(unitNumber);
                    }
                    else
                    {
                        miscReadXDMemoryButtonArray[unitNumber]->Visible = GUI_NO;
                        miscWriteXDMemoryButtonArray[unitNumber]->Visible = GUI_NO;
                        miscDisplayRawXDCoeffButtonArray[unitNumber]->Visible = GUI_NO;
                        testingXDMemoryCheckArray[unitNumber]->Enabled = GUI_NO;
                        unit->testFlags &= ~QCOM_UNIT_TEST_XD_MEMORY_TEST;
                    }
                    if (UGO_XDFrequency(unitNumber))
                    {
                        miscToggleTransducerTypeButtonArray[unitNumber]->Text =
                            GUI_SWITCH_TO_DIGITAL_TRANSDUCER;
                        testingXDIntegrityCheckArray[unitNumber]->Text = _T("Analog Integrity Test");
                    }
                    else
                    {
                        miscToggleTransducerTypeButtonArray[unitNumber]->Text =
                            GUI_SWITCH_TO_FREQUENCY_TRANSDUCER;
                        testingXDIntegrityCheckArray[unitNumber]->Text = _T("Digital Integrity Test");
                    }
                    testingAllTransducerCheckArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                    testingXDCommCheckArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                    testingXDIntegrityCheckArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                    if (UGO_BootLoaderMode(unitNumber))
                    {
                        miscBootLoaderButtonArray[unitNumber]->Text = GUI_RESET_BOOT_LOADER_MODE;
                    }
                    else
                    {
                        miscBootLoaderButtonArray[unitNumber]->Text = GUI_ENTER_BOOT_LOADER_MODE;
                    }
                    //--------------------------------------------------------
                    // Unit expert objects
                    //--------------------------------------------------------
                    expertSendTransducerReadingsCheckArray[unitNumber]->Checked = UGO_SendReadings(unitNumber);
                    expertSendTransducerReadingsCheckArray[unitNumber]->Enabled =
                        (StringSet(expertTextMessageToNumberBox->Text) || StringSet(expertEmailMessageToAddressBox->Text)) ?
                            GUI_YES : GUI_NO;
                    if (UGO_XDHasMemory(unitNumber))
                    {
                        multipleCoefficientDataWindowArray[unitNumber]->Height = GUI_UNIT_MULTIPLE_CF_WINDOW_HEIGHT_XD;
                        for (int slotNumber = 0; slotNumber < 4; slotNumber++)
                            multipleModuleCopyButtonArray[unitNumber][slotNumber]->Visible = GUI_YES;
                    }
                    else
                    {
                        multipleCoefficientDataWindowArray[unitNumber]->Height = GUI_UNIT_MULTIPLE_CF_WINDOW_HEIGHT_NO_XD;
                        for (int slotNumber = 0; slotNumber < 4; slotNumber++)
                            multipleModuleCopyButtonArray[unitNumber][slotNumber]->Visible = GUI_NO;
                    }
                    //--------------------------------------------------------
                    // Title strings for unit objects
                    //--------------------------------------------------------
                    miscTabPageArray[unitNumber]->Text = unit->moduleSerialNumber;
                    logUnitWindowArray[unitNumber]->Text = String::Concat(
                        _T("Data Logging for "),
                        unit->unitDescriptionString);
//                    logUnitWindowArray[unitNumber]->Text = String::Concat(
//                        "Data Logging for ",
//                        (UGO_XDFrequency(unitNumber) ?
//                            "Frequency (Analog)" : "Digital"),
//                        " Transducer ",
//                        (QCOM_XDSNValid(unit) ? unit->transducerSerialNumber : String::Empty));
//                    logUnitWindowArray[unitNumber]->Text = String::Concat(
//                        logUnitWindowArray[unitNumber]->Text,
//                        " on Module ",
//                        unit->moduleSerialNumber);
                    graphingWindowArray[unitNumber]->Text = String::Concat(
                        _T("Graphs for "),
                        unit->unitDescriptionString);
                    graphingTransducerPartNumberLabelArray[unitNumber]->Text = unit->transducerPartNumber;
                    graphingTransducerSerialNumberLabelArray[unitNumber]->Text = String::Concat(
                        _T("S/N "), unit->transducerSerialNumber);
                    multipleCoefficientDataWindowArray[unitNumber]->Text = String::Concat(
                        _T("Multiple Coefficient Storage for "),
                        unit->unitDescriptionString);
                    expertGroupBoxArray[unitNumber]->Text = unit->unitDescriptionString;
                    readoutGroupBoxArray[unitNumber]->Text = unit->unitDescriptionString;
                    logAllGroupBoxArray[unitNumber]->Text = unit->unitDescriptionString;
                    testingGroupBoxArray[unitNumber]->Text = unit->unitDescriptionString;
                    utilitiesGroupBoxArray[unitNumber]->Text = unit->unitDescriptionString;
                    expertUnitTabPageArray[unitNumber]->Text = unit->moduleSerialNumber;
                    readoutUnitTabPageArray[unitNumber]->Text = unit->moduleSerialNumber;
                    testingUnitTabPageArray[unitNumber]->Text = unit->moduleSerialNumber;
                    utilitiesUnitTabPageArray[unitNumber]->Text = unit->moduleSerialNumber;
                    logAllUnitTabPageArray[unitNumber]->Text = unit->moduleSerialNumber;
                    if (UGO_UnitValid(unitNumber))
                    {
                        miscUnitGroupBoxArray[unitNumber]->Text = unit->unitDescriptionString;
                    }
                    else
                    {
                        miscUnitGroupBoxArray[unitNumber]->Text = String::Concat(
                            "Miscellaneous Controls and Utilities for Unit ",
                            unitNumber);
                    }
                    QCOM_LogUnitReflectDataPresence(unit);
                }                       // end of if (UGO_UnitValid(unitNumber))
                else
                {
                    if (expertTabControl->Controls->Contains(expertUnitTabPageArray[unitNumber]))
                    {
                        if (expertTabControl->InvokeRequired)
                        {
                            array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                            {
                                expertTabControl,
                                expertUnitTabPageArray[unitNumber]
                            };
                            expertTabControl->BeginInvoke(gcnew QCOM_RemoveTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageRemoveDelegate), unitTabPageArray);
                            delete [] unitTabPageArray;
                        }
                        else
                            expertTabControl->Controls->Remove(expertUnitTabPageArray[unitNumber]);
                    }
                    if (loggingTabControl->Controls->Contains(logAllUnitTabPageArray[unitNumber]))
                    {
                        if (loggingTabControl->InvokeRequired)
                        {
                            array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                            {
                                loggingTabControl,
                                logAllUnitTabPageArray[unitNumber]
                            };
                            loggingTabControl->BeginInvoke(gcnew QCOM_RemoveTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageRemoveDelegate), unitTabPageArray);
                            delete [] unitTabPageArray;
                        }
                        else
                            loggingTabControl->Controls->Remove(logAllUnitTabPageArray[unitNumber]);
                    }
                    if (readoutTabControl->Controls->Contains(readoutUnitTabPageArray[unitNumber]))
                    {
                        if (readoutTabControl->InvokeRequired)
                        {
                            array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                            {
                                readoutTabControl,
                                readoutUnitTabPageArray[unitNumber]
                            };
                            readoutTabControl->BeginInvoke(gcnew QCOM_RemoveTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageRemoveDelegate), unitTabPageArray);
                            delete [] unitTabPageArray;
                        }
                        else
                            readoutTabControl->Controls->Remove(readoutUnitTabPageArray[unitNumber]);
                    }
                    if (testingTabControl->Controls->Contains(testingUnitTabPageArray[unitNumber]))
                    {
                        if (testingTabControl->InvokeRequired)
                        {
                            array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                            {
                                testingTabControl,
                                testingUnitTabPageArray[unitNumber]
                            };
                            testingTabControl->BeginInvoke(gcnew QCOM_RemoveTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageRemoveDelegate), unitTabPageArray);
                            delete [] unitTabPageArray;
                        }
                        else
                            testingTabControl->Controls->Remove(testingUnitTabPageArray[unitNumber]);
                    }
                    if (utilitiesTabControl->Controls->Contains(utilitiesUnitTabPageArray[unitNumber]))
                    {
                        if (utilitiesTabControl->InvokeRequired)
                        {
                            array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                            {
                                utilitiesTabControl,
                                utilitiesUnitTabPageArray[unitNumber]
                            };
                            utilitiesTabControl->BeginInvoke(gcnew QCOM_RemoveTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageRemoveDelegate), unitTabPageArray);
                            delete [] unitTabPageArray;
                        }
                        else
                            utilitiesTabControl->Controls->Remove(utilitiesUnitTabPageArray[unitNumber]);
                    }
                    if (miscTabControl->Controls->Contains(miscTabPageArray[unitNumber]))
                    {
                        if (miscTabControl->InvokeRequired)
                        {
                            array <Object ^> ^unitTabPageArray = gcnew array <Object ^>
                            {
                                miscTabControl,
                                miscTabPageArray[unitNumber]
                            };
                            miscTabControl->BeginInvoke(gcnew QCOM_RemoveTabPageDelegate(this, &QCOM_GUIClass::QCOM_TabPageRemoveDelegate), unitTabPageArray);
                            delete [] unitTabPageArray;
                        }
                        else
                            miscTabControl->Controls->Remove(miscTabPageArray[unitNumber]);
                    }
                }                       // end of else of if (UGO_UnitValid(unitNumber))
                logAllGroupBoxArray[unitNumber]->Visible = UGO_UnitValid(unitNumber);
                miscGetModuleSerialNumberGroupBoxArray[unitNumber]->Enabled = UGO_UnitValid(unitNumber);
                miscGetSetI2CDataRateGroupBoxArray[unitNumber]->Enabled = UGO_UnitOpen(unitNumber);
                miscGetFirmwareIDGroupBoxArray[unitNumber]->Enabled = UGO_UnitOpen(unitNumber);
                miscGetTransducerChipIDGroupBoxArray[unitNumber]->Enabled = (UGO_UnitValid(unitNumber) && UGO_UnitOpen(unitNumber)) ? GUI_YES : GUI_NO;
                miscGetTransducerTypeGroupBoxArray[unitNumber]->Enabled = (UGO_UnitValid(unitNumber) && UGO_UnitOpen(unitNumber)) ? GUI_YES : GUI_NO;
                miscGetMemoryTypeGroupBoxArray[unitNumber]->Enabled = UGO_UnitOpen(unitNumber);
                miscI2CSendCommandGroupBoxArray[unitNumber]->Enabled = UGO_UnitOpen(unitNumber);
                miscGetStatusRegisterGroupBoxArray[unitNumber]->Enabled = UGO_UnitOpen(unitNumber);
                miscGetControlRegisterGroupBoxArray[unitNumber]->Enabled = UGO_UnitOpen(unitNumber);
                miscGetErrorCodeGroupBoxArray[unitNumber]->Enabled = UGO_UnitOpen(unitNumber);
                miscGetCadenceTimerGroupBoxArray[unitNumber]->Enabled = UGO_UnitOpen(unitNumber);
                miscReadXDMemoryButtonArray[unitNumber]->Enabled = (UGO_UnitValid(unitNumber) && UGO_UnitOpen(unitNumber)) ? GUI_YES : GUI_NO;
                miscWriteXDMemoryButtonArray[unitNumber]->Enabled = (UGO_UnitValid(unitNumber) && UGO_UnitOpen(unitNumber)) ? GUI_YES : GUI_NO;
                miscDisplayRawModuleCoeffButtonArray[unitNumber]->Enabled = UGO_UnitOpen(unitNumber);
                miscDisplayRawXDCoeffButtonArray[unitNumber]->Enabled = (UGO_UnitValid(unitNumber) && UGO_UnitOpen(unitNumber)) ? GUI_YES : GUI_NO;
                miscDisplayDLLFunctionsButtonArray[unitNumber]->Enabled = UGO_UnitOpen(unitNumber);
                miscBootLoaderButtonArray[unitNumber]->Enabled = UGO_UnitOpen(unitNumber);
            }                           // end of for (DWORD unitNumber = 0; ...) [second pass]
            for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
            {
            }                           // end of for (DWORD unitNumber = 0; ...) [middle pass]
            //----------------------------------------------------------------
            // Third pass: Settings made relative to other unit object states
            //----------------------------------------------------------------
            for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
            {
                if (UGO_UnitValid(unitNumber))
                {
                    UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
                    //--------------------------------------------------------
                    // Unit objects affected by either general sampling or
                    // general testing
                    //--------------------------------------------------------
                    if (atLeastOneUnitSampling || atLeastOneUnitTesting)
                    {
                        logUnitPauseResumeButtonArray[unitNumber]->Enabled = GUI_YES;
                        graphingPauseResumeButtonArray[unitNumber]->Enabled = GUI_YES;
                        utilResetModuleButtonArray[unitNumber]->Enabled = GUI_NO;
                        utilResetTransducerButtonArray[unitNumber]->Enabled = GUI_NO;
                        utilDisplayTCCheckButtonArray[unitNumber]->Enabled = GUI_NO;
                        utilImportCoefficientDataFileButtonArray[unitNumber]->Enabled = GUI_NO;
                        utilExportCoefficientDataFileButtonArray[unitNumber]->Enabled = GUI_NO;
                        utilUpdateFirmwareButtonArray[unitNumber]->Enabled = GUI_NO;
                        expertTransducerPowerButtonArray[unitNumber]->Enabled = GUI_NO;
                    }
                    else
                    {
                        logUnitPauseResumeButtonArray[unitNumber]->Enabled = GUI_NO;
                        graphingPauseResumeButtonArray[unitNumber]->Enabled = GUI_NO;
                        utilResetModuleButtonArray[unitNumber]->Enabled = GUI_YES;
                        utilResetTransducerButtonArray[unitNumber]->Enabled = UGO_XDPresent(unitNumber);
                        utilDisplayTCCheckButtonArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                        utilImportCoefficientDataFileButtonArray[unitNumber]->Enabled = GUI_YES;
                        utilExportCoefficientDataFileButtonArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                        utilUpdateFirmwareButtonArray[unitNumber]->Enabled = GUI_YES;
                        expertTransducerPowerButtonArray[unitNumber]->Enabled = GUI_YES;
                    }
                    //--------------------------------------------------------
                    // Unit objects affected by general sampling
                    //--------------------------------------------------------
                    if (atLeastOneUnitSampling)
                    {
                        testingStartStopButtonArray[unitNumber]->Enabled = GUI_NO;
                    }
                    else
                    {
                        //----------------------------------------------------
                        // Enable test fixture objects that depend on test
                        // selection and visibility
                        //----------------------------------------------------
                        if (unit->testFlags & QCOM_UNIT_TEST_ALL)
                        {
                            if (unit->testFlags & QCOM_UNIT_TEST_ALL_MODULE)
                            {
                                testingStartStopButtonArray[unitNumber]->Enabled = GUI_YES;
                            }
                            else
                            {
                                if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_DISPLAY_XD_TESTS)
                                {
                                    if (unit->testFlags & QCOM_UNIT_TEST_ALL_TRANSDUCER)
                                    {
                                        testingStartStopButtonArray[unitNumber]->Enabled = GUI_YES;
                                    }
                                    else
                                    {
                                        testingStartStopButtonArray[unitNumber]->Enabled = GUI_NO;
                                    }
                                }
                                else
                                {
                                    testingStartStopButtonArray[unitNumber]->Enabled = GUI_NO;
                                }
                            }
                        }
                        else
                        {
                            testingStartStopButtonArray[unitNumber]->Enabled = GUI_NO;
                        }
                    }
                    //--------------------------------------------------------
                    // General Readout objects
                    //--------------------------------------------------------
                    if (atLeastOneUnitTesting)
                    {
                        readoutStartStopLoggingButtonArray[unitNumber]->Enabled = GUI_NO;
                        readoutStartStopSamplingButtonArray[unitNumber]->Enabled = GUI_NO;
                        readoutDisplayDataGraphButtonArray[unitNumber]->Enabled = GUI_NO;
                        graphingStartStopSamplingButtonArray[unitNumber]->Enabled = GUI_NO;
                        graphingStartStopLoggingButtonArray[unitNumber]->Enabled = GUI_NO;
                    }
                    else
                    {
                        readoutStartStopLoggingButtonArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                        readoutStartStopSamplingButtonArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                        readoutDisplayDataGraphButtonArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                        graphingStartStopSamplingButtonArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                        graphingStartStopLoggingButtonArray[unitNumber]->Enabled = UGO_UnitReady(unitNumber);
                    }
                    readoutIncludeInSamplingCheckArray[unitNumber]->Enabled =
                        (numberOfTransducers > 1) ? GUI_YES : GUI_NO;
                    //--------------------------------------------------------
                    // Objects affected by function
                    //--------------------------------------------------------
                    QCOM_LogUnitUpdateChecks(unit);
                    QCOM_TestUnitUpdateChecks(unit);
                    QCOM_UpdateFirmwareDisplays(unit);
                    expertGroupBoxArray[unitNumber]->Update();
                    logAllGroupBoxArray[unitNumber]->Update();
                    readoutGroupBoxArray[unitNumber]->Update();
                    testingGroupBoxArray[unitNumber]->Update();
                    utilitiesGroupBoxArray[unitNumber]->Update();
                }
            }                           // end of for (DWORD unitNumber = 0; ...) [third pass]
            //----------------------------------------------------------------
            // Determine general object states
            //----------------------------------------------------------------
            if (atLeastOneUnitSampling || atLeastOneUnitTesting)
            {
                utilResetAllUnitsButton->Enabled = GUI_NO;
                rescanFunctionTSButton->Enabled = GUI_NO;
                resetTSDDButton->Enabled = GUI_NO;
                resetAllFunctionTSButton->Enabled = GUI_NO;
                resetAllModulesFunctionTSButton->Enabled = GUI_NO;
                resetAllTransducersFunctionTSButton->Enabled = GUI_NO;
                resetSoftwareFunctionTSButton->Enabled = GUI_NO;
            }
            else
            {
                utilResetAllUnitsButton->Enabled = atLeastOneUnitValid;
                rescanFunctionTSButton->Enabled = GUI_YES;
                resetTSDDButton->Enabled = GUI_YES;
                resetAllFunctionTSButton->Enabled = GUI_YES;
                resetAllModulesFunctionTSButton->Enabled = atLeastOneUnitValid;
                resetAllTransducersFunctionTSButton->Enabled = atLeastOneTransducerAvailable;
                resetSoftwareFunctionTSButton->Enabled = GUI_YES;
            }
            if (atLeastOneUnitSampling)
            {
                readoutStartStopAllSamplingButton->Text = GUI_STOP_SAMPLING_STRING_2;
                homeSamplingStatusButton->BackgroundImage = yellowLEDOnImage;
                homeSamplingStatusLabel->Text = GUI_STATUS_SAMPLING_STRING;
                homeSamplingStatusLabel->ForeColor = Color::Red;
                if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED))
                {
                    samplingTimer->Start();
                }
            }
            else
            {
                readoutStartStopAllSamplingButton->Text = GUI_START_SAMPLING_STRING_2;
                homeSamplingStatusButton->BackgroundImage = yellowLEDOffImage;
                homeSamplingStatusLabel->Text = GUI_STATUS_NOT_SAMPLING_STRING;
                homeSamplingStatusLabel->ForeColor = Color::OliveDrab;
                samplingTimer->Stop();
            }
            if (atLeastOneUnitLogging)
            {
                homeLoggingStatusButton->BackgroundImage = yellowLEDOnImage;
                homeLoggingStatusLabel->Text = GUI_STATUS_LOGGING_STRING;
                homeLoggingStatusLabel->ForeColor = Color::Red;
                logAllStartStopButton->Text = GUI_STOP_ALL_LOGGING_STRING_1;
                readoutStartStopAllLoggingButton->Text = GUI_STOP_ALL_LOGGING_STRING_2;
            }
            else
            {
                homeLoggingStatusButton->BackgroundImage = yellowLEDOffImage;
                homeLoggingStatusLabel->Text = GUI_STATUS_NOT_LOGGING_STRING;
                homeLoggingStatusLabel->ForeColor = Color::OliveDrab;
                logAllStartStopButton->Text = GUI_START_ALL_LOGGING_STRING_1;
                readoutStartStopAllLoggingButton->Text = GUI_START_ALL_LOGGING_STRING_2;
            }
            if (atLeastOneUnitTesting)
            {
                testingStartStopAllButton->Text = GUI_STOP_ALL_TESTS_STRING;
                homeTestingStatusButton->BackgroundImage = yellowLEDOnImage;
                homeTestingStatusLabel->Text = GUI_STATUS_TESTING_STRING;
                homeTestingStatusLabel->ForeColor = Color::Red;
                QCOM_GeneralInfo->testFlags |= QCOM_GENERAL_TEST_CURRENTLY_TESTING;
            }
            else
            {
                testingStartStopAllButton->Text = GUI_TEST_ALL_UNITS_STRING;
                homeTestingStatusButton->BackgroundImage = yellowLEDOffImage;
                homeTestingStatusLabel->Text = GUI_STATUS_NOT_TESTING_STRING;
                homeTestingStatusLabel->ForeColor = Color::OliveDrab;
                QCOM_GeneralInfo->testFlags &= ~QCOM_GENERAL_TEST_CURRENTLY_TESTING;
            }
            if (atLeastOneUnitSending)
            {
                homeSendingStatusButton->BackgroundImage = yellowLEDOnImage;
                homeSendingStatusLabel->Text = GUI_STATUS_SENDING_STRING;
                homeSendingStatusLabel->ForeColor = Color::Red;
            }
            else
            {
                homeSendingStatusButton->BackgroundImage = yellowLEDOffImage;
                homeSendingStatusLabel->Text = GUI_STATUS_NOT_SENDING_STRING;
                homeSendingStatusLabel->ForeColor = Color::OliveDrab;
            }
            //----------------------------------------------------------------
            // Set general objects
            //----------------------------------------------------------------
            QCOM_CurrentSamplingInterval =
                QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_RECENT_OFFSET];
            readoutDisplayAllFrequenciesCheck->Checked =
                (QCOM_GeneralInfo->flags & QCOM_GENERAL_DISPLAY_ALL_FREQUENCIES) ?
                    GUI_YES : GUI_NO;
            readoutDisplayAllVIValuesCheck->Checked =
                (QCOM_GeneralInfo->flags & QCOM_GENERAL_DISPLAY_ALL_VI_VALUES) ?
                    GUI_YES : GUI_NO;
            readoutStartStopAllSamplingButton->Enabled =
                (atLeastOneUnitReady && atLeastOneUnitCanBeSampled && !atLeastOneUnitTesting) ?
                    GUI_YES : GUI_NO;
            readoutSamplingIntervalBox->Text = String::Concat(QCOM_CurrentSamplingInterval);
            readoutSamplingIntervalBox->BackColor = atLeastOneUnitSampling ? Color::Gainsboro : Color::White;
            readoutSamplingIntervalBox->Enabled = atLeastOneUnitSampling ? GUI_NO : GUI_YES;
            readoutSamplingIntervalBox->ReadOnly = atLeastOneUnitSampling;
            readoutIncludeAllInSamplingCheck->Enabled = moreThanOneUnitReady;
            readoutIncludeAllInSamplingCheck->Checked =
                (QCOM_GeneralInfo->flags & QCOM_GENERAL_INCLUDE_ALL_IN_SAMPLING) ?
                    GUI_YES : GUI_NO;
            readoutIntervalUnitsLabel->Text = QCOM_IntervalUnitsStringArray[QCOM_CurrentIntervalUnitsOffset];
            readoutIntervalRangeLabel->Text = String::Format(
                "({0:D} to {1:D} {2})",
                QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MINIMUM_OFFSET],
                QCOM_CurrentIntervalUnitsArray[QCOM_CurrentIntervalUnitsOffset][GUI_INTERVAL_MAXIMUM_OFFSET],
                QCOM_IntervalUnitsStringArray[QCOM_CurrentIntervalUnitsOffset]);
            //----------------------------------------------------------------
            // Set general log objects
            //----------------------------------------------------------------
            logAllStartStopButton->Enabled = atLeastOneUnitReady;
            logAllIntervalBox->Text = readoutSamplingIntervalBox->Text;
            logAllIntervalBox->BackColor = atLeastOneUnitSampling ? Color::Gainsboro : Color::White;
            logAllIntervalBox->Enabled = atLeastOneUnitSampling ? GUI_NO : GUI_YES;
            logAllIntervalBox->ReadOnly = atLeastOneUnitSampling;
            logAllIntervalUnitsLabel->Text = readoutIntervalUnitsLabel->Text;
            logAllIntervalRangeLabel->Text = readoutIntervalRangeLabel->Text;
            readoutClearAllLogsButton->Enabled = atLeastOneLogHasData;
            readoutStartStopAllLoggingButton->Enabled =
                (atLeastOneUnitReady && atLeastOneUnitCanBeSampled && !atLeastOneUnitTesting) ?
                    GUI_YES : GUI_NO;
            utilLogAllDisplayButton->Enabled = atLeastOneUnitReady;
            logAllInsertCommentBox->BackColor = atLeastOneUnitValid ? Color::White : Color::Gainsboro;
            logAllInsertCommentGroupBox->Enabled = atLeastOneUnitValid;
            logAllDisplaySummariesCheck->Checked =
                (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DISPLAY_SUMMARIES) ?
                    GUI_YES : GUI_NO;
            logAllPrependEntryNumbersCheck->Checked =
                (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS) ?
                    GUI_YES : GUI_NO;
            logAllDisplayWrapCheck->Checked =
                (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DISPLAY_WRAP) ?
                    GUI_YES : GUI_NO;
            logAllBothFileFormatsCheck->Checked =
                (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_FILE_BOTH_FORMATS) ?
                    GUI_YES : GUI_NO;
            logAllSaveLoggedDataImmediatelyCheck->Checked =
                (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_DATA_SAVE_IMMEDIATELY) ?
                    GUI_YES : GUI_NO;
            //----------------------------------------------------------------
            // Set general test objects
            //----------------------------------------------------------------
            testingSaveAllResultsButton->Enabled = atLeastOneUnitHasTestResults;
            testingStartStopAllButton->Enabled =
                (atLeastOneUnitHasTestsSelected && !atLeastOneUnitSampling) ?
                    GUI_YES : GUI_NO;
            testingDisplayTransducerTestsCheck->Enabled =
                (atLeastOneTransducerAvailable && !atLeastOneUnitTesting) ?
                    GUI_YES : GUI_NO;
            testingResetAllTestsButton->Enabled =
                (atLeastOneUnitHasTestsSelected && !atLeastOneUnitTesting) ?
                    GUI_YES : GUI_NO;
            testingClearAllResultsButton->Enabled =
                (atLeastOneUnitHasTestResults && !atLeastOneUnitTesting) ?
                    GUI_YES : GUI_NO;
            testingLoopCountBox->BackColor = atLeastOneUnitTesting ? Color::Gainsboro : Color::White;
            testingLoopCountBox->Enabled = atLeastOneUnitTesting ? GUI_NO : GUI_YES;
            if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_LOOPING_ENABLED)
            {
                testingLoopCountBox->Visible = GUI_YES;
                testingLoopLimitsLabel->Visible = GUI_YES;
                testingLoopForeverCheck->Visible = GUI_YES;
            }
            else
            {
                testingLoopCountBox->Visible = GUI_NO;
                testingLoopLimitsLabel->Visible = GUI_NO;
                testingLoopForeverCheck->Visible = GUI_NO;
            }
            testingDetailAllCheck->Checked =
                (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_DETAILED) ?
                    GUI_YES : GUI_NO;
            testingLoopForeverCheck->Checked =
                (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_LOOP_FOREVER) ?
                    GUI_YES : GUI_NO;
            testingStopOnErrorsCheck->Checked =
                (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_STOP_ON_ERRORS) ?
                    GUI_YES : GUI_NO;
            testingDisplayTestResultsCheck->Checked = allTestResultsDisplayed;
            testingAppendCheck->Checked =
                (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_APPEND) ?
                    GUI_YES : GUI_NO;
            testingAutoSaveCheck->Checked =
                (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_AUTO_SAVE) ?
                    GUI_YES : GUI_NO;
            testingWrapCheck->Checked =
                (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_RESULTS_WRAP) ?
                    GUI_YES : GUI_NO;
            testingInsertCommentBox->BackColor = atLeastOneUnitValid ? Color::White : Color::Gainsboro;
            testingInsertCommentGroupBox->Enabled = atLeastOneUnitValid;
            testingInsertCommentTimeStampCheck->Checked =
                (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_TIME_STAMP_COMMENTS) ?
                    GUI_YES : GUI_NO;
            //----------------------------------------------------------------
            // Other general objects
            //----------------------------------------------------------------
            expertProgramIntervalBox->Text = String::Concat(QCOM_CurrentProgramInterval);
            if (!atLeastOneUnitSampling && QCOM_ProgramIntervalEnabled)
            {
                expertProgramIntervalBox->BackColor = Color::White;
                expertProgramIntervalBox->Enabled = GUI_YES;
            }
            else
            {
                expertProgramIntervalBox->BackColor = Color::Gainsboro;
                expertProgramIntervalBox->Enabled = GUI_NO;
            }
            expertExperimentNumberBox->Text = String::Concat(QCOM_CurrentExperimentNumber);
            readoutContinuousSamplingTimeLabel->Visible =
                QCOM_SamplingStartTime ? GUI_YES : GUI_NO;
            logAllContinuousLoggingTimeLabel->Visible =
                QCOM_LoggingStartTime ? GUI_YES : GUI_NO;
            if (atLeastOneUnitSampling || atLeastOneUnitTesting)
            {
                readoutPauseResumeButton->Enabled = GUI_YES;
                logAllPauseResumeButton->Enabled = GUI_YES;
                testingPauseResumeButton->Enabled = GUI_YES;
            }
            else
            {
                readoutPauseResumeButton->Enabled = GUI_NO;
                logAllPauseResumeButton->Enabled = GUI_NO;
                testingPauseResumeButton->Enabled = GUI_NO;
            }
            //----------------------------------------------------------------
            // Modify objects based on unique general flags
            //----------------------------------------------------------------
            readoutPrecisionNumeric->Value = (int) QCOM_CurrentPrecision;
            readoutDefaultPressureTemperatureRadio->Text = String::Concat(
                QCOM_PressureUnitsStringArray[QCOM_DefaultPressureUnits], _T(" / "),
                QCOM_TemperatureUnitsStringArray[QCOM_DefaultTemperatureUnits], _T(" (default)"));
            readoutAlternatePressureTemperatureRadio->Text = String::Concat(
                QCOM_PressureUnitsStringArray[QCOM_AlternatePressureUnits], _T(" / "),
                QCOM_TemperatureUnitsStringArray[QCOM_AlternateTemperatureUnits], _T(" (alternate)"));
            if (QCOM_GeneralInfo->flags & QCOM_GENERAL_DISPLAY_COUNTS)
            {
                readoutDefaultPressureTemperatureRadio->Checked = GUI_NO;
                readoutAlternatePressureTemperatureRadio->Checked = GUI_NO;
                readoutCountsRadio->Checked = GUI_YES;
                readoutHexCheck->Visible = GUI_YES;
//                readoutHexCheck->Checked = allCountsDisplayedInHex;
                readoutHexCheck->Checked =
                    (QCOM_GeneralInfo->flags & QCOM_GENERAL_DISPLAY_COUNTS_IN_HEX) ?
                        GUI_YES : GUI_NO;
                readoutPrecisionLabel->Visible = GUI_NO;
                readoutPrecisionNumeric->Visible = GUI_NO;
            }
            else
            {
                if (QCOM_GeneralInfo->flags & QCOM_GENERAL_DISPLAY_ALT_UNITS)
                {
                    readoutAlternatePressureTemperatureRadio->Checked = GUI_YES;
                    readoutDefaultPressureTemperatureRadio->Checked = GUI_NO;
//                    QCOM_CurrentPressureUnits = QCOM_AlternatePressureUnits;
//                    QCOM_CurrentTemperatureUnits = QCOM_AlternateTemperatureUnits;
                }
                else
                {
                    readoutAlternatePressureTemperatureRadio->Checked = GUI_NO;
                    readoutDefaultPressureTemperatureRadio->Checked = GUI_YES;
//                    QCOM_CurrentPressureUnits = QCOM_DefaultPressureUnits;
//                    QCOM_CurrentTemperatureUnits = QCOM_DefaultTemperatureUnits;
                }
                readoutCountsRadio->Checked = GUI_NO;
                readoutHexCheck->Visible = GUI_NO;
                readoutPrecisionLabel->Visible = GUI_YES;
                readoutPrecisionNumeric->Visible = GUI_YES;
            }
            samplingTimer->Interval = QCOM_MapDisplayIntervalToActual(QCOM_CurrentSamplingInterval);
            if (QCOM_CurrentIntervalUnitsOffset == GUI_INTERVAL_MS_OFFSET)
            {
                readoutMillisecondsRadio->Checked = GUI_YES;
                logAllMillisecondsRadio->Checked = GUI_YES;
            }
            else
            {
                readoutMillisecondsRadio->Checked = GUI_NO;
                logAllMillisecondsRadio->Checked = GUI_NO;
            }
            if (QCOM_CurrentIntervalUnitsOffset == GUI_INTERVAL_SEC_OFFSET)
            {
                readoutSecondsRadio->Checked = GUI_YES;
                logAllSecondsRadio->Checked = GUI_YES;
            }
            else
            {
                readoutSecondsRadio->Checked = GUI_NO;
                logAllSecondsRadio->Checked = GUI_NO;
            }
            if (QCOM_CurrentIntervalUnitsOffset == GUI_INTERVAL_MIN_OFFSET)
            {
                readoutMinutesRadio->Checked = GUI_YES;
                logAllMinutesRadio->Checked = GUI_YES;
            }
            else
            {
                readoutMinutesRadio->Checked = GUI_NO;
                logAllMinutesRadio->Checked = GUI_NO;
            }
            if (QCOM_CurrentIntervalUnitsOffset == GUI_INTERVAL_HR_OFFSET)
            {
                readoutHoursRadio->Checked = GUI_YES;
                logAllHoursRadio->Checked = GUI_YES;
            }
            else
            {
                readoutHoursRadio->Checked = GUI_NO;
                logAllHoursRadio->Checked = GUI_NO;
            }
            if (QCOM_GeneralInfo->flags & QCOM_GENERAL_SAMPLING_TIME_LIMITED)
            {
//                readoutRunSamplingTimedCheck->Checked = GUI_YES;
//                readoutLimitSamplingTimeLabel->Visible = GUI_YES;
//                readoutLimitSamplingTimeBox->Visible = GUI_YES;
//                readoutLimitSamplingTimeMinutesLabel->Visible = GUI_YES;
//                logAllRunLoggingTimedCheck->Checked = GUI_YES;
//                logAllRunLoggingTimedCheck->Size = Drawing::Size(60, GUI_REGULAR_CHECK_BOX_HEIGHT);
//                logAllRunLoggingTimedCheck->Text = _T("Run for");
//                logAllLimitLoggingTimeBox->Visible = GUI_YES;
//                logAllLimitLoggingTimeBox->Location = Point(
//                    logAllRunLoggingTimedCheck->Right + 2,
//                    logAllRunLoggingTimedCheck->Top - 2);
//                logAllLimitLoggingTimeMinutesLabel->Location = Point(
//                    logAllLimitLoggingTimeBox->Right + 2,
//                    logAllRunLoggingTimedCheck->Top);
////                logAllLimitLoggingTimeMinutesRemainingLabel->Location = Point(
////                    logAllLimitLoggingTimeMinutesLabel->Right,
////                    logAllLimitLoggingTimeMinutesLabel->Top);
//                logAllLimitLoggingTimeBox->Visible = GUI_YES;
//                logAllLimitLoggingTimeMinutesLabel->Visible = GUI_YES;
                readoutLimitSamplingTimeBox->Text =
                    String::Concat(QCOM_MaximumSamplingRunTimeMinutes);
                logAllLimitLoggingTimeBox->Text =
                    String::Concat(QCOM_MaximumSamplingRunTimeMinutes);
                if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
                {
                    readoutLimitSamplingTimeBox->BackColor = Color::Gainsboro;
                    readoutLimitSamplingTimeBox->Enabled = GUI_NO;
                    logAllLimitLoggingTimeBox->BackColor = Color::Gainsboro;
                    logAllLimitLoggingTimeBox->Enabled = GUI_NO;
                }
                else
                {
                    readoutLimitSamplingTimeBox->BackColor = Color::White;
                    readoutLimitSamplingTimeBox->Enabled = GUI_YES;
                    logAllLimitLoggingTimeBox->BackColor = Color::White;
                    logAllLimitLoggingTimeBox->Enabled = GUI_YES;
                }
            }
            else
            {
                readoutLimitSamplingTimeBox->BackColor = Color::White;
                readoutLimitSamplingTimeBox->Enabled = GUI_YES;
                logAllLimitLoggingTimeBox->BackColor = Color::White;
                logAllLimitLoggingTimeBox->Enabled = GUI_YES;
//                readoutRunSamplingTimedCheck->Checked = GUI_NO;
//                readoutLimitSamplingTimeLabel->Visible = GUI_NO;
//                readoutLimitSamplingTimeBox->Visible = GUI_NO;
//                readoutLimitSamplingTimeMinutesLabel->Visible = GUI_NO;
//                logAllRunLoggingTimedCheck->Checked = GUI_NO;
////                logAllRunLoggingTimedCheck->Size = Drawing::Size(160, GUI_REGULAR_CHECK_BOX_HEIGHT);
//                logAllLimitLoggingTimeBox->Visible = GUI_NO;
//                logAllLimitLoggingTimeMinutesLabel->Visible = GUI_NO;
//                logAllLimitLoggingTimeMinutesRemainingLabel->Visible = GUI_NO;
//                logAllRunLoggingTimedCheck->Text = _T("Run for a time period");
            }
            if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_DISPLAY_XD_TESTS)
            {
                testingDisplayTransducerTestsCheck->Checked = GUI_YES;
            }
            else
            {
                testingDisplayTransducerTestsCheck->Checked = GUI_NO;
            }
            //----------------------------------------------------------------
            // Adjust independent objects
            //----------------------------------------------------------------
            openingBannerLabel->Text = String::Concat(
                numberOfUnits, " QCOM Module",
                (numberOfUnits == 1 ? QCOM_STRING_EMPTY : QCOM_STRING_S), " and ", numberOfTransducers,
                " Transducer", (numberOfTransducers == 1 ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                " attached");
            logAllDataWindow->Text = String::Concat(
                "Data Logging for ", numberOfTransducers, " Transducer",
                (numberOfTransducers == 1 ? QCOM_STRING_EMPTY : QCOM_STRING_S));
            QCOM_UpdateMessageChecks();
        }                               // end of if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_GUI_READY_FOR_UPDATING) && ...)
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_EXITING)
        {
            QCOM_DisplayStackTrace("Should not be called during shutdown");
        }
            //----------------------------------------------------------------
            // Determine general object states
            //----------------------------------------------------------------
    }                                   // end of if (context)
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_UpdateGlobalObjects()
//----------------------------------------------------------------------------
// QCOM_UpdateGlobalObjectsPerFlags
//
// Updates the state, availability, and visibility of all global objects
//
// Called by:   QCOM_UpdateGlobalObjects
//
// Note:    This method enforces the policy that the individual unit flags
//          determine the settings of the general flags
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateGlobalObjectsPerFlags(void)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_UpdateGlobalObjectsPerFlags");
    //------------------------------------------------------------------------
    RecordVerboseEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // General Readout objects
    //------------------------------------------------------------------------
    QCOM_ApplyGeneralFlagToUnitFlags(
        QCOM_GENERAL_DISPLAY_COUNTS, QCOM_UNIT_DISPLAY_COUNTS);
    QCOM_ApplyGeneralFlagToUnitFlags(
        QCOM_GENERAL_DISPLAY_COUNTS_IN_HEX, QCOM_UNIT_DISPLAY_COUNTS_IN_HEX);
    QCOM_ApplyGeneralFlagToUnitFlags(
        QCOM_GENERAL_DISPLAY_ALT_UNITS, QCOM_UNIT_DISPLAY_ALT_UNITS);
    QCOM_ApplyGeneralFlagToUnitFlags(
        QCOM_GENERAL_DISPLAY_ALL_FREQUENCIES, QCOM_UNIT_DISPLAY_FREQUENCIES);
    QCOM_ApplyGeneralFlagToUnitFlags(
        QCOM_GENERAL_DISPLAY_ALL_VI_VALUES, QCOM_UNIT_DISPLAY_VI_VALUES);
    QCOM_ApplyGeneralFlagToUnitFlags(
        QCOM_GENERAL_INCLUDE_ALL_IN_SAMPLING, QCOM_UNIT_INCLUDE_IN_SAMPLING);
    //------------------------------------------------------------------------
    // General Utilities objects
    //------------------------------------------------------------------------
    //------------------------------------------------------------------------
    // General Expert objects
    //------------------------------------------------------------------------
    //------------------------------------------------------------------------
    // General Logging objects
    //------------------------------------------------------------------------
    QCOM_ApplyGeneralLogFlagToUnitFlags(
        QCOM_GENERAL_LOG_DISPLAY_SUMMARIES, QCOM_UNIT_LOG_DISPLAY_SUMMARY);
    QCOM_ApplyGeneralLogFlagToUnitFlags(
        QCOM_GENERAL_LOG_PREPEND_ENTRY_NUMBERS, QCOM_UNIT_LOG_PREPEND_ENTRY_NUMBERS);
    QCOM_ApplyGeneralLogFlagToUnitFlags(
        QCOM_GENERAL_LOG_DISPLAY_WRAP, QCOM_UNIT_LOG_DISPLAY_WRAP);
    QCOM_ApplyGeneralLogFlagToUnitFlags(
        QCOM_GENERAL_LOG_FILE_BOTH_FORMATS, QCOM_UNIT_LOG_FILE_BOTH_FORMATS);
    QCOM_ApplyGeneralLogFlagToUnitFlags(
        QCOM_GENERAL_LOG_DATA_SAVE_IMMEDIATELY, QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY);
    //------------------------------------------------------------------------
    // General Testing objects
    //------------------------------------------------------------------------
    QCOM_ApplyGeneralTestFlagToUnitFlags(
        QCOM_GENERAL_TEST_RESULTS_DETAILED, QCOM_UNIT_TEST_RESULTS_DETAILED);
    QCOM_ApplyGeneralTestFlagToUnitFlags(
        QCOM_GENERAL_TEST_STOP_ON_ERRORS, QCOM_UNIT_TEST_STOP_ON_ERRORS);
    QCOM_ApplyGeneralTestFlagToUnitFlags(
        QCOM_GENERAL_TEST_RESULTS_WRAP, QCOM_UNIT_TEST_RESULTS_WRAP);
    QCOM_ApplyGeneralTestFlagToUnitFlags(
        QCOM_GENERAL_TEST_RESULTS_APPEND, QCOM_UNIT_TEST_RESULTS_APPEND);
    QCOM_ApplyGeneralTestFlagToUnitFlags(
        QCOM_GENERAL_TEST_RESULTS_AUTO_SAVE, QCOM_UNIT_TEST_RESULTS_AUTO_SAVE);
    //------------------------------------------------------------------------
    // General Miscellaneous objects
    //------------------------------------------------------------------------
    //------------------------------------------------------------------------
    // General Program Info objects
    //------------------------------------------------------------------------
    //------------------------------------------------------------------------
    // The following have both general and unit controls
    //------------------------------------------------------------------------
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            QCOM_UpdateGlobalUnitObjectsPerFlags(unit);
            if (unit->testFlags & QCOM_UNIT_TEST_ALL)
                QCOM_GeneralInfo->testFlags |= QCOM_GENERAL_TEST_TESTS_SELECTED;
        }
    }                                   // end of for (DWORD unitNumber = 0; ...)
    RecordVerboseEvent("{0} concluded", functionName);
}                                       // end of QCOM_UpdateGlobalObjectsPerFlags()
//----------------------------------------------------------------------------
// QCOM_UpdateGlobalUnitObjectsPerFlags
//
// Updates the state, availability, and visibility of all global objects that
// belong to the specified unit, based on global flags
//
// Called by:   QCOM_UpdateGlobalObjectsPerFlags
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateGlobalUnitObjectsPerFlags(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_UpdateGlobalUnitObjectsPerFlags");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordVerboseEvent("{0}({1:D}) called", functionName, unitNumber);
        //--------------------------------------------------------------------
        // Unit Readout objects
        //--------------------------------------------------------------------
        //--------------------------------------------------------------------
        // Unit Utilities objects
        //--------------------------------------------------------------------
        //--------------------------------------------------------------------
        // Unit Expert objects
        //--------------------------------------------------------------------
        //--------------------------------------------------------------------
        // Unit Logging objects
        //--------------------------------------------------------------------
        //--------------------------------------------------------------------
        // Unit Testing objects
        //--------------------------------------------------------------------
        //--------------------------------------------------------------------
        // Unit Miscellaneous objects
        //--------------------------------------------------------------------
        //--------------------------------------------------------------------
        // Unit Program Info objects
        //--------------------------------------------------------------------
        //--------------------------------------------------------------------
        // The following unit controls rely on general controls
        //--------------------------------------------------------------------
        if ((QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE) &&
            !(unit->dataLogFlags & QCOM_UNIT_LOG_DATA_SAVE_IMMEDIATELY))
        {
            logUnitPercentFullLabelArray[unitNumber]->Visible = GUI_YES;
            logUnitPercentFullProgressArray[unitNumber]->Visible = GUI_YES;
            logAllPercentFullLabelArray[unitNumber]->Visible = GUI_YES;
            logAllPercentFullProgressArray[unitNumber]->Visible = GUI_YES;
        }
        else
        {
            logUnitPercentFullLabelArray[unitNumber]->Visible = GUI_NO;
            logUnitPercentFullProgressArray[unitNumber]->Visible = GUI_NO;
            logAllPercentFullLabelArray[unitNumber]->Visible = GUI_NO;
            logAllPercentFullProgressArray[unitNumber]->Visible = GUI_NO;
        }
        if (unit->flags & QCOM_UNIT_SEND_XD_READINGS)
        {
            expertSendTransducerReadingsCheckArray[unitNumber]->Checked = GUI_YES;
        }
        else
        {
            expertSendTransducerReadingsCheckArray[unitNumber]->Checked = GUI_NO;
        }
        if (StringSet(expertTextMessageToNumberBox->Text) || StringSet(expertEmailMessageToAddressBox->Text))
        {
            expertSendTransducerReadingsCheckArray[unitNumber]->Enabled = GUI_YES;
            expertSendEveryLabelArray[unitNumber]->Enabled = GUI_YES;
            expertSendEveryBoxArray[unitNumber]->Enabled = GUI_YES;
            expertSendEveryMinutesLabelArray[unitNumber]->Enabled = GUI_YES;
            expertSendEveryMinutesRemainingLabelArray[unitNumber]->Enabled = GUI_YES;
        }
        else
        {
            expertSendTransducerReadingsCheckArray[unitNumber]->Enabled = GUI_NO;
            expertSendEveryLabelArray[unitNumber]->Enabled = GUI_NO;
            expertSendEveryBoxArray[unitNumber]->Enabled = GUI_NO;
            expertSendEveryMinutesLabelArray[unitNumber]->Enabled = GUI_NO;
            expertSendEveryMinutesRemainingLabelArray[unitNumber]->Enabled = GUI_NO;
        }
        if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_DISPLAY_XD_TESTS)
        {
            testingAllTransducerCheckArray[unitNumber]->Visible = GUI_YES;
            testingXDCommCheckArray[unitNumber]->Visible = GUI_YES;
            testingXDIntegrityCheckArray[unitNumber]->Visible = GUI_YES;
            testingXDMemoryCheckArray[unitNumber]->Visible = GUI_YES;
        }
        else
        {
            testingAllTransducerCheckArray[unitNumber]->Visible = GUI_NO;
            testingXDCommCheckArray[unitNumber]->Visible = GUI_NO;
            testingXDIntegrityCheckArray[unitNumber]->Visible = GUI_NO;
            testingXDMemoryCheckArray[unitNumber]->Visible = GUI_NO;
        }
        RecordVerboseEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_UpdateGlobalUnitObjectsPerFlags()
//----------------------------------------------------------------------------
// QCOM_UpdateMessageChecks
//
// Updates the message and event log check marks in the General Expert window,
// plus updates the text of the Advanced tool strip drop-down
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateMessageChecks(void)
{
    //------------------------------------------------------------------------
    expertDetailedMessagesCheck->Checked = QCOM_DetailedMessagesEnabled;
    expertBasicMessagesCheck->Checked = QCOM_BasicMessagesEnabled;
    expertDLLMessagesCheck->Checked = QD_DLLMessagesEnabled;
    expertErrorMessagesCheck->Checked = QCOM_ErrorMessagesEnabled;
    expertExpMessagesCheck->Checked = QCOM_ExpMessagesEnabled;
    expertVerboseMessagesCheck->Checked = QCOM_VerboseMessagesEnabled;
    expertResetMessagesButton->Enabled =
        (QCOM_BasicMessagesEnabled || QCOM_DetailedMessagesEnabled || QD_DLLMessagesEnabled ||
         QCOM_ErrorMessagesEnabled || QCOM_ExpMessagesEnabled || QCOM_VerboseMessagesEnabled) ?
            GUI_YES : GUI_NO;
    expertStackTraceCheck->Checked = QCOM_StackTracesEnabled;
    expertProgramIntervalCheck->Checked = QCOM_ProgramIntervalEnabled;
    expertSendTextErrorMessageCheck->Checked = QCOM_SendTextErrorMessagesEnabled;
    expertSendTextErrorMessageCheck->Enabled =
        StringSet(expertTextMessageToNumberBox->Text) ?
            GUI_YES : GUI_NO;
    expertSendEmailErrorMessageCheck->Checked = QCOM_SendEmailErrorMessagesEnabled;
    expertSendEmailErrorMessageCheck->Enabled =
        StringSet(expertEmailMessageToAddressBox->Text) ?
            GUI_YES : GUI_NO;
    expertExperimentsCheck->Checked = QCOM_ExperimentsEnabled;
    expertExperimentalButton->Visible = QCOM_ExperimentsEnabled;
    expertHaltOperationsOnErrorsCheck->Checked = QCOM_HaltOperationsOnErrors;
    expertExperimentNumberBox->Visible = QCOM_ExperimentsEnabled;
    expertExperimentsButton->Visible = QCOM_ExperimentsEnabled;
    expertRealTimeWeightDemoButton->Visible = QCOM_ExperimentsEnabled;
    //------------------------------------------------------------------------
    // Modify the display of the ToolStrip pull-downs
    //------------------------------------------------------------------------
    eventLogAllTSButton->Text =
        (QCOM_EventLogBasicEnabled || QCOM_EventLogVerboseEnabled || QCOM_EventLogDetailedEnabled) ?
            GUI_ELOG_ALL_STOP_STRING : GUI_ELOG_ALL_START_STRING;
    eventLogBasicTSButton->Text =
        QCOM_EventLogBasicEnabled ?
            GUI_ELOG_BASIC_STOP_STRING : GUI_ELOG_BASIC_START_STRING;
    eventLogVerboseTSButton->Text =
        QCOM_EventLogVerboseEnabled ?
            GUI_ELOG_VERBOSE_STOP_STRING : GUI_ELOG_VERBOSE_START_STRING;
    eventLogDetailedTSButton->Text =
        QCOM_EventLogDetailedEnabled ?
            GUI_ELOG_DETAILED_STOP_STRING : GUI_ELOG_DETAILED_START_STRING;
    eventLogTestTSButton->Text =
        QCOM_EventLogTestEnabled ?
            GUI_ELOG_TEST_STOP_STRING : GUI_ELOG_TEST_START_STRING;
    displayEventLogTSButton->Enabled =
        StringSet(QCOM_GeneralInfo->mostRecentEventLogPath) ?
            GUI_YES : GUI_NO;
}                                       // end of QCOM_UpdateMessageChecks()
//----------------------------------------------------------------------------
// QCOM_UpdateSendEveryMinutesRemainingLabel
//
// Updates the Send Every Minutes label with the current number of minutes
// remaining in the count
//
// Called by:   QCOM_ConstructUnitExpertGroupBox
//              QCOM_LogUnitSnapshotDataButtonClicked
//              QCOM_OneMinuteTimerElapsed
//              QCOM_ValidateSendEveryIntervalValue
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateSendEveryMinutesRemainingLabel(
    DWORD           unitNumber)
{
    String          ^functionName = _T("QCOM_UpdateSendEveryMinutesRemainingLabel");
    //------------------------------------------------------------------------
    if (QCOM_UnitNumberLegal(unitNumber))
    {
        RecordDetailedEvent("{0}({1:D}) called", functionName, unitNumber);
        expertSendEveryMinutesRemainingLabelArray[unitNumber]->Text = String::Format(
            "Will send in less than {0:D} minute{1}",
            QCOM_CurrentSendEveryIntervalRemaining[unitNumber],
            ((QCOM_CurrentSendEveryIntervalRemaining[unitNumber] == 1) ? "" : "s"));
        RecordDetailedEvent("    Send Every interval set for {0:D} minute{1}",
            QCOM_CurrentSendEveryIntervalRemaining[unitNumber],
            ((QCOM_CurrentSendEveryIntervalRemaining[unitNumber] == 1) ? "" : "s"));
        RecordDetailedEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_UpdateSendEveryMinutesRemainingLabel()
//----------------------------------------------------------------------------
// QCOM_UpdateStatusLine
//
// Updates the home status strip message box with the specified managed string
//
// Note:    The status line can hold at most GUI_MAXIMUM_STATUS_LINE_PIXEL_SIZE
//          (556) pixels of text
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UpdateStatusLine(
    String          ^statusString)
{
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_STATUS_LINE_AVAILABLE)
    {
        if (StringSet(statusString))
        {
            homeStatusLineTSSLabel->Text = statusString;
            homeStatusStrip->Update();
        }
        else
        {
            homeStatusLineTSSLabel->Text = String::Empty;
        }
    }
}                                       // end of QCOM_UpdateStatusLine()
//----------------------------------------------------------------------------
#endif      // UPDATE_CPP
//============================================================================
// End of Update.cpp
//============================================================================
