//============================================================================
// Update.h
//
// Header for Update.cpp
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#pragma once
#ifndef     UPDATE_H
#define     UPDATE_H
//----------------------------------------------------------------------------
// Include appropriate headers
//----------------------------------------------------------------------------
#include    "GUI.h"
//----------------------------------------------------------------------------
// The following lines are only seen by Update.cpp
//----------------------------------------------------------------------------
#ifdef      UPDATE_CPP
//----------------------------------------------------------------------------
// The following definitions are used exclusively by QCOM_UpdateGlobalObjects
//----------------------------------------------------------------------------
#define     QCOM_UPDATE_ZERO_FLAG                               0x00000000
#define     QCOM_UPDATE_UNIT_VALID                              0x00000001
#define     QCOM_UPDATE_UNIT_MSN_VALID                          0x00000002
#define     QCOM_UPDATE_UNIT_OPEN                               0x00000004
#define     QCOM_UPDATE_UNIT_READY                              0x00000008
#define     QCOM_UPDATE_UNIT_XD_PRESENT                         0x00000010
#define     QCOM_UPDATE_UNIT_XD_FREQUENCY                       0x00000020
#define     QCOM_UPDATE_UNIT_XD_HAS_MEMORY                      0x00000040
#define     QCOM_UPDATE_UNIT_XD_POWER_ENABLED                   0x00000080
#define     QCOM_UPDATE_UNIT_INCLUDE_IN_SAMPLING                0x00000100
#define     QCOM_UPDATE_UNIT_SAMPLING                           0x00000200
#define     QCOM_UPDATE_UNIT_DISPLAY_COUNTS                     0x00010000
#define     QCOM_UPDATE_UNIT_DISPLAY_FREQUENCIES                0x00020000
#define     QCOM_UPDATE_UNIT_DISPLAY_VI_VALUES                  0x00040000
#define     QCOM_UPDATE_UNIT_CAL_MUX                            0x40000000
#define     QCOM_UPDATE_UNIT_BOOT_LOADER_MODE                   0x80000000
//----------------------------------------------------------------------------
// Unit log flags
//----------------------------------------------------------------------------
#define     QCOM_UPDATE_UNIT_LOG_LOGGING                        0x00000010
#define     QCOM_UPDATE_UNIT_LOG_HAS_DATA                       0x00000020
#define     QCOM_UPDATE_UNIT_LOG_DATA_UNSAVED                   0x00000040
#define     QCOM_UPDATE_UNIT_LOG_DISPLAY_SUMMARY                0x00000100
#define     QCOM_UPDATE_UNIT_LOG_DISPLAY_WRAP                   0x00000200
#define     QCOM_UPDATE_UNIT_LOG_FILE_SPECIFIED                 0x00001000
#define     QCOM_UPDATE_UNIT_LOG_FILE_AUTO_SAVE                 0x00002000
#define     QCOM_UPDATE_UNIT_LOG_TIME_STAMP                     0x00010000
//----------------------------------------------------------------------------
// Unit test flags
//----------------------------------------------------------------------------
#define     QCOM_UPDATE_UNIT_TEST_TESTING                       0x00000010
#define     QCOM_UPDATE_UNIT_TEST_HAS_RESULTS                   0x00000020
#define     QCOM_UPDATE_UNIT_TEST_DISPLAY_RESULTS               0x00000100
#define     QCOM_UPDATE_UNIT_TEST_DISPLAY_WRAP                  0x00000200
#define     QCOM_UPDATE_UNIT_TEST_LOOPING_ENABLED               0x00000400
#define     QCOM_UPDATE_UNIT_TEST_LOOP_FOREVER                  0x00000800
#define     QCOM_UPDATE_UNIT_TEST_FILE_SPECIFIED                0x00001000
#define     QCOM_UPDATE_UNIT_TEST_ALL                           0x00010000
#define     QCOM_UPDATE_UNIT_TEST_TRANSDUCER                    0x00020000
//----------------------------------------------------------------------------
// Unit expert flags
//----------------------------------------------------------------------------
#define     QCOM_UPDATE_UNIT_SEND_READINGS                      0x00010000
//----------------------------------------------------------------------------
// The following macros are used exclusively by QCOM_UpdateGlobalObjects
//----------------------------------------------------------------------------
#define     UGO_UnitValid(U)            ((unitState[U] & QCOM_UPDATE_UNIT_VALID) ? GUI_YES : GUI_NO)
#define     UGO_ModuleSNValid(U)        ((unitState[U] & QCOM_UPDATE_UNIT_MSN_VALID) ? GUI_YES : GUI_NO)
#define     UGO_UnitOpen(U)             ((unitState[U] & QCOM_UPDATE_UNIT_OPEN) ? GUI_YES : GUI_NO)
#define     UGO_UnitReady(U)            ((unitState[U] & QCOM_UPDATE_UNIT_READY) ? GUI_YES : GUI_NO)
#define     UGO_XDPresent(U)            ((unitState[U] & QCOM_UPDATE_UNIT_XD_PRESENT) ? GUI_YES : GUI_NO)
#define     UGO_XDFrequency(U)          ((unitState[U] & QCOM_UPDATE_UNIT_XD_FREQUENCY) ? GUI_YES : GUI_NO)
#define     UGO_XDHasMemory(U)          ((unitState[U] & QCOM_UPDATE_UNIT_XD_HAS_MEMORY) ? GUI_YES : GUI_NO)
#define     UGO_XDPowered(U)            ((unitState[U] & QCOM_UPDATE_UNIT_XD_POWER_ENABLED) ? GUI_YES : GUI_NO)
#define     UGO_IncludeInSampling(U)    ((unitState[U] & QCOM_UPDATE_UNIT_INCLUDE_IN_SAMPLING) ? GUI_YES : GUI_NO)
#define     UGO_CurrentlySampling(U)    ((unitState[U] & QCOM_UPDATE_UNIT_SAMPLING) ? GUI_YES : GUI_NO)
#define     UGO_DisplayCounts(U)        ((unitState[U] & QCOM_UPDATE_UNIT_DISPLAY_COUNTS) ? GUI_YES : GUI_NO)
#define     UGO_DisplayFrequencies(U)   ((unitState[U] & QCOM_UPDATE_UNIT_DISPLAY_FREQUENCIES) ? GUI_YES : GUI_NO)
#define     UGO_DisplayVI(U)            ((unitState[U] & QCOM_UPDATE_UNIT_DISPLAY_VI_VALUES) ? GUI_YES : GUI_NO)
#define     UGO_IsCalMux(U)             ((unitState[U] & QCOM_UPDATE_UNIT_CAL_MUX) ? GUI_YES : GUI_NO)
#define     UGO_BootLoaderMode(U)       ((unitState[U] & QCOM_UPDATE_UNIT_BOOT_LOADER_MODE) ? GUI_YES : GUI_NO)
#define     UGO_CurrentlyLogging(U)     ((unitLogState[U] & QCOM_UPDATE_UNIT_LOG_LOGGING) ? GUI_YES : GUI_NO)
#define     UGO_LogHasData(U)           ((unitLogState[U] & QCOM_UPDATE_UNIT_LOG_LOGGING) ? GUI_YES : GUI_NO)
#define     UGO_LogDisplaySummary(U)    ((unitLogState[U] & QCOM_UPDATE_UNIT_LOG_DISPLAY_SUMMARY) ? GUI_YES : GUI_NO)
#define     UGO_LogDisplayWrap(U)       ((unitLogState[U] & QCOM_UPDATE_UNIT_LOG_DISPLAY_WRAP) ? GUI_YES : GUI_NO)
#define     UGO_LogFileKnown(U)         ((unitLogState[U] & QCOM_UPDATE_UNIT_LOG_FILE_SPECIFIED) ? GUI_YES : GUI_NO)
#define     UGO_LogFileAutoSave(U)      ((unitLogState[U] & QCOM_UPDATE_UNIT_LOG_FILE_AUTO_SAVE) ? GUI_YES : GUI_NO)
#define     UGO_LogTimeStamp(U)         ((unitLogState[U] & QCOM_UPDATE_UNIT_LOG_TIME_STAMP) ? GUI_YES : GUI_NO)
#define     UGO_CurrentlyTesting(U)     ((unitTestState[U] & QCOM_UPDATE_UNIT_TEST_TESTING) ? GUI_YES : GUI_NO)
#define     UGO_TestHasResults(U)       ((unitTestState[U] & QCOM_UPDATE_UNIT_TEST_HAS_RESULTS) ? GUI_YES : GUI_NO)
#define     UGO_TestDisplayResults(U)   ((unitTestState[U] & QCOM_UPDATE_UNIT_TEST_DISPLAY_RESULTS) ? GUI_YES : GUI_NO)
#define     UGO_TestDisplayWrap(U)      ((unitTestState[U] & QCOM_UPDATE_UNIT_TEST_DISPLAY_WRAP) ? GUI_YES : GUI_NO)
#define     UGO_TestLoopingEnabled(U)   ((unitTestState[U] & QCOM_UPDATE_UNIT_TEST_LOOPING_ENABLED) ? GUI_YES : GUI_NO)
#define     UGO_TestLoopForever(U)      ((unitTestState[U] & QCOM_UPDATE_UNIT_TEST_LOOP_FOREVER) ? GUI_YES : GUI_NO)
#define     UGO_TestFileKnown(U)        ((unitTestState[U] & QCOM_UPDATE_UNIT_TEST_FILE_SPECIFIED) ? GUI_YES : GUI_NO)
#define     UGO_TestAllTests(U)         ((unitTestState[U] & QCOM_UPDATE_UNIT_TEST_ALL) ? GUI_YES : GUI_NO)
#define     UGO_TestTransducerTests(U)  ((unitTestState[U] & QCOM_UPDATE_UNIT_TEST_TRANSDUCER) ? GUI_YES : GUI_NO)
#define     UGO_SendReadings(U)         ((unitExpertState[U] & QCOM_UPDATE_UNIT_SEND_READINGS) ? GUI_YES : GUI_NO)
//----------------------------------------------------------------------------
// External global variables
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// End of the lines that are only seen by Update.cpp
//----------------------------------------------------------------------------
#endif      // UPDATE_CPP
#endif      // UPDATE_H
//============================================================================
// End of Update.h
//============================================================================
