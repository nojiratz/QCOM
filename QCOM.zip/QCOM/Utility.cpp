﻿//============================================================================
// Utility.cpp
//
// The methods used by the QCOM software for utility tasks
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#include    "stdafx.h"
#ifndef     UTILITY_CPP
#define     UTILITY_CPP
#include    "Utility.h"
//----------------------------------------------------------------------------
// QCOM_AboutHelp
//
// Displays a small windows that describes the QCOM software and version, plus
// provides some links to Quartzdyne websites
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_AboutHelp(void)
{
    DWORD           yPosition = 10;
    String          ^functionName = _T("QCOM_AboutHelp");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Create a new window form
    //------------------------------------------------------------------------
    aboutHelpWindow = gcnew Form;
    //------------------------------------------------------------------------
    // Set its icon
    //------------------------------------------------------------------------
    aboutHelpWindow->Icon = QCOM_SoftwareIcon;
    //------------------------------------------------------------------------
    // Set the background image
    //------------------------------------------------------------------------
    aboutHelpWindow->BackgroundImage = whiteSandBackground;
    //------------------------------------------------------------------------
    // Set the title, the starting location, the size, and border style
    //------------------------------------------------------------------------
    aboutHelpWindow->Text = _T("About QCOM");
    aboutHelpWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
    aboutHelpWindow->StartPosition = FormStartPosition::CenterScreen;
    //------------------------------------------------------------------------
    // Prevent the user from changing its appearance
    //------------------------------------------------------------------------
    aboutHelpWindow->MaximizeBox = GUI_NO;
    aboutHelpWindow->HelpButton = GUI_NO;
    //------------------------------------------------------------------------
    // Begin pouplating the help text
    //------------------------------------------------------------------------
    QCOM_DisplayHelpTextLine(
        aboutHelpWindow,
        String::Format(
            "QCOM, Version {0} - {1:D}",
            QCOM_PROGRAM_VERSION_STRING,
            QCOM_BuildNumber),
        yPosition,
        300);
    yPosition += 26;
    QCOM_DisplayHelpTextLine(aboutHelpWindow, "Copyright © 2015 Quartzdyne, Inc.", yPosition, 280);
    yPosition += 26;
    //------------------------------------------------------------------------
    // This line contains a link at character offset 12 for 18 characters
    //------------------------------------------------------------------------
    QCOM_DisplayHelpLink(aboutHelpWindow, "Visit us at www.quartzdyne.com", yPosition, 150, 12, 18);
    yPosition += 52;
    QCOM_DisplayHelpTextLine(aboutHelpWindow, "Transducer information communication", yPosition, 304);
    yPosition += 26;
    QCOM_DisplayHelpTextLine(aboutHelpWindow, "software for QCOM modules", yPosition, 254);
    aboutHelpWindow->Size = Drawing::Size(440, yPosition + 70);
    //------------------------------------------------------------------------
    // Add an OK button
    //------------------------------------------------------------------------
    Button ^okButton = gcnew Button;
    okButton->Text = _T("OK");
    okButton->Location = Point(aboutHelpWindow->Width - 80, yPosition);
    okButton->Size = Drawing::Size(60, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(okButton);
    okButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_HelpCloseWindow);
    aboutHelpWindow->Controls->Add(okButton);
    aboutHelpWindow->AcceptButton = okButton; // button when user presses Enter
    aboutHelpWindow->CancelButton = okButton; // button when user presses Esc
    //------------------------------------------------------------------------
    // Display the company logo
    //------------------------------------------------------------------------
    Label ^logo = gcnew Label;
    Image ^QCOMLogo = Image::FromFile(GUI_PROGRAM_LOGO);
    logo->Image = QCOMLogo;
    logo->Location = Point(aboutHelpWindow->Width - 110, 10);
    logo->Size = Drawing::Size(QCOMLogo->Width, QCOMLogo->Height);
    GUI_SetObjectInterfaceProperties(logo);
    logo->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_ToolStripOnlineHelpDropDownClicked);
    logo->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_HelpAboutSoftwareLogoMouseEntered);
    logo->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    aboutHelpWindow->Controls->Add(logo);
    //------------------------------------------------------------------------
    // Finally, display the new window
    //------------------------------------------------------------------------
    aboutHelpWindow->ShowDialog();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_AboutHelp()
//----------------------------------------------------------------------------
// QCOM_CheckModuleRegistryEntry
//
// Checks the Registry for the keys that correspond to the specified module,
// then enters and exits BootLoader Mode if either of the keys is not present
//
// Called by:   QCOM_ScanForDevices
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_CheckModuleRegistryEntry(
    UnitInfo        ^unit)
{
    bool            foundRegularPath = GUI_NO;
    bool            foundTildePath = GUI_NO;
    int             timeout = 15;           // 15-second timeout
    String          ^MSN;
    String          ^registryKeyPath;
    String          ^functionName = _T("QCOM_CheckModuleRegistryEntry");
    //------------------------------------------------------------------------
    if (QCOM_ModuleSNValid(unit))
    {
        RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
        if (QCOM_UnitValid(unit))
        {
            if (unit->moduleSerialNumber->Contains("~"))
                MSN = unit->moduleSerialNumber->Substring(0, unit->moduleSerialNumber->IndexOf("~"));
            else
                MSN = unit->moduleSerialNumber;
            String ^MSNTilde = String::Concat(MSN, "~");
            registryKeyPath = String::Concat(
                "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Enum\\USB\\VID_",
                QCOM_VENDOR_ID_STRING,
                "&PID_",
                QCOM_PRODUCT_ID_STRING,
                "\\");
            String ^registryKeyString = String::Concat(registryKeyPath, MSN);
            String ^registryKeyStringTilde = String::Concat(registryKeyPath, MSNTilde);
            String ^registryKey = (String ^) Registry::GetValue(registryKeyString, "Service", String::Empty);
            if ((StringICompare(registryKey, "QCOM") == 0) || (StringICompare(registryKey, "CalMux") == 0))
            {
                foundRegularPath = GUI_YES;
            }
            else
            {
                RecordErrorEvent(
                    "    QCOM key {0} or its service is not listed in the Registry",
                    MSN);
            }
            String ^registryKeyTilde = (String ^) Registry::GetValue(registryKeyStringTilde, "Service", String::Empty);
            if ((StringICompare(registryKeyTilde, "QCOM") == 0) || (StringICompare(registryKeyTilde, "CalMux") == 0))
            {
                foundTildePath = GUI_YES;
            }
            else
            {
                RecordErrorEvent(
                    "    QCOM key {0} or its service is not listed in the Registry",
                    MSNTilde);
            }
            if (!foundRegularPath || !foundTildePath)
            {
                QCOM_SwitchToBootLoaderMode(unit);
                Sleep(1000);
                QCOM_SwitchFromBootLoaderMode(unit);
                Sleep(2000);
                do
                {
                    if (!foundRegularPath)
                    {
                        registryKey = (String ^) Registry::GetValue(registryKeyString, "Service", String::Empty);
                        if (StringICompare(registryKey, "QCOM") == 0)
                        {
                            foundRegularPath = GUI_YES;
                            RecordBasicEvent(
                                "    Corrected - QCOM key {0} is now properly recorded in the Registry",
                                MSN);
                        }
                        else
                        {
                            if (StringICompare(registryKey, "CalMux") == 0)
                            {
                                foundRegularPath = GUI_YES;
                                RecordBasicEvent(
                                    "    Corrected - CalMux key {0} is now properly recorded in the Registry",
                                    MSN);
                            }
                            else
                            {
                                RecordErrorEvent(
                                    "    QCOM key {0} still not properly listed in the Registry",
                                    MSN);
                            }
                        }
                    }                   // end of if (!foundRegularPath)
                    if (!foundTildePath)
                    {
                        registryKeyTilde = (String ^) Registry::GetValue(registryKeyStringTilde, "Service", String::Empty);
                        if (StringICompare(registryKeyTilde, "QCOM") == 0)
                        {
                            foundTildePath = GUI_YES;
                            RecordBasicEvent(
                                "    Corrected - QCOM key {0} is now properly recorded in the Registry",
                                MSNTilde);
                        }
                        else
                        {
                            if (StringICompare(registryKeyTilde, "CalMux") == 0)
                            {
                                foundTildePath = GUI_YES;
                                RecordBasicEvent(
                                    "    Corrected - CalMux key {0} is now properly recorded in the Registry",
                                    MSNTilde);
                            }
                            else
                            {
                                RecordErrorEvent(
                                    "    QCOM key {0} still not properly listed in the Registry",
                                    MSNTilde);
                            }
                        }
                    }                   // end of if (!foundTildePath)
                    if (!foundRegularPath || !foundTildePath)
                        Thread::Sleep(1000);
                }
                while ((!foundRegularPath || !foundTildePath) && timeout--);
            }                           // end of if (!foundRegularPath || !foundTildePath)
            if (foundRegularPath && foundTildePath)
            {
                unit->flags |= QCOM_UNIT_REGISTRY_CHECKED;
                RecordBasicEvent("    QCOM key {0} is properly listed in the Registry", MSN);
            }
            else
            {
                Modal("The QCOM driver is not configured properly in the Windows Registry");
            }
            delete MSNTilde;
        }                               // end of if (QCOM_UnitValid(unit))
        else
        {
            if (unit->flags & QCOM_UNIT_CMUX_BOX)
            {
                bool foundMuxPath = GUI_NO;
                MSN = unit->moduleSerialNumber;
                registryKeyPath = String::Concat(
                    "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Enum\\USB\\VID_",
                    QCOM_VENDOR_ID_STRING,
                    "&PID_");
                String ^registryKeyString = String::Concat(
                    registryKeyPath,
                    CMUX_OLD_PRODUCT_ID_STRING,
                    "\\",
                    MSN);
                String ^registryKeyStringAlternate = String::Concat(
                    registryKeyPath,
                    CMUX_PRODUCT_ID_STRING,
                    MSN);
                String ^registryKey = (String ^) Registry::GetValue(registryKeyString, "Service", String::Empty);
                if (StringICompare(registryKey, "CalMux") == 0)
                    foundRegularPath = GUI_YES;
                String ^registryKeyAlternate = (String ^) Registry::GetValue(registryKeyStringAlternate, "Service", String::Empty);
                if (StringICompare(registryKeyAlternate, "CalMux") == 0)
                    foundMuxPath = GUI_YES;
                //------------------------------------------------------------
                // The Cal Lab mux box is absent only if both keys are missing
                //------------------------------------------------------------
                if (foundRegularPath || foundMuxPath)
                {
                    unit->flags |= QCOM_UNIT_REGISTRY_CHECKED;
                    RecordBasicEvent("    CalMux key {0} is properly listed in the Registry", MSN);
                }
                else
                {
                    RecordErrorEvent("    CalMux key {0} not listed in the Registry", MSN);
                }
            }                           // end of if (unit->flags & QCOM_UNIT_CMUX_BOX)
        }                               // end of else of if (QCOM_UnitValid(unit))
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_ModuleSNValid(unit))
    else
    {
        if (!unit)
            RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
    }
}                                       // end of QCOM_CheckModuleRegistryEntry()
//----------------------------------------------------------------------------
// QCOM_CleanUpTextBoxTextString
//
// Removes all occurrences of spaces, newlines, tabs, commas, and many other
// unwanted characters in the specified text box text
//----------------------------------------------------------------------------
    String ^ QCOM_GUIClass::
QCOM_CleanUpTextBoxTextString(
    String          ^textBoxText)
{
    array <String ^> ^unwantedStringArray =
        gcnew array <String ^>
            {
                Environment::NewLine, " ", "'", "\n", ",", "=", "|", "~", "/",
                "\\", ";", ":", "!", "#", "$", "%", "^", "&", "*", "\"", "\t",
                "(", ")", "[", "]", "{", "}", "<", ">",
                "+", "?", "`"
            };
    //------------------------------------------------------------------------
    if (StringSet(textBoxText))
    {
        for each (String ^unwantedString in unwantedStringArray)
        {
            if (textBoxText->Contains(unwantedString))
                textBoxText = textBoxText->Replace(unwantedString, QCOM_STRING_EMPTY);
        }
        textBoxText = textBoxText->Trim();
        RecordVerboseEvent("    Cleaned up text box text string: {0}", textBoxText);
    }
    return textBoxText;
}                                       // end of QCOM_CleanUpTextBoxTextString()
//----------------------------------------------------------------------------
// QCOM_ConstructUnitDescriptionString
//
// Constructs the unit description string from the module and transducer
// serial numbers, if they are available
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ConstructUnitDescriptionString(
    UnitInfo        ^unit)
{
    DWORD           unitNumber;
    String          ^functionName = _T("QCOM_ConstructUnitDescriptionString");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit))
    {
        unitNumber = unit->unitNumber;
        RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
        String ^transducerTypeString;
        switch (unit->transducerType)
        {
            case 0 : transducerTypeString =
                (unit->flags & QCOM_UNIT_TRANSDUCER_PRESENT) ?
                    _T("Unknown Type") : _T("No");
                break;
            case 1 : transducerTypeString = _T("Frequency (Analog)"); break;
            case 2 : transducerTypeString = _T("Digital (older type)"); break;
            case 3 :
            case 4 : transducerTypeString = _T("Digital (newer type)"); break;
            case 5 : transducerTypeString = _T("Digital (no memory)"); break;
            default : transducerTypeString = _T("Unknown Type"); break;
        }
        if (QCOM_ModuleSNValid(unit))
        {
            if (unit->flags & QCOM_UNIT_BOOT_LOADER_MODE)
            {
                unit->unitDescriptionString = String::Format(
                    "Module {0} [Unit {1:D}]",
                    unit->moduleSerialNumber,
                    unitNumber);
            }
            else
            {
                unit->unitDescriptionString = String::Format(
                    "Module {0} [Unit {1:D}] : {2} Transducer",
                    unit->moduleSerialNumber,
                    unitNumber, transducerTypeString);
                if (QCOM_XDSNValid(unit))
                {
                    if (unit->flags & QCOM_UNIT_TRANSDUCER_PRESENT)
                    {
                        unit->unitDescriptionString = String::Concat(
                            unit->unitDescriptionString,
                            _T(" S/N "),
                            unit->transducerSerialNumber);
                    }
                }
                if ((unit->transducerChipID[0] == QD_QUARTZDYNE_ID) && (unit->transducerChipID[1] <= 9))
                {
                    String ^transducerChipType;
                    switch (unit->transducerChipID[1])
                    {
                        case 2 : transducerChipType = _T("SMT FPGA"); break;
                        case 5 : transducerChipType = _T("Hybrid FPGA"); break;
                        case 9 : transducerChipType = _T("ASIC"); break;
                        default : transducerChipType = _T("Unknown"); break;
                    }
                    unit->unitDescriptionString = String::Format(
                        "{0} ({1} v{2:D}.{3:D2})",
                        unit->unitDescriptionString,
                        transducerChipType,
                        unit->transducerChipID[2],
                        unit->transducerChipID[3]);
                }
            }
        }
        else
        {
            unit->unitDescriptionString = String::Concat(
                transducerTypeString,
                _T(" Transducer"));
            if (QCOM_XDSNValid(unit))
            {
                unit->unitDescriptionString = String::Concat(
                    unit->unitDescriptionString,
                    _T(" S/N "),
                    unit->transducerSerialNumber);
            }
        }
        delete transducerTypeString;
        RecordVerboseEvent("    Resulting string: '{0}'",
            unit->unitDescriptionString);
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_UnitValid(unit))
    else
    {
        if (unit)
        {
            unitNumber = unit->unitNumber;
            if (unit->flags & QCOM_UNIT_CMUX_BOX)
            {
                RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
                if (QCOM_ModuleSNValid(unit))
                {
                    unit->unitDescriptionString = String::Format(
                        "Calibration Mux Box S/N {0} [Unit {1:D}]",
                        unit->moduleSerialNumber,
                        unitNumber);
                }
                else
                {
                    unit->unitDescriptionString = String::Format(
                        "Calibration Mux Box [Unit {0:D}]",
                        unitNumber);
                }
                RecordVerboseEvent("    Resulting string: '{0}'",
                    unit->unitDescriptionString);
                RecordBasicEvent("{0} concluded", functionName);
            }                           // end of if (unit->flags & QCOM_UNIT_CMUX_BOX)
            else
            {
                unit->unitDescriptionString = String::Concat("Unit ", unitNumber);
            }
        }                               // end of if (unit)
        else
        {
            RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
        }
    }                                   // end of else of if (QCOM_UnitValid(unit))
}                                       // end of QCOM_ConstructUnitDescriptionString()
//----------------------------------------------------------------------------
// QCOM_DeleteLogFiles
//
// Deletes all the specified log files in the QLog folder
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DeleteLogFiles(
    DWORD           logFileSetMask)
{
    bool            proceedToDelete = GUI_YES;
    bool            proceedToDeleteAll = GUI_YES;
    bool            proceedToPrompt = GUI_YES;
    String          ^functionName = _T("QCOM_DeleteLogFiles");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}(0x{1:X2}) called", functionName, logFileSetMask);
    if (logFileSetMask)
    {
        String ^logDir = String::Concat(QCOM_GeneralInfo->logDirectory, "\\");
        if ((logFileSetMask & GUI_DELETE_ALL_LOG_FILES) == GUI_DELETE_ALL_LOG_FILES)
        {
            if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
            {
                proceedToDeleteAll = QCOM_PromptYesNoModal(
                    "Delete All Log Files",
                    "Delete", "Cancel",
                    "Delete all data, test, event, and\nerror log files in {0} ?",
                    QCOM_LOG_DIRECTORY);
                if (proceedToDeleteAll)
                    proceedToPrompt = GUI_NO;
            }
        }
        if (proceedToDeleteAll)
        {
            if (logFileSetMask & GUI_DELETE_ALL_DATA_LOG_FILES)                 // 0x00000001
            {
                if (proceedToPrompt && !(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
                {
                    proceedToDelete = QCOM_PromptYesNoModal(
                        "Delete Data Log Files",
                        "Delete", "Cancel",
                        "Delete all data log files in {0} ?",
                        QCOM_LOG_DIRECTORY);
                }
                if (proceedToDelete)
                {
                    array <String ^> ^dataLogFiles = Directory::GetFiles(logDir, "QCOM-DataLog-*.log");
                    if (StringSet(dataLogFiles))
                    {
                        for each (String ^pathString in dataLogFiles)
                        {
                            File::Delete(pathString);
                        }
                    }
                    dataLogFiles = Directory::GetFiles(logDir, "QCOM-SnapshotLog-*.log");
                    if (StringSet(dataLogFiles))
                    {
                        for each (String ^pathString in dataLogFiles)
                        {
                            File::Delete(pathString);
                        }
                    }
                    delete [] dataLogFiles;
                }
            }
            if (logFileSetMask & GUI_DELETE_ALL_DATA_CSV_FILES)                 // 0x00000002
            {
                if (proceedToPrompt && !(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
                {
                    proceedToDelete = QCOM_PromptYesNoModal(
                        "Delete Data CSV Files",
                        "Delete", "Cancel",
                        "Delete all data .csv files in {0} ?",
                        QCOM_LOG_DIRECTORY);
                }
                if (proceedToDelete)
                {
                    array <String ^> ^dataCSVFiles = Directory::GetFiles(logDir, "QCOM-DataLog-*.csv");
                    if (StringSet(dataCSVFiles))
                    {
                        for each (String ^pathString in dataCSVFiles)
                        {
                            File::Delete(pathString);
                        }
                    }
                    dataCSVFiles = Directory::GetFiles(logDir, "QCOM-SnapshotLog-*.csv");
                    if (StringSet(dataCSVFiles))
                    {
                        for each (String ^pathString in dataCSVFiles)
                        {
                            File::Delete(pathString);
                        }
                    }
                    delete [] dataCSVFiles;
                }
            }
            if (logFileSetMask & GUI_DELETE_ALL_TEST_LOG_FILES)                 // 0x00000004
            {
                if (proceedToPrompt && !(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
                {
                    proceedToDelete = QCOM_PromptYesNoModal(
                        "Delete Test Results Files",
                        "Delete", "Cancel",
                        "Delete all test results files in {0} ?",
                        QCOM_LOG_DIRECTORY);
                }
                if (proceedToDelete)
                {
                    array <String ^> ^testResultsFiles = Directory::GetFiles(logDir, "QCOM-TestResults-*.log");
                    if (StringSet(testResultsFiles))
                    {
                        for each (String ^pathString in testResultsFiles)
                        {
                            File::Delete(pathString);
                        }
                    }
                    delete [] testResultsFiles;
                }
            }
            if (logFileSetMask & GUI_DELETE_ALL_EVENT_LOG_FILES)                // 0x00000008
            {
                if (proceedToPrompt && !(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
                {
                    proceedToDelete = QCOM_PromptYesNoModal(
                        "Delete Event Log Files",
                        "Delete", "Cancel",
                        "Delete all event log files in {0} ?",
                        QCOM_LOG_DIRECTORY);
                }
                if (proceedToDelete)
                {
                    array <String ^> ^eventLogFiles = Directory::GetFiles(logDir, "QCOM-EventLog-*.log");
                    if (StringSet(eventLogFiles))
                    {
                        for each (String ^pathString in eventLogFiles)
                        {
                            if (StringICompare(pathString, QCOM_GeneralInfo->eventLogPath))
                            {
                                File::Delete(pathString);
                            }
                        }
                    }
                    delete [] eventLogFiles;
                }
            }
            if (logFileSetMask & GUI_DELETE_ALL_ERROR_LOG_FILES)                // 0x00000010
            {
                if (proceedToPrompt && !(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
                {
                    proceedToDelete = QCOM_PromptYesNoModal(
                        "Delete Error Log Files",
                        "Delete", "Cancel",
                        "Delete all error log files in {0} ?",
                        QCOM_LOG_DIRECTORY);
                }
                if (proceedToDelete)
                {
                    array <String ^> ^errorLogFiles = Directory::GetFiles(logDir, "QCOM-ErrorLog-*.log");
                    if (StringSet(errorLogFiles))
                    {
                        for each (String ^pathString in errorLogFiles)
                        {
                            if (StringICompare(pathString, QCOM_GeneralInfo->errorLogPath))
                            {
                                File::Delete(pathString);
                            }
                        }
                    }
                    delete [] errorLogFiles;
                }
            }
            if (logFileSetMask & GUI_DELETE_ALL_SNAPSHOT_LOG_FILES)             // 0x00000020
            {
                if (proceedToPrompt && !(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
                {
                    proceedToDelete = QCOM_PromptYesNoModal(
                        "Delete Snapshot Data Log Files",
                        "Delete", "Cancel",
                        "Delete all snapshot data log files in {0} ?",
                        QCOM_LOG_DIRECTORY);
                }
                if (proceedToDelete)
                {
                    array <String ^> ^dataLogFiles = Directory::GetFiles(logDir, "QCOM-SnapshotLog-*.log");
                    if (StringSet(dataLogFiles))
                    {
                        for each (String ^pathString in dataLogFiles)
                        {
                            File::Delete(pathString);
                        }
                    }
                    delete [] dataLogFiles;
                }
            }
            if (logFileSetMask & GUI_DELETE_ALL_SNAPSHOT_CSV_FILES)             // 0x00000040
            {
                if (proceedToPrompt && !(QCOM_GeneralInfo->flags & QCOM_GENERAL_EXPERT_MODE))
                {
                    proceedToDelete = QCOM_PromptYesNoModal(
                        "Delete Snapshot Data CSV Files",
                        "Delete", "Cancel",
                        "Delete all snapshot data .csv files in {0} ?",
                        QCOM_LOG_DIRECTORY);
                }
                if (proceedToDelete)
                {
                    array <String ^> ^dataCSVFiles = Directory::GetFiles(logDir, "QCOM-SnapshotLog-*.csv");
                    if (StringSet(dataCSVFiles))
                    {
                        for each (String ^pathString in dataCSVFiles)
                        {
                            File::Delete(pathString);
                        }
                    }
                    delete [] dataCSVFiles;
                }
            }
            QCOM_UpdateDeleteLogFilesDropDown();
        }                               // end of if (proceedToDeleteAll)
        delete logDir;
    }                                   // end of if (logFileSetMask)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_DeleteLogFiles()
//----------------------------------------------------------------------------
// QCOM_DisplayFunctionStatus
//
// Displays the error code returned from the specified function, along with a
// user-friendly error message interpretation of the error code, then returns
// the status
//
// Returns the specified status, whether it's displayed or not
//
// Note:    This function is made to be used primarily by the DLL
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_DisplayFunctionStatus(
    DWORD           status,
    String          ^sourceFunctionName)
{
    char            *errorDescription;
    String          ^functionName = _T("QCOM_DisplayFunctionStatus");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QD_DLLMessagesEnabled && QCOM_ErrorMessagesEnabled)
    {
        errorDescription = (char *) malloc(QD_MAXIMUM_ERROR_STRING_SIZE);
        if (errorDescription)
        {
            ClearBuffer(errorDescription, QD_MAXIMUM_ERROR_STRING_SIZE);
            if (QCOM_StackTracesEnabled)
            {
                RecordErrorEvent(
                    "    {0} returned status 0x{1:X8} :\n{2}\n{3}",
                    sourceFunctionName,
                    status,
                    gcnew String(QD_InterpretErrorCode(status, errorDescription)),
                    Environment::StackTrace);
            }
            else
            {
                RecordErrorEvent(
                    "    {0} returned status 0x{1:X8} :\n{2}",
                    sourceFunctionName,
                    status,
                    gcnew String(QD_InterpretErrorCode(status, errorDescription)));
            }
            free((void *) errorDescription);
        }
    }
    QD_DLLStatus = status;
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of QCOM_DisplayFunctionStatus()
//----------------------------------------------------------------------------
// QCOM_DisplayHelpLink
//
// Displays a link in the help text
//
// Called by:   QCOM_AboutHelp
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayHelpLink(
    Form            ^helpWindow,
    String          ^textString,
    DWORD           yPosition,
    DWORD           fieldWidth,
    DWORD           firstLinkCharacterOffset,
    DWORD           numberOfLinkCharacters)
{
    //------------------------------------------------------------------------
    LinkLabel ^helpLinkLabel = gcnew LinkLabel;
    helpLinkLabel->Text = textString;
    helpLinkLabel->LinkArea = LinkArea(
        firstLinkCharacterOffset,
        numberOfLinkCharacters);
    helpLinkLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        12.0F,                      // em-size of the font
        FontStyle::Bold);           // choose from Bold, Italic, Underline, Strikeout
    helpLinkLabel->Location = Point(10, yPosition);
    helpLinkLabel->Size = Drawing::Size(fieldWidth, GUI_HELP_LABEL_HEIGHT);
    helpLinkLabel->AutoSize = GUI_YES;
    helpLinkLabel->BackColor = Color::Transparent;
    helpLinkLabel->LinkColor = Color::Blue;
    helpLinkLabel->DisabledLinkColor = Color::Red;
    helpLinkLabel->VisitedLinkColor = Color::Purple;
    helpLinkLabel->LinkBehavior = LinkBehavior::HoverUnderline;
    helpLinkLabel->TabIndex = 0;
    helpLinkLabel->TabStop = GUI_YES;
    helpLinkLabel->Links[0]->LinkData = QUARTZDYNE_URL;
    helpLinkLabel->LinkClicked +=
        gcnew LinkLabelLinkClickedEventHandler(this, &QCOM_GUIClass::QCOM_InternetHyperLinkClicked);
    helpLinkLabel->MouseEnter +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_HelpAboutQuartzdyneLogoMouseEntered);
    helpLinkLabel->MouseLeave +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
    helpWindow->Controls->Add(helpLinkLabel);
}                                       // end of QCOM_DisplayHelpLink()
//----------------------------------------------------------------------------
// QCOM_DisplayHelpTextLine
//
// Displays one line of the help text
//
// Called by:   QCOM_AboutHelp
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayHelpTextLine(
    Form            ^helpWindow,
    String          ^textString,
    DWORD           yPosition,
    DWORD           fieldWidth)
{
    //------------------------------------------------------------------------
    Label ^helpText = gcnew Label;
    helpText->Text = textString;
    helpText->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        12.0F,                      // em-size of the font
        FontStyle::Bold);           // choose from Bold, Italic, Underline, Strikeout
    helpText->Location = Point(10, yPosition);
    helpText->Size = Drawing::Size(fieldWidth, GUI_HELP_LABEL_HEIGHT);
    helpText->BackColor = Color::Transparent;
    helpWindow->Controls->Add(helpText);
}                                       // end of QCOM_DisplayHelpTextLine()
//----------------------------------------------------------------------------
// QCOM_DisplayModalMessage
//
// Displays a modal message, using variable arguments and pausing program
// activity
//
// Returns: System::Windows::Forms::DialogResult::OK
//
// Note:    Because this function uses the String::Format method to format the
//          arguments into a single managed string, the calling convention
//          should look similar to
//
//          char    *unmanagedString = "Testing";
//          DWORD   status = QCOM_SUCCESS;
//          . . .
//          QCOM_DisplayModalMessage(
//              true,
//              GUI_MODAL_ICON_INFORMATION,
//              "Modal Title",
//              "The function returned 0x{0:X8} for XD {1}",
//              status,
//              gcnew String(unmanagedString));
//----------------------------------------------------------------------------
    System::Windows::Forms::DialogResult QCOM_GUIClass::
QCOM_DisplayModalMessage(
    bool            allow,
    DWORD           flag,
    String          ^titleString,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    System::Windows::Forms::DialogResult
                    result = System::Windows::Forms::DialogResult::OK;
    String          ^functionName = _T("QCOM_DisplayModalMessage");
    //------------------------------------------------------------------------
    if (allow && StringSet(titleString) && StringSet(formatString))
    {
        RecordBasicEvent("{0} called", functionName);
        String ^formattedString = String::Format(formatString, parameters);
        MessageBoxIcon icon;
        switch (flag)
        {
            case GUI_MODAL_ICON_INFORMATION :                                   // 0x00000001
                icon = MessageBoxIcon::Information;
                break;
            case GUI_MODAL_ICON_WARNING :                                       // 0x00000002
                icon = MessageBoxIcon::Exclamation;
                break;
            case GUI_MODAL_ICON_ERROR :                                         // 0x00000003
                icon = MessageBoxIcon::Error;
                break;
            case GUI_MODAL_ICON_CRITICAL :                                      // 0x00000004
                icon = MessageBoxIcon::Stop;
                break;
            default :
                icon = MessageBoxIcon::None;
                break;
        }
        //--------------------------------------------------------------------
        // Create an invisible window, from which to force the modal window to
        // the forefront
        //--------------------------------------------------------------------
        Form ^invisibleWindow = gcnew Form;
        invisibleWindow->Size = Drawing::Size(1, 1);
        invisibleWindow->Location = Point(1, 1);
        invisibleWindow->Focus();
        invisibleWindow->BringToFront();
        invisibleWindow->TopMost = GUI_YES;
        if (invisibleWindow->CanSelect)
            invisibleWindow->Select();
        invisibleWindow->TopLevel = GUI_YES;
        invisibleWindow->Visible = GUI_NO;
        QCOM_PauseElapsedTime();
        result = MessageBox::Show(
            invisibleWindow,
            formattedString,
            titleString,
            MessageBoxButtons::OK,
            icon);
        QCOM_ResumeElapsedTime();
        delete invisibleWindow;
        RecordBasicEvent(
            "    Title '{0}' and text\n'{1}'\nresulted in '{2}'",
            titleString,
            formattedString,
            result);
        RecordBasicEvent("{0} concluded, returning {1}", functionName, result);
    }                                   // end of if (allow && ...)
    return result;
}                                       // end of QCOM_DisplayModalMessage()
//----------------------------------------------------------------------------
// QCOM_DisplayMostRecentEventLog
//
// Displays the most recent event log
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayMostRecentEventLog(void)
{
    int             attempts = 3;
    int             numberOfColumns = 0;
    int             numberOfLines = 0;
    int             maximumHorizontalSize = 0;
    int             maximumVerticalSize = 0;
    StreamReader    ^textReader;
    String          ^eventLogText;
    String          ^line;
    String          ^functionName = _T("QCOM_DisplayMostRecentEventLog");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (File::Exists(QCOM_GeneralInfo->mostRecentEventLogPath))
    {
        textReader = gcnew StreamReader(QCOM_GeneralInfo->mostRecentEventLogPath);
        if (textReader)
        {
            while (line = textReader->ReadLine())
            {
                numberOfLines++;
                numberOfColumns = Max(numberOfColumns, line->Length);
            }
            textReader->Close();
            maximumVerticalSize = (numberOfLines * 153) / 10;
            maximumHorizontalSize = (numberOfColumns * 86) / 10;
        }                               // end of if (textReader)
        textReader = gcnew StreamReader(QCOM_GeneralInfo->mostRecentEventLogPath);
        if (textReader)
        {
            eventLogText = textReader->ReadToEnd();
            textReader->Close();
            //----------------------------------------------------------------
            // Create a new window to display the event log text
            //----------------------------------------------------------------
            eventLogWindow = gcnew Form;
            eventLogWindow->HelpButton = GUI_NO;
            eventLogWindow->Icon = QCOM_SoftwareIcon;
            eventLogWindow->BackgroundImage = gcnew Bitmap(GUI_BG_WHITE_SAND, GUI_YES);
            eventLogWindow->Text = String::Concat(
                "Event Log ", QCOM_GeneralInfo->mostRecentEventLogPath);
            eventLogWindow->Size = Drawing::Size(1000, 500);
            eventLogWindow->Font = gcnew Drawing::Font(
                FontFamily::GenericMonospace,
                10.0F,
                FontStyle::Regular);
            eventLogWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Sizable;
            eventLogWindow->SizeGripStyle = System::Windows::Forms::SizeGripStyle::Hide;
            //----------------------------------------------------------------
            // Display the text
            //----------------------------------------------------------------
            Label ^eventLogLabel = gcnew Label;
            eventLogLabel->Location = Point(10, 10);
            eventLogLabel->Size = Drawing::Size(
                maximumHorizontalSize,
                maximumVerticalSize);
            eventLogLabel->Text = eventLogText;
            eventLogLabel->BackColor = Color::Transparent;
//            eventLogLabel->DoubleBuffered = GUI_YES;
            eventLogWindow->Controls->Add(eventLogLabel);
            //----------------------------------------------------------------
            // Add a Close button
            //----------------------------------------------------------------
            Button ^closeButton = gcnew Button;
            closeButton->Location = Point(0, 0);
            closeButton->Size = Drawing::Size(1, 1);
            closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
            GUI_SetObjectInterfaceProperties(closeButton);
            closeButton->Click +=
                gcnew EventHandler(this, &QCOM_GUIClass::QCOM_EventLogCloseWindow);
            eventLogWindow->Controls->Add(closeButton);
            eventLogWindow->AcceptButton = closeButton; // button when user presses Enter
            eventLogWindow->CancelButton = closeButton; // button when user presses Esc
            //----------------------------------------------------------------
            // Complete the features of the window
            //----------------------------------------------------------------
            eventLogWindow->AutoScroll = GUI_YES;
//            eventLogWindow->AutoScrollPosition = Point(0, 0);
            eventLogWindow->VerticalScroll->Visible = GUI_YES;
            eventLogWindow->VerticalScroll->Enabled = GUI_YES;
            eventLogWindow->VerticalScroll->Maximum = maximumVerticalSize;
            ScrollToControl(closeButton);
            eventLogWindow->ShowDialog();
        }                               // end of if (textReader)
    }                                   // end of if (File::Exists(QCOM_GeneralInfo->eventLogPath))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_DisplayMostRecentEventLog()
//----------------------------------------------------------------------------
// QCOM_DisplayStackTrace
//
// Displays a stack trace
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_DisplayStackTrace(
    String          ^messageString)
{
    String          ^stack;
    //------------------------------------------------------------------------
    if (StringSet(messageString))
    {
        stack = String::Concat(
            messageString,
            Environment::NewLine,
            Environment::StackTrace);
    }
    else
    {
        stack = String::Concat(Environment::StackTrace);
    }
    //------------------------------------------------------------------------
    // Create an invisible window, from which to force the modal window to the
    // forefront
    //------------------------------------------------------------------------
    Form ^invisibleWindow = gcnew Form;
    invisibleWindow->Size = Drawing::Size(1, 1);
    invisibleWindow->Location = Point(1, 1);
    invisibleWindow->Show();
    invisibleWindow->Focus();
    invisibleWindow->BringToFront();
    invisibleWindow->TopMost = GUI_YES;
    if (invisibleWindow->CanSelect)
        invisibleWindow->Select();
    invisibleWindow->Visible = GUI_NO;
    MessageBox::Show(
        invisibleWindow,
        stack,
        _T("Stack Trace"),
        MessageBoxButtons::OK,
        MessageBoxIcon::Exclamation);
    delete invisibleWindow;
}                                       // end of QCOM_DisplayStackTrace()
//----------------------------------------------------------------------------
// QCOM_EmailAddressFormatIsValid
//
// Determines whether the specified string is an email address with a valid
// format
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_EmailAddressFormatIsValid(
    String          ^emailAddress)
{
    bool            formatIsValid = GUI_NO;
    int             atIndex;
    int             periodIndex;
    String          ^functionName = _T("QCOM_EmailAddressFormatIsValid");
    //------------------------------------------------------------------------
    if (StringSet(emailAddress))
    {
        RecordBasicEvent("{0}({1}) called", functionName, emailAddress);
        if (emailAddress->Contains(QCOM_STRING_AT) && emailAddress->Contains(QCOM_STRING_DOT))
        {
            atIndex = emailAddress->IndexOf(QCOM_STRING_AT);
            periodIndex = emailAddress->IndexOf(QCOM_STRING_DOT);
            if (atIndex && periodIndex &&
                emailAddress->Substring(0, atIndex)->Length &&
                (emailAddress->Substring(atIndex)->Length > 3))
            {
                formatIsValid = GUI_YES;
                RecordVerboseEvent("    The format of {0} as an email address is validated",
                    emailAddress);
            }
        }
        else
        {
            RecordErrorEvent(
                "    {0} contains an invalid email address format",
                emailAddress);
        }
        RecordBasicEvent("{0} concluded, returning {1}",
            functionName, (formatIsValid ? _T("Valid") : QCOM_STRING_INVALID));
    }                                   // end of if (StringSet(emailAddress))
    else
    {
        RecordErrorEvent(
            "    {0} was passed an invalid email address string",
            functionName);
    }
    return formatIsValid;
}                                       // end of QCOM_EmailAddressFormatIsValid()
//----------------------------------------------------------------------------
// QCOM_ErrorAlert
//
// Displays and/or records a general-purpose error message with optional
// parameters
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ErrorAlert(
    String          ^titleString,
    UnitInfo        ^unit,
    DWORD           status,
    DWORD           messageFlags,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    char            *errorDescription;
    String          ^errorDescriptionString;
    String          ^errorLogString;
    String          ^functionName = _T("QCOM_ErrorAlert");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(formatString))
    {
        String ^promptString = String::Format(formatString, parameters);
        if (messageFlags & GUI_EMSG_INTERPRET_STATUS)
        {
            errorDescription = (char *) malloc(QD_MAXIMUM_ERROR_STRING_SIZE);
            if (errorDescription)
            {
                if (messageFlags & (GUI_EMSG_USE_UNIT_SN | GUI_EMSG_USE_TRANSDUCER_SN))
                {
                    if (QCOM_UnitValid(unit))
                    {
                        if ((messageFlags & GUI_EMSG_USE_UNIT_SN) &&
                            (messageFlags & GUI_EMSG_USE_TRANSDUCER_SN))
                        {
                            errorDescriptionString = String::Format(
                                "{0} resulted in status 0x{1:X8} :\n{2}\n"
                                "    on module {3} transducer {4}",
                                promptString,
                                status,
                                gcnew String(QD_InterpretErrorCode(status, errorDescription)),
                                unit->moduleSerialNumber,
                                unit->transducerSerialNumber);
                        }
                        else
                        {
                            if (messageFlags & GUI_EMSG_USE_UNIT_SN)
                            {
                                errorDescriptionString = String::Format(
                                    "{0} resulted in status 0x{1:X8} :\n{2}\n"
                                    "    on module {3}",
                                    promptString,
                                    status,
                                    gcnew String(QD_InterpretErrorCode(status, errorDescription)),
                                    unit->moduleSerialNumber);
                            }
                            else
                            {
                                errorDescriptionString = String::Format(
                                    "{0} resulted in status 0x{1:X8} :\n{2}\n"
                                    "    on transducer {3}",
                                    promptString,
                                    status,
                                    gcnew String(QD_InterpretErrorCode(status, errorDescription)),
                                    unit->transducerSerialNumber);
                            }
                        }
                    }
                    else
                    {
                        errorDescriptionString = String::Format(
                            "Unit specification conflict 0x{0:X8} ({1})",
                            status,
                            gcnew String(QD_InterpretErrorCode(status, errorDescription)));
                    }
                }
                else
                {
                    errorDescriptionString = String::Format(
                        "{0} resulted in status 0x{1:X8} :\n{2}",
                        promptString,
                        status,
                        gcnew String(QD_InterpretErrorCode(status, errorDescription)));
                }
                free((void *) errorDescription);
            }                       // end of if (errorDescription)
        }                           // end of if (messageFlags & GUI_EMSG_INTERPRET_STATUS)
        else
        {
            if (messageFlags & (GUI_EMSG_USE_UNIT_SN | GUI_EMSG_USE_TRANSDUCER_SN))
            {
                if (QCOM_UnitValid(unit))
                {
                    if ((messageFlags & GUI_EMSG_USE_UNIT_SN) &&
                        (messageFlags & GUI_EMSG_USE_TRANSDUCER_SN))
                    {
                        errorDescriptionString = String::Format(
                            "{0}\n    on module {1} transducer {2}",
                            promptString,
                            unit->moduleSerialNumber,
                            unit->transducerSerialNumber);
                    }
                    else
                    {
                        if (messageFlags & GUI_EMSG_USE_UNIT_SN)
                        {
                            errorDescriptionString = String::Format(
                                "{0}\n    on module {1}",
                                promptString,
                                unit->moduleSerialNumber);
                        }
                        else
                        {
                            errorDescriptionString = String::Format(
                                "{0}\n    on transducer {1}",
                                promptString,
                                unit->transducerSerialNumber);
                        }
                    }
                }
                else
                {
                    errorDescriptionString = _T("Unit specification conflict (no status)");
                }
            }
            else
            {
                errorDescriptionString = promptString;
            }
        }
        String ^fullErrorDescriptionString;
        if (QCOM_StackTracesEnabled)
        {
            String ^stackTrace = Environment::StackTrace->Replace(Environment::NewLine, QCOM_STRING_LF);
            fullErrorDescriptionString = String::Concat(
                errorDescriptionString, "\n\n", stackTrace);
            delete stackTrace;
        }
        else
        {
            fullErrorDescriptionString = errorDescriptionString;
        }
        if (QCOM_ErrorMessagesEnabled || (messageFlags & GUI_EMSG_MUST_DISPLAY))
        {
            if (messageFlags & GUI_EMSG_PLAY_SOUND)
                GUI_PlaySound(errorSound);
            if (StringSet(titleString))
                QCOM_PromptOKModal(titleString, fullErrorDescriptionString);
            else
                QCOM_PromptOKModal("Error", fullErrorDescriptionString);
        }
        errorLogString = String::Format(
            "{0} :\n{1}",
            titleString,
            fullErrorDescriptionString);
        RecordErrorEvent(errorLogString);
        QCOM_UpdateErrorLog(errorLogString);
        if (QCOM_SendTextErrorMessagesEnabled)
        {
            QCOM_SendTextMessage(
                _T("QCOM Error Alert"),
                errorDescriptionString);
        }
        if (QCOM_SendEmailErrorMessagesEnabled)
        {
            QCOM_SendEmailMessage(
                _T("QCOM Error Alert"),
                errorDescriptionString);
        }
        delete fullErrorDescriptionString;
        delete promptString;
    }                                   // end of if (StringSet(formatString))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ErrorAlert()
//----------------------------------------------------------------------------
// QCOM_GenerateSupportLog
//
// Generates the support log file, then prompts the user to save it, and
// creates a .zip file of all applicable log files
//
// Called by:   QCOM_ToolStripSupportLogDropDownClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GenerateSupportLog(void)
{
    bool            proceedToGenerate = GUI_NO;
    int             lapsedDays;
    int             lapsedHours;
    int             lapsedMinutes;
    int             lapsedSeconds;
    int             lapsedMilliseconds;
    int             numberOfLogFiles = 0;
    int             numberOfTemporaryFiles = 0;
    int             pathNameArrayEntries = 0;
    BYTE            buildVersion;
    BYTE            majorVersion;
    BYTE            minorVersion;
    DWORD           lowerVersion;
    DWORD           upperVersion;
    UnitInfo        ^unit;
    array <String ^>
                    ^pathNameStringArray;
    array <String ^>
                    ^temporaryFilesArray;
    DateTime        dateTime = DateTime::Now;
    String          ^border = GUI_TEXT_FILE_BORDER;
    String          ^dateStamp;
    String          ^fileNameString;
    String          ^lineString;
    String          ^logDir;
    StringBuilder   ^pathNameBuilder;
    String          ^pathString;
    StreamWriter    ^textWriter;
    String          ^functionName = _T("QCOM_GenerateSupportLog");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    logDir = String::Concat(QCOM_GeneralInfo->logDirectory, "\\");
    dateStamp = String::Format(
        "{0:D2}{1:D2}{2:D2}",
        (dateTime.Year % 100),
        dateTime.Month,
        dateTime.Day);
    fileNameString = String::Concat("QCOM-Support-", dateStamp, ".log");
    pathNameBuilder = gcnew StringBuilder(QCOM_MAXIMUM_FILE_PATH_LENGTH);
    GUI_StringToBuilder(
        String::Concat(logDir, fileNameString),
        pathNameBuilder);
    proceedToGenerate = QCOM_PromptForSaveFile(
        "Save General Support Log",
        pathNameBuilder,
        fileNameString,
        GUI_FILE_TYPE_LOG);
    pathString = pathNameBuilder->ToString();
    delete pathNameBuilder;
    if (proceedToGenerate)
    {
        QCOM_PleaseWait(
            GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
            "Collecting Files for the Support Log");
        Thread::Sleep(2000);
        QCOM_SetGeneralUsePath(pathString);
        fileNameString = Path::GetFileName(pathString);
        //--------------------------------------------------------------------
        // Determine how many files are to be ZIPped up, then add two for the
        // actual Support Log and the Content_Type file
        //--------------------------------------------------------------------
        numberOfLogFiles = Directory::GetFiles(logDir, "*.*")->Length + 2;
        for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                unit = QCOM_UnitInfoArray[unitNumber];
                if (QCOM_LogDataPresent(unit))
                {
                    numberOfLogFiles++;
                }
                if (QCOM_TestResultsPresent(unit))
                {
                    numberOfLogFiles++;
                }
            }
        }
        pathNameStringArray = gcnew array <String ^> (numberOfLogFiles);
        pathNameStringArray[pathNameArrayEntries++] = pathString;
        temporaryFilesArray = gcnew array <String ^> (numberOfLogFiles);
        textWriter = File::CreateText(pathString);
        if (textWriter)
        {
            //----------------------------------------------------------------
            // Write out the header, including filename and date
            //----------------------------------------------------------------
            textWriter->WriteLine(border);
            lineString = String::Format(
                "# {0}\n#\n# QCOM Support Log File\n#\n"
                "# Created on {1:D2} {2} {3:D4} at {4:D2}:{5:D2}:{6:D2}",
                fileNameString,
                dateTime.Day,
                QCOM_MonthStringArray[dateTime.Month],
                dateTime.Year,
                dateTime.Hour,
                dateTime.Minute,
                dateTime.Second);
            textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
            textWriter->WriteLine(border);
            QD_GetQDDLLVersion(
                (LPBYTE) &majorVersion,
                (LPBYTE) &minorVersion,
                (LPBYTE) &buildVersion);
            QD_GetUSBDriverVersion(&upperVersion, &lowerVersion);
            MEMORYSTATUSEX memory;
            memory.dwLength = sizeof(MEMORYSTATUSEX);
            GlobalMemoryStatusEx(&memory);
            DriveInfo ^driveInfo = gcnew DriveInfo(Environment::CurrentDirectory);
            lineString = String::Format(
                "    Program Version: {0} Build {1:D}\n"
                "    QCOM DLL Version: {2:D}.{3:D}.{4:D}\n"
                "    Silicon Labs USB Driver Version: {5:X}.{6:X}.{7:X}.{8:X}\n"
                "    OS: {9}\n"
                "    Available Memory: {10:D} MB / {11:D} MB\n"
                "    Available Disk Space: {12:D} MB out of {13:D} MB",
                QCOM_PROGRAM_VERSION_STRING,
                QCOM_BuildNumber,
                majorVersion, minorVersion, buildVersion,
                ((upperVersion >> 16) & 0xFFFF), (upperVersion & 0xFFFF),
                ((lowerVersion >> 16) & 0xFFFF), (lowerVersion & 0xFFFF),
                QCOM_GeneralInfo->windowsVersion,
                (memory.ullAvailPhys / 1000000),
                (memory.ullTotalPhys / 1000000),
                (driveInfo->AvailableFreeSpace / 1000000),
                (driveInfo->TotalSize / 1000000));
            textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
            delete driveInfo;
            lineString = String::Format(
                "    Number of Units: {0:D}    Maximum Number of Units: {1:D}    Valid Unit Bitmap: {2:X8}\n"
                "    Command Line Parameters: {3}\n"
                "    Search String: {4}\n"
                "    Email Address: {5}\n"
                "    Configuration File Path: {6}\n"
                "    Error Log File Path: {7}\n"
                "    Event Log File Path: {8}",
                QCOM_GeneralInfo->numberOfUnits,
                QCOM_GeneralInfo->maximumNumberOfUnits,
                QCOM_GeneralInfo->validUnitBitMap,
                (StringSet(QCOM_GeneralInfo->commandLine) ?
                    QCOM_GeneralInfo->commandLine : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->searchString) ?
                    QCOM_GeneralInfo->searchString : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->emailAddress) ?
                    QCOM_GeneralInfo->emailAddress : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->configFilePath) ?
                    QCOM_GeneralInfo->configFilePath : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->errorLogPath) ?
                    QCOM_GeneralInfo->errorLogPath : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->eventLogPath) ?
                    QCOM_GeneralInfo->eventLogPath : QCOM_STRING_NONE));
            textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
            lineString = String::Format(
                "    General Flags: {0:X8}    General Log Flags: {1:X8}    General Test Flags: {2:X8}\n"
                "    Persistent Flags: {3:X8} Persistent Log Flags: {4:X8} Persistent Test Flags: {5:X8}\n"
                "    Unit Persistent Flags: {6:X8} Unit Persistent Log Flags: {7:X8} Unit Persistent Test Flags: {8:X8}\n"
                "    Unit Persistent Data Log Points: {9:X8}\n"
                "    Unit Persistent Graphing Flags: {10:X8}",
                QCOM_GeneralInfo->flags,
                QCOM_GeneralInfo->logFlags,
                QCOM_GeneralInfo->testFlags,
                QCOM_GeneralInfo->persistentFlags,
                QCOM_GeneralInfo->persistentLogFlags,
                QCOM_GeneralInfo->persistentTestFlags,
                QCOM_GeneralInfo->persistentUnitFlags,
                QCOM_GeneralInfo->persistentUnitLogFlags,
                QCOM_GeneralInfo->persistentUnitTestFlags,
                QCOM_GeneralInfo->persistentUnitLogDataPoints,
                QCOM_GeneralInfo->persistentUnitGraphingFlags);
            textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
            lineString = String::Format(
                "    Basic Messages: {0}\n"
                "    Error Messages: {1}\n"
                "    Verbose Messages: {2}\n"
                "    Detailed Messages: {3}\n"
                "    Stack Traces: {4}\n"
                "    Exp Messages: {5}\n"
                "    DLL Messages: {6}\n"
                "    Basic Event Log: {7}\n"
                "    Verbose Event Log: {8}\n"
                "    Detailed Event Log: {9}\n"
                "    Test Event Log: {10}\n"
                "    Interval Enabled: {11}\n"
                "    Experiments: {12}\n"
                "    Halt On Errors: {13}\n"
                "    Command-Line Only: {14}\n"
                "    Software Updating: {15}",
                (QCOM_BasicMessagesEnabled ? "On" : "Off"),
                (QCOM_ErrorMessagesEnabled ? "On" : "Off"),
                (QCOM_VerboseMessagesEnabled ? "On" : "Off"),
                (QCOM_DetailedMessagesEnabled ? "On" : "Off"),
                (QCOM_StackTracesEnabled ? "On" : "Off"),
                (QCOM_ExpMessagesEnabled ? "On" : "Off"),
                (QD_DLLMessagesEnabled ? "On" : "Off"),
                (QCOM_EventLogBasicEnabled ? "On" : "Off"),
                (QCOM_EventLogVerboseEnabled ? "On" : "Off"),
                (QCOM_EventLogDetailedEnabled ? "On" : "Off"),
                (QCOM_EventLogTestEnabled ? "On" : "Off"),
                (QCOM_ProgramIntervalEnabled ? "Yes" : "No"),
                (QCOM_ExperimentsEnabled ? "On" : "Off"),
                (QCOM_HaltOperationsOnErrors ? "On" : "Off"),
                (QCOM_CommandLineOnly ? "Yes" : "No"),
                (QCOM_SoftwareUpdateInProgress ? "Yes" : "No"));
            textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
            lineString = String::Format(
                "    Text Message To Number: {0}\n"
                "    Text Message CC Number: {1}\n"
                "    Email Message To Address: {2}\n"
                "    Email Message CC Address: {3}\n"
                "    Text Error Messages: {4}\n"
                "    Email Error Messages: {5}",
                (StringSet(QCOM_GeneralInfo->textMessageToNumber) ?
                    QCOM_GeneralInfo->textMessageToNumber : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->textMessageCCNumber) ?
                    QCOM_GeneralInfo->textMessageCCNumber : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->emailMessageToAddress) ?
                    QCOM_GeneralInfo->emailMessageToAddress : QCOM_STRING_NONE),
                (StringSet(QCOM_GeneralInfo->emailMessageCCAddress) ?
                    QCOM_GeneralInfo->emailMessageCCAddress : QCOM_STRING_NONE),
                (QCOM_SendTextErrorMessagesEnabled ? "On" : "Off"),
                (QCOM_SendEmailErrorMessagesEnabled ? "On" : "Off"));
            textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
            lineString = String::Format(
                "    DefaultPressureUnits={0:D}\n"
                "    DefaultTemperatureUnits={1:D}\n"
                "    CurrentPressureUnits={2:D}\n"
                "    CurrentTemperatureUnits={3:D}\n"
                "    AlternatePressureUnits={4:D}\n"
                "    AlternateTemperatureUnits={5:D}\n"
                "    CurrentPrecision={6:D}\n"
                "    ProgramInterval={7:D}\n"
                "    IntervalUnitsOffset={8:D}\n"
                "    SamplingInterval(ms)={9:D}\n"
                "    SamplingInterval(sec)={10:D}\n"
                "    SamplingInterval(min)={11:D}\n"
                "    SamplingInterval(hr)={12:D}\n"
                "    SamplingTimeLimit={13:D} minutes\n"
                "    TestLoopCount={14:D}",
                QCOM_DefaultPressureUnits,
                QCOM_DefaultTemperatureUnits,
                QCOM_CurrentPressureUnits,
                QCOM_CurrentTemperatureUnits,
                QCOM_AlternatePressureUnits,
                QCOM_AlternateTemperatureUnits,
                QCOM_CurrentPrecision,
                QCOM_CurrentProgramInterval,
                QCOM_CurrentIntervalUnitsOffset,
                QCOM_CurrentIntervalUnitsArray[GUI_INTERVAL_MS_OFFSET][GUI_INTERVAL_RECENT_OFFSET],
                QCOM_CurrentIntervalUnitsArray[GUI_INTERVAL_SEC_OFFSET][GUI_INTERVAL_RECENT_OFFSET],
                QCOM_CurrentIntervalUnitsArray[GUI_INTERVAL_MIN_OFFSET][GUI_INTERVAL_RECENT_OFFSET],
                QCOM_CurrentIntervalUnitsArray[GUI_INTERVAL_HR_OFFSET][GUI_INTERVAL_RECENT_OFFSET],
                QCOM_MaximumSamplingRunTimeMinutes,
                QCOM_TestLoopCount);
            textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
            QCOM_TimeElapsed(
                GetTickCount() - QCOM_StartTime,
                &lapsedDays,
                &lapsedHours,
                &lapsedMinutes,
                &lapsedSeconds,
                &lapsedMilliseconds);
            textWriter->WriteLine(
                String::Format(
                    "    Running for {0:D} day{1} {2:D} hour{3} {4:D} minute{5} {6:D} second{7}",
                    lapsedDays, ((lapsedDays == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                    lapsedHours, ((lapsedHours == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                    lapsedMinutes, ((lapsedMinutes == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                    lapsedSeconds, ((lapsedSeconds == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S)));
            for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
            {
                unit = QCOM_UnitInfoArray[unitNumber];
                if (!unit)
                    continue;
                textWriter->WriteLine(border);
                lineString = String::Format(
                    "# Unit {0:D2} : S/N {1} [Physical Number {2:D} / Logical Number {3:D}]",
                    unitNumber,
                    (QCOM_UnitValid(unit) ?
                        unit->moduleSerialNumber : "(Invalid)"),
                    unit->physicalUnitNumber,
                    unit->unitNumber);
                textWriter->WriteLine(lineString);
                textWriter->WriteLine(border);
                textWriter->WriteLine(
                    String::Format(
                        "    Unit Flags: {0:X8}",
                        unit->flags));
                if (QCOM_UnitValid(unit))
                {
                    textWriter->WriteLine(
                        String::Format(
                            "    Firmware Description: {0} (ID: {1:X2} {2:X2} {3:X2} {4:X2})",
                            ((unit->flags & QCOM_UNIT_FIRMWARE_ID_PRESENT) ?
                                unit->firmwareString : QCOM_STRING_INVALID),
                            unit->firmwareID[0], unit->firmwareID[1],
                            unit->firmwareID[2], unit->firmwareID[3]));
                    if (QCOM_XDPresent(unit) && QCOM_XDSNValid(unit))
                    {
                        BYTE memoryType = QD_MEMORY_TYPE_ABSENT;
                        QD_GetMemoryType(
                            unit->unitHandle,
                            QD_DEVICE_TRANSDUCER,
                            (LPBYTE) &memoryType);
                        lineString = String::Format(
                                "    Transducer Serial Number: {0} (ID: {1:X2} {2:X2} {3:X2} {4:X2})\n"
                                "    Transducer Part Number: {5}\n"
                                "    Transducer Type: {6:D}    Memory Type: {7:D}\n"
                                "    Most Recent Pressure Reading: {8:F4} psi\n"
                                "    Most Recent Temperature Reading: {9:F4} °C",
                                unit->transducerSerialNumber,
                                unit->transducerChipID[0], unit->transducerChipID[1],
                                unit->transducerChipID[2], unit->transducerChipID[3],
                                unit->transducerPartNumber,
                                unit->transducerType,
                                memoryType,
                                unit->pressureValuePSI,
                                unit->temperatureValueCelsius);
                        textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
                    }
                    else
                    {
                        textWriter->WriteLine(
                            "    Transducer Serial Number: Invalid");
                    }
                    textWriter->WriteLine(
                        String::Format(
                            "    I²C Data Rate: {0:F1} kHz",
                                unit->dataRate));
                }
                lineString = String::Format(
                    "    Coefficient File Path: {0}\n"
                    "    Data Log Flags: {1:X8}    Data Log Points: {2:X8}\n"
                    "    Data Log Size: {3:D}    Data Log Remaining: {4:D}\n"
                    "    Data Log File Path: {5}\n"
                    "    Data Log Snapshot Path: {6}\n"
                    "    Test Flags: {7:X8}\n"
                    "    Test Summary Log Size: {8:D}    Test Summary Log Remaining: {9:D}\n"
                    "    Test Detailed Log Size: {10:D}    Test Detailed Log Remaining: {11:D}\n"
                    "    Test Results File Path: {12}\n"
                    "    Test Data File Path: {13}\n"
                    "    Test Firmware File Path: {14}\n"
                    "    Send Every Interval: {15:D}    Send Every Interval Remaining: {16:D}",
                    ((QCOM_CFKnown(unit) && StringSet(unit->coefficientFilePath)) ?
                        unit->coefficientFilePath : QCOM_STRING_NONE),
                    unit->dataLogFlags,
                    unit->dataLogPoints,
                    unit->dataLogSize,
                    unit->dataLogRemaining,
                    ((QCOM_LogFileKnown(unit) && StringSet(unit->dataLogFilePath)) ?
                        unit->dataLogFilePath : QCOM_STRING_NONE),
                    ((QCOM_LogSSFileKnown(unit) && StringSet(unit->dataLogSnapshotFilePath)) ?
                        unit->dataLogSnapshotFilePath : QCOM_STRING_NONE),
                    unit->testFlags,
                    unit->testSummaryResultsLogSize,
                    unit->testSummaryResultsLogRemaining,
                    unit->testDetailedResultsLogSize,
                    unit->testDetailedResultsLogRemaining,
                    ((QCOM_TRFileKnown(unit) && StringSet(unit->testResultsFilePath)) ?
                        unit->testResultsFilePath : QCOM_STRING_NONE),
                    (((unit->testFlags & QCOM_UNIT_TEST_DATA_FILE_SPECIFIED) && StringSet(unit->testDataFilePath)) ?
                        unit->testDataFilePath : QCOM_STRING_NONE),
                    (((unit->testFlags & QCOM_UNIT_TEST_FW_FILE_SPECIFIED) && StringSet(unit->testFirmwareFilePath)) ?
                        unit->testFirmwareFilePath : QCOM_STRING_NONE),
                    QCOM_CurrentSendEveryInterval[unitNumber],
                    QCOM_CurrentSendEveryIntervalRemaining[unitNumber]);
                textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
                if (QCOM_UnitValid(unit))
                {
                    textWriter->WriteLine(
                        String::Format(
                            "    Tests Completed: {0:D}    Tests To Complete: {1:D}",
                            unit->testsCompleted,
                            unit->testsToComplete));
                }
                lineString = String::Format(
                    "    GraphingFlags={0:X8}\n"
                    "    GraphingPressureLowBoundaryPSI={1:F8}\n"
                    "    GraphingPressureHighBoundaryPSI={2:F8}\n"
                    "    GraphingTemperatureLowBoundaryCelsius={3:F8}\n"
                    "    GraphingTemperatureHighBoundaryCelsius={4:F8}\n"
                    "    GraphingAmperageLowBoundarymA={5:F8}\n"
                    "    GraphingAmperageHighBoundarymA={6:F8}",
                    unit->graphingFlags,
                    unit->graphingPressureLowBoundaryPSI,
                    unit->graphingPressureHighBoundaryPSI,
                    unit->graphingTemperatureLowBoundaryCelsius,
                    unit->graphingTemperatureHighBoundaryCelsius,
                    unit->graphingAmperageLowBoundarymA,
                    unit->graphingAmperageHighBoundarymA);
                textWriter->WriteLine(lineString->Replace(QCOM_STRING_LF, Environment::NewLine));
            }                           // end of for (DWORD unitNumber = 0; ...)
            textWriter->WriteLine(border);
            textWriter->WriteLine(String::Concat("# End of ", fileNameString));
            textWriter->WriteLine(border);
            textWriter->Close();
        }                               // end of if (textWriter)
        //--------------------------------------------------------------------
        // Collect the names of all the files in the Log directory
        //--------------------------------------------------------------------
        if (Directory::Exists(logDir))
        {
            array <String ^> ^logDirFiles = Directory::GetFiles(logDir, "*.*");
            if (StringSet(logDirFiles))
            {
                for each (String ^logDirFile in logDirFiles)
                {
                    if (File::Exists(logDirFile) && StringICompare(logDirFile, pathString))
                    {
                        pathNameStringArray[pathNameArrayEntries++] = logDirFile;
                    }
                }
            }
        }                               // end of if (Directory::Exists(logDir))
        //--------------------------------------------------------------------
        // Record any data logs and test logs in memory
        //--------------------------------------------------------------------
        for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                unit = QCOM_UnitInfoArray[unitNumber];
                //------------------------------------------------------------
                // Record any data logs
                //------------------------------------------------------------
                if (QCOM_LogDataPresent(unit))
                {
                    String ^tempPathString = String::Concat(
                        logDir,
                        "\\QCOM-DataLog-",
                        dateStamp,
                        ".log");
                    if (unit->dataLogFlags & QCOM_UNIT_LOG_DATA_UNSAVED)
                    {
                        bool spinLockAcquired = GUI_NO;
                        try
                        {
                            QCOM_LogSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                            QCOM_LogUnitSaveDataLog(unit, tempPathString);
                        }               // end of try
                        finally
                        {
                            if (spinLockAcquired == GUI_YES)
                                QCOM_LogSpinLockArray[unitNumber]->Exit();
                        }
                        temporaryFilesArray[numberOfTemporaryFiles++] =
                            tempPathString;
                    }
                    else
                    {
                        tempPathString = unit->dataLogFilePath;
                    }
                    if (File::Exists(tempPathString))
                        pathNameStringArray[pathNameArrayEntries++] =
                            tempPathString;
                    delete tempPathString;
                }
                //------------------------------------------------------------
                // Record any test logs
                //------------------------------------------------------------
                if (QCOM_TestResultsPresent(unit))
                {
                    String ^tempPathString = String::Concat(
                        logDir,
                        "\\QCOM-TestLog-",
                        dateStamp,
                        ".log");
                    if (unit->testFlags & QCOM_UNIT_TEST_RESULTS_UNSAVED)
                    {
                        bool spinLockAcquired = GUI_NO;
                        try
                        {
                            QCOM_TestSpinLockArray[unitNumber]->Enter(spinLockAcquired);
                            QCOM_TestUnitSaveResultsLog(unit, tempPathString);
                        }               // end of try
                        finally
                        {
                            if (spinLockAcquired == GUI_YES)
                                QCOM_LogSpinLockArray[unitNumber]->Exit();
                        }
                        temporaryFilesArray[numberOfTemporaryFiles++] =
                            tempPathString;
                    }
                    else
                    {
                        tempPathString = unit->testResultsFilePath;
                    }
                    if (File::Exists(tempPathString))
                        pathNameStringArray[pathNameArrayEntries++] =
                            tempPathString;
                    delete tempPathString;
                }
            }
        }                               // end of for (DWORD unitNumber = 0; ...)
        //--------------------------------------------------------------------
        // ZIP up all the support log files
        //--------------------------------------------------------------------
        String ^zipPathString = String::Concat(
            Path::GetDirectoryName(pathString), "\\",
            Path::GetFileNameWithoutExtension(pathString),
            ".zip");
        QCOM_ZipFiles(pathNameStringArray, zipPathString);
        QCOM_RecordAndModalEventByFlags(
            QCOM_EventLogVerboseEnabled,
            QCOM_DetailedMessagesEnabled,
            functionName,
            "Support Log ZIP {0} created successfully",
            zipPathString);
        for each (String ^tempFile in temporaryFilesArray)
            if (tempFile && File::Exists(tempFile))
                File::Delete(tempFile);
        delete [] temporaryFilesArray;
        delete [] pathNameStringArray;
        QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
        Thread::Sleep(100);
        //--------------------------------------------------------------------
        // Display the email interface
        //--------------------------------------------------------------------
        emailSupportLogWindow = gcnew Form;
        emailSupportLogWindow->SuspendLayout();
        //--------------------------------------------------------------------
        // Set the appearance
        //--------------------------------------------------------------------
        emailSupportLogWindow->MaximizeBox = GUI_NO;
        emailSupportLogWindow->HelpButton = GUI_NO;
//        emailSupportLogWindow->TopMost = GUI_YES;
        //--------------------------------------------------------------------
        // Set its icon
        //--------------------------------------------------------------------
        emailSupportLogWindow->Icon = QCOM_SoftwareIcon;
        //--------------------------------------------------------------------
        // Set the background image
        //--------------------------------------------------------------------
//        emailSupportLogWindow->BackgroundImage = whiteSandBackground;
        //--------------------------------------------------------------------
        // Set the title and border style
        //--------------------------------------------------------------------
        emailSupportLogWindow->Text = _T("Email the Support Log with an Issue Description");
        emailSupportLogWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
        //--------------------------------------------------------------------
        // Create an email object instance
        //--------------------------------------------------------------------
        EmailInfo ^emailInfo = gcnew EmailInfo;
        emailInfo->attachment = zipPathString;
        //--------------------------------------------------------------------
        // Display the email group box
        //--------------------------------------------------------------------
        GroupBox ^emailGroupBox = gcnew GroupBox;
        //--------------------------------------------------------------------
        // Email group box
        //--------------------------------------------------------------------
        emailGroupBox->Text = _T("Compose Email");
        emailGroupBox->Location = Point(14, 10);
        emailGroupBox->Size = Drawing::Size(
            GUI_DEFAULT_GROUP_BOX_WIDTH,
            144);
        emailGroupBox->BackColor = Color::Transparent;
        //--------------------------------------------------------------------
        // To label
        //--------------------------------------------------------------------
        Label ^emailToLabel = gcnew Label;
        emailToLabel->Text = _T("To:");
        emailToLabel->Location = Point(10, 22);
        emailToLabel->Size = Drawing::Size(35, GUI_INFO_LABEL_HEIGHT);
        emailToLabel->BackColor = Color::Transparent;
        emailGroupBox->Controls->Add(emailToLabel);
        //--------------------------------------------------------------------
        // To combo
        //--------------------------------------------------------------------
        emailToCombo = gcnew ComboBox;
        emailToCombo->Location = Point(
            emailToLabel->Right + 2,
            emailToLabel->Top - 3);
        emailToCombo->Size = Drawing::Size(
            emailGroupBox->Width - 570,
            GUI_REGULAR_COMBO_BOX_HEIGHT);
        emailToCombo->MaxDropDownItems = 2;
        emailToCombo->FormattingEnabled = GUI_YES;
        emailToCombo->Tag = dynamic_cast <Object ^> (emailInfo);
        emailToCombo->Items->Add(QUARTZDYNE_SUPPORT_EMAIL_ADDRESS);
        if (StringSet(QCOM_GeneralInfo->emailAddress) &&
            StringICompare(
                QCOM_GeneralInfo->emailAddress,
                QUARTZDYNE_SUPPORT_EMAIL_ADDRESS))
            emailToCombo->Items->Add(QCOM_GeneralInfo->emailAddress);
        emailToCombo->Text = QUARTZDYNE_SUPPORT_EMAIL_ADDRESS;
        emailInfo->toAddress = emailToCombo->Text;
        emailToCombo->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_EmailMessageClearComboBox);
        emailToCombo->PreviewKeyDown +=
            gcnew PreviewKeyDownEventHandler(this, &QCOM_GUIClass::QCOM_ComboBoxAcceptEnterKey);
        emailToCombo->KeyDown +=
            gcnew KeyEventHandler(this, &QCOM_GUIClass::QCOM_EmailMessageProcessComboEnterKey);
        emailGroupBox->Controls->Add(emailToCombo);
        //--------------------------------------------------------------------
        // From label
        //--------------------------------------------------------------------
        Label ^emailFromLabel = gcnew Label;
        emailFromLabel->Text = _T("From: ");
        emailFromLabel->Location = Point(10, emailToLabel->Bottom + 12);
        emailFromLabel->Size = emailToLabel->Size;
        emailFromLabel->BackColor = Color::Transparent;
        emailGroupBox->Controls->Add(emailFromLabel);
        //--------------------------------------------------------------------
        // From combo
        //--------------------------------------------------------------------
        emailFromCombo = gcnew ComboBox;
        emailFromCombo->Location = Point(
            emailFromLabel->Right + 2,
            emailFromLabel->Top - 3);
        emailFromCombo->Size = emailToCombo->Size;
        emailFromCombo->MaxDropDownItems = 2;
        emailFromCombo->FormattingEnabled = GUI_YES;
        emailFromCombo->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_EmailMessageClearComboBox);
        emailGroupBox->Controls->Add(emailFromCombo);
        //--------------------------------------------------------------------
        // Subject label
        //--------------------------------------------------------------------
        Label ^emailSubjectLabel = gcnew Label;
        emailSubjectLabel->Text = _T("Subject: ");
        emailSubjectLabel->Location = Point(emailToCombo->Right + 20, 23);
        emailSubjectLabel->Size = Drawing::Size(56, GUI_INFO_LABEL_HEIGHT);
        emailSubjectLabel->BackColor = Color::Transparent;
        emailGroupBox->Controls->Add(emailSubjectLabel);
        //--------------------------------------------------------------------
        // Subject box
        //--------------------------------------------------------------------
        emailSubjectBox = gcnew TextBox;
        emailSubjectBox->Text = String::Format(
            "QCOM Support Log (v{0} {1:D2}-{2:D2}-{3:D2} {4:D2}:{5:D2})",
            QCOM_PROGRAM_VERSION_STRING,
            dateTime.Month,
            dateTime.Day,
            dateTime.Year,
            dateTime.Hour,
            dateTime.Minute);
        emailSubjectBox->Location = Point(
            emailSubjectLabel->Right + 2,
            emailSubjectLabel->Top - 3);
        emailSubjectBox->Size = Drawing::Size(
            430,
            GUI_REGULAR_TEXT_BOX_HEIGHT);
        emailSubjectBox->Multiline = GUI_NO;
        emailSubjectBox->AcceptsReturn = GUI_NO;
        emailSubjectBox->AcceptsTab = GUI_NO;
        emailSubjectBox->WordWrap = GUI_NO;
        emailSubjectBox->TextAlign = HorizontalAlignment::Left;
        emailSubjectBox->BackColor = Color::White;
        emailGroupBox->Controls->Add(emailSubjectBox);
        emailInfo->subjectString = emailSubjectBox->Text;
        //--------------------------------------------------------------------
        // Message label
        //--------------------------------------------------------------------
        Label ^emailMessageLabel = gcnew Label;
        emailMessageLabel->Text =
            _T("Please describe the problem or issue you would like to report:");
        emailMessageLabel->Location = Point(
            emailSubjectLabel->Left,
            emailSubjectBox->Bottom + 10);
        emailMessageLabel->Size = Drawing::Size(
            emailSubjectLabel->Width + 2 + emailSubjectBox->Width,
            GUI_INFO_LABEL_HEIGHT);
        emailMessageLabel->BackColor = Color::Transparent;
        emailGroupBox->Controls->Add(emailMessageLabel);
        //--------------------------------------------------------------------
        // Message box
        //--------------------------------------------------------------------
        emailMessageBox = gcnew TextBox;
        emailMessageBox->Location = Point(
            emailSubjectLabel->Left,
            emailMessageLabel->Bottom + 4);
        emailMessageBox->Size = Drawing::Size(
            emailMessageLabel->Width,
            GUI_REGULAR_TEXT_BOX_HEIGHT * 3);
        emailMessageBox->Multiline = GUI_YES;
        emailMessageBox->AcceptsReturn = GUI_YES;
        emailMessageBox->AcceptsTab = GUI_YES;
        emailMessageBox->WordWrap = GUI_YES;
        emailMessageBox->TextAlign = HorizontalAlignment::Left;
        emailMessageBox->BackColor = Color::White;
        emailGroupBox->Controls->Add(emailMessageBox);
        emailInfo->messageString = emailMessageBox->Text;
        //--------------------------------------------------------------------
        // Status label
        //--------------------------------------------------------------------
        emailStatusLabel = gcnew Label;
        emailStatusLabel->Text = _T("Email not yet sent");
        emailStatusLabel->Location = Point(
            emailFromCombo->Left,
            emailFromLabel->Bottom + 40);
        emailStatusLabel->Size = Drawing::Size(
            223,
            GUI_INFO_LABEL_HEIGHT);
        emailStatusLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        emailStatusLabel->ForeColor = Color::Green;
        emailStatusLabel->BackColor = Color::Transparent;
        emailGroupBox->Controls->Add(emailStatusLabel);
        //--------------------------------------------------------------------
        // Send button
        //--------------------------------------------------------------------
        Button ^emailSendButton = gcnew Button;
        emailSendButton->Text = _T("Send");
        emailSendButton->Tag = dynamic_cast <Object ^> (emailInfo);
        emailSendButton->Location = Point(
            emailFromCombo->Right - 40,
            emailMessageBox->Bottom - 27);
        emailSendButton->Size = Drawing::Size(40, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetButtonInterfaceProperties(emailSendButton);
        emailSendButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_EmailMessageSendButtonClicked);
        emailSendButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_EmailMessageSendButtonMouseEntered);
        emailSendButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        emailGroupBox->Controls->Add(emailSendButton);
        emailSupportLogWindow->Controls->Add(emailGroupBox);
        //--------------------------------------------------------------------
        // Set the dimensions of the email window
        //--------------------------------------------------------------------
        emailSupportLogWindow->Size = Drawing::Size(
            GUI_DEFAULT_GROUP_BOX_WIDTH + 40,
            emailGroupBox->Bottom + 85);
        //--------------------------------------------------------------------
        // Close button
        //--------------------------------------------------------------------
        Button ^closeButton = gcnew Button;
        closeButton->Text = _T("Close");
        closeButton->Location = Point(
            emailSupportLogWindow->Right - 100,
            emailSupportLogWindow->Bottom - 70);
        closeButton->Size = Drawing::Size(
            GUI_CLOSE_BUTTON_WIDTH,
            GUI_REGULAR_BUTTON_HEIGHT);
        closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
        GUI_SetButtonInterfaceProperties(closeButton);
        closeButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_EmailSupportLogCloseWindow);
        closeButton->MouseEnter +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_EmailMessageCloseButtonMouseEntered);
        closeButton->MouseLeave +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_AnyObjectMouseExited);
        emailSupportLogWindow->Controls->Add(closeButton);
        //--------------------------------------------------------------------
        // Set the remaining window properties
        //--------------------------------------------------------------------
        emailSupportLogWindow->AcceptButton = emailSendButton;
        emailSupportLogWindow->CancelButton = closeButton;
        //--------------------------------------------------------------------
        // Finally, display the new window
        //--------------------------------------------------------------------
        emailSupportLogWindow->ShowDialog();
        emailSupportLogWindow->ResumeLayout();
        delete emailInfo;
        delete zipPathString;
    }                                   // end of if (proceedToGenerate)
    delete pathString;
    delete logDir;
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_GenerateSupportLog()
//----------------------------------------------------------------------------
// QCOM_GetOperatingEnvironment
//
// Retrieves information about the client operating environment
//
// Called by:   QCOM_EnsureMinimumEnvironment
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GetOperatingEnvironment(void)
{
//    DWORD           status;
    String          ^functionName = _T("QCOM_GetOperatingEnvironment");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Retrieve the Windows version of the client
    //------------------------------------------------------------------------
    QCOM_GetWindowsVersion();
    //------------------------------------------------------------------------
    // Retrieve the client user and machine name
    //------------------------------------------------------------------------
    RecordVerboseEvent("    Operator {0} is using computer {1} ({2:D} processor{3})",
        Environment::UserName,
        Environment::MachineName,
        Environment::ProcessorCount,
        ((Environment::ProcessorCount == 1) ? _T("") : _T("s")));
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_GetOperatingEnvironment()
//----------------------------------------------------------------------------
// QCOM_GetWindowsVersion
//
// Discovers the currently running Windows version and sets the general
// QCOM_GeneralInfo->windowsVersion string accordingly
//
// Called by:   QCOM_GetOperatingEnvironment
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_GetWindowsVersion(void)
{
    bool            serverOS = GUI_NO;
    BOOL            is64Bit = GUI_NO;
    DWORD           status;
    OSVERSIONINFOEX osInfo;
    String          ^bitWidthString = _T("32");
    String          ^osString;
    String          ^functionName = _T("QCOM_GetWindowsVersion");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // First, initialize the OS version variable
    //------------------------------------------------------------------------
    QCOM_WindowsVersion = QCOM_WIN_VER_UNKNOWN;
    //------------------------------------------------------------------------
    // Next, determine the processor native address size
    //------------------------------------------------------------------------
    if (Environment::Is64BitOperatingSystem)
    {
        bitWidthString = _T("64");
        QCOM_WindowsVersion |= QCOM_WIN_VER_64_BIT;
    }
    //------------------------------------------------------------------------
    // Now, determine the operating system version
    //------------------------------------------------------------------------
    osInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
    status = GetVersionEx((LPOSVERSIONINFOW) &osInfo);
    if (status)
    {
        switch (osInfo.dwMajorVersion)
        {
            case 5 :
                switch (osInfo.dwMinorVersion)
                {
                    case 0 :
                        osString = _T("Windows 2000");
                        QCOM_WindowsVersion |= QCOM_WIN_VER_PRE_XP;
                        break;
                    case 1 :
                        osString = _T("Windows XP");
                        QCOM_WindowsVersion |= QCOM_WIN_VER_XP;
                        break;
                    case 2 :
                        QCOM_WindowsVersion |= QCOM_WIN_VER_SERVER_2003;
                        if (GetSystemMetrics(SM_SERVERR2) == 0)
                        {
                            osString = _T("Windows Server 2003");
                        }
                        else
                        {
                            osString = _T("Windows Server 2003 R2");
                            QCOM_WindowsVersion |= QCOM_WIN_VER_R2;
                        }
                        serverOS = GUI_YES;
                        break;
                    default :
                        osString = _T("Unsupported");
                        break;
                }
                break;
            case 6 :
                switch (osInfo.dwMinorVersion)
                {
                    case 0 :
                        if (osInfo.wProductType == VER_NT_WORKSTATION)
                        {
                            osString = _T("Windows Vista");
                            QCOM_WindowsVersion |= QCOM_WIN_VER_VISTA;
                        }
                        else
                        {
                            osString = _T("Windows Server 2008");
                            QCOM_WindowsVersion |= QCOM_WIN_VER_SERVER_2008;
                            serverOS = GUI_YES;
                        }
                        break;
                    case 1 :
                        if (osInfo.wProductType == VER_NT_WORKSTATION)
                        {
                            osString = _T("Windows 7");
                            QCOM_WindowsVersion |= QCOM_WIN_VER_7;
                        }
                        else
                        {
                            osString = _T("Windows Server 2008 R2");
                            QCOM_WindowsVersion |= (QCOM_WIN_VER_SERVER_2008 | QCOM_WIN_VER_R2);
                            serverOS = GUI_YES;
                        }
                        break;
                    case 2 :
                        if (osInfo.wProductType == VER_NT_WORKSTATION)
                        {
                            osString = _T("Windows 8");
                            QCOM_WindowsVersion |= QCOM_WIN_VER_8;
                        }
                        else
                        {
                            osString = _T("Windows Server 2012");
                            QCOM_WindowsVersion |= QCOM_WIN_VER_SERVER_2012;
                            serverOS = GUI_YES;
                        }
                        break;
                    case 3 :
                        if (osInfo.wProductType == VER_NT_WORKSTATION)
                        {
                            osString = _T("Windows 8.1");
                            QCOM_WindowsVersion |= QCOM_WIN_VER_8;
                        }
                        else
                        {
                            osString = _T("Windows Server 2012 R2");
                            QCOM_WindowsVersion |= QCOM_WIN_VER_SERVER_2012;
                            serverOS = GUI_YES;
                        }
                        break;
                    default :
                        osString = _T("Unsupported");
                        break;
                }                       // end of switch (osInfo.dwMinorVersion)
                break;
            case 10 :
                switch (osInfo.dwMinorVersion)
                {
                    case 0 :
                        if (osInfo.wProductType == VER_NT_WORKSTATION)
                        {
                            osString = _T("Windows 10");
                            QCOM_WindowsVersion |= QCOM_WIN_VER_10;
                        }
                        else
                        {
                            osString = _T("Windows Server 2016 TR");
                            QCOM_WindowsVersion |= QCOM_WIN_VER_SERVER_2016;
                            serverOS = GUI_YES;
                        }
                        break;
                    default :
                        osString = _T("Unsupported");
                        break;
                }                       // end of switch (osInfo.dwMinorVersion)
                break;
            default :
                osString = _T("Unsupported");
                break;
        }                               // end of switch (osInfo.dwMajorVersion)
        //--------------------------------------------------------------------
        // Finally, determine the service pack version, if available
        //--------------------------------------------------------------------
        if (wcslen(osInfo.szCSDVersion) && !serverOS)
        {
            String ^SPString = gcnew String(osInfo.szCSDVersion);
            if (SPString->Contains("Service Pack"))
            {
                SPString = SPString->Replace(_T("Service Pack "), _T("SP"));
            }
            QCOM_GeneralInfo->windowsVersion = String::Format(
                "{0} {1}-bit with {2}",
                osString,
                bitWidthString,
                SPString);
            delete SPString;
        }
        else
        {
            QCOM_GeneralInfo->windowsVersion = String::Format(
                "{0} {1}-bit",
                osString,
                bitWidthString);
        }
        RecordBasicEvent(
            "    The Windows version is detected as '{0}'",
            QCOM_GeneralInfo->windowsVersion);
    }                                   // end of if (status)
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} :\nThe call to GetVersionEx failed",
            functionName);
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_GetWindowsVersion()
//----------------------------------------------------------------------------
// QCOM_GlobalFileSearch
//
// Searches the file system starting at the specified top-most directory,
// which includes the drive letter, and all its subdirectories for the
// specified filename, and returns the path of the file with the latest
// date-and-time stamp if more than one is found
//
// Returns: GUI_YES or GUI_NO
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_GlobalFileSearch(
    String          ^fileName,
    StringBuilder   ^filePathBuilder)
{
    bool            fileLocated = GUI_NO;
    String          ^filePathString = filePathBuilder->ToString();
    String          ^functionName = _T("QCOM_GlobalFileSearch");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(fileName) && filePathBuilder)
    {
        if (Directory::Exists(filePathString))
        {
            DirectoryInfo ^dirInfo = gcnew DirectoryInfo(filePathString);
            array <FileInfo ^> ^files =
                dirInfo->GetFiles(
                    "*" + fileName + "*",
                    SearchOption::AllDirectories);
            FileInfo ^latestFile;
            DateTime latestDate = DateTime(0);
            for each (FileInfo ^fileInfo in files)
            {
                if (DateTime::Compare(fileInfo->LastWriteTime, latestDate) > 0)
                {
                    latestDate = fileInfo->LastWriteTime;
                    latestFile = fileInfo;
                    fileLocated = GUI_YES;
                }
            }
            if (fileLocated)
            {
                filePathBuilder->Length = QCOM_MAXIMUM_FILE_PATH_LENGTH;
                GUI_StringToBuilder(latestFile->FullName, filePathBuilder);
            }
            delete latestDate;
        }
    }
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (fileLocated ? "Found" : "Not Found"));
    return fileLocated;
}                                       // end of QCOM_GlobalFileSearch()
//----------------------------------------------------------------------------
// QCOM_HaltAllUserActivity
//
// Stops all activity that might be initiated by the user
//
// Called by:   QCOM_ReDrawWindows
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_HaltAllUserActivity(void)
{
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_HaltAllUserActivity");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
    {
        //--------------------------------------------------------------------
        // Stop sampling
        //--------------------------------------------------------------------
        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_CURRENTLY_SAMPLING;
    }
    if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING)
    {
        //--------------------------------------------------------------------
        // Stop logging
        //--------------------------------------------------------------------
        QCOM_GeneralInfo->logFlags &= ~QCOM_GENERAL_LOG_CURRENTLY_LOGGING;
    }
    if (QCOM_GeneralInfo->testFlags & QCOM_GENERAL_TEST_CURRENTLY_TESTING)
    {
        //--------------------------------------------------------------------
        // Stop testing
        //--------------------------------------------------------------------
        QCOM_GeneralInfo->testFlags &= ~QCOM_GENERAL_TEST_CURRENTLY_TESTING;
    }
    for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            unit = QCOM_UnitInfoArray[unitNumber];
            if (unit->flags & QCOM_UNIT_CURRENTLY_SAMPLING)
            {
                QCOM_StartStopSamplingUnit(unit);
            }
            if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
            {
                QCOM_StartStopDataLoggingUnit(unit);
            }
            if (unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING)
            {
                QCOM_TestUnitStartStopTests(unit);
            }
        }
    }
    //------------------------------------------------------------------------
    // Save all outstanding unsaved data
    //------------------------------------------------------------------------
    QCOM_QuerySaveUnsavedLogData();
    QCOM_QuerySaveUnsavedTestResults();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_HaltAllUserActivity()
//----------------------------------------------------------------------------
// QCOM_I2CChecksumVerified
//
// Verifies that the fifth byte in the array of BYTEs is the correct checksum
// of the preceding four BYTEs, with each BYTE being represented by two
// hexadecimal string characters
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_I2CChecksumVerified(
    char            *i2CReplyData)
{
    bool            verified = GUI_NO;
    char            *dataPtr = i2CReplyData;
    BYTE            calculatedChecksum;
    BYTE            readChecksum;
    String          ^functionName = _T("QCOM_I2CChecksumVerified");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (i2CReplyData)
    {
        for (int index = calculatedChecksum = 0; index < 4; index++)
        {
            calculatedChecksum += (AtoX(*dataPtr) << 4) | AtoX(*(dataPtr + 1));
            dataPtr += 2;
        }
        readChecksum = (AtoX(*dataPtr) << 4) | AtoX(*(dataPtr + 1));
        if (((BYTE) (calculatedChecksum + readChecksum)) == 0)
        {
            calculatedChecksum = (~calculatedChecksum + 1);
            if (calculatedChecksum == readChecksum)
                verified = GUI_YES;
        }
    }
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (verified ? "Yes" : "No"));
    return verified;
}                                       // end of QCOM_I2CChecksumVerified()
//----------------------------------------------------------------------------
// QCOM_InstallConvertReadingsObjects
//
// Installs the objects associated with the convert readings utility
//
// Called by:   QCOM_InstallUtilities
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InstallConvertReadingsObjects(void)
{
    String          ^functionName = _T("QCOM_InstallConvertReadingsObjects");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    utilConvertReadingsUnit = gcnew UnitInfo;
    utilConvertReadingsUnit->transducerSerialNumber = String::Empty;
    utilConvertReadingsUnit->coefficientFilePath = String::Empty;
    utilConvertReadingsUnit->convertReadingsFilePath =
        QCOM_GeneralInfo->convertReadingsFilePath;
    utilConvertReadingsUnit->flags = QCOM_UNIT_ZERO_FLAG;
    utilConvertReadingsUnit->coefficientData = (CoefficientFormatDef *)
        malloc(2 * sizeof(CoefficientFormatDef));
    ClearBuffer(utilConvertReadingsUnit->coefficientData, (2 * sizeof(CoefficientFormatDef)));
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_InstallConvertReadingsObjects()
//----------------------------------------------------------------------------
// QCOM_InstallUtilities
//
// Installs program utilities and their windows
//
// Called by:   QCOM_ConstructAndPresentUserInterface
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InstallUtilities(void)
{
    String          ^functionName = _T("QCOM_InstallUtilities");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Set up the data logging windows
    //------------------------------------------------------------------------
    QCOM_InstallDataLogging();
    //------------------------------------------------------------------------
    // Set up the miscellaneous controls window
    //------------------------------------------------------------------------
    QCOM_MiscSetUpControls();
    //------------------------------------------------------------------------
    // Set up the graphing windows
    //------------------------------------------------------------------------
    QCOM_InstallGraphingWindows();
    //------------------------------------------------------------------------
    // Set up the convert readings objects
    //------------------------------------------------------------------------
    QCOM_InstallConvertReadingsObjects();
    //------------------------------------------------------------------------
    // Set up the multiple coefficient data management windows
    //------------------------------------------------------------------------
    QCOM_InstallMultipleCoefficientWindows();
    //------------------------------------------------------------------------
    // Set up the real time weight windows
    //------------------------------------------------------------------------
    QCOM_InstallRealTimeWeightWindows();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_InstallUtilities()
//----------------------------------------------------------------------------
// QCOM_InternetIsAvailable
//
// Determines whether the web is available for access
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_InternetIsAvailable(void)
{
    bool            webAvailable = GUI_NO;
    int             attempts = 3;
    int             timeout = 120;
    String          ^functionName = _T("QCOM_InternetIsAvailable");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Determine whether the software has access to the web by pinging the
    // Quartzdyne host website
    //------------------------------------------------------------------------
    while (!webAvailable && attempts--)
    {
        Ping ^webPing = gcnew Ping;
        PingOptions ^pingOptions = gcnew PingOptions;
        pingOptions->DontFragment = GUI_YES;
        String ^pingData = _T("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        array <Byte> ^pingBuffer = Encoding::ASCII->GetBytes(pingData);
        try
        {
            PingReply ^pingReply = webPing->Send(
                QUARTZDYNE_HOST,
                timeout, pingBuffer, pingOptions);
            if (pingReply->Status == IPStatus::Success)
            {
                webAvailable = GUI_YES;
                QCOM_GeneralInfo->flags |= QCOM_GENERAL_INTERNET_AVAILABLE;
                RecordBasicEvent("    Internet search for {0} succeeded",
                    QUARTZDYNE_HOST);
                attempts = 0;
            }
            else
            {
                if (attempts)
                {
                    Thread::Sleep(500);
                }
                else
                {
                    QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_INTERNET_AVAILABLE;
                    String ^reasonString;
                    switch (pingReply->Status)
                    {
                        case IPStatus::DestinationNetworkUnreachable :
                            reasonString = _T("    Network is unreachable");
                            break;
                        case IPStatus::TimedOut :
                            reasonString = String::Format(
                                "    Attempted access to {0} timed out",
                                QUARTZDYNE_HOST);
                            break;
                        default :
                            reasonString = String::Format(
                                "    Reason unknown (status {0:D})",
                                pingReply->Status);
                            break;
                    }                   // end of switch (pingReply->Status)
                    RecordErrorEvent("    The internet is unavailable at the moment\n{0}",
                        reasonString);
                    delete reasonString;
                }
            }
        }                               // end of try
        catch (PingException ^ex)
        {
            QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_INTERNET_AVAILABLE;
            if (QCOM_ExpMessagesEnabled)
            {
                QCOM_RecordAndModalErrorEvent(
                    "Internet ping for {0} failed\nException: {1}",
                    QUARTZDYNE_HOST,
                    ex->Message);
            }
            else
            {
                QCOM_RecordAndModalErrorEvent(
                    "Unable to locate host {0} during an internet ping (attempt {1:D} of 3)",
                    QUARTZDYNE_HOST,
                    (3 - attempts));
            }
        }
        delete pingOptions;
        delete webPing;
    }                                   // end of while (!webAvailable && attempts--)
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (webAvailable ? "Available" : "Unavailable"));
    return webAvailable;
}                                       // end of QCOM_InternetIsAvailable()
//----------------------------------------------------------------------------
// QCOM_LimitFilePathStringWidth
//
// Returns a new string, based on the specified string, but limited in length
// to the specified width in pixels, by replacing leading characters with
// ellipsis
//----------------------------------------------------------------------------
    String ^ QCOM_GUIClass::
QCOM_LimitFilePathStringWidth(
    String          ^filePath,
    DWORD           maximumWidth)
{
    DWORD           minimumSpaceWidths = 28;
    //------------------------------------------------------------------------
    if (Environment::Is64BitOperatingSystem)
        minimumSpaceWidths += 10;
    if (StringSet(filePath) && (maximumWidth > minimumSpaceWidths))
    {
        //--------------------------------------------------------------------
        // Subtract the pixels taken by padding, spaces, and a colon
        //--------------------------------------------------------------------
        maximumWidth -= minimumSpaceWidths;
        if (QCOM_StringWidth(filePath) > maximumWidth)
        {
            //----------------------------------------------------------------
            // Insert the ellipsis at the front of the string
            //----------------------------------------------------------------
            filePath = filePath->PadLeft(filePath->Length + 3, '.');
            while (QCOM_StringWidth(filePath->Substring(3)) > maximumWidth)
            {
                if (filePath->Contains("\\"))
                {
                    if (filePath[3] == '\\')
                    {
                        if (filePath->Substring(4)->Contains("\\"))
                            filePath = filePath->Remove(4, filePath->Substring(4)->IndexOf('\\') + 1);
                        else
                            filePath = filePath->Remove(3, 1);
                    }
                    else
                    {
                        if (filePath->IndexOf('\\') > 3)
                            filePath = filePath->Remove(3, filePath->IndexOf('\\') - 3);
                        else
                            filePath = filePath->Remove(3, 1);
                    }
                }
                else
                {
                    //--------------------------------------------------------
                    // No more back-slashes in the string to reference, so
                    // simply remove enough characters from the front of the
                    // string, except for the ellipsis, to limit its width
                    //--------------------------------------------------------
                    while (QCOM_StringWidth(filePath->Substring(3)) > maximumWidth)
                    {
                        filePath = filePath->Remove(3, 1);
                    }
                }
            }                           // end of while (QCOM_StringWidth(filePath) > maximumWidth)
        }                               // end of if (QCOM_StringWidth(filePath) > maximumWidth)
    }                                   // end of if (StringSet(filePath) && maximumWidth)
    return filePath;
}                                       // end of QCOM_LimitFilePathStringWidth()
//----------------------------------------------------------------------------
// QCOM_LimitStringWidth
//
// Returns the specified string, limited to the specified width in pixels, by
// removing either trailing (truncateString == GUI_TRUNCATE_STRING) or leading
// (truncateString == GUI_LOP_STRING) characters
//----------------------------------------------------------------------------
    String ^ QCOM_GUIClass::
QCOM_LimitStringWidth(
    String          ^textString,
    DWORD           maximumWidth,
    bool            truncateString)
{
    int             offset = 0;
    //------------------------------------------------------------------------
    if (StringSet(textString) && (maximumWidth > 26))
    {
        //--------------------------------------------------------------------
        // Subtract the pixels taken by padding, spaces, and a colon
        //--------------------------------------------------------------------
        maximumWidth -= 26;
        while (QCOM_StringWidth(textString) > maximumWidth)
        {
            if (truncateString == GUI_TRUNCATE_STRING)
                offset = textString->Length - 1;
            textString = textString->Remove(offset, 1);
        }
    }
    return textString;
}                                       // end of QCOM_LimitStringWidth()
//----------------------------------------------------------------------------
// QCOM_ParseAndConvertStringToDouble
//
// Tests the string for floating point digits and returns the double-precision
// equivalent of the string and true if it is formatted properly, or zero and
// false if it is not
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_ParseAndConvertStringToDouble(
    String          ^doubleString,
    double          *doubleEquivalent)
{
    double          doubleValue = 0;
    String          ^functionName = _T("QCOM_ParseAndConvertStringToDouble");
    //------------------------------------------------------------------------
    bool isCorrectFormat = Double::TryParse(doubleString, doubleValue);
    if (isCorrectFormat)
        *doubleEquivalent = doubleValue;
    else
        *doubleEquivalent = 0.0;
    return isCorrectFormat;
}                                       // end of QCOM_ParseAndConvertStringToDouble()
//----------------------------------------------------------------------------
// QCOM_ParseAndConvertStringToUnsigned
//
// Tests the string for decimal digits and returns the unsigned integer
// equivalent of the string and true if it is formatted properly, or zero and
// false if it is not
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_ParseAndConvertStringToUnsigned(
    String          ^integerString,
    DWORD           *unsignedEquivalent)
{
    int             integerEquivalent = 0;
    String          ^functionName = _T("QCOM_ParseAndConvertStringToUnsigned");
    //------------------------------------------------------------------------
    bool isCorrectFormat = Int32::TryParse(integerString, integerEquivalent);
    if (isCorrectFormat)
        *unsignedEquivalent = (DWORD) integerEquivalent;
    else
        *unsignedEquivalent = 0;
    return isCorrectFormat;
}                                       // end of QCOM_ParseAndConvertStringToUnsigned()
//----------------------------------------------------------------------------
// QCOM_PauseElapsedTime
//
// Pauses activities that record the passing of time
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PauseElapsedTime(void)
{
    DWORD           currentTime = GetTickCount();
//    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_PauseElapsedTime");
    //------------------------------------------------------------------------
    RecordDetailedEvent("{0} called", functionName);
    if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED))
    {
        QCOM_PauseTime = currentTime;
        QCOM_GeneralInfo->flags |= QCOM_GENERAL_PROGRAM_PAUSED;
//        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
//            QCOM_SamplingElapsedTime += (currentTime - QCOM_SamplingStartTime);
//        if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING)
//            QCOM_LoggingElapsedTime += (currentTime - QCOM_LoggingStartTime);
//        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
//        {
//            if (QCOM_UnitNumberValid(unitNumber))
//            {
//                unit = QCOM_UnitInfoArray[unitNumber];
//                if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
//                {
//                    unit->loggingStats->cumulative += (currentTime - unit->loggingStats->startTime);
//                }
//                if (unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING)
//                {
//                    unit->testingStats->cumulative += (currentTime - unit->testingStats->startTime);
//                }
//            }
//        }
        QCOM_StartPausedBlinker();
    }                                   // end of if (!(QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED))
    RecordDetailedEvent("{0} concluded", functionName);
}                                       // end of QCOM_PauseElapsedTime()
//----------------------------------------------------------------------------
// QCOM_InstallRealTimeWeightWindows
//
// Installs the Real Time Weight windows
//
// Called by:   QCOM_InstallUtilities
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_InstallRealTimeWeightWindows(void)
{
    String          ^functionName = _T("QCOM_InstallRealTimeWeightWindows");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    for (DWORD unitNumber = 0; unitNumber < QCOM_MAXIMUM_NUMBER_OF_UNITS; unitNumber++)
    {
        if (QCOM_UnitNumberValid(unitNumber))
        {
            QCOM_RealTimeWeightCreateWindow(unitNumber);
        }                               // end of if (QCOM_UnitNumberValid(unitNumber))
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_InstallRealTimeWeightWindows()
//----------------------------------------------------------------------------
// QCOM_RealTimeWeightCloseWindow
//
// Event that hides the Real Time Weight window
//
// Called by:   QCOM_RealTimeWeightDisplayWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_RealTimeWeightCloseWindow(
    Object          ^sender,
    EventArgs       ^evt)
{
    RecordBasicEvent("Misc Persistent Flags window closed");
    realTimeWeightWindow->Hide();
    QCOM_RealTimeWeightWindowOpen = GUI_NO;
}                                       // end of QCOM_RealTimeWeightCloseWindow()
//----------------------------------------------------------------------------
// QCOM_RealTimeWeightCalibrateButtonClicked
//
// Performs calibration for the Real Time Weight window
//
// Called by:   QCOM_RealTimeWeightCreateWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_RealTimeWeightCalibrateButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_RealTimeWeightCalibrateButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
    if (unit)
    {
        QCOM_RealTimeWeightCalibration = unit->pressureValuePSI;
        QCOM_RealTimeWeightUpdateDisplayWindow(unit);
    }                                   // end of if (unit)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_RealTimeWeightCalibrateButtonClicked()
//----------------------------------------------------------------------------
// QCOM_RealTimeWeightStartStopButtonClicked
//
// Starts or stops sampling for the Real Time Weight window
//
// Called by:   QCOM_RealTimeWeightCreateWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_RealTimeWeightStartStopButtonClicked(
    Object          ^sender,
    EventArgs       ^evt)
{
    DWORD           unitNumber = (DWORD) (dynamic_cast <Button ^> (sender))->Tag;
    String          ^functionName = _T("QCOM_RealTimeWeightStartStopButtonClicked");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    UnitInfo ^unit = QCOM_UnitInfoArray[unitNumber];
    if (unit)
    {
        QCOM_StartStopSamplingUnit(unit);
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    }                                   // end of if (unit)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_RealTimeWeightStartStopButtonClicked()
//----------------------------------------------------------------------------
// QCOM_RealTimeWeightClosingWindow
//
// Handles the closing of the Real Time Weight window by the red
// X or similar method
//
// Called by:   QCOM_RealTimeWeightDisplayWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_RealTimeWeightClosingWindow(
    Object          ^sender,
    FormClosingEventArgs
                    ^evt)
{
    //------------------------------------------------------------------------
    evt->Cancel = GUI_YES;              // cancel the closing of the window
    realTimeWeightWindow->Hide();
    QCOM_RealTimeWeightWindowOpen = GUI_NO;
}                                       // end of QCOM_RealTimeWeightClosingWindow()
//----------------------------------------------------------------------------
// QCOM_RealTimeWeightCreateWindow
//
// Creates the Real Time Weight window
//
// Called by:   QCOM_InitializeUserInterface
//
// Note:    Hard-coded to unit 0 for now
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_RealTimeWeightCreateWindow(
    DWORD           unitNumber)
{
    String          ^functionName = _T("QCOM_RealTimeWeightCreateWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
    //------------------------------------------------------------------------
    // Create a new window form
    //------------------------------------------------------------------------
    if (!QCOM_RealTimeWeightWindowOpen && (unitNumber == 0))
    {
        realTimeWeightWindow = gcnew Form;
        //--------------------------------------------------------------------
        // Set the window appearance
        //--------------------------------------------------------------------
        realTimeWeightWindow->MaximizeBox = GUI_NO;
        realTimeWeightWindow->HelpButton = GUI_NO;
        realTimeWeightWindow->Icon = QCOM_SoftwareIcon;
        realTimeWeightWindow->BackgroundImage = greenMarbleBackground;
        realTimeWeightWindow->Text = _T("Your Weight");
        realTimeWeightWindow->Size = Drawing::Size(1600, 610);
        realTimeWeightWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
        //--------------------------------------------------------------------
        // Real time weight in pounds text
        //--------------------------------------------------------------------
        realTimeWeightPoundsLabel = gcnew Label;
        realTimeWeightPoundsLabel->Location = Point(10, 10);
        realTimeWeightPoundsLabel->Size = Drawing::Size(
            realTimeWeightWindow->Width - 30,
            340);
        realTimeWeightPoundsLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        realTimeWeightPoundsLabel->BackColor = Color::Transparent;
        realTimeWeightPoundsLabel->ForeColor = Color::Red;
        realTimeWeightPoundsLabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            220.0F,
            FontStyle::Bold);
        realTimeWeightWindow->Controls->Add(realTimeWeightPoundsLabel);
        //--------------------------------------------------------------------
        // Real time weight in pounds text
        //--------------------------------------------------------------------
        realTimeWeightPSILabel = gcnew Label;
        realTimeWeightPSILabel->Location = Point(
            realTimeWeightPoundsLabel->Left,
            realTimeWeightPoundsLabel->Bottom + 20);
        realTimeWeightPSILabel->Size = Drawing::Size(
            realTimeWeightPoundsLabel->Width,
            150);
        realTimeWeightPSILabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
        realTimeWeightPSILabel->BackColor = Color::Transparent;
        realTimeWeightPSILabel->ForeColor = Color::Blue;
        realTimeWeightPSILabel->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            80.0F,
            FontStyle::Bold);
        realTimeWeightWindow->Controls->Add(realTimeWeightPSILabel);
        //--------------------------------------------------------------------
        // Start / Stop button
        //--------------------------------------------------------------------
        Button ^realTimeWeightStartStopButton = gcnew Button;
        realTimeWeightStartStopButton->Text = _T("Start");
        realTimeWeightStartStopButton->Location = Point(
            10, realTimeWeightWindow->Bottom - 70);
        realTimeWeightStartStopButton->Size = Drawing::Size(
            85, GUI_REGULAR_BUTTON_HEIGHT);
        GUI_SetUnitButtonInterfaceProperties(
            realTimeWeightStartStopButton,
            unitNumber);
        realTimeWeightStartStopButton->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            12.0F,
            FontStyle::Bold);
        GUI_SetUnitButtonInterfaceProperties(
            realTimeWeightStartStopButton,
            unitNumber);
        realTimeWeightStartStopButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_RealTimeWeightStartStopButtonClicked);
        expertRealTimeWeightStartStopButtonArray[unitNumber] = realTimeWeightStartStopButton;
        realTimeWeightWindow->Controls->Add(realTimeWeightStartStopButton);
        //--------------------------------------------------------------------
        // Real Time Weight Multiplier label
        //--------------------------------------------------------------------
        Label ^realTimeWeightMultiplierLabel = gcnew Label;
        realTimeWeightMultiplierLabel->Text = _T("Multiplier :");
        realTimeWeightMultiplierLabel->Location = Point(
            realTimeWeightStartStopButton->Right + 35,
            realTimeWeightStartStopButton->Top + 6);
        realTimeWeightMultiplierLabel->Size = Drawing::Size(
            56, GUI_REGULAR_LABEL_HEIGHT);
        realTimeWeightMultiplierLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
        realTimeWeightMultiplierLabel->BackColor = Color::Transparent;
        realTimeWeightWindow->Controls->Add(realTimeWeightMultiplierLabel);
        //--------------------------------------------------------------------
        // Multiplier box
        //--------------------------------------------------------------------
        realTimeWeightMultiplierBox = gcnew TextBox;
        realTimeWeightMultiplierBox->Text = String::Format(
            "{0:F3}",
            QCOM_RealTimeWeightMultiplier);
        realTimeWeightMultiplierBox->Location = Point(
            realTimeWeightMultiplierLabel->Right + 2,
            realTimeWeightMultiplierLabel->Top - 2);
        realTimeWeightMultiplierBox->Size = Drawing::Size(
            50, GUI_REGULAR_TEXT_BOX_HEIGHT);
        realTimeWeightMultiplierBox->Multiline = GUI_NO;
        realTimeWeightMultiplierBox->AcceptsReturn = GUI_NO;
        realTimeWeightMultiplierBox->AcceptsTab = GUI_NO;
        realTimeWeightMultiplierBox->WordWrap = GUI_NO;
        realTimeWeightMultiplierBox->TextAlign = HorizontalAlignment::Center;
        realTimeWeightMultiplierBox->BackColor = Color::White;
        realTimeWeightMultiplierBox->Validating +=
            gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateRealTimeWeightMultiplierValue);
        realTimeWeightWindow->Controls->Add(realTimeWeightMultiplierBox);
        //--------------------------------------------------------------------
        // Calibrate button
        //--------------------------------------------------------------------
        Button ^realTimeWeightCalibrateButton = gcnew Button;
        realTimeWeightCalibrateButton->Text = _T("Calibrate");
        realTimeWeightCalibrateButton->Location = Point(
            realTimeWeightMultiplierBox->Right + 35,
            realTimeWeightStartStopButton->Top);
        realTimeWeightCalibrateButton->Size = realTimeWeightStartStopButton->Size;
        GUI_SetUnitButtonInterfaceProperties(
            realTimeWeightCalibrateButton,
            unitNumber);
        realTimeWeightCalibrateButton->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            12.0F,
            FontStyle::Bold);
        GUI_SetButtonInterfaceProperties(realTimeWeightCalibrateButton);
        realTimeWeightCalibrateButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_RealTimeWeightCalibrateButtonClicked);
        expertRealTimeWeightCalibrateButtonArray[unitNumber] = realTimeWeightCalibrateButton;
        realTimeWeightWindow->Controls->Add(realTimeWeightCalibrateButton);
        //--------------------------------------------------------------------
        // Close button
        //--------------------------------------------------------------------
        Button ^realTimeWeightCloseButton = gcnew Button;
        realTimeWeightCloseButton->Text = _T("Close");
        realTimeWeightCloseButton->Location = Point(
            realTimeWeightWindow->Right - 110,
            realTimeWeightWindow->Bottom - 70);
        realTimeWeightCloseButton->Size = realTimeWeightStartStopButton->Size;
        realTimeWeightCloseButton->Font = gcnew Drawing::Font(
            FontFamily::GenericSansSerif,
            12.0F,
            FontStyle::Bold);
        realTimeWeightCloseButton->DialogResult = System::Windows::Forms::DialogResult::OK;
        GUI_SetButtonInterfaceProperties(realTimeWeightCloseButton);
        realTimeWeightCloseButton->Click +=
            gcnew EventHandler(this, &QCOM_GUIClass::QCOM_RealTimeWeightCloseWindow);
        realTimeWeightWindow->FormClosing +=
            gcnew FormClosingEventHandler(this, &QCOM_GUIClass::QCOM_RealTimeWeightClosingWindow);
        realTimeWeightWindow->Controls->Add(realTimeWeightCloseButton);
        realTimeWeightWindow->AcceptButton = realTimeWeightCloseButton;
        realTimeWeightWindow->CancelButton = realTimeWeightCloseButton;
        //--------------------------------------------------------------------
        // Retrieve and set the initial values
        //--------------------------------------------------------------------
        QCOM_RealTimeWeightUpdateDisplayWindow(QCOM_UnitInfoArray[unitNumber]);
        realTimeWeightWindow->ResumeLayout();
        realTimeWeightWindow->Hide();
    }                                   // end of if (!QCOM_RealTimeWeightWindowOpen)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_RealTimeWeightCreateWindow()
//----------------------------------------------------------------------------
// QCOM_RealTimeWeightDisplayWindow
//
// Displays a person's weight in real time
//
// Called by:   QCOM_ExpertRealTimeWeightDemoButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_RealTimeWeightDisplayWindow(
    DWORD           unitNumber)
{
    String          ^functionName = _T("QCOM_RealTimeWeightDisplayWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1:D}) called", functionName, unitNumber);
    if (!QCOM_RealTimeWeightWindowOpen)
    {
        QCOM_RealTimeWeightWindowOpen = GUI_YES;
        if (realTimeWeightWindow->WindowState == FormWindowState::Minimized)
            realTimeWeightWindow->WindowState = FormWindowState::Normal;
        else
            realTimeWeightWindow->Show();
        if (realTimeWeightWindow->CanSelect)
            realTimeWeightWindow->Select();
        QCOM_RealTimeWeightWindowOpen = GUI_YES;
    }                                   // end of if (!QCOM_RealTimeWeightWindowOpen)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_RealTimeWeightDisplayWindow()
//----------------------------------------------------------------------------
// QCOM_RealTimeWeightUpdateDisplayWindow
//
// Updates the Real Time Weight window with the real time weight
//
// Called by:   QCOM_UpdateReadout
//
// Note:    Hard-coded to unit 0 for now
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_RealTimeWeightUpdateDisplayWindow(
    UnitInfo        ^unit)
{
    String          ^functionName = _T("QCOM_RealTimeWeightUpdateDisplayWindow");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0}({1:D}) called", functionName, unit->unitNumber);
    if (unit)
    {
        if (unit->unitNumber == 0)
        {
            double apparentPressurePSI =
                unit->pressureValuePSI - QCOM_RealTimeWeightCalibration;
            if (apparentPressurePSI < 0)
                apparentPressurePSI *= -1.0;
            double realTimeWeightPounds =
                apparentPressurePSI * QCOM_RealTimeWeightMultiplier;
            if (realTimeWeightPounds < 0)
                realTimeWeightPounds *= -1.0;
            realTimeWeightPoundsLabel->Text = String::Format(
                "{0:F2} lbs",
                realTimeWeightPounds);
            realTimeWeightPSILabel->Text = String::Format(
                "({0:F2} psi)",
                apparentPressurePSI);
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_RealTimeWeightUpdateDisplayWindow()
//----------------------------------------------------------------------------
// QCOM_PerformExperimentalExercise
//
// Performs a particular experimental exercise
//
// Called by:   QCOM_ExpertExperimentalButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PerformExperimentalExercise(void)
{
    String          ^functionName = _T("QCOM_PerformExperimentalExercise");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    Modal("No experiment to perform");
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_PerformExperimentalExercise()
//----------------------------------------------------------------------------
// QCOM_PerformExperiments
//
// Performs arbitrary experiments on demand
//
// Called by:   QCOM_ExpertPerformExperimentsButtonClicked (QCOM_ConstructGeneralExpertGroupBox)
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PerformExperiments(void)
{
    DWORD           experimentNumber = QCOM_CurrentExperimentNumber;
    UnitInfo        ^unit = QCOM_UnitInfoArray[0];
    String          ^functionName = _T("QCOM_PerformExperiments");
    //------------------------------------------------------------------------
    if (QCOM_ExperimentsEnabled)
    {
        RecordBasicEvent("{0} called for experiment {1:D}", functionName, experimentNumber);
        if (experimentNumber)
        {
            switch (experimentNumber)
            {
                case 1 :
                    Modal("The cwd = {0}",
                        AppDomain::CurrentDomain->BaseDirectory);
                    Modal("The app = {0}",
                        Application::StartupPath);
                    break;
                case 7 :
                    break;
                case 73 :
                case 74 :
                    break;
                case 8 :
                    break;
                default :
                    break;
            }                           // end of switch (experimentNumber)
        }                               // end of if (experimentNumber)
        RecordBasicEvent("{0} concluded", functionName);
    }                                   // end of if (QCOM_ExperimentsEnabled)
    else
    {
        Modal("Experiments are not enabled");
    }
}                                       // end of QCOM_PerformExperiments()
//----------------------------------------------------------------------------
// QCOM_PleaseWait
//
// Displays a "Please wait..." window
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PleaseWait(
    DWORD           action,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    String          ^titleString;
    //------------------------------------------------------------------------
    if (!QCOM_CommandLineOnly)
    {
        if (StringSet(formatString))
        {
            titleString = String::Format(formatString, parameters);
        }
        switch (action)
        {
            case GUI_PLEASE_WAIT_INSTALL :                                      // 1
                pleaseWaitWindow = gcnew Form;
                pleaseWaitWindow->TopMost = GUI_YES;
                pleaseWaitWindow->Tag = GUI_PLEASE_WAIT_STATE_HIDDEN;
                pleaseWaitWindow->Icon = QCOM_SoftwareIcon;
                pleaseWaitWindow->BackgroundImage = whiteSandBackground;
                pleaseWaitWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
                pleaseWaitWindow->StartPosition = FormStartPosition::CenterScreen;
                pleaseWaitWindow->MaximizeBox = GUI_NO;
                pleaseWaitWindow->MinimizeBox = GUI_NO;
                pleaseWaitWindow->HelpButton = GUI_NO;
                pleaseWaitLabel = gcnew Label;
                pleaseWaitLabel->Text = GUI_PLEASE_WAIT_STRING;
                pleaseWaitLabel->Font = gcnew Drawing::Font(
                    FontFamily::GenericSansSerif,
                    13.0F,
                    FontStyle::Bold);
                pleaseWaitLabel->Size = Drawing::Size(132, 20);
                pleaseWaitLabel->BackColor = Color::Transparent;
                pleaseWaitWindow->Controls->Add(pleaseWaitLabel);
                //------------------------------------------------------------
                // Handle the closing of the window
                //------------------------------------------------------------
                pleaseWaitWindow->FormClosing +=
                    gcnew FormClosingEventHandler(this, &QCOM_GUIClass::QCOM_PleaseWaitClosingWindow);
                break;

            case GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE :                            // 2
                if (pleaseWaitWindow)
                {
                    Cursor = Cursors::WaitCursor;
                    if (((int) pleaseWaitWindow->Tag) == GUI_PLEASE_WAIT_STATE_VISIBLE)
                    {
                        //----------------------------------------------------
                        // One is already showing, so hide it to reconfigure it
                        //----------------------------------------------------
                        pleaseWaitWindow->Hide();
                        pleaseWaitWindow->Update();
                    }
                    if (StringSet(titleString))
                    {
                        pleaseWaitWindow->Text = titleString;
                        pleaseWaitWindow->Size = Drawing::Size(
                            Max(QCOM_StringWidth(titleString), QCOM_StringWidth(GUI_PLEASE_WAIT_STRING)) + 124,
                            100);
                    }
                    else
                    {
                        pleaseWaitWindow->Text = _T("QCOM");
                        pleaseWaitWindow->Size = Drawing::Size(
                            QCOM_StringWidth(GUI_PLEASE_WAIT_STRING) + 124,
                            100);
                    }
                    if (pleaseWaitLabel)
                    {
                        pleaseWaitLabel->Location = Point(
                            (abs(pleaseWaitWindow->Width - pleaseWaitLabel->Width) / 2),
                            20);
                    }
                    pleaseWaitWindow->Show();
                    pleaseWaitWindow->Tag = GUI_PLEASE_WAIT_STATE_VISIBLE;
                    pleaseWaitWindow->Update();
                }
                break;

            case GUI_PLEASE_WAIT_DISPLAY_CURRENT_TITLE :                        // 3
                if (pleaseWaitWindow)
                {
                    pleaseWaitWindow->Show();
                    pleaseWaitWindow->Tag = GUI_PLEASE_WAIT_STATE_VISIBLE;
                    pleaseWaitWindow->Update();
                }
                break;

            case GUI_PLEASE_WAIT_HIDE :                                         // 4
            case GUI_PLEASE_WAIT_REMOVE :                                       // 5
                if (pleaseWaitWindow)
                {
                    if (((int) pleaseWaitWindow->Tag) == GUI_PLEASE_WAIT_STATE_VISIBLE)
                    {
                        pleaseWaitWindow->Hide();
                        pleaseWaitWindow->Tag = GUI_PLEASE_WAIT_STATE_HIDDEN;
                        pleaseWaitWindow->Update();
                    }
                }
                Cursor = Cursors::Default;
                break;

            case GUI_PLEASE_WAIT_DISPOSE :                                      // 7
                if (pleaseWaitLabel)
                {
                    delete pleaseWaitLabel;
                }
                if (pleaseWaitWindow)
                {
                    pleaseWaitWindow->Close();
                    delete pleaseWaitWindow;
                }
                break;

            default :
                break;
        }                               // end of switch (action)
    }                                   // end of if (!QCOM_CommandLineOnly)
}                                       // end of QCOM_PleaseWait()
//----------------------------------------------------------------------------
// QCOM_ProcessI2CCommand
//
// Sends the specified I²C-formatted command to the transducer at the specified
// unit and returns the response
//
// Note:    replyString must point to at least QCOM_MAXIMUM_I2C_REPLY_STRING_SIZE
//          (768) bytes of available memory
//
// Note:    interpretationString must point to at least
//          QCOM_MAXIMUM_I2C_INTERP_STRING_SIZE (1024) bytes of available memory
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_ProcessI2CCommand(
    UnitInfo        ^unit,
    char            *commandString,
    char            *replyString,
    char            *interpretationString)
{
    bool            digital = GUI_NO;
    bool            fromTransducer = GUI_NO;
    bool            readCommand = GUI_NO;
    bool            statusRegister = GUI_NO;
    bool            temperature = GUI_NO;
    char            memoryAddress[QCOM_MAXIMUM_I2C_ADDRESS_BUFFER_SIZE];
    char            *commandInterp;
    char            *commandDetail;
    char            *commandStringCopy;
    char            *rCharacter;
    char            *stopCharacter;
    char            response[QCOM_MAXIMUM_I2C_RESPONSE_STRING_SIZE];            // 96
    DWORD           status = QCOM_FAILURE;
    String          ^functionName = _T("QCOM_ProcessI2CCommand");
    //------------------------------------------------------------------------
    if (QCOM_UnitValid(unit) &&
        commandString && replyString && interpretationString)
    {
        RecordBasicEvent("{0}({1:D})[{2}] called",
            functionName, unit->unitNumber, gcnew String(commandString));
        commandInterp = (char *) malloc(QCOM_MAXIMUM_I2C_INTERP_STRING_SIZE);
        commandStringCopy = (char *) malloc(QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE);
        if (commandInterp && commandStringCopy)
        {
            strcpy_s(
                commandStringCopy,
                QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE,
                commandString);
            _strupr_s(commandStringCopy, QCOM_MAXIMUM_I2C_COMMAND_STRING_SIZE);
            if (AtoX(commandStringCopy[2]) & 0x01)
                readCommand = GUI_YES;
            if (commandStringCopy[1] == '9')
            {
                fromTransducer = GUI_YES;
                if (commandStringCopy[3] == 'R')
                {
                    readCommand = GUI_YES;
                    if ((AtoX(commandStringCopy[5]) & 0x03) == 0x01)
                        commandDetail = "Chip ID";
                    if ((AtoX(commandStringCopy[5]) & 0x03) == 0x03)
                        commandDetail = "Status";
                }
                else
                {
                    if (AtoX(commandStringCopy[2]) & 0x02)
                    {
                        statusRegister = GUI_YES;
                        temperature = GUI_YES;
                    }
                    if (AtoX(commandStringCopy[2]) & 0x04)
                        digital = GUI_YES;
                    if (temperature)
                        commandDetail = "Temperature";
                    else
                        commandDetail = "Pressure";
                }
                sprintf_s(
                    commandInterp,
                    QCOM_MAXIMUM_I2C_INTERP_STRING_SIZE,
                    "%s (%s)",
                    commandDetail,
                    (digital ? "digital" : "analog"));
            }
            else
            {
                if (commandStringCopy[7] == 'R')
                {
                    readCommand = GUI_YES;
                    ClearBuffer(memoryAddress, QCOM_MAXIMUM_I2C_ADDRESS_BUFFER_SIZE);
                    memcpy(memoryAddress, &commandStringCopy[3], 4);
                    if ((commandStringCopy[2] == 'C') && (commandStringCopy[9] == 'D'))
                        digital = GUI_YES;
                    if (((commandStringCopy[2] == '2') && (commandStringCopy[9] == '3')) ||
                        ((commandStringCopy[2] == 'C') && (commandStringCopy[9] == 'D')))
                        commandDetail = "Specific Address";
                    else
                        commandDetail = "Address";
                    sprintf_s(
                        commandInterp,
                        QCOM_MAXIMUM_I2C_INTERP_STRING_SIZE,
                        "ASIC (%s 0x%s)",
                        commandDetail,
                        memoryAddress);
                }
                else
                {
                    commandDetail = "unknown";
                    sprintf_s(
                        commandInterp,
                        QCOM_MAXIMUM_I2C_INTERP_STRING_SIZE,
                        "ASIC (%s)",
                        commandDetail);
                }
            }
            stopCharacter = strchr(commandStringCopy, 'P');
            if ((*commandStringCopy == 'S') && stopCharacter)
            {
                *++stopCharacter = QCOM_CHAR_NULL;
                status = QD_ExecuteI2CCommand(
                    unit->unitHandle,
                    (LPBYTE) commandString,
                    (LPBYTE) replyString);
                if (status == QD_SUCCESS)
                {
                    String ^reply = gcnew String(replyString);
                    RecordVerboseEvent("    I²C command reply: {0}",
                        reply->Replace(QCOM_STRING_CRLF, QCOM_STRING_EMPTY));
                    ClearBuffer(response, QCOM_MAXIMUM_I2C_RESPONSE_STRING_SIZE);
                    if (replyString[strlen(replyString) - 2] == QCOM_CHAR_CR)
                        replyString[strlen(replyString) - 2] = QCOM_CHAR_NULL;
                    if (strlen(replyString) > (QCOM_MAXIMUM_I2C_RESPONSE_STRING_SIZE - 4))
                    {
                        sprintf_s(
                            response,
                            QCOM_MAXIMUM_I2C_RESPONSE_STRING_SIZE,
                            "...%s",
                            &replyString[strlen(replyString) - QCOM_MAXIMUM_I2C_RESPONSE_STRING_SIZE - 4]);
                    }
                    else
                    {
                        strcpy_s(response, QCOM_MAXIMUM_I2C_RESPONSE_STRING_SIZE, replyString);
                    }
                    if (*response == 'S')
                        memmove(response, (response + 3), strlen(response) - 2);
                    rCharacter = strchr(response, 'R');
                    if (rCharacter)
                    {
                        memmove(response, (rCharacter + 3), strlen(rCharacter) - 2);
                    }
                    stopCharacter = strchr(response, 'P');
                    if (stopCharacter)
                    {
                        *stopCharacter = QCOM_CHAR_NULL;
                    }
                    if (fromTransducer)
                    {
                        sprintf_s(
                            interpretationString,
                            QCOM_MAXIMUM_I2C_INTERP_STRING_SIZE,
                            "[ %s %s %s => %s ]",
                            (readCommand ? "Read" : "Write"),
                            commandInterp,
                            "",
                            response);
                    }
                    else
                    {
                        sprintf_s(
                            interpretationString,
                            QCOM_MAXIMUM_I2C_INTERP_STRING_SIZE,
                            "[ %s %s %s => %s ]",
                            (readCommand ? "Read" : "Write"),
                            commandInterp,
                            "",
                            response);
                    }
                }
                else
                {
                    RecordErrorEvent("    QD_ExecuteI2CCommand({0}) returned 0x{1:X8}",
                        gcnew String(commandString), status);
                }
            }
            else
            {
                RecordErrorEvent(
                    "    Malformed I²C command string: {1}",
                    gcnew String(commandString));
            }
            free((void *) commandStringCopy);
            free((void *) commandInterp);
        }
        RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    }                                   // end of if (QCOM_UnitValid(unit) && ...)
    else
    {
        if (QCOM_UnitValid(unit))
        {
            RecordErrorEvent("{0}({1:D}) called with an invalid pointer",
                functionName, unit->unitNumber);
        }
        else
        {
            RecordErrorEvent("{0} called with an invalid unit pointer", functionName);
        }
    }
    return status;
}                                       // end of QCOM_ProcessI2CCommand()
//----------------------------------------------------------------------------
// QCOM_PromptAndVerifyHexFile
//
// Prompts for a hex file and tests it for validity
//
// Called by:   QCOM_UtilVerifyHexFileButtonClicked (QCOM_ConstructGeneralUtilitiesGroupBox)
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_PromptAndVerifyHexFile(void)
{
    bool            browseForFiles = GUI_NO;
    bool            dbFileFound = GUI_NO;
    bool            fileLocated = GUI_NO;
    bool            inputResponse = GUI_ACCEPT;
    bool            inputValid = GUI_NO;
    bool            proceedToSearchDB = GUI_NO;
    bool            promptResult = GUI_ACCEPT;
    DWORD           status = QCOM_SUCCESS;
    DWORD           transducerSerialNumber = 0;
    StringBuilder   ^filePathBuilder;
    String          ^dbPathString = QUARTZDYNE_CONFIDENTIAL_ROOT QUARTZDYNE_CALSUM_DB_FILE_PATH;
    String          ^filePathString;
    String          ^transducerSearchString;
    String          ^functionName = _T("QCOM_PromptAndVerifyHexFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    filePathBuilder = gcnew StringBuilder(QCOM_MAXIMUM_FILE_PATH_LENGTH);
    //------------------------------------------------------------------------
    // Search the network, if present, for the CALSUM database file
    //------------------------------------------------------------------------
    if (File::Exists(dbPathString))
    {
        dbFileFound = GUI_YES;
    }
    else
    {
        array <DriveInfo ^> ^driveInfo = DriveInfo::GetDrives();
        for each (DriveInfo ^oneDrive in driveInfo)
        {
            if (oneDrive->DriveType == DriveType::Network)
            {
                dbPathString = String::Concat(
                    oneDrive->Name, QUARTZDYNE_CALSUM_DB_FILE_PATH);
                if (File::Exists(dbPathString))
                {
                    dbFileFound = GUI_YES;
                }
            }
        }
    }
    if (dbFileFound)
    {
        proceedToSearchDB = QCOM_PromptYesNoModal(
            "Search or Browse",
            "Search", "Browse...",
            "Search the database or browse for a\nhex file to test ?");
        if (QCOM_ModalKeyStroke == GUI_KEY_ESC)
        {
            browseForFiles = GUI_NO;
        }
        else
        {
            if (proceedToSearchDB)
            {
                do
                {
                    inputValid = GUI_YES;
                    StringBuilder ^transducerSearchBuilder = gcnew StringBuilder(
                        transducerSearchString,
                        QCOM_MAXIMUM_SEARCH_STRING_SIZE);
                    inputResponse = QCOM_PromptInputModal(
                        "Transducer Serial Number",
                        QCOM_GeneralInfo->searchString,
                        &transducerSerialNumber,
                        transducerSearchBuilder,
                        QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH,
                        "Enter the transducer serial number to search for");
                    transducerSearchString = transducerSearchBuilder->ToString();
                    delete transducerSearchBuilder;
                    if (inputResponse == GUI_ACCEPT)
                    {
                        if (StringSet(transducerSearchString) && transducerSerialNumber)
                        {
                            if (transducerSerialNumber < 10000)
                                inputValid = GUI_NO;
                            if (transducerSearchString->Length < (QCOM_MAXIMUM_XD_SERIAL_NUMBER_LENGTH - 1))
                                inputValid = GUI_NO;
                            if (inputValid)
                            {
                                QCOM_GeneralInfo->searchString = transducerSearchString;
                            }
                            else
                            {
                                GUI_DisplayMandatoryError(
                                    functionName,
                                    "'{0}' is not a valid transducer serial number",
                                    transducerSearchString);
                            }
                        }
                        else
                        {
                            browseForFiles = GUI_YES;
                        }
                    }
                }
                while ((inputResponse == GUI_ACCEPT) && !inputValid);
                if ((inputResponse == GUI_ACCEPT) && inputValid)
                {
                    browseForFiles = GUI_NO;
                    //--------------------------------------------------------
                    // Search the database
                    //--------------------------------------------------------
                    QCOM_PleaseWait(
                        GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
                        "Searching for Transducer {0} Hex File",
                        transducerSearchString);
                    fileLocated = QCOM_SearchForCoefficientFile(
                        transducerSearchString,
                        filePathBuilder);
                    filePathString = filePathBuilder->ToString();
                    QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
                    Thread::Sleep(100);
                    if (fileLocated)
                    {
                        if (!filePathString->ToLower()->EndsWith(".hex"))
                        {
                            filePathString = filePathString->Replace(
                                Path::GetExtension(filePathString),
                                ".hex");
                            GUI_StringToBuilder(filePathString, filePathBuilder);
                        }
                        if (File::Exists(filePathString))
                        {
                            fileLocated = GUI_YES;
                        }
                        else
                        {
                            fileLocated = GUI_NO;
                            browseForFiles = GUI_YES;
                        }
                    }
                    else
                    {
                        browseForFiles = GUI_YES;
                    }
                }
            }
            else
            {
                browseForFiles = GUI_YES;
            }
        }                               // end of else of if (QCOM_ModalKeyStroke == GUI_KEY_ESC)
    }
    else
    {
        browseForFiles = GUI_YES;
    }
    if (browseForFiles)
    {
        do
        {
            fileLocated = GUI_NO;
            promptResult = QCOM_PromptForReadFile(
                "Locating a Hex File to Test",
                filePathBuilder,
                transducerSearchString,
                GUI_FILE_TYPE_HEX);
            filePathString = filePathBuilder->ToString();
            if (promptResult == GUI_ACCEPT)
            {
                if (File::Exists(filePathString))
                {
                    fileLocated = GUI_YES;
                }
            }
        }
        while ((promptResult == GUI_ACCEPT) && !fileLocated);
    }
    delete filePathBuilder;
    if ((promptResult == GUI_ACCEPT) && fileLocated)
    {
        QCOM_VerifyHexFileFormat(filePathString);
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_PromptAndVerifyHexFile()
//----------------------------------------------------------------------------
// QCOM_PromptForReadFile
//
// Prompts the user for a filename used for reading data, but does not actually
// perform any data transfer
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_PromptForReadFile(
    String          ^titleString,
    StringBuilder   ^filePathBuilder,
    String          ^suggestedFileName,
    DWORD           fileType)
{
    bool            promptResult;
    String          ^filePathString;
    String          ^functionName = _T("QCOM_PromptForReadFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
//    QCOM_PauseElapsedTime();
    OpenFileDialog ^readFile = gcnew OpenFileDialog;
    if (StringSet(filePathBuilder))
    {
        filePathString = filePathBuilder->ToString();
        readFile->InitialDirectory = Path::GetDirectoryName(filePathString);
    }
    else
    {
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_USE_PATH_SPECIFIED)
        {
            readFile->InitialDirectory = QCOM_GeneralInfo->generalUsePath;
        }
        else
        {
            readFile->InitialDirectory =
                Environment::GetFolderPath(Environment::SpecialFolder::Recent);
//                Environment::GetFolderPath(Environment::SpecialFolder::MyDocuments);
        }
    }
    if (StringSet(suggestedFileName))
    {
        readFile->FileName = Path::GetFileName(suggestedFileName);
    }
    else
    {
        if (StringSet(filePathString))
            readFile->FileName = Path::GetFileName(filePathString);
    }
    if (!StringSet(titleString))
        titleString = _T("Read File");
    readFile->Title = titleString;
    switch (fileType)
    {
        case GUI_FILE_TYPE_TEXT :                                               // 1
            readFile->DefaultExt = _T("txt");
            readFile->Filter = GUI_FILE_SPEC_TEXT;
            break;
        case GUI_FILE_TYPE_HEX :                                                // 2
            readFile->DefaultExt = _T("hex");
            readFile->Filter = GUI_FILE_SPEC_HEX;
            break;
        case GUI_FILE_TYPE_LOG :                                                // 3
            readFile->DefaultExt = _T("log");
            readFile->Filter = GUI_FILE_SPEC_LOG;
            break;
        case GUI_FILE_TYPE_DAT :                                                // 4
            readFile->DefaultExt = _T("dat");
            readFile->Filter = GUI_FILE_SPEC_DAT;
            break;
        case GUI_FILE_TYPE_HEX_NATIVE_REF :                                     // 5
            readFile->DefaultExt = _T("hex");
            readFile->Filter = GUI_FILE_SPEC_HEX_NATIVE_REF;
            break;
        case GUI_FILE_TYPE_HEX_NATIVE_ALL :                                     // 6
            readFile->DefaultExt = _T("hex");
            readFile->Filter = GUI_FILE_SPEC_HEX_NATIVE_ALL;
            break;
        case GUI_FILE_TYPE_NATIVE_REF :                                         // 7
            readFile->DefaultExt = _T("crf");
            readFile->Filter = GUI_FILE_SPEC_NATIVE_REF;
            break;
        case GUI_FILE_TYPE_CSV :                                                // 8
            readFile->DefaultExt = _T("csv");
            readFile->Filter = GUI_FILE_SPEC_CSV;
            break;
        case GUI_FILE_TYPE_CONFIG :                                             // 9
            readFile->DefaultExt = _T("config");
            readFile->Filter = GUI_FILE_SPEC_CONFIG;
            break;
        case GUI_FILE_TYPE_BIN :                                                // 10
            readFile->DefaultExt = _T("bin");
            readFile->Filter = GUI_FILE_SPEC_BIN;
            break;
        case GUI_FILE_TYPE_EXE :                                                // 11
            readFile->DefaultExt = _T("exe");
            readFile->Filter = GUI_FILE_SPEC_EXE;
            break;
        case GUI_FILE_TYPE_ZIP :                                                // 12
            readFile->DefaultExt = _T("zip");
            readFile->Filter = GUI_FILE_SPEC_ZIP;
            break;
        case GUI_FILE_TYPE_DLL :                                                // 13
            readFile->DefaultExt = _T("dll");
            readFile->Filter = GUI_FILE_SPEC_DLL;
            break;
        case GUI_FILE_TYPE_LOG_CSV :                                            // 14
            readFile->DefaultExt = _T("log");
            readFile->Filter = GUI_FILE_SPEC_LOG_CSV;
            break;
        case GUI_FILE_TYPE_COF2 :                                               // 15
            readFile->DefaultExt = _T("cof2");
            readFile->Filter = GUI_FILE_SPEC_COF2;
            break;
        case GUI_FILE_TYPE_UNKNOWN :                                            // 0
            if (StringSet(readFile->FileName))
            {
                readFile->DefaultExt = Path::GetExtension(readFile->FileName);
            }
            else
            {
                readFile->FileName = _T("*.*");
                readFile->DefaultExt = _T("*");
            }
            readFile->Filter = GUI_FILE_SPEC_ALL;
            break;
        default :
            if (StringSet(readFile->FileName))
                readFile->FileName = _T("*.*");
            else
                readFile->DefaultExt = _T("*");
            readFile->Filter = GUI_FILE_SPEC_ALL;
            break;
    }                                   // end of switch (fileType)
    if (StringSet(readFile->FileName))
        readFile->FileName = Path::GetFileNameWithoutExtension(readFile->FileName);
    readFile->FilterIndex = 1;          // 1 == specified / 2 == *.*
    readFile->RestoreDirectory = GUI_YES;
    //------------------------------------------------------------------------
    // The following line works around issues with Windows 7 and Vista
    //------------------------------------------------------------------------
    readFile->AutoUpgradeEnabled = GUI_NO;
    //------------------------------------------------------------------------
    // Display the window and query the user
    //------------------------------------------------------------------------
    if (readFile->ShowDialog() == System::Windows::Forms::DialogResult::OK)
    {
        promptResult = GUI_ACCEPT;
        filePathBuilder->Length = QCOM_MAXIMUM_FILE_PATH_LENGTH;
        GUI_StringToBuilder(readFile->FileName, filePathBuilder);
        filePathString = filePathBuilder->ToString();
        QCOM_SetGeneralUsePath(filePathString);
        RecordBasicEvent(
            "    Prompt for input file accepted: {0}",
            readFile->FileName);
    }
    else
    {
        promptResult = GUI_CANCEL;
    }
    delete readFile;
//    QCOM_ResumeElapsedTime();
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (promptResult ? "Yes" : "No"));
    return promptResult;
}                                       // end of QCOM_PromptForReadFile()
//----------------------------------------------------------------------------
// QCOM_PromptForSaveFile
//
// Prompts the user for a filename used for saving data, but does not actually
// perform any data transfer
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_PromptForSaveFile(
    String          ^titleString,
    StringBuilder   ^filePathBuilder,
    String          ^suggestedFileName,
    DWORD           fileType)
{
    bool            promptResult;
    String          ^filePathString;
    String          ^functionName = _T("QCOM_PromptForSaveFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
//    QCOM_PauseElapsedTime();
    SaveFileDialog ^saveFile = gcnew SaveFileDialog;
    if (StringSet(filePathBuilder))
    {
        filePathString = filePathBuilder->ToString();
        saveFile->InitialDirectory = Path::GetDirectoryName(filePathString);
    }
    else
    {
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_USE_PATH_SPECIFIED)
        {
            saveFile->InitialDirectory = QCOM_GeneralInfo->generalUsePath;
        }
        else
        {
            saveFile->InitialDirectory =
                Environment::GetFolderPath(Environment::SpecialFolder::Recent);
//                Environment::GetFolderPath(Environment::SpecialFolder::MyDocuments);
        }
    }
    if (StringSet(suggestedFileName))
    {
        saveFile->FileName = Path::GetFileName(suggestedFileName);
    }
    else
    {
        if (StringSet(filePathString))
            saveFile->FileName = Path::GetFileName(filePathString);
    }
    if (!StringSet(titleString))
        titleString = _T("Save File");
    saveFile->Title = titleString;
    switch (fileType)
    {
        case GUI_FILE_TYPE_TEXT :                                               // 1
            saveFile->DefaultExt = _T("txt");
            saveFile->Filter = GUI_FILE_SPEC_TEXT;
            break;
        case GUI_FILE_TYPE_HEX :                                                // 2
            saveFile->DefaultExt = _T("hex");
            saveFile->Filter = GUI_FILE_SPEC_HEX;
            break;
        case GUI_FILE_TYPE_LOG :                                                // 3
            saveFile->DefaultExt = _T("log");
            saveFile->Filter = GUI_FILE_SPEC_LOG;
            break;
        case GUI_FILE_TYPE_DAT :                                                // 4
            saveFile->DefaultExt = _T("dat");
            saveFile->Filter = GUI_FILE_SPEC_DAT;
            break;
        case GUI_FILE_TYPE_HEX_NATIVE_REF :                                     // 5
            saveFile->DefaultExt = _T("hex");
            saveFile->Filter = GUI_FILE_SPEC_HEX_NATIVE_REF;
            break;
        case GUI_FILE_TYPE_HEX_NATIVE_ALL :                                     // 6
            saveFile->DefaultExt = _T("hex");
            saveFile->Filter = GUI_FILE_SPEC_HEX_NATIVE_ALL;
            break;
        case GUI_FILE_TYPE_NATIVE_REF :                                         // 7
            saveFile->DefaultExt = _T("crf");
            saveFile->Filter = GUI_FILE_SPEC_NATIVE_REF;
            break;
        case GUI_FILE_TYPE_CSV :                                                // 8
            saveFile->DefaultExt = _T("csv");
            saveFile->Filter = GUI_FILE_SPEC_CSV;
            break;
        case GUI_FILE_TYPE_CONFIG :                                             // 9
            saveFile->DefaultExt = _T("config");
            saveFile->Filter = GUI_FILE_SPEC_CONFIG;
            break;
        case GUI_FILE_TYPE_BIN :                                                // 10
            saveFile->DefaultExt = _T("bin");
            saveFile->Filter = GUI_FILE_SPEC_BIN;
            break;
        case GUI_FILE_TYPE_EXE :                                                // 11
            saveFile->DefaultExt = _T("exe");
            saveFile->Filter = GUI_FILE_SPEC_EXE;
            break;
        case GUI_FILE_TYPE_ZIP :                                                // 12
            saveFile->DefaultExt = _T("zip");
            saveFile->Filter = GUI_FILE_SPEC_ZIP;
            break;
        case GUI_FILE_TYPE_DLL :                                                // 13
            saveFile->DefaultExt = _T("dll");
            saveFile->Filter = GUI_FILE_SPEC_DLL;
            break;
        case GUI_FILE_TYPE_LOG_CSV :                                            // 14
            saveFile->DefaultExt = _T("log");
            saveFile->Filter = GUI_FILE_SPEC_LOG_CSV;
            break;
        case GUI_FILE_TYPE_COF2 :                                               // 15
            saveFile->DefaultExt = _T("cof2");
            saveFile->Filter = GUI_FILE_SPEC_COF2;
            break;
        case GUI_FILE_TYPE_PNG :                                                // 16
            saveFile->DefaultExt = _T("png");
            saveFile->Filter = GUI_FILE_SPEC_PNG;
            break;
        case GUI_FILE_TYPE_PDF :                                                // 17
            saveFile->DefaultExt = _T("pdf");
            saveFile->Filter = GUI_FILE_SPEC_PDF;
            break;
        case GUI_FILE_TYPE_UNKNOWN :                                            // 0
        default :
            if (StringSet(saveFile->FileName))
                saveFile->FileName = _T("*.*");
            else
                saveFile->DefaultExt = _T("*");
            saveFile->Filter = GUI_FILE_SPEC_ALL;
            break;
    }                                   // end of switch (fileType)
    if (StringSet(saveFile->FileName))
        saveFile->FileName = Path::GetFileNameWithoutExtension(saveFile->FileName);
    saveFile->FilterIndex = 1;          // 1 == specified / 2 == *.*
    saveFile->RestoreDirectory = GUI_YES;
    //------------------------------------------------------------------------
    // The following line works around issues with Windows 7 and Vista
    //------------------------------------------------------------------------
    saveFile->AutoUpgradeEnabled = GUI_NO;
    //------------------------------------------------------------------------
    // Display the window and query the user
    //------------------------------------------------------------------------
    if (saveFile->ShowDialog() == System::Windows::Forms::DialogResult::OK)
    {
        promptResult = GUI_ACCEPT;
        filePathBuilder->Length = QCOM_MAXIMUM_FILE_PATH_LENGTH;
        GUI_StringToBuilder(saveFile->FileName, filePathBuilder);
        filePathString = filePathBuilder->ToString();
        QCOM_SetGeneralUsePath(filePathString);
        //--------------------------------------------------------------------
        // The next two lines are somewhat controversial. They are needed when
        // the user wants to feel certain that the selected file has actually
        // been saved, and not just selected. But that really should be the
        // responsibility of the calling routine. Also, saving the file marks
        // the folder with a filename as a placeholder.
        //--------------------------------------------------------------------
        FileStream ^fileStream = File::Create(filePathString);
        fileStream->Close();
        RecordBasicEvent(
            "    Prompt for output file accepted: {0}",
            saveFile->FileName);
    }
    else
    {
        promptResult = GUI_CANCEL;
    }
    delete saveFile;
//    QCOM_ResumeElapsedTime();
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (promptResult ? "Yes" : "No"));
    return promptResult;
}                                       // end of QCOM_PromptForSaveFile()
//----------------------------------------------------------------------------
// QCOM_PromptInputModal
//
// Displays a text box input modal with a single-line prompt field that is at
// most maximumInputStringSize characters (or digits) long
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_PromptInputModal(
    String          ^titleString,
    String          ^suggestedInputString,
    DWORD           *inputValue,
    StringBuilder   ^inputStringBuilder,
    DWORD           maximumInputStringSize,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    bool            modalResponse = GUI_CANCEL;
    int             buttonWidth = GUI_YES_NO_BUTTON_WIDTH;
    int             lines = 0;
    int             promptWidth = 0;
    int             titleWidth;
    String          ^functionName = _T("QCOM_PromptInputModal");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(formatString))
    {
//        QCOM_PauseElapsedTime();
        String ^promptString = String::Format(formatString, parameters);
        //--------------------------------------------------------------------
        // Create a new window
        //--------------------------------------------------------------------
        Form ^inputModal = gcnew Form;
        //--------------------------------------------------------------------
        // Set the title
        //--------------------------------------------------------------------
        if (StringSet(titleString))
        {
            inputModal->Text = titleString;
            titleWidth = QCOM_StringWidth(titleString);
        }
        else
        {
            inputModal->Text = _T("QCOM");
        }
        //--------------------------------------------------------------------
        // Set its properties
        //--------------------------------------------------------------------
        inputModal->Icon = QCOM_SoftwareIcon;
        inputModal->BackgroundImage = gcnew Bitmap(GUI_BG_WOOD_PANEL, GUI_YES);
        inputModal->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
        inputModal->StartPosition = FormStartPosition::CenterScreen;
        inputModal->TopMost = GUI_YES;
        //--------------------------------------------------------------------
        // Prevent the user from changing its appearance
        //--------------------------------------------------------------------
        inputModal->MaximizeBox = GUI_NO;
        inputModal->MinimizeBox = GUI_NO;
        inputModal->HelpButton = GUI_NO;
        //--------------------------------------------------------------------
        // If this is a multi-line prompt, find the number of lines and the
        // width of the longest line
        //--------------------------------------------------------------------
        promptString = promptString->Replace(Environment::NewLine, QCOM_STRING_LF);
        array <Char> ^lineDelimiters = gcnew array <Char> {QCOM_CHAR_CR, QCOM_CHAR_LF};
        array <String ^> ^promptLines = promptString->Split(lineDelimiters);
        lines = promptLines->Length;
        for each (String ^promptLine in promptLines)
        {
            promptWidth = Max(promptWidth, (int) QCOM_StringWidth(promptLine) + (promptLine->Length / 2));
            Label ^modalMessage = gcnew Label;
            modalMessage->Location = Point(
                10,
                ((Array::IndexOf(promptLines, promptLine) * GUI_PROMPT_LABEL_HEIGHT) + 10));
            modalMessage->Size = Drawing::Size(
                promptWidth,
                GUI_PROMPT_LABEL_HEIGHT);
            modalMessage->TextAlign = Drawing::ContentAlignment::MiddleLeft;
            modalMessage->Text = promptLine;
            modalMessage->ForeColor = Color::Black;
            modalMessage->BackColor = Color::Transparent;
            inputModal->Controls->Add(modalMessage);
            promptWidth = Max(promptWidth, modalMessage->Width);
        }
        delete [] promptLines;
        delete [] lineDelimiters;
        inputModal->Size = Drawing::Size(
            Max(Max((promptWidth + 25), (titleWidth + 100)), 280),
            (lines * GUI_PROMPT_LABEL_HEIGHT) + 85);
        //--------------------------------------------------------------------
        // Create the input text box
        //--------------------------------------------------------------------
        TextBox ^inputTextBox = gcnew TextBox;
        inputTextBox->Size = Drawing::Size(60, 20);
        inputTextBox->Location = Point(
            ((inputModal->Width / 2) - 50),
            inputModal->Height - 62);
        inputTextBox->Multiline = GUI_NO;
        inputTextBox->AcceptsReturn = GUI_NO;
        inputTextBox->AcceptsTab = GUI_NO;
        inputTextBox->WordWrap = GUI_NO;
        inputTextBox->ReadOnly = GUI_NO;
        inputTextBox->MaxLength = maximumInputStringSize;
        inputTextBox->TextAlign = HorizontalAlignment::Center;
        inputTextBox->BackColor = Color::White;
        if (StringSet(suggestedInputString))
            inputTextBox->Text = suggestedInputString;
        inputModal->Controls->Add(inputTextBox);
        //--------------------------------------------------------------------
        // Display the OK button to accept the input
        //--------------------------------------------------------------------
        Button ^okButton = gcnew Button;
        okButton->Text = _T("OK");
        okButton->Location = Point(
            inputTextBox->Right + 10,
            inputTextBox->Top - 2);
        okButton->Size = Drawing::Size(buttonWidth, GUI_REGULAR_BUTTON_HEIGHT);
        okButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
        okButton->DialogResult = Windows::Forms::DialogResult::OK;
        GUI_SetObjectInterfaceProperties(okButton);
        okButton->KeyPress +=
            gcnew KeyPressEventHandler(this, &QCOM_GUIClass::QCOM_PromptKeyPressed);
        inputModal->AcceptButton = okButton;     // button when user presses Enter
        inputModal->Controls->Add(okButton);
        //--------------------------------------------------------------------
        // Display the Cancel button to accept the input
        //--------------------------------------------------------------------
        Button ^cancelButton = gcnew Button;
        cancelButton->Text = _T("Cancel");
        cancelButton->Location = Point(inputModal->Width - 70, okButton->Top);
        cancelButton->Size = Drawing::Size(50, GUI_REGULAR_BUTTON_HEIGHT);
        cancelButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
        cancelButton->DialogResult = Windows::Forms::DialogResult::Cancel;
        GUI_SetObjectInterfaceProperties(cancelButton);
        cancelButton->KeyPress +=
            gcnew KeyPressEventHandler(this, &QCOM_GUIClass::QCOM_PromptKeyPressed);
        inputModal->CancelButton = cancelButton;     // button when user presses Esc
        inputModal->Controls->Add(cancelButton);
        //--------------------------------------------------------------------
        // Display the window and query the user
        //--------------------------------------------------------------------
        QCOM_ModalKeyStroke = 0;
        inputModal->ShowDialog();
        if (QCOM_ModalKeyStroke != GUI_KEY_ESC)
        {
            if ((QCOM_ModalKeyStroke == 'Y') || (QCOM_ModalKeyStroke == 'N'))
            {
                //------------------------------------------------------------
                // A recognized key was pressed that was not Enter, Esc, or Space
                //------------------------------------------------------------
                if (QCOM_ModalKeyStroke == 'Y')
                    modalResponse = GUI_ACCEPT;
                else
                    modalResponse = GUI_CANCEL;
            }
            else
            {
                //------------------------------------------------------------
                // A button was clicked, or Enter, Esc, or Space was pressed
                //------------------------------------------------------------
                if (inputModal->DialogResult == Windows::Forms::DialogResult::OK)
                    modalResponse = GUI_ACCEPT;
                else
                    modalResponse = GUI_CANCEL;
                if (modalResponse == GUI_CANCEL)
                    QCOM_ModalKeyStroke = GUI_KEY_ESC;
            }
            if (modalResponse == GUI_ACCEPT)
            {
                bool isCorrectFormat = QCOM_ParseAndConvertStringToUnsigned(
                    inputTextBox->Text,
                    inputValue);
                if (isCorrectFormat)
                {
                    inputStringBuilder->Length = maximumInputStringSize;
                    GUI_StringToBuilder(inputTextBox->Text, inputStringBuilder);
                }
                else
                {
                    QCOM_PromptOKModal(
                        "Invalid Characters",
                        "The entry contains invalid characters;\n"
                        "enter only decimal digits");
                    RecordErrorEvent(
                        "    Attempted entry of '{0}'",
                        inputTextBox->Text);
                    modalResponse = GUI_CANCEL;
                }
                RecordBasicEvent(
                    "Prompt for Input with title '{0}' and text\n'{1}'\nresulted in '{2}'",
                    titleString,
                    promptString,
                    ((modalResponse == GUI_ACCEPT) ? inputTextBox->Text : cancelButton->Text));
            }
            else
            {
                RecordBasicEvent(
                    "Prompt for Input with title '{0}' and text\n'{1}'\nresulted in '{2}'",
                    titleString,
                    promptString,
                    cancelButton->Text);
            }
        }                               // end of if (QCOM_ModalKeyStroke != GUI_KEY_ESC)
        //--------------------------------------------------------------------
        // Dispose of the window components
        //--------------------------------------------------------------------
        delete inputModal;
        this->Refresh();
        delete promptString;
//        QCOM_ResumeElapsedTime();
    }                                   // end of if (StringSet(formatString))
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (modalResponse ? "Accept" : "Cancel"));
    return modalResponse;
}                                       // end of QCOM_PromptInputModal()
//----------------------------------------------------------------------------
// QCOM_PromptPulldownModal
//
// Displays a combo box (pulldown) input modal with a list that is at most
// maximumPulldownListSize lines long, and returns the offset of the selected
// list line
//
// Returns: GUI_ACCEPT or GUI_CANCEL
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_PromptPulldownModal(
    String          ^titleString,
    array <String ^>
                    ^pulldownList,
    DWORD           *listOffset,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    bool            modalResponse = GUI_CANCEL;
    int             buttonWidth = GUI_YES_NO_BUTTON_WIDTH;
    int             lines = 0;
    int             promptWidth = 0;
    int             pulldownListWidth = 0;
    DWORD           titleWidth;
    String          ^functionName = _T("QCOM_PromptPulldownModal");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
//    QCOM_PauseElapsedTime();
    if (StringSet(formatString))
    {
        String ^promptString = String::Format(formatString, parameters);
        //--------------------------------------------------------------------
        // Create a new window
        //--------------------------------------------------------------------
        Form ^promptPulldownModal = gcnew Form;
        //--------------------------------------------------------------------
        // Set the title
        //--------------------------------------------------------------------
        if (StringSet(titleString))
        {
            promptPulldownModal->Text = titleString;
            titleWidth = QCOM_StringWidth(titleString);
        }
        else
        {
            promptPulldownModal->Text = _T("QCOM");
        }
        //--------------------------------------------------------------------
        // Set its properties
        //--------------------------------------------------------------------
        promptPulldownModal->Icon = QCOM_SoftwareIcon;
        promptPulldownModal->BackgroundImage = gcnew Bitmap(GUI_BG_WOOD_PANEL, GUI_YES);
        promptPulldownModal->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
        promptPulldownModal->StartPosition = FormStartPosition::CenterScreen;
        promptPulldownModal->TopMost = GUI_YES;
        //--------------------------------------------------------------------
        // Prevent the user from changing its appearance
        //--------------------------------------------------------------------
        promptPulldownModal->MaximizeBox = GUI_NO;
        promptPulldownModal->MinimizeBox = GUI_NO;
        promptPulldownModal->HelpButton = GUI_NO;
        //--------------------------------------------------------------------
        // If this is a multi-line prompt, find the number of lines and the
        // width of the longest line
        //--------------------------------------------------------------------
        promptString = promptString->Replace(Environment::NewLine, QCOM_STRING_LF);
        array <Char> ^lineDelimiters = gcnew array <Char> {QCOM_CHAR_CR, QCOM_CHAR_LF};
        array <String ^> ^promptLines = promptString->Split(lineDelimiters);
        lines = promptLines->Length;
        for each (String ^promptLine in promptLines)
        {
            promptWidth = Max(promptWidth, (int) QCOM_StringWidth(promptLine) + (promptLine->Length / 2));
            Label ^modalMessage = gcnew Label;
            modalMessage->Location = Point(
                10,
                ((Array::IndexOf(promptLines, promptLine) * GUI_PROMPT_LABEL_HEIGHT) + 10));
            modalMessage->Size = Drawing::Size(
                promptWidth,
                GUI_PROMPT_LABEL_HEIGHT);
            modalMessage->TextAlign = Drawing::ContentAlignment::MiddleLeft;
            modalMessage->Text = promptLine;
            modalMessage->ForeColor = Color::Black;
            modalMessage->BackColor = Color::Transparent;
            promptPulldownModal->Controls->Add(modalMessage);
            promptWidth = Max(promptWidth, modalMessage->Width);
        }
        delete [] promptLines;
        delete [] lineDelimiters;
        //--------------------------------------------------------------------
        // Create the pulldown combo box
        //--------------------------------------------------------------------
        Drawing::Font ^currentFont = gcnew Drawing::Font(this->Font, FontStyle::Regular);
        for each (String ^pulldownEntry in pulldownList)
        {
            Drawing::Size ^numberOfPixels = Drawing::Size(
                TextRenderer::MeasureText(pulldownEntry, currentFont));
            pulldownListWidth = Max(pulldownListWidth, numberOfPixels->Width);
        }
        promptPulldownModal->Width = Max(
            (DWORD) promptPulldownModal->Width,
            (DWORD) (pulldownListWidth + buttonWidth + 120));
        delete currentFont;
        ComboBox ^inputComboBox = gcnew ComboBox;
        inputComboBox->Size = Drawing::Size(
            pulldownListWidth + 20,
            GUI_REGULAR_COMBO_BOX_HEIGHT);
        inputComboBox->Location = Point(
            10,
            promptPulldownModal->Height - 62);
        inputComboBox->MaxDropDownItems = 12;
        inputComboBox->FormattingEnabled = GUI_YES;
        inputComboBox->Items->AddRange(pulldownList);
        inputComboBox->Text = pulldownList[*listOffset];
        promptPulldownModal->Controls->Add(inputComboBox);
        //--------------------------------------------------------------------
        // Display the OK button to accept the input
        //--------------------------------------------------------------------
        Button ^okButton = gcnew Button;
        okButton->Text = _T("OK");
        okButton->Location = Point(
            inputComboBox->Right + 10,
            inputComboBox->Top - 2);
        okButton->Size = Drawing::Size(buttonWidth, GUI_REGULAR_BUTTON_HEIGHT);
        okButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
        okButton->DialogResult = Windows::Forms::DialogResult::OK;
        GUI_SetObjectInterfaceProperties(okButton);
        okButton->KeyPress +=
            gcnew KeyPressEventHandler(this, &QCOM_GUIClass::QCOM_PromptKeyPressed);
        promptPulldownModal->AcceptButton = okButton;     // button when user presses Enter
        promptPulldownModal->Controls->Add(okButton);
        //--------------------------------------------------------------------
        // Display the Cancel button to accept the input
        //--------------------------------------------------------------------
        Button ^cancelButton = gcnew Button;
        cancelButton->Text = _T("Cancel");
        cancelButton->Location = Point(
            promptPulldownModal->Width - 70,
            okButton->Top);
        cancelButton->Size = Drawing::Size(50, GUI_REGULAR_BUTTON_HEIGHT);
        cancelButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
        cancelButton->DialogResult = Windows::Forms::DialogResult::Cancel;
        cancelButton->KeyPress +=
            gcnew KeyPressEventHandler(this, &QCOM_GUIClass::QCOM_PromptKeyPressed);
        promptPulldownModal->CancelButton = cancelButton;     // button when user presses Esc
        promptPulldownModal->Controls->Add(cancelButton);
        //--------------------------------------------------------------------
        // Display the window and query the user
        //--------------------------------------------------------------------
        QCOM_ModalKeyStroke = 0;
        promptPulldownModal->ShowDialog();
        if (QCOM_ModalKeyStroke != GUI_KEY_ESC)
        {
            if (promptPulldownModal->DialogResult == Windows::Forms::DialogResult::OK)
                modalResponse = GUI_ACCEPT;
            else
                modalResponse = GUI_CANCEL;
            if (modalResponse == GUI_ACCEPT)
            {
                if (inputComboBox->SelectedIndex && (inputComboBox->SelectedIndex != -1))
                {
                    *listOffset = inputComboBox->SelectedIndex;
                }
            }
        }                               // end of else of if (QCOM_ModalKeyStroke != GUI_KEY_ESC)
        RecordBasicEvent(
            "Prompt Pulldown with title '{0}' and text\n'{1}'\nresulted in '{2}'",
            titleString,
            promptString,
            ((modalResponse == GUI_ACCEPT) ? pulldownList[*listOffset] : cancelButton->Text));
        //--------------------------------------------------------------------
        // Dispose of the window components
        //--------------------------------------------------------------------
        delete promptPulldownModal;
        this->Refresh();
        delete promptString;
    }                                   // end of if (StringSet(formatString))
//    QCOM_ResumeElapsedTime();
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (modalResponse ? "Accept" : "Cancel"));
    return modalResponse;
}                                       // end of QCOM_PromptPulldownModal()
//----------------------------------------------------------------------------
// QCOM_PromptYesNoModal
//
// Displays a Yes / No modal with a single prompt line
//
// Returns: GUI_YES or GUI_NO
//
// Note:    If the user presses Enter, the 'Yes' button will be accepted; if
//          the user presses Esc, the 'No' button will be accepted
//
// Note:    If either yesText or noText is NULL, only the 'OK' button will be
//          displayed
//
// Note:    If yesText is a zero-length string, the OK button will be
//          displayed as 'Yes' and if noText is a zero-length string,
//          Cancel button will be displayed as 'No'
//----------------------------------------------------------------------------
    bool QCOM_GUIClass::
QCOM_PromptYesNoModal(
    String          ^titleString,
    String          ^yesText,
    String          ^noText,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    bool            modalResponse = GUI_NO; // defaults to a 'No' response
    int             buttonCenter;
    int             buttonWidth = GUI_YES_NO_BUTTON_WIDTH;
    int             lines = 0;
    int             promptWidth = 0;
    int             titleWidth;
    char            *nextLine = (char *) 0;
    DWORD           textWidth;
    Button          ^noButton;
    Button          ^okButton;
    Button          ^yesButton;
    String          ^responseButton;
    String          ^functionName = _T("QCOM_PromptYesNoModal");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(formatString))
    {
        String ^promptString = String::Format(formatString, parameters);
        //--------------------------------------------------------------------
        // Create a new window
        //--------------------------------------------------------------------
        Form ^promptYNModal = gcnew Form;
        //--------------------------------------------------------------------
        // Set the title
        //--------------------------------------------------------------------
        if (StringSet(titleString))
        {
            promptYNModal->Text = titleString;
            titleWidth = QCOM_StringWidth(titleString);
        }
        else
        {
            promptYNModal->Text = _T("QCOM");
        }
        //--------------------------------------------------------------------
        // Set its properties
        //--------------------------------------------------------------------
        promptYNModal->Icon = QCOM_SoftwareIcon;
        promptYNModal->BackgroundImage = gcnew Bitmap(GUI_BG_WOOD_PANEL, GUI_YES);
        promptYNModal->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
        promptYNModal->StartPosition = FormStartPosition::CenterScreen;
        promptYNModal->TopMost = GUI_YES;
        //--------------------------------------------------------------------
        // Prevent the user from changing its appearance
        //--------------------------------------------------------------------
        promptYNModal->MaximizeBox = GUI_NO;
        promptYNModal->MinimizeBox = GUI_NO;
        promptYNModal->HelpButton = GUI_NO;
        //--------------------------------------------------------------------
        // If this is a multi-line prompt, find the number of lines and the
        // width of the longest line
        //--------------------------------------------------------------------
        promptString = promptString->Replace(Environment::NewLine, QCOM_STRING_LF);
        array <Char> ^lineDelimiters = gcnew array <Char> {QCOM_CHAR_CR, QCOM_CHAR_LF};
        array <String ^> ^promptLines = promptString->Split(lineDelimiters);
        lines = promptLines->Length;
        for each (String ^promptLine in promptLines)
        {
            promptWidth = Max(promptWidth, (int) QCOM_StringWidth(promptLine) + (promptLine->Length / 2));
            Label ^modalMessage = gcnew Label;
            modalMessage->Location = Point(
                10,
                ((Array::IndexOf(promptLines, promptLine) * GUI_PROMPT_LABEL_HEIGHT) + 10));
            modalMessage->Size = Drawing::Size(
                promptWidth,
                GUI_PROMPT_LABEL_HEIGHT);
            modalMessage->TextAlign = Drawing::ContentAlignment::MiddleLeft;
            modalMessage->Text = promptLine;
            modalMessage->ForeColor = Color::Black;
            modalMessage->BackColor = Color::Transparent;
            promptYNModal->Controls->Add(modalMessage);
            promptWidth = Max(promptWidth, modalMessage->Width);
        }
        delete [] promptLines;
        delete [] lineDelimiters;
        promptYNModal->Size = Drawing::Size(
            Max((promptWidth + 25), (titleWidth + 100)),
            (lines * GUI_PROMPT_LABEL_HEIGHT) + 85);
        if (yesText && noText)
        {
            //----------------------------------------------------------------
            // Create the 'Yes' and 'No' buttons
            //----------------------------------------------------------------
            if (String::IsNullOrEmpty(yesText))
                yesText = _T("Yes");
            if (String::IsNullOrEmpty(noText))
                noText = _T("No");
            textWidth = Max(QCOM_StringWidth(yesText), QCOM_StringWidth(noText));
            if (textWidth > 25)
                buttonWidth += (textWidth - 25);
            buttonCenter = Max((promptYNModal->Width / 4), buttonWidth);
            promptYNModal->Width = Max(promptYNModal->Width, (buttonCenter * 4));
            yesButton = gcnew Button;
            yesButton->Text = yesText;
            yesButton->Tag = 1;
            yesButton->Location = Point(
                (buttonCenter - (buttonWidth / 2)),
                promptYNModal->Height - 65);
            yesButton->Size = Drawing::Size(buttonWidth, GUI_REGULAR_BUTTON_HEIGHT);
            yesButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
            yesButton->DialogResult = Windows::Forms::DialogResult::OK;
            GUI_SetObjectInterfaceProperties(yesButton);
            yesButton->KeyPress +=
                gcnew KeyPressEventHandler(this, &QCOM_GUIClass::QCOM_PromptKeyPressed);
            noButton = gcnew Button;
            noButton->Text = noText;
            noButton->Location = Point(
                (promptYNModal->Width - yesButton->Left - buttonWidth),
                yesButton->Top);
            noButton->Size = yesButton->Size;
            noButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
            noButton->DialogResult = Windows::Forms::DialogResult::Cancel;
            GUI_SetObjectInterfaceProperties(noButton);
            noButton->KeyPress +=
                gcnew KeyPressEventHandler(this, &QCOM_GUIClass::QCOM_PromptKeyPressed);
            //----------------------------------------------------------------
            // Relate the buttons to the window
            //----------------------------------------------------------------
            promptYNModal->AcceptButton = yesButton;    // button when user presses Enter
            array <Button ^> ^modalButtons =
            {
                yesButton,
                noButton
            };
            promptYNModal->Controls->AddRange(modalButtons);
        }                               // end of if (yesText && noText)
        else
        {
            okButton = gcnew Button;
            okButton->Text = _T("OK");
            okButton->Location = Point(
                (promptYNModal->Width - okButton->Width - 15),
                promptYNModal->Height - 65);
            okButton->Size = Drawing::Size(buttonWidth, GUI_REGULAR_BUTTON_HEIGHT);
            okButton->BackgroundImage = gcnew Bitmap(GUI_BG_SAND, GUI_YES);
            okButton->DialogResult = Windows::Forms::DialogResult::OK;
            GUI_SetObjectInterfaceProperties(okButton);
            okButton->KeyPress +=
                gcnew KeyPressEventHandler(this, &QCOM_GUIClass::QCOM_PromptKeyPressed);
            promptYNModal->AcceptButton = okButton;     // button when user presses Enter
            promptYNModal->Controls->Add(okButton);
            //----------------------------------------------------------------
            // Create but miniaturize the Cancel button to accept the Esc key
            //----------------------------------------------------------------
            Button ^cancelButton = gcnew Button;
            cancelButton->Location = Point(okButton->Left, okButton->Top);
            cancelButton->Size = Drawing::Size(1, 1);
            cancelButton->DialogResult = Windows::Forms::DialogResult::Cancel;
            cancelButton->KeyPress +=
                gcnew KeyPressEventHandler(this, &QCOM_GUIClass::QCOM_PromptKeyPressed);
            promptYNModal->CancelButton = cancelButton;     // button when user presses Esc
            promptYNModal->Controls->Add(cancelButton);
        }
        //--------------------------------------------------------------------
        // Display the window and query the user
        //--------------------------------------------------------------------
        QCOM_PauseElapsedTime();
        QCOM_ModalKeyStroke = 0;
        promptYNModal->ShowDialog();
        QCOM_ResumeElapsedTime();
        if (QCOM_ModalKeyStroke == GUI_KEY_ESC)
        {
            responseButton = _T("Esc");
        }
        else
        {
            if ((QCOM_ModalKeyStroke == 'Y') || (QCOM_ModalKeyStroke == 'N'))
            {
                //----------------------------------------------------------------
                // A recognized key was pressed that was not Enter
                //----------------------------------------------------------------
                if (QCOM_ModalKeyStroke == 'Y')
                    modalResponse = GUI_ACCEPT;
                else
                    modalResponse = GUI_CANCEL;
            }
            else
            {
                //----------------------------------------------------------------
                // A button was clicked, or Enter was pressed
                //----------------------------------------------------------------
                if (promptYNModal->DialogResult == Windows::Forms::DialogResult::OK)
                    modalResponse = GUI_ACCEPT;
                else
                    modalResponse = GUI_CANCEL;
            }
            if (yesText && noText)
            {
                if (modalResponse == GUI_ACCEPT)
                    responseButton = yesButton->Text;
                else
                    responseButton = noButton->Text;
            }
            else
            {
                if (modalResponse == GUI_ACCEPT)
                    responseButton = okButton->Text;
                else
                    responseButton = _T("Esc");
            }
        }                               // end of else of if (QCOM_ModalKeyStroke == GUI_KEY_ESC)
        RecordBasicEvent(
            "Prompt Y/N with title '{0}' and text\n'{1}'\nresulted in '{2}'",
            titleString,
            promptString,
            responseButton);
        //--------------------------------------------------------------------
        // Dispose of the window components
        //--------------------------------------------------------------------
        delete promptYNModal;
        this->Refresh();
        delete promptString;
    }                                   // end of if (StringSet(formatString))
    RecordBasicEvent("{0} concluded, returning {1}",
        functionName, (modalResponse ? "Accept" : "Cancel"));
    return modalResponse;
}                                       // end of QCOM_PromptYesNoModal()
//----------------------------------------------------------------------------
// QCOM_RecordAndModalErrorEvent
//
// Records the message as an error event, then prompts the user with the same
// message
//
// Note:    The Error Log will be updated with the formatted message string if
//          the log file exists, regardless of any other flag setting, but the
//          Event Log will be updated with the message only if one or more of
//          the event log flags is enabled, and the modal dialog will be
//          displayed only if the global error messages flag is enabled
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_RecordAndModalErrorEvent(
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    //------------------------------------------------------------------------
    if (StringSet(formatString))
    {
        String ^formattedString = String::Format(formatString, parameters);
        RecordErrorEvent(formattedString);
        QCOM_UpdateErrorLog(formattedString);
        ModalE(formattedString);
        delete formattedString;
    }
}                                       // end of QCOM_RecordAndModalErrorEvent()
//----------------------------------------------------------------------------
// QCOM_RecordAndModalEventByFlags
//
// Records the message as an event if the event flag is set, then prompts the
// user with the same message, if the message flag is set
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_RecordAndModalEventByFlags(
    bool            eventFlag,
    bool            messageFlag,
    String          ^sourceFunction,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    //------------------------------------------------------------------------
    if ((eventFlag || messageFlag) && StringSet(formatString))
    {
        String ^formattedString = String::Format(formatString, parameters);
        QCOM_RecordEvent(
            eventFlag,
            String::Format(
                "{0} :\n{1}", sourceFunction, formattedString));
        if (messageFlag)
            QCOM_PromptOKModal(sourceFunction, formattedString);
        delete formattedString;
    }
}                                       // end of QCOM_RecordAndModalEventByFlags()
//----------------------------------------------------------------------------
// QCOM_ResumeElapsedTime
//
// Resumes activities that record the passing of time
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ResumeElapsedTime(void)
{
    int             lapsedDays;
    int             lapsedHours;
    int             lapsedMinutes;
    int             lapsedSeconds;
    int             lapsedMilliseconds;
    DWORD           currentTime = GetTickCount();
    DWORD           pausedTimeElapsed = currentTime - QCOM_PauseTime;
    UnitInfo        ^unit;
    String          ^functionName = _T("QCOM_ResumeElapsedTime");
    //------------------------------------------------------------------------
    RecordDetailedEvent("{0} called", functionName);
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED)
    {
        QCOM_TimeElapsed(
            pausedTimeElapsed,
            &lapsedDays,
            &lapsedHours,
            &lapsedMinutes,
            &lapsedSeconds,
            &lapsedMilliseconds);
        if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
        {
            QCOM_SamplingStartTime += pausedTimeElapsed;
            samplingTimer->Start();
        }
        if (QCOM_GeneralInfo->logFlags & QCOM_GENERAL_LOG_CURRENTLY_LOGGING)
            QCOM_LoggingStartTime += pausedTimeElapsed;
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                unit = QCOM_UnitInfoArray[unitNumber];
                if (unit->dataLogFlags & QCOM_UNIT_LOG_CURRENTLY_LOGGING)
                {
                    unit->loggingStats->startTime += pausedTimeElapsed;
                }
                if (unit->testFlags & QCOM_UNIT_TEST_CURRENTLY_TESTING)
                {
                    unit->testingStats->startTime += pausedTimeElapsed;
                }
            }
        }
        RecordDetailedEvent("    Program was paused for {0:D} d {1:D} h {2:D} m {3:D} s",
            lapsedDays, lapsedHours, lapsedMinutes, lapsedSeconds);
        QCOM_PauseTime = 0;
        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_PROGRAM_PAUSED;
        QCOM_StopPausedBlinker();
    }                                   // end of if (QCOM_GeneralInfo->flags & QCOM_GENERAL_PROGRAM_PAUSED)
    RecordDetailedEvent("{0} concluded", functionName);
}                                       // end of QCOM_ResumeElapsedTime()
//----------------------------------------------------------------------------
// QCOM_SaveBinaryData
//
// Saves the specified array of Bytes to the specified binary file
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SaveBinaryData(
    array <Byte>    ^binaryData,
    String          ^binaryFileName)
{
    BinaryWriter    ^writeStream;
    String          ^functionName = _T("QCOM_SaveBinaryData");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(binaryData) && StringSet(binaryFileName))
    {
        if (File::Exists(binaryFileName))
            File::Delete(binaryFileName);
        writeStream = WriteBinary(binaryFileName);
        if (writeStream)
        {
            writeStream->Write(binaryData);
            writeStream->Close();
            delete writeStream;
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_SaveBinaryData()
//----------------------------------------------------------------------------
// QCOM_SendEmailMessage
//
// Sends an email with the specified subject and message
//
// Returns: 0           Success
//          nonzero     Failure
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_SendEmailMessage(
    String          ^emailSubjectString,
    String          ^emailMessageString)
{
    DWORD           status = QCOM_SUCCESS;
    String          ^functionName = _T("QCOM_SendEmailMessage");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(QCOM_GeneralInfo->emailMessageToAddress))
    {
        if (StringSet(emailSubjectString) && StringSet(emailMessageString))
        {
            EmailInfo ^emailInfo = gcnew EmailInfo;
            emailInfo->subjectString = emailSubjectString;
            emailInfo->messageString = emailMessageString;
            MailMessage ^emailMessage = gcnew MailMessage;
            emailMessage->From = gcnew MailAddress(QCOM_EMAIL_MESSAGE_SOURCE);
            MailAddress ^toAddress = gcnew MailAddress(QCOM_GeneralInfo->emailMessageToAddress);
            emailMessage->To->Add(toAddress);
            delete toAddress;
            if (StringSet(QCOM_GeneralInfo->emailMessageCCAddress))
            {
                MailAddress ^ccAddress = gcnew MailAddress(QCOM_GeneralInfo->emailMessageCCAddress);
                emailMessage->CC->Add(ccAddress);
                delete ccAddress;
            }
            if (StringSet(emailInfo->messageString))
            {
                emailMessage->Body = emailInfo->messageString->Trim();
                emailMessage->BodyEncoding = Encoding::UTF8;
            }
            else
            {
                QCOM_RecordAndModalErrorEvent(
                    "{0} :\nMessage text is absent",
                    functionName);
                status = QCOM_ERROR_EMAIL_MISSING_MESSAGE;                      // 0x00000094
            }
            if (StringSet(emailInfo->subjectString))
            {
                emailMessage->Subject = emailInfo->subjectString->Trim();
                emailMessage->SubjectEncoding = Encoding::UTF8;
            }
            else
            {
                QCOM_RecordAndModalErrorEvent(
                    "{0} :\nSubject text is absent",
                    functionName);
                status = QCOM_ERROR_EMAIL_MISSING_SUBJECT;                      // 0x00000093
            }
            if (status == QCOM_SUCCESS)
            {
                status = QCOM_SendSMTPMail(emailMessage);
            }                           // end of if (status == QCOM_SUCCESS)
            emailMessage->~MailMessage();
            delete emailMessage;
            delete emailInfo;
        }                               // end of if (StringSet(emailSubjectString) && ...)
        else
        {
            if (!StringSet(emailSubjectString))
            {
                QCOM_RecordAndModalErrorEvent(
                    "{0} : No email subject string specified", functionName);
                status = QCOM_ERROR_EMAIL_MISSING_SUBJECT;                      // 0x00000093
            }
            if (!StringSet(emailMessageString))
            {
                QCOM_RecordAndModalErrorEvent(
                    "{0} : No email message string specified", functionName);
                status = QCOM_ERROR_EMAIL_MISSING_MESSAGE;                      // 0x00000094
            }
        }
    }
    else
    {
        QCOM_SendEmailErrorMessagesEnabled = GUI_NO;
        QCOM_UpdateMessageChecks();
        Modal("No email address specified to send message");
        status = QCOM_ERROR_EMAIL_MISSING_COMPONENT;                            // 0x00000092
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of QCOM_SendEmailMessage()
//----------------------------------------------------------------------------
// QCOM_SendEmailMessageStructure
//
// Sends an email using the specified email structure, which is needed for
// sending attachments
//
// Returns: 0           Success
//          nonzero     Failure
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_SendEmailMessageStructure(
    EmailInfo       ^emailInfo)
{
    DWORD           status = QCOM_SUCCESS;
    String          ^carbonAddress;
    String          ^emailAddress;
    String          ^returnAddress;
    String          ^sourceAddress;
    String          ^functionName = _T("QCOM_SendEmailMessageStructure");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (emailInfo && StringSet(emailInfo->toAddress) &&
        StringSet(emailInfo->fromAddress) &&
        StringSet(emailInfo->messageString))
    {
        emailAddress = emailInfo->toAddress;
        sourceAddress = emailInfo->fromAddress;
        //--------------------------------------------------------------------
        // Loosely verify the format of the email address
        //--------------------------------------------------------------------
        if (QCOM_EmailAddressFormatIsValid(emailAddress) &&
            QCOM_EmailAddressFormatIsValid(sourceAddress))
        {
            MailAddress ^toAddress = gcnew MailAddress(emailAddress);
            MailAddress ^fromAddress = gcnew MailAddress(sourceAddress);
            MailMessage ^emailMessage = gcnew MailMessage(fromAddress, toAddress);
            carbonAddress = emailInfo->ccAddress;
            if (StringSet(carbonAddress))
            {
                if (QCOM_EmailAddressFormatIsValid(carbonAddress))
                {
                    MailAddress ^ccAddress = gcnew MailAddress(carbonAddress);
                    emailMessage->CC->Add(ccAddress);
                }
                else
                {
                    QCOM_RecordAndModalErrorEvent(
                        "{0}({1}) :\nEmail CC address '{2}' is invalid",
                        functionName, emailAddress, carbonAddress);
                    status = QCOM_ERROR_INVALID_EMAIL_ADDRESS;                  // 0x00000091
                }
            }
            returnAddress = emailInfo->replyAddress;
            if (StringSet(returnAddress))
            {
                if (QCOM_EmailAddressFormatIsValid(returnAddress))
                {
                    MailAddress ^replyAddress = gcnew MailAddress(returnAddress);
                    emailMessage->ReplyToList->Add(replyAddress);
                }
                else
                {
                    QCOM_RecordAndModalErrorEvent(
                        "{0}({1}) :\nEmail reply address '{2}' is invalid",
                        functionName, emailAddress, returnAddress);
                    status = QCOM_ERROR_INVALID_EMAIL_ADDRESS;                  // 0x00000091
                }
            }
            if (StringSet(emailInfo->messageString))
            {
                emailMessage->Body = emailInfo->messageString->Trim();
                emailMessage->BodyEncoding = Encoding::UTF8;
            }
            else
            {
                QCOM_RecordAndModalErrorEvent(
                    "{0}({1}) :\nMessage text is absent",
                    functionName, emailAddress);
                status = QCOM_ERROR_EMAIL_MISSING_MESSAGE;                      // 0x00000094
            }
            if (StringSet(emailInfo->subjectString))
            {
                emailMessage->Subject = emailInfo->subjectString->Trim();
                emailMessage->SubjectEncoding = Encoding::UTF8;
            }
            else
            {
                QCOM_RecordAndModalErrorEvent(
                    "{0}({1}) :\nSubject text is absent",
                    functionName, emailAddress);
                status = QCOM_ERROR_EMAIL_MISSING_SUBJECT;                      // 0x00000093
            }
            if (status == QCOM_SUCCESS)
            {
                if (StringSet(emailInfo->attachment) || StringSet(emailInfo->attachmentArray))
                {
                    if (StringSet(emailInfo->attachment))
                    {
                        if (File::Exists(emailInfo->attachment))
                        {
                            Attachment ^attachment = gcnew Attachment(
                                emailInfo->attachment, MediaTypeNames::Application::Zip);
                            emailMessage->Attachments->Add(attachment);
                        }
                        else
                        {
                            QCOM_RecordAndModalErrorEvent(
                                "{0}({1}) :\nAttachment {2} could not be found",
                                functionName, emailAddress, emailInfo->attachment);
                            status = QCOM_ERROR_EMAIL_MISSING_ATTACHMENT;       // 0x00000095
                        }
                    }
                    else
                    {
                        for each (String ^attachmentFilePath in emailInfo->attachmentArray)
                        {
                            if (File::Exists(attachmentFilePath))
                            {
                                Attachment ^attachment = gcnew Attachment(
                                    attachmentFilePath, MediaTypeNames::Application::Zip);
                                emailMessage->Attachments->Add(attachment);
                            }
                            else
                            {
                                QCOM_RecordAndModalErrorEvent(
                                    "{0}({1}) :\nAttachment {2} could not be found",
                                    functionName, emailAddress, attachmentFilePath);
                                status = QCOM_ERROR_EMAIL_MISSING_ATTACHMENT;   // 0x00000095
                            }
                        }
                    }
                }                       // end of if (StringSet(emailInfo->attachment) || ...)
                status = QCOM_SendSMTPMail(emailMessage);
            }                           // end of if (status == QCOM_SUCCESS)
            emailMessage->~MailMessage();
            delete emailMessage;
            delete fromAddress;
            delete toAddress;
        }
        else
        {
            QCOM_RecordAndModalErrorEvent(
                "{0}({1}) :\nInvalid email address '{2}'",
                functionName, emailAddress,
                (QCOM_EmailAddressFormatIsValid(emailAddress) ? sourceAddress : emailAddress));
            status = QCOM_ERROR_INVALID_EMAIL_ADDRESS;                          // 0x00000091
        }
    }                                   // end of if (emailInfo && ...)
    else
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} : Nothing to email", functionName);
        status = QCOM_ERROR_EMAIL_MISSING_COMPONENT;                            // 0x00000092
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of QCOM_SendEmailMessageStructure()
//----------------------------------------------------------------------------
// QCOM_SendSMTPMail
//
// Creates and sends the specified mail package via SMTP
//
// Returns: 0           Success
//          nonzero     Failure
//
// Called by:   QCOM_SendEmailMessage
//              QCOM_SendEmailMessageStructure
//              QCOM_SendTextMessage
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_SendSMTPMail(
    MailMessage     ^mailPackage)
{
    int             portNumber = GMAIL_MAIL_SERVER_PORT_NUMBER;                 // 587  // SMTP = 465, IMAP = 993
    DWORD           status = QCOM_SUCCESS;
    String          ^hostName = GMAIL_MAIL_SERVER;
    String          ^primary = QCOM_CREDENTIAL_PRIMARY;
    String          ^secondary = QCOM_CREDENTIAL_SECONDARY;
    String          ^unhashed;
    String          ^functionName = _T("QCOM_SendSMTPMail");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
// The following is for Robert Smallwood only
//
//hostName = _T("ca.smtp.weatherford.com");
//mailPackage->From = gcnew MailAddress(_T("QCOM-reporting.ca.weatherford.com"));
//mailPackage->ReplyToList->Clear();
    unhashed = String::Empty;
    for (int offset = 0; offset < primary->Length; offset++)
    {
        unhashed = String::Concat(
            unhashed, Char::ConvertFromUtf32(primary[offset] - offset + 0x1F));
    }
    primary = unhashed;
    unhashed = String::Empty;
    for (int offset = 0; offset < secondary->Length; offset++)
    {
        unhashed = String::Concat(
            unhashed, Char::ConvertFromUtf32(secondary[offset] - (2 * offset) - 0x01));
    }
    secondary = unhashed;
    //------------------------------------------------------------------------
    // The following works from work:
    //
    // SmtpClient ^client = gcnew SmtpClient("mail.quartzdyne.com", 25);
    // client->UseDefaultCredentials = GUI_YES;
    // client->EnableSsl = GUI_YES;
    //
    // or
    //
    // SmtpClient ^client = gcnew SmtpClient(QUARTZDYNE_EXCHANGE_SERVER);
    //
    // The following works from home:
    //
    // SmtpClient ^client = gcnew SmtpClient("smtp.gmail.com", 587);
    // client->UseDefaultCredentials = GUI_NO;
    // client->Credentials = gcnew NetworkCredential("qcom.notify", "qcom9119");
    //------------------------------------------------------------------------
    SmtpClient ^client = gcnew SmtpClient(hostName, portNumber);
    client->UseDefaultCredentials = GUI_NO;
    client->Credentials = gcnew NetworkCredential(primary, secondary);
    client->EnableSsl = GUI_YES;
    try
    {
        client->Send(mailPackage);
        client->~SmtpClient();
    }
    catch (Exception ^ex)
    {
        QCOM_RecordAndModalErrorEvent(
            "{0} :\nProblem sending mail via host {1} on port {2:D}\nException: {3}",
            functionName, hostName, portNumber,
            ex->ToString());
        status = QCOM_ERROR_EMAIL_FAILED_TO_SEND;                               // 0x00000090
    }
    delete unhashed;
    delete secondary;
    delete primary;
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of QCOM_SendSMTPMail()
//----------------------------------------------------------------------------
// QCOM_SendTextMessage
//
// Sends the specified subject and text as a text message
//
// Returns: 0           Success
//          nonzero     Failure
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_SendTextMessage(
    String          ^textSubjectString,
    String          ^textMessageString)
{
    DWORD           status = QCOM_SUCCESS;
    //------------------------------------------------------------------------
    // This is a list of current SMS gateways, and is constantly in need of
    // update, until I can find a better way to pinpoint the subscription
    // gateway of the target number. A relatively reliable list is updated at
    // http://en.wikipedia.org/wiki/List_of_SMS_gateways
    //------------------------------------------------------------------------
    array <String ^>
                    ^gatewayHostArray =
                        {
                            _T("txt.att.net"),              // AT&T - OK
//                            _T("mms.att.net"),              // AT&T MultiMedia - OK
                            _T("vtext.com"),                // Verizon
                            _T("tmomail.net"),              // T-Mobile
                            _T("messaging.sprintpcs.com"),  // Sprint
                            _T("sms.mycricket.com"),        // Cricket
                            _T("messaging.nextel.com"),     // Nextel - maybe OK
//                            _T("cingularme.com"),           // Cingular - redundant with AT&T
                            _T("vmobl.com"),                // Virgin Mobile - maybe OK
                            _T("message.alltel.com"),       // Alltel
                            _T("myboostmobile.com"),        // Boost Mobile
//                            _T("email.uscc.net"),           // US Cellular - maybe OK
                            _T("sms.thumbcellular.com"),    // Thumb Cellular
//                            _T("tms.suncom.com"),           // SunCom - domain not found
                            _T("ptel.net"),                 // PowerTel - maybe OK
                            _T("MyMetroPCS.com"),           // Metro PCS
                            _T("phone.cellone.net"),        // Cellular One - East Coast - maybe OK
                            _T("mobile.celloneusa.com"),    // Cellular One - USA Other - maybe OK
                            _T("messagealert.com"),         // GTE - maybe OK
                            _T("mci.com"),                  // MCI - maybe OK
                            _T("pacbellpcs.net"),           // Pacific Bell - maybe OK
                            _T("qwestmp.com"),              // Qwest - maybe OK
                            _T("mmst5.tracfone.com"),       // Tracfone - OK
                            _T("mobipcs.net"),              // Mobi PCS - maybe OK
                            _T("pcs.rogers.com"),           // Rogers Canada
                            _T("cellularonewest.com"),      // Western Wireless - maybe OK
                            _T("msg.telus.com"),            // Telus - maybe OK
                            _T("txt.windmobile.ca"),        // Wind Mobile (Canada)
                            _T("sms.xit.net")               // XIT Communications (Texas)
                        };
    String          ^gatewaySection;
    String          ^numberSection;
    String          ^functionName = _T("QCOM_SendTextMessage");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(QCOM_GeneralInfo->textMessageToNumber))
    {
        if (StringSet(textSubjectString) && StringSet(textMessageString))
        {
            EmailInfo ^emailInfo = gcnew EmailInfo;
            emailInfo->subjectString = textSubjectString;
            emailInfo->messageString = textMessageString;
            MailMessage ^textMessage = gcnew MailMessage;
            textMessage->From = gcnew MailAddress(QCOM_TEXT_MESSAGE_SOURCE);
            if (QCOM_GeneralInfo->textMessageToNumber->Contains(QCOM_STRING_AT))
            {
                gatewaySection = QCOM_GeneralInfo->textMessageToNumber->Substring(
                    QCOM_GeneralInfo->textMessageToNumber->IndexOf(QCOM_STRING_AT));
                numberSection = QCOM_GeneralInfo->textMessageToNumber->Substring(
                    0, QCOM_GeneralInfo->textMessageToNumber->IndexOf(QCOM_STRING_AT));
                if (numberSection->Contains(QCOM_STRING_HYPHEN))
                    numberSection = numberSection->Replace(QCOM_STRING_HYPHEN, QCOM_STRING_EMPTY);
                emailInfo->toAddress = String::Concat(numberSection, gatewaySection);
                MailAddress ^toAddress = gcnew MailAddress(emailInfo->toAddress);
                textMessage->To->Add(toAddress);
                delete toAddress;
            }
            else
            {
                //------------------------------------------------------------
                // If the gateway is not specified, use all of them
                //------------------------------------------------------------
                numberSection = QCOM_GeneralInfo->textMessageToNumber;
                if (numberSection->Contains(QCOM_STRING_HYPHEN))
                    numberSection = numberSection->Replace(QCOM_STRING_HYPHEN, QCOM_STRING_EMPTY);
                for each (String ^gateway in gatewayHostArray)
                {
                    emailInfo->toAddress = String::Concat(
                        numberSection, QCOM_STRING_AT, gateway);
                    MailAddress ^toAddress = gcnew MailAddress(emailInfo->toAddress);
                    textMessage->To->Add(toAddress);
                    delete toAddress;
                }
            }
            if (StringSet(QCOM_GeneralInfo->textMessageCCNumber))
            {
                if (QCOM_GeneralInfo->textMessageCCNumber->Contains(QCOM_STRING_AT))
                {
                    gatewaySection = QCOM_GeneralInfo->textMessageCCNumber->Substring(
                        QCOM_GeneralInfo->textMessageCCNumber->IndexOf(QCOM_STRING_AT));
                    numberSection = QCOM_GeneralInfo->textMessageCCNumber->Substring(
                        0, QCOM_GeneralInfo->textMessageCCNumber->IndexOf(QCOM_STRING_AT));
                    if (numberSection->Contains(QCOM_STRING_HYPHEN))
                        numberSection = numberSection->Replace(QCOM_STRING_HYPHEN, QCOM_STRING_EMPTY);
                    emailInfo->ccAddress = String::Concat(numberSection, gatewaySection);
                    MailAddress ^ccAddress = gcnew MailAddress(emailInfo->ccAddress);
                    textMessage->CC->Add(ccAddress);
                    delete ccAddress;
                }
                else
                {
                    numberSection = QCOM_GeneralInfo->textMessageCCNumber;
                    if (numberSection->Contains(QCOM_STRING_HYPHEN))
                        numberSection = numberSection->Replace(QCOM_STRING_HYPHEN, QCOM_STRING_EMPTY);
                    for each (String ^gateway in gatewayHostArray)
                    {
                        emailInfo->ccAddress = String::Concat(
                            numberSection, QCOM_STRING_AT, gateway);
                        MailAddress ^ccAddress = gcnew MailAddress(emailInfo->ccAddress);
                        textMessage->CC->Add(ccAddress);
                        delete ccAddress;
                    }
                }
            }
            if (StringSet(emailInfo->messageString))
            {
                textMessage->Body = emailInfo->messageString->Trim();
                textMessage->BodyEncoding = Encoding::UTF8;
            }
            else
            {
                QCOM_RecordAndModalErrorEvent(
                    "{0} :\nMessage text is absent",
                    functionName);
                status = QCOM_ERROR_TEXT_MISSING_MESSAGE;                       // 0x0000009B
            }
            if (StringSet(emailInfo->subjectString))
            {
                textMessage->Subject = emailInfo->subjectString->Trim();
                textMessage->SubjectEncoding = Encoding::UTF8;
            }
            else
            {
                QCOM_RecordAndModalErrorEvent(
                    "{0} :\nSubject text is absent",
                    functionName);
                status = QCOM_ERROR_TEXT_MISSING_SUBJECT;                       // 0x0000009A
            }
            if (status == QCOM_SUCCESS)
            {
                status = QCOM_SendSMTPMail(textMessage);
            }                           // end of if (status == QCOM_SUCCESS)
            textMessage->~MailMessage();
            delete textMessage;
            delete emailInfo;
        }                               // end of if (StringSet(textSubjectString) && ...)
        else
        {
            if (!StringSet(textSubjectString))
            {
                QCOM_RecordAndModalErrorEvent(
                    "{0} : No text subject string specified", functionName);
                status = QCOM_ERROR_TEXT_MISSING_SUBJECT;                       // 0x0000009A
            }
            if (!StringSet(textMessageString))
            {
                QCOM_RecordAndModalErrorEvent(
                    "{0} : No text message string specified", functionName);
                status = QCOM_ERROR_TEXT_MISSING_MESSAGE;                       // 0x0000009B
            }
        }
    }
    else
    {
        QCOM_SendTextErrorMessagesEnabled = GUI_NO;
        QCOM_UpdateMessageChecks();
        Modal("No text message number specified to send message");
        status = QCOM_ERROR_TEXT_MISSING_COMPONENT;                             // 0x00000099
    }
    RecordBasicEvent("{0} concluded, returning 0x{1:X8}", functionName, status);
    return status;
}                                       // end of QCOM_SendTextMessage()
//----------------------------------------------------------------------------
// QCOM_SetDecimalPrecision
//
// Sets the precision (decimal places) of the pressure and temperature
// floating-point values
//
// Called by:   QCOM_PrecisionUpDownClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_SetDecimalPrecision(void)
{
    DWORD           value;
    DWORD           valueAll;
    String          ^functionName = _T("QCOM_SetDecimalPrecision");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    value = Convert::ToInt32(readoutPrecisionNumeric->Value);
    valueAll = Convert::ToInt32(logAllPrecisionNumeric->Value);
    if ((QCOM_CurrentPrecision != value) || (QCOM_CurrentPrecision != valueAll))
    {
        if (QCOM_CurrentPrecision != value)
        {
            RecordBasicEvent(
                "    The decimal precision changed from {0:D} to {1:D}",
                QCOM_CurrentPrecision,
                value);
            QCOM_CurrentPrecision = value;
            logAllPrecisionNumeric->Value = (int) value;
        }
        else
        {
            QCOM_CurrentPrecision = valueAll;
            readoutPrecisionNumeric->Value = (int) valueAll;
        }
        QCOM_PrecisionFormatString = String::Concat("{0:F", QCOM_CurrentPrecision, "}");
        QCOM_UpdateAllReadouts();
        QCOM_LogAllUpdateCaptions();
        QCOM_UpdateGlobalObjects(GUI_UPDATE_CONTEXT_ALL);
    }                                   // end of if (QCOM_CurrentPrecision != value)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_SetDecimalPrecision()
//----------------------------------------------------------------------------
// QCOM_ShutDownSoftware
//
// Returns allocated memory to the pool, destroys the linked list of devices,
// and terminates the software
//
// Called by:   QCOM_HomeClosingWindow
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ShutDownSoftware(void)
{
    String          ^functionName = _T("QCOM_ShutDownSoftware");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Turn off sampling, if it's running
    //------------------------------------------------------------------------
    if (QCOM_GeneralInfo->flags & QCOM_GENERAL_CURRENTLY_SAMPLING)
    {
        QCOM_GeneralInfo->flags &= ~QCOM_GENERAL_CURRENTLY_SAMPLING;
        for (DWORD unitNumber = 0; unitNumber < QCOM_CurrentNumberOfUnits; unitNumber++)
        {
            if (QCOM_UnitNumberValid(unitNumber))
            {
                QCOM_UnitInfoArray[unitNumber]->flags &= ~QCOM_UNIT_CURRENTLY_SAMPLING;
                if (sendEveryTimerArray[unitNumber]->Enabled)
                    sendEveryTimerArray[unitNumber]->Stop();
            }
        }
    }
    //------------------------------------------------------------------------
    // Shut down the program and non-programmable timers, if they're running
    //------------------------------------------------------------------------
    if (programTimer->Enabled)
        programTimer->Stop();
    if (oneMinuteTimer->Enabled)
        oneMinuteTimer->Stop();
    if (oneSecondTimer->Enabled)
        oneSecondTimer->Stop();
    //------------------------------------------------------------------------
    // Terminate testing if it's running
    //------------------------------------------------------------------------
    QCOM_TerminateTesting();
    //------------------------------------------------------------------------
    // Terminate data logging if it's running
    //------------------------------------------------------------------------
    QCOM_TerminateDataLogging();
    //------------------------------------------------------------------------
    // Remove the Please Wait window
    //------------------------------------------------------------------------
    QCOM_PleaseWait(GUI_PLEASE_WAIT_DISPOSE, nullptr);
    //------------------------------------------------------------------------
    // Announce software conclusion
    //------------------------------------------------------------------------
    GUI_PlaySound(downSound);
    //------------------------------------------------------------------------
    // Save the config file and conclude any running logs
    //------------------------------------------------------------------------
    QCOM_Finalize(String::Concat(functionName, " concluded"));
    //------------------------------------------------------------------------
    // Un-register the computer events before exiting the program
    //------------------------------------------------------------------------
    SystemEvents::PowerModeChanged -=
        gcnew PowerModeChangedEventHandler(this, &QCOM_GUIClass::QCOM_ComputerGoingToHibernation);
    SystemEvents::SessionEnded -=
        gcnew SessionEndedEventHandler(this, &QCOM_GUIClass::QCOM_ComputerShuttingDown);
}                                       // end of QCOM_ShutDownSoftware()
//----------------------------------------------------------------------------
// QCOM_StringWidth
//
// Returns the width of the specified string in pixels
//----------------------------------------------------------------------------
    DWORD QCOM_GUIClass::
QCOM_StringWidth(
    String          ^textString)
{
    DWORD           widthInPixels = 0;
    //------------------------------------------------------------------------
    if (StringSet(textString))
    {
        Drawing::Size ^numberOfPixels = Drawing::Size(
            TextRenderer::MeasureText(
                textString,
                gcnew Drawing::Font(this->Font, FontStyle::Regular)));
        widthInPixels = (DWORD) numberOfPixels->Width;
        delete numberOfPixels;
    }
    return widthInPixels;
}                                       // end of QCOM_StringWidth()
//----------------------------------------------------------------------------
// QCOM_UtilConvertReadings
//
// Prompts the tester for a transducer serial number and a text file
// containing pressure and temperature counts to convert to actual pressure
// and temperature values
//
// Called by:   QCOM_UtilConvertReadingsButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertReadings(void)
{
    String          ^functionName = _T("QCOM_UtilConvertReadings");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    convertReadingsWindow = gcnew Form;
    //------------------------------------------------------------------------
    // Set its properties
    //------------------------------------------------------------------------
    convertReadingsWindow->Text = _T("Convert Transducer Readings");
    convertReadingsWindow->Icon = QCOM_SoftwareIcon;
    convertReadingsWindow->BackgroundImage = gcnew Bitmap(GUI_BG_WOOD_PANEL, GUI_YES);
    convertReadingsWindow->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
    convertReadingsWindow->StartPosition = FormStartPosition::CenterScreen;
    convertReadingsWindow->Size = Drawing::Size(460, 260);
    //------------------------------------------------------------------------
    // Prevent the user from changing its appearance
    //------------------------------------------------------------------------
    convertReadingsWindow->MaximizeBox = GUI_NO;
    convertReadingsWindow->HelpButton = GUI_NO;
    //------------------------------------------------------------------------
    // Transducer Serial Number label
    //------------------------------------------------------------------------
    Label ^transducerSerialNumberLabel = gcnew Label;
    transducerSerialNumberLabel->Text = _T("Transducer serial number :");
    transducerSerialNumberLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);           // choose from Bold, Italic, Underline, Strikeout
    transducerSerialNumberLabel->Location = Point(10, 10);
    transducerSerialNumberLabel->Size = Drawing::Size(
        176, GUI_HELP_LABEL_HEIGHT);
    transducerSerialNumberLabel->BackColor = Color::Transparent;
    transducerSerialNumberLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    convertReadingsWindow->Controls->Add(transducerSerialNumberLabel);
    //------------------------------------------------------------------------
    // Transducer Serial Number text box
    //------------------------------------------------------------------------
    utilConvertReadingsTransducerSerialNumberBox = gcnew TextBox;
    utilConvertReadingsTransducerSerialNumberBox->Location = Point(
        transducerSerialNumberLabel->Right + 2,
        transducerSerialNumberLabel->Top + 2);
    utilConvertReadingsTransducerSerialNumberBox->Size = Drawing::Size(
        70, GUI_REGULAR_TEXT_BOX_HEIGHT);
    utilConvertReadingsTransducerSerialNumberBox->Multiline = GUI_NO;
    utilConvertReadingsTransducerSerialNumberBox->AcceptsReturn = GUI_NO;
    utilConvertReadingsTransducerSerialNumberBox->AcceptsTab = GUI_NO;
    utilConvertReadingsTransducerSerialNumberBox->WordWrap = GUI_NO;
    utilConvertReadingsTransducerSerialNumberBox->TextAlign = HorizontalAlignment::Center;
    utilConvertReadingsTransducerSerialNumberBox->BackColor = Color::White;
    utilConvertReadingsTransducerSerialNumberBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateConvertReadingsTransducerSerialNumber);
    if (utilConvertReadingsUnit->flags & QCOM_UNIT_COEFFICIENTS_VERIFIED)
    {
        char *transducerSerialNumber = (char *) malloc(QCOM_MAXIMUM_SERIAL_NUMBER_SIZE);
        if (transducerSerialNumber)
        {
            QCOM_ExtractSerialNumberFromCoefficientData(
                utilConvertReadingsUnit->coefficientData,
                transducerSerialNumber);
            utilConvertReadingsUnit->transducerSerialNumber =
                gcnew String(transducerSerialNumber, 0, 6);
            free((void *) transducerSerialNumber);
        }
        if (StringSet(utilConvertReadingsUnit->transducerSerialNumber))
            utilConvertReadingsTransducerSerialNumberBox->Text =
                utilConvertReadingsUnit->transducerSerialNumber;
    }
    else
    {
        utilConvertReadingsUnit->transducerSerialNumber = String::Empty;
    }
    convertReadingsWindow->Controls->Add(utilConvertReadingsTransducerSerialNumberBox);
    //------------------------------------------------------------------------
    // Transducer Serial Number Caption label
    //------------------------------------------------------------------------
    Label ^transducerSerialNumberCaptionLabel = gcnew Label;
    transducerSerialNumberCaptionLabel->Text = _T("(enter S/N and press Tab)");
    transducerSerialNumberCaptionLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    transducerSerialNumberCaptionLabel->Location = Point(
        utilConvertReadingsTransducerSerialNumberBox->Right + 4,
        transducerSerialNumberLabel->Top);
    transducerSerialNumberCaptionLabel->Size = Drawing::Size(
        180, GUI_HELP_LABEL_HEIGHT);
    transducerSerialNumberCaptionLabel->BackColor = Color::Transparent;
    transducerSerialNumberCaptionLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    convertReadingsWindow->Controls->Add(transducerSerialNumberCaptionLabel);
    //------------------------------------------------------------------------
    // Transducer Serial Number tool tip
    //------------------------------------------------------------------------
    ToolTip ^transducerSerialNumberToolTip = gcnew ToolTip;
    transducerSerialNumberToolTip->ShowAlways = GUI_YES;
    transducerSerialNumberToolTip->AutoPopDelay = 10000;    // let stand for ten seconds
    transducerSerialNumberToolTip->ToolTipTitle = _T("Transducer Serial Number");
    String ^transducerSerialNumberToolTipText = String::Concat(
        "Serial number of the transducer whose coefficient", Environment::NewLine,
        "data will be used to convert the pressure and", Environment::NewLine,
        "temperature counts or frequencies");
    transducerSerialNumberToolTip->SetToolTip(transducerSerialNumberLabel, transducerSerialNumberToolTipText);
    transducerSerialNumberToolTip->SetToolTip(utilConvertReadingsTransducerSerialNumberBox, transducerSerialNumberToolTipText);
    transducerSerialNumberToolTip->SetToolTip(transducerSerialNumberCaptionLabel, transducerSerialNumberToolTipText);
    delete transducerSerialNumberToolTipText;
    //------------------------------------------------------------------------
    // Load Readings File button
    //------------------------------------------------------------------------
    utilConvertReadingsLoadFileButton = gcnew Button;
    utilConvertReadingsLoadFileButton->Text = _T("Load Readings File");
    utilConvertReadingsLoadFileButton->Location = Point(
        10, transducerSerialNumberLabel->Bottom + 6);
    utilConvertReadingsLoadFileButton->Size = Drawing::Size(
        158, GUI_REGULAR_BUTTON_HEIGHT);
    GUI_SetButtonInterfaceProperties(utilConvertReadingsLoadFileButton);
    utilConvertReadingsLoadFileButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilConvertReadingsLoadFileButtonClicked);
    convertReadingsWindow->Controls->Add(utilConvertReadingsLoadFileButton);
    if (StringSet(utilConvertReadingsTransducerSerialNumberBox->Text))
        utilConvertReadingsLoadFileButton->Enabled = GUI_YES;
    else
        utilConvertReadingsLoadFileButton->Enabled = GUI_NO;
    //------------------------------------------------------------------------
    // Load Readings File label
    //------------------------------------------------------------------------
    utilConvertReadingsLoadFileLabel = gcnew Label;
    utilConvertReadingsLoadFileLabel->Text = Path::GetFileName(
        utilConvertReadingsUnit->convertReadingsFilePath);
    utilConvertReadingsLoadFileLabel->Location = Point(
        utilConvertReadingsLoadFileButton->Right + 6,
        utilConvertReadingsLoadFileButton->Top + 2);
    utilConvertReadingsLoadFileLabel->Size = Drawing::Size(
        convertReadingsWindow->Width - utilConvertReadingsLoadFileButton->Width - 30,
        GUI_HELP_LABEL_HEIGHT);
    utilConvertReadingsLoadFileLabel->BackColor = Color::Transparent;
    utilConvertReadingsLoadFileLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    convertReadingsWindow->Controls->Add(utilConvertReadingsLoadFileLabel);
    //------------------------------------------------------------------------
    // Load Readings File tool tip
    //------------------------------------------------------------------------
    ToolTip ^loadReadingsFileToolTip = gcnew ToolTip;
    loadReadingsFileToolTip->ShowAlways = GUI_YES;
    loadReadingsFileToolTip->AutoPopDelay = 10000;    // let stand for ten seconds
    loadReadingsFileToolTip->ToolTipTitle = _T("Load Readings File");
    String ^loadReadingsFileToolTipText = String::Concat(
        "Prompts for a text file that contains one or", Environment::NewLine,
        "more lines of pressure and temperature count", Environment::NewLine,
        "pairs to convert, one pair per line");
    loadReadingsFileToolTip->SetToolTip(utilConvertReadingsLoadFileButton, loadReadingsFileToolTipText);
    loadReadingsFileToolTip->SetToolTip(utilConvertReadingsLoadFileLabel, loadReadingsFileToolTipText);
    delete loadReadingsFileToolTipText;
    //------------------------------------------------------------------------
    // Or label
    //------------------------------------------------------------------------
    Label ^utilConvertReadingsOrLabel = gcnew Label;
    utilConvertReadingsOrLabel->Text = _T("or manually enter a single set of readings:");
    utilConvertReadingsOrLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);           // choose from Bold, Italic, Underline, Strikeout
    utilConvertReadingsOrLabel->Location = Point(
        utilConvertReadingsLoadFileButton->Left + 40,
        utilConvertReadingsLoadFileButton->Bottom + 6);
    utilConvertReadingsOrLabel->Size = Drawing::Size(
        270, GUI_HELP_LABEL_HEIGHT);
    utilConvertReadingsOrLabel->BackColor = Color::Transparent;
    utilConvertReadingsOrLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    convertReadingsWindow->Controls->Add(utilConvertReadingsOrLabel);
    //------------------------------------------------------------------------
    // Pressure label
    //------------------------------------------------------------------------
    Label ^utilConvertReadingsPressureLabel = gcnew Label;
    utilConvertReadingsPressureLabel->Text = _T("Pressure =");
    utilConvertReadingsPressureLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);           // choose from Bold, Italic, Underline, Strikeout
    utilConvertReadingsPressureLabel->Location = Point(
        utilConvertReadingsLoadFileButton->Left,
        utilConvertReadingsOrLabel->Bottom + 6);
    utilConvertReadingsPressureLabel->Size = Drawing::Size(
        100, GUI_HELP_LABEL_HEIGHT);
    utilConvertReadingsPressureLabel->BackColor = Color::Transparent;
    utilConvertReadingsPressureLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    convertReadingsWindow->Controls->Add(utilConvertReadingsPressureLabel);
    //------------------------------------------------------------------------
    // Temperature label
    //------------------------------------------------------------------------
    Label ^utilConvertReadingsTemperatureLabel = gcnew Label;
    utilConvertReadingsTemperatureLabel->Text = _T("Temperature =");
    utilConvertReadingsTemperatureLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);           // choose from Bold, Italic, Underline, Strikeout
    GUI_PositionBelow(
        utilConvertReadingsTemperatureLabel,
        utilConvertReadingsPressureLabel, 6);
    utilConvertReadingsTemperatureLabel->Size = utilConvertReadingsPressureLabel->Size;
    utilConvertReadingsTemperatureLabel->BackColor = Color::Transparent;
    utilConvertReadingsTemperatureLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    convertReadingsWindow->Controls->Add(utilConvertReadingsTemperatureLabel);
    //------------------------------------------------------------------------
    // Pressure Count text box
    //------------------------------------------------------------------------
    utilConvertReadingsPressureCountBox = gcnew TextBox;
    utilConvertReadingsPressureCountBox->Location = Point(
        utilConvertReadingsPressureLabel->Right + 2,
        utilConvertReadingsPressureLabel->Top + 2);
    utilConvertReadingsPressureCountBox->Size = Drawing::Size(
        70, GUI_REGULAR_TEXT_BOX_HEIGHT);
    utilConvertReadingsPressureCountBox->Multiline = GUI_NO;
    utilConvertReadingsPressureCountBox->AcceptsReturn = GUI_NO;
    utilConvertReadingsPressureCountBox->AcceptsTab = GUI_NO;
    utilConvertReadingsPressureCountBox->WordWrap = GUI_NO;
    utilConvertReadingsPressureCountBox->TextAlign = HorizontalAlignment::Center;
    if ((utilConvertReadingsUnit->flags & QCOM_UNIT_COEFFICIENTS_VERIFIED) &&
        StringICompare(utilConvertReadingsUnit->transducerSerialNumber, utilConvertReadingsTransducerSerialNumberBox->Text) == 0)
    {
        utilConvertReadingsPressureCountBox->BackColor = Color::White;
        utilConvertReadingsPressureCountBox->Enabled = GUI_YES;
    }
    else
    {
        utilConvertReadingsPressureCountBox->BackColor = Color::Gainsboro;
        utilConvertReadingsPressureCountBox->Enabled = GUI_NO;
    }
    utilConvertReadingsPressureCountBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateConvertReadingsPressureCount);
    convertReadingsWindow->Controls->Add(utilConvertReadingsPressureCountBox);
    //------------------------------------------------------------------------
    // Temperature Count text box
    //------------------------------------------------------------------------
    utilConvertReadingsTemperatureCountBox = gcnew TextBox;
    utilConvertReadingsTemperatureCountBox->Location = Point(
        utilConvertReadingsPressureCountBox->Left,
        utilConvertReadingsTemperatureLabel->Top + 2);
    utilConvertReadingsTemperatureCountBox->Size = utilConvertReadingsPressureCountBox->Size;
    utilConvertReadingsTemperatureCountBox->Multiline = GUI_NO;
    utilConvertReadingsTemperatureCountBox->AcceptsReturn = GUI_NO;
    utilConvertReadingsTemperatureCountBox->AcceptsTab = GUI_NO;
    utilConvertReadingsTemperatureCountBox->WordWrap = GUI_NO;
    utilConvertReadingsTemperatureCountBox->TextAlign = HorizontalAlignment::Center;
    if ((utilConvertReadingsUnit->flags & QCOM_UNIT_COEFFICIENTS_VERIFIED) &&
        StringICompare(utilConvertReadingsUnit->transducerSerialNumber, utilConvertReadingsTransducerSerialNumberBox->Text) == 0)
    {
        utilConvertReadingsTemperatureCountBox->BackColor = Color::White;
        utilConvertReadingsTemperatureCountBox->Enabled = GUI_YES;
    }
    else
    {
        utilConvertReadingsTemperatureCountBox->BackColor = Color::Gainsboro;
        utilConvertReadingsTemperatureCountBox->Enabled = GUI_NO;
    }
    utilConvertReadingsTemperatureCountBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateConvertReadingsTemperatureCount);
    convertReadingsWindow->Controls->Add(utilConvertReadingsTemperatureCountBox);
    //------------------------------------------------------------------------
    // Counts label
    //------------------------------------------------------------------------
    Label ^utilConvertReadingsCountsLabel = gcnew Label;
    utilConvertReadingsCountsLabel->Text = _T("counts");
    utilConvertReadingsCountsLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);           // choose from Bold, Italic, Underline, Strikeout
    GUI_PositionBelow(
        utilConvertReadingsCountsLabel,
        utilConvertReadingsTemperatureCountBox, 2);
    utilConvertReadingsCountsLabel->Size = Drawing::Size(
        utilConvertReadingsTemperatureCountBox->Width,
        GUI_HELP_LABEL_HEIGHT);
    utilConvertReadingsCountsLabel->BackColor = Color::Transparent;
    utilConvertReadingsCountsLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    convertReadingsWindow->Controls->Add(utilConvertReadingsCountsLabel);
    //------------------------------------------------------------------------
    // Counts tool tip
    //------------------------------------------------------------------------
    ToolTip ^countsToolTip = gcnew ToolTip;
    countsToolTip->ShowAlways = GUI_YES;
    countsToolTip->AutoPopDelay = 10000;        // let stand for ten seconds
    countsToolTip->ToolTipTitle = _T("Transducer Counts");
    String ^countsToolTipText = String::Concat(
        "Enter the pressure and temperature counts,", Environment::NewLine,
        "which are long (32-bit) integers");
    countsToolTip->SetToolTip(utilConvertReadingsPressureCountBox, countsToolTipText);
    countsToolTip->SetToolTip(utilConvertReadingsTemperatureCountBox, countsToolTipText);
    countsToolTip->SetToolTip(utilConvertReadingsCountsLabel, countsToolTipText);
    delete countsToolTipText;
    //------------------------------------------------------------------------
    // Pressure Frequency text box
    //------------------------------------------------------------------------
    utilConvertReadingsPressureFrequencyBox = gcnew TextBox;
    utilConvertReadingsPressureFrequencyBox->Location = Point(
        utilConvertReadingsPressureCountBox->Right + 10,
        utilConvertReadingsPressureCountBox->Top);
    utilConvertReadingsPressureFrequencyBox->Size = utilConvertReadingsPressureCountBox->Size;
    utilConvertReadingsPressureFrequencyBox->Multiline = GUI_NO;
    utilConvertReadingsPressureFrequencyBox->AcceptsReturn = GUI_NO;
    utilConvertReadingsPressureFrequencyBox->AcceptsTab = GUI_NO;
    utilConvertReadingsPressureFrequencyBox->WordWrap = GUI_NO;
    utilConvertReadingsPressureFrequencyBox->TextAlign = HorizontalAlignment::Center;
    if ((utilConvertReadingsUnit->flags & QCOM_UNIT_COEFFICIENTS_VERIFIED) &&
        StringICompare(utilConvertReadingsUnit->transducerSerialNumber, utilConvertReadingsTransducerSerialNumberBox->Text) == 0)
    {
        utilConvertReadingsPressureFrequencyBox->BackColor = Color::White;
        utilConvertReadingsPressureFrequencyBox->Enabled = GUI_YES;
    }
    else
    {
        utilConvertReadingsPressureFrequencyBox->BackColor = Color::Gainsboro;
        utilConvertReadingsPressureFrequencyBox->Enabled = GUI_NO;
    }
    utilConvertReadingsPressureFrequencyBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateConvertReadingsPressureFrequency);
    convertReadingsWindow->Controls->Add(utilConvertReadingsPressureFrequencyBox);
    //------------------------------------------------------------------------
    // Temperature Frequency text box
    //------------------------------------------------------------------------
    utilConvertReadingsTemperatureFrequencyBox = gcnew TextBox;
    utilConvertReadingsTemperatureFrequencyBox->Location = Point(
        utilConvertReadingsPressureFrequencyBox->Left,
        utilConvertReadingsTemperatureCountBox->Top);
    utilConvertReadingsTemperatureFrequencyBox->Size = utilConvertReadingsPressureFrequencyBox->Size;
    utilConvertReadingsTemperatureFrequencyBox->Multiline = GUI_NO;
    utilConvertReadingsTemperatureFrequencyBox->AcceptsReturn = GUI_NO;
    utilConvertReadingsTemperatureFrequencyBox->AcceptsTab = GUI_NO;
    utilConvertReadingsTemperatureFrequencyBox->WordWrap = GUI_NO;
    utilConvertReadingsTemperatureFrequencyBox->TextAlign = HorizontalAlignment::Center;
    if ((utilConvertReadingsUnit->flags & QCOM_UNIT_COEFFICIENTS_VERIFIED) &&
        StringICompare(utilConvertReadingsUnit->transducerSerialNumber, utilConvertReadingsTransducerSerialNumberBox->Text) == 0)
    {
        utilConvertReadingsTemperatureFrequencyBox->BackColor = Color::White;
        utilConvertReadingsTemperatureFrequencyBox->Enabled = GUI_YES;
    }
    else
    {
        utilConvertReadingsTemperatureFrequencyBox->BackColor = Color::Gainsboro;
        utilConvertReadingsTemperatureFrequencyBox->Enabled = GUI_NO;
    }
    utilConvertReadingsTemperatureFrequencyBox->Validating +=
        gcnew CancelEventHandler(this, &QCOM_GUIClass::QCOM_ValidateConvertReadingsTemperatureFrequency);
    convertReadingsWindow->Controls->Add(utilConvertReadingsTemperatureFrequencyBox);
    //------------------------------------------------------------------------
    // Frequencies label
    //------------------------------------------------------------------------
    Label ^utilConvertReadingsFrequenciesLabel = gcnew Label;
    utilConvertReadingsFrequenciesLabel->Text = _T("freqs");
    utilConvertReadingsFrequenciesLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);           // choose from Bold, Italic, Underline, Strikeout
    GUI_PositionBelow(
        utilConvertReadingsFrequenciesLabel,
        utilConvertReadingsTemperatureFrequencyBox, 2);
    utilConvertReadingsFrequenciesLabel->Size = Drawing::Size(
        utilConvertReadingsTemperatureFrequencyBox->Width,
        GUI_HELP_LABEL_HEIGHT);
    utilConvertReadingsFrequenciesLabel->BackColor = Color::Transparent;
    utilConvertReadingsFrequenciesLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    convertReadingsWindow->Controls->Add(utilConvertReadingsFrequenciesLabel);
    //------------------------------------------------------------------------
    // Frequencies tool tip
    //------------------------------------------------------------------------
    ToolTip ^frequenciesToolTip = gcnew ToolTip;
    frequenciesToolTip->ShowAlways = GUI_YES;
    frequenciesToolTip->AutoPopDelay = 10000;       // let stand for ten seconds
    frequenciesToolTip->ToolTipTitle = _T("Transducer Frequencies");
    String ^frequenciesToolTipText = String::Concat(
        "Enter the pressure and temperature frequencies,", Environment::NewLine,
        "which are floating-point values");
    frequenciesToolTip->SetToolTip(utilConvertReadingsPressureFrequencyBox, frequenciesToolTipText);
    frequenciesToolTip->SetToolTip(utilConvertReadingsTemperatureFrequencyBox, frequenciesToolTipText);
    frequenciesToolTip->SetToolTip(utilConvertReadingsFrequenciesLabel, frequenciesToolTipText);
    delete frequenciesToolTipText;
    //------------------------------------------------------------------------
    // Pressure To label
    //------------------------------------------------------------------------
    Label ^utilConvertReadingsPressureToLabel = gcnew Label;
    utilConvertReadingsPressureToLabel->Text = _T("=>");
    utilConvertReadingsPressureToLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    utilConvertReadingsPressureToLabel->Location = Point(
        utilConvertReadingsPressureFrequencyBox->Right + 10,
        utilConvertReadingsPressureFrequencyBox->Top - 2);
    utilConvertReadingsPressureToLabel->Size = Drawing::Size(
        24,
        GUI_HELP_LABEL_HEIGHT);
    utilConvertReadingsPressureToLabel->BackColor = Color::Transparent;
    utilConvertReadingsPressureToLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    convertReadingsWindow->Controls->Add(utilConvertReadingsPressureToLabel);
    //------------------------------------------------------------------------
    // Temperature To label
    //------------------------------------------------------------------------
    Label ^utilConvertReadingsTemperatureToLabel = gcnew Label;
    utilConvertReadingsTemperatureToLabel->Text = _T("=>");
    utilConvertReadingsTemperatureToLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    utilConvertReadingsTemperatureToLabel->Location = Point(
        utilConvertReadingsPressureToLabel->Left,
        utilConvertReadingsTemperatureFrequencyBox->Top - 2);
    utilConvertReadingsTemperatureToLabel->Size = utilConvertReadingsPressureToLabel->Size;
    utilConvertReadingsTemperatureToLabel->BackColor = Color::Transparent;
    utilConvertReadingsTemperatureToLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    convertReadingsWindow->Controls->Add(utilConvertReadingsTemperatureToLabel);
    //------------------------------------------------------------------------
    // Pressure Actual text box
    //------------------------------------------------------------------------
    utilConvertReadingsPressureActualBox = gcnew TextBox;
    utilConvertReadingsPressureActualBox->Location = Point(
        utilConvertReadingsPressureToLabel->Right + 10,
        utilConvertReadingsPressureFrequencyBox->Top);
    utilConvertReadingsPressureActualBox->Size = Drawing::Size(
        94, GUI_REGULAR_TEXT_BOX_HEIGHT);
    utilConvertReadingsPressureActualBox->Multiline = GUI_NO;
    utilConvertReadingsPressureActualBox->AcceptsReturn = GUI_NO;
    utilConvertReadingsPressureActualBox->AcceptsTab = GUI_NO;
    utilConvertReadingsPressureActualBox->WordWrap = GUI_NO;
    utilConvertReadingsPressureActualBox->ReadOnly = GUI_YES;
    utilConvertReadingsPressureActualBox->TextAlign = HorizontalAlignment::Center;
    utilConvertReadingsPressureActualBox->BackColor = Color::Lavender;
    convertReadingsWindow->Controls->Add(utilConvertReadingsPressureActualBox);
    //------------------------------------------------------------------------
    // Temperature Actual text box
    //------------------------------------------------------------------------
    utilConvertReadingsTemperatureActualBox = gcnew TextBox;
    utilConvertReadingsTemperatureActualBox->Location = Point(
        utilConvertReadingsPressureActualBox->Left,
        utilConvertReadingsTemperatureFrequencyBox->Top);
    utilConvertReadingsTemperatureActualBox->Size = utilConvertReadingsPressureActualBox->Size;
    utilConvertReadingsTemperatureActualBox->Multiline = GUI_NO;
    utilConvertReadingsTemperatureActualBox->AcceptsReturn = GUI_NO;
    utilConvertReadingsTemperatureActualBox->AcceptsTab = GUI_NO;
    utilConvertReadingsTemperatureActualBox->WordWrap = GUI_NO;
    utilConvertReadingsTemperatureActualBox->ReadOnly = GUI_YES;
    utilConvertReadingsTemperatureActualBox->TextAlign = HorizontalAlignment::Center;
    utilConvertReadingsTemperatureActualBox->BackColor = Color::Lavender;
    convertReadingsWindow->Controls->Add(utilConvertReadingsTemperatureActualBox);
    //------------------------------------------------------------------------
    // Actual label
    //------------------------------------------------------------------------
    Label ^utilConvertReadingsActualLabel = gcnew Label;
    utilConvertReadingsActualLabel->Text = _T("actual");
    utilConvertReadingsActualLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);           // choose from Bold, Italic, Underline, Strikeout
    GUI_PositionBelow(
        utilConvertReadingsActualLabel,
        utilConvertReadingsTemperatureActualBox, 2);
    utilConvertReadingsActualLabel->Size = Drawing::Size(
        utilConvertReadingsTemperatureActualBox->Width,
        GUI_HELP_LABEL_HEIGHT);
    utilConvertReadingsActualLabel->BackColor = Color::Transparent;
    utilConvertReadingsActualLabel->TextAlign = Drawing::ContentAlignment::MiddleCenter;
    convertReadingsWindow->Controls->Add(utilConvertReadingsActualLabel);
    //------------------------------------------------------------------------
    // Pressure Units label
    //------------------------------------------------------------------------
    Label ^utilConvertReadingsPressureUnitsLabel = gcnew Label;
    utilConvertReadingsPressureUnitsLabel->Text = _T("psi");
    utilConvertReadingsPressureUnitsLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    utilConvertReadingsPressureUnitsLabel->Location = Point(
        utilConvertReadingsPressureActualBox->Right + 4,
        utilConvertReadingsPressureToLabel->Top);
    utilConvertReadingsPressureUnitsLabel->Size = Drawing::Size(
        26, GUI_HELP_LABEL_HEIGHT);
    utilConvertReadingsPressureUnitsLabel->BackColor = Color::Transparent;
    utilConvertReadingsPressureUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    convertReadingsWindow->Controls->Add(utilConvertReadingsPressureUnitsLabel);
    //------------------------------------------------------------------------
    // Temperature Units label
    //------------------------------------------------------------------------
    Label ^utilConvertReadingsTemperatureUnitsLabel = gcnew Label;
    utilConvertReadingsTemperatureUnitsLabel->Text = _T("°C");
    utilConvertReadingsTemperatureUnitsLabel->Font = gcnew Drawing::Font(
        FontFamily::GenericSansSerif,
        10.0F,
        FontStyle::Bold);
    utilConvertReadingsTemperatureUnitsLabel->Location = Point(
        utilConvertReadingsPressureUnitsLabel->Left,
        utilConvertReadingsTemperatureToLabel->Top);
    utilConvertReadingsTemperatureUnitsLabel->Size = utilConvertReadingsPressureUnitsLabel->Size;
    utilConvertReadingsTemperatureUnitsLabel->BackColor = Color::Transparent;
    utilConvertReadingsTemperatureUnitsLabel->TextAlign = Drawing::ContentAlignment::MiddleLeft;
    convertReadingsWindow->Controls->Add(utilConvertReadingsTemperatureUnitsLabel);
    //------------------------------------------------------------------------
    // Actual tool tip
    //------------------------------------------------------------------------
    ToolTip ^actualToolTip = gcnew ToolTip;
    actualToolTip->ShowAlways = GUI_YES;
    actualToolTip->AutoPopDelay = 10000;        // let stand for ten seconds
    actualToolTip->ToolTipTitle = _T("Actual Values");
    String ^actualToolTipText = String::Concat(
        "The resulting converted values", Environment::NewLine,
        "are displayed here");
    actualToolTip->SetToolTip(utilConvertReadingsPressureActualBox, actualToolTipText);
    actualToolTip->SetToolTip(utilConvertReadingsTemperatureActualBox, actualToolTipText);
    actualToolTip->SetToolTip(utilConvertReadingsActualLabel, actualToolTipText);
    actualToolTip->SetToolTip(utilConvertReadingsPressureUnitsLabel, actualToolTipText);
    actualToolTip->SetToolTip(utilConvertReadingsTemperatureUnitsLabel, actualToolTipText);
    delete actualToolTipText;
    //------------------------------------------------------------------------
    // Close button
    //------------------------------------------------------------------------
    Button ^closeButton = gcnew Button;
    closeButton->Text = _T("Close");
    closeButton->Location = Point(
        convertReadingsWindow->Right - 100,
        convertReadingsWindow->Bottom - 70);
    closeButton->Size = Drawing::Size(
        GUI_CLOSE_BUTTON_WIDTH,
        GUI_REGULAR_BUTTON_HEIGHT);
    closeButton->DialogResult = System::Windows::Forms::DialogResult::OK;
    GUI_SetButtonInterfaceProperties(closeButton);
    closeButton->Click +=
        gcnew EventHandler(this, &QCOM_GUIClass::QCOM_UtilConvertReadingsCloseWindow);
    convertReadingsWindow->Controls->Add(closeButton);
    convertReadingsWindow->AcceptButton = closeButton;
    convertReadingsWindow->CancelButton = closeButton;
    //------------------------------------------------------------------------
    // Display the window and query the user
    //------------------------------------------------------------------------
    convertReadingsWindow->ShowDialog();
    convertReadingsWindow->BringToFront();
    if (convertReadingsWindow->CanFocus)
        convertReadingsWindow->Focus();
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_UtilConvertReadings()
//----------------------------------------------------------------------------
// QCOM_UtilConvertReadingsLoadFile
//
// Prompts the tester for a text file containing pressure and temperature
// counts to convert to actual pressure and temperature values
//
// Called by:   QCOM_UtilConvertReadingsLoadFileButtonClicked
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertReadingsLoadFile(void)
{
    String          ^functionName = _T("QCOM_UtilConvertReadingsLoadFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    //------------------------------------------------------------------------
    // Prompt the tester for a file to read
    //------------------------------------------------------------------------
    String ^readingsFilePathString = QCOM_GeneralInfo->generalUsePath;
    bool promptResult = GUI_ACCEPT;
    bool fileLocated = GUI_NO;
    do
    {
        StringBuilder ^readingsFilePathBuilder = gcnew StringBuilder(
            readingsFilePathString,
            QCOM_MAXIMUM_FILE_PATH_LENGTH);
        promptResult = QCOM_PromptForReadFile(
            String::Format(
                "Load a readings file for S/N {0}",
                utilConvertReadingsUnit->transducerSerialNumber),
            readingsFilePathBuilder,
            nullptr,
            GUI_FILE_TYPE_TEXT);
        readingsFilePathString = readingsFilePathBuilder->ToString();
        delete readingsFilePathBuilder;
        if (promptResult == GUI_ACCEPT)
        {
            if (File::Exists(readingsFilePathString))
            {
                fileLocated = GUI_YES;
                QCOM_GeneralInfo->generalUsePath = readingsFilePathString;
                utilConvertReadingsUnit->convertReadingsFilePath = readingsFilePathString;
                utilConvertReadingsLoadFileLabel->Text = Path::GetFileName(
                    utilConvertReadingsUnit->convertReadingsFilePath);
                QCOM_UtilConvertReadingsProcessFile(readingsFilePathString);
            }
            else
            {
                QCOM_PromptOKModal(
                    "File Not Found",
                    "File '{0}' is not found",
                    readingsFilePathString);
            }
        }
    }
    while (!fileLocated && (promptResult == GUI_ACCEPT));
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_UtilConvertReadingsLoadFile()
//----------------------------------------------------------------------------
// QCOM_UtilConvertReadingsProcessFile
//
// Processes the specified text file containing pressure and temperature
// counts and converts them to actual pressure and temperature values
//
// Called by:   QCOM_UtilConvertReadingsLoadFile
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertReadingsProcessFile(
    String          ^convertReadingsPath)
{
    String          ^functionName = _T("QCOM_UtilConvertReadingsProcessFile");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(convertReadingsPath) && File::Exists(convertReadingsPath))
    {
        DWORD pressureCount = 0;
        DWORD temperatureCount = 0;
        double pressurePSI = 0.0;
        double temperatureCelsius = 0.0;
        String ^fileText = String::Empty;
        StreamReader ^textReader = File::OpenText(convertReadingsPath);
        if (textReader)
        {
            fileText = textReader->ReadToEnd();
            textReader->Close();
        }                               // end of if (textReader)
        array <Char> ^lineDelimiters = gcnew array <Char> {QCOM_CHAR_CR, QCOM_CHAR_LF};
        array <String ^> ^lines = fileText->Split(
            lineDelimiters,
            StringSplitOptions::RemoveEmptyEntries);
        for (int lineNumber = 0; lineNumber < lines->Length; lineNumber++)
        {
            String ^lineString = lines[lineNumber];
            if (lineString->Contains("#"))
            {
                lineString = lineString->Substring(0, lineString->IndexOf("#"));
            }
            if (lineString->Length)
            {
                lineString = lineString->Replace(QCOM_STRING_COMMA, QCOM_STRING_SPACE)->Trim();
                array <Char> ^countDelimiters = gcnew array <Char> {QCOM_CHAR_SPACE};
                array <String ^> ^countStrings = lineString->Split(
                    countDelimiters,
                    StringSplitOptions::RemoveEmptyEntries);
                QCOM_ParseAndConvertStringToUnsigned(
                    countStrings[0],
                    &pressureCount);
                QCOM_ParseAndConvertStringToUnsigned(
                    countStrings[1],
                    &temperatureCount);
                DWORD status = QD_CalculatePressureAndTemperature(
                    (LPBYTE) utilConvertReadingsUnit->coefficientData,
                    pressureCount,
                    temperatureCount,
                    &pressurePSI,
                    &temperatureCelsius);
                if (status == QD_SUCCESS)
                {
                    lines[lineNumber] = String::Format(
                        "{0:F2} {1:F2}", pressurePSI, temperatureCelsius);
                }
                delete [] countStrings;
                delete [] countDelimiters;
            }
            delete lineString;
        }                               // end of for (int lineNumber = 0; ...)
        //--------------------------------------------------------------------
        // Recombine all the lines into the original string
        //--------------------------------------------------------------------
        fileText = String::Join(QCOM_STRING_CRLF, lines);
        lines = fileText->Split(lineDelimiters, StringSplitOptions::RemoveEmptyEntries);
        //--------------------------------------------------------------------
        // Combine the new set of lines into the new file string
        //--------------------------------------------------------------------
        fileText = String::Join(QCOM_STRING_CRLF, lines);
        String ^actualFilePathString = String::Empty;
        StringBuilder ^actualFilePathBuilder = gcnew StringBuilder(
            convertReadingsPath->Replace(".txt", ".log"),
            QCOM_MAXIMUM_FILE_PATH_LENGTH);
        bool promptResult = QCOM_PromptForSaveFile(
            String::Format(
                "Save the converted file for S/N {0}",
                utilConvertReadingsUnit->transducerSerialNumber),
            actualFilePathBuilder,
            nullptr,
            GUI_FILE_TYPE_LOG);
        actualFilePathString = actualFilePathBuilder->ToString();
        delete actualFilePathBuilder;
        if (promptResult == GUI_ACCEPT)
        {
            StreamWriter ^textWriter = File::CreateText(actualFilePathString);
            if (textWriter)
            {
                textWriter->WriteLine(fileText);
                textWriter->Close();
            }
        }
        delete [] lines;
        delete [] lineDelimiters;
    }                                   // end of if (StringSet(convertReadingsPath) && ...)
    else
    {
        if (StringSet(convertReadingsPath))
        {
            QCOM_PromptOKModal(
                "File Not Found",
                "File '{0}' is not found",
                convertReadingsPath);
        }
        else
        {
            QCOM_PromptOKModal(
                "Invalid Path",
                "Invalid file path specified");
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_UtilConvertReadingsProcessFile()
//----------------------------------------------------------------------------
// QCOM_UtilConvertTransducerCounts
//
// Converts the counts displayed in the fields into actual values, then
// displays the results
//
// Called by:   QCOM_ValidateConvertReadingsPressureCount
//              QCOM_ValidateConvertReadingsTemperatureCount
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertTransducerCounts(void)
{
    String          ^functionName = _T("QCOM_UtilConvertTransducerCounts");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (utilConvertReadingsUnit->flags & QCOM_UNIT_COEFFICIENTS_VERIFIED)
    {
        double pressurePSI = 0.0;
        double temperatureCelsius = 0.0;
        DWORD status = QD_CalculatePressureAndTemperature(
            (LPBYTE) utilConvertReadingsUnit->coefficientData,
            utilConvertReadingsUnit->pressureCount,
            utilConvertReadingsUnit->temperatureCount,
            &pressurePSI,
            &temperatureCelsius);
        if (status == QD_SUCCESS)
        {
            utilConvertReadingsPressureActualBox->Text = String::Format(
                "{0:F4}", pressurePSI);
            utilConvertReadingsTemperatureActualBox->Text = String::Format(
                "{0:F4}", temperatureCelsius);
            utilConvertReadingsPressureFrequencyBox->Text = String::Format(
                "{0:F3}",
                ((double) utilConvertReadingsUnit->pressureCount) * QCOM_FREQUENCY_MULTIPLIER);
            utilConvertReadingsTemperatureFrequencyBox->Text = String::Format(
                "{0:F3}",
                ((double) utilConvertReadingsUnit->temperatureCount) * QCOM_FREQUENCY_MULTIPLIER);
        }
        else
        {
            utilConvertReadingsPressureActualBox->Text = String::Format(
                "Error 0x{0:X8}", status);
            utilConvertReadingsTemperatureActualBox->Text = String::Format(
                "Error 0x{0:X8}", status);
            utilConvertReadingsPressureFrequencyBox->Text = String::Empty;
            utilConvertReadingsTemperatureFrequencyBox->Text = String::Empty;
        }
    }                                   // end of if (utilConvertReadingsUnit->flags & QCOM_UNIT_COEFFICIENTS_VERIFIED)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_UtilConvertTransducerCounts()
//----------------------------------------------------------------------------
// QCOM_UtilConvertTransducerFrequencies
//
// Converts the frequencies displayed in the fields into actual values, then
// displays the results
//
// Called by:   QCOM_ValidateConvertReadingsPressureFrequency
//              QCOM_ValidateConvertReadingsTemperatureFrequency
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_UtilConvertTransducerFrequencies(void)
{
    String          ^functionName = _T("QCOM_UtilConvertTransducerFrequencies");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (utilConvertReadingsUnit->flags & QCOM_UNIT_COEFFICIENTS_VERIFIED)
    {
        double pressurePSI = 0.0;
        double temperatureCelsius = 0.0;
        DWORD status = QD_CalculatePressureAndTemperature(
            (LPBYTE) utilConvertReadingsUnit->coefficientData,
            utilConvertReadingsUnit->pressureCount,
            utilConvertReadingsUnit->temperatureCount,
            &pressurePSI,
            &temperatureCelsius);
        if (status == QD_SUCCESS)
        {
            utilConvertReadingsPressureActualBox->Text = String::Format(
                "{0:F4}", pressurePSI);
            utilConvertReadingsTemperatureActualBox->Text = String::Format(
                "{0:F4}", temperatureCelsius);
            utilConvertReadingsPressureCountBox->Text = String::Format(
                "{0:D}",
                utilConvertReadingsUnit->pressureCount);
            utilConvertReadingsTemperatureCountBox->Text = String::Format(
                "{0:D}",
                utilConvertReadingsUnit->temperatureCount);
        }
        else
        {
            utilConvertReadingsPressureActualBox->Text = String::Format(
                "Error 0x{0:X8}", status);
            utilConvertReadingsTemperatureActualBox->Text = String::Format(
                "Error 0x{0:X8}", status);
            utilConvertReadingsPressureCountBox->Text = String::Empty;
            utilConvertReadingsTemperatureCountBox->Text = String::Empty;
        }
    }                                   // end of if (utilConvertReadingsUnit->flags & QCOM_UNIT_COEFFICIENTS_VERIFIED)
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_UtilConvertTransducerFrequencies()
//----------------------------------------------------------------------------
// QCOM_VerifyAndSendEmail
//
// Validates the contents of the specified email, then sends it if they appear
// valid
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_VerifyAndSendEmail(
    EmailInfo       ^emailInfo)
{
    int             numberOfBlankFields = 0;
    DWORD           status;
    String          ^blankFieldText;
    String          ^carbonAddress;
    String          ^emailAddress;
    String          ^returnAddress;
    String          ^sourceAddress;
    String          ^functionName = _T("QCOM_VerifyAndSendEmail");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (emailInfo && StringSet(emailInfo->toAddress) &&
        StringSet(emailInfo->fromAddress) &&
        StringSet(emailInfo->subjectString) &&
        StringSet(emailInfo->messageString))
    {
        emailAddress = emailInfo->toAddress;
        sourceAddress = emailInfo->fromAddress;
        //--------------------------------------------------------------------
        // Loosely verify the format of the email addresses
        //--------------------------------------------------------------------
        if (QCOM_EmailAddressFormatIsValid(emailAddress))
        {
            if (QCOM_EmailAddressFormatIsValid(sourceAddress))
            {
                QCOM_GeneralInfo->emailAddress = sourceAddress;
                //------------------------------------------------------------
                // Check for a carbon-copy address
                //------------------------------------------------------------
                carbonAddress = emailInfo->ccAddress;
                if (StringSet(carbonAddress))
                {
                    if (!QCOM_EmailAddressFormatIsValid(carbonAddress))
                    {
                        QCOM_PromptOKModal(
                            "Invalid Email Address",
                            "Email CC address '{0}' is invalid",
                            carbonAddress);
                    }
                }
                //------------------------------------------------------------
                // Check for a reply address
                //------------------------------------------------------------
                returnAddress = emailInfo->replyAddress;
                if (StringSet(returnAddress))
                {
                    if (!QCOM_EmailAddressFormatIsValid(returnAddress))
                    {
                        QCOM_PromptOKModal(
                            "Invalid Email Address",
                            "Email reply address '{0}' is invalid",
                            returnAddress);
                    }
                }
                //------------------------------------------------------------
                // Check for attachments
                //------------------------------------------------------------
                if (StringSet(emailInfo->attachment))
                {
                    if (!File::Exists(emailInfo->attachment))
                    {
                        QCOM_PromptOKModal(
                            "Email Attachment Missing",
                            "Attachment {0} could not be found",
                            emailInfo->attachment);
                    }
                }
                else
                {
                    for each (String ^attachmentFilePath in emailInfo->attachmentArray)
                    {
                        if (!File::Exists(attachmentFilePath))
                        {
                            QCOM_PromptOKModal(
                                "Email Attachment Missing",
                                "Attachment {0} could not be found",
                                attachmentFilePath);
                        }
                    }
                }
                //------------------------------------------------------------
                // Possible errors encountered up to this point are not
                // serious enough to prevent sending the email
                //------------------------------------------------------------
                emailToCombo->BackColor = Color::White;
                emailFromCombo->BackColor = Color::White;
                emailSubjectBox->BackColor = Color::White;
                emailMessageBox->BackColor = Color::White;
                emailStatusLabel->Text = _T("Email sent...awaiting confirmation");
                emailStatusLabel->ForeColor = Color::Purple;
                emailStatusLabel->Update();
                QCOM_PleaseWait(
                    GUI_PLEASE_WAIT_DISPLAY_NEW_TITLE,
                    "Sending Email");
                status = QCOM_SendEmailMessageStructure(emailInfo);
                QCOM_PleaseWait(GUI_PLEASE_WAIT_REMOVE, nullptr);
                if (status == QCOM_SUCCESS)
                {
                    emailStatusLabel->Text = _T("Email successfully sent");
                    emailStatusLabel->ForeColor = Color::Blue;
                    emailStatusLabel->Update();
                    QCOM_PromptOKModal(
                        "Send Email",
                        "Email successfully sent to\n{0}", emailAddress);
                }
                else
                {
                    emailStatusLabel->Text = _T("Email failed to send");
                    emailStatusLabel->ForeColor = Color::Red;
                    emailStatusLabel->Update();
                    GUI_DisplayMandatoryError(functionName,
                        "Failed to send email to\n{0}", emailAddress);
                }
            }                               // end of if (QCOM_EmailAddressFormatIsValid(sourceAddress))
            else
            {
                emailFromCombo->BackColor = Color::Yellow;
                QCOM_PromptOKModal(
                    "Invalid Email Address",
                    "Invalid 'From' email address");
            }
        }                               // end of if (QCOM_EmailAddressFormatIsValid(emailAddress))
        else
        {
            emailToCombo->BackColor = Color::Yellow;
            QCOM_PromptOKModal(
                "Invalid Email Address",
                "Invalid 'To' email address");
        }
    }                                   // end of if (emailInfo && ...)
    else
    {
        emailStatusLabel->ForeColor = Color::Red;
        if (emailInfo)
        {
            if (StringSet(emailInfo->toAddress))
            {
                emailToCombo->BackColor = Color::White;
            }
            else
            {
                numberOfBlankFields++;
                blankFieldText = _T("The 'To' field is blank");
                emailToCombo->BackColor = Color::Yellow;
            }
            if (StringSet(emailInfo->fromAddress))
            {
                emailFromCombo->BackColor = Color::White;
            }
            else
            {
                numberOfBlankFields++;
                blankFieldText = _T("The 'From' field is blank");
                emailFromCombo->BackColor = Color::Yellow;
            }
            if (StringSet(emailInfo->subjectString))
            {
                emailSubjectBox->BackColor = Color::White;
            }
            else
            {
                numberOfBlankFields++;
                blankFieldText = _T("The Subject field is blank");
                emailSubjectBox->BackColor = Color::Yellow;
            }
            if (StringSet(emailInfo->messageString))
            {
                emailMessageBox->BackColor = Color::White;
            }
            else
            {
                numberOfBlankFields++;
                blankFieldText = _T("The Message field is blank");
                emailMessageBox->BackColor = Color::Yellow;
            }
            emailStatusLabel->Text =
                (numberOfBlankFields == 1) ?
                blankFieldText :
                _T("Multiple fields are blank");
            QCOM_PromptOKModal(
                "Missing Email Fields",
                "Fill in the missing fields and try again");
        }                               // end of if (emailInfo)
        else
        {
            emailStatusLabel->Text = _T("The email structure is invalid");
            GUI_DisplayMandatoryError(functionName,
                "The email structure is invalid");
        }
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_VerifyAndSendEmail()
//----------------------------------------------------------------------------
// QCOM_VerifyHexFileFormat
//
// Determines whether the hex file data in the specified file is valid, by
// verifying it length fields, checksums, and other rules, including
// -   Each line must start with a ':' character
// -   The record type of each line must be "00" unless it is the last line
//     (file types of "02" and "04" are also permitted)
// -   The file must be in DOS text format, so each line must end with a
//     CR/LF pair
// -   The file must end with ":00000001FF"
//
// Note:    The address fields are not verified
//
// Note:    This was patterned after QD_HexFileFormatIsValid
//
// Called by:   QCOM_PromptAndVerifyHexFile
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_VerifyHexFileFormat(
    String          ^filePathString)
{
    bool            correctTheFile;
    bool            dataIsValid = GUI_YES;  // innocent until proven guilty
    bool            isCoefficientDataFile = GUI_NO;
    bool            promptResult = GUI_CANCEL;
    int             CFTotalBytes = 0;
    int             extendedAddress = 0;
//    int             offset;
    int             lineNumber = 0;         // 1-relative 'line' number
    int             numberOfBadChecksums = 0;
    int             numberOfBadLengths = 0;
    int             numberOfBadTerminations = 0;
    int             recordAddress;
    int             recordLength;
    int             recordType;
    int             terminationDifference;
    char            *binaryFileData;
    char            *CFChecksumLine = (char *) 0;
    char            *CFChecksumPointer;
    char            *filePath;
    char            *hexFileData;
    char            *hexFileLine;
    char            *lastPeriodLocation;
    char            *nextCRLFPair;
    char            transducerSerialNumber[8];
    unsigned        CFChecksumActual = 0;
    unsigned        CFChecksumSpecified;
    unsigned        checksumActual;
    unsigned        checksumSpecified;
    BYTE            *coefficientData;
    long            binaryFileSize;
    long            bufferSize = 0;
    long            bytesRead;
    long            fileSize;
    errno_t         result;
    FILE            *filePointer;
    array <Byte>    ^binaryFileContents;
    String          ^promptString;
    String          ^transducerSerialNumberString;
//    StreamReader    ^textReader;
//    StreamWriter    ^textWriter;
    String          ^functionName = _T("QCOM_VerifyHexFileFormat");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(filePathString))
    {
        filePath = (char *) malloc(QCOM_MAXIMUM_FILE_PATH_LENGTH);
        if (filePath)
        {
            if (File::Exists(filePathString))
            {
                FileInfo ^filePathInfo = gcnew FileInfo(filePathString);
                fileSize = (long) filePathInfo->Length;
                delete filePathInfo;
                QCOM_ConvertString(
                    filePathString,
                    filePath,
                    QCOM_MAXIMUM_FILE_PATH_LENGTH);
                //------------------------------------------------------------
                // Open the file
                //------------------------------------------------------------
                result = fopen_s(&filePointer, filePath, "rb");
                if (filePointer && (result == 0))
                {
                    hexFileData = (char *) malloc(fileSize * 2);
                    if (hexFileData)
                    {
                        //----------------------------------------------------
                        // Input the contents of the entire file
                        //----------------------------------------------------
                        bytesRead = fread((void *) hexFileData, 1, fileSize, filePointer);
                        fclose(filePointer);
                        if (bytesRead == fileSize)
                        {
                            bytesRead = 0;
                            hexFileLine = (char *) hexFileData;
                            do
                            {
                                lineNumber++;
                                if ((hexFileLine[0] == ':'))
                                {
                                    recordLength =
                                        ((AtoX(hexFileLine[1]) << 4) & 0xF0) | (AtoX(hexFileLine[2]) & 0x0F);
                                    recordType =
                                        ((AtoX(hexFileLine[7]) << 4) & 0xF0) | (AtoX(hexFileLine[8]) & 0x0F);
                                    switch (recordType)
                                    {
                                        case 0x00 :
                                            {
                                                recordAddress =
                                                    ((AtoX(hexFileLine[3]) << 12) & 0xF000) |
                                                    ((AtoX(hexFileLine[4]) << 8) & 0x0F00) |
                                                    ((AtoX(hexFileLine[5]) << 4) & 0x00F0) |
                                                    (AtoX(hexFileLine[6]) & 0x000F);
                                                //--------------------------------------------------
                                                // At this point, the actual buffer address is
                                                // recordAddress + extendedAddress for the start of
                                                // the data contained in this line
                                                //--------------------------------------------------
                                                bufferSize = max(bufferSize, (recordAddress + extendedAddress + recordLength));
                                                //--------------------------------------------------
                                                // Determine whether this happens to be a
                                                // coefficient data hex file
                                                //--------------------------------------------------
                                                if ((recordAddress == 0x0000) &&
                                                    (recordLength >= 4) &&
                                                    (memcmp(&hexFileLine[9], "0D", 2) == 0) &&
                                                    (memcmp(&hexFileLine[17], "0D", 2) == 0))
                                                {
                                                    isCoefficientDataFile = GUI_YES;
                                                    ClearBuffer(transducerSerialNumber, 8);
                                                    memcpy(transducerSerialNumber, &hexFileLine[19], 6);
                                                    transducerSerialNumberString = gcnew String(transducerSerialNumber);
                                                    if (!filePathString->Contains(transducerSerialNumberString))
                                                    {
                                                        GUI_DisplayMandatoryError(functionName,
                                                            "You selected hex (coefficient) data file\n{0}\n\n"
                                                            "The file contains a different serial number ({1})\n"
                                                            "from that represented by its filename",
                                                            filePathString,
                                                            transducerSerialNumberString);
                                                        dataIsValid = GUI_NO;
                                                    }
                                                }
                                                nextCRLFPair = &hexFileLine[(recordLength * 2) + 11];
                                                if (nextCRLFPair[0] != QCOM_CHAR_CR)
                                                {
                                                    if ((nextCRLFPair[0] == ':') || (nextCRLFPair[1] == ':'))
                                                    {
                                                        numberOfBadTerminations++;
                                                        GUI_DisplayMandatoryError(functionName,
                                                            "You selected hex{0}data file\n{1}\n\n"
                                                            "Invalid (but correctable) termination in\n"
                                                            "line {2:D} of the hex data file",
                                                            (isCoefficientDataFile ? _T(" (coefficient) ") : QCOM_STRING_SPACE),
                                                            filePathString,
                                                            lineNumber);
                                                        if (nextCRLFPair[0] == ':')
                                                        {
                                                            fileSize += 2;
                                                            memmove(&nextCRLFPair[2], &nextCRLFPair[0], (fileSize - bytesRead));
                                                        }
                                                        else
                                                        {
                                                            if (nextCRLFPair[1] == ':')
                                                            {
                                                                fileSize++;
                                                                memmove(&nextCRLFPair[2], &nextCRLFPair[1], (fileSize - bytesRead));
                                                            }
                                                        }
                                                        nextCRLFPair[0] = QCOM_CHAR_CR;
                                                        nextCRLFPair[1] = QCOM_CHAR_LF;
                                                    }
                                                }
                                                //--------------------------------------------------
                                                // Check for proper line termination
                                                //--------------------------------------------------
                                                if ((hexFileLine[(recordLength * 2) + 11] == QCOM_CHAR_CR) &&
                                                    (hexFileLine[(recordLength * 2) + 12] == QCOM_CHAR_LF))
                                                {
                                                    if (isCoefficientDataFile)
                                                    {
                                                        CFTotalBytes += recordLength;
                                                        for (int offset = 9; offset < ((recordLength * 2) + 9); offset += 2)
                                                        {
                                                            //--------------------------------------
                                                            // Determine whether this offset is where
                                                            // the coefficient data checksum is stored
                                                            //--------------------------------------
                                                            if ((offset % 2) && (recordAddress + ((offset - 9) / 2)) == 0xFF)
                                                            {
                                                                CFChecksumLine = hexFileLine;
                                                                CFChecksumPointer = &hexFileLine[offset];
                                                                CFChecksumSpecified =
                                                                    ((AtoX(CFChecksumPointer[0]) << 4) & 0xF0) |
                                                                    (AtoX(CFChecksumPointer[1]) & 0x0F);
                                                            }
                                                            else
                                                            {
                                                                CFChecksumActual +=
                                                                    ((AtoX(hexFileLine[offset]) << 4) & 0xF0) |
                                                                    (AtoX(hexFileLine[offset + 1]) & 0x0F);
                                                            }
                                                        }
                                                    }
                                                    checksumSpecified =
                                                        ((AtoX(hexFileLine[(recordLength * 2) + 9]) << 4) & 0xF0) |
                                                        (AtoX(hexFileLine[(recordLength * 2) + 10]) & 0x0F);
                                                    //----------------------------------------------
                                                    // Calculate the checksum for this line
                                                    //----------------------------------------------
                                                    checksumActual = 0;
                                                    for (int offset = 1; offset < ((recordLength * 2) + 9); offset += 2)
                                                    {
                                                        checksumActual +=
                                                            ((AtoX(hexFileLine[offset]) << 4) & 0xF0) |
                                                            (AtoX(hexFileLine[offset + 1]) & 0x0F);
                                                    }
                                                    checksumActual = (~checksumActual + 1) & 0xFF;
                                                    if (checksumActual != checksumSpecified)
                                                    {
                                                        numberOfBadChecksums++;
                                                        GUI_DisplayMandatoryError(functionName,
                                                            "You selected hex{0}data file\n{1}\n\n"
                                                            "Invalid checksum in line {2:D} of the hex data file is\n"
                                                            "listed as {3:X2} but should be {4:X2}",
                                                            (isCoefficientDataFile ? _T(" (coefficient) ") : QCOM_STRING_SPACE),
                                                            filePathString,
                                                            lineNumber, checksumSpecified, checksumActual);
                                                        //------------------------------------------
                                                        // Correct the checksum in memory
                                                        //------------------------------------------
                                                        hexFileLine[(recordLength * 2) + 9] = XtoA(checksumActual >> 4);
                                                        hexFileLine[(recordLength * 2) + 10] = XtoA(checksumActual);
                                                    }
                                                    //----------------------------------------------
                                                    // Advance to the next line
                                                    //----------------------------------------------
                                                    hexFileLine = &hexFileLine[(recordLength * 2) + 13];
                                                }
                                                else
                                                {
                                                    nextCRLFPair = strchr(hexFileLine, QCOM_CHAR_CR);
                                                    while (nextCRLFPair && ((nextCRLFPair[0] != QCOM_CHAR_CR) || (nextCRLFPair[1] != QCOM_CHAR_LF)))
                                                    {
                                                        nextCRLFPair++;
                                                        if (((long) (nextCRLFPair - ((char *) hexFileData))) > fileSize)
                                                            nextCRLFPair = (char *) 0;
                                                    }
                                                    if (nextCRLFPair && ((nextCRLFPair[0] == QCOM_CHAR_CR) && (nextCRLFPair[1] == QCOM_CHAR_LF)))
                                                    {
                                                        terminationDifference = ((int) (nextCRLFPair - hexFileLine)) - ((recordLength * 2) + 11);
                                                        GUI_DisplayMandatoryError(functionName,
                                                            "You selected hex{0}data file\n{1}\n\n"
                                                            "Line {2:D} {3} {4:D} character{5}{6}",
                                                            (isCoefficientDataFile ? _T(" (coefficient) ") : QCOM_STRING_SPACE),
                                                            filePathString,
                                                            lineNumber,
                                                            ((terminationDifference > 0) ? "contains" : "is missing"),
                                                            abs(terminationDifference),
                                                            ((abs(terminationDifference) == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                                                            ((terminationDifference > 0) ? _T(" too many") : QCOM_STRING_EMPTY));
                                                        if ((abs(terminationDifference) % 2) || isCoefficientDataFile)
                                                        {
                                                            dataIsValid = GUI_NO;
                                                        }
                                                        else
                                                        {
                                                            numberOfBadLengths++;
                                                            if (terminationDifference > 0)
                                                            {
                                                                recordLength -= (terminationDifference / 2);
                                                            }
                                                            else
                                                            {
                                                                recordLength += (terminationDifference / 2);
                                                            }
                                                            hexFileLine[1] = XtoA(recordLength >> 4);
                                                            hexFileLine[2] = XtoA(recordLength);
                                                            checksumActual = 0;
                                                            for (int offset = 1; offset < ((recordLength * 2) + 9); offset += 2)
                                                            {
                                                                checksumActual +=
                                                                    ((AtoX(hexFileLine[offset]) << 4) & 0xF0) |
                                                                    (AtoX(hexFileLine[offset + 1]) & 0x0F);
                                                            }
                                                            checksumActual = (~checksumActual + 1) & 0xFF;
                                                            //--------------------------------------
                                                            // Correct the checksum in memory
                                                            //--------------------------------------
                                                            hexFileLine[(recordLength * 2) + 9] = XtoA(checksumActual >> 4);
                                                            hexFileLine[(recordLength * 2) + 10] = XtoA(checksumActual);
                                                        }
                                                        //------------------------------------------
                                                        // Advance to the next line
                                                        //------------------------------------------
                                                        hexFileLine = &nextCRLFPair[2];
                                                    }
                                                    else
                                                    {
                                                        GUI_DisplayMandatoryError(functionName,
                                                            "You selected hex{0}data file\n{1}\n\n"
                                                            "Line {2:D} is not properly terminated (with a CR/LF pair)\n"
                                                            "and will not be repaired",
                                                            (isCoefficientDataFile ? _T(" (coefficient) ") : QCOM_STRING_SPACE),
                                                            filePathString,
                                                            lineNumber);
                                                        dataIsValid = GUI_NO;
                                                    }
                                                }
                                            }
                                            break;

                                        case 0x01 :
                                            if (_strnicmp(hexFileLine, ":00000001FF", 11))
                                            {
                                                GUI_DisplayMandatoryError(functionName,
                                                    "You selected hex{0}data file\n{1}\n\n"
                                                    "The terminating line (line {2:D}) is formatted incorrectly",
                                                    (isCoefficientDataFile ? _T(" (coefficient) ") : QCOM_STRING_SPACE),
                                                    filePathString,
                                                    lineNumber);
                                                dataIsValid = GUI_NO;
                                            }
                                            else
                                            {
                                                hexFileLine = &hexFileLine[13];
                                            }
                                            break;

                                        case 0x02 :
                                        case 0x04 :
                                        case 0x05 :
                                            if (recordType == 0x05)
                                            {
                                                extendedAddress =
                                                    ((AtoX(hexFileLine[9]) << 28) & 0xF0000000) |
                                                    ((AtoX(hexFileLine[10]) << 24) & 0x0F000000) |
                                                    ((AtoX(hexFileLine[11]) << 20) & 0x00F00000) |
                                                    ((AtoX(hexFileLine[12]) << 16) & 0x000F0000) |
                                                    ((AtoX(hexFileLine[13]) << 12) & 0x0000F000) |
                                                    ((AtoX(hexFileLine[14]) << 8) & 0x00000F00) |
                                                    ((AtoX(hexFileLine[15]) << 4) & 0x000000F0) |
                                                    (AtoX(hexFileLine[16]) & 0x0000000F);
                                                //--------------------------------------------------
                                                // Note: extendedAddress is the EIP register value
                                                // for the subsequent code data
                                                //--------------------------------------------------
                                            }
                                            else
                                            {
                                                extendedAddress =
                                                    ((AtoX(hexFileLine[9]) << 12) & 0xF000) |
                                                    ((AtoX(hexFileLine[10]) << 8) & 0x0F00) |
                                                    ((AtoX(hexFileLine[11]) << 4) & 0x00F0) |
                                                    (AtoX(hexFileLine[12]) & 0x000F);
                                                if (recordType == 0x02)
                                                {
                                                    extendedAddress = (extendedAddress << 4) & 0xFFFF0;
                                                }
                                                else
                                                {
                                                    extendedAddress = (extendedAddress << 16) & 0xFFFF0000;
                                                }
                                            }
                                            checksumSpecified =
                                                ((AtoX(hexFileLine[(recordLength * 2) + 9]) << 4) & 0xF0) |
                                                (AtoX(hexFileLine[(recordLength * 2) + 10]) & 0x0F);
                                            //------------------------------------------------------
                                            // Calculate the checksum for this line
                                            //------------------------------------------------------
                                            checksumActual = 0;
                                            for (int offset = 1; offset < ((recordLength * 2) + 9); offset += 2)
                                            {
                                                checksumActual +=
                                                    ((AtoX(hexFileLine[offset]) << 4) & 0xF0) |
                                                    (AtoX(hexFileLine[offset + 1]) & 0x0F);
                                            }
                                            checksumActual = (~checksumActual + 1) & 0xFF;
                                            if (checksumActual != checksumSpecified)
                                            {
                                                numberOfBadChecksums++;
                                                GUI_DisplayMandatoryError(functionName,
                                                    "You selected hex{0}data file\n{1}\n\n"
                                                    "Invalid checksum in line {2:D} of the hex data file is\n"
                                                    "listed as {3:X2} but should be {4:X2}",
                                                    (isCoefficientDataFile ? _T(" (coefficient) ") : QCOM_STRING_SPACE),
                                                    filePathString,
                                                    lineNumber, checksumSpecified, checksumActual);
                                                //--------------------------------------------------
                                                // Correct the checksum in memory
                                                //--------------------------------------------------
                                                hexFileLine[(recordLength * 2) + 9] = XtoA(checksumActual >> 4);
                                                hexFileLine[(recordLength * 2) + 10] = XtoA(checksumActual);
                                            }
                                            //------------------------------------------------------
                                            // Advance to the next line
                                            //------------------------------------------------------
                                            hexFileLine = &hexFileLine[(recordLength * 2) + 13];
                                            break;

                                        default :
                                            GUI_DisplayMandatoryError(functionName,
                                                "You selected hex{0}data file\n{1}\n\n"
                                                "Record type 0x{2:X2} (line {3:D}) is not recognized",
                                                (isCoefficientDataFile ? _T(" (coefficient) ") : QCOM_STRING_SPACE),
                                                filePathString,
                                                recordType, lineNumber);
                                            dataIsValid = GUI_NO;
                                            break;
                                    }   // end of switch (recordType)
                                }       // end of if ((hexFileLine[0] == ':'))
                                else
                                {
                                    if ((hexFileLine[0] == QCOM_CHAR_CR) || (hexFileLine[0] == QCOM_CHAR_LF))
                                    {
                                        hexFileLine++;
                                    }
                                    if ((hexFileLine[0] == QCOM_CHAR_CR) || (hexFileLine[0] == QCOM_CHAR_LF))
                                    {
                                        hexFileLine++;
                                    }
                                    if ((hexFileLine[0] != ':') && ((hexFileLine - (char *) hexFileData) < fileSize))
                                    {
                                        GUI_DisplayMandatoryError(functionName,
                                            "You selected hex{0}data file\n{1}\n\n"
                                            "Missing the starting ':' character on line {2:D}",
                                            (isCoefficientDataFile ? _T(" (coefficient) ") : QCOM_STRING_SPACE),
                                            filePathString,
                                            lineNumber);
                                        dataIsValid = GUI_NO;
                                    }
                                }
                                bytesRead = (long) (hexFileLine - (char *) hexFileData);
                            }
                            while ((bytesRead < fileSize) && dataIsValid);
                            //----------------------------------------------------------------------
                            // Act on the information discovered to this point
                            //----------------------------------------------------------------------
                            if (isCoefficientDataFile && dataIsValid)
                            {
                                if (CFTotalBytes == QD_COEFFICIENT_DATA_SIZE)
                                {
                                    //--------------------------------------------------------------
                                    // Validate the expected coefficient data by the DLL
                                    //--------------------------------------------------------------
                                    coefficientData = (LPBYTE) malloc(QD_COEFFICIENT_DATA_SIZE);
                                    if (coefficientData)
                                    {
                                        DWORD numberOfDataBytes = QD_UnFormatHexFileData(
                                            (LPBYTE) hexFileData,
                                            (LPBYTE) coefficientData);
                                        if (numberOfDataBytes == QD_COEFFICIENT_DATA_SIZE)
                                        {
                                            dataIsValid = QD_CoefficientDataIsValid(
                                                (LPBYTE) coefficientData);
                                            if (!dataIsValid)
                                            {
                                                //--------------------------------------------------
                                                // This modal message is temporary
                                                //--------------------------------------------------
                                                GUI_DisplayMandatoryError(functionName,
                                                    "You selected coefficient data file\n{0}\n\n"
                                                    "The DLL reports that the file data is invalid",
                                                    filePathString);
                                                //--------------------------------------------------
                                                // dataIsValid must be set to True so that
                                                // pending corrections can be made
                                                //--------------------------------------------------
                                                dataIsValid = GUI_YES;
                                                //--------------------------------------------------
                                                // Determine the reason(s) for the failure
                                                //--------------------------------------------------
                                            }
                                        }
                                        else
                                        {
                                        }
                                        free((void *) coefficientData);
                                    }   // end of if (coefficientData)
                                    //--------------------------------------------------------------
                                    // Determine the validity of the coefficient data checksum
                                    //--------------------------------------------------------------
                                    CFChecksumActual = (~CFChecksumActual + 1) & 0xFF;
                                    if (CFChecksumActual != CFChecksumSpecified)
                                    {
                                        numberOfBadChecksums++;
                                        GUI_DisplayMandatoryError(functionName,
                                            "You selected hex{0}data file\n{1}\n\n"
                                            "Invalid coefficient data checksum of {2:X2}\n"
                                            "should be {3:X2}",
                                            (isCoefficientDataFile ? _T(" (coefficient) ") : QCOM_STRING_SPACE),
                                            filePathString,
                                            CFChecksumSpecified, CFChecksumActual);
                                        CFChecksumPointer[0] = XtoA(CFChecksumActual >> 4);
                                        CFChecksumPointer[1] = XtoA(CFChecksumActual);
                                        if (CFChecksumLine)
                                        {
                                            recordLength =
                                                ((AtoX(CFChecksumLine[1]) << 4) & 0xF0) | (AtoX(CFChecksumLine[2]) & 0x0F);
                                            checksumSpecified =
                                                ((AtoX(CFChecksumLine[(recordLength * 2) + 9]) << 4) & 0xF0) |
                                                (AtoX(CFChecksumLine[(recordLength * 2) + 10]) & 0x0F);
                                            checksumActual = 0;
                                            for (int offset = 1; offset < ((recordLength * 2) + 9); offset += 2)
                                            {
                                                checksumActual +=
                                                    ((AtoX(CFChecksumLine[offset]) << 4) & 0xF0) |
                                                    (AtoX(CFChecksumLine[offset + 1]) & 0x0F);
                                            }
                                            checksumActual = (~checksumActual + 1) & 0xFF;
                                            if (checksumActual != checksumSpecified)
                                            {
                                                CFChecksumLine[(recordLength * 2) + 9] = XtoA(checksumActual >> 4);
                                                CFChecksumLine[(recordLength * 2) + 10] = XtoA(checksumActual);
                                            }
                                        }
                                    }   // end of if (CFChecksumActual != CFChecksumSpecified)
                                }       // end of if (CFTotalBytes == QD_COEFFICIENT_DATA_SIZE)
                                else
                                {
                                    GUI_DisplayMandatoryError(functionName,
                                        "You selected hex (coefficient) data file\n{0}\n\n"
                                        "The coefficient data is {1:D} byte{2}\n"
                                        "{3} of a valid coefficient data set",
                                        filePathString,
                                        abs(QD_COEFFICIENT_DATA_SIZE - CFTotalBytes),
                                        ((abs(QD_COEFFICIENT_DATA_SIZE - CFTotalBytes) == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                                        ((QD_COEFFICIENT_DATA_SIZE > CFTotalBytes) ? "short" : "in excess"));
                                    dataIsValid = GUI_NO;
                                }
                            }           // end of if (isCoefficientDataFile && dataIsValid)
                            //------------------------------------------------
                            // Correct inaccuracies that could be corrected
                            //------------------------------------------------
                            if (dataIsValid &&
                                (numberOfBadChecksums || numberOfBadLengths || numberOfBadTerminations))
                            {
                                if (numberOfBadChecksums && (numberOfBadLengths || numberOfBadTerminations))
                                {
                                    promptString = String::Format(
                                        "Correct the invalid line{0} and checksum{1} ?",
                                        ((numberOfBadLengths == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S),
                                        ((numberOfBadChecksums == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S));
                                }
                                else
                                {
                                    if (numberOfBadChecksums)
                                    {
                                        promptString = String::Format(
                                            "Correct the invalid checksum{0} ?",
                                            ((numberOfBadChecksums == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S));
                                    }
                                    else
                                    {
                                        promptString = String::Format(
                                            "Correct the invalid line{0} ?",
                                            ((numberOfBadLengths == 1) ? QCOM_STRING_EMPTY : QCOM_STRING_S));
                                    }
                                }
                                correctTheFile = QCOM_PromptModal(
                                    "Correct The File",
                                    promptString);
                                if (correctTheFile)
                                {
                                    StringBuilder ^filePathBuilder =
                                        gcnew StringBuilder(filePathString, QCOM_MAXIMUM_FILE_PATH_LENGTH);
                                    promptResult = QCOM_PromptForSaveFile(
                                        "Save Corrected Hex File",
                                        filePathBuilder,
                                        filePathString,
                                        GUI_FILE_TYPE_HEX);
                                    filePathString = filePathBuilder->ToString();
                                    delete filePathBuilder;
                                    QCOM_ConvertString(
                                        filePathString,
                                        filePath,
                                        QCOM_MAXIMUM_FILE_PATH_LENGTH);
                                    if (promptResult)
                                    {
                                        array <Byte> ^hexFileContents = gcnew array <Byte> (fileSize);
                                        for (long index = 0; index < fileSize; index++)
                                        {
                                            hexFileContents[index] = (Byte) hexFileData[index];
                                        }
                                        QCOM_SaveBinaryData(
                                            hexFileContents,
                                            filePathString);
                                        delete [] hexFileContents;
                                    }
                                }       // end of if (correctTheFile)
                                else
                                {
                                    dataIsValid = GUI_NO;
                                }
                            }           // end of if (dataIsValid && (numberOfBadChecksums || numberOfBadLengths || numberOfBadTerminations))
                        }               // end of if (bytesRead == fileSize)
                        else
                        {
                            GUI_DisplayMandatoryError(functionName,
                                "Hex data file located at\n{0}\n"
                                "has a file size ({1:D} bytes) that does not match\n"
                                "that ({2:D} bytes) registered with the file system",
                                filePathString,
                                bytesRead, fileSize);
                            dataIsValid = GUI_NO;
                        }
                        free((void *) hexFileData);
                    }                   // end of if (hexFileData)
                    else
                    {
                        fclose(filePointer);
                        GUI_DisplayMandatoryError(functionName,
                            "Not enough memory to test hex data file");
                    }
                }                       // end of if (filePointer && (result == 0))
                else
                {
                    GUI_DisplayMandatoryError(functionName,
                        "Hex data file located at\n{0}\n"
                        "could not be opened",
                        filePathString);
                    dataIsValid = GUI_NO;
                }
            }                           // end of if (File::Exists(filePathString))
            else
            {
                GUI_DisplayMandatoryError(functionName,
                    "Hex data file\n{0}\ncould not be found",
                    filePathString);
                dataIsValid = GUI_NO;
            }
            //----------------------------------------------------------------
            // Analysis and processing are complete
            //----------------------------------------------------------------
            if (dataIsValid && !numberOfBadChecksums)
            {
                //------------------------------------------------------------
                // The file appears intact
                //------------------------------------------------------------
                if (isCoefficientDataFile)
                {
                    //--------------------------------------------------------
                    // This appears to be a coefficient data file, so offer to
                    // display its contents
                    //--------------------------------------------------------
                    bool proceedToDisplayFile = QCOM_PromptModal(
                        "Verify Hex File",
                        "You selected hex (coefficient) data file\n{0}\n\n"
                        "The hex file data is verified and results\n"
                        "in a data size of {1:D} bytes. Display the\n"
                        "contents of the coefficient data file?",
                        filePathString,
                        bufferSize);
                    if (proceedToDisplayFile)
                    {
                        QCOM_DisplayHexCFParameters(
                            filePathString,
                            GUI_SECONDARY_DISPLAY);
                    }                   // end of if (proceedToDisplayFile)
                }                       // end of if (isCoefficientDataFile)
                else
                {
                    //--------------------------------------------------------
                    // This appears to be a non-coefficient data hex file, so
                    // offer to save its contents as a binary file
                    //--------------------------------------------------------
                    bool proceedToSaveFile = QCOM_PromptModal(
                        "Verify Hex File",
                        "You selected hex data file\n{0}\n\n"
                        "The hex file data is verified and results\n"
                        "in a data size of {1:D} bytes. Save the\n"
                        "resulting raw data as a binary file?",
                        filePathString,
                        bufferSize);
                    if (proceedToSaveFile)
                    {
                        binaryFileData = (char *) malloc(bufferSize);
                        hexFileData = (char *) malloc(fileSize * 2);
                        if (binaryFileData && hexFileData)
                        {
                            ClearBuffer(binaryFileData, bufferSize);
                            ClearBuffer(hexFileData, fileSize * 2);
                            BinaryReader ^readStream = ReadBinary(filePathString);
                            if (readStream)
                            {
                                //--------------------------------------------
                                //  1.  Get hexFileContents
                                //  2.  hexFileContents => hexFileData
                                //  3.  QD_UnFormatHexFileData( hexFileData => binaryFileData )
                                //  4.  binaryFileData => binaryFileContents
                                //--------------------------------------------
                                array <Byte> ^hexFileContents;
                                hexFileContents = readStream->ReadBytes(fileSize);
                                readStream->Close();
                                delete readStream;
                                for (long index = 0; index < fileSize; index++)
                                {
                                    hexFileData[index] = (char) hexFileContents[index];
                                }
                                binaryFileSize = QD_UnFormatHexFileData(
                                    (LPBYTE) hexFileData,
                                    (LPBYTE) binaryFileData);
                                binaryFileContents = gcnew array <Byte> (binaryFileSize);
                                for (long index = 0; index < binaryFileSize; index++)
                                {
                                    binaryFileContents[index] = (Byte) binaryFileData[index];
                                }
                                delete [] hexFileContents;
                            }
                            lastPeriodLocation = strrchr(filePath, '.');
                            if (lastPeriodLocation)
                            {
                                *lastPeriodLocation = QCOM_CHAR_NULL;
                            }
                            StringBuilder ^filePathBuilder =
                                gcnew StringBuilder(filePathString, QCOM_MAXIMUM_FILE_PATH_LENGTH);
                            proceedToSaveFile = QCOM_PromptForSaveFile(
                                "Save Binary Version",
                                filePathBuilder,
                                nullptr,
                                GUI_FILE_TYPE_BIN);
                            filePathString = filePathBuilder->ToString();
                            delete filePathBuilder;
                            QCOM_ConvertString(
                                filePathString,
                                filePath,
                                QCOM_MAXIMUM_FILE_PATH_LENGTH);
                            if (proceedToSaveFile == GUI_ACCEPT)
                            {
                                QCOM_SaveBinaryData(
                                    binaryFileContents,
                                    filePathString);
                            }
                            free((void *) hexFileData);
                            free((void *) binaryFileData);
                        }               // end of if (binaryFileData && hexFileData)
                    }                   // end of if (proceedToSaveFile)
                }                       // end of else of if (isCoefficientDataFile)
            }                           // end of if (dataIsValid && !numberOfBadChecksums)
            free((void *) filePath);
        }                               // end of if (filePath)
    }                                   // end of if (StringSet(filePathString))
    else
    {
        GUI_DisplayMandatoryError(functionName,
            "No hex data file specified");
    }
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_VerifyHexFileFormat()
//----------------------------------------------------------------------------
// QCOM_ZipFiles
//
// Creates the specified .zip file from the collection of files indicated by
// the specified array of files
//
// Note:    The resulting .zip file will contain a file called
//          [Content_Types].xml when it is unZIPped. This file contains content
//          information about the types of files included in the .zip file, and
//          and is explained on http://www.codeproject.com/KB/vb/ZipDemo.aspx
//          under "Points of Interest"
//
// Note:    This function requires WindowsBase.dll
//----------------------------------------------------------------------------
    void QCOM_GUIClass::
QCOM_ZipFiles(
    array <String ^>
                    ^filesToZip,
    String          ^zipFileName)
{
    String          ^functionName = _T("QCOM_ZipFiles");
    //------------------------------------------------------------------------
    RecordBasicEvent("{0} called", functionName);
    if (StringSet(filesToZip) && StringSet(zipFileName))
    {
        Package ^zipPackage = Package::Open(zipFileName, FileMode::Create);
        for each (String ^pathString in filesToZip)
        {
            if (pathString && File::Exists(pathString) &&
                StringICompare(pathString, zipFileName))
            {
                FileInfo ^pathInfo = gcnew FileInfo(pathString);
                //------------------------------------------------------------
                // Don't attempt to package files larger than 2 MB
                //
                // Attempting to package a file larger than 25 MB will result
                // in a Data Error exception, so exclude those files from the
                // package
                //------------------------------------------------------------
                if (pathInfo->Length > 2000000)
                {
                    QCOM_PromptOKModal(
                        "File Too Big",
                        "File is too large to ZIP and will be skipped:\n{0}",
                        pathString);
                }
                else
                {
                    bool includeThisFile = GUI_YES;
                    for each (String ^fileString in filesToZip)
                    {
                        //----------------------------------------------------
                        // If a file with a duplicate filename exists in the
                        // array, take the one with the later date
                        //----------------------------------------------------
                        if (StringICompare(Path::GetFileName(pathString), Path::GetFileName(fileString)) == 0)
                        {
                            FileInfo ^fileInfo = gcnew FileInfo(fileString);
                            if (fileInfo->LastAccessTime > pathInfo->LastAccessTime)
                            {
                                includeThisFile = GUI_NO;
                                break;
                            }
                        }
                    }                   // end of for each (String ^fileString in filesToZip)
                    if (includeThisFile)
                    {
                        String ^zipURI = String::Concat(
                            "/", Path::GetFileName(pathString)->Replace(' ', '_'));
                        Uri ^partURI = gcnew Uri(zipURI, UriKind::Relative);
                        PackagePart ^packagePart = zipPackage->CreatePart(
                            partURI,
                            MediaTypeNames::Application::Zip,
                            CompressionOption::Normal);
                        array <Byte> ^fileBytes = File::ReadAllBytes(pathString);
                        packagePart->GetStream()->Write(fileBytes, 0, fileBytes->Length);
                        delete [] fileBytes;
                        delete partURI;
                    }                   // end of if (includeThisFile)
                }                       // end of else of if (pathInfo->Length > 26300000)
                delete pathInfo;
            }                           // end of if (pathString && ...)
        }                               // end of for each (String ^pathString in filesToZip)
        zipPackage->Close();
        delete zipPackage;
    }                                   // end of if (StringSet(filesToZip) && StringSet(zipFileName))
    RecordBasicEvent("{0} concluded", functionName);
}                                       // end of QCOM_ZipFiles()
//----------------------------------------------------------------------------
// QCOM_CalculatePercentage
//
// Calculates an integer (whole number) percentage
//
// Returns: The result of the integer percentage calculation
//----------------------------------------------------------------------------
    int
QCOM_CalculatePercentage(
    DWORD           dividend,
    DWORD           divisor)
{
    int             quotient = 0;
    DWORD           holder;
    //------------------------------------------------------------------------
    if (dividend && divisor)
    {
        //--------------------------------------------------------------------
        // Multiply by 10 twice using the fast multiply
        //--------------------------------------------------------------------
        holder = Mult10(dividend);
        holder = Mult10(holder);
        //--------------------------------------------------------------------
        // perform the integer (div) division
        //--------------------------------------------------------------------
        quotient = (int) (holder / divisor);
    }
    return quotient;
}                                       // end of QCOM_CalculatePercentage()
//----------------------------------------------------------------------------
// QCOM_ConvertString
//
// Converts a String ^string to a char *string
//
// Returns unmanagedString
//----------------------------------------------------------------------------
    char *
QCOM_ConvertString(
    String          ^managedString,
    char            *unmanagedString,
    size_t          unmanagedBufferSize)
{
    size_t          returnValue;
    //------------------------------------------------------------------------
    if (managedString && unmanagedString)
    {
        if (managedString->Length)
        {
            pin_ptr <const wchar_t> widePtr = PtrToStringChars(managedString);
            wcstombs_s(
                &returnValue,
                unmanagedString,
                unmanagedBufferSize,
                widePtr,
                ((wcslen(widePtr) >= unmanagedBufferSize) ? _TRUNCATE : wcslen(widePtr)));
        }
        else
        {
            ClearBuffer(unmanagedString, unmanagedBufferSize);
        }
    }
    return unmanagedString;
}                                       // end of QCOM_ConvertString()
//----------------------------------------------------------------------------
// QCOM_ModalMessage
//
// Displays a modal message, using variable arguments, but does not pause
// program activity
//
// Note:    Because this function uses the String::Format method to format the
//          arguments into a single managed string, the calling convention
//          should look similar to
//
//          char    *unmanagedString = "Testing";
//          DWORD   status = QCOM_SUCCESS;
//          . . .
//          QCOM_ModalMessage(
//              true,
//              GUI_MODAL_ICON_INFORMATION,
//              "Modal Title",
//              "The function returned 0x{0:X8} for XD {1}",
//              status,
//              gcnew String(unmanagedString));
//
// Called by:   QCOM_Main
//              QCOM_SetCommandLineFlags
//----------------------------------------------------------------------------
    System::Windows::Forms::DialogResult
QCOM_ModalMessage(
    bool            allow,
    DWORD           flag,
    String          ^titleString,
    String          ^formatString,
    ...array <Object ^>
                    ^parameters)
{
    System::Windows::Forms::DialogResult
                    result = System::Windows::Forms::DialogResult::OK;
    //------------------------------------------------------------------------
    if (allow && StringSet(titleString) && StringSet(formatString))
    {
        String ^formattedString = String::Format(formatString, parameters);
        MessageBoxIcon icon;
        switch (flag)
        {
            case GUI_MODAL_ICON_INFORMATION :                                   // 0x00000001
                icon = MessageBoxIcon::Information;
                break;
            case GUI_MODAL_ICON_WARNING :                                       // 0x00000002
                icon = MessageBoxIcon::Exclamation;
                break;
            case GUI_MODAL_ICON_ERROR :                                         // 0x00000003
                icon = MessageBoxIcon::Error;
                break;
            case GUI_MODAL_ICON_CRITICAL :                                      // 0x00000004
                icon = MessageBoxIcon::Stop;
                break;
            default :
                icon = MessageBoxIcon::None;
                break;
        }
        //--------------------------------------------------------------------
        // Create an invisible window, from which to force the modal window to
        // the forefront
        //--------------------------------------------------------------------
        Form ^invisibleWindow = gcnew Form;
        invisibleWindow->Size = Drawing::Size(1, 1);
        invisibleWindow->Location = Point(1, 1);
        invisibleWindow->Focus();
        invisibleWindow->BringToFront();
        invisibleWindow->TopMost = GUI_YES;
        if (invisibleWindow->CanSelect)
            invisibleWindow->Select();
        invisibleWindow->TopLevel = GUI_YES;
        invisibleWindow->Visible = GUI_NO;
        result = MessageBox::Show(
            invisibleWindow,
            formattedString,
            titleString,
            MessageBoxButtons::OK,
            icon);
        delete invisibleWindow;
    }
    return result;
}                                       // end of QCOM_ModalMessage()
//----------------------------------------------------------------------------
// QCOM_FilenameContainsExtension
//
// Returns a pointer to the period preceding the filename extension if the
// specified path name contains a filename with an extension preceded by a
// period, or NULL if it does not
//
// Note: This compare is not case-sensitive
//----------------------------------------------------------------------------
    char *
QCOM_FilenameContainsExtension(
    char            *pathName,
    char            *extension)
{
    char            *lastPeriodLocation = (char *) 0;
    //------------------------------------------------------------------------
    if (pathName && extension && strlen(pathName) && strlen(extension))
    {
        lastPeriodLocation = strrchr(pathName, '.');
        if (lastPeriodLocation)
        {
            if (_memicmp((void *) (lastPeriodLocation + 1), (void *) extension, strlen(extension)))
                lastPeriodLocation = (char *) 0;
        }
    }
    return lastPeriodLocation;
}                                       // end of QCOM_FilenameContainsExtension()
//----------------------------------------------------------------------------
// QCOM_ItoA
//
// Converts an unsigned, non-negative 32-bit value into a base-10 string
//
// Returns: The array passed to the function
//
// Note:    The function itoa() is inadequate because it uses too many
//          high-level operations, resulting in excessive program delays
//----------------------------------------------------------------------------
    char *
QCOM_ItoA(
    DWORD           value,
    char            *valueString)
{
    char            *out = valueString;
    char            *start = valueString;
    char            temp;
    DWORD           quotient = value;
    //------------------------------------------------------------------------
    do
    {
        *out++ = "0123456789ABCDEF"[quotient % 10];
        quotient /= 10;
    }
    while (quotient);

    *out-- = QCOM_CHAR_NULL;                    // append a null character before stepping back
    while (start < out)
    {
        temp = *start;
        *start++ = *out;
        *out-- = temp;
    }
    return valueString;
}                                       // end of QCOM_ItoA()
//----------------------------------------------------------------------------
// QCOM_ItoX
//
// Converts an unsigned, non-negative 32-bit value into a base-16 string
//
// Returns: The array passed to the function
//----------------------------------------------------------------------------
    char *
QCOM_ItoX(
    DWORD           value,
    char            *valueString)
{
    char            *out = valueString;
    char            *start = valueString;
    char            temp;
    DWORD           quotient = value;
    //------------------------------------------------------------------------
    do
    {
        *out++ = "0123456789ABCDEF"[quotient % 16];
        quotient >>= 4;
    }
    while (quotient);

    *out-- = QCOM_CHAR_NULL;                    // append a null character before stepping back
    while (start < out)
    {
        temp = *start;
        *start++ = *out;
        *out-- = temp;
    }
    memmove((valueString + 2), valueString, (strlen(valueString) + 1));
    memcpy(valueString, "0x", 2);
    return valueString;
}                                       // end of QCOM_ItoX()
//----------------------------------------------------------------------------
// QCOM_ReverseFloatValue
//
// Reverses the little-endian byte-order representation of the specified float
// value
//
// Note:    The input value must be a 32-bit value; hence, the float
//          specification instead of double
//----------------------------------------------------------------------------
    float
QCOM_ReverseFloatValue(
    float           forwardValue)
{
    DWORD           forwardInteger = *(DWORD *) &forwardValue;
    DWORD           reverseInteger;
    float           reverseValue;
    //------------------------------------------------------------------------
    reverseInteger = QCOM_ReverseIntegerValue(forwardInteger);
    reverseValue = *(float *) &reverseInteger;
    return reverseValue;
}                                       // end of QCOM_ReverseFloatValue()
//----------------------------------------------------------------------------
// QCOM_ReverseIntegerValue
//
// Reverses the little-endian byte-order representation of the specified
// integer value
//
// Note:    The input value must be a 32-bit value
//----------------------------------------------------------------------------
    DWORD
QCOM_ReverseIntegerValue(
    DWORD           forwardValue)
{
    DWORD           reverseValue;
    //------------------------------------------------------------------------
    reverseValue = (DWORD)
        (((forwardValue & 0x000000FF) << 24) |
         ((forwardValue & 0x0000FF00) << 8) |
         ((forwardValue & 0x00FF0000) >> 8) |
         ((forwardValue & 0xFF000000) >> 24));
    return reverseValue;
}                                       // end of QCOM_ReverseIntegerValue()
//----------------------------------------------------------------------------
// QCOM_TimeElapsed
//
// Determines the amount of time that has elapsed in days, hours, minutes,
// seconds, and milliseconds from the total time in milliseconds elapsed
//----------------------------------------------------------------------------
    void
QCOM_TimeElapsed(
    DWORD           lapsedTimeMilliseconds,
    int             *lapsedDays,
    int             *lapsedHours,
    int             *lapsedMinutes,
    int             *lapsedSeconds,
    int             *lapsedMilliseconds)
{
    //------------------------------------------------------------------------
    *lapsedDays = 0;
    *lapsedHours = 0;
    *lapsedMinutes = 0;
    *lapsedSeconds = 0;
    while (lapsedTimeMilliseconds >= 86400000)
    {
        (*lapsedDays)++;
        lapsedTimeMilliseconds -= 86400000;
    }
    while (lapsedTimeMilliseconds >= 3600000)
    {
        (*lapsedHours)++;
        lapsedTimeMilliseconds -= 3600000;
    }
    while (lapsedTimeMilliseconds >= 60000)
    {
        (*lapsedMinutes)++;
        lapsedTimeMilliseconds -= 60000;
    }
    while (lapsedTimeMilliseconds >= 1000)
    {
        (*lapsedSeconds)++;
        lapsedTimeMilliseconds -= 1000;
    }
    *lapsedMilliseconds = lapsedTimeMilliseconds;
}                                       // end of QCOM_TimeElapsed()
//----------------------------------------------------------------------------
// QCOM_WaitMS
//
// Waits (blocks) for the specified number of milliseconds
//----------------------------------------------------------------------------
    void
QCOM_WaitMS(
    DWORD           ms)
{
    while (ms--)
    {
        for (int count = 0; count < 1133113; count++)
            ;
    }
}                                       // end of QCOM_WaitMS()
//----------------------------------------------------------------------------
#endif      // UTILITY_CPP
//============================================================================
// End of Utility.cpp
//============================================================================
