//============================================================================
// qdUSB.h
//
// Header for qdUSB.cpp, which defines functions that front-end SI calls
//
// Copyright (C) 2010 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
// Dan Sealy
//
// See qdUSB.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding the qdUSB interface
//
// Updated 02-25-2014
//============================================================================
#pragma once
#ifndef     QDUSB_H     // provided for legacy compilers, but unnecessary for
#define     QDUSB_H     // recent compilers, due to the preceding pragma
//----------------------------------------------------------------------------
// Include appropriate headers
//----------------------------------------------------------------------------
#include    <windows.h>
//----------------------------------------------------------------------------
// Type definitions
//----------------------------------------------------------------------------
typedef
    struct _CoefficientDataFormat
        CoefficientFormatDef;
typedef
    struct _UnitDeviceInfo
        UnitDeviceInfoDef;
//----------------------------------------------------------------------------
// C declaration space
//----------------------------------------------------------------------------
#ifdef      __cplusplus
extern "C"
{
#endif
//----------------------------------------------------------------------------
// Substitutions
//----------------------------------------------------------------------------
#define     DLLImport                   __declspec(dllimport)
//----------------------------------------------------------------------------
// Prototypes of QD USB DLL functions
//----------------------------------------------------------------------------
DLLImport DWORD QD_CalculateFirmwarePageCRC(                        // B1 3.34
                    LPBYTE          firmwareData,
                    BYTE            pageNumber);
DLLImport DWORD QD_CalculatePressureAndTemperature(                 // B1 3.35
                    LPBYTE          coefficientData,
                    DWORD           pressureCount,
                    DWORD           temperatureCount,
                    DOUBLE          *pressurePSI,
                    DOUBLE          *temperatureCelsius);
DLLImport DWORD QD_CalculatePressureOrTemperature(                  // B1 3.11
                    BYTE            PorT,
                    LPBYTE          coefficientData,
                    DWORD           pressureCount,
                    DWORD           temperatureCount,
                    DOUBLE          *result);
DLLImport DWORD QD_Close(                                           // 3.4
                    HANDLE          unitHandle);
DLLImport DWORD QD_CheckReceiveQueue(                               // B1 3.7
                    HANDLE          unitHandle,
                    LPDWORD         numberOfBytesInQueue,
                    LPDWORD         queueStatus);
DLLImport DWORD QD_ClearInternalError(                              // 3.31
                    HANDLE          unitHandle);
DLLImport bool  QD_CoefficientDataIsValid(                          // B1 3.36
                    LPBYTE          coefficientData);
DLLImport bool  QD_CoefficientHexFileDataIsValid(                   // B1 3.37
                    LPBYTE          hexFileData);
DLLImport bool  QD_DataIsInHexFileFormat(                           // B1 3.38
                    LPBYTE          hexFileData);
DLLImport DWORD QD_EraseFirmwarePage(                               // B1 3.39
                    HANDLE          unitHandle,
                    BYTE            pageNumber);
DLLImport DWORD QD_ExecuteI2CCommand(                               // B1 3.16
                    HANDLE          unitHandle,
                    LPBYTE          commandString,
                    LPBYTE          replyString);
DLLImport bool  QD_FirmwareHexFileDataIsValid(                      // B1 3.40
                    LPBYTE          hexFileData);
DLLImport DWORD QD_FlushBuffers(                                    // 3.8
                    HANDLE          unitHandle,
                    BYTE            flushTransmitBuffer,
                    BYTE            flushReceiveBuffer);
DLLImport DWORD QD_FormatCoefficientHexFileData(                    // B1 3.41
                    LPBYTE          unformattedData,
                    LPBYTE          formattedData);
DLLImport DWORD QD_GetCadenceTimer(                                 // B1 3.26
                    HANDLE          unitHandle,
                    LPDWORD         cadenceTimerValue);
DLLImport DWORD QD_GetInternalErrorCode(                            // 3.30
                    HANDLE          unitHandle,
                    LPWORD          errorCode);
DLLImport DWORD QD_GetFirmwareCRC(                                  // B1 3.42
                    HANDLE          unitHandle,
                    BYTE            pageNumber,
                    LPWORD          pageCRC);
DLLImport DWORD QD_GetFirmwareDeviceInfo(                           // B1 3.43
                    HANDLE          unitHandle,
                    LPBYTE          unitInfo);
DLLImport DWORD QD_GetI2CDataRate(                                  // 3.33
                    HANDLE          unitHandle,
                    DOUBLE          *currentDataRate);
DLLImport DWORD QD_GetMemoryType(                                   // B2 3.62
                    HANDLE          unitHandle,
                    BYTE            targetDevice,
                    LPBYTE          memoryType);
DLLImport DWORD QD_GetModuleControlRegister(                        // B4 3.21
                    HANDLE          unitHandle,
                    LPBYTE          registerValue);
DLLImport DWORD QD_GetModuleFirmwareID(                             // B4 3.24
                    HANDLE          unitHandle,
                    LPBYTE          firmwareID);
DLLImport DWORD QD_GetModuleModeSwitchSetting(                      // B4 3.27
                    HANDLE          unitHandle,
                    LPBYTE          modeSwitchSetting);
DLLImport DWORD QD_GetModuleSerialNumber(                           // B4 3.46
                    DWORD           unitNumber,
                    LPBYTE          serialNumber);
DLLImport DWORD QD_GetModuleStatusRegister(                         // B4 3.23
                    HANDLE          unitHandle,
                    LPBYTE          registerValue);
DLLImport DWORD QD_GetNumberOfModules(void);                        // B4 3.1
DLLImport DWORD QD_GetPressureAndTemperature(                       // B1 3.12
                    HANDLE          unitHandle,
                    LPBYTE          coefficientData,
                    DOUBLE          *pressurePSI,
                    DOUBLE          *temperatureCelsius);
DLLImport DWORD QD_GetProductInfo(                                  // 3.2
                    DWORD           unitNumber,
                    LPBYTE          productInfoString,
                    DWORD           item);
DLLImport DWORD QD_GetQDDLLVersion(                                 // C0 3.63
                    LPBYTE          majorVersion,
                    LPBYTE          minorVersion,
                    LPBYTE          buildVersion);
DLLImport DWORD QD_GetTimeouts(                                     // 3.6
                    LPDWORD         readTimeout,
                    LPDWORD         writeTimeout);
DLLImport DWORD QD_GetTransducerCounts(                             // B1 3.10
                    HANDLE          unitHandle,
                    LPDWORD         pressureCount,
                    LPDWORD         temperatureCount);
DLLImport DWORD QD_GetTransducerCurrent(                            // B1 3.18
                    HANDLE          unitHandle,
                    DOUBLE          *transducerCurrent);
DLLImport DWORD QD_GetTransducerType(                               // B1 3.9
                    HANDLE          unitHandle,
                    LPBYTE          transducerType);
DLLImport DWORD QD_GetTransducerVoltage(                            // B1 3.19
                    HANDLE          unitHandle,
                    DOUBLE          *transducerVoltage);
DLLImport DWORD QD_GetUSBDLLVersion(                                // B1 3.44
                    LPDWORD         upperVersion,
                    LPDWORD         lowerVersion);
DLLImport DWORD QD_GetUSBDriverVersion(                             // B1 3.45
                    LPDWORD         upperVersion,
                    LPDWORD         lowerVersion);
DLLImport bool  QD_HexFileFormatIsValid(                            // B1 3.47
                    LPBYTE          hexFileData);
DLLImport char  *QD_InterpretErrorCode(                             // B? 3.??
                    DWORD           errorCode,
                    char            *errorDescription);
DLLImport DWORD QD_Open(                                            // 3.3
                    DWORD           unitNumber,
                    HANDLE          *unitHandle);
DLLImport DWORD QD_Read(                                            // B1 3.48
                    HANDLE          unitHandle,
                    LPBYTE          readBuffer,
                    DWORD           readBufferSize,
                    LPDWORD         bytesRead);
DLLImport DWORD QD_ReadCoefficientDataFromDevice(                   // B1 3.49
                    HANDLE          unitHandle,
                    LPBYTE          coefficientData);
DLLImport DWORD QD_ReadCoefficientDataFromHexFile(                  // B1 3.15
                    LPBYTE          pathName,
                    LPBYTE          coefficientData);
DLLImport DWORD QD_ReadCoefficientDataFromModulePage(               // B4 3.50
                    HANDLE          unitHandle,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DLLImport DWORD QD_ReadCoefficientDataFromSourcePage(               // B1 3.13
                    HANDLE          unitHandle,
                    BYTE            targetDevice,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DLLImport DWORD QD_ReadFirmwareDataFromFile(                        // B1 3.51
                    LPBYTE          pathName,
                    LPBYTE          firmwareData);
DLLImport DWORD QD_ReadUnitADC(                                     // B1 3.17
                    HANDLE          unitHandle,
                    BYTE            ADCChannel,
                    LPDWORD         ADCCount);
DLLImport DWORD QD_ResetModule(                                     // B4 3.29
                    HANDLE          unitHandle);
DLLImport DWORD QD_SetCadenceTimer(                                 // B1 3.25
                    HANDLE          unitHandle,
                    DWORD           cadenceTimerValue);
DLLImport DWORD QD_SetFirmwareKeyCodes(                             // B1 3.52
                    HANDLE          unitHandle,
                    BYTE            key0,
                    BYTE            key1);
DLLImport DWORD QD_SetFirmwareMode(                                 // B1 3.28
                    HANDLE          unitHandle,
                    BYTE            mode);
DLLImport DWORD QD_SetFirmwarePage(                                 // B1 3.53
                    HANDLE          unitHandle,
                    BYTE            pageNumber);
DLLImport DWORD QD_SetI2CDataRate(                                  // 3.32
                    HANDLE          unitHandle,
                    DOUBLE          newDataRate);
DLLImport DWORD QD_SetModuleControlRegister(                        // B4 3.22
                    HANDLE          unitHandle,
                    BYTE            registerValue);
DLLImport DWORD QD_SetTimeouts(                                     // 3.5
                    DWORD           readTimeout,
                    DWORD           writeTimeout);
DLLImport DWORD QD_SetTransducerPowerState(                         // B1 3.20
                    HANDLE          unitHandle,
                    BYTE            powerState);
DLLImport bool  QD_TransducerMemoryPresent(                         // B? 3.??
                    HANDLE          unitHandle);
DLLImport DWORD QD_UnFormatHexFileData(                             // B1 3.54
                    LPBYTE          formattedData,
                    LPBYTE          unformattedData);
DLLImport DWORD QD_WaitForReply(                                    // B1 3.55
                    HANDLE          unitHandle,
                    DWORD           bytesExpected);
DLLImport DWORD QD_Write(                                           // B1 3.56
                    HANDLE          unitHandle,
                    LPBYTE          writeBuffer,
                    DWORD           writeBufferSize,
                    LPDWORD         bytesWritten);
DLLImport DWORD QD_WriteCoefficientDataToDevice(                    // B1 3.57
                    HANDLE          unitHandle,
                    LPBYTE          coefficientData);
DLLImport DWORD QD_WriteCoefficientDataToHexFile(                   // B1 3.58
                    LPBYTE          coefficientData,
                    LPBYTE          pathName);
DLLImport DWORD QD_WriteCoefficientDataToModulePage(                // B4 3.59
                    HANDLE          unitHandle,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DLLImport DWORD QD_WriteCoefficientDataToTargetPage(                // B1 3.14
                    HANDLE          unitHandle,
                    BYTE            targetDevice,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DLLImport DWORD QD_WriteFirmwarePage(                               // B1 3.60
                    HANDLE          unitHandle,
                    LPBYTE          firmwareData,
                    BYTE            pageNumber,
                    LPWORD          pageCRC);
DLLImport DWORD QD_WriteFirmwareSignature(                          // B1 3.61
                    HANDLE          unitHandle);
//----------------------------------------------------------------------------
// Prototypes of experimental QD USB DLL functions
//----------------------------------------------------------------------------
DLLImport DWORD QD_KickStartUSB(HANDLE unitHandle);
DLLImport DWORD QD_WriteFirmwareData(                               // B1 3.??
                    HANDLE          unitHandle,
                    LPBYTE          firmwareData);
//----------------------------------------------------------------------------
// Prototypes of deprecated QD USB DLL functions (included for backward-compatibility)
//----------------------------------------------------------------------------
DLLImport DWORD QD_CalcPT(                                          // A0 3.11
                    BYTE            PorT,
                    LPBYTE          coefficientData,
                    DWORD           pressureCount,
                    DWORD           temperatureCount,
                    DOUBLE          *result);
DLLImport DWORD QD_CheckRXQueue(                                    // A0 3.7
                    HANDLE          unitHandle,
                    LPDWORD         numberOfBytesInQueue,
                    LPDWORD         queueStatus);
DLLImport DWORD QD_ClearError(                                      // B1 3.31
                    HANDLE          unitHandle);
DLLImport DWORD QD_GetCadenceTmr(                                   // A0 3.26
                    HANDLE          unitHandle,
                    LPDWORD         cadenceTimerValue);
DLLImport DWORD QD_GetCFfromFile(                                   // A0 3.15
                    LPBYTE          path,
                    LPBYTE          coefficientData);
DLLImport DWORD QD_GetCFfromMemDevice(                              // A0 3.13
                    HANDLE          unitHandle,
                    BYTE            targetDevice,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DLLImport DWORD QD_GetCounts(                                       // A0 3.10
                    HANDLE          unitHandle,
                    BYTE            which,
                    LPDWORD         pressureCount,
                    LPDWORD         temperatureCount);
DLLImport DWORD QD_GetErrorCode(                                    // B1 3.30
                    HANDLE          unitHandle,
                    LPWORD          errorCode);
DLLImport DWORD QD_GetI2CBaudRate(                                  // B1 3.33
                    HANDLE          unitHandle,
                    DOUBLE          *currentBaudRate);
DLLImport DWORD QD_GetNumberOfUnits(void);                          // B1 3.1
DLLImport DWORD QD_GetNumDevices(                                   // A0 3.1
                    LPDWORD         numberOfDevices);
DLLImport DWORD QD_GetProductString(                                // B1 3.2
                    DWORD           unitNumber,
                    LPVOID          productInfoString,
                    DWORD           item);
DLLImport DWORD QD_GetPT(                                           // A0 3.12
                    HANDLE          unitHandle,
                    BYTE            PorT,
                    LPBYTE          coefficientData,
                    DOUBLE          *result,
                    LPBYTE          error);
DLLImport DWORD QD_GetUnitControlRegister(                          // B1 3.21
                    HANDLE          unitHandle,
                    LPBYTE          registerValue);
DLLImport DWORD QD_GetUnitFirmwareID(                               // B1 3.24
                    HANDLE          unitHandle,
                    LPBYTE          firmwareID);
DLLImport DWORD QD_GetUnitModeSwitchSetting(                        // B1 3.27
                    HANDLE          unitHandle,
                    LPBYTE          modeSwitchSetting);
DLLImport DWORD QD_GetUnitSerialNumber(                             // B1 3.46
                    DWORD           unitNumber,
                    LPBYTE          serialNumber);
DLLImport DWORD QD_GetUnitStatusRegister(                           // B1 3.23
                    HANDLE          unitHandle,
                    LPBYTE          registerValue);
DLLImport DWORD QD_GetXDCurrent(                                    // A0 3.18
                    HANDLE          unitHandle,
                    DOUBLE          *transducerCurrent);
DLLImport DWORD QD_GetXDType(                                       // A0 3.9
                    HANDLE          unitHandle,
                    LPBYTE          transducerType);
DLLImport DWORD QD_GetXDVoltage(                                    // A0 3.19
                    HANDLE          unitHandle,
                    DOUBLE          *transducerVoltage);
DLLImport DWORD QD_PodFPGAReset(                                    // A0 3.29
                    HANDLE          unitHandle);
DLLImport DWORD QD_RawI2C(                                          // A0 3.16
                    HANDLE          unitHandle,
                    LPBYTE          commandString,
                    LPBYTE          replyString);
DLLImport DWORD QD_ReadADC(                                         // A0 3.17
                    HANDLE          unitHandle,
                    BYTE            ADCChannel,
                    LPDWORD         ADCCount);
DLLImport DWORD QD_ReadCoefficientDataFromUnitPage(                 // B1 3.50
                    HANDLE          unitHandle,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DLLImport DWORD QD_ReadPodControlReg(                               // A0 3.21
                    HANDLE          unitHandle,
                    LPBYTE          registerValue);
DLLImport DWORD QD_ReadPodFWID(                                     // A0 3.24
                    HANDLE          unitHandle,
                    LPBYTE          firmwareID);
DLLImport DWORD QD_ReadPodModeSwitch(                               // A0 3.27
                    HANDLE          unitHandle,
                    LPBYTE          modeSwitchSetting);
DLLImport DWORD QD_ReadPodStatusReg(                                // A0 3.23
                    HANDLE          unitHandle,
                    LPBYTE          registerValue);
DLLImport DWORD QD_ResetUnit(                                       // B1 3.29
                    HANDLE          unitHandle);
DLLImport DWORD QD_SetBootLoad(                                     // A0 3.28
                    HANDLE          unitHandle);
DLLImport DWORD QD_SetCadenceTmr(                                   // A0 3.25
                    HANDLE          unitHandle,
                    DWORD           cadenceTimerValue);
DLLImport DWORD QD_SetI2CBaudRate(                                  // B1 3.32
                    HANDLE          unitHandle,
                    DOUBLE          newBaudRate);
DLLImport DWORD QD_SetUnitControlRegister(                          // B1 3.22
                    HANDLE          unitHandle,
                    BYTE            registerValue);
DLLImport DWORD QD_SetXDPower(                                      // A0 3.20
                    HANDLE          unitHandle,
                    BYTE            powerState);
DLLImport DWORD QD_WriteCFtoMemDevice(                              // A0 3.14
                    HANDLE          unitHandle,
                    BYTE            targetDevice,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DLLImport DWORD QD_WriteCoefficientDataToUnitPage(                  // B1 3.59
                    HANDLE          unitHandle,
                    BYTE            pageNumber,
                    LPBYTE          coefficientData);
DLLImport DWORD QD_WritePodControlReg(                              // A0 3.22
                    HANDLE          unitHandle,
                    BYTE            registerValue);
//----------------------------------------------------------------------------
// DLL variables
//----------------------------------------------------------------------------
DLLImport DWORD QD_DLLStatus;
DLLImport bool  QD_DLLErrorEncountered;
DLLImport bool  QD_DLLMessagesEnabled;
#ifdef      __cplusplus
}
#endif
//----------------------------------------------------------------------------
// Predetermined definitions
//----------------------------------------------------------------------------
#define     QD_STATUS_SUCCESS                                   0x00
#define     QD_STATUS_INITIALIZE                                0x01
#define     QD_MODE_SWITCH_PRESSED                              0x00
#define     QD_MODE_SWITCH_NOT_PRESSED                          0x01
#define     QD_DISABLE_TRANSDUCER_POWER                         0x00
#define     QD_ENABLE_TRANSDUCER_POWER                          0x01
#define     QD_READ_ADC_CHANNEL_CURRENT                         0x03
#define     QD_READ_ADC_CHANNEL_VOLTAGE                         0x04
#define     QD_DEVICE_TRANSDUCER                                0
#define     QD_DEVICE_MODULE                                    1
#define     QD_TRANSDUCER_TYPE_ABSENT                           0
#define     QD_TRANSDUCER_TYPE_FREQUENCY                        1
#define     QD_TRANSDUCER_TYPE_DIGITAL_NOMEM                    5
#define     QD_TRANSDUCER_CHIP_ID_LENGTH                        4
#define     QD_TRANSDUCER_CHIP_SMT_FPGA                         2
#define     QD_TRANSDUCER_CHIP_HYBRID_FPGA                      5
#define     QD_TRANSDUCER_CHIP_ASIC                             9
#define     QD_BYTES_PER_QMEM_PAGE                              256
#define     QD_NUMBER_OF_LOWER_QMEM_PAGES                       4
#define     QD_MAXIMUM_NUMBER_OF_QMEM_PAGES                     64
#define     QD_COEFFICIENT_DATA_SIZE                            QD_BYTES_PER_QMEM_PAGE
#define     QD_QUARTZDYNE_ID                                    0x0D
#define     QD_QUARTZDYNE_CF_TYPE_BIG_ENDIAN                    0x010D
#define     QD_QUARTZDYNE_CF_TYPE_LITTLE_ENDIAN                 0x040D
#define     QD_QUARTZDYNE_CF_VERSION_123                        0x2301
#define     QD_QUARTZDYNE_CF_VERSION_100                        0x0001
#define     QD_MAXIMUM_TRANSFER_SIZE                            768
#define     QD_MEMORY_TYPE_ABSENT                               0
#define     QD_MEMORY_TYPE_FRAM                                 1
#define     QD_MEMORY_TYPE_EEPROM                               2
//----------------------------------------------------------------------------
// Product string entities
//----------------------------------------------------------------------------
#define     QD_MAXIMUM_PRODUCT_STRING_SIZE                      256
#define     QD_MAXIMUM_SERIAL_NUMBER_SIZE                       QD_MAXIMUM_PRODUCT_STRING_SIZE
#define     QD_RETURN_SERIAL_NUMBER                             0
#define     QD_RETURN_DESCRIPTION                               1
#define     QD_RETURN_COMPANY                                   2
#define     QD_RETURN_VID                                       3
#define     QD_RETURN_PID                                       4
#define     QD_RETURN_AUTHOR                                    5
//----------------------------------------------------------------------------
// Receive Queue status
//----------------------------------------------------------------------------
#define     QD_QUEUE_NO_OVERRUN                                 0x00
#define     QD_QUEUE_EMPTY                                      0x00
#define     QD_QUEUE_OVERRUN                                    0x01
#define     QD_QUEUE_READY                                      0x02
//----------------------------------------------------------------------------
// Hardware limits
//----------------------------------------------------------------------------
#define     QD_MINIMUM_I2C_DATA_RATE                            33.3
#define     QD_MAXIMUM_I2C_DATA_RATE                            100.0
#define     QD_MINIMUM_CADENCE_TIMER_MS                         250
#define     QD_MAXIMUM_CADENCE_TIMER_MS                         2000
#define     QD_MAXIMUM_NUMBER_OF_COEFFICIENTS                   25
//----------------------------------------------------------------------------
// Custom definitions
//----------------------------------------------------------------------------
#define     QD_CALCULATE_PRESSURE_PSI                           0
#define     QD_CALCULATE_TEMPERATURE_CELSIUS                    1
#define     QD_DEFAULT_COEFFICIENT_PAGE_NUMBER                  0
#define     QD_GET_BOTH_COUNTS                                  0x00
#define     QD_GET_PRESSURE_COUNTS                              0x01
#define     QD_GET_TEMPERATURE_COUNTS                           0x02
#define     QD_COMMAND_BUFFER_SIZE                              16
#define     QD_COEFFICIENT_DATA_HEX_FILE_SIZE                   733
#define     QD_MAXIMUM_FORMATTED_HEX_DATA_LINE_SIZE             530
#define     QD_CHECK_RECEIVE_QUEUE_TIMEOUT                      500
#define     QD_MAXIMUM_MODAL_STRING_SIZE                        256
#define     QD_MAXIMUM_ERROR_STRING_SIZE                        QD_MAXIMUM_MODAL_STRING_SIZE
//----------------------------------------------------------------------------
// Firmware-related definitions
//----------------------------------------------------------------------------
#define     QD_SET_APPLICATION_MODE                             0x00
#define     QD_SET_BOOT_LOADER_MODE                             0x01
#define     QD_FIRMWARE_ID_LENGTH                               4
#define     QD_FIRMWARE_QUARTZDYNE_ID                           QD_QUARTZDYNE_ID
#define     QD_FIRMWARE_QCOM_ID                                 0x16
#define     QD_FIRMWARE_MAXIMUM_DATA_SIZE                       (63 * 1024)
#define     QD_FIRMWARE_DEVICE_INFO_SIZE                        9
#define     QD_FIRMWARE_PAGE_SIZE                               512
#define     QD_FIRMWARE_APPLICATION_OFFSET                      0x1200
#define     QD_FIRMWARE_FIRST_PAGE_C8051F320                    (QD_FIRMWARE_APPLICATION_OFFSET / QD_FIRMWARE_PAGE_SIZE)    /* 9 */
#define     QD_FIRMWARE_LAST_PAGE_C8051F320                     29
#define     QD_FIRMWARE_DEVICE_CODE_C8051F320                   0x81
#define     QD_FIRMWARE_TEST_OFFSET                             (((QD_FIRMWARE_LAST_PAGE_C8051F320 + 1) * QD_FIRMWARE_PAGE_SIZE) - 12)  /* 0x3BF4 */
#define     QD_FIRMWARE_SERIAL_STRING_SIZE                      7
#define     QD_FIRMWARE_SIGNATURE                               0x3DC2
#define     QD_FIRMWARE_KEY_0                                   0xA5
#define     QD_FIRMWARE_KEY_1                                   0xF1
#define     QD_FIRMWARE_CRC_POLYNOMIAL                          0x8408
#define     QD_ERROR_SIGNATURE_NOT_ERASED                       0x03
#define     QD_MINIMUM_BOOT_LOADER_MODE_WAIT_TIME               1500
#define     QD_MAXIMUM_BOOT_LOADER_MODE_WAIT_TIME               2000
//----------------------------------------------------------------------------
// Unit status register (mask) definitions
//----------------------------------------------------------------------------
#define     QD_SREG_TRANSDUCER_TYPE_MASK                        0x07
#define     QD_SREG_TRANSDUCER_PRESENT                          0x08
#define     QD_SREG_TRANSDUCER_OVER_CURRENT                     0x10
#define     QD_SREG_TRANSDUCER_POWER_STATE                      0x20
#define     QD_SREG_HIGH_SIDE_SWITCH_PRESENCE                   0x40
#define     QD_SREG_ERROR_PRESENCE                              0x80
//----------------------------------------------------------------------------
// Status and error definitions (values 0x00000001 through 0x0000000F line up
// with those in SiUSBXp.h)
//
// The lower word 0x0000FFFF is used for error codes
//
// The third byte* 0x00FF0000 is used for loci within a function
//
// The fourth byte 0xFF000000 is the function number
//
//      Function numbers 0x01000000 through 0x0F000000 inclusive are reserved
//      for general or global DLL elements (16 maximum)
//
//      Function numbers 0x10000000 through 0x5F000000 inclusive are reserved
//      for regular DLL functions (80 maximum)
//
//      Function numbers 0xD0000000 through 0xFF000000 inclusive are reserved
//      for deprecated DLL functions (48 maximum)
//----------------------------------------------------------------------------
#define     QD_SUCCESS                                          0x00000000
#define     QD_FAILURE                                          -1
#define     QD_ERROR_NO_ERROR                                   QD_SUCCESS
#define     QD_ERROR_INVALID_HANDLE                             0x00000001
#define     QD_ERROR_READ_ERROR                                 0x00000002
#define     QD_ERROR_RECEIVE_QUEUE_NOT_READY                    0x00000003
#define     QD_ERROR_WRITE_ERROR                                0x00000004
#define     QD_ERROR_RESET_ERROR                                0x00000005
#define     QD_ERROR_INVALID_PARAMETER                          0x00000006
#define     QD_ERROR_INVALID_REQUEST_LENGTH                     0x00000007
#define     QD_ERROR_DEVICE_IO_FAILED                           0x00000008
#define     QD_ERROR_INVALID_DATA_RATE                          0x00000009
#define     QD_ERROR_FUNCTION_NOT_SUPPORTED                     0x0000000A
#define     QD_ERROR_GLOBAL_DATA_ERROR                          0x0000000B
#define     QD_ERROR_SYSTEM_ERROR                               0x0000000C
#define     QD_ERROR_READ_TIMED_OUT                             0x0000000D
#define     QD_ERROR_WRITE_TIMED_OUT                            0x0000000E
#define     QD_ERROR_IO_PENDING                                 0x0000000F
#define     QD_ERROR_CHECKSUM_ERROR                             0x00000010
#define     QD_ERROR_XD_PRESSURE_COUNT_ZERO                     0x00000011
#define     QD_ERROR_XD_TEMPERATURE_COUNT_ZERO                  0x00000012
#define     QD_ERROR_XD_BOTH_COUNTS_ZERO                        0x00000013
#define     QD_ERROR_MEMORY_ALLOCATION_FAILED                   0x00000014
#define     QD_ERROR_FILE_OPEN_FAILURE                          0x00000015
#define     QD_ERROR_ADC_COUNT_ZERO                             0x00000016
#define     QD_ERROR_FILE_SIZE_MISMATCH                         0x00000017
#define     QD_ERROR_INVALID_HEX_FILE_DATA                      0x00000018
#define     QD_ERROR_INCORRECT_DATA_SIZE                        0x00000019
#define     QD_ERROR_INVALID_FIRMWARE_PAGE                      0x0000001A
#define     QD_ERROR_UNIT_NOT_READY                             0x0000001B
#define     QD_ERROR_CADENCE_TIMER_ZERO                         0x0000001C
#define     QD_ERROR_DATA_RATE_ZERO                             0x0000001D
#define     QD_ERROR_INVALID_I2C_REPLY                          0x0000001E
#define     QD_ERROR_FIRMWARE_ID_ZERO                           0x0000001F
#define     QD_ERROR_DATA_TRANSFER_FAILURE                      0x00000020
#define     QD_ERROR_DEVICE_TIMED_OUT                           0x00000021
#define     QD_ERROR_RECEIVE_QUEUE_OVERRUN                      0x00000022
#define     QD_ERROR_FIRMWARE_SIGNATURE_NOT_ERASED              0x00000023
#define     QD_ERROR_XD_VOLTAGE_TOO_HIGH                        0x00000024
#define     QD_ERROR_XD_VOLTAGE_TOO_LOW                         0x00000025
#define     QD_ERROR_XD_CURRENT_TOO_HIGH                        0x00000026
#define     QD_ERROR_XD_CURRENT_TOO_LOW                         0x00000027
#define     QD_ERROR_WRITE_ACKNOWLEDGE_FAILED                   0x00000028
#define     QD_ERROR_UNREACHABLE_CONDITION                      0x00000029
#define     QD_ERROR_NULL_POINTER_PARAMETER                     0x0000002A
#define     QD_ERROR_ZERO_LENGTH_STRING_PARAMETER               0x0000002B
#define     QD_ERROR_INVALID_COEFFICIENT_DATA                   0x00000040
#define     QD_ERROR_FILE_NOT_FOUND                             0x00000070
#define     QD_ERROR_INVALID_FILE_NAME                          0x00000071
#define     QD_ERROR_INVALID_FILE_FOUND                         0x00000072
#define     QD_ERROR_NO_DEVICE_FOUND                            0x000000FF
//----------------------------------------------------------------------------
// Error code and locus masks
//----------------------------------------------------------------------------
#define     QD_ERROR_CODE_MASK                                  0x0000FFFF
#define     QD_ERROR_CODE_AND_LOCUS_MASK                        0x00FFFFFF
#define     QD_ERROR_CODE_LOCUS_MASK                            0x00FF0000
#define     QD_ERROR_CODE_FUNCTION_MASK                         0xFF000000
//----------------------------------------------------------------------------
// Status and error detection points (where they are first encountered)
//----------------------------------------------------------------------------
#define     QD_LOCUS_NOT_APPLICABLE                             0x00000000
#define     QD_LOCUS_GENERAL_DLL                                0x01000000
#define     QD_LOCUS_CALCULATE_P_AND_T                          0x10000000
#define     QD_LOCUS_CALCULATE_P_OR_T                           0x11000000
#define         QD_LOCUS_CALCULATE_P_OR_T_1                         0x11010000
#define         QD_LOCUS_CALCULATE_P_OR_T_2                         0x11020000
#define         QD_LOCUS_CALCULATE_P_OR_T_3                         0x11030000
#define         QD_LOCUS_CALCULATE_P_OR_T_4                         0x11040000
#define         QD_LOCUS_CALCULATE_P_OR_T_5                         0x11050000
#define     QD_LOCUS_CHECK_RECEIVE_QUEUE                        0x12000000
#define         QD_LOCUS_CHECK_RECEIVE_QUEUE_1                      0x12010000
#define         QD_LOCUS_CHECK_RECEIVE_QUEUE_2                      0x12020000
#define         QD_LOCUS_CHECK_RECEIVE_QUEUE_3                      0x12030000
#define         QD_LOCUS_CHECK_RECEIVE_QUEUE_4                      0x12040000
#define     QD_LOCUS_CLEAR_INTERNAL_ERROR                       0x13000000
#define         QD_LOCUS_CLEAR_INTERNAL_ERROR_1                     0x13010000
#define         QD_LOCUS_CLEAR_INTERNAL_ERROR_2                     0x13020000
#define     QD_LOCUS_CLOSE                                      0x14000000
#define         QD_LOCUS_CLOSE_1                                    0x14010000
#define     QD_LOCUS_ERASE_FIRMWARE_PAGE                        0x15000000
#define         QD_LOCUS_ERASE_FIRMWARE_PAGE_1                      0x15010000
#define         QD_LOCUS_ERASE_FIRMWARE_PAGE_2                      0x15020000
#define         QD_LOCUS_ERASE_FIRMWARE_PAGE_3                      0x15030000
#define         QD_LOCUS_ERASE_FIRMWARE_PAGE_4                      0x15040000
#define     QD_LOCUS_EXECUTE_I2C_COMMAND                        0x16000000
#define         QD_LOCUS_EXECUTE_I2C_COMMAND_1                      0x16010000
#define         QD_LOCUS_EXECUTE_I2C_COMMAND_2                      0x16020000
#define         QD_LOCUS_EXECUTE_I2C_COMMAND_3                      0x16030000
#define         QD_LOCUS_EXECUTE_I2C_COMMAND_4                      0x16040000
#define         QD_LOCUS_EXECUTE_I2C_COMMAND_5                      0x16050000
#define         QD_LOCUS_EXECUTE_I2C_COMMAND_6                      0x16060000
#define         QD_LOCUS_EXECUTE_I2C_COMMAND_7                      0x16070000
#define         QD_LOCUS_EXECUTE_I2C_COMMAND_8                      0x16080000
#define         QD_LOCUS_EXECUTE_I2C_COMMAND_9                      0x16090000
#define         QD_LOCUS_EXECUTE_I2C_COMMAND_A                      0x160A0000
#define     QD_LOCUS_FLUSH_BUFFERS                              0x17000000
#define         QD_LOCUS_FLUSH_BUFFERS_1                            0x17010000
#define         QD_LOCUS_FLUSH_BUFFERS_2                            0x17020000
#define     QD_LOCUS_GET_CADENCE_TIMER                          0x18000000
#define         QD_LOCUS_GET_CADENCE_TIMER_1                        0x18010000
#define         QD_LOCUS_GET_CADENCE_TIMER_2                        0x18020000
#define         QD_LOCUS_GET_CADENCE_TIMER_3                        0x18030000
#define         QD_LOCUS_GET_CADENCE_TIMER_4                        0x18040000
#define         QD_LOCUS_GET_CADENCE_TIMER_5                        0x18050000
#define         QD_LOCUS_GET_CADENCE_TIMER_6                        0x18060000
#define         QD_LOCUS_GET_CADENCE_TIMER_7                        0x18070000
#define         QD_LOCUS_GET_CADENCE_TIMER_8                        0x18080000
#define     QD_LOCUS_GET_FIRMWARE_CRC                           0x19000000
#define         QD_LOCUS_GET_FIRMWARE_CRC_1                         0x19010000
#define         QD_LOCUS_GET_FIRMWARE_CRC_2                         0x19020000
#define         QD_LOCUS_GET_FIRMWARE_CRC_3                         0x19030000
#define         QD_LOCUS_GET_FIRMWARE_CRC_4                         0x19040000
#define     QD_LOCUS_GET_FIRMWARE_DEVICE_INFO                   0x1A000000
#define         QD_LOCUS_GET_FIRMWARE_DEVICE_INFO_1                 0x1A010000
#define         QD_LOCUS_GET_FIRMWARE_DEVICE_INFO_2                 0x1A020000
#define         QD_LOCUS_GET_FIRMWARE_DEVICE_INFO_3                 0x1A030000
#define         QD_LOCUS_GET_FIRMWARE_DEVICE_INFO_4                 0x1A040000
#define         QD_LOCUS_GET_FIRMWARE_DEVICE_INFO_5                 0x1A050000
#define     QD_LOCUS_GET_I2C_DATA_RATE                          0x1B000000
#define         QD_LOCUS_GET_I2C_DATA_RATE_1                        0x1B010000
#define         QD_LOCUS_GET_I2C_DATA_RATE_2                        0x1B020000
#define         QD_LOCUS_GET_I2C_DATA_RATE_3                        0x1B030000
#define         QD_LOCUS_GET_I2C_DATA_RATE_4                        0x1B040000
#define         QD_LOCUS_GET_I2C_DATA_RATE_5                        0x1B050000
#define         QD_LOCUS_GET_I2C_DATA_RATE_6                        0x1B060000
#define         QD_LOCUS_GET_I2C_DATA_RATE_7                        0x1B070000
#define     QD_LOCUS_GET_INTERNAL_ERROR_CODE                    0x1C000000
#define         QD_LOCUS_GET_INTERNAL_ERROR_CODE_1                  0x1C010000
#define         QD_LOCUS_GET_INTERNAL_ERROR_CODE_2                  0x1C020000
#define         QD_LOCUS_GET_INTERNAL_ERROR_CODE_3                  0x1C030000
#define         QD_LOCUS_GET_INTERNAL_ERROR_CODE_4                  0x1C040000
#define         QD_LOCUS_GET_INTERNAL_ERROR_CODE_5                  0x1C050000
#define     QD_LOCUS_GET_MEMORY_TYPE                            0x1D000000
#define         QD_LOCUS_GET_MEMORY_TYPE_1                          0x1D010000
#define         QD_LOCUS_GET_MEMORY_TYPE_2                          0x1D020000
#define         QD_LOCUS_GET_MEMORY_TYPE_3                          0x1D030000
#define         QD_LOCUS_GET_MEMORY_TYPE_4                          0x1D040000
#define         QD_LOCUS_GET_MEMORY_TYPE_5                          0x1D050000
#define         QD_LOCUS_GET_MEMORY_TYPE_6                          0x1D060000
#define     QD_LOCUS_GET_NUMBER_OF_MODULES                      0x1E000000
#define     QD_LOCUS_GET_PRESSURE_AND_TEMPERATURE               0x1F000000
#define     QD_LOCUS_GET_PRODUCT_INFO                           0x20000000
#define         QD_LOCUS_GET_PRODUCT_INFO_1                         0x20010000
#define         QD_LOCUS_GET_PRODUCT_INFO_2                         0x20020000
#define         QD_LOCUS_GET_PRODUCT_INFO_3                         0x20030000
#define         QD_LOCUS_GET_PRODUCT_INFO_4                         0x20040000
#define         QD_LOCUS_GET_PRODUCT_INFO_5                         0x20050000
#define     QD_LOCUS_GET_TIMEOUTS                               0x21000000
#define         QD_LOCUS_GET_TIMEOUTS_1                             0x21010000
#define         QD_LOCUS_GET_TIMEOUTS_2                             0x21020000
#define         QD_LOCUS_GET_TIMEOUTS_3                             0x21030000
#define     QD_LOCUS_GET_TRANSDUCER_COUNTS                      0x22000000
#define         QD_LOCUS_GET_TRANSDUCER_COUNTS_1                    0x22010000
#define         QD_LOCUS_GET_TRANSDUCER_COUNTS_2                    0x22020000
#define         QD_LOCUS_GET_TRANSDUCER_COUNTS_3                    0x22030000
#define         QD_LOCUS_GET_TRANSDUCER_COUNTS_4                    0x22040000
#define         QD_LOCUS_GET_TRANSDUCER_COUNTS_5                    0x22050000
#define         QD_LOCUS_GET_TRANSDUCER_COUNTS_6                    0x22060000
#define         QD_LOCUS_GET_TRANSDUCER_COUNTS_7                    0x22070000
#define         QD_LOCUS_GET_TRANSDUCER_COUNTS_8                    0x22080000
#define         QD_LOCUS_GET_TRANSDUCER_COUNTS_9                    0x22090000
#define         QD_LOCUS_GET_TRANSDUCER_COUNTS_A                    0x220A0000
#define         QD_LOCUS_GET_TRANSDUCER_COUNTS_B                    0x220B0000
#define     QD_LOCUS_GET_TRANSDUCER_CURRENT                     0x23000000
#define         QD_LOCUS_GET_TRANSDUCER_CURRENT_1                   0x23010000
#define         QD_LOCUS_GET_TRANSDUCER_CURRENT_2                   0x23020000
#define         QD_LOCUS_GET_TRANSDUCER_CURRENT_3                   0x23030000
#define     QD_LOCUS_GET_TRANSDUCER_TYPE                        0x24000000
#define         QD_LOCUS_GET_TRANSDUCER_TYPE_1                      0x24010000
#define         QD_LOCUS_GET_TRANSDUCER_TYPE_2                      0x24020000
#define         QD_LOCUS_GET_TRANSDUCER_TYPE_3                      0x24030000
#define         QD_LOCUS_GET_TRANSDUCER_TYPE_4                      0x24040000
#define         QD_LOCUS_GET_TRANSDUCER_TYPE_5                      0x24050000
#define     QD_LOCUS_GET_TRANSDUCER_VOLTAGE                     0x25000000
#define         QD_LOCUS_GET_TRANSDUCER_VOLTAGE_1                   0x25010000
#define         QD_LOCUS_GET_TRANSDUCER_VOLTAGE_2                   0x25020000
#define         QD_LOCUS_GET_TRANSDUCER_VOLTAGE_3                   0x25030000
#define     QD_LOCUS_GET_MODULE_CONTROL_REGISTER                0x26000000
#define         QD_LOCUS_GET_MODULE_CONTROL_REGISTER_1              0x26010000
#define         QD_LOCUS_GET_MODULE_CONTROL_REGISTER_2              0x26020000
#define         QD_LOCUS_GET_MODULE_CONTROL_REGISTER_3              0x26030000
#define         QD_LOCUS_GET_MODULE_CONTROL_REGISTER_4              0x26040000
#define         QD_LOCUS_GET_MODULE_CONTROL_REGISTER_5              0x26050000
#define     QD_LOCUS_GET_MODULE_FIRMWARE_ID                     0x27000000
#define         QD_LOCUS_GET_MODULE_FIRMWARE_ID_1                   0x27010000
#define         QD_LOCUS_GET_MODULE_FIRMWARE_ID_2                   0x27020000
#define         QD_LOCUS_GET_MODULE_FIRMWARE_ID_3                   0x27030000
#define         QD_LOCUS_GET_MODULE_FIRMWARE_ID_4                   0x27040000
#define         QD_LOCUS_GET_MODULE_FIRMWARE_ID_5                   0x27050000
#define         QD_LOCUS_GET_MODULE_FIRMWARE_ID_6                   0x27060000
#define         QD_LOCUS_GET_MODULE_FIRMWARE_ID_7                   0x27070000
#define     QD_LOCUS_GET_MODULE_MODE_SWITCH_SETTING             0x28000000
#define         QD_LOCUS_GET_MODULE_MODE_SWITCH_SETTING_1           0x28010000
#define         QD_LOCUS_GET_MODULE_MODE_SWITCH_SETTING_2           0x28020000
#define         QD_LOCUS_GET_MODULE_MODE_SWITCH_SETTING_3           0x28030000
#define         QD_LOCUS_GET_MODULE_MODE_SWITCH_SETTING_4           0x28040000
#define         QD_LOCUS_GET_MODULE_MODE_SWITCH_SETTING_5           0x28050000
#define     QD_LOCUS_GET_MODULE_SERIAL_NUMBER                   0x29000000
#define     QD_LOCUS_GET_MODULE_STATUS_REGISTER                 0x2A000000
#define         QD_LOCUS_GET_MODULE_STATUS_REGISTER_1               0x2A010000
#define         QD_LOCUS_GET_MODULE_STATUS_REGISTER_2               0x2A020000
#define         QD_LOCUS_GET_MODULE_STATUS_REGISTER_3               0x2A030000
#define         QD_LOCUS_GET_MODULE_STATUS_REGISTER_4               0x2A040000
#define         QD_LOCUS_GET_MODULE_STATUS_REGISTER_5               0x2A050000
#define     QD_LOCUS_GET_USB_DLL_VERSION                        0x2B000000
#define         QD_LOCUS_GET_USB_DLL_VERSION_1                      0x2B010000
#define         QD_LOCUS_GET_USB_DLL_VERSION_2                      0x2B020000
#define         QD_LOCUS_GET_USB_DLL_VERSION_3                      0x2B030000
#define     QD_LOCUS_GET_USB_DRIVER_VERSION                     0x2C000000
#define         QD_LOCUS_GET_USB_DRIVER_VERSION_1                   0x2C010000
#define         QD_LOCUS_GET_USB_DRIVER_VERSION_2                   0x2C020000
#define         QD_LOCUS_GET_USB_DRIVER_VERSION_3                   0x2C030000
#define     QD_LOCUS_OPEN                                       0x2D000000
#define         QD_LOCUS_OPEN_1                                     0x2D010000
#define         QD_LOCUS_OPEN_2                                     0x2D020000
#define         QD_LOCUS_OPEN_3                                     0x2D030000
#define         QD_LOCUS_OPEN_4                                     0x2D040000
#define         QD_LOCUS_OPEN_5                                     0x2D050000
#define     QD_LOCUS_READ                                       0x2E000000
#define         QD_LOCUS_READ_1                                     0x2E010000
#define         QD_LOCUS_READ_2                                     0x2E020000
#define         QD_LOCUS_READ_3                                     0x2E030000
#define         QD_LOCUS_READ_4                                     0x2E040000
#define         QD_LOCUS_READ_5                                     0x2E050000
#define         QD_LOCUS_READ_6                                     0x2E060000
#define     QD_LOCUS_READ_CF_DATA_FROM_DEVICE                   0x2F000000
#define     QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE                 0x30000000
#define         QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_1               0x30010000
#define         QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_2               0x30020000
#define         QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_3               0x30030000
#define         QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_4               0x30040000
#define         QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_5               0x30050000
#define         QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_6               0x30060000
#define         QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_7               0x30070000
#define         QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_8               0x30080000
#define         QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_9               0x30090000
//#define         QD_LOCUS_READ_CF_DATA_FROM_HEX_FILE_A               0x300A0000
#define     QD_LOCUS_READ_CF_DATA_FROM_SOURCE_PAGE              0x31000000
#define     QD_LOCUS_READ_CF_DATA_FROM_MODULE_PAGE              0x32000000
#define     QD_LOCUS_READ_FW_DATA_FROM_FILE                     0x33000000
#define         QD_LOCUS_READ_FW_DATA_FROM_FILE_1                   0x33010000
#define         QD_LOCUS_READ_FW_DATA_FROM_FILE_2                   0x33020000
#define         QD_LOCUS_READ_FW_DATA_FROM_FILE_3                   0x33030000
#define         QD_LOCUS_READ_FW_DATA_FROM_FILE_4                   0x33040000
#define         QD_LOCUS_READ_FW_DATA_FROM_FILE_5                   0x33050000
#define         QD_LOCUS_READ_FW_DATA_FROM_FILE_6                   0x33060000
#define         QD_LOCUS_READ_FW_DATA_FROM_FILE_7                   0x33070000
#define         QD_LOCUS_READ_FW_DATA_FROM_FILE_8                   0x33080000
#define     QD_LOCUS_READ_UNIT_ADC                              0x34000000
#define         QD_LOCUS_READ_UNIT_ADC_1                            0x34010000
#define         QD_LOCUS_READ_UNIT_ADC_2                            0x34020000
#define         QD_LOCUS_READ_UNIT_ADC_3                            0x34030000
#define         QD_LOCUS_READ_UNIT_ADC_4                            0x34040000
#define         QD_LOCUS_READ_UNIT_ADC_5                            0x34050000
#define         QD_LOCUS_READ_UNIT_ADC_6                            0x34060000
#define         QD_LOCUS_READ_UNIT_ADC_7                            0x34070000
#define     QD_LOCUS_RESET_MODULE                               0x35000000
#define         QD_LOCUS_RESET_MODULE_1                             0x35010000
#define         QD_LOCUS_RESET_MODULE_2                             0x35020000
#define     QD_LOCUS_SET_CADENCE_TIMER                          0x36000000
#define         QD_LOCUS_SET_CADENCE_TIMER_1                        0x36010000
#define         QD_LOCUS_SET_CADENCE_TIMER_2                        0x36020000
#define     QD_LOCUS_SET_FIRMWARE_KEY_CODES                     0x37000000
#define         QD_LOCUS_SET_FIRMWARE_KEY_CODES_1                   0x37010000
#define         QD_LOCUS_SET_FIRMWARE_KEY_CODES_2                   0x37020000
#define         QD_LOCUS_SET_FIRMWARE_KEY_CODES_3                   0x37030000
#define         QD_LOCUS_SET_FIRMWARE_KEY_CODES_4                   0x37040000
#define         QD_LOCUS_SET_FIRMWARE_KEY_CODES_5                   0x37050000
#define     QD_LOCUS_SET_FIRMWARE_MODE                          0x38000000
#define         QD_LOCUS_SET_FIRMWARE_MODE_1                        0x38010000
#define         QD_LOCUS_SET_FIRMWARE_MODE_2                        0x38020000
#define         QD_LOCUS_SET_FIRMWARE_MODE_3                        0x38030000
#define         QD_LOCUS_SET_FIRMWARE_MODE_4                        0x38040000
#define     QD_LOCUS_SET_FIRMWARE_PAGE                          0x39000000
#define         QD_LOCUS_SET_FIRMWARE_PAGE_1                        0x39010000
#define         QD_LOCUS_SET_FIRMWARE_PAGE_2                        0x39020000
#define         QD_LOCUS_SET_FIRMWARE_PAGE_3                        0x39030000
#define         QD_LOCUS_SET_FIRMWARE_PAGE_4                        0x39040000
#define         QD_LOCUS_SET_FIRMWARE_PAGE_5                        0x39050000
#define     QD_LOCUS_SET_I2C_DATA_RATE                          0x3A000000
#define         QD_LOCUS_SET_I2C_DATA_RATE_1                        0x3A010000
#define         QD_LOCUS_SET_I2C_DATA_RATE_2                        0x3A020000
#define     QD_LOCUS_SET_TIMEOUTS                               0x3B000000
#define     QD_LOCUS_SET_TRANSDUCER_POWER_STATE                 0x3C000000
#define         QD_LOCUS_SET_TRANSDUCER_POWER_STATE_1               0x3C010000
#define         QD_LOCUS_SET_TRANSDUCER_POWER_STATE_2               0x3C020000
#define         QD_LOCUS_SET_TRANSDUCER_POWER_STATE_3               0x3C030000
#define     QD_LOCUS_SET_MODULE_CONTROL_REGISTER                0x3D000000
#define         QD_LOCUS_SET_MODULE_CONTROL_REGISTER_1              0x3D010000
#define         QD_LOCUS_SET_MODULE_CONTROL_REGISTER_2              0x3D020000
#define     QD_LOCUS_WAIT_FOR_REPLY                             0x3E000000
#define         QD_LOCUS_WAIT_FOR_REPLY_1                           0x3E010000
#define     QD_LOCUS_WRITE                                      0x3F000000
#define         QD_LOCUS_WRITE_1                                    0x3F010000
#define         QD_LOCUS_WRITE_2                                    0x3F020000
#define         QD_LOCUS_WRITE_3                                    0x3F030000
#define         QD_LOCUS_WRITE_4                                    0x3F040000
#define         QD_LOCUS_WRITE_5                                    0x3F050000
#define         QD_LOCUS_WRITE_6                                    0x3F060000
#define     QD_LOCUS_WRITE_CF_DATA_TO_DEVICE                    0x40000000
#define     QD_LOCUS_WRITE_CF_DATA_TO_HEX_FILE                  0x41000000
#define         QD_LOCUS_WRITE_CF_DATA_TO_HEX_FILE_1                0x41010000
#define         QD_LOCUS_WRITE_CF_DATA_TO_HEX_FILE_2                0x41020000
//#define         QD_LOCUS_WRITE_CF_DATA_TO_HEX_FILE_3                0x41030000
//#define         QD_LOCUS_WRITE_CF_DATA_TO_HEX_FILE_4                0x41040000
#define         QD_LOCUS_WRITE_CF_DATA_TO_HEX_FILE_5                0x41050000
#define         QD_LOCUS_WRITE_CF_DATA_TO_HEX_FILE_6                0x41060000
#define     QD_LOCUS_WRITE_CF_DATA_TO_TARGET_PAGE               0x42000000
#define     QD_LOCUS_WRITE_CF_DATA_TO_MODULE_PAGE               0x43000000
#define     QD_LOCUS_WRITE_FIRMWARE_DATA                        0x44000000
#define         QD_LOCUS_WRITE_FIRMWARE_DATA_1                      0x44010000
#define         QD_LOCUS_WRITE_FIRMWARE_DATA_2                      0x44020000
#define         QD_LOCUS_WRITE_FIRMWARE_DATA_3                      0x44030000
#define     QD_LOCUS_WRITE_FIRMWARE_PAGE                        0x45000000
#define         QD_LOCUS_WRITE_FIRMWARE_PAGE_1                      0x45010000
#define         QD_LOCUS_WRITE_FIRMWARE_PAGE_2                      0x45020000
#define         QD_LOCUS_WRITE_FIRMWARE_PAGE_3                      0x45030000
#define         QD_LOCUS_WRITE_FIRMWARE_PAGE_4                      0x45040000
#define         QD_LOCUS_WRITE_FIRMWARE_PAGE_5                      0x45050000
#define         QD_LOCUS_WRITE_FIRMWARE_PAGE_6                      0x45060000
#define         QD_LOCUS_WRITE_FIRMWARE_PAGE_7                      0x45070000
#define         QD_LOCUS_WRITE_FIRMWARE_PAGE_8                      0x45080000
#define         QD_LOCUS_WRITE_FIRMWARE_PAGE_9                      0x45090000
#define         QD_LOCUS_WRITE_FIRMWARE_PAGE_A                      0x450A0000
#define         QD_LOCUS_WRITE_FIRMWARE_PAGE_B                      0x450B0000
#define     QD_LOCUS_WRITE_FIRMWARE_SIGNATURE                   0x46000000
#define         QD_LOCUS_WRITE_FIRMWARE_SIGNATURE_1                 0x46010000
#define         QD_LOCUS_WRITE_FIRMWARE_SIGNATURE_2                 0x46020000
#define         QD_LOCUS_WRITE_FIRMWARE_SIGNATURE_3                 0x46030000
#define         QD_LOCUS_WRITE_FIRMWARE_SIGNATURE_4                 0x46040000
#define         QD_LOCUS_WRITE_FIRMWARE_SIGNATURE_5                 0x46050000
#define         QD_LOCUS_WRITE_FIRMWARE_SIGNATURE_6                 0x46060000
#define     QD_LOCUS_GET_DLL_VERSION                            0x47000000
#define         QD_LOCUS_GET_DLL_VERSION_1                          0x47010000
#define     QD_LOCUS_X_CALC_PT                                  0xD0000000
#define     QD_LOCUS_X_CHECK_RX_QUEUE                           0xD1000000
#define     QD_LOCUS_X_CLEAR_ERROR                              0xD2000000
#define     QD_LOCUS_X_GET_CADENCE_TIMER                        0xD3000000
#define     QD_LOCUS_X_GET_CF_FROM_FILE                         0xD4000000
#define     QD_LOCUS_X_GET_CF_FROM_DEVICE                       0xD5000000
#define     QD_LOCUS_X_GET_COUNTS                               0xD6000000
#define     QD_LOCUS_X_GET_ERROR_CODE                           0xD7000000
#define     QD_LOCUS_X_GET_I2C_BAUD_RATE                        0xD8000000
#define     QD_LOCUS_X_GET_NUM_DEVICES                          0xD9000000
#define     QD_LOCUS_X_GET_PRODUCT_STRING                       0xDA000000
#define     QD_LOCUS_X_GET_PT                                   0xDB000000
#define     QD_LOCUS_X_GET_XD_CURRENT                           0xDC000000
#define     QD_LOCUS_X_GET_XD_TYPE                              0xDD000000
#define     QD_LOCUS_X_GET_XD_VOLTAGE                           0xDE000000
#define     QD_LOCUS_X_POD_FPGA_RESET                           0xDF000000
#define     QD_LOCUS_X_RAW_I2C                                  0xE0000000
#define     QD_LOCUS_X_READ_ADC                                 0xE1000000
#define     QD_LOCUS_X_READ_POD_CONTROL_REG                     0xE2000000
#define     QD_LOCUS_X_READ_POD_FWID                            0xE3000000
#define     QD_LOCUS_X_READ_POD_MODE_SWITCH                     0xE4000000
#define     QD_LOCUS_X_READ_POD_STATUS_REG                      0xE5000000
#define     QD_LOCUS_X_SET_BOOT_LOAD                            0xE6000000
#define     QD_LOCUS_X_SET_CADENCE_TIMER                        0xE7000000
#define     QD_LOCUS_X_SET_I2C_BAUD_RATE                        0xE8000000
#define     QD_LOCUS_X_SET_XD_POWER                             0xE9000000
#define     QD_LOCUS_X_WRITE_CF_TO_DEVICE                       0xEA000000
#define     QD_LOCUS_X_WRITE_POD_CONTOL_REG                     0xEB000000
#define     QD_LOCUS_X_GET_UNIT_CONTROL_REGISTER                0xEC000000
#define     QD_LOCUS_X_GET_UNIT_SERIAL_NUMBER                   0xED000000
#define     QD_LOCUS_X_GET_UNIT_FIRMWARE_ID                     0xEE000000
#define     QD_LOCUS_X_GET_UNIT_STATUS_REGISTER                 0xEF000000
#define     QD_LOCUS_X_GET_UNIT_MODE_SWITCH_SETTING             0xF0000000
#define     QD_LOCUS_X_READ_CF_DATA_FROM_UNIT_PAGE              0xF1000000
#define     QD_LOCUS_X_SET_UNIT_CONTROL_REGISTER                0xF2000000
#define     QD_LOCUS_X_WRITE_CF_DATA_TO_UNIT_PAGE               0xF3000000
#define     QD_LOCUS_X_RESET_UNIT                               0xF4000000
//----------------------------------------------------------------------------
// *Applicable to the functions
//
//      QD_ReadCoefficientDataFromDevice
//      QD_ReadCoefficientDataFromModulePage
//      QD_ReadCoefficientDataFromSourcePage
//      QD_WriteCoefficientDataToDevice
//      QD_WriteCoefficientDataToModulePage
//      QD_WriteCoefficientDataToTargetPage
//
// The third byte (0x00FF0000) of the status is mapped as follows:
//
// The highest two bits (0xC0) = device, the lower six bits (0x3F) = pageNumber
//
//      00 000000b = Data to / from the transducer memory page 0  (0x3100XXXX)
//      00 000001b = Data to / from the transducer memory page 1  (0x3101XXXX)
//      00 000010b = Data to / from the transducer memory page 2  (0x3102XXXX)
//          .
//          .
//          .
//      00 111111b = Data to / from the transducer memory page 63  (0x313FXXXX)
//
//      01 000000b = Data to / from the QCOM module memory page 0 (0x3140XXXX)
//      01 000001b = Data to / from the QCOM module memory page 1 (0x3141XXXX)
//      01 000010b = Data to / from the QCOM module memory page 2 (0x3142XXXX)
//          .
//          .
//          .
//      01 111111b = Data to / from the QCOM module memory page 63 (0x317FXXXX)
//
// The third (destination) byte will reflect the target device and memory page
// unless over-written by an error locus
//----------------------------------------------------------------------------
// Coefficient Data Format Structure
//----------------------------------------------------------------------------
struct _CoefficientDataFormat           // QD_COEFFICIENT_DATA_SIZE (256) bytes
{
    WORD        fileType;               // 0x010D           // offset 0x0000    // 0x010D == big endian , 0x040D = little endian
    WORD        fileVersion;            // 0x2301           // offset 0x0002    // 0x2301 == newer, 0x0001 == older
    DWORD       serialNumber;           // 0xXXXXXX0D (BCD) // offset 0x0004
    char        partNumber[8];          // DXBXXX / QSBXXX  // offset 0x0008
    WORD        calibrationYear;        // 0x2009 (BCD)     // offset 0x0010
    BYTE        calibrationMonth;       // 0x12 (BCD)       // offset 0x0012
    BYTE        calibrationDate;        // 0x31 (BCD)       // offset 0x0013
    char        minimumPressure;        // 0x00 kpsi        // offset 0x0014
    char        maximumPressure;        // 0x10 kpsi        // offset 0x0015
    char        minimumTemperature;     // X 5 �C           // offset 0x0016
    char        maximumTemperature;     // X 5 �C           // offset 0x0017
    char        calibration1Type;       // 0x01             // offset 0x0018
    char        prescale1Type;          // 0x03             // offset 0x0019
    char        pressure1FitOrder;      // 0x03             // offset 0x001A
    char        temperature1FitOrder;   // 0x03             // offset 0x001B
    float       scaleFactor1StdUnits;   // 0x39800000       // offset 0x001C
    float       scaleFactor1AltUnits;   // 0x378D3466       // offset 0x0020
    long        offset1AlternateUnits;  // 0x00000000       // offset 0x0024
    char        coefficients1[100];                         // offset 0x0028
    char        calibration2Type;       // 0x02             // offset 0x008C
    char        prescale2Type;          // 0x03             // offset 0x008D
    char        pressure2FitOrder;      // 0x00             // offset 0x008E
    char        temperature2FitOrder;   // 0x03             // offset 0x008F
    float       scaleFactor2StdUnits;   // 0x39800000       // offset 0x0090
    float       scaleFactor2AltUnits;   // 0x39E66666       // offset 0x0094
    long        offset2AlternateUnits;  // 0x00011C72       // offset 0x0098
    char        coefficients2[96];                          // offset 0x009C
    BYTE        endOfFile[3];           // 0x0000FF         // offset 0x00FC
    BYTE        checksum;                                   // offset 0x00FF
};                                      // end of struct _CoefficientDataFormat
//----------------------------------------------------------------------------
// UnitDeviceInfo structure
//----------------------------------------------------------------------------
struct _UnitDeviceInfo                  // QD_FIRMWARE_DEVICE_INFO_SIZE (9) bytes
{
    // serialString is not returned populated during QD_CMD_GET_DEVICE_INFO
//    char        serialString[QD_FIRMWARE_SERIAL_STRING_SIZE];                   // 7
    BYTE        bootloaderFWVersionHigh;
    BYTE        bootloaderFWVersionLow;
    BYTE        libraryFWVersionHigh;
    BYTE        libraryFWVersionLow;
    BYTE        applicationFWVersionHigh;
    BYTE        applicationFWVersionLow;
    WORD        signature;
    BYTE        deviceCode;
};                                      // end of struct _UnitDeviceInfo
#endif      // QDUSB_H
//============================================================================
// End of qdUSB.h
//============================================================================
