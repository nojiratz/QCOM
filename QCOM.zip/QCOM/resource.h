//{{NO_DEPENDENCIES}}=========================================================
//
// Resource.h
//
// Definitions created by Microsoft Visual C++ and used by QCOM.rc
//
// Copyright (C) 2011 - 2014 Quartzdyne, Inc.  All rights reserved.
//
// No part of this source code may be reproduced or transmitted in any form or
// by any means, electronic or mechanical, including photocopying, recording,
// or any information storage and retrieval system, without express written
// permission from Quartzdyne, Inc.  Further, no use of this source code is
// permitted in any form or means without a valid, written license agreement
// with Quartzdyne, Inc.  While every reasonable precaution has been taken in
// the preparation of this source code, Quartzdyne, Inc., assumes no
// responsibility for errors, omissions, or damages from the use of the source
// code contained herein.
//
// NEITHER QUARTZDYNE, INC., ANY MEMBER OF QUARTZDYNE, INC., NOR ANY PERSON OR
// ORGANIZATION ACTING ON BEHALF OF THEM MAKES ANY WARRANTY OR REPRESENTATION
// WHATSOEVER, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF MERCHANTABILITY
// OR FITNESS FOR ANY PURPOSE WITH RESPECT TO THE SOURCE CODE OR ASSUMES ANY
// LIABILITY WHATSOEVER WITH RESPECT TO ANY USE OF THE SOURCE CODE OR ANY
// PORTION THEREOF OR WITH RESPECT TO ANY DAMAGES THAT MAY RESULT FROM SUCH
// USE.
//
// Noji Ratzlaff
//
// See QCOM.log for a complete history of all updates, changes, and revisions
// of this source and other files and policies regarding QCOM software
//
// Updated 06-13-2014
//============================================================================
#pragma once
//----------------------------------------------------------------------------
// Program version
//----------------------------------------------------------------------------
#define     QCOM_VERSION_MAJOR              1
#define     QCOM_VERSION_MAJOR_STR          "1"
#define     QCOM_VERSION_MINOR              1
#define     QCOM_VERSION_MINOR_STR          "1"
#define     QCOM_VERSION_BUILD              0
#define     QCOM_VERSION_BUILD_STR          "0"
#define     QCOM_VERSION_REV                0
#define     QCOM_VERSION_REV_STR            "0"
#define     QCOM_VERSION_FILE               QCOM_VERSION_MAJOR, QCOM_VERSION_MINOR, QCOM_VERSION_BUILD, QCOM_VERSION_REV
#define     QCOM_VERSION_PRODUCT            QCOM_VERSION_FILE
//----------------------------------------------------------------------------
// Visible file properties
//----------------------------------------------------------------------------
#define     QCOM_VERSION_FILE_DESCRIPTION   value "FileDescription", "QCOM Transducer Communication Software\0"
#define     QCOM_VERSION_FILE_VERSION       value "FileVersion", QCOM_VERSION_MAJOR_STR "." QCOM_VERSION_MINOR_STR "." QCOM_VERSION_BUILD_STR "." QCOM_VERSION_REV_STR "\0"
#define     QCOM_VERSION_PRODUCT_NAME       value "ProductName", "QCOM\0"
#define     QCOM_VERSION_PRODUCT_VERSION    value "ProductVersion", QCOM_VERSION_MAJOR_STR "." QCOM_VERSION_MINOR_STR "." QCOM_VERSION_BUILD_STR "." QCOM_VERSION_REV_STR "\0"
#define     QCOM_VERSION_LEGAL_COPYRIGHT    value "LegalCopyright", "� 2015 Quartzdyne, Inc.\0"
#define     QCOM_VERSION_LEGAL_TRADEMARKS   value "LegalTrademarks", "A Dover company. All rights reserved.\0"
#define     QCOM_VERSION_ORIGINAL_FILENAME  value "OriginalFilename", "QCOM.exe\0"
//----------------------------------------------------------------------------
// Hidden file properties
//----------------------------------------------------------------------------
#define     QCOM_VERSION_BUILD_STRING       value "Build", QCOM_VERSION_MAJOR_STR "." QCOM_VERSION_MINOR_STR "." QCOM_VERSION_BUILD_STR "." QCOM_VERSION_REV_STR "\0"
#define     QCOM_VERSION_COMPANY_NAME       value "CompanyName", "Quartzdyne, Inc.\0"
#define     QCOM_VERSION_COMMENTS           value "Comments", "Quartzdyne Software\0"
#define     QCOM_VERSION_DEVELOPER          value "Developer", "Noji Ratzlaff\0"
#define     QCOM_VERSION_INTERNAL_NAME      value "InternalName", "QCOM\0"
#define     QCOM_VERSION_PRIVATE_BUILD      value "PrivateBuild", "Noji Ratzlaff\0"
#define     QCOM_VERSION_SPECIAL_BUILD      value "SpecialBuild", "Noji Ratzlaff\0"
#define     QCOM_VERSION_SUPPORT            value "Support", "http://qd.quartzdyne.com/QCOM\0"
#define     QCOM_VERSION_USERS              value "Users", "Unlimited\0"
//----------------------------------------------------------------------------
// Program building block identifiers
//----------------------------------------------------------------------------
#define     IDS_APP_TITLE                   103
#define     IDR_MAINFRAME                   128
#define     IDI_QCOM                        102
#define     IDI_SMALL                       103
//----------------------------------------------------------------------------
// APS definitions
//----------------------------------------------------------------------------
#ifdef      APSTUDIO_INVOKED
#ifndef     APSTUDIO_READONLY_SYMBOLS
#define     _APS_NO_MFC                     130
#define     _APS_NEXT_RESOURCE_VALUE        129
#define     _APS_NEXT_COMMAND_VALUE         32771
#define     _APS_NEXT_CONTROL_VALUE         1000
#define     _APS_NEXT_SYMED_VALUE           110
#endif      // APSTUDIO_READONLY_SYMBOLS
#endif      // APSTUDIO_INVOKED
//============================================================================
// End of resource.h
//============================================================================
